<?php
//wajib urut
$this->user_login->proteksi_halaman();
require_once('v_header.php');
require_once('v_sidebar.php');
require_once('v_content.php');
require_once('v_footer.php');
