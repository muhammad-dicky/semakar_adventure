<html>
<head>
    <title>Proses Pembayaran</title>
</head>
<body>
    <!-- Tampilkan pop-up pembayaran menggunakan Snap Token -->
    <script src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="<?php echo $snapToken; ?>">
    
</script>
<script >
    console.log('<?php echo $snapToken; ?>');
</script>
</body>
</html>
