<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-27 01:14:27 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-27 01:14:27 --> Config Class Initialized
INFO - 2023-11-27 01:14:27 --> Hooks Class Initialized
DEBUG - 2023-11-27 01:14:27 --> UTF-8 Support Enabled
INFO - 2023-11-27 01:14:27 --> Utf8 Class Initialized
INFO - 2023-11-27 01:14:27 --> URI Class Initialized
DEBUG - 2023-11-27 01:14:27 --> No URI present. Default controller set.
INFO - 2023-11-27 01:14:27 --> Router Class Initialized
INFO - 2023-11-27 01:14:27 --> Output Class Initialized
INFO - 2023-11-27 01:14:27 --> Security Class Initialized
DEBUG - 2023-11-27 01:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 01:14:27 --> Input Class Initialized
INFO - 2023-11-27 01:14:27 --> Language Class Initialized
INFO - 2023-11-27 01:14:27 --> Loader Class Initialized
INFO - 2023-11-27 01:14:27 --> Helper loaded: url_helper
INFO - 2023-11-27 01:14:27 --> Helper loaded: form_helper
INFO - 2023-11-27 01:14:27 --> Helper loaded: file_helper
INFO - 2023-11-27 01:14:27 --> Database Driver Class Initialized
DEBUG - 2023-11-27 01:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-27 01:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 01:14:27 --> Form Validation Class Initialized
INFO - 2023-11-27 01:14:27 --> Upload Class Initialized
INFO - 2023-11-27 01:14:27 --> Model "M_auth" initialized
INFO - 2023-11-27 01:14:27 --> Model "M_user" initialized
INFO - 2023-11-27 01:14:27 --> Model "M_produk" initialized
INFO - 2023-11-27 01:14:27 --> Controller Class Initialized
INFO - 2023-11-27 01:14:27 --> Model "M_pelanggan" initialized
INFO - 2023-11-27 01:14:27 --> Model "M_produk" initialized
DEBUG - 2023-11-27 01:14:27 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-27 01:14:27 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-27 01:14:27 --> Model "M_transaksi" initialized
INFO - 2023-11-27 01:14:27 --> Model "M_bank" initialized
INFO - 2023-11-27 01:14:27 --> Model "M_pesan" initialized
DEBUG - 2023-11-27 01:14:27 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-27 01:14:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-27 01:14:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-27 01:14:27 --> Final output sent to browser
DEBUG - 2023-11-27 01:14:27 --> Total execution time: 0.0344
ERROR - 2023-11-27 07:16:13 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-27 07:16:13 --> Config Class Initialized
INFO - 2023-11-27 07:16:13 --> Hooks Class Initialized
DEBUG - 2023-11-27 07:16:13 --> UTF-8 Support Enabled
INFO - 2023-11-27 07:16:13 --> Utf8 Class Initialized
INFO - 2023-11-27 07:16:13 --> URI Class Initialized
DEBUG - 2023-11-27 07:16:13 --> No URI present. Default controller set.
INFO - 2023-11-27 07:16:13 --> Router Class Initialized
INFO - 2023-11-27 07:16:13 --> Output Class Initialized
INFO - 2023-11-27 07:16:13 --> Security Class Initialized
DEBUG - 2023-11-27 07:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 07:16:13 --> Input Class Initialized
INFO - 2023-11-27 07:16:13 --> Language Class Initialized
INFO - 2023-11-27 07:16:13 --> Loader Class Initialized
INFO - 2023-11-27 07:16:13 --> Helper loaded: url_helper
INFO - 2023-11-27 07:16:13 --> Helper loaded: form_helper
INFO - 2023-11-27 07:16:13 --> Helper loaded: file_helper
INFO - 2023-11-27 07:16:13 --> Database Driver Class Initialized
DEBUG - 2023-11-27 07:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-27 07:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 07:16:13 --> Form Validation Class Initialized
INFO - 2023-11-27 07:16:13 --> Upload Class Initialized
INFO - 2023-11-27 07:16:13 --> Model "M_auth" initialized
INFO - 2023-11-27 07:16:13 --> Model "M_user" initialized
INFO - 2023-11-27 07:16:13 --> Model "M_produk" initialized
INFO - 2023-11-27 07:16:13 --> Controller Class Initialized
INFO - 2023-11-27 07:16:13 --> Model "M_pelanggan" initialized
INFO - 2023-11-27 07:16:13 --> Model "M_produk" initialized
DEBUG - 2023-11-27 07:16:13 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-27 07:16:13 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-27 07:16:13 --> Model "M_transaksi" initialized
INFO - 2023-11-27 07:16:13 --> Model "M_bank" initialized
INFO - 2023-11-27 07:16:13 --> Model "M_pesan" initialized
DEBUG - 2023-11-27 07:16:13 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-27 07:16:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-27 07:16:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-27 07:16:13 --> Final output sent to browser
DEBUG - 2023-11-27 07:16:13 --> Total execution time: 0.0368
ERROR - 2023-11-27 09:37:01 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-27 09:37:01 --> Config Class Initialized
INFO - 2023-11-27 09:37:01 --> Hooks Class Initialized
DEBUG - 2023-11-27 09:37:01 --> UTF-8 Support Enabled
INFO - 2023-11-27 09:37:01 --> Utf8 Class Initialized
INFO - 2023-11-27 09:37:01 --> URI Class Initialized
DEBUG - 2023-11-27 09:37:01 --> No URI present. Default controller set.
INFO - 2023-11-27 09:37:01 --> Router Class Initialized
INFO - 2023-11-27 09:37:01 --> Output Class Initialized
INFO - 2023-11-27 09:37:01 --> Security Class Initialized
DEBUG - 2023-11-27 09:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 09:37:01 --> Input Class Initialized
INFO - 2023-11-27 09:37:01 --> Language Class Initialized
INFO - 2023-11-27 09:37:01 --> Loader Class Initialized
INFO - 2023-11-27 09:37:01 --> Helper loaded: url_helper
INFO - 2023-11-27 09:37:01 --> Helper loaded: form_helper
INFO - 2023-11-27 09:37:01 --> Helper loaded: file_helper
INFO - 2023-11-27 09:37:01 --> Database Driver Class Initialized
DEBUG - 2023-11-27 09:37:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-27 09:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 09:37:01 --> Form Validation Class Initialized
INFO - 2023-11-27 09:37:01 --> Upload Class Initialized
INFO - 2023-11-27 09:37:01 --> Model "M_auth" initialized
INFO - 2023-11-27 09:37:01 --> Model "M_user" initialized
INFO - 2023-11-27 09:37:01 --> Model "M_produk" initialized
INFO - 2023-11-27 09:37:01 --> Controller Class Initialized
INFO - 2023-11-27 09:37:01 --> Model "M_pelanggan" initialized
INFO - 2023-11-27 09:37:01 --> Model "M_produk" initialized
DEBUG - 2023-11-27 09:37:01 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-27 09:37:01 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-27 09:37:01 --> Model "M_transaksi" initialized
INFO - 2023-11-27 09:37:01 --> Model "M_bank" initialized
INFO - 2023-11-27 09:37:01 --> Model "M_pesan" initialized
DEBUG - 2023-11-27 09:37:01 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-27 09:37:01 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-27 09:37:01 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-27 09:37:01 --> Final output sent to browser
DEBUG - 2023-11-27 09:37:01 --> Total execution time: 0.0317
ERROR - 2023-11-27 09:37:02 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-27 09:37:02 --> Config Class Initialized
INFO - 2023-11-27 09:37:02 --> Hooks Class Initialized
DEBUG - 2023-11-27 09:37:02 --> UTF-8 Support Enabled
INFO - 2023-11-27 09:37:02 --> Utf8 Class Initialized
INFO - 2023-11-27 09:37:02 --> URI Class Initialized
INFO - 2023-11-27 09:37:02 --> Router Class Initialized
INFO - 2023-11-27 09:37:02 --> Output Class Initialized
INFO - 2023-11-27 09:37:02 --> Security Class Initialized
DEBUG - 2023-11-27 09:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 09:37:02 --> Input Class Initialized
INFO - 2023-11-27 09:37:02 --> Language Class Initialized
INFO - 2023-11-27 09:37:02 --> Loader Class Initialized
INFO - 2023-11-27 09:37:02 --> Helper loaded: url_helper
INFO - 2023-11-27 09:37:02 --> Helper loaded: form_helper
INFO - 2023-11-27 09:37:02 --> Helper loaded: file_helper
INFO - 2023-11-27 09:37:02 --> Database Driver Class Initialized
DEBUG - 2023-11-27 09:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-27 09:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 09:37:02 --> Form Validation Class Initialized
INFO - 2023-11-27 09:37:02 --> Upload Class Initialized
INFO - 2023-11-27 09:37:02 --> Model "M_auth" initialized
INFO - 2023-11-27 09:37:02 --> Model "M_user" initialized
INFO - 2023-11-27 09:37:02 --> Model "M_produk" initialized
INFO - 2023-11-27 09:37:02 --> Controller Class Initialized
INFO - 2023-11-27 09:37:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-27 09:37:02 --> Final output sent to browser
DEBUG - 2023-11-27 09:37:02 --> Total execution time: 0.0034
ERROR - 2023-11-27 13:01:44 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-27 13:01:44 --> Config Class Initialized
INFO - 2023-11-27 13:01:44 --> Hooks Class Initialized
DEBUG - 2023-11-27 13:01:44 --> UTF-8 Support Enabled
INFO - 2023-11-27 13:01:44 --> Utf8 Class Initialized
INFO - 2023-11-27 13:01:44 --> URI Class Initialized
INFO - 2023-11-27 13:01:44 --> Router Class Initialized
INFO - 2023-11-27 13:01:44 --> Output Class Initialized
INFO - 2023-11-27 13:01:44 --> Security Class Initialized
DEBUG - 2023-11-27 13:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 13:01:44 --> Input Class Initialized
INFO - 2023-11-27 13:01:44 --> Language Class Initialized
INFO - 2023-11-27 13:01:44 --> Loader Class Initialized
INFO - 2023-11-27 13:01:44 --> Helper loaded: url_helper
INFO - 2023-11-27 13:01:44 --> Helper loaded: form_helper
INFO - 2023-11-27 13:01:44 --> Helper loaded: file_helper
INFO - 2023-11-27 13:01:44 --> Database Driver Class Initialized
DEBUG - 2023-11-27 13:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-27 13:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 13:01:44 --> Form Validation Class Initialized
INFO - 2023-11-27 13:01:44 --> Upload Class Initialized
INFO - 2023-11-27 13:01:44 --> Model "M_auth" initialized
INFO - 2023-11-27 13:01:44 --> Model "M_user" initialized
INFO - 2023-11-27 13:01:44 --> Model "M_produk" initialized
INFO - 2023-11-27 13:01:44 --> Controller Class Initialized
INFO - 2023-11-27 13:01:44 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-27 13:01:44 --> Final output sent to browser
DEBUG - 2023-11-27 13:01:44 --> Total execution time: 0.0250
ERROR - 2023-11-27 13:01:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-27 13:01:45 --> Config Class Initialized
INFO - 2023-11-27 13:01:45 --> Hooks Class Initialized
DEBUG - 2023-11-27 13:01:45 --> UTF-8 Support Enabled
INFO - 2023-11-27 13:01:45 --> Utf8 Class Initialized
INFO - 2023-11-27 13:01:45 --> URI Class Initialized
DEBUG - 2023-11-27 13:01:45 --> No URI present. Default controller set.
INFO - 2023-11-27 13:01:45 --> Router Class Initialized
INFO - 2023-11-27 13:01:45 --> Output Class Initialized
INFO - 2023-11-27 13:01:45 --> Security Class Initialized
DEBUG - 2023-11-27 13:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 13:01:45 --> Input Class Initialized
INFO - 2023-11-27 13:01:45 --> Language Class Initialized
INFO - 2023-11-27 13:01:45 --> Loader Class Initialized
INFO - 2023-11-27 13:01:45 --> Helper loaded: url_helper
INFO - 2023-11-27 13:01:45 --> Helper loaded: form_helper
INFO - 2023-11-27 13:01:45 --> Helper loaded: file_helper
INFO - 2023-11-27 13:01:45 --> Database Driver Class Initialized
DEBUG - 2023-11-27 13:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-27 13:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 13:01:45 --> Form Validation Class Initialized
INFO - 2023-11-27 13:01:45 --> Upload Class Initialized
INFO - 2023-11-27 13:01:45 --> Model "M_auth" initialized
INFO - 2023-11-27 13:01:45 --> Model "M_user" initialized
INFO - 2023-11-27 13:01:45 --> Model "M_produk" initialized
INFO - 2023-11-27 13:01:45 --> Controller Class Initialized
INFO - 2023-11-27 13:01:45 --> Model "M_pelanggan" initialized
INFO - 2023-11-27 13:01:45 --> Model "M_produk" initialized
DEBUG - 2023-11-27 13:01:45 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-27 13:01:45 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-27 13:01:45 --> Model "M_transaksi" initialized
INFO - 2023-11-27 13:01:45 --> Model "M_bank" initialized
INFO - 2023-11-27 13:01:45 --> Model "M_pesan" initialized
DEBUG - 2023-11-27 13:01:45 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-27 13:01:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-27 13:01:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-27 13:01:45 --> Final output sent to browser
DEBUG - 2023-11-27 13:01:45 --> Total execution time: 0.0112
ERROR - 2023-11-27 15:16:15 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-27 15:16:15 --> Config Class Initialized
INFO - 2023-11-27 15:16:15 --> Hooks Class Initialized
DEBUG - 2023-11-27 15:16:16 --> UTF-8 Support Enabled
INFO - 2023-11-27 15:16:16 --> Utf8 Class Initialized
INFO - 2023-11-27 15:16:16 --> URI Class Initialized
DEBUG - 2023-11-27 15:16:16 --> No URI present. Default controller set.
INFO - 2023-11-27 15:16:16 --> Router Class Initialized
INFO - 2023-11-27 15:16:16 --> Output Class Initialized
INFO - 2023-11-27 15:16:16 --> Security Class Initialized
DEBUG - 2023-11-27 15:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 15:16:16 --> Input Class Initialized
INFO - 2023-11-27 15:16:16 --> Language Class Initialized
INFO - 2023-11-27 15:16:16 --> Loader Class Initialized
INFO - 2023-11-27 15:16:16 --> Helper loaded: url_helper
INFO - 2023-11-27 15:16:16 --> Helper loaded: form_helper
INFO - 2023-11-27 15:16:16 --> Helper loaded: file_helper
INFO - 2023-11-27 15:16:16 --> Database Driver Class Initialized
DEBUG - 2023-11-27 15:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-27 15:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 15:16:16 --> Form Validation Class Initialized
INFO - 2023-11-27 15:16:16 --> Upload Class Initialized
INFO - 2023-11-27 15:16:16 --> Model "M_auth" initialized
INFO - 2023-11-27 15:16:16 --> Model "M_user" initialized
INFO - 2023-11-27 15:16:16 --> Model "M_produk" initialized
INFO - 2023-11-27 15:16:16 --> Controller Class Initialized
INFO - 2023-11-27 15:16:16 --> Model "M_pelanggan" initialized
INFO - 2023-11-27 15:16:16 --> Model "M_produk" initialized
DEBUG - 2023-11-27 15:16:16 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-27 15:16:16 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-27 15:16:16 --> Model "M_transaksi" initialized
INFO - 2023-11-27 15:16:16 --> Model "M_bank" initialized
INFO - 2023-11-27 15:16:16 --> Model "M_pesan" initialized
DEBUG - 2023-11-27 15:16:16 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-27 15:16:16 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-27 15:16:16 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-27 15:16:16 --> Final output sent to browser
DEBUG - 2023-11-27 15:16:16 --> Total execution time: 0.0336
ERROR - 2023-11-27 20:18:25 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-27 20:18:25 --> Config Class Initialized
INFO - 2023-11-27 20:18:25 --> Hooks Class Initialized
DEBUG - 2023-11-27 20:18:25 --> UTF-8 Support Enabled
INFO - 2023-11-27 20:18:25 --> Utf8 Class Initialized
INFO - 2023-11-27 20:18:25 --> URI Class Initialized
DEBUG - 2023-11-27 20:18:25 --> No URI present. Default controller set.
INFO - 2023-11-27 20:18:25 --> Router Class Initialized
INFO - 2023-11-27 20:18:25 --> Output Class Initialized
INFO - 2023-11-27 20:18:25 --> Security Class Initialized
DEBUG - 2023-11-27 20:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 20:18:25 --> Input Class Initialized
INFO - 2023-11-27 20:18:25 --> Language Class Initialized
INFO - 2023-11-27 20:18:25 --> Loader Class Initialized
INFO - 2023-11-27 20:18:25 --> Helper loaded: url_helper
INFO - 2023-11-27 20:18:25 --> Helper loaded: form_helper
INFO - 2023-11-27 20:18:25 --> Helper loaded: file_helper
INFO - 2023-11-27 20:18:25 --> Database Driver Class Initialized
DEBUG - 2023-11-27 20:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-27 20:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 20:18:25 --> Form Validation Class Initialized
INFO - 2023-11-27 20:18:25 --> Upload Class Initialized
INFO - 2023-11-27 20:18:25 --> Model "M_auth" initialized
INFO - 2023-11-27 20:18:25 --> Model "M_user" initialized
INFO - 2023-11-27 20:18:25 --> Model "M_produk" initialized
INFO - 2023-11-27 20:18:25 --> Controller Class Initialized
INFO - 2023-11-27 20:18:25 --> Model "M_pelanggan" initialized
INFO - 2023-11-27 20:18:25 --> Model "M_produk" initialized
DEBUG - 2023-11-27 20:18:25 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-27 20:18:25 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-27 20:18:25 --> Model "M_transaksi" initialized
INFO - 2023-11-27 20:18:25 --> Model "M_bank" initialized
INFO - 2023-11-27 20:18:25 --> Model "M_pesan" initialized
DEBUG - 2023-11-27 20:18:25 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-27 20:18:25 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-27 20:18:25 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-27 20:18:25 --> Final output sent to browser
DEBUG - 2023-11-27 20:18:25 --> Total execution time: 0.0414
ERROR - 2023-11-27 21:54:18 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-27 21:54:18 --> Config Class Initialized
INFO - 2023-11-27 21:54:18 --> Hooks Class Initialized
DEBUG - 2023-11-27 21:54:18 --> UTF-8 Support Enabled
INFO - 2023-11-27 21:54:18 --> Utf8 Class Initialized
INFO - 2023-11-27 21:54:18 --> URI Class Initialized
INFO - 2023-11-27 21:54:18 --> Router Class Initialized
INFO - 2023-11-27 21:54:18 --> Output Class Initialized
INFO - 2023-11-27 21:54:18 --> Security Class Initialized
DEBUG - 2023-11-27 21:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 21:54:18 --> Input Class Initialized
INFO - 2023-11-27 21:54:18 --> Language Class Initialized
INFO - 2023-11-27 21:54:18 --> Loader Class Initialized
INFO - 2023-11-27 21:54:18 --> Helper loaded: url_helper
INFO - 2023-11-27 21:54:18 --> Helper loaded: form_helper
INFO - 2023-11-27 21:54:18 --> Helper loaded: file_helper
INFO - 2023-11-27 21:54:18 --> Database Driver Class Initialized
DEBUG - 2023-11-27 21:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-27 21:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 21:54:18 --> Form Validation Class Initialized
INFO - 2023-11-27 21:54:18 --> Upload Class Initialized
INFO - 2023-11-27 21:54:18 --> Model "M_auth" initialized
INFO - 2023-11-27 21:54:18 --> Model "M_user" initialized
INFO - 2023-11-27 21:54:18 --> Model "M_produk" initialized
INFO - 2023-11-27 21:54:18 --> Controller Class Initialized
INFO - 2023-11-27 21:54:18 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-27 21:54:18 --> Final output sent to browser
DEBUG - 2023-11-27 21:54:18 --> Total execution time: 0.0279
ERROR - 2023-11-27 22:26:39 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-27 22:26:39 --> Config Class Initialized
INFO - 2023-11-27 22:26:39 --> Hooks Class Initialized
DEBUG - 2023-11-27 22:26:39 --> UTF-8 Support Enabled
INFO - 2023-11-27 22:26:39 --> Utf8 Class Initialized
INFO - 2023-11-27 22:26:39 --> URI Class Initialized
DEBUG - 2023-11-27 22:26:39 --> No URI present. Default controller set.
INFO - 2023-11-27 22:26:39 --> Router Class Initialized
INFO - 2023-11-27 22:26:39 --> Output Class Initialized
INFO - 2023-11-27 22:26:39 --> Security Class Initialized
DEBUG - 2023-11-27 22:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 22:26:39 --> Input Class Initialized
INFO - 2023-11-27 22:26:39 --> Language Class Initialized
INFO - 2023-11-27 22:26:39 --> Loader Class Initialized
INFO - 2023-11-27 22:26:39 --> Helper loaded: url_helper
INFO - 2023-11-27 22:26:39 --> Helper loaded: form_helper
INFO - 2023-11-27 22:26:39 --> Helper loaded: file_helper
INFO - 2023-11-27 22:26:39 --> Database Driver Class Initialized
DEBUG - 2023-11-27 22:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-27 22:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 22:26:39 --> Form Validation Class Initialized
INFO - 2023-11-27 22:26:39 --> Upload Class Initialized
INFO - 2023-11-27 22:26:39 --> Model "M_auth" initialized
INFO - 2023-11-27 22:26:39 --> Model "M_user" initialized
INFO - 2023-11-27 22:26:39 --> Model "M_produk" initialized
INFO - 2023-11-27 22:26:39 --> Controller Class Initialized
INFO - 2023-11-27 22:26:39 --> Model "M_pelanggan" initialized
INFO - 2023-11-27 22:26:39 --> Model "M_produk" initialized
DEBUG - 2023-11-27 22:26:39 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-27 22:26:39 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-27 22:26:39 --> Model "M_transaksi" initialized
INFO - 2023-11-27 22:26:39 --> Model "M_bank" initialized
INFO - 2023-11-27 22:26:39 --> Model "M_pesan" initialized
DEBUG - 2023-11-27 22:26:39 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-27 22:26:39 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-27 22:26:39 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-27 22:26:39 --> Final output sent to browser
DEBUG - 2023-11-27 22:26:39 --> Total execution time: 0.0317
