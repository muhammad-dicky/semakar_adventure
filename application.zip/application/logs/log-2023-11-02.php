<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-02 09:03:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:03:25 --> Config Class Initialized
INFO - 2023-11-02 09:03:25 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:03:25 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:03:25 --> Utf8 Class Initialized
INFO - 2023-11-02 09:03:25 --> URI Class Initialized
DEBUG - 2023-11-02 09:03:25 --> No URI present. Default controller set.
INFO - 2023-11-02 09:03:25 --> Router Class Initialized
INFO - 2023-11-02 09:03:25 --> Output Class Initialized
INFO - 2023-11-02 09:03:25 --> Security Class Initialized
DEBUG - 2023-11-02 09:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:03:25 --> Input Class Initialized
INFO - 2023-11-02 09:03:25 --> Language Class Initialized
INFO - 2023-11-02 09:03:25 --> Loader Class Initialized
INFO - 2023-11-02 09:03:25 --> Helper loaded: url_helper
INFO - 2023-11-02 09:03:25 --> Helper loaded: form_helper
INFO - 2023-11-02 09:03:25 --> Helper loaded: file_helper
INFO - 2023-11-02 09:03:26 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:03:26 --> Form Validation Class Initialized
INFO - 2023-11-02 09:03:26 --> Upload Class Initialized
INFO - 2023-11-02 09:03:26 --> Model "M_auth" initialized
INFO - 2023-11-02 09:03:26 --> Model "M_user" initialized
INFO - 2023-11-02 09:03:26 --> Model "M_produk" initialized
INFO - 2023-11-02 09:03:26 --> Controller Class Initialized
INFO - 2023-11-02 09:03:26 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:03:26 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:03:26 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:03:26 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:03:26 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:03:26 --> Model "M_bank" initialized
INFO - 2023-11-02 09:03:26 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:03:26 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:03:26 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:03:26 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/index.php
INFO - 2023-11-02 09:03:26 --> Final output sent to browser
DEBUG - 2023-11-02 09:03:26 --> Total execution time: 0.5223
ERROR - 2023-11-02 09:04:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:04:19 --> Config Class Initialized
INFO - 2023-11-02 09:04:19 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:04:19 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:04:19 --> Utf8 Class Initialized
INFO - 2023-11-02 09:04:19 --> URI Class Initialized
DEBUG - 2023-11-02 09:04:19 --> No URI present. Default controller set.
INFO - 2023-11-02 09:04:19 --> Router Class Initialized
INFO - 2023-11-02 09:04:19 --> Output Class Initialized
INFO - 2023-11-02 09:04:19 --> Security Class Initialized
DEBUG - 2023-11-02 09:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:04:19 --> Input Class Initialized
INFO - 2023-11-02 09:04:19 --> Language Class Initialized
INFO - 2023-11-02 09:04:19 --> Loader Class Initialized
INFO - 2023-11-02 09:04:19 --> Helper loaded: url_helper
INFO - 2023-11-02 09:04:19 --> Helper loaded: form_helper
INFO - 2023-11-02 09:04:19 --> Helper loaded: file_helper
INFO - 2023-11-02 09:04:19 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:04:19 --> Form Validation Class Initialized
INFO - 2023-11-02 09:04:19 --> Upload Class Initialized
INFO - 2023-11-02 09:04:19 --> Model "M_auth" initialized
INFO - 2023-11-02 09:04:19 --> Model "M_user" initialized
INFO - 2023-11-02 09:04:19 --> Model "M_produk" initialized
INFO - 2023-11-02 09:04:19 --> Controller Class Initialized
INFO - 2023-11-02 09:04:19 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:04:19 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:04:19 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:04:19 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:04:19 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:04:19 --> Model "M_bank" initialized
INFO - 2023-11-02 09:04:19 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:04:19 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:04:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-11-02 09:04:19 --> Email Class Initialized
INFO - 2023-11-02 09:04:21 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-11-02 09:04:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:04:25 --> Config Class Initialized
INFO - 2023-11-02 09:04:25 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:04:25 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:04:25 --> Utf8 Class Initialized
INFO - 2023-11-02 09:04:25 --> URI Class Initialized
DEBUG - 2023-11-02 09:04:25 --> No URI present. Default controller set.
INFO - 2023-11-02 09:04:25 --> Router Class Initialized
INFO - 2023-11-02 09:04:25 --> Output Class Initialized
INFO - 2023-11-02 09:04:25 --> Security Class Initialized
DEBUG - 2023-11-02 09:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:04:25 --> Input Class Initialized
INFO - 2023-11-02 09:04:25 --> Language Class Initialized
INFO - 2023-11-02 09:04:25 --> Loader Class Initialized
INFO - 2023-11-02 09:04:25 --> Helper loaded: url_helper
INFO - 2023-11-02 09:04:25 --> Helper loaded: form_helper
INFO - 2023-11-02 09:04:25 --> Helper loaded: file_helper
INFO - 2023-11-02 09:04:25 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:04:25 --> Form Validation Class Initialized
INFO - 2023-11-02 09:04:25 --> Upload Class Initialized
INFO - 2023-11-02 09:04:25 --> Model "M_auth" initialized
INFO - 2023-11-02 09:04:25 --> Model "M_user" initialized
INFO - 2023-11-02 09:04:25 --> Model "M_produk" initialized
INFO - 2023-11-02 09:04:25 --> Controller Class Initialized
INFO - 2023-11-02 09:04:25 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:04:25 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:04:25 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:04:25 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:04:25 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:04:25 --> Model "M_bank" initialized
INFO - 2023-11-02 09:04:25 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:04:25 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:04:25 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:04:25 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/index.php
INFO - 2023-11-02 09:04:25 --> Final output sent to browser
DEBUG - 2023-11-02 09:04:25 --> Total execution time: 0.1177
ERROR - 2023-11-02 09:04:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:04:32 --> Config Class Initialized
INFO - 2023-11-02 09:04:32 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:04:32 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:04:32 --> Utf8 Class Initialized
INFO - 2023-11-02 09:04:32 --> URI Class Initialized
INFO - 2023-11-02 09:04:32 --> Router Class Initialized
INFO - 2023-11-02 09:04:32 --> Output Class Initialized
INFO - 2023-11-02 09:04:32 --> Security Class Initialized
DEBUG - 2023-11-02 09:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:04:32 --> Input Class Initialized
INFO - 2023-11-02 09:04:32 --> Language Class Initialized
INFO - 2023-11-02 09:04:32 --> Loader Class Initialized
INFO - 2023-11-02 09:04:32 --> Helper loaded: url_helper
INFO - 2023-11-02 09:04:32 --> Helper loaded: form_helper
INFO - 2023-11-02 09:04:32 --> Helper loaded: file_helper
INFO - 2023-11-02 09:04:32 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:04:32 --> Form Validation Class Initialized
INFO - 2023-11-02 09:04:32 --> Upload Class Initialized
INFO - 2023-11-02 09:04:32 --> Model "M_auth" initialized
INFO - 2023-11-02 09:04:32 --> Model "M_user" initialized
INFO - 2023-11-02 09:04:32 --> Model "M_produk" initialized
INFO - 2023-11-02 09:04:32 --> Controller Class Initialized
INFO - 2023-11-02 09:04:32 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:04:32 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:04:32 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:04:32 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:04:32 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:04:32 --> Model "M_bank" initialized
INFO - 2023-11-02 09:04:32 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:04:32 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:04:37 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:04:37 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 09:04:37 --> Final output sent to browser
DEBUG - 2023-11-02 09:04:37 --> Total execution time: 5.3401
ERROR - 2023-11-02 09:04:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:04:43 --> Config Class Initialized
INFO - 2023-11-02 09:04:43 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:04:43 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:04:43 --> Utf8 Class Initialized
INFO - 2023-11-02 09:04:43 --> URI Class Initialized
DEBUG - 2023-11-02 09:04:43 --> No URI present. Default controller set.
INFO - 2023-11-02 09:04:43 --> Router Class Initialized
INFO - 2023-11-02 09:04:43 --> Output Class Initialized
INFO - 2023-11-02 09:04:43 --> Security Class Initialized
DEBUG - 2023-11-02 09:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:04:43 --> Input Class Initialized
INFO - 2023-11-02 09:04:43 --> Language Class Initialized
INFO - 2023-11-02 09:04:43 --> Loader Class Initialized
INFO - 2023-11-02 09:04:43 --> Helper loaded: url_helper
INFO - 2023-11-02 09:04:43 --> Helper loaded: form_helper
INFO - 2023-11-02 09:04:43 --> Helper loaded: file_helper
INFO - 2023-11-02 09:04:43 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:04:43 --> Form Validation Class Initialized
INFO - 2023-11-02 09:04:43 --> Upload Class Initialized
INFO - 2023-11-02 09:04:43 --> Model "M_auth" initialized
INFO - 2023-11-02 09:04:43 --> Model "M_user" initialized
INFO - 2023-11-02 09:04:43 --> Model "M_produk" initialized
INFO - 2023-11-02 09:04:43 --> Controller Class Initialized
INFO - 2023-11-02 09:04:43 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:04:43 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:04:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:04:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:04:43 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:04:43 --> Model "M_bank" initialized
INFO - 2023-11-02 09:04:43 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:04:43 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:04:43 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:04:43 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/index.php
INFO - 2023-11-02 09:04:43 --> Final output sent to browser
DEBUG - 2023-11-02 09:04:43 --> Total execution time: 0.0527
ERROR - 2023-11-02 09:04:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:04:46 --> Config Class Initialized
INFO - 2023-11-02 09:04:46 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:04:46 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:04:46 --> Utf8 Class Initialized
INFO - 2023-11-02 09:04:46 --> URI Class Initialized
INFO - 2023-11-02 09:04:46 --> Router Class Initialized
INFO - 2023-11-02 09:04:46 --> Output Class Initialized
INFO - 2023-11-02 09:04:46 --> Security Class Initialized
DEBUG - 2023-11-02 09:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:04:46 --> Input Class Initialized
INFO - 2023-11-02 09:04:46 --> Language Class Initialized
INFO - 2023-11-02 09:04:46 --> Loader Class Initialized
INFO - 2023-11-02 09:04:46 --> Helper loaded: url_helper
INFO - 2023-11-02 09:04:46 --> Helper loaded: form_helper
INFO - 2023-11-02 09:04:46 --> Helper loaded: file_helper
INFO - 2023-11-02 09:04:46 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:04:46 --> Form Validation Class Initialized
INFO - 2023-11-02 09:04:46 --> Upload Class Initialized
INFO - 2023-11-02 09:04:46 --> Model "M_auth" initialized
INFO - 2023-11-02 09:04:46 --> Model "M_user" initialized
INFO - 2023-11-02 09:04:46 --> Model "M_produk" initialized
INFO - 2023-11-02 09:04:46 --> Controller Class Initialized
INFO - 2023-11-02 09:04:46 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:04:46 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:04:46 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:04:46 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:04:46 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:04:46 --> Model "M_bank" initialized
INFO - 2023-11-02 09:04:46 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:04:46 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:04:46 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:04:46 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_produk_detail.php
INFO - 2023-11-02 09:04:46 --> Final output sent to browser
DEBUG - 2023-11-02 09:04:46 --> Total execution time: 0.1401
ERROR - 2023-11-02 09:04:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:04:57 --> Config Class Initialized
INFO - 2023-11-02 09:04:57 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:04:57 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:04:57 --> Utf8 Class Initialized
INFO - 2023-11-02 09:04:57 --> URI Class Initialized
INFO - 2023-11-02 09:04:57 --> Router Class Initialized
INFO - 2023-11-02 09:04:57 --> Output Class Initialized
INFO - 2023-11-02 09:04:57 --> Security Class Initialized
DEBUG - 2023-11-02 09:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:04:57 --> Input Class Initialized
INFO - 2023-11-02 09:04:57 --> Language Class Initialized
INFO - 2023-11-02 09:04:57 --> Loader Class Initialized
INFO - 2023-11-02 09:04:57 --> Helper loaded: url_helper
INFO - 2023-11-02 09:04:57 --> Helper loaded: form_helper
INFO - 2023-11-02 09:04:57 --> Helper loaded: file_helper
INFO - 2023-11-02 09:04:57 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:04:57 --> Form Validation Class Initialized
INFO - 2023-11-02 09:04:57 --> Upload Class Initialized
INFO - 2023-11-02 09:04:57 --> Model "M_auth" initialized
INFO - 2023-11-02 09:04:57 --> Model "M_user" initialized
INFO - 2023-11-02 09:04:57 --> Model "M_produk" initialized
INFO - 2023-11-02 09:04:57 --> Controller Class Initialized
INFO - 2023-11-02 09:04:57 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:04:57 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:04:57 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:04:57 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:04:57 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:04:57 --> Model "M_bank" initialized
INFO - 2023-11-02 09:04:57 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:04:57 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:04:57 --> Email Class Initialized
INFO - 2023-11-02 09:04:59 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-11-02 09:05:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:05:03 --> Config Class Initialized
INFO - 2023-11-02 09:05:03 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:05:03 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:05:03 --> Utf8 Class Initialized
INFO - 2023-11-02 09:05:03 --> URI Class Initialized
INFO - 2023-11-02 09:05:03 --> Router Class Initialized
INFO - 2023-11-02 09:05:03 --> Output Class Initialized
INFO - 2023-11-02 09:05:03 --> Security Class Initialized
DEBUG - 2023-11-02 09:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:05:03 --> Input Class Initialized
INFO - 2023-11-02 09:05:03 --> Language Class Initialized
INFO - 2023-11-02 09:05:03 --> Loader Class Initialized
INFO - 2023-11-02 09:05:03 --> Helper loaded: url_helper
INFO - 2023-11-02 09:05:03 --> Helper loaded: form_helper
INFO - 2023-11-02 09:05:03 --> Helper loaded: file_helper
INFO - 2023-11-02 09:05:03 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:05:03 --> Form Validation Class Initialized
INFO - 2023-11-02 09:05:03 --> Upload Class Initialized
INFO - 2023-11-02 09:05:03 --> Model "M_auth" initialized
INFO - 2023-11-02 09:05:03 --> Model "M_user" initialized
INFO - 2023-11-02 09:05:03 --> Model "M_produk" initialized
INFO - 2023-11-02 09:05:03 --> Controller Class Initialized
INFO - 2023-11-02 09:05:03 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:05:03 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:05:03 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:05:03 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:05:03 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:05:03 --> Model "M_bank" initialized
INFO - 2023-11-02 09:05:03 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:05:03 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:05:06 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:05:06 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 09:05:06 --> Final output sent to browser
DEBUG - 2023-11-02 09:05:06 --> Total execution time: 2.8271
ERROR - 2023-11-02 09:05:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:05:13 --> Config Class Initialized
INFO - 2023-11-02 09:05:13 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:05:13 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:05:13 --> Utf8 Class Initialized
INFO - 2023-11-02 09:05:13 --> URI Class Initialized
INFO - 2023-11-02 09:05:13 --> Router Class Initialized
INFO - 2023-11-02 09:05:13 --> Output Class Initialized
INFO - 2023-11-02 09:05:13 --> Security Class Initialized
DEBUG - 2023-11-02 09:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:05:13 --> Input Class Initialized
INFO - 2023-11-02 09:05:13 --> Language Class Initialized
INFO - 2023-11-02 09:05:13 --> Loader Class Initialized
INFO - 2023-11-02 09:05:13 --> Helper loaded: url_helper
INFO - 2023-11-02 09:05:13 --> Helper loaded: form_helper
INFO - 2023-11-02 09:05:13 --> Helper loaded: file_helper
INFO - 2023-11-02 09:05:13 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:05:13 --> Form Validation Class Initialized
INFO - 2023-11-02 09:05:13 --> Upload Class Initialized
INFO - 2023-11-02 09:05:13 --> Model "M_auth" initialized
INFO - 2023-11-02 09:05:13 --> Model "M_user" initialized
INFO - 2023-11-02 09:05:13 --> Model "M_produk" initialized
INFO - 2023-11-02 09:05:13 --> Controller Class Initialized
INFO - 2023-11-02 09:05:13 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:05:13 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:05:13 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:05:13 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:05:13 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:05:13 --> Model "M_bank" initialized
INFO - 2023-11-02 09:05:13 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:05:13 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:05:19 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:05:19 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 09:05:19 --> Final output sent to browser
DEBUG - 2023-11-02 09:05:19 --> Total execution time: 5.3256
ERROR - 2023-11-02 09:05:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:05:43 --> Config Class Initialized
INFO - 2023-11-02 09:05:43 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:05:43 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:05:43 --> Utf8 Class Initialized
INFO - 2023-11-02 09:05:43 --> URI Class Initialized
INFO - 2023-11-02 09:05:43 --> Router Class Initialized
INFO - 2023-11-02 09:05:43 --> Output Class Initialized
INFO - 2023-11-02 09:05:43 --> Security Class Initialized
DEBUG - 2023-11-02 09:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:05:43 --> Input Class Initialized
INFO - 2023-11-02 09:05:43 --> Language Class Initialized
INFO - 2023-11-02 09:05:43 --> Loader Class Initialized
INFO - 2023-11-02 09:05:43 --> Helper loaded: url_helper
INFO - 2023-11-02 09:05:43 --> Helper loaded: form_helper
INFO - 2023-11-02 09:05:43 --> Helper loaded: file_helper
INFO - 2023-11-02 09:05:44 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:05:44 --> Form Validation Class Initialized
INFO - 2023-11-02 09:05:44 --> Upload Class Initialized
INFO - 2023-11-02 09:05:44 --> Model "M_auth" initialized
INFO - 2023-11-02 09:05:44 --> Model "M_user" initialized
INFO - 2023-11-02 09:05:44 --> Model "M_produk" initialized
INFO - 2023-11-02 09:05:44 --> Controller Class Initialized
INFO - 2023-11-02 09:05:44 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:05:44 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:05:44 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:05:44 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:05:44 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:05:44 --> Model "M_bank" initialized
INFO - 2023-11-02 09:05:44 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:05:44 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:05:45 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:05:45 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 09:05:45 --> Final output sent to browser
DEBUG - 2023-11-02 09:05:45 --> Total execution time: 1.1221
ERROR - 2023-11-02 09:37:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:37:18 --> Config Class Initialized
INFO - 2023-11-02 09:37:18 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:37:18 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:37:18 --> Utf8 Class Initialized
INFO - 2023-11-02 09:37:18 --> URI Class Initialized
DEBUG - 2023-11-02 09:37:18 --> No URI present. Default controller set.
INFO - 2023-11-02 09:37:18 --> Router Class Initialized
INFO - 2023-11-02 09:37:18 --> Output Class Initialized
INFO - 2023-11-02 09:37:18 --> Security Class Initialized
DEBUG - 2023-11-02 09:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:37:18 --> Input Class Initialized
INFO - 2023-11-02 09:37:18 --> Language Class Initialized
INFO - 2023-11-02 09:37:18 --> Loader Class Initialized
INFO - 2023-11-02 09:37:18 --> Helper loaded: url_helper
INFO - 2023-11-02 09:37:18 --> Helper loaded: form_helper
INFO - 2023-11-02 09:37:18 --> Helper loaded: file_helper
INFO - 2023-11-02 09:37:18 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:37:18 --> Form Validation Class Initialized
INFO - 2023-11-02 09:37:18 --> Upload Class Initialized
INFO - 2023-11-02 09:37:18 --> Model "M_auth" initialized
INFO - 2023-11-02 09:37:18 --> Model "M_user" initialized
INFO - 2023-11-02 09:37:18 --> Model "M_produk" initialized
INFO - 2023-11-02 09:37:18 --> Controller Class Initialized
INFO - 2023-11-02 09:37:18 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:37:18 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:37:18 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:37:18 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:37:18 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:37:18 --> Model "M_bank" initialized
INFO - 2023-11-02 09:37:18 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:37:18 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:37:18 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:37:18 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/index.php
INFO - 2023-11-02 09:37:18 --> Final output sent to browser
DEBUG - 2023-11-02 09:37:18 --> Total execution time: 0.0627
ERROR - 2023-11-02 09:37:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:37:22 --> Config Class Initialized
INFO - 2023-11-02 09:37:22 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:37:22 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:37:22 --> Utf8 Class Initialized
INFO - 2023-11-02 09:37:22 --> URI Class Initialized
INFO - 2023-11-02 09:37:22 --> Router Class Initialized
INFO - 2023-11-02 09:37:22 --> Output Class Initialized
INFO - 2023-11-02 09:37:22 --> Security Class Initialized
DEBUG - 2023-11-02 09:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:37:22 --> Input Class Initialized
INFO - 2023-11-02 09:37:22 --> Language Class Initialized
INFO - 2023-11-02 09:37:22 --> Loader Class Initialized
INFO - 2023-11-02 09:37:22 --> Helper loaded: url_helper
INFO - 2023-11-02 09:37:22 --> Helper loaded: form_helper
INFO - 2023-11-02 09:37:22 --> Helper loaded: file_helper
INFO - 2023-11-02 09:37:22 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:37:22 --> Form Validation Class Initialized
INFO - 2023-11-02 09:37:22 --> Upload Class Initialized
INFO - 2023-11-02 09:37:22 --> Model "M_auth" initialized
INFO - 2023-11-02 09:37:22 --> Model "M_user" initialized
INFO - 2023-11-02 09:37:22 --> Model "M_produk" initialized
INFO - 2023-11-02 09:37:22 --> Controller Class Initialized
INFO - 2023-11-02 09:37:22 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:37:22 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:37:22 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:37:22 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:37:22 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:37:22 --> Model "M_bank" initialized
INFO - 2023-11-02 09:37:22 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:37:22 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:37:23 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:37:23 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 09:37:23 --> Final output sent to browser
DEBUG - 2023-11-02 09:37:23 --> Total execution time: 1.3466
ERROR - 2023-11-02 09:37:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:37:32 --> Config Class Initialized
INFO - 2023-11-02 09:37:32 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:37:32 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:37:32 --> Utf8 Class Initialized
INFO - 2023-11-02 09:37:32 --> URI Class Initialized
DEBUG - 2023-11-02 09:37:32 --> No URI present. Default controller set.
INFO - 2023-11-02 09:37:32 --> Router Class Initialized
INFO - 2023-11-02 09:37:32 --> Output Class Initialized
INFO - 2023-11-02 09:37:32 --> Security Class Initialized
DEBUG - 2023-11-02 09:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:37:32 --> Input Class Initialized
INFO - 2023-11-02 09:37:32 --> Language Class Initialized
INFO - 2023-11-02 09:37:32 --> Loader Class Initialized
INFO - 2023-11-02 09:37:32 --> Helper loaded: url_helper
INFO - 2023-11-02 09:37:32 --> Helper loaded: form_helper
INFO - 2023-11-02 09:37:32 --> Helper loaded: file_helper
INFO - 2023-11-02 09:37:32 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:37:32 --> Form Validation Class Initialized
INFO - 2023-11-02 09:37:32 --> Upload Class Initialized
INFO - 2023-11-02 09:37:32 --> Model "M_auth" initialized
INFO - 2023-11-02 09:37:32 --> Model "M_user" initialized
INFO - 2023-11-02 09:37:32 --> Model "M_produk" initialized
INFO - 2023-11-02 09:37:32 --> Controller Class Initialized
INFO - 2023-11-02 09:37:32 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:37:32 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:37:32 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:37:32 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:37:32 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:37:32 --> Model "M_bank" initialized
INFO - 2023-11-02 09:37:32 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:37:32 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:37:32 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:37:32 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/index.php
INFO - 2023-11-02 09:37:32 --> Final output sent to browser
DEBUG - 2023-11-02 09:37:32 --> Total execution time: 0.1013
ERROR - 2023-11-02 09:37:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:37:34 --> Config Class Initialized
INFO - 2023-11-02 09:37:34 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:37:34 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:37:34 --> Utf8 Class Initialized
INFO - 2023-11-02 09:37:34 --> URI Class Initialized
INFO - 2023-11-02 09:37:34 --> Router Class Initialized
INFO - 2023-11-02 09:37:34 --> Output Class Initialized
INFO - 2023-11-02 09:37:34 --> Security Class Initialized
DEBUG - 2023-11-02 09:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:37:34 --> Input Class Initialized
INFO - 2023-11-02 09:37:34 --> Language Class Initialized
INFO - 2023-11-02 09:37:34 --> Loader Class Initialized
INFO - 2023-11-02 09:37:34 --> Helper loaded: url_helper
INFO - 2023-11-02 09:37:34 --> Helper loaded: form_helper
INFO - 2023-11-02 09:37:34 --> Helper loaded: file_helper
INFO - 2023-11-02 09:37:34 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:37:34 --> Form Validation Class Initialized
INFO - 2023-11-02 09:37:34 --> Upload Class Initialized
INFO - 2023-11-02 09:37:34 --> Model "M_auth" initialized
INFO - 2023-11-02 09:37:34 --> Model "M_user" initialized
INFO - 2023-11-02 09:37:34 --> Model "M_produk" initialized
INFO - 2023-11-02 09:37:34 --> Controller Class Initialized
INFO - 2023-11-02 09:37:34 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:37:34 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:37:34 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:37:34 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:37:34 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:37:34 --> Model "M_bank" initialized
INFO - 2023-11-02 09:37:34 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:37:34 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:37:34 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:37:34 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 09:37:34 --> Final output sent to browser
DEBUG - 2023-11-02 09:37:34 --> Total execution time: 0.7173
ERROR - 2023-11-02 09:37:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:37:49 --> Config Class Initialized
INFO - 2023-11-02 09:37:49 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:37:49 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:37:49 --> Utf8 Class Initialized
INFO - 2023-11-02 09:37:49 --> URI Class Initialized
INFO - 2023-11-02 09:37:49 --> Router Class Initialized
INFO - 2023-11-02 09:37:49 --> Output Class Initialized
INFO - 2023-11-02 09:37:49 --> Security Class Initialized
DEBUG - 2023-11-02 09:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:37:49 --> Input Class Initialized
INFO - 2023-11-02 09:37:49 --> Language Class Initialized
INFO - 2023-11-02 09:37:49 --> Loader Class Initialized
INFO - 2023-11-02 09:37:49 --> Helper loaded: url_helper
INFO - 2023-11-02 09:37:49 --> Helper loaded: form_helper
INFO - 2023-11-02 09:37:49 --> Helper loaded: file_helper
INFO - 2023-11-02 09:37:49 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:37:49 --> Form Validation Class Initialized
INFO - 2023-11-02 09:37:49 --> Upload Class Initialized
INFO - 2023-11-02 09:37:49 --> Model "M_auth" initialized
INFO - 2023-11-02 09:37:49 --> Model "M_user" initialized
INFO - 2023-11-02 09:37:49 --> Model "M_produk" initialized
INFO - 2023-11-02 09:37:49 --> Controller Class Initialized
INFO - 2023-11-02 09:37:49 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:37:49 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:37:49 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:37:49 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:37:49 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:37:49 --> Model "M_bank" initialized
INFO - 2023-11-02 09:37:49 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:37:49 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:37:50 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:37:50 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 09:37:50 --> Final output sent to browser
DEBUG - 2023-11-02 09:37:50 --> Total execution time: 0.8408
ERROR - 2023-11-02 09:37:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:37:56 --> Config Class Initialized
INFO - 2023-11-02 09:37:56 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:37:56 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:37:56 --> Utf8 Class Initialized
INFO - 2023-11-02 09:37:56 --> URI Class Initialized
INFO - 2023-11-02 09:37:56 --> Router Class Initialized
INFO - 2023-11-02 09:37:56 --> Output Class Initialized
INFO - 2023-11-02 09:37:56 --> Security Class Initialized
DEBUG - 2023-11-02 09:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:37:56 --> Input Class Initialized
INFO - 2023-11-02 09:37:56 --> Language Class Initialized
INFO - 2023-11-02 09:37:56 --> Loader Class Initialized
INFO - 2023-11-02 09:37:56 --> Helper loaded: url_helper
INFO - 2023-11-02 09:37:56 --> Helper loaded: form_helper
INFO - 2023-11-02 09:37:56 --> Helper loaded: file_helper
INFO - 2023-11-02 09:37:56 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:37:56 --> Form Validation Class Initialized
INFO - 2023-11-02 09:37:56 --> Upload Class Initialized
INFO - 2023-11-02 09:37:56 --> Model "M_auth" initialized
INFO - 2023-11-02 09:37:56 --> Model "M_user" initialized
INFO - 2023-11-02 09:37:56 --> Model "M_produk" initialized
INFO - 2023-11-02 09:37:56 --> Controller Class Initialized
INFO - 2023-11-02 09:37:56 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:37:56 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:37:56 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:37:56 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:37:56 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:37:56 --> Model "M_bank" initialized
INFO - 2023-11-02 09:37:56 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:37:56 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:37:56 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:37:56 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 09:37:56 --> Final output sent to browser
DEBUG - 2023-11-02 09:37:56 --> Total execution time: 0.4130
ERROR - 2023-11-02 09:38:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:38:22 --> Config Class Initialized
INFO - 2023-11-02 09:38:22 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:38:22 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:38:22 --> Utf8 Class Initialized
INFO - 2023-11-02 09:38:22 --> URI Class Initialized
INFO - 2023-11-02 09:38:22 --> Router Class Initialized
INFO - 2023-11-02 09:38:22 --> Output Class Initialized
INFO - 2023-11-02 09:38:22 --> Security Class Initialized
DEBUG - 2023-11-02 09:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:38:22 --> Input Class Initialized
INFO - 2023-11-02 09:38:22 --> Language Class Initialized
INFO - 2023-11-02 09:38:22 --> Loader Class Initialized
INFO - 2023-11-02 09:38:22 --> Helper loaded: url_helper
INFO - 2023-11-02 09:38:22 --> Helper loaded: form_helper
INFO - 2023-11-02 09:38:22 --> Helper loaded: file_helper
INFO - 2023-11-02 09:38:22 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:38:22 --> Form Validation Class Initialized
INFO - 2023-11-02 09:38:22 --> Upload Class Initialized
INFO - 2023-11-02 09:38:22 --> Model "M_auth" initialized
INFO - 2023-11-02 09:38:22 --> Model "M_user" initialized
INFO - 2023-11-02 09:38:22 --> Model "M_produk" initialized
INFO - 2023-11-02 09:38:22 --> Controller Class Initialized
INFO - 2023-11-02 09:38:22 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:38:22 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:38:22 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:38:22 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:38:22 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:38:22 --> Model "M_bank" initialized
INFO - 2023-11-02 09:38:22 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:38:22 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:38:24 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:38:24 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 09:38:24 --> Final output sent to browser
DEBUG - 2023-11-02 09:38:24 --> Total execution time: 1.9049
ERROR - 2023-11-02 09:38:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:38:27 --> Config Class Initialized
INFO - 2023-11-02 09:38:27 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:38:27 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:38:27 --> Utf8 Class Initialized
INFO - 2023-11-02 09:38:27 --> URI Class Initialized
INFO - 2023-11-02 09:38:27 --> Router Class Initialized
INFO - 2023-11-02 09:38:27 --> Output Class Initialized
INFO - 2023-11-02 09:38:27 --> Security Class Initialized
DEBUG - 2023-11-02 09:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:38:27 --> Input Class Initialized
INFO - 2023-11-02 09:38:27 --> Language Class Initialized
INFO - 2023-11-02 09:38:27 --> Loader Class Initialized
INFO - 2023-11-02 09:38:27 --> Helper loaded: url_helper
INFO - 2023-11-02 09:38:27 --> Helper loaded: form_helper
INFO - 2023-11-02 09:38:27 --> Helper loaded: file_helper
INFO - 2023-11-02 09:38:27 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:38:27 --> Form Validation Class Initialized
INFO - 2023-11-02 09:38:27 --> Upload Class Initialized
INFO - 2023-11-02 09:38:27 --> Model "M_auth" initialized
INFO - 2023-11-02 09:38:27 --> Model "M_user" initialized
INFO - 2023-11-02 09:38:27 --> Model "M_produk" initialized
INFO - 2023-11-02 09:38:27 --> Controller Class Initialized
INFO - 2023-11-02 09:38:27 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:38:27 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:38:27 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:38:27 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:38:27 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:38:27 --> Model "M_bank" initialized
INFO - 2023-11-02 09:38:27 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:38:27 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:38:27 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:38:27 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_bayar_sekarang.php
INFO - 2023-11-02 09:38:27 --> Final output sent to browser
DEBUG - 2023-11-02 09:38:27 --> Total execution time: 0.0355
ERROR - 2023-11-02 09:38:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:38:28 --> Config Class Initialized
INFO - 2023-11-02 09:38:28 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:38:28 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:38:28 --> Utf8 Class Initialized
INFO - 2023-11-02 09:38:28 --> URI Class Initialized
INFO - 2023-11-02 09:38:28 --> Router Class Initialized
INFO - 2023-11-02 09:38:28 --> Output Class Initialized
INFO - 2023-11-02 09:38:28 --> Security Class Initialized
DEBUG - 2023-11-02 09:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:38:28 --> Input Class Initialized
INFO - 2023-11-02 09:38:28 --> Language Class Initialized
INFO - 2023-11-02 09:38:28 --> Loader Class Initialized
INFO - 2023-11-02 09:38:28 --> Helper loaded: url_helper
INFO - 2023-11-02 09:38:28 --> Helper loaded: form_helper
INFO - 2023-11-02 09:38:28 --> Helper loaded: file_helper
INFO - 2023-11-02 09:38:28 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:38:28 --> Form Validation Class Initialized
INFO - 2023-11-02 09:38:28 --> Upload Class Initialized
INFO - 2023-11-02 09:38:28 --> Model "M_auth" initialized
INFO - 2023-11-02 09:38:28 --> Model "M_user" initialized
INFO - 2023-11-02 09:38:28 --> Model "M_produk" initialized
INFO - 2023-11-02 09:38:28 --> Controller Class Initialized
INFO - 2023-11-02 09:38:28 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/not_found.php
INFO - 2023-11-02 09:38:28 --> Final output sent to browser
DEBUG - 2023-11-02 09:38:28 --> Total execution time: 0.1245
ERROR - 2023-11-02 09:38:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:38:32 --> Config Class Initialized
INFO - 2023-11-02 09:38:32 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:38:32 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:38:32 --> Utf8 Class Initialized
INFO - 2023-11-02 09:38:32 --> URI Class Initialized
INFO - 2023-11-02 09:38:32 --> Router Class Initialized
INFO - 2023-11-02 09:38:32 --> Output Class Initialized
INFO - 2023-11-02 09:38:32 --> Security Class Initialized
DEBUG - 2023-11-02 09:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:38:32 --> Input Class Initialized
INFO - 2023-11-02 09:38:32 --> Language Class Initialized
INFO - 2023-11-02 09:38:32 --> Loader Class Initialized
INFO - 2023-11-02 09:38:32 --> Helper loaded: url_helper
INFO - 2023-11-02 09:38:32 --> Helper loaded: form_helper
INFO - 2023-11-02 09:38:32 --> Helper loaded: file_helper
INFO - 2023-11-02 09:38:32 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:38:32 --> Form Validation Class Initialized
INFO - 2023-11-02 09:38:32 --> Upload Class Initialized
INFO - 2023-11-02 09:38:32 --> Model "M_auth" initialized
INFO - 2023-11-02 09:38:32 --> Model "M_user" initialized
INFO - 2023-11-02 09:38:32 --> Model "M_produk" initialized
INFO - 2023-11-02 09:38:32 --> Controller Class Initialized
INFO - 2023-11-02 09:38:32 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:38:32 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:38:32 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:38:32 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:38:32 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:38:32 --> Model "M_bank" initialized
INFO - 2023-11-02 09:38:32 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:38:32 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:38:34 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:38:34 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 09:38:34 --> Final output sent to browser
DEBUG - 2023-11-02 09:38:34 --> Total execution time: 2.2787
ERROR - 2023-11-02 09:38:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:38:36 --> Config Class Initialized
INFO - 2023-11-02 09:38:36 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:38:36 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:38:36 --> Utf8 Class Initialized
INFO - 2023-11-02 09:38:36 --> URI Class Initialized
INFO - 2023-11-02 09:38:36 --> Router Class Initialized
INFO - 2023-11-02 09:38:36 --> Output Class Initialized
INFO - 2023-11-02 09:38:36 --> Security Class Initialized
DEBUG - 2023-11-02 09:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:38:36 --> Input Class Initialized
INFO - 2023-11-02 09:38:36 --> Language Class Initialized
INFO - 2023-11-02 09:38:36 --> Loader Class Initialized
INFO - 2023-11-02 09:38:36 --> Helper loaded: url_helper
INFO - 2023-11-02 09:38:36 --> Helper loaded: form_helper
INFO - 2023-11-02 09:38:36 --> Helper loaded: file_helper
INFO - 2023-11-02 09:38:36 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:38:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:38:36 --> Form Validation Class Initialized
INFO - 2023-11-02 09:38:36 --> Upload Class Initialized
INFO - 2023-11-02 09:38:36 --> Model "M_auth" initialized
INFO - 2023-11-02 09:38:36 --> Model "M_user" initialized
INFO - 2023-11-02 09:38:36 --> Model "M_produk" initialized
INFO - 2023-11-02 09:38:36 --> Controller Class Initialized
INFO - 2023-11-02 09:38:36 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:38:36 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:38:36 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:38:36 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:38:36 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:38:36 --> Model "M_bank" initialized
INFO - 2023-11-02 09:38:36 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:38:36 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:38:36 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:38:36 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_bayar_sekarang.php
INFO - 2023-11-02 09:38:36 --> Final output sent to browser
DEBUG - 2023-11-02 09:38:36 --> Total execution time: 0.0779
ERROR - 2023-11-02 09:38:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:38:36 --> Config Class Initialized
INFO - 2023-11-02 09:38:36 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:38:36 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:38:36 --> Utf8 Class Initialized
INFO - 2023-11-02 09:38:36 --> URI Class Initialized
INFO - 2023-11-02 09:38:36 --> Router Class Initialized
INFO - 2023-11-02 09:38:36 --> Output Class Initialized
INFO - 2023-11-02 09:38:36 --> Security Class Initialized
DEBUG - 2023-11-02 09:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:38:36 --> Input Class Initialized
INFO - 2023-11-02 09:38:36 --> Language Class Initialized
INFO - 2023-11-02 09:38:36 --> Loader Class Initialized
INFO - 2023-11-02 09:38:36 --> Helper loaded: url_helper
INFO - 2023-11-02 09:38:36 --> Helper loaded: form_helper
INFO - 2023-11-02 09:38:36 --> Helper loaded: file_helper
INFO - 2023-11-02 09:38:36 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:38:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:38:36 --> Form Validation Class Initialized
INFO - 2023-11-02 09:38:36 --> Upload Class Initialized
INFO - 2023-11-02 09:38:36 --> Model "M_auth" initialized
INFO - 2023-11-02 09:38:36 --> Model "M_user" initialized
INFO - 2023-11-02 09:38:36 --> Model "M_produk" initialized
INFO - 2023-11-02 09:38:36 --> Controller Class Initialized
INFO - 2023-11-02 09:38:36 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/not_found.php
INFO - 2023-11-02 09:38:36 --> Final output sent to browser
DEBUG - 2023-11-02 09:38:36 --> Total execution time: 0.0208
ERROR - 2023-11-02 09:42:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:42:15 --> Config Class Initialized
INFO - 2023-11-02 09:42:15 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:42:15 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:42:15 --> Utf8 Class Initialized
INFO - 2023-11-02 09:42:15 --> URI Class Initialized
INFO - 2023-11-02 09:42:15 --> Router Class Initialized
INFO - 2023-11-02 09:42:15 --> Output Class Initialized
INFO - 2023-11-02 09:42:15 --> Security Class Initialized
DEBUG - 2023-11-02 09:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:42:15 --> Input Class Initialized
INFO - 2023-11-02 09:42:15 --> Language Class Initialized
INFO - 2023-11-02 09:42:15 --> Loader Class Initialized
INFO - 2023-11-02 09:42:15 --> Helper loaded: url_helper
INFO - 2023-11-02 09:42:15 --> Helper loaded: form_helper
INFO - 2023-11-02 09:42:15 --> Helper loaded: file_helper
INFO - 2023-11-02 09:42:15 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:42:15 --> Form Validation Class Initialized
INFO - 2023-11-02 09:42:15 --> Upload Class Initialized
INFO - 2023-11-02 09:42:15 --> Model "M_auth" initialized
INFO - 2023-11-02 09:42:15 --> Model "M_user" initialized
INFO - 2023-11-02 09:42:15 --> Model "M_produk" initialized
INFO - 2023-11-02 09:42:15 --> Controller Class Initialized
INFO - 2023-11-02 09:42:15 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:42:15 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:42:15 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:42:15 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:42:15 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:42:15 --> Model "M_bank" initialized
INFO - 2023-11-02 09:42:15 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:42:15 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:42:18 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:42:18 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 09:42:18 --> Final output sent to browser
DEBUG - 2023-11-02 09:42:18 --> Total execution time: 3.5964
ERROR - 2023-11-02 09:42:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:42:21 --> Config Class Initialized
INFO - 2023-11-02 09:42:21 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:42:21 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:42:21 --> Utf8 Class Initialized
INFO - 2023-11-02 09:42:21 --> URI Class Initialized
INFO - 2023-11-02 09:42:21 --> Router Class Initialized
INFO - 2023-11-02 09:42:21 --> Output Class Initialized
INFO - 2023-11-02 09:42:21 --> Security Class Initialized
DEBUG - 2023-11-02 09:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:42:21 --> Input Class Initialized
INFO - 2023-11-02 09:42:21 --> Language Class Initialized
INFO - 2023-11-02 09:42:21 --> Loader Class Initialized
INFO - 2023-11-02 09:42:21 --> Helper loaded: url_helper
INFO - 2023-11-02 09:42:21 --> Helper loaded: form_helper
INFO - 2023-11-02 09:42:21 --> Helper loaded: file_helper
INFO - 2023-11-02 09:42:21 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:42:21 --> Form Validation Class Initialized
INFO - 2023-11-02 09:42:21 --> Upload Class Initialized
INFO - 2023-11-02 09:42:21 --> Model "M_auth" initialized
INFO - 2023-11-02 09:42:21 --> Model "M_user" initialized
INFO - 2023-11-02 09:42:21 --> Model "M_produk" initialized
INFO - 2023-11-02 09:42:21 --> Controller Class Initialized
INFO - 2023-11-02 09:42:21 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:42:21 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:42:21 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:42:21 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:42:21 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:42:21 --> Model "M_bank" initialized
INFO - 2023-11-02 09:42:21 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:42:21 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:42:21 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:42:21 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_bayar_sekarang.php
INFO - 2023-11-02 09:42:21 --> Final output sent to browser
DEBUG - 2023-11-02 09:42:21 --> Total execution time: 0.0293
ERROR - 2023-11-02 09:42:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:42:21 --> Config Class Initialized
INFO - 2023-11-02 09:42:21 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:42:21 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:42:21 --> Utf8 Class Initialized
INFO - 2023-11-02 09:42:21 --> URI Class Initialized
INFO - 2023-11-02 09:42:21 --> Router Class Initialized
INFO - 2023-11-02 09:42:21 --> Output Class Initialized
INFO - 2023-11-02 09:42:21 --> Security Class Initialized
DEBUG - 2023-11-02 09:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:42:21 --> Input Class Initialized
INFO - 2023-11-02 09:42:21 --> Language Class Initialized
INFO - 2023-11-02 09:42:21 --> Loader Class Initialized
INFO - 2023-11-02 09:42:21 --> Helper loaded: url_helper
INFO - 2023-11-02 09:42:21 --> Helper loaded: form_helper
INFO - 2023-11-02 09:42:21 --> Helper loaded: file_helper
INFO - 2023-11-02 09:42:21 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:42:21 --> Form Validation Class Initialized
INFO - 2023-11-02 09:42:21 --> Upload Class Initialized
INFO - 2023-11-02 09:42:21 --> Model "M_auth" initialized
INFO - 2023-11-02 09:42:21 --> Model "M_user" initialized
INFO - 2023-11-02 09:42:21 --> Model "M_produk" initialized
INFO - 2023-11-02 09:42:21 --> Controller Class Initialized
INFO - 2023-11-02 09:42:21 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/not_found.php
INFO - 2023-11-02 09:42:21 --> Final output sent to browser
DEBUG - 2023-11-02 09:42:21 --> Total execution time: 0.0239
ERROR - 2023-11-02 09:42:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:42:23 --> Config Class Initialized
INFO - 2023-11-02 09:42:23 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:42:23 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:42:23 --> Utf8 Class Initialized
INFO - 2023-11-02 09:42:24 --> URI Class Initialized
INFO - 2023-11-02 09:42:24 --> Router Class Initialized
INFO - 2023-11-02 09:42:24 --> Output Class Initialized
INFO - 2023-11-02 09:42:24 --> Security Class Initialized
DEBUG - 2023-11-02 09:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:42:24 --> Input Class Initialized
INFO - 2023-11-02 09:42:24 --> Language Class Initialized
INFO - 2023-11-02 09:42:24 --> Loader Class Initialized
INFO - 2023-11-02 09:42:24 --> Helper loaded: url_helper
INFO - 2023-11-02 09:42:24 --> Helper loaded: form_helper
INFO - 2023-11-02 09:42:24 --> Helper loaded: file_helper
INFO - 2023-11-02 09:42:24 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:42:24 --> Form Validation Class Initialized
INFO - 2023-11-02 09:42:24 --> Upload Class Initialized
INFO - 2023-11-02 09:42:24 --> Model "M_auth" initialized
INFO - 2023-11-02 09:42:24 --> Model "M_user" initialized
INFO - 2023-11-02 09:42:24 --> Model "M_produk" initialized
INFO - 2023-11-02 09:42:24 --> Controller Class Initialized
INFO - 2023-11-02 09:42:24 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:42:24 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:42:24 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:42:24 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:42:24 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:42:24 --> Model "M_bank" initialized
INFO - 2023-11-02 09:42:24 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:42:24 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
ERROR - 2023-11-02 09:42:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:42:31 --> Config Class Initialized
INFO - 2023-11-02 09:42:31 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:42:31 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:42:31 --> Utf8 Class Initialized
INFO - 2023-11-02 09:42:31 --> URI Class Initialized
INFO - 2023-11-02 09:42:31 --> Router Class Initialized
INFO - 2023-11-02 09:42:31 --> Output Class Initialized
INFO - 2023-11-02 09:42:31 --> Security Class Initialized
DEBUG - 2023-11-02 09:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:42:31 --> Input Class Initialized
INFO - 2023-11-02 09:42:31 --> Language Class Initialized
INFO - 2023-11-02 09:42:31 --> Loader Class Initialized
INFO - 2023-11-02 09:42:31 --> Helper loaded: url_helper
INFO - 2023-11-02 09:42:31 --> Helper loaded: form_helper
INFO - 2023-11-02 09:42:31 --> Helper loaded: file_helper
INFO - 2023-11-02 09:42:31 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2023-11-02 09:42:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:42:44 --> Config Class Initialized
INFO - 2023-11-02 09:42:44 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:42:44 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:42:44 --> Utf8 Class Initialized
INFO - 2023-11-02 09:42:44 --> URI Class Initialized
DEBUG - 2023-11-02 09:42:44 --> No URI present. Default controller set.
INFO - 2023-11-02 09:42:44 --> Router Class Initialized
INFO - 2023-11-02 09:42:44 --> Output Class Initialized
INFO - 2023-11-02 09:42:44 --> Security Class Initialized
DEBUG - 2023-11-02 09:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:42:44 --> Input Class Initialized
INFO - 2023-11-02 09:42:44 --> Language Class Initialized
INFO - 2023-11-02 09:42:44 --> Loader Class Initialized
INFO - 2023-11-02 09:42:44 --> Helper loaded: url_helper
INFO - 2023-11-02 09:42:44 --> Helper loaded: form_helper
INFO - 2023-11-02 09:42:44 --> Helper loaded: file_helper
INFO - 2023-11-02 09:42:44 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:42:56 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:42:56 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 09:42:56 --> Final output sent to browser
DEBUG - 2023-11-02 09:42:56 --> Total execution time: 32.3164
INFO - 2023-11-02 09:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:42:56 --> Form Validation Class Initialized
INFO - 2023-11-02 09:42:56 --> Upload Class Initialized
INFO - 2023-11-02 09:42:56 --> Model "M_auth" initialized
INFO - 2023-11-02 09:42:56 --> Model "M_user" initialized
INFO - 2023-11-02 09:42:56 --> Model "M_produk" initialized
INFO - 2023-11-02 09:42:56 --> Controller Class Initialized
INFO - 2023-11-02 09:42:56 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:42:56 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:42:56 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:42:56 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:42:56 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:42:56 --> Model "M_bank" initialized
INFO - 2023-11-02 09:42:56 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:42:56 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:42:57 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:42:57 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 09:42:57 --> Final output sent to browser
DEBUG - 2023-11-02 09:42:57 --> Total execution time: 26.0458
INFO - 2023-11-02 09:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:42:57 --> Form Validation Class Initialized
INFO - 2023-11-02 09:42:57 --> Upload Class Initialized
INFO - 2023-11-02 09:42:57 --> Model "M_auth" initialized
INFO - 2023-11-02 09:42:57 --> Model "M_user" initialized
INFO - 2023-11-02 09:42:57 --> Model "M_produk" initialized
INFO - 2023-11-02 09:42:57 --> Controller Class Initialized
INFO - 2023-11-02 09:42:57 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:42:57 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:42:57 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:42:57 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:42:57 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:42:57 --> Model "M_bank" initialized
INFO - 2023-11-02 09:42:57 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:42:57 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:42:57 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:42:57 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/index.php
INFO - 2023-11-02 09:42:57 --> Final output sent to browser
DEBUG - 2023-11-02 09:42:57 --> Total execution time: 13.4379
ERROR - 2023-11-02 09:43:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:43:02 --> Config Class Initialized
INFO - 2023-11-02 09:43:02 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:43:02 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:43:02 --> Utf8 Class Initialized
INFO - 2023-11-02 09:43:02 --> URI Class Initialized
INFO - 2023-11-02 09:43:02 --> Router Class Initialized
INFO - 2023-11-02 09:43:02 --> Output Class Initialized
INFO - 2023-11-02 09:43:02 --> Security Class Initialized
DEBUG - 2023-11-02 09:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:43:02 --> Input Class Initialized
INFO - 2023-11-02 09:43:02 --> Language Class Initialized
INFO - 2023-11-02 09:43:02 --> Loader Class Initialized
INFO - 2023-11-02 09:43:02 --> Helper loaded: url_helper
INFO - 2023-11-02 09:43:02 --> Helper loaded: form_helper
INFO - 2023-11-02 09:43:02 --> Helper loaded: file_helper
INFO - 2023-11-02 09:43:02 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:43:02 --> Form Validation Class Initialized
INFO - 2023-11-02 09:43:02 --> Upload Class Initialized
INFO - 2023-11-02 09:43:02 --> Model "M_auth" initialized
INFO - 2023-11-02 09:43:02 --> Model "M_user" initialized
INFO - 2023-11-02 09:43:02 --> Model "M_produk" initialized
INFO - 2023-11-02 09:43:02 --> Controller Class Initialized
INFO - 2023-11-02 09:43:02 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:43:02 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:43:02 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:43:02 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:43:02 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:43:02 --> Model "M_bank" initialized
INFO - 2023-11-02 09:43:02 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:43:02 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:43:03 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:43:03 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 09:43:03 --> Final output sent to browser
DEBUG - 2023-11-02 09:43:03 --> Total execution time: 1.5479
ERROR - 2023-11-02 09:51:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:51:10 --> Config Class Initialized
INFO - 2023-11-02 09:51:10 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:51:10 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:51:10 --> Utf8 Class Initialized
INFO - 2023-11-02 09:51:10 --> URI Class Initialized
INFO - 2023-11-02 09:51:10 --> Router Class Initialized
INFO - 2023-11-02 09:51:10 --> Output Class Initialized
INFO - 2023-11-02 09:51:10 --> Security Class Initialized
DEBUG - 2023-11-02 09:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:51:10 --> Input Class Initialized
INFO - 2023-11-02 09:51:10 --> Language Class Initialized
INFO - 2023-11-02 09:51:10 --> Loader Class Initialized
INFO - 2023-11-02 09:51:10 --> Helper loaded: url_helper
INFO - 2023-11-02 09:51:10 --> Helper loaded: form_helper
INFO - 2023-11-02 09:51:10 --> Helper loaded: file_helper
INFO - 2023-11-02 09:51:10 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:51:10 --> Form Validation Class Initialized
INFO - 2023-11-02 09:51:10 --> Upload Class Initialized
INFO - 2023-11-02 09:51:10 --> Model "M_auth" initialized
INFO - 2023-11-02 09:51:10 --> Model "M_user" initialized
INFO - 2023-11-02 09:51:10 --> Model "M_produk" initialized
INFO - 2023-11-02 09:51:10 --> Controller Class Initialized
INFO - 2023-11-02 09:51:10 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:51:10 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:51:10 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:51:10 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:51:10 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:51:10 --> Model "M_bank" initialized
INFO - 2023-11-02 09:51:10 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:51:10 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:51:10 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:51:10 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_bayar_sekarang.php
INFO - 2023-11-02 09:51:10 --> Final output sent to browser
DEBUG - 2023-11-02 09:51:10 --> Total execution time: 0.0688
ERROR - 2023-11-02 09:51:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:51:10 --> Config Class Initialized
INFO - 2023-11-02 09:51:10 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:51:10 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:51:10 --> Utf8 Class Initialized
INFO - 2023-11-02 09:51:11 --> URI Class Initialized
INFO - 2023-11-02 09:51:11 --> Router Class Initialized
INFO - 2023-11-02 09:51:11 --> Output Class Initialized
INFO - 2023-11-02 09:51:11 --> Security Class Initialized
DEBUG - 2023-11-02 09:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:51:11 --> Input Class Initialized
INFO - 2023-11-02 09:51:11 --> Language Class Initialized
INFO - 2023-11-02 09:51:11 --> Loader Class Initialized
INFO - 2023-11-02 09:51:11 --> Helper loaded: url_helper
INFO - 2023-11-02 09:51:11 --> Helper loaded: form_helper
INFO - 2023-11-02 09:51:11 --> Helper loaded: file_helper
INFO - 2023-11-02 09:51:11 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:51:11 --> Form Validation Class Initialized
INFO - 2023-11-02 09:51:11 --> Upload Class Initialized
INFO - 2023-11-02 09:51:11 --> Model "M_auth" initialized
INFO - 2023-11-02 09:51:11 --> Model "M_user" initialized
INFO - 2023-11-02 09:51:11 --> Model "M_produk" initialized
INFO - 2023-11-02 09:51:11 --> Controller Class Initialized
INFO - 2023-11-02 09:51:11 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/not_found.php
INFO - 2023-11-02 09:51:11 --> Final output sent to browser
DEBUG - 2023-11-02 09:51:11 --> Total execution time: 0.0210
ERROR - 2023-11-02 09:51:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:51:12 --> Config Class Initialized
INFO - 2023-11-02 09:51:12 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:51:12 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:51:12 --> Utf8 Class Initialized
INFO - 2023-11-02 09:51:12 --> URI Class Initialized
INFO - 2023-11-02 09:51:12 --> Router Class Initialized
INFO - 2023-11-02 09:51:12 --> Output Class Initialized
INFO - 2023-11-02 09:51:12 --> Security Class Initialized
DEBUG - 2023-11-02 09:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:51:12 --> Input Class Initialized
INFO - 2023-11-02 09:51:12 --> Language Class Initialized
INFO - 2023-11-02 09:51:12 --> Loader Class Initialized
INFO - 2023-11-02 09:51:12 --> Helper loaded: url_helper
INFO - 2023-11-02 09:51:12 --> Helper loaded: form_helper
INFO - 2023-11-02 09:51:12 --> Helper loaded: file_helper
INFO - 2023-11-02 09:51:12 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:51:12 --> Form Validation Class Initialized
INFO - 2023-11-02 09:51:12 --> Upload Class Initialized
INFO - 2023-11-02 09:51:12 --> Model "M_auth" initialized
INFO - 2023-11-02 09:51:12 --> Model "M_user" initialized
INFO - 2023-11-02 09:51:12 --> Model "M_produk" initialized
INFO - 2023-11-02 09:51:12 --> Controller Class Initialized
INFO - 2023-11-02 09:51:12 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:51:12 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:51:12 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:51:12 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:51:12 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:51:12 --> Model "M_bank" initialized
INFO - 2023-11-02 09:51:12 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:51:12 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:51:13 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:51:13 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 09:51:13 --> Final output sent to browser
DEBUG - 2023-11-02 09:51:13 --> Total execution time: 0.9397
ERROR - 2023-11-02 09:51:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:51:15 --> Config Class Initialized
INFO - 2023-11-02 09:51:15 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:51:15 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:51:15 --> Utf8 Class Initialized
INFO - 2023-11-02 09:51:15 --> URI Class Initialized
INFO - 2023-11-02 09:51:15 --> Router Class Initialized
INFO - 2023-11-02 09:51:15 --> Output Class Initialized
INFO - 2023-11-02 09:51:15 --> Security Class Initialized
DEBUG - 2023-11-02 09:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:51:15 --> Input Class Initialized
INFO - 2023-11-02 09:51:15 --> Language Class Initialized
INFO - 2023-11-02 09:51:15 --> Loader Class Initialized
INFO - 2023-11-02 09:51:15 --> Helper loaded: url_helper
INFO - 2023-11-02 09:51:15 --> Helper loaded: form_helper
INFO - 2023-11-02 09:51:15 --> Helper loaded: file_helper
INFO - 2023-11-02 09:51:15 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:51:15 --> Form Validation Class Initialized
INFO - 2023-11-02 09:51:15 --> Upload Class Initialized
INFO - 2023-11-02 09:51:15 --> Model "M_auth" initialized
INFO - 2023-11-02 09:51:15 --> Model "M_user" initialized
INFO - 2023-11-02 09:51:15 --> Model "M_produk" initialized
INFO - 2023-11-02 09:51:15 --> Controller Class Initialized
INFO - 2023-11-02 09:51:15 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:51:15 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:51:15 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:51:15 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:51:15 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:51:15 --> Model "M_bank" initialized
INFO - 2023-11-02 09:51:15 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:51:15 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:51:15 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:51:15 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_bayar_sekarang.php
INFO - 2023-11-02 09:51:15 --> Final output sent to browser
DEBUG - 2023-11-02 09:51:15 --> Total execution time: 0.0557
ERROR - 2023-11-02 09:51:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:51:16 --> Config Class Initialized
INFO - 2023-11-02 09:51:16 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:51:16 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:51:16 --> Utf8 Class Initialized
INFO - 2023-11-02 09:51:16 --> URI Class Initialized
INFO - 2023-11-02 09:51:16 --> Router Class Initialized
INFO - 2023-11-02 09:51:16 --> Output Class Initialized
INFO - 2023-11-02 09:51:16 --> Security Class Initialized
DEBUG - 2023-11-02 09:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:51:16 --> Input Class Initialized
INFO - 2023-11-02 09:51:16 --> Language Class Initialized
INFO - 2023-11-02 09:51:16 --> Loader Class Initialized
INFO - 2023-11-02 09:51:16 --> Helper loaded: url_helper
INFO - 2023-11-02 09:51:16 --> Helper loaded: form_helper
INFO - 2023-11-02 09:51:16 --> Helper loaded: file_helper
INFO - 2023-11-02 09:51:16 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:51:16 --> Form Validation Class Initialized
INFO - 2023-11-02 09:51:16 --> Upload Class Initialized
INFO - 2023-11-02 09:51:16 --> Model "M_auth" initialized
INFO - 2023-11-02 09:51:16 --> Model "M_user" initialized
INFO - 2023-11-02 09:51:16 --> Model "M_produk" initialized
INFO - 2023-11-02 09:51:16 --> Controller Class Initialized
INFO - 2023-11-02 09:51:16 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/not_found.php
INFO - 2023-11-02 09:51:16 --> Final output sent to browser
DEBUG - 2023-11-02 09:51:16 --> Total execution time: 0.0402
ERROR - 2023-11-02 09:51:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:51:22 --> Config Class Initialized
INFO - 2023-11-02 09:51:22 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:51:22 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:51:22 --> Utf8 Class Initialized
INFO - 2023-11-02 09:51:22 --> URI Class Initialized
INFO - 2023-11-02 09:51:22 --> Router Class Initialized
INFO - 2023-11-02 09:51:22 --> Output Class Initialized
INFO - 2023-11-02 09:51:22 --> Security Class Initialized
DEBUG - 2023-11-02 09:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:51:22 --> Input Class Initialized
INFO - 2023-11-02 09:51:22 --> Language Class Initialized
INFO - 2023-11-02 09:51:22 --> Loader Class Initialized
INFO - 2023-11-02 09:51:22 --> Helper loaded: url_helper
INFO - 2023-11-02 09:51:22 --> Helper loaded: form_helper
INFO - 2023-11-02 09:51:22 --> Helper loaded: file_helper
INFO - 2023-11-02 09:51:22 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:51:22 --> Form Validation Class Initialized
INFO - 2023-11-02 09:51:22 --> Upload Class Initialized
INFO - 2023-11-02 09:51:22 --> Model "M_auth" initialized
INFO - 2023-11-02 09:51:22 --> Model "M_user" initialized
INFO - 2023-11-02 09:51:22 --> Model "M_produk" initialized
INFO - 2023-11-02 09:51:22 --> Controller Class Initialized
INFO - 2023-11-02 09:51:22 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:51:22 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:51:22 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:51:22 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:51:22 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:51:22 --> Model "M_bank" initialized
INFO - 2023-11-02 09:51:22 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:51:22 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:51:23 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:51:23 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 09:51:23 --> Final output sent to browser
DEBUG - 2023-11-02 09:51:23 --> Total execution time: 0.8613
ERROR - 2023-11-02 09:51:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:51:29 --> Config Class Initialized
INFO - 2023-11-02 09:51:29 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:51:29 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:51:29 --> Utf8 Class Initialized
INFO - 2023-11-02 09:51:29 --> URI Class Initialized
DEBUG - 2023-11-02 09:51:29 --> No URI present. Default controller set.
INFO - 2023-11-02 09:51:29 --> Router Class Initialized
INFO - 2023-11-02 09:51:29 --> Output Class Initialized
INFO - 2023-11-02 09:51:29 --> Security Class Initialized
DEBUG - 2023-11-02 09:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:51:29 --> Input Class Initialized
INFO - 2023-11-02 09:51:29 --> Language Class Initialized
INFO - 2023-11-02 09:51:29 --> Loader Class Initialized
INFO - 2023-11-02 09:51:29 --> Helper loaded: url_helper
INFO - 2023-11-02 09:51:29 --> Helper loaded: form_helper
INFO - 2023-11-02 09:51:29 --> Helper loaded: file_helper
INFO - 2023-11-02 09:51:29 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:51:29 --> Form Validation Class Initialized
INFO - 2023-11-02 09:51:29 --> Upload Class Initialized
INFO - 2023-11-02 09:51:29 --> Model "M_auth" initialized
INFO - 2023-11-02 09:51:29 --> Model "M_user" initialized
INFO - 2023-11-02 09:51:29 --> Model "M_produk" initialized
INFO - 2023-11-02 09:51:29 --> Controller Class Initialized
INFO - 2023-11-02 09:51:29 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:51:29 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:51:29 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:51:29 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:51:29 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:51:29 --> Model "M_bank" initialized
INFO - 2023-11-02 09:51:29 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:51:29 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:51:29 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:51:29 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/index.php
INFO - 2023-11-02 09:51:29 --> Final output sent to browser
DEBUG - 2023-11-02 09:51:29 --> Total execution time: 0.0985
ERROR - 2023-11-02 09:51:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:51:33 --> Config Class Initialized
INFO - 2023-11-02 09:51:33 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:51:33 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:51:33 --> Utf8 Class Initialized
INFO - 2023-11-02 09:51:33 --> URI Class Initialized
INFO - 2023-11-02 09:51:33 --> Router Class Initialized
INFO - 2023-11-02 09:51:33 --> Output Class Initialized
INFO - 2023-11-02 09:51:33 --> Security Class Initialized
DEBUG - 2023-11-02 09:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:51:33 --> Input Class Initialized
INFO - 2023-11-02 09:51:33 --> Language Class Initialized
INFO - 2023-11-02 09:51:33 --> Loader Class Initialized
INFO - 2023-11-02 09:51:33 --> Helper loaded: url_helper
INFO - 2023-11-02 09:51:33 --> Helper loaded: form_helper
INFO - 2023-11-02 09:51:33 --> Helper loaded: file_helper
INFO - 2023-11-02 09:51:33 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:51:33 --> Form Validation Class Initialized
INFO - 2023-11-02 09:51:33 --> Upload Class Initialized
INFO - 2023-11-02 09:51:33 --> Model "M_auth" initialized
INFO - 2023-11-02 09:51:33 --> Model "M_user" initialized
INFO - 2023-11-02 09:51:33 --> Model "M_produk" initialized
INFO - 2023-11-02 09:51:33 --> Controller Class Initialized
INFO - 2023-11-02 09:51:33 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:51:33 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:51:33 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:51:33 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:51:33 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:51:33 --> Model "M_bank" initialized
INFO - 2023-11-02 09:51:33 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:51:33 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:51:33 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:51:33 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_produk_detail.php
INFO - 2023-11-02 09:51:33 --> Final output sent to browser
DEBUG - 2023-11-02 09:51:33 --> Total execution time: 0.0720
ERROR - 2023-11-02 09:51:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:51:33 --> Config Class Initialized
INFO - 2023-11-02 09:51:33 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:51:33 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:51:33 --> Utf8 Class Initialized
INFO - 2023-11-02 09:51:33 --> URI Class Initialized
INFO - 2023-11-02 09:51:33 --> Router Class Initialized
INFO - 2023-11-02 09:51:33 --> Output Class Initialized
INFO - 2023-11-02 09:51:33 --> Security Class Initialized
DEBUG - 2023-11-02 09:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:51:33 --> Input Class Initialized
INFO - 2023-11-02 09:51:33 --> Language Class Initialized
INFO - 2023-11-02 09:51:33 --> Loader Class Initialized
INFO - 2023-11-02 09:51:33 --> Helper loaded: url_helper
INFO - 2023-11-02 09:51:33 --> Helper loaded: form_helper
INFO - 2023-11-02 09:51:33 --> Helper loaded: file_helper
INFO - 2023-11-02 09:51:33 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:51:33 --> Form Validation Class Initialized
INFO - 2023-11-02 09:51:33 --> Upload Class Initialized
INFO - 2023-11-02 09:51:33 --> Model "M_auth" initialized
INFO - 2023-11-02 09:51:33 --> Model "M_user" initialized
INFO - 2023-11-02 09:51:33 --> Model "M_produk" initialized
INFO - 2023-11-02 09:51:33 --> Controller Class Initialized
INFO - 2023-11-02 09:51:33 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/not_found.php
INFO - 2023-11-02 09:51:33 --> Final output sent to browser
DEBUG - 2023-11-02 09:51:33 --> Total execution time: 0.0318
ERROR - 2023-11-02 09:51:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:51:43 --> Config Class Initialized
INFO - 2023-11-02 09:51:43 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:51:43 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:51:43 --> Utf8 Class Initialized
INFO - 2023-11-02 09:51:43 --> URI Class Initialized
INFO - 2023-11-02 09:51:43 --> Router Class Initialized
INFO - 2023-11-02 09:51:43 --> Output Class Initialized
INFO - 2023-11-02 09:51:43 --> Security Class Initialized
DEBUG - 2023-11-02 09:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:51:43 --> Input Class Initialized
INFO - 2023-11-02 09:51:43 --> Language Class Initialized
INFO - 2023-11-02 09:51:43 --> Loader Class Initialized
INFO - 2023-11-02 09:51:43 --> Helper loaded: url_helper
INFO - 2023-11-02 09:51:43 --> Helper loaded: form_helper
INFO - 2023-11-02 09:51:43 --> Helper loaded: file_helper
INFO - 2023-11-02 09:51:43 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:51:43 --> Form Validation Class Initialized
INFO - 2023-11-02 09:51:43 --> Upload Class Initialized
INFO - 2023-11-02 09:51:43 --> Model "M_auth" initialized
INFO - 2023-11-02 09:51:43 --> Model "M_user" initialized
INFO - 2023-11-02 09:51:43 --> Model "M_produk" initialized
INFO - 2023-11-02 09:51:43 --> Controller Class Initialized
INFO - 2023-11-02 09:51:43 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:51:43 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:51:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:51:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:51:43 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:51:43 --> Model "M_bank" initialized
INFO - 2023-11-02 09:51:43 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:51:43 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:51:43 --> Email Class Initialized
ERROR - 2023-11-02 09:51:48 --> Severity: Warning --> fsockopen(): Unable to connect to ssl://smtp.googlemail.com:465 (A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond) C:\xampp\htdocs\semakar_adventure\system\libraries\Email.php 2070
INFO - 2023-11-02 09:51:48 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-11-02 09:51:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:51:48 --> Config Class Initialized
INFO - 2023-11-02 09:51:48 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:51:48 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:51:48 --> Utf8 Class Initialized
INFO - 2023-11-02 09:51:48 --> URI Class Initialized
INFO - 2023-11-02 09:51:48 --> Router Class Initialized
INFO - 2023-11-02 09:51:48 --> Output Class Initialized
INFO - 2023-11-02 09:51:48 --> Security Class Initialized
DEBUG - 2023-11-02 09:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:51:48 --> Input Class Initialized
INFO - 2023-11-02 09:51:48 --> Language Class Initialized
INFO - 2023-11-02 09:51:48 --> Loader Class Initialized
INFO - 2023-11-02 09:51:48 --> Helper loaded: url_helper
INFO - 2023-11-02 09:51:48 --> Helper loaded: form_helper
INFO - 2023-11-02 09:51:48 --> Helper loaded: file_helper
INFO - 2023-11-02 09:51:48 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:51:48 --> Form Validation Class Initialized
INFO - 2023-11-02 09:51:48 --> Upload Class Initialized
INFO - 2023-11-02 09:51:48 --> Model "M_auth" initialized
INFO - 2023-11-02 09:51:48 --> Model "M_user" initialized
INFO - 2023-11-02 09:51:48 --> Model "M_produk" initialized
INFO - 2023-11-02 09:51:48 --> Controller Class Initialized
INFO - 2023-11-02 09:51:48 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:51:48 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:51:48 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:51:48 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:51:48 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:51:48 --> Model "M_bank" initialized
INFO - 2023-11-02 09:51:48 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:51:48 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:51:56 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:51:56 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 09:51:56 --> Final output sent to browser
DEBUG - 2023-11-02 09:51:56 --> Total execution time: 7.7844
ERROR - 2023-11-02 09:51:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:51:59 --> Config Class Initialized
INFO - 2023-11-02 09:51:59 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:51:59 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:51:59 --> Utf8 Class Initialized
INFO - 2023-11-02 09:51:59 --> URI Class Initialized
INFO - 2023-11-02 09:51:59 --> Router Class Initialized
INFO - 2023-11-02 09:51:59 --> Output Class Initialized
INFO - 2023-11-02 09:51:59 --> Security Class Initialized
DEBUG - 2023-11-02 09:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:51:59 --> Input Class Initialized
INFO - 2023-11-02 09:51:59 --> Language Class Initialized
INFO - 2023-11-02 09:51:59 --> Loader Class Initialized
INFO - 2023-11-02 09:51:59 --> Helper loaded: url_helper
INFO - 2023-11-02 09:51:59 --> Helper loaded: form_helper
INFO - 2023-11-02 09:51:59 --> Helper loaded: file_helper
INFO - 2023-11-02 09:51:59 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:51:59 --> Form Validation Class Initialized
INFO - 2023-11-02 09:51:59 --> Upload Class Initialized
INFO - 2023-11-02 09:51:59 --> Model "M_auth" initialized
INFO - 2023-11-02 09:51:59 --> Model "M_user" initialized
INFO - 2023-11-02 09:51:59 --> Model "M_produk" initialized
INFO - 2023-11-02 09:51:59 --> Controller Class Initialized
INFO - 2023-11-02 09:51:59 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:51:59 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:51:59 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:51:59 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:51:59 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:51:59 --> Model "M_bank" initialized
INFO - 2023-11-02 09:51:59 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:51:59 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:51:59 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:51:59 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_bayar_sekarang.php
INFO - 2023-11-02 09:51:59 --> Final output sent to browser
DEBUG - 2023-11-02 09:51:59 --> Total execution time: 0.1106
ERROR - 2023-11-02 09:51:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:51:59 --> Config Class Initialized
INFO - 2023-11-02 09:51:59 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:51:59 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:51:59 --> Utf8 Class Initialized
INFO - 2023-11-02 09:51:59 --> URI Class Initialized
INFO - 2023-11-02 09:51:59 --> Router Class Initialized
INFO - 2023-11-02 09:51:59 --> Output Class Initialized
INFO - 2023-11-02 09:51:59 --> Security Class Initialized
DEBUG - 2023-11-02 09:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:51:59 --> Input Class Initialized
INFO - 2023-11-02 09:51:59 --> Language Class Initialized
INFO - 2023-11-02 09:51:59 --> Loader Class Initialized
INFO - 2023-11-02 09:51:59 --> Helper loaded: url_helper
INFO - 2023-11-02 09:51:59 --> Helper loaded: form_helper
INFO - 2023-11-02 09:51:59 --> Helper loaded: file_helper
INFO - 2023-11-02 09:51:59 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:51:59 --> Form Validation Class Initialized
INFO - 2023-11-02 09:51:59 --> Upload Class Initialized
INFO - 2023-11-02 09:51:59 --> Model "M_auth" initialized
INFO - 2023-11-02 09:51:59 --> Model "M_user" initialized
INFO - 2023-11-02 09:51:59 --> Model "M_produk" initialized
INFO - 2023-11-02 09:51:59 --> Controller Class Initialized
INFO - 2023-11-02 09:51:59 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/not_found.php
INFO - 2023-11-02 09:51:59 --> Final output sent to browser
DEBUG - 2023-11-02 09:51:59 --> Total execution time: 0.0232
ERROR - 2023-11-02 09:52:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:52:02 --> Config Class Initialized
INFO - 2023-11-02 09:52:02 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:52:02 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:52:02 --> Utf8 Class Initialized
INFO - 2023-11-02 09:52:02 --> URI Class Initialized
INFO - 2023-11-02 09:52:02 --> Router Class Initialized
INFO - 2023-11-02 09:52:02 --> Output Class Initialized
INFO - 2023-11-02 09:52:02 --> Security Class Initialized
DEBUG - 2023-11-02 09:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:52:02 --> Input Class Initialized
INFO - 2023-11-02 09:52:02 --> Language Class Initialized
INFO - 2023-11-02 09:52:02 --> Loader Class Initialized
INFO - 2023-11-02 09:52:02 --> Helper loaded: url_helper
INFO - 2023-11-02 09:52:02 --> Helper loaded: form_helper
INFO - 2023-11-02 09:52:02 --> Helper loaded: file_helper
INFO - 2023-11-02 09:52:02 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:52:02 --> Form Validation Class Initialized
INFO - 2023-11-02 09:52:02 --> Upload Class Initialized
INFO - 2023-11-02 09:52:02 --> Model "M_auth" initialized
INFO - 2023-11-02 09:52:02 --> Model "M_user" initialized
INFO - 2023-11-02 09:52:02 --> Model "M_produk" initialized
INFO - 2023-11-02 09:52:02 --> Controller Class Initialized
INFO - 2023-11-02 09:52:02 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:52:02 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:52:02 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:52:02 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:52:02 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:52:02 --> Model "M_bank" initialized
INFO - 2023-11-02 09:52:02 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:52:02 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:52:03 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:52:03 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 09:52:03 --> Final output sent to browser
DEBUG - 2023-11-02 09:52:03 --> Total execution time: 1.6344
ERROR - 2023-11-02 09:52:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:52:05 --> Config Class Initialized
INFO - 2023-11-02 09:52:05 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:52:05 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:52:05 --> Utf8 Class Initialized
INFO - 2023-11-02 09:52:05 --> URI Class Initialized
INFO - 2023-11-02 09:52:05 --> Router Class Initialized
INFO - 2023-11-02 09:52:05 --> Output Class Initialized
INFO - 2023-11-02 09:52:05 --> Security Class Initialized
DEBUG - 2023-11-02 09:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:52:05 --> Input Class Initialized
INFO - 2023-11-02 09:52:05 --> Language Class Initialized
INFO - 2023-11-02 09:52:05 --> Loader Class Initialized
INFO - 2023-11-02 09:52:05 --> Helper loaded: url_helper
INFO - 2023-11-02 09:52:05 --> Helper loaded: form_helper
INFO - 2023-11-02 09:52:05 --> Helper loaded: file_helper
INFO - 2023-11-02 09:52:05 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:52:05 --> Form Validation Class Initialized
INFO - 2023-11-02 09:52:05 --> Upload Class Initialized
INFO - 2023-11-02 09:52:05 --> Model "M_auth" initialized
INFO - 2023-11-02 09:52:05 --> Model "M_user" initialized
INFO - 2023-11-02 09:52:05 --> Model "M_produk" initialized
INFO - 2023-11-02 09:52:05 --> Controller Class Initialized
INFO - 2023-11-02 09:52:05 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:52:05 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:52:05 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:52:05 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:52:05 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:52:05 --> Model "M_bank" initialized
INFO - 2023-11-02 09:52:05 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:52:05 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:52:05 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:52:05 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_bayar_sekarang.php
INFO - 2023-11-02 09:52:05 --> Final output sent to browser
DEBUG - 2023-11-02 09:52:05 --> Total execution time: 0.0319
ERROR - 2023-11-02 09:52:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:52:05 --> Config Class Initialized
INFO - 2023-11-02 09:52:05 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:52:05 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:52:05 --> Utf8 Class Initialized
INFO - 2023-11-02 09:52:05 --> URI Class Initialized
INFO - 2023-11-02 09:52:05 --> Router Class Initialized
INFO - 2023-11-02 09:52:05 --> Output Class Initialized
INFO - 2023-11-02 09:52:05 --> Security Class Initialized
DEBUG - 2023-11-02 09:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:52:05 --> Input Class Initialized
INFO - 2023-11-02 09:52:05 --> Language Class Initialized
INFO - 2023-11-02 09:52:05 --> Loader Class Initialized
INFO - 2023-11-02 09:52:05 --> Helper loaded: url_helper
INFO - 2023-11-02 09:52:05 --> Helper loaded: form_helper
INFO - 2023-11-02 09:52:06 --> Helper loaded: file_helper
INFO - 2023-11-02 09:52:06 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:52:06 --> Form Validation Class Initialized
INFO - 2023-11-02 09:52:06 --> Upload Class Initialized
INFO - 2023-11-02 09:52:06 --> Model "M_auth" initialized
INFO - 2023-11-02 09:52:06 --> Model "M_user" initialized
INFO - 2023-11-02 09:52:06 --> Model "M_produk" initialized
INFO - 2023-11-02 09:52:06 --> Controller Class Initialized
INFO - 2023-11-02 09:52:06 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/not_found.php
INFO - 2023-11-02 09:52:06 --> Final output sent to browser
DEBUG - 2023-11-02 09:52:06 --> Total execution time: 0.0803
ERROR - 2023-11-02 09:54:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:54:18 --> Config Class Initialized
INFO - 2023-11-02 09:54:18 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:54:18 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:54:18 --> Utf8 Class Initialized
INFO - 2023-11-02 09:54:18 --> URI Class Initialized
INFO - 2023-11-02 09:54:18 --> Router Class Initialized
INFO - 2023-11-02 09:54:18 --> Output Class Initialized
INFO - 2023-11-02 09:54:18 --> Security Class Initialized
DEBUG - 2023-11-02 09:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:54:18 --> Input Class Initialized
INFO - 2023-11-02 09:54:18 --> Language Class Initialized
INFO - 2023-11-02 09:54:18 --> Loader Class Initialized
INFO - 2023-11-02 09:54:18 --> Helper loaded: url_helper
INFO - 2023-11-02 09:54:18 --> Helper loaded: form_helper
INFO - 2023-11-02 09:54:18 --> Helper loaded: file_helper
INFO - 2023-11-02 09:54:18 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:54:18 --> Form Validation Class Initialized
INFO - 2023-11-02 09:54:18 --> Upload Class Initialized
INFO - 2023-11-02 09:54:18 --> Model "M_auth" initialized
INFO - 2023-11-02 09:54:18 --> Model "M_user" initialized
INFO - 2023-11-02 09:54:18 --> Model "M_produk" initialized
INFO - 2023-11-02 09:54:18 --> Controller Class Initialized
INFO - 2023-11-02 09:54:18 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:54:18 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:54:18 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:54:18 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:54:18 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:54:18 --> Model "M_bank" initialized
INFO - 2023-11-02 09:54:18 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:54:18 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
ERROR - 2023-11-02 09:54:18 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 09:54:18 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 09:54:18 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
INFO - 2023-11-02 09:54:18 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:54:18 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 09:54:18 --> Final output sent to browser
DEBUG - 2023-11-02 09:54:18 --> Total execution time: 0.1098
ERROR - 2023-11-02 09:54:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:54:36 --> Config Class Initialized
INFO - 2023-11-02 09:54:36 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:54:36 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:54:36 --> Utf8 Class Initialized
INFO - 2023-11-02 09:54:36 --> URI Class Initialized
INFO - 2023-11-02 09:54:36 --> Router Class Initialized
INFO - 2023-11-02 09:54:36 --> Output Class Initialized
INFO - 2023-11-02 09:54:36 --> Security Class Initialized
DEBUG - 2023-11-02 09:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:54:36 --> Input Class Initialized
INFO - 2023-11-02 09:54:36 --> Language Class Initialized
INFO - 2023-11-02 09:54:36 --> Loader Class Initialized
INFO - 2023-11-02 09:54:36 --> Helper loaded: url_helper
INFO - 2023-11-02 09:54:36 --> Helper loaded: form_helper
INFO - 2023-11-02 09:54:36 --> Helper loaded: file_helper
INFO - 2023-11-02 09:54:36 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:54:36 --> Form Validation Class Initialized
INFO - 2023-11-02 09:54:36 --> Upload Class Initialized
INFO - 2023-11-02 09:54:36 --> Model "M_auth" initialized
INFO - 2023-11-02 09:54:36 --> Model "M_user" initialized
INFO - 2023-11-02 09:54:36 --> Model "M_produk" initialized
INFO - 2023-11-02 09:54:36 --> Controller Class Initialized
INFO - 2023-11-02 09:54:36 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:54:36 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:54:36 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:54:36 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:54:36 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:54:36 --> Model "M_bank" initialized
INFO - 2023-11-02 09:54:37 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:54:37 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:54:37 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:54:37 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_bayar_sekarang.php
INFO - 2023-11-02 09:54:37 --> Final output sent to browser
DEBUG - 2023-11-02 09:54:37 --> Total execution time: 0.0620
ERROR - 2023-11-02 09:54:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:54:37 --> Config Class Initialized
INFO - 2023-11-02 09:54:37 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:54:37 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:54:37 --> Utf8 Class Initialized
INFO - 2023-11-02 09:54:37 --> URI Class Initialized
INFO - 2023-11-02 09:54:37 --> Router Class Initialized
INFO - 2023-11-02 09:54:37 --> Output Class Initialized
INFO - 2023-11-02 09:54:37 --> Security Class Initialized
DEBUG - 2023-11-02 09:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:54:37 --> Input Class Initialized
INFO - 2023-11-02 09:54:37 --> Language Class Initialized
INFO - 2023-11-02 09:54:37 --> Loader Class Initialized
INFO - 2023-11-02 09:54:37 --> Helper loaded: url_helper
INFO - 2023-11-02 09:54:37 --> Helper loaded: form_helper
INFO - 2023-11-02 09:54:37 --> Helper loaded: file_helper
INFO - 2023-11-02 09:54:37 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:54:37 --> Form Validation Class Initialized
INFO - 2023-11-02 09:54:37 --> Upload Class Initialized
INFO - 2023-11-02 09:54:37 --> Model "M_auth" initialized
INFO - 2023-11-02 09:54:37 --> Model "M_user" initialized
INFO - 2023-11-02 09:54:37 --> Model "M_produk" initialized
INFO - 2023-11-02 09:54:37 --> Controller Class Initialized
INFO - 2023-11-02 09:54:37 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/not_found.php
INFO - 2023-11-02 09:54:37 --> Final output sent to browser
DEBUG - 2023-11-02 09:54:37 --> Total execution time: 0.0493
ERROR - 2023-11-02 09:54:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:54:39 --> Config Class Initialized
INFO - 2023-11-02 09:54:39 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:54:39 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:54:39 --> Utf8 Class Initialized
INFO - 2023-11-02 09:54:39 --> URI Class Initialized
INFO - 2023-11-02 09:54:39 --> Router Class Initialized
INFO - 2023-11-02 09:54:39 --> Output Class Initialized
INFO - 2023-11-02 09:54:39 --> Security Class Initialized
DEBUG - 2023-11-02 09:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:54:39 --> Input Class Initialized
INFO - 2023-11-02 09:54:39 --> Language Class Initialized
INFO - 2023-11-02 09:54:39 --> Loader Class Initialized
INFO - 2023-11-02 09:54:39 --> Helper loaded: url_helper
INFO - 2023-11-02 09:54:39 --> Helper loaded: form_helper
INFO - 2023-11-02 09:54:39 --> Helper loaded: file_helper
INFO - 2023-11-02 09:54:39 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:54:39 --> Form Validation Class Initialized
INFO - 2023-11-02 09:54:39 --> Upload Class Initialized
INFO - 2023-11-02 09:54:39 --> Model "M_auth" initialized
INFO - 2023-11-02 09:54:39 --> Model "M_user" initialized
INFO - 2023-11-02 09:54:39 --> Model "M_produk" initialized
INFO - 2023-11-02 09:54:39 --> Controller Class Initialized
INFO - 2023-11-02 09:54:39 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:54:39 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:54:39 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:54:39 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:54:39 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:54:39 --> Model "M_bank" initialized
INFO - 2023-11-02 09:54:39 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:54:39 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
ERROR - 2023-11-02 09:54:39 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 09:54:39 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 09:54:39 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
INFO - 2023-11-02 09:54:39 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:54:39 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 09:54:39 --> Final output sent to browser
DEBUG - 2023-11-02 09:54:39 --> Total execution time: 0.0789
ERROR - 2023-11-02 09:54:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:54:41 --> Config Class Initialized
INFO - 2023-11-02 09:54:41 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:54:41 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:54:41 --> Utf8 Class Initialized
INFO - 2023-11-02 09:54:41 --> URI Class Initialized
INFO - 2023-11-02 09:54:41 --> Router Class Initialized
INFO - 2023-11-02 09:54:41 --> Output Class Initialized
INFO - 2023-11-02 09:54:41 --> Security Class Initialized
DEBUG - 2023-11-02 09:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:54:41 --> Input Class Initialized
INFO - 2023-11-02 09:54:41 --> Language Class Initialized
INFO - 2023-11-02 09:54:41 --> Loader Class Initialized
INFO - 2023-11-02 09:54:41 --> Helper loaded: url_helper
INFO - 2023-11-02 09:54:41 --> Helper loaded: form_helper
INFO - 2023-11-02 09:54:41 --> Helper loaded: file_helper
INFO - 2023-11-02 09:54:41 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:54:41 --> Form Validation Class Initialized
INFO - 2023-11-02 09:54:41 --> Upload Class Initialized
INFO - 2023-11-02 09:54:41 --> Model "M_auth" initialized
INFO - 2023-11-02 09:54:41 --> Model "M_user" initialized
INFO - 2023-11-02 09:54:41 --> Model "M_produk" initialized
INFO - 2023-11-02 09:54:41 --> Controller Class Initialized
INFO - 2023-11-02 09:54:41 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:54:41 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:54:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:54:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:54:41 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:54:41 --> Model "M_bank" initialized
INFO - 2023-11-02 09:54:41 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:54:41 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:54:41 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:54:41 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_bayar_sekarang.php
INFO - 2023-11-02 09:54:41 --> Final output sent to browser
DEBUG - 2023-11-02 09:54:41 --> Total execution time: 0.0689
ERROR - 2023-11-02 09:54:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:54:41 --> Config Class Initialized
INFO - 2023-11-02 09:54:41 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:54:41 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:54:41 --> Utf8 Class Initialized
INFO - 2023-11-02 09:54:41 --> URI Class Initialized
INFO - 2023-11-02 09:54:41 --> Router Class Initialized
INFO - 2023-11-02 09:54:41 --> Output Class Initialized
INFO - 2023-11-02 09:54:41 --> Security Class Initialized
DEBUG - 2023-11-02 09:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:54:41 --> Input Class Initialized
INFO - 2023-11-02 09:54:41 --> Language Class Initialized
INFO - 2023-11-02 09:54:41 --> Loader Class Initialized
INFO - 2023-11-02 09:54:41 --> Helper loaded: url_helper
INFO - 2023-11-02 09:54:41 --> Helper loaded: form_helper
INFO - 2023-11-02 09:54:41 --> Helper loaded: file_helper
INFO - 2023-11-02 09:54:41 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:54:41 --> Form Validation Class Initialized
INFO - 2023-11-02 09:54:41 --> Upload Class Initialized
INFO - 2023-11-02 09:54:41 --> Model "M_auth" initialized
INFO - 2023-11-02 09:54:41 --> Model "M_user" initialized
INFO - 2023-11-02 09:54:41 --> Model "M_produk" initialized
INFO - 2023-11-02 09:54:41 --> Controller Class Initialized
INFO - 2023-11-02 09:54:41 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/not_found.php
INFO - 2023-11-02 09:54:41 --> Final output sent to browser
DEBUG - 2023-11-02 09:54:41 --> Total execution time: 0.0235
ERROR - 2023-11-02 09:54:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:54:43 --> Config Class Initialized
INFO - 2023-11-02 09:54:43 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:54:43 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:54:43 --> Utf8 Class Initialized
INFO - 2023-11-02 09:54:43 --> URI Class Initialized
INFO - 2023-11-02 09:54:43 --> Router Class Initialized
INFO - 2023-11-02 09:54:43 --> Output Class Initialized
INFO - 2023-11-02 09:54:43 --> Security Class Initialized
DEBUG - 2023-11-02 09:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:54:43 --> Input Class Initialized
INFO - 2023-11-02 09:54:43 --> Language Class Initialized
INFO - 2023-11-02 09:54:43 --> Loader Class Initialized
INFO - 2023-11-02 09:54:43 --> Helper loaded: url_helper
INFO - 2023-11-02 09:54:43 --> Helper loaded: form_helper
INFO - 2023-11-02 09:54:43 --> Helper loaded: file_helper
INFO - 2023-11-02 09:54:43 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:54:43 --> Form Validation Class Initialized
INFO - 2023-11-02 09:54:43 --> Upload Class Initialized
INFO - 2023-11-02 09:54:43 --> Model "M_auth" initialized
INFO - 2023-11-02 09:54:43 --> Model "M_user" initialized
INFO - 2023-11-02 09:54:43 --> Model "M_produk" initialized
INFO - 2023-11-02 09:54:43 --> Controller Class Initialized
INFO - 2023-11-02 09:54:43 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:54:43 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:54:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:54:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:54:43 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:54:43 --> Model "M_bank" initialized
INFO - 2023-11-02 09:54:43 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:54:43 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
ERROR - 2023-11-02 09:54:43 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 09:54:43 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 09:54:43 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
INFO - 2023-11-02 09:54:43 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:54:43 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 09:54:43 --> Final output sent to browser
DEBUG - 2023-11-02 09:54:43 --> Total execution time: 0.0621
ERROR - 2023-11-02 09:54:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:54:45 --> Config Class Initialized
INFO - 2023-11-02 09:54:45 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:54:45 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:54:45 --> Utf8 Class Initialized
INFO - 2023-11-02 09:54:45 --> URI Class Initialized
INFO - 2023-11-02 09:54:45 --> Router Class Initialized
INFO - 2023-11-02 09:54:45 --> Output Class Initialized
INFO - 2023-11-02 09:54:45 --> Security Class Initialized
DEBUG - 2023-11-02 09:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:54:45 --> Input Class Initialized
INFO - 2023-11-02 09:54:45 --> Language Class Initialized
INFO - 2023-11-02 09:54:45 --> Loader Class Initialized
INFO - 2023-11-02 09:54:45 --> Helper loaded: url_helper
INFO - 2023-11-02 09:54:45 --> Helper loaded: form_helper
INFO - 2023-11-02 09:54:45 --> Helper loaded: file_helper
INFO - 2023-11-02 09:54:45 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:54:45 --> Form Validation Class Initialized
INFO - 2023-11-02 09:54:45 --> Upload Class Initialized
INFO - 2023-11-02 09:54:45 --> Model "M_auth" initialized
INFO - 2023-11-02 09:54:45 --> Model "M_user" initialized
INFO - 2023-11-02 09:54:45 --> Model "M_produk" initialized
INFO - 2023-11-02 09:54:45 --> Controller Class Initialized
INFO - 2023-11-02 09:54:45 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:54:45 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:54:45 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:54:45 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:54:45 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:54:45 --> Model "M_bank" initialized
INFO - 2023-11-02 09:54:45 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:54:45 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:54:45 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:54:45 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_bayar_sekarang.php
INFO - 2023-11-02 09:54:45 --> Final output sent to browser
DEBUG - 2023-11-02 09:54:45 --> Total execution time: 0.0287
ERROR - 2023-11-02 09:54:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:54:45 --> Config Class Initialized
INFO - 2023-11-02 09:54:45 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:54:45 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:54:45 --> Utf8 Class Initialized
INFO - 2023-11-02 09:54:45 --> URI Class Initialized
INFO - 2023-11-02 09:54:45 --> Router Class Initialized
INFO - 2023-11-02 09:54:45 --> Output Class Initialized
INFO - 2023-11-02 09:54:45 --> Security Class Initialized
DEBUG - 2023-11-02 09:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:54:45 --> Input Class Initialized
INFO - 2023-11-02 09:54:45 --> Language Class Initialized
INFO - 2023-11-02 09:54:45 --> Loader Class Initialized
INFO - 2023-11-02 09:54:45 --> Helper loaded: url_helper
INFO - 2023-11-02 09:54:45 --> Helper loaded: form_helper
INFO - 2023-11-02 09:54:45 --> Helper loaded: file_helper
INFO - 2023-11-02 09:54:45 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:54:45 --> Form Validation Class Initialized
INFO - 2023-11-02 09:54:45 --> Upload Class Initialized
INFO - 2023-11-02 09:54:45 --> Model "M_auth" initialized
INFO - 2023-11-02 09:54:45 --> Model "M_user" initialized
INFO - 2023-11-02 09:54:45 --> Model "M_produk" initialized
INFO - 2023-11-02 09:54:45 --> Controller Class Initialized
INFO - 2023-11-02 09:54:45 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/not_found.php
INFO - 2023-11-02 09:54:45 --> Final output sent to browser
DEBUG - 2023-11-02 09:54:45 --> Total execution time: 0.0214
ERROR - 2023-11-02 09:55:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:55:28 --> Config Class Initialized
INFO - 2023-11-02 09:55:28 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:55:28 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:55:28 --> Utf8 Class Initialized
INFO - 2023-11-02 09:55:28 --> URI Class Initialized
INFO - 2023-11-02 09:55:28 --> Router Class Initialized
INFO - 2023-11-02 09:55:28 --> Output Class Initialized
INFO - 2023-11-02 09:55:28 --> Security Class Initialized
DEBUG - 2023-11-02 09:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:55:28 --> Input Class Initialized
INFO - 2023-11-02 09:55:28 --> Language Class Initialized
INFO - 2023-11-02 09:55:28 --> Loader Class Initialized
INFO - 2023-11-02 09:55:28 --> Helper loaded: url_helper
INFO - 2023-11-02 09:55:28 --> Helper loaded: form_helper
INFO - 2023-11-02 09:55:28 --> Helper loaded: file_helper
INFO - 2023-11-02 09:55:28 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:55:28 --> Form Validation Class Initialized
INFO - 2023-11-02 09:55:28 --> Upload Class Initialized
INFO - 2023-11-02 09:55:28 --> Model "M_auth" initialized
INFO - 2023-11-02 09:55:28 --> Model "M_user" initialized
INFO - 2023-11-02 09:55:28 --> Model "M_produk" initialized
INFO - 2023-11-02 09:55:28 --> Controller Class Initialized
INFO - 2023-11-02 09:55:28 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:55:28 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:55:28 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:55:28 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:55:28 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:55:28 --> Model "M_bank" initialized
INFO - 2023-11-02 09:55:28 --> Model "M_pesan" initialized
ERROR - 2023-11-02 09:55:29 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 09:55:29 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 09:55:29 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
INFO - 2023-11-02 09:55:29 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:55:29 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 09:55:29 --> Final output sent to browser
DEBUG - 2023-11-02 09:55:29 --> Total execution time: 0.1360
ERROR - 2023-11-02 09:55:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:55:30 --> Config Class Initialized
INFO - 2023-11-02 09:55:30 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:55:30 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:55:30 --> Utf8 Class Initialized
INFO - 2023-11-02 09:55:30 --> URI Class Initialized
INFO - 2023-11-02 09:55:30 --> Router Class Initialized
INFO - 2023-11-02 09:55:30 --> Output Class Initialized
INFO - 2023-11-02 09:55:30 --> Security Class Initialized
DEBUG - 2023-11-02 09:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:55:30 --> Input Class Initialized
INFO - 2023-11-02 09:55:30 --> Language Class Initialized
INFO - 2023-11-02 09:55:30 --> Loader Class Initialized
INFO - 2023-11-02 09:55:30 --> Helper loaded: url_helper
INFO - 2023-11-02 09:55:30 --> Helper loaded: form_helper
INFO - 2023-11-02 09:55:30 --> Helper loaded: file_helper
INFO - 2023-11-02 09:55:30 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:55:30 --> Form Validation Class Initialized
INFO - 2023-11-02 09:55:30 --> Upload Class Initialized
INFO - 2023-11-02 09:55:30 --> Model "M_auth" initialized
INFO - 2023-11-02 09:55:30 --> Model "M_user" initialized
INFO - 2023-11-02 09:55:30 --> Model "M_produk" initialized
INFO - 2023-11-02 09:55:30 --> Controller Class Initialized
INFO - 2023-11-02 09:55:30 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:55:30 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:55:30 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:55:30 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:55:30 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:55:30 --> Model "M_bank" initialized
INFO - 2023-11-02 09:55:30 --> Model "M_pesan" initialized
ERROR - 2023-11-02 09:55:30 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 09:55:30 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 09:55:30 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
INFO - 2023-11-02 09:55:30 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:55:30 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 09:55:30 --> Final output sent to browser
DEBUG - 2023-11-02 09:55:30 --> Total execution time: 0.0957
ERROR - 2023-11-02 09:55:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:55:33 --> Config Class Initialized
INFO - 2023-11-02 09:55:33 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:55:33 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:55:33 --> Utf8 Class Initialized
INFO - 2023-11-02 09:55:33 --> URI Class Initialized
INFO - 2023-11-02 09:55:33 --> Router Class Initialized
INFO - 2023-11-02 09:55:33 --> Output Class Initialized
INFO - 2023-11-02 09:55:33 --> Security Class Initialized
DEBUG - 2023-11-02 09:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:55:33 --> Input Class Initialized
INFO - 2023-11-02 09:55:33 --> Language Class Initialized
INFO - 2023-11-02 09:55:33 --> Loader Class Initialized
INFO - 2023-11-02 09:55:33 --> Helper loaded: url_helper
INFO - 2023-11-02 09:55:33 --> Helper loaded: form_helper
INFO - 2023-11-02 09:55:33 --> Helper loaded: file_helper
INFO - 2023-11-02 09:55:33 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:55:33 --> Form Validation Class Initialized
INFO - 2023-11-02 09:55:33 --> Upload Class Initialized
INFO - 2023-11-02 09:55:33 --> Model "M_auth" initialized
INFO - 2023-11-02 09:55:33 --> Model "M_user" initialized
INFO - 2023-11-02 09:55:33 --> Model "M_produk" initialized
INFO - 2023-11-02 09:55:33 --> Controller Class Initialized
INFO - 2023-11-02 09:55:33 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:55:33 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:55:33 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:55:33 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:55:33 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:55:33 --> Model "M_bank" initialized
INFO - 2023-11-02 09:55:33 --> Model "M_pesan" initialized
INFO - 2023-11-02 09:55:33 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:55:33 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_bayar_sekarang.php
INFO - 2023-11-02 09:55:33 --> Final output sent to browser
DEBUG - 2023-11-02 09:55:33 --> Total execution time: 0.1076
ERROR - 2023-11-02 09:55:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:55:34 --> Config Class Initialized
INFO - 2023-11-02 09:55:34 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:55:34 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:55:34 --> Utf8 Class Initialized
INFO - 2023-11-02 09:55:34 --> URI Class Initialized
INFO - 2023-11-02 09:55:34 --> Router Class Initialized
INFO - 2023-11-02 09:55:34 --> Output Class Initialized
INFO - 2023-11-02 09:55:34 --> Security Class Initialized
DEBUG - 2023-11-02 09:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:55:34 --> Input Class Initialized
INFO - 2023-11-02 09:55:34 --> Language Class Initialized
INFO - 2023-11-02 09:55:34 --> Loader Class Initialized
INFO - 2023-11-02 09:55:34 --> Helper loaded: url_helper
INFO - 2023-11-02 09:55:34 --> Helper loaded: form_helper
INFO - 2023-11-02 09:55:34 --> Helper loaded: file_helper
INFO - 2023-11-02 09:55:34 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:55:34 --> Form Validation Class Initialized
INFO - 2023-11-02 09:55:34 --> Upload Class Initialized
INFO - 2023-11-02 09:55:34 --> Model "M_auth" initialized
INFO - 2023-11-02 09:55:34 --> Model "M_user" initialized
INFO - 2023-11-02 09:55:34 --> Model "M_produk" initialized
INFO - 2023-11-02 09:55:34 --> Controller Class Initialized
INFO - 2023-11-02 09:55:34 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/not_found.php
INFO - 2023-11-02 09:55:34 --> Final output sent to browser
DEBUG - 2023-11-02 09:55:34 --> Total execution time: 0.0223
ERROR - 2023-11-02 09:58:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:58:13 --> Config Class Initialized
INFO - 2023-11-02 09:58:13 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:58:13 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:58:13 --> Utf8 Class Initialized
INFO - 2023-11-02 09:58:13 --> URI Class Initialized
INFO - 2023-11-02 09:58:13 --> Router Class Initialized
INFO - 2023-11-02 09:58:13 --> Output Class Initialized
INFO - 2023-11-02 09:58:13 --> Security Class Initialized
DEBUG - 2023-11-02 09:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:58:13 --> Input Class Initialized
INFO - 2023-11-02 09:58:13 --> Language Class Initialized
INFO - 2023-11-02 09:58:13 --> Loader Class Initialized
INFO - 2023-11-02 09:58:13 --> Helper loaded: url_helper
INFO - 2023-11-02 09:58:13 --> Helper loaded: form_helper
INFO - 2023-11-02 09:58:13 --> Helper loaded: file_helper
INFO - 2023-11-02 09:58:13 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:58:13 --> Form Validation Class Initialized
INFO - 2023-11-02 09:58:13 --> Upload Class Initialized
INFO - 2023-11-02 09:58:13 --> Model "M_auth" initialized
INFO - 2023-11-02 09:58:13 --> Model "M_user" initialized
INFO - 2023-11-02 09:58:13 --> Model "M_produk" initialized
INFO - 2023-11-02 09:58:13 --> Controller Class Initialized
INFO - 2023-11-02 09:58:13 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:58:13 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:58:13 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:58:13 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:58:13 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:58:13 --> Model "M_bank" initialized
INFO - 2023-11-02 09:58:13 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:58:13 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:58:13 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:58:13 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_bayar_sekarang.php
INFO - 2023-11-02 09:58:13 --> Final output sent to browser
DEBUG - 2023-11-02 09:58:13 --> Total execution time: 0.1266
ERROR - 2023-11-02 09:58:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:58:13 --> Config Class Initialized
INFO - 2023-11-02 09:58:13 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:58:13 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:58:13 --> Utf8 Class Initialized
INFO - 2023-11-02 09:58:13 --> URI Class Initialized
INFO - 2023-11-02 09:58:13 --> Router Class Initialized
INFO - 2023-11-02 09:58:13 --> Output Class Initialized
INFO - 2023-11-02 09:58:13 --> Security Class Initialized
DEBUG - 2023-11-02 09:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:58:13 --> Input Class Initialized
INFO - 2023-11-02 09:58:13 --> Language Class Initialized
INFO - 2023-11-02 09:58:13 --> Loader Class Initialized
INFO - 2023-11-02 09:58:13 --> Helper loaded: url_helper
INFO - 2023-11-02 09:58:13 --> Helper loaded: form_helper
INFO - 2023-11-02 09:58:13 --> Helper loaded: file_helper
INFO - 2023-11-02 09:58:13 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:58:13 --> Form Validation Class Initialized
INFO - 2023-11-02 09:58:13 --> Upload Class Initialized
INFO - 2023-11-02 09:58:13 --> Model "M_auth" initialized
INFO - 2023-11-02 09:58:13 --> Model "M_user" initialized
INFO - 2023-11-02 09:58:13 --> Model "M_produk" initialized
INFO - 2023-11-02 09:58:13 --> Controller Class Initialized
INFO - 2023-11-02 09:58:13 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/not_found.php
INFO - 2023-11-02 09:58:13 --> Final output sent to browser
DEBUG - 2023-11-02 09:58:13 --> Total execution time: 0.0213
ERROR - 2023-11-02 09:58:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:58:15 --> Config Class Initialized
INFO - 2023-11-02 09:58:15 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:58:15 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:58:15 --> Utf8 Class Initialized
INFO - 2023-11-02 09:58:15 --> URI Class Initialized
INFO - 2023-11-02 09:58:15 --> Router Class Initialized
INFO - 2023-11-02 09:58:15 --> Output Class Initialized
INFO - 2023-11-02 09:58:15 --> Security Class Initialized
DEBUG - 2023-11-02 09:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:58:15 --> Input Class Initialized
INFO - 2023-11-02 09:58:15 --> Language Class Initialized
INFO - 2023-11-02 09:58:15 --> Loader Class Initialized
INFO - 2023-11-02 09:58:15 --> Helper loaded: url_helper
INFO - 2023-11-02 09:58:15 --> Helper loaded: form_helper
INFO - 2023-11-02 09:58:15 --> Helper loaded: file_helper
INFO - 2023-11-02 09:58:15 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:58:15 --> Form Validation Class Initialized
INFO - 2023-11-02 09:58:15 --> Upload Class Initialized
INFO - 2023-11-02 09:58:15 --> Model "M_auth" initialized
INFO - 2023-11-02 09:58:15 --> Model "M_user" initialized
INFO - 2023-11-02 09:58:15 --> Model "M_produk" initialized
INFO - 2023-11-02 09:58:15 --> Controller Class Initialized
INFO - 2023-11-02 09:58:15 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:58:15 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:58:15 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:58:15 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:58:15 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:58:15 --> Model "M_bank" initialized
INFO - 2023-11-02 09:58:15 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:58:15 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
ERROR - 2023-11-02 09:58:15 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 09:58:15 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 09:58:15 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
INFO - 2023-11-02 09:58:15 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:58:15 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 09:58:15 --> Final output sent to browser
DEBUG - 2023-11-02 09:58:15 --> Total execution time: 0.0308
ERROR - 2023-11-02 09:58:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:58:17 --> Config Class Initialized
INFO - 2023-11-02 09:58:17 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:58:17 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:58:17 --> Utf8 Class Initialized
INFO - 2023-11-02 09:58:17 --> URI Class Initialized
INFO - 2023-11-02 09:58:17 --> Router Class Initialized
INFO - 2023-11-02 09:58:17 --> Output Class Initialized
INFO - 2023-11-02 09:58:17 --> Security Class Initialized
DEBUG - 2023-11-02 09:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:58:17 --> Input Class Initialized
INFO - 2023-11-02 09:58:17 --> Language Class Initialized
INFO - 2023-11-02 09:58:17 --> Loader Class Initialized
INFO - 2023-11-02 09:58:17 --> Helper loaded: url_helper
INFO - 2023-11-02 09:58:17 --> Helper loaded: form_helper
INFO - 2023-11-02 09:58:17 --> Helper loaded: file_helper
INFO - 2023-11-02 09:58:17 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:58:17 --> Form Validation Class Initialized
INFO - 2023-11-02 09:58:17 --> Upload Class Initialized
INFO - 2023-11-02 09:58:17 --> Model "M_auth" initialized
INFO - 2023-11-02 09:58:17 --> Model "M_user" initialized
INFO - 2023-11-02 09:58:17 --> Model "M_produk" initialized
INFO - 2023-11-02 09:58:17 --> Controller Class Initialized
INFO - 2023-11-02 09:58:17 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:58:17 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:58:17 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:58:17 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:58:17 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:58:17 --> Model "M_bank" initialized
INFO - 2023-11-02 09:58:17 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:58:17 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:58:17 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:58:17 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_bayar_sekarang.php
INFO - 2023-11-02 09:58:17 --> Final output sent to browser
DEBUG - 2023-11-02 09:58:17 --> Total execution time: 0.0499
ERROR - 2023-11-02 09:58:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:58:17 --> Config Class Initialized
INFO - 2023-11-02 09:58:17 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:58:17 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:58:17 --> Utf8 Class Initialized
INFO - 2023-11-02 09:58:17 --> URI Class Initialized
INFO - 2023-11-02 09:58:17 --> Router Class Initialized
INFO - 2023-11-02 09:58:17 --> Output Class Initialized
INFO - 2023-11-02 09:58:17 --> Security Class Initialized
DEBUG - 2023-11-02 09:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:58:17 --> Input Class Initialized
INFO - 2023-11-02 09:58:17 --> Language Class Initialized
INFO - 2023-11-02 09:58:17 --> Loader Class Initialized
INFO - 2023-11-02 09:58:17 --> Helper loaded: url_helper
INFO - 2023-11-02 09:58:17 --> Helper loaded: form_helper
INFO - 2023-11-02 09:58:17 --> Helper loaded: file_helper
INFO - 2023-11-02 09:58:17 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:58:17 --> Form Validation Class Initialized
INFO - 2023-11-02 09:58:17 --> Upload Class Initialized
INFO - 2023-11-02 09:58:17 --> Model "M_auth" initialized
INFO - 2023-11-02 09:58:17 --> Model "M_user" initialized
INFO - 2023-11-02 09:58:17 --> Model "M_produk" initialized
INFO - 2023-11-02 09:58:17 --> Controller Class Initialized
INFO - 2023-11-02 09:58:17 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/not_found.php
INFO - 2023-11-02 09:58:17 --> Final output sent to browser
DEBUG - 2023-11-02 09:58:17 --> Total execution time: 0.0484
ERROR - 2023-11-02 09:58:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:58:20 --> Config Class Initialized
INFO - 2023-11-02 09:58:20 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:58:20 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:58:20 --> Utf8 Class Initialized
INFO - 2023-11-02 09:58:20 --> URI Class Initialized
INFO - 2023-11-02 09:58:20 --> Router Class Initialized
INFO - 2023-11-02 09:58:20 --> Output Class Initialized
INFO - 2023-11-02 09:58:20 --> Security Class Initialized
DEBUG - 2023-11-02 09:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:58:20 --> Input Class Initialized
INFO - 2023-11-02 09:58:20 --> Language Class Initialized
INFO - 2023-11-02 09:58:20 --> Loader Class Initialized
INFO - 2023-11-02 09:58:20 --> Helper loaded: url_helper
INFO - 2023-11-02 09:58:20 --> Helper loaded: form_helper
INFO - 2023-11-02 09:58:20 --> Helper loaded: file_helper
INFO - 2023-11-02 09:58:20 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:58:20 --> Form Validation Class Initialized
INFO - 2023-11-02 09:58:20 --> Upload Class Initialized
INFO - 2023-11-02 09:58:20 --> Model "M_auth" initialized
INFO - 2023-11-02 09:58:20 --> Model "M_user" initialized
INFO - 2023-11-02 09:58:20 --> Model "M_produk" initialized
INFO - 2023-11-02 09:58:20 --> Controller Class Initialized
INFO - 2023-11-02 09:58:20 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:58:20 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:58:20 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:58:20 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:58:20 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:58:20 --> Model "M_bank" initialized
INFO - 2023-11-02 09:58:20 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:58:20 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
ERROR - 2023-11-02 09:58:20 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 09:58:20 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 09:58:20 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
INFO - 2023-11-02 09:58:20 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:58:20 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 09:58:20 --> Final output sent to browser
DEBUG - 2023-11-02 09:58:20 --> Total execution time: 0.1199
ERROR - 2023-11-02 09:58:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:58:22 --> Config Class Initialized
INFO - 2023-11-02 09:58:22 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:58:22 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:58:22 --> Utf8 Class Initialized
INFO - 2023-11-02 09:58:22 --> URI Class Initialized
INFO - 2023-11-02 09:58:22 --> Router Class Initialized
INFO - 2023-11-02 09:58:22 --> Output Class Initialized
INFO - 2023-11-02 09:58:22 --> Security Class Initialized
DEBUG - 2023-11-02 09:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:58:22 --> Input Class Initialized
INFO - 2023-11-02 09:58:22 --> Language Class Initialized
INFO - 2023-11-02 09:58:22 --> Loader Class Initialized
INFO - 2023-11-02 09:58:22 --> Helper loaded: url_helper
INFO - 2023-11-02 09:58:22 --> Helper loaded: form_helper
INFO - 2023-11-02 09:58:22 --> Helper loaded: file_helper
INFO - 2023-11-02 09:58:22 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:58:22 --> Form Validation Class Initialized
INFO - 2023-11-02 09:58:22 --> Upload Class Initialized
INFO - 2023-11-02 09:58:22 --> Model "M_auth" initialized
INFO - 2023-11-02 09:58:22 --> Model "M_user" initialized
INFO - 2023-11-02 09:58:22 --> Model "M_produk" initialized
INFO - 2023-11-02 09:58:22 --> Controller Class Initialized
INFO - 2023-11-02 09:58:22 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:58:22 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:58:22 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:58:22 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:58:22 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:58:22 --> Model "M_bank" initialized
INFO - 2023-11-02 09:58:22 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:58:22 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 09:58:22 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:58:22 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_bayar_sekarang.php
INFO - 2023-11-02 09:58:22 --> Final output sent to browser
DEBUG - 2023-11-02 09:58:22 --> Total execution time: 0.0731
ERROR - 2023-11-02 09:58:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:58:22 --> Config Class Initialized
INFO - 2023-11-02 09:58:22 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:58:22 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:58:22 --> Utf8 Class Initialized
INFO - 2023-11-02 09:58:22 --> URI Class Initialized
INFO - 2023-11-02 09:58:22 --> Router Class Initialized
INFO - 2023-11-02 09:58:22 --> Output Class Initialized
INFO - 2023-11-02 09:58:22 --> Security Class Initialized
DEBUG - 2023-11-02 09:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:58:22 --> Input Class Initialized
INFO - 2023-11-02 09:58:22 --> Language Class Initialized
INFO - 2023-11-02 09:58:22 --> Loader Class Initialized
INFO - 2023-11-02 09:58:22 --> Helper loaded: url_helper
INFO - 2023-11-02 09:58:22 --> Helper loaded: form_helper
INFO - 2023-11-02 09:58:22 --> Helper loaded: file_helper
INFO - 2023-11-02 09:58:22 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:58:22 --> Form Validation Class Initialized
INFO - 2023-11-02 09:58:22 --> Upload Class Initialized
INFO - 2023-11-02 09:58:22 --> Model "M_auth" initialized
INFO - 2023-11-02 09:58:22 --> Model "M_user" initialized
INFO - 2023-11-02 09:58:22 --> Model "M_produk" initialized
INFO - 2023-11-02 09:58:22 --> Controller Class Initialized
INFO - 2023-11-02 09:58:22 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/not_found.php
INFO - 2023-11-02 09:58:22 --> Final output sent to browser
DEBUG - 2023-11-02 09:58:22 --> Total execution time: 0.0249
ERROR - 2023-11-02 09:59:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 09:59:51 --> Config Class Initialized
INFO - 2023-11-02 09:59:51 --> Hooks Class Initialized
DEBUG - 2023-11-02 09:59:51 --> UTF-8 Support Enabled
INFO - 2023-11-02 09:59:51 --> Utf8 Class Initialized
INFO - 2023-11-02 09:59:51 --> URI Class Initialized
INFO - 2023-11-02 09:59:51 --> Router Class Initialized
INFO - 2023-11-02 09:59:51 --> Output Class Initialized
INFO - 2023-11-02 09:59:51 --> Security Class Initialized
DEBUG - 2023-11-02 09:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 09:59:51 --> Input Class Initialized
INFO - 2023-11-02 09:59:51 --> Language Class Initialized
INFO - 2023-11-02 09:59:51 --> Loader Class Initialized
INFO - 2023-11-02 09:59:51 --> Helper loaded: url_helper
INFO - 2023-11-02 09:59:51 --> Helper loaded: form_helper
INFO - 2023-11-02 09:59:51 --> Helper loaded: file_helper
INFO - 2023-11-02 09:59:51 --> Database Driver Class Initialized
DEBUG - 2023-11-02 09:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 09:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 09:59:51 --> Form Validation Class Initialized
INFO - 2023-11-02 09:59:51 --> Upload Class Initialized
INFO - 2023-11-02 09:59:51 --> Model "M_auth" initialized
INFO - 2023-11-02 09:59:51 --> Model "M_user" initialized
INFO - 2023-11-02 09:59:51 --> Model "M_produk" initialized
INFO - 2023-11-02 09:59:51 --> Controller Class Initialized
INFO - 2023-11-02 09:59:51 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 09:59:51 --> Model "M_produk" initialized
DEBUG - 2023-11-02 09:59:51 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 09:59:51 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 09:59:51 --> Model "M_transaksi" initialized
INFO - 2023-11-02 09:59:51 --> Model "M_bank" initialized
INFO - 2023-11-02 09:59:51 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 09:59:51 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
ERROR - 2023-11-02 09:59:51 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 09:59:51 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 09:59:51 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
INFO - 2023-11-02 09:59:51 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 09:59:51 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 09:59:51 --> Final output sent to browser
DEBUG - 2023-11-02 09:59:51 --> Total execution time: 0.1205
ERROR - 2023-11-02 10:00:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 10:00:37 --> Config Class Initialized
INFO - 2023-11-02 10:00:37 --> Hooks Class Initialized
DEBUG - 2023-11-02 10:00:37 --> UTF-8 Support Enabled
INFO - 2023-11-02 10:00:37 --> Utf8 Class Initialized
INFO - 2023-11-02 10:00:37 --> URI Class Initialized
INFO - 2023-11-02 10:00:37 --> Router Class Initialized
INFO - 2023-11-02 10:00:37 --> Output Class Initialized
INFO - 2023-11-02 10:00:37 --> Security Class Initialized
DEBUG - 2023-11-02 10:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 10:00:37 --> Input Class Initialized
INFO - 2023-11-02 10:00:37 --> Language Class Initialized
INFO - 2023-11-02 10:00:37 --> Loader Class Initialized
INFO - 2023-11-02 10:00:37 --> Helper loaded: url_helper
INFO - 2023-11-02 10:00:37 --> Helper loaded: form_helper
INFO - 2023-11-02 10:00:37 --> Helper loaded: file_helper
INFO - 2023-11-02 10:00:37 --> Database Driver Class Initialized
DEBUG - 2023-11-02 10:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 10:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 10:00:37 --> Form Validation Class Initialized
INFO - 2023-11-02 10:00:37 --> Upload Class Initialized
INFO - 2023-11-02 10:00:37 --> Model "M_auth" initialized
INFO - 2023-11-02 10:00:37 --> Model "M_user" initialized
INFO - 2023-11-02 10:00:37 --> Model "M_produk" initialized
INFO - 2023-11-02 10:00:37 --> Controller Class Initialized
INFO - 2023-11-02 10:00:37 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 10:00:37 --> Model "M_produk" initialized
DEBUG - 2023-11-02 10:00:37 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 10:00:37 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 10:00:37 --> Model "M_transaksi" initialized
INFO - 2023-11-02 10:00:37 --> Model "M_bank" initialized
INFO - 2023-11-02 10:00:37 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 10:00:37 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
ERROR - 2023-11-02 10:00:37 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 10:00:37 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 10:00:37 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
INFO - 2023-11-02 10:00:37 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 10:00:37 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 10:00:37 --> Final output sent to browser
DEBUG - 2023-11-02 10:00:37 --> Total execution time: 0.0783
ERROR - 2023-11-02 10:00:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 10:00:40 --> Config Class Initialized
INFO - 2023-11-02 10:00:40 --> Hooks Class Initialized
DEBUG - 2023-11-02 10:00:40 --> UTF-8 Support Enabled
INFO - 2023-11-02 10:00:40 --> Utf8 Class Initialized
INFO - 2023-11-02 10:00:40 --> URI Class Initialized
INFO - 2023-11-02 10:00:40 --> Router Class Initialized
INFO - 2023-11-02 10:00:40 --> Output Class Initialized
INFO - 2023-11-02 10:00:40 --> Security Class Initialized
DEBUG - 2023-11-02 10:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 10:00:40 --> Input Class Initialized
INFO - 2023-11-02 10:00:40 --> Language Class Initialized
INFO - 2023-11-02 10:00:40 --> Loader Class Initialized
INFO - 2023-11-02 10:00:40 --> Helper loaded: url_helper
INFO - 2023-11-02 10:00:40 --> Helper loaded: form_helper
INFO - 2023-11-02 10:00:40 --> Helper loaded: file_helper
INFO - 2023-11-02 10:00:40 --> Database Driver Class Initialized
DEBUG - 2023-11-02 10:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 10:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 10:00:40 --> Form Validation Class Initialized
INFO - 2023-11-02 10:00:40 --> Upload Class Initialized
INFO - 2023-11-02 10:00:40 --> Model "M_auth" initialized
INFO - 2023-11-02 10:00:40 --> Model "M_user" initialized
INFO - 2023-11-02 10:00:40 --> Model "M_produk" initialized
INFO - 2023-11-02 10:00:40 --> Controller Class Initialized
INFO - 2023-11-02 10:00:40 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 10:00:40 --> Model "M_produk" initialized
DEBUG - 2023-11-02 10:00:40 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 10:00:40 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 10:00:40 --> Model "M_transaksi" initialized
INFO - 2023-11-02 10:00:40 --> Model "M_bank" initialized
INFO - 2023-11-02 10:00:40 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 10:00:40 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 10:00:40 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 10:00:40 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_bayar_sekarang.php
INFO - 2023-11-02 10:00:40 --> Final output sent to browser
DEBUG - 2023-11-02 10:00:40 --> Total execution time: 0.1321
ERROR - 2023-11-02 10:00:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 10:00:41 --> Config Class Initialized
INFO - 2023-11-02 10:00:41 --> Hooks Class Initialized
DEBUG - 2023-11-02 10:00:41 --> UTF-8 Support Enabled
INFO - 2023-11-02 10:00:41 --> Utf8 Class Initialized
INFO - 2023-11-02 10:00:41 --> URI Class Initialized
INFO - 2023-11-02 10:00:41 --> Router Class Initialized
INFO - 2023-11-02 10:00:41 --> Output Class Initialized
INFO - 2023-11-02 10:00:41 --> Security Class Initialized
DEBUG - 2023-11-02 10:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 10:00:41 --> Input Class Initialized
INFO - 2023-11-02 10:00:41 --> Language Class Initialized
INFO - 2023-11-02 10:00:41 --> Loader Class Initialized
INFO - 2023-11-02 10:00:41 --> Helper loaded: url_helper
INFO - 2023-11-02 10:00:41 --> Helper loaded: form_helper
INFO - 2023-11-02 10:00:41 --> Helper loaded: file_helper
INFO - 2023-11-02 10:00:41 --> Database Driver Class Initialized
DEBUG - 2023-11-02 10:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 10:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 10:00:41 --> Form Validation Class Initialized
INFO - 2023-11-02 10:00:41 --> Upload Class Initialized
INFO - 2023-11-02 10:00:41 --> Model "M_auth" initialized
INFO - 2023-11-02 10:00:41 --> Model "M_user" initialized
INFO - 2023-11-02 10:00:41 --> Model "M_produk" initialized
INFO - 2023-11-02 10:00:41 --> Controller Class Initialized
INFO - 2023-11-02 10:00:41 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/not_found.php
INFO - 2023-11-02 10:00:41 --> Final output sent to browser
DEBUG - 2023-11-02 10:00:41 --> Total execution time: 0.0836
ERROR - 2023-11-02 10:00:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 10:00:51 --> Config Class Initialized
INFO - 2023-11-02 10:00:51 --> Hooks Class Initialized
DEBUG - 2023-11-02 10:00:51 --> UTF-8 Support Enabled
INFO - 2023-11-02 10:00:51 --> Utf8 Class Initialized
INFO - 2023-11-02 10:00:51 --> URI Class Initialized
INFO - 2023-11-02 10:00:51 --> Router Class Initialized
INFO - 2023-11-02 10:00:51 --> Output Class Initialized
INFO - 2023-11-02 10:00:51 --> Security Class Initialized
DEBUG - 2023-11-02 10:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 10:00:51 --> Input Class Initialized
INFO - 2023-11-02 10:00:51 --> Language Class Initialized
INFO - 2023-11-02 10:00:51 --> Loader Class Initialized
INFO - 2023-11-02 10:00:51 --> Helper loaded: url_helper
INFO - 2023-11-02 10:00:51 --> Helper loaded: form_helper
INFO - 2023-11-02 10:00:51 --> Helper loaded: file_helper
INFO - 2023-11-02 10:00:51 --> Database Driver Class Initialized
DEBUG - 2023-11-02 10:00:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 10:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 10:00:51 --> Form Validation Class Initialized
INFO - 2023-11-02 10:00:51 --> Upload Class Initialized
INFO - 2023-11-02 10:00:51 --> Model "M_auth" initialized
INFO - 2023-11-02 10:00:51 --> Model "M_user" initialized
INFO - 2023-11-02 10:00:51 --> Model "M_produk" initialized
INFO - 2023-11-02 10:00:51 --> Controller Class Initialized
INFO - 2023-11-02 10:00:51 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 10:00:51 --> Model "M_produk" initialized
DEBUG - 2023-11-02 10:00:51 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 10:00:51 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 10:00:51 --> Model "M_transaksi" initialized
INFO - 2023-11-02 10:00:51 --> Model "M_bank" initialized
INFO - 2023-11-02 10:00:51 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 10:00:51 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
ERROR - 2023-11-02 10:00:51 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 10:00:51 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 10:00:51 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
INFO - 2023-11-02 10:00:51 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 10:00:51 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 10:00:51 --> Final output sent to browser
DEBUG - 2023-11-02 10:00:51 --> Total execution time: 0.0842
ERROR - 2023-11-02 10:00:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 10:00:53 --> Config Class Initialized
INFO - 2023-11-02 10:00:53 --> Hooks Class Initialized
DEBUG - 2023-11-02 10:00:53 --> UTF-8 Support Enabled
INFO - 2023-11-02 10:00:53 --> Utf8 Class Initialized
INFO - 2023-11-02 10:00:53 --> URI Class Initialized
INFO - 2023-11-02 10:00:53 --> Router Class Initialized
INFO - 2023-11-02 10:00:53 --> Output Class Initialized
INFO - 2023-11-02 10:00:53 --> Security Class Initialized
DEBUG - 2023-11-02 10:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 10:00:53 --> Input Class Initialized
INFO - 2023-11-02 10:00:53 --> Language Class Initialized
INFO - 2023-11-02 10:00:53 --> Loader Class Initialized
INFO - 2023-11-02 10:00:53 --> Helper loaded: url_helper
INFO - 2023-11-02 10:00:53 --> Helper loaded: form_helper
INFO - 2023-11-02 10:00:53 --> Helper loaded: file_helper
INFO - 2023-11-02 10:00:53 --> Database Driver Class Initialized
DEBUG - 2023-11-02 10:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 10:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 10:00:53 --> Form Validation Class Initialized
INFO - 2023-11-02 10:00:53 --> Upload Class Initialized
INFO - 2023-11-02 10:00:53 --> Model "M_auth" initialized
INFO - 2023-11-02 10:00:53 --> Model "M_user" initialized
INFO - 2023-11-02 10:00:53 --> Model "M_produk" initialized
INFO - 2023-11-02 10:00:53 --> Controller Class Initialized
INFO - 2023-11-02 10:00:53 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 10:00:53 --> Model "M_produk" initialized
DEBUG - 2023-11-02 10:00:53 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 10:00:53 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 10:00:53 --> Model "M_transaksi" initialized
INFO - 2023-11-02 10:00:53 --> Model "M_bank" initialized
INFO - 2023-11-02 10:00:53 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 10:00:53 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 10:00:53 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 10:00:53 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_bayar_sekarang.php
INFO - 2023-11-02 10:00:53 --> Final output sent to browser
DEBUG - 2023-11-02 10:00:53 --> Total execution time: 0.0269
ERROR - 2023-11-02 10:00:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 10:00:54 --> Config Class Initialized
INFO - 2023-11-02 10:00:54 --> Hooks Class Initialized
DEBUG - 2023-11-02 10:00:54 --> UTF-8 Support Enabled
INFO - 2023-11-02 10:00:54 --> Utf8 Class Initialized
INFO - 2023-11-02 10:00:54 --> URI Class Initialized
INFO - 2023-11-02 10:00:54 --> Router Class Initialized
INFO - 2023-11-02 10:00:54 --> Output Class Initialized
INFO - 2023-11-02 10:00:54 --> Security Class Initialized
DEBUG - 2023-11-02 10:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 10:00:54 --> Input Class Initialized
INFO - 2023-11-02 10:00:54 --> Language Class Initialized
INFO - 2023-11-02 10:00:54 --> Loader Class Initialized
INFO - 2023-11-02 10:00:54 --> Helper loaded: url_helper
INFO - 2023-11-02 10:00:54 --> Helper loaded: form_helper
INFO - 2023-11-02 10:00:54 --> Helper loaded: file_helper
INFO - 2023-11-02 10:00:54 --> Database Driver Class Initialized
DEBUG - 2023-11-02 10:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 10:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 10:00:54 --> Form Validation Class Initialized
INFO - 2023-11-02 10:00:54 --> Upload Class Initialized
INFO - 2023-11-02 10:00:54 --> Model "M_auth" initialized
INFO - 2023-11-02 10:00:54 --> Model "M_user" initialized
INFO - 2023-11-02 10:00:54 --> Model "M_produk" initialized
INFO - 2023-11-02 10:00:54 --> Controller Class Initialized
INFO - 2023-11-02 10:00:54 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/not_found.php
INFO - 2023-11-02 10:00:54 --> Final output sent to browser
DEBUG - 2023-11-02 10:00:54 --> Total execution time: 0.0236
ERROR - 2023-11-02 10:02:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 10:02:10 --> Config Class Initialized
INFO - 2023-11-02 10:02:10 --> Hooks Class Initialized
DEBUG - 2023-11-02 10:02:10 --> UTF-8 Support Enabled
INFO - 2023-11-02 10:02:10 --> Utf8 Class Initialized
INFO - 2023-11-02 10:02:10 --> URI Class Initialized
INFO - 2023-11-02 10:02:10 --> Router Class Initialized
INFO - 2023-11-02 10:02:10 --> Output Class Initialized
INFO - 2023-11-02 10:02:10 --> Security Class Initialized
DEBUG - 2023-11-02 10:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 10:02:10 --> Input Class Initialized
INFO - 2023-11-02 10:02:10 --> Language Class Initialized
INFO - 2023-11-02 10:02:10 --> Loader Class Initialized
INFO - 2023-11-02 10:02:10 --> Helper loaded: url_helper
INFO - 2023-11-02 10:02:10 --> Helper loaded: form_helper
INFO - 2023-11-02 10:02:10 --> Helper loaded: file_helper
INFO - 2023-11-02 10:02:10 --> Database Driver Class Initialized
DEBUG - 2023-11-02 10:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 10:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 10:02:10 --> Form Validation Class Initialized
INFO - 2023-11-02 10:02:10 --> Upload Class Initialized
INFO - 2023-11-02 10:02:10 --> Model "M_auth" initialized
INFO - 2023-11-02 10:02:10 --> Model "M_user" initialized
INFO - 2023-11-02 10:02:10 --> Model "M_produk" initialized
INFO - 2023-11-02 10:02:10 --> Controller Class Initialized
INFO - 2023-11-02 10:02:10 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 10:02:10 --> Model "M_produk" initialized
DEBUG - 2023-11-02 10:02:10 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 10:02:10 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 10:02:10 --> Model "M_transaksi" initialized
INFO - 2023-11-02 10:02:10 --> Model "M_bank" initialized
INFO - 2023-11-02 10:02:10 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 10:02:10 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
ERROR - 2023-11-02 10:02:10 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 10:02:10 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 10:02:10 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
INFO - 2023-11-02 10:02:10 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 10:02:10 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 10:02:10 --> Final output sent to browser
DEBUG - 2023-11-02 10:02:10 --> Total execution time: 0.0398
ERROR - 2023-11-02 10:02:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 10:02:13 --> Config Class Initialized
INFO - 2023-11-02 10:02:13 --> Hooks Class Initialized
DEBUG - 2023-11-02 10:02:13 --> UTF-8 Support Enabled
INFO - 2023-11-02 10:02:13 --> Utf8 Class Initialized
INFO - 2023-11-02 10:02:13 --> URI Class Initialized
INFO - 2023-11-02 10:02:13 --> Router Class Initialized
INFO - 2023-11-02 10:02:13 --> Output Class Initialized
INFO - 2023-11-02 10:02:13 --> Security Class Initialized
DEBUG - 2023-11-02 10:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 10:02:13 --> Input Class Initialized
INFO - 2023-11-02 10:02:13 --> Language Class Initialized
INFO - 2023-11-02 10:02:13 --> Loader Class Initialized
INFO - 2023-11-02 10:02:13 --> Helper loaded: url_helper
INFO - 2023-11-02 10:02:13 --> Helper loaded: form_helper
INFO - 2023-11-02 10:02:13 --> Helper loaded: file_helper
INFO - 2023-11-02 10:02:13 --> Database Driver Class Initialized
DEBUG - 2023-11-02 10:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 10:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 10:02:13 --> Form Validation Class Initialized
INFO - 2023-11-02 10:02:13 --> Upload Class Initialized
INFO - 2023-11-02 10:02:13 --> Model "M_auth" initialized
INFO - 2023-11-02 10:02:13 --> Model "M_user" initialized
INFO - 2023-11-02 10:02:13 --> Model "M_produk" initialized
INFO - 2023-11-02 10:02:13 --> Controller Class Initialized
INFO - 2023-11-02 10:02:13 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 10:02:13 --> Model "M_produk" initialized
DEBUG - 2023-11-02 10:02:13 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 10:02:13 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 10:02:13 --> Model "M_transaksi" initialized
INFO - 2023-11-02 10:02:13 --> Model "M_bank" initialized
INFO - 2023-11-02 10:02:13 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 10:02:13 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 10:02:13 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 10:02:13 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_bayar_sekarang.php
INFO - 2023-11-02 10:02:13 --> Final output sent to browser
DEBUG - 2023-11-02 10:02:13 --> Total execution time: 0.0915
ERROR - 2023-11-02 10:02:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 10:02:13 --> Config Class Initialized
INFO - 2023-11-02 10:02:13 --> Hooks Class Initialized
DEBUG - 2023-11-02 10:02:13 --> UTF-8 Support Enabled
INFO - 2023-11-02 10:02:13 --> Utf8 Class Initialized
INFO - 2023-11-02 10:02:13 --> URI Class Initialized
INFO - 2023-11-02 10:02:13 --> Router Class Initialized
INFO - 2023-11-02 10:02:13 --> Output Class Initialized
INFO - 2023-11-02 10:02:13 --> Security Class Initialized
DEBUG - 2023-11-02 10:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 10:02:13 --> Input Class Initialized
INFO - 2023-11-02 10:02:13 --> Language Class Initialized
INFO - 2023-11-02 10:02:13 --> Loader Class Initialized
INFO - 2023-11-02 10:02:13 --> Helper loaded: url_helper
INFO - 2023-11-02 10:02:13 --> Helper loaded: form_helper
INFO - 2023-11-02 10:02:13 --> Helper loaded: file_helper
INFO - 2023-11-02 10:02:13 --> Database Driver Class Initialized
DEBUG - 2023-11-02 10:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 10:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 10:02:13 --> Form Validation Class Initialized
INFO - 2023-11-02 10:02:13 --> Upload Class Initialized
INFO - 2023-11-02 10:02:13 --> Model "M_auth" initialized
INFO - 2023-11-02 10:02:14 --> Model "M_user" initialized
INFO - 2023-11-02 10:02:14 --> Model "M_produk" initialized
INFO - 2023-11-02 10:02:14 --> Controller Class Initialized
INFO - 2023-11-02 10:02:14 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/not_found.php
INFO - 2023-11-02 10:02:14 --> Final output sent to browser
DEBUG - 2023-11-02 10:02:14 --> Total execution time: 0.0248
ERROR - 2023-11-02 11:18:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:18:34 --> Config Class Initialized
INFO - 2023-11-02 11:18:34 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:18:34 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:18:34 --> Utf8 Class Initialized
INFO - 2023-11-02 11:18:34 --> URI Class Initialized
INFO - 2023-11-02 11:18:34 --> Router Class Initialized
INFO - 2023-11-02 11:18:34 --> Output Class Initialized
INFO - 2023-11-02 11:18:34 --> Security Class Initialized
DEBUG - 2023-11-02 11:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:18:34 --> Input Class Initialized
INFO - 2023-11-02 11:18:34 --> Language Class Initialized
INFO - 2023-11-02 11:18:34 --> Loader Class Initialized
INFO - 2023-11-02 11:18:34 --> Helper loaded: url_helper
INFO - 2023-11-02 11:18:34 --> Helper loaded: form_helper
INFO - 2023-11-02 11:18:34 --> Helper loaded: file_helper
INFO - 2023-11-02 11:18:34 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:18:34 --> Form Validation Class Initialized
INFO - 2023-11-02 11:18:34 --> Upload Class Initialized
INFO - 2023-11-02 11:18:34 --> Model "M_auth" initialized
INFO - 2023-11-02 11:18:34 --> Model "M_user" initialized
INFO - 2023-11-02 11:18:34 --> Model "M_produk" initialized
INFO - 2023-11-02 11:18:34 --> Controller Class Initialized
INFO - 2023-11-02 11:18:34 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:18:34 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:18:34 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:18:34 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:18:34 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:18:34 --> Model "M_bank" initialized
INFO - 2023-11-02 11:18:34 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:18:34 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
ERROR - 2023-11-02 11:18:34 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 11:18:34 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 11:18:34 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
INFO - 2023-11-02 11:18:34 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:18:34 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 11:18:34 --> Final output sent to browser
DEBUG - 2023-11-02 11:18:34 --> Total execution time: 0.1382
ERROR - 2023-11-02 11:18:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:18:46 --> Config Class Initialized
INFO - 2023-11-02 11:18:46 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:18:46 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:18:46 --> Utf8 Class Initialized
INFO - 2023-11-02 11:18:46 --> URI Class Initialized
INFO - 2023-11-02 11:18:46 --> Router Class Initialized
INFO - 2023-11-02 11:18:46 --> Output Class Initialized
INFO - 2023-11-02 11:18:46 --> Security Class Initialized
DEBUG - 2023-11-02 11:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:18:46 --> Input Class Initialized
INFO - 2023-11-02 11:18:46 --> Language Class Initialized
INFO - 2023-11-02 11:18:46 --> Loader Class Initialized
INFO - 2023-11-02 11:18:46 --> Helper loaded: url_helper
INFO - 2023-11-02 11:18:46 --> Helper loaded: form_helper
INFO - 2023-11-02 11:18:46 --> Helper loaded: file_helper
INFO - 2023-11-02 11:18:46 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:18:46 --> Form Validation Class Initialized
INFO - 2023-11-02 11:18:46 --> Upload Class Initialized
INFO - 2023-11-02 11:18:46 --> Model "M_auth" initialized
INFO - 2023-11-02 11:18:46 --> Model "M_user" initialized
INFO - 2023-11-02 11:18:46 --> Model "M_produk" initialized
INFO - 2023-11-02 11:18:46 --> Controller Class Initialized
INFO - 2023-11-02 11:18:46 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:18:46 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:18:46 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:18:46 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:18:46 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:18:46 --> Model "M_bank" initialized
INFO - 2023-11-02 11:18:46 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:18:46 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 11:18:46 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:18:46 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_bayar_sekarang.php
INFO - 2023-11-02 11:18:46 --> Final output sent to browser
DEBUG - 2023-11-02 11:18:46 --> Total execution time: 0.1173
ERROR - 2023-11-02 11:18:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:18:46 --> Config Class Initialized
INFO - 2023-11-02 11:18:46 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:18:46 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:18:46 --> Utf8 Class Initialized
INFO - 2023-11-02 11:18:46 --> URI Class Initialized
INFO - 2023-11-02 11:18:46 --> Router Class Initialized
INFO - 2023-11-02 11:18:46 --> Output Class Initialized
INFO - 2023-11-02 11:18:46 --> Security Class Initialized
DEBUG - 2023-11-02 11:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:18:46 --> Input Class Initialized
INFO - 2023-11-02 11:18:46 --> Language Class Initialized
INFO - 2023-11-02 11:18:46 --> Loader Class Initialized
INFO - 2023-11-02 11:18:46 --> Helper loaded: url_helper
INFO - 2023-11-02 11:18:46 --> Helper loaded: form_helper
INFO - 2023-11-02 11:18:46 --> Helper loaded: file_helper
INFO - 2023-11-02 11:18:46 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:18:46 --> Form Validation Class Initialized
INFO - 2023-11-02 11:18:46 --> Upload Class Initialized
INFO - 2023-11-02 11:18:46 --> Model "M_auth" initialized
INFO - 2023-11-02 11:18:46 --> Model "M_user" initialized
INFO - 2023-11-02 11:18:46 --> Model "M_produk" initialized
INFO - 2023-11-02 11:18:46 --> Controller Class Initialized
INFO - 2023-11-02 11:18:46 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/not_found.php
INFO - 2023-11-02 11:18:46 --> Final output sent to browser
DEBUG - 2023-11-02 11:18:46 --> Total execution time: 0.0724
ERROR - 2023-11-02 11:19:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:19:15 --> Config Class Initialized
INFO - 2023-11-02 11:19:15 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:19:15 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:19:15 --> Utf8 Class Initialized
INFO - 2023-11-02 11:19:15 --> URI Class Initialized
INFO - 2023-11-02 11:19:15 --> Router Class Initialized
INFO - 2023-11-02 11:19:15 --> Output Class Initialized
INFO - 2023-11-02 11:19:15 --> Security Class Initialized
DEBUG - 2023-11-02 11:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:19:15 --> Input Class Initialized
INFO - 2023-11-02 11:19:15 --> Language Class Initialized
INFO - 2023-11-02 11:19:15 --> Loader Class Initialized
INFO - 2023-11-02 11:19:15 --> Helper loaded: url_helper
INFO - 2023-11-02 11:19:15 --> Helper loaded: form_helper
INFO - 2023-11-02 11:19:15 --> Helper loaded: file_helper
INFO - 2023-11-02 11:19:15 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:19:15 --> Form Validation Class Initialized
INFO - 2023-11-02 11:19:15 --> Upload Class Initialized
INFO - 2023-11-02 11:19:15 --> Model "M_auth" initialized
INFO - 2023-11-02 11:19:15 --> Model "M_user" initialized
INFO - 2023-11-02 11:19:15 --> Model "M_produk" initialized
INFO - 2023-11-02 11:19:15 --> Controller Class Initialized
INFO - 2023-11-02 11:19:15 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:19:15 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:19:15 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:19:15 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:19:15 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:19:15 --> Model "M_bank" initialized
INFO - 2023-11-02 11:19:15 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:19:15 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 11:19:15 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:19:15 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_bayar_sekarang.php
INFO - 2023-11-02 11:19:15 --> Final output sent to browser
DEBUG - 2023-11-02 11:19:15 --> Total execution time: 0.1549
ERROR - 2023-11-02 11:19:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:19:15 --> Config Class Initialized
INFO - 2023-11-02 11:19:15 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:19:15 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:19:15 --> Utf8 Class Initialized
INFO - 2023-11-02 11:19:15 --> URI Class Initialized
INFO - 2023-11-02 11:19:15 --> Router Class Initialized
INFO - 2023-11-02 11:19:15 --> Output Class Initialized
INFO - 2023-11-02 11:19:15 --> Security Class Initialized
DEBUG - 2023-11-02 11:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:19:15 --> Input Class Initialized
INFO - 2023-11-02 11:19:15 --> Language Class Initialized
INFO - 2023-11-02 11:19:15 --> Loader Class Initialized
INFO - 2023-11-02 11:19:15 --> Helper loaded: url_helper
INFO - 2023-11-02 11:19:15 --> Helper loaded: form_helper
INFO - 2023-11-02 11:19:15 --> Helper loaded: file_helper
INFO - 2023-11-02 11:19:15 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:19:15 --> Form Validation Class Initialized
INFO - 2023-11-02 11:19:15 --> Upload Class Initialized
INFO - 2023-11-02 11:19:15 --> Model "M_auth" initialized
INFO - 2023-11-02 11:19:15 --> Model "M_user" initialized
INFO - 2023-11-02 11:19:15 --> Model "M_produk" initialized
INFO - 2023-11-02 11:19:15 --> Controller Class Initialized
INFO - 2023-11-02 11:19:15 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/not_found.php
INFO - 2023-11-02 11:19:15 --> Final output sent to browser
DEBUG - 2023-11-02 11:19:15 --> Total execution time: 0.0296
ERROR - 2023-11-02 11:19:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:19:17 --> Config Class Initialized
INFO - 2023-11-02 11:19:17 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:19:17 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:19:17 --> Utf8 Class Initialized
INFO - 2023-11-02 11:19:17 --> URI Class Initialized
INFO - 2023-11-02 11:19:17 --> Router Class Initialized
INFO - 2023-11-02 11:19:17 --> Output Class Initialized
INFO - 2023-11-02 11:19:17 --> Security Class Initialized
DEBUG - 2023-11-02 11:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:19:17 --> Input Class Initialized
INFO - 2023-11-02 11:19:17 --> Language Class Initialized
INFO - 2023-11-02 11:19:17 --> Loader Class Initialized
INFO - 2023-11-02 11:19:17 --> Helper loaded: url_helper
INFO - 2023-11-02 11:19:17 --> Helper loaded: form_helper
INFO - 2023-11-02 11:19:17 --> Helper loaded: file_helper
INFO - 2023-11-02 11:19:17 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:19:17 --> Form Validation Class Initialized
INFO - 2023-11-02 11:19:17 --> Upload Class Initialized
INFO - 2023-11-02 11:19:17 --> Model "M_auth" initialized
INFO - 2023-11-02 11:19:17 --> Model "M_user" initialized
INFO - 2023-11-02 11:19:17 --> Model "M_produk" initialized
INFO - 2023-11-02 11:19:17 --> Controller Class Initialized
INFO - 2023-11-02 11:19:17 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:19:17 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:19:17 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:19:17 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:19:17 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:19:17 --> Model "M_bank" initialized
INFO - 2023-11-02 11:19:17 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:19:17 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
ERROR - 2023-11-02 11:19:17 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 11:19:17 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 11:19:17 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
INFO - 2023-11-02 11:19:17 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:19:17 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 11:19:17 --> Final output sent to browser
DEBUG - 2023-11-02 11:19:17 --> Total execution time: 0.0583
ERROR - 2023-11-02 11:19:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:19:27 --> Config Class Initialized
INFO - 2023-11-02 11:19:27 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:19:27 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:19:27 --> Utf8 Class Initialized
INFO - 2023-11-02 11:19:27 --> URI Class Initialized
INFO - 2023-11-02 11:19:27 --> Router Class Initialized
INFO - 2023-11-02 11:19:27 --> Output Class Initialized
INFO - 2023-11-02 11:19:27 --> Security Class Initialized
DEBUG - 2023-11-02 11:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:19:27 --> Input Class Initialized
INFO - 2023-11-02 11:19:27 --> Language Class Initialized
INFO - 2023-11-02 11:19:27 --> Loader Class Initialized
INFO - 2023-11-02 11:19:27 --> Helper loaded: url_helper
INFO - 2023-11-02 11:19:27 --> Helper loaded: form_helper
INFO - 2023-11-02 11:19:27 --> Helper loaded: file_helper
INFO - 2023-11-02 11:19:27 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:19:27 --> Form Validation Class Initialized
INFO - 2023-11-02 11:19:27 --> Upload Class Initialized
INFO - 2023-11-02 11:19:27 --> Model "M_auth" initialized
INFO - 2023-11-02 11:19:27 --> Model "M_user" initialized
INFO - 2023-11-02 11:19:27 --> Model "M_produk" initialized
INFO - 2023-11-02 11:19:27 --> Controller Class Initialized
INFO - 2023-11-02 11:19:27 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:19:27 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:19:27 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:19:27 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:19:27 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:19:27 --> Model "M_bank" initialized
INFO - 2023-11-02 11:19:27 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:19:27 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
ERROR - 2023-11-02 11:19:27 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 11:19:27 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 11:19:27 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
INFO - 2023-11-02 11:19:27 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:19:27 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 11:19:27 --> Final output sent to browser
DEBUG - 2023-11-02 11:19:27 --> Total execution time: 0.1089
ERROR - 2023-11-02 11:19:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:19:28 --> Config Class Initialized
INFO - 2023-11-02 11:19:28 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:19:28 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:19:28 --> Utf8 Class Initialized
INFO - 2023-11-02 11:19:28 --> URI Class Initialized
INFO - 2023-11-02 11:19:28 --> Router Class Initialized
INFO - 2023-11-02 11:19:28 --> Output Class Initialized
INFO - 2023-11-02 11:19:28 --> Security Class Initialized
DEBUG - 2023-11-02 11:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:19:28 --> Input Class Initialized
INFO - 2023-11-02 11:19:28 --> Language Class Initialized
INFO - 2023-11-02 11:19:28 --> Loader Class Initialized
INFO - 2023-11-02 11:19:28 --> Helper loaded: url_helper
INFO - 2023-11-02 11:19:28 --> Helper loaded: form_helper
INFO - 2023-11-02 11:19:28 --> Helper loaded: file_helper
INFO - 2023-11-02 11:19:28 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:19:28 --> Form Validation Class Initialized
INFO - 2023-11-02 11:19:28 --> Upload Class Initialized
INFO - 2023-11-02 11:19:28 --> Model "M_auth" initialized
INFO - 2023-11-02 11:19:28 --> Model "M_user" initialized
INFO - 2023-11-02 11:19:28 --> Model "M_produk" initialized
INFO - 2023-11-02 11:19:28 --> Controller Class Initialized
INFO - 2023-11-02 11:19:28 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:19:28 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:19:28 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:19:28 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:19:28 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:19:28 --> Model "M_bank" initialized
INFO - 2023-11-02 11:19:28 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:19:28 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 11:19:28 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:19:28 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_bayar_sekarang.php
INFO - 2023-11-02 11:19:28 --> Final output sent to browser
DEBUG - 2023-11-02 11:19:28 --> Total execution time: 0.0504
ERROR - 2023-11-02 11:19:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:19:28 --> Config Class Initialized
INFO - 2023-11-02 11:19:28 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:19:28 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:19:28 --> Utf8 Class Initialized
INFO - 2023-11-02 11:19:28 --> URI Class Initialized
INFO - 2023-11-02 11:19:28 --> Router Class Initialized
INFO - 2023-11-02 11:19:28 --> Output Class Initialized
INFO - 2023-11-02 11:19:28 --> Security Class Initialized
DEBUG - 2023-11-02 11:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:19:28 --> Input Class Initialized
INFO - 2023-11-02 11:19:28 --> Language Class Initialized
INFO - 2023-11-02 11:19:28 --> Loader Class Initialized
INFO - 2023-11-02 11:19:28 --> Helper loaded: url_helper
INFO - 2023-11-02 11:19:28 --> Helper loaded: form_helper
INFO - 2023-11-02 11:19:28 --> Helper loaded: file_helper
INFO - 2023-11-02 11:19:29 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:19:29 --> Form Validation Class Initialized
INFO - 2023-11-02 11:19:29 --> Upload Class Initialized
INFO - 2023-11-02 11:19:29 --> Model "M_auth" initialized
INFO - 2023-11-02 11:19:29 --> Model "M_user" initialized
INFO - 2023-11-02 11:19:29 --> Model "M_produk" initialized
INFO - 2023-11-02 11:19:29 --> Controller Class Initialized
INFO - 2023-11-02 11:19:29 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/not_found.php
INFO - 2023-11-02 11:19:29 --> Final output sent to browser
DEBUG - 2023-11-02 11:19:29 --> Total execution time: 0.0625
ERROR - 2023-11-02 11:19:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:19:30 --> Config Class Initialized
INFO - 2023-11-02 11:19:30 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:19:30 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:19:30 --> Utf8 Class Initialized
INFO - 2023-11-02 11:19:30 --> URI Class Initialized
INFO - 2023-11-02 11:19:30 --> Router Class Initialized
INFO - 2023-11-02 11:19:30 --> Output Class Initialized
INFO - 2023-11-02 11:19:30 --> Security Class Initialized
DEBUG - 2023-11-02 11:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:19:30 --> Input Class Initialized
INFO - 2023-11-02 11:19:30 --> Language Class Initialized
INFO - 2023-11-02 11:19:30 --> Loader Class Initialized
INFO - 2023-11-02 11:19:30 --> Helper loaded: url_helper
INFO - 2023-11-02 11:19:30 --> Helper loaded: form_helper
INFO - 2023-11-02 11:19:30 --> Helper loaded: file_helper
INFO - 2023-11-02 11:19:30 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:19:31 --> Form Validation Class Initialized
INFO - 2023-11-02 11:19:31 --> Upload Class Initialized
INFO - 2023-11-02 11:19:31 --> Model "M_auth" initialized
INFO - 2023-11-02 11:19:31 --> Model "M_user" initialized
INFO - 2023-11-02 11:19:31 --> Model "M_produk" initialized
INFO - 2023-11-02 11:19:31 --> Controller Class Initialized
INFO - 2023-11-02 11:19:31 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:19:31 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:19:31 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:19:31 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:19:31 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:19:31 --> Model "M_bank" initialized
INFO - 2023-11-02 11:19:31 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:19:31 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
ERROR - 2023-11-02 11:19:31 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 11:19:31 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 11:19:31 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
INFO - 2023-11-02 11:19:31 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:19:31 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 11:19:31 --> Final output sent to browser
DEBUG - 2023-11-02 11:19:31 --> Total execution time: 0.1057
ERROR - 2023-11-02 11:19:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:19:34 --> Config Class Initialized
INFO - 2023-11-02 11:19:34 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:19:34 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:19:34 --> Utf8 Class Initialized
INFO - 2023-11-02 11:19:34 --> URI Class Initialized
INFO - 2023-11-02 11:19:34 --> Router Class Initialized
INFO - 2023-11-02 11:19:34 --> Output Class Initialized
INFO - 2023-11-02 11:19:34 --> Security Class Initialized
DEBUG - 2023-11-02 11:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:19:34 --> Input Class Initialized
INFO - 2023-11-02 11:19:34 --> Language Class Initialized
INFO - 2023-11-02 11:19:34 --> Loader Class Initialized
INFO - 2023-11-02 11:19:34 --> Helper loaded: url_helper
INFO - 2023-11-02 11:19:34 --> Helper loaded: form_helper
INFO - 2023-11-02 11:19:34 --> Helper loaded: file_helper
INFO - 2023-11-02 11:19:34 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:19:34 --> Form Validation Class Initialized
INFO - 2023-11-02 11:19:34 --> Upload Class Initialized
INFO - 2023-11-02 11:19:34 --> Model "M_auth" initialized
INFO - 2023-11-02 11:19:34 --> Model "M_user" initialized
INFO - 2023-11-02 11:19:34 --> Model "M_produk" initialized
INFO - 2023-11-02 11:19:34 --> Controller Class Initialized
INFO - 2023-11-02 11:19:34 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:19:34 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:19:34 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:19:34 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:19:34 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:19:34 --> Model "M_bank" initialized
INFO - 2023-11-02 11:19:34 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:19:34 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
ERROR - 2023-11-02 11:19:34 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 11:19:34 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 11:19:34 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
INFO - 2023-11-02 11:19:34 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:19:34 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 11:19:34 --> Final output sent to browser
DEBUG - 2023-11-02 11:19:34 --> Total execution time: 0.1150
ERROR - 2023-11-02 11:19:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:19:38 --> Config Class Initialized
INFO - 2023-11-02 11:19:38 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:19:38 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:19:38 --> Utf8 Class Initialized
INFO - 2023-11-02 11:19:38 --> URI Class Initialized
INFO - 2023-11-02 11:19:38 --> Router Class Initialized
INFO - 2023-11-02 11:19:38 --> Output Class Initialized
INFO - 2023-11-02 11:19:38 --> Security Class Initialized
DEBUG - 2023-11-02 11:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:19:38 --> Input Class Initialized
INFO - 2023-11-02 11:19:38 --> Language Class Initialized
INFO - 2023-11-02 11:19:38 --> Loader Class Initialized
INFO - 2023-11-02 11:19:38 --> Helper loaded: url_helper
INFO - 2023-11-02 11:19:38 --> Helper loaded: form_helper
INFO - 2023-11-02 11:19:38 --> Helper loaded: file_helper
INFO - 2023-11-02 11:19:38 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:19:38 --> Form Validation Class Initialized
INFO - 2023-11-02 11:19:38 --> Upload Class Initialized
INFO - 2023-11-02 11:19:38 --> Model "M_auth" initialized
INFO - 2023-11-02 11:19:38 --> Model "M_user" initialized
INFO - 2023-11-02 11:19:38 --> Model "M_produk" initialized
INFO - 2023-11-02 11:19:38 --> Controller Class Initialized
INFO - 2023-11-02 11:19:38 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:19:38 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:19:38 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:19:38 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:19:38 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:19:38 --> Model "M_bank" initialized
INFO - 2023-11-02 11:19:38 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:19:38 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
ERROR - 2023-11-02 11:19:38 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 11:19:38 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 11:19:38 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
INFO - 2023-11-02 11:19:38 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:19:38 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 11:19:38 --> Final output sent to browser
DEBUG - 2023-11-02 11:19:38 --> Total execution time: 0.1189
ERROR - 2023-11-02 11:19:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:19:42 --> Config Class Initialized
INFO - 2023-11-02 11:19:42 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:19:42 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:19:42 --> Utf8 Class Initialized
INFO - 2023-11-02 11:19:42 --> URI Class Initialized
DEBUG - 2023-11-02 11:19:42 --> No URI present. Default controller set.
INFO - 2023-11-02 11:19:42 --> Router Class Initialized
INFO - 2023-11-02 11:19:42 --> Output Class Initialized
INFO - 2023-11-02 11:19:42 --> Security Class Initialized
DEBUG - 2023-11-02 11:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:19:42 --> Input Class Initialized
INFO - 2023-11-02 11:19:42 --> Language Class Initialized
INFO - 2023-11-02 11:19:42 --> Loader Class Initialized
INFO - 2023-11-02 11:19:42 --> Helper loaded: url_helper
INFO - 2023-11-02 11:19:42 --> Helper loaded: form_helper
INFO - 2023-11-02 11:19:42 --> Helper loaded: file_helper
INFO - 2023-11-02 11:19:42 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:19:42 --> Form Validation Class Initialized
INFO - 2023-11-02 11:19:42 --> Upload Class Initialized
INFO - 2023-11-02 11:19:42 --> Model "M_auth" initialized
INFO - 2023-11-02 11:19:42 --> Model "M_user" initialized
INFO - 2023-11-02 11:19:42 --> Model "M_produk" initialized
INFO - 2023-11-02 11:19:42 --> Controller Class Initialized
INFO - 2023-11-02 11:19:42 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:19:42 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:19:42 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:19:42 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:19:42 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:19:42 --> Model "M_bank" initialized
INFO - 2023-11-02 11:19:42 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:19:42 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 11:19:42 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:19:42 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/index.php
INFO - 2023-11-02 11:19:42 --> Final output sent to browser
DEBUG - 2023-11-02 11:19:42 --> Total execution time: 0.1618
ERROR - 2023-11-02 11:19:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:19:45 --> Config Class Initialized
INFO - 2023-11-02 11:19:45 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:19:45 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:19:45 --> Utf8 Class Initialized
INFO - 2023-11-02 11:19:45 --> URI Class Initialized
DEBUG - 2023-11-02 11:19:45 --> No URI present. Default controller set.
INFO - 2023-11-02 11:19:45 --> Router Class Initialized
INFO - 2023-11-02 11:19:45 --> Output Class Initialized
INFO - 2023-11-02 11:19:45 --> Security Class Initialized
DEBUG - 2023-11-02 11:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:19:45 --> Input Class Initialized
INFO - 2023-11-02 11:19:45 --> Language Class Initialized
INFO - 2023-11-02 11:19:45 --> Loader Class Initialized
INFO - 2023-11-02 11:19:45 --> Helper loaded: url_helper
INFO - 2023-11-02 11:19:45 --> Helper loaded: form_helper
INFO - 2023-11-02 11:19:45 --> Helper loaded: file_helper
INFO - 2023-11-02 11:19:45 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:19:45 --> Form Validation Class Initialized
INFO - 2023-11-02 11:19:45 --> Upload Class Initialized
INFO - 2023-11-02 11:19:45 --> Model "M_auth" initialized
INFO - 2023-11-02 11:19:45 --> Model "M_user" initialized
INFO - 2023-11-02 11:19:45 --> Model "M_produk" initialized
INFO - 2023-11-02 11:19:45 --> Controller Class Initialized
INFO - 2023-11-02 11:19:45 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:19:45 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:19:45 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:19:45 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:19:45 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:19:45 --> Model "M_bank" initialized
INFO - 2023-11-02 11:19:45 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:19:45 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 11:19:45 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:19:45 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/index.php
INFO - 2023-11-02 11:19:45 --> Final output sent to browser
DEBUG - 2023-11-02 11:19:45 --> Total execution time: 0.0644
ERROR - 2023-11-02 11:19:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:19:47 --> Config Class Initialized
INFO - 2023-11-02 11:19:47 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:19:47 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:19:47 --> Utf8 Class Initialized
INFO - 2023-11-02 11:19:47 --> URI Class Initialized
INFO - 2023-11-02 11:19:47 --> Router Class Initialized
INFO - 2023-11-02 11:19:47 --> Output Class Initialized
INFO - 2023-11-02 11:19:47 --> Security Class Initialized
DEBUG - 2023-11-02 11:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:19:47 --> Input Class Initialized
INFO - 2023-11-02 11:19:47 --> Language Class Initialized
INFO - 2023-11-02 11:19:47 --> Loader Class Initialized
INFO - 2023-11-02 11:19:47 --> Helper loaded: url_helper
INFO - 2023-11-02 11:19:47 --> Helper loaded: form_helper
INFO - 2023-11-02 11:19:47 --> Helper loaded: file_helper
INFO - 2023-11-02 11:19:47 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:19:47 --> Form Validation Class Initialized
INFO - 2023-11-02 11:19:47 --> Upload Class Initialized
INFO - 2023-11-02 11:19:47 --> Model "M_auth" initialized
INFO - 2023-11-02 11:19:47 --> Model "M_user" initialized
INFO - 2023-11-02 11:19:47 --> Model "M_produk" initialized
INFO - 2023-11-02 11:19:47 --> Controller Class Initialized
INFO - 2023-11-02 11:19:47 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:19:47 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:19:47 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:19:47 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:19:47 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:19:47 --> Model "M_bank" initialized
INFO - 2023-11-02 11:19:47 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:19:47 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 11:19:47 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:19:47 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_produk_detail.php
INFO - 2023-11-02 11:19:47 --> Final output sent to browser
DEBUG - 2023-11-02 11:19:47 --> Total execution time: 0.0917
ERROR - 2023-11-02 11:19:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:19:47 --> Config Class Initialized
INFO - 2023-11-02 11:19:47 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:19:47 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:19:47 --> Utf8 Class Initialized
INFO - 2023-11-02 11:19:47 --> URI Class Initialized
INFO - 2023-11-02 11:19:47 --> Router Class Initialized
INFO - 2023-11-02 11:19:47 --> Output Class Initialized
INFO - 2023-11-02 11:19:47 --> Security Class Initialized
DEBUG - 2023-11-02 11:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:19:47 --> Input Class Initialized
INFO - 2023-11-02 11:19:47 --> Language Class Initialized
INFO - 2023-11-02 11:19:47 --> Loader Class Initialized
INFO - 2023-11-02 11:19:47 --> Helper loaded: url_helper
INFO - 2023-11-02 11:19:47 --> Helper loaded: form_helper
INFO - 2023-11-02 11:19:47 --> Helper loaded: file_helper
INFO - 2023-11-02 11:19:47 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:19:47 --> Form Validation Class Initialized
INFO - 2023-11-02 11:19:47 --> Upload Class Initialized
INFO - 2023-11-02 11:19:47 --> Model "M_auth" initialized
INFO - 2023-11-02 11:19:47 --> Model "M_user" initialized
INFO - 2023-11-02 11:19:47 --> Model "M_produk" initialized
INFO - 2023-11-02 11:19:47 --> Controller Class Initialized
INFO - 2023-11-02 11:19:47 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/not_found.php
INFO - 2023-11-02 11:19:47 --> Final output sent to browser
DEBUG - 2023-11-02 11:19:48 --> Total execution time: 0.0219
ERROR - 2023-11-02 11:19:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:19:54 --> Config Class Initialized
INFO - 2023-11-02 11:19:54 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:19:54 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:19:54 --> Utf8 Class Initialized
INFO - 2023-11-02 11:19:54 --> URI Class Initialized
INFO - 2023-11-02 11:19:54 --> Router Class Initialized
INFO - 2023-11-02 11:19:54 --> Output Class Initialized
INFO - 2023-11-02 11:19:54 --> Security Class Initialized
DEBUG - 2023-11-02 11:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:19:54 --> Input Class Initialized
INFO - 2023-11-02 11:19:54 --> Language Class Initialized
INFO - 2023-11-02 11:19:54 --> Loader Class Initialized
INFO - 2023-11-02 11:19:54 --> Helper loaded: url_helper
INFO - 2023-11-02 11:19:54 --> Helper loaded: form_helper
INFO - 2023-11-02 11:19:54 --> Helper loaded: file_helper
INFO - 2023-11-02 11:19:54 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:19:54 --> Form Validation Class Initialized
INFO - 2023-11-02 11:19:54 --> Upload Class Initialized
INFO - 2023-11-02 11:19:54 --> Model "M_auth" initialized
INFO - 2023-11-02 11:19:54 --> Model "M_user" initialized
INFO - 2023-11-02 11:19:54 --> Model "M_produk" initialized
INFO - 2023-11-02 11:19:54 --> Controller Class Initialized
INFO - 2023-11-02 11:19:54 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:19:54 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:19:54 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:19:54 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:19:54 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:19:54 --> Model "M_bank" initialized
INFO - 2023-11-02 11:19:54 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:19:54 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 11:19:54 --> Email Class Initialized
INFO - 2023-11-02 11:19:55 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-11-02 11:19:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:19:58 --> Config Class Initialized
INFO - 2023-11-02 11:19:58 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:19:58 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:19:58 --> Utf8 Class Initialized
INFO - 2023-11-02 11:19:58 --> URI Class Initialized
INFO - 2023-11-02 11:19:58 --> Router Class Initialized
INFO - 2023-11-02 11:19:58 --> Output Class Initialized
INFO - 2023-11-02 11:19:58 --> Security Class Initialized
DEBUG - 2023-11-02 11:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:19:58 --> Input Class Initialized
INFO - 2023-11-02 11:19:58 --> Language Class Initialized
INFO - 2023-11-02 11:19:58 --> Loader Class Initialized
INFO - 2023-11-02 11:19:58 --> Helper loaded: url_helper
INFO - 2023-11-02 11:19:58 --> Helper loaded: form_helper
INFO - 2023-11-02 11:19:58 --> Helper loaded: file_helper
INFO - 2023-11-02 11:19:58 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:19:58 --> Form Validation Class Initialized
INFO - 2023-11-02 11:19:58 --> Upload Class Initialized
INFO - 2023-11-02 11:19:58 --> Model "M_auth" initialized
INFO - 2023-11-02 11:19:58 --> Model "M_user" initialized
INFO - 2023-11-02 11:19:58 --> Model "M_produk" initialized
INFO - 2023-11-02 11:19:58 --> Controller Class Initialized
INFO - 2023-11-02 11:19:58 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:19:58 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:19:58 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:19:58 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:19:58 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:19:58 --> Model "M_bank" initialized
INFO - 2023-11-02 11:19:58 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:19:58 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
ERROR - 2023-11-02 11:19:58 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 11:19:58 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 11:19:58 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
ERROR - 2023-11-02 11:19:58 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure\application\views\front\v_booking_saya.php 256
INFO - 2023-11-02 11:19:58 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:19:58 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 11:19:58 --> Final output sent to browser
DEBUG - 2023-11-02 11:19:58 --> Total execution time: 0.0897
ERROR - 2023-11-02 11:20:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:20:12 --> Config Class Initialized
INFO - 2023-11-02 11:20:12 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:20:12 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:20:12 --> Utf8 Class Initialized
INFO - 2023-11-02 11:20:12 --> URI Class Initialized
INFO - 2023-11-02 11:20:12 --> Router Class Initialized
INFO - 2023-11-02 11:20:12 --> Output Class Initialized
INFO - 2023-11-02 11:20:12 --> Security Class Initialized
DEBUG - 2023-11-02 11:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:20:12 --> Input Class Initialized
INFO - 2023-11-02 11:20:12 --> Language Class Initialized
INFO - 2023-11-02 11:20:12 --> Loader Class Initialized
INFO - 2023-11-02 11:20:12 --> Helper loaded: url_helper
INFO - 2023-11-02 11:20:12 --> Helper loaded: form_helper
INFO - 2023-11-02 11:20:12 --> Helper loaded: file_helper
INFO - 2023-11-02 11:20:12 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:20:12 --> Form Validation Class Initialized
INFO - 2023-11-02 11:20:12 --> Upload Class Initialized
INFO - 2023-11-02 11:20:12 --> Model "M_auth" initialized
INFO - 2023-11-02 11:20:12 --> Model "M_user" initialized
INFO - 2023-11-02 11:20:12 --> Model "M_produk" initialized
INFO - 2023-11-02 11:20:12 --> Controller Class Initialized
INFO - 2023-11-02 11:20:12 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:20:12 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:20:12 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:20:12 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:20:12 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:20:12 --> Model "M_bank" initialized
INFO - 2023-11-02 11:20:12 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:20:12 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 11:20:13 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:20:13 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 11:20:13 --> Final output sent to browser
DEBUG - 2023-11-02 11:20:13 --> Total execution time: 0.4648
ERROR - 2023-11-02 11:20:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:20:24 --> Config Class Initialized
INFO - 2023-11-02 11:20:24 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:20:24 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:20:24 --> Utf8 Class Initialized
INFO - 2023-11-02 11:20:24 --> URI Class Initialized
INFO - 2023-11-02 11:20:24 --> Router Class Initialized
INFO - 2023-11-02 11:20:24 --> Output Class Initialized
INFO - 2023-11-02 11:20:24 --> Security Class Initialized
DEBUG - 2023-11-02 11:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:20:24 --> Input Class Initialized
INFO - 2023-11-02 11:20:24 --> Language Class Initialized
INFO - 2023-11-02 11:20:24 --> Loader Class Initialized
INFO - 2023-11-02 11:20:24 --> Helper loaded: url_helper
INFO - 2023-11-02 11:20:24 --> Helper loaded: form_helper
INFO - 2023-11-02 11:20:24 --> Helper loaded: file_helper
INFO - 2023-11-02 11:20:24 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:20:24 --> Form Validation Class Initialized
INFO - 2023-11-02 11:20:24 --> Upload Class Initialized
INFO - 2023-11-02 11:20:24 --> Model "M_auth" initialized
INFO - 2023-11-02 11:20:24 --> Model "M_user" initialized
INFO - 2023-11-02 11:20:24 --> Model "M_produk" initialized
INFO - 2023-11-02 11:20:24 --> Controller Class Initialized
INFO - 2023-11-02 11:20:24 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:20:24 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:20:24 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:20:24 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:20:24 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:20:24 --> Model "M_bank" initialized
INFO - 2023-11-02 11:20:24 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:20:24 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 11:20:25 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:20:25 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 11:20:25 --> Final output sent to browser
DEBUG - 2023-11-02 11:20:25 --> Total execution time: 0.4397
ERROR - 2023-11-02 11:21:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:21:33 --> Config Class Initialized
INFO - 2023-11-02 11:21:33 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:21:33 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:21:33 --> Utf8 Class Initialized
INFO - 2023-11-02 11:21:33 --> URI Class Initialized
INFO - 2023-11-02 11:21:33 --> Router Class Initialized
INFO - 2023-11-02 11:21:33 --> Output Class Initialized
INFO - 2023-11-02 11:21:33 --> Security Class Initialized
DEBUG - 2023-11-02 11:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:21:33 --> Input Class Initialized
INFO - 2023-11-02 11:21:33 --> Language Class Initialized
INFO - 2023-11-02 11:21:33 --> Loader Class Initialized
INFO - 2023-11-02 11:21:33 --> Helper loaded: url_helper
INFO - 2023-11-02 11:21:33 --> Helper loaded: form_helper
INFO - 2023-11-02 11:21:33 --> Helper loaded: file_helper
INFO - 2023-11-02 11:21:33 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:21:33 --> Form Validation Class Initialized
INFO - 2023-11-02 11:21:33 --> Upload Class Initialized
INFO - 2023-11-02 11:21:33 --> Model "M_auth" initialized
INFO - 2023-11-02 11:21:33 --> Model "M_user" initialized
INFO - 2023-11-02 11:21:33 --> Model "M_produk" initialized
INFO - 2023-11-02 11:21:33 --> Controller Class Initialized
INFO - 2023-11-02 11:21:33 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:21:33 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:21:33 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:21:33 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:21:33 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:21:33 --> Model "M_bank" initialized
INFO - 2023-11-02 11:21:33 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:21:33 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 11:21:33 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:21:33 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 11:21:33 --> Final output sent to browser
DEBUG - 2023-11-02 11:21:33 --> Total execution time: 0.3770
ERROR - 2023-11-02 11:22:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:22:55 --> Config Class Initialized
INFO - 2023-11-02 11:22:55 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:22:55 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:22:55 --> Utf8 Class Initialized
INFO - 2023-11-02 11:22:55 --> URI Class Initialized
INFO - 2023-11-02 11:22:55 --> Router Class Initialized
INFO - 2023-11-02 11:22:55 --> Output Class Initialized
INFO - 2023-11-02 11:22:55 --> Security Class Initialized
DEBUG - 2023-11-02 11:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:22:55 --> Input Class Initialized
INFO - 2023-11-02 11:22:55 --> Language Class Initialized
INFO - 2023-11-02 11:22:55 --> Loader Class Initialized
INFO - 2023-11-02 11:22:55 --> Helper loaded: url_helper
INFO - 2023-11-02 11:22:55 --> Helper loaded: form_helper
INFO - 2023-11-02 11:22:55 --> Helper loaded: file_helper
INFO - 2023-11-02 11:22:55 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:22:55 --> Form Validation Class Initialized
INFO - 2023-11-02 11:22:55 --> Upload Class Initialized
INFO - 2023-11-02 11:22:55 --> Model "M_auth" initialized
INFO - 2023-11-02 11:22:55 --> Model "M_user" initialized
INFO - 2023-11-02 11:22:55 --> Model "M_produk" initialized
INFO - 2023-11-02 11:22:55 --> Controller Class Initialized
INFO - 2023-11-02 11:22:55 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:22:55 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:22:55 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:22:55 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:22:55 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:22:55 --> Model "M_bank" initialized
INFO - 2023-11-02 11:22:55 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:22:55 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 11:22:55 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:22:55 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 11:22:55 --> Final output sent to browser
DEBUG - 2023-11-02 11:22:55 --> Total execution time: 0.3741
ERROR - 2023-11-02 11:23:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:23:07 --> Config Class Initialized
INFO - 2023-11-02 11:23:07 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:23:07 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:23:07 --> Utf8 Class Initialized
INFO - 2023-11-02 11:23:07 --> URI Class Initialized
INFO - 2023-11-02 11:23:07 --> Router Class Initialized
INFO - 2023-11-02 11:23:07 --> Output Class Initialized
INFO - 2023-11-02 11:23:07 --> Security Class Initialized
DEBUG - 2023-11-02 11:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:23:07 --> Input Class Initialized
INFO - 2023-11-02 11:23:07 --> Language Class Initialized
INFO - 2023-11-02 11:23:07 --> Loader Class Initialized
INFO - 2023-11-02 11:23:07 --> Helper loaded: url_helper
INFO - 2023-11-02 11:23:07 --> Helper loaded: form_helper
INFO - 2023-11-02 11:23:07 --> Helper loaded: file_helper
INFO - 2023-11-02 11:23:07 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:23:07 --> Form Validation Class Initialized
INFO - 2023-11-02 11:23:07 --> Upload Class Initialized
INFO - 2023-11-02 11:23:07 --> Model "M_auth" initialized
INFO - 2023-11-02 11:23:07 --> Model "M_user" initialized
INFO - 2023-11-02 11:23:07 --> Model "M_produk" initialized
INFO - 2023-11-02 11:23:07 --> Controller Class Initialized
INFO - 2023-11-02 11:23:07 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:23:07 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:23:07 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:23:07 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:23:07 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:23:07 --> Model "M_bank" initialized
INFO - 2023-11-02 11:23:07 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:23:07 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 11:23:08 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:23:08 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 11:23:08 --> Final output sent to browser
DEBUG - 2023-11-02 11:23:08 --> Total execution time: 0.3455
ERROR - 2023-11-02 11:23:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:23:15 --> Config Class Initialized
INFO - 2023-11-02 11:23:15 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:23:15 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:23:15 --> Utf8 Class Initialized
INFO - 2023-11-02 11:23:15 --> URI Class Initialized
INFO - 2023-11-02 11:23:15 --> Router Class Initialized
INFO - 2023-11-02 11:23:15 --> Output Class Initialized
INFO - 2023-11-02 11:23:15 --> Security Class Initialized
DEBUG - 2023-11-02 11:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:23:15 --> Input Class Initialized
INFO - 2023-11-02 11:23:15 --> Language Class Initialized
INFO - 2023-11-02 11:23:15 --> Loader Class Initialized
INFO - 2023-11-02 11:23:15 --> Helper loaded: url_helper
INFO - 2023-11-02 11:23:15 --> Helper loaded: form_helper
INFO - 2023-11-02 11:23:15 --> Helper loaded: file_helper
INFO - 2023-11-02 11:23:15 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:23:15 --> Form Validation Class Initialized
INFO - 2023-11-02 11:23:15 --> Upload Class Initialized
INFO - 2023-11-02 11:23:15 --> Model "M_auth" initialized
INFO - 2023-11-02 11:23:15 --> Model "M_user" initialized
INFO - 2023-11-02 11:23:15 --> Model "M_produk" initialized
INFO - 2023-11-02 11:23:15 --> Controller Class Initialized
INFO - 2023-11-02 11:23:15 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:23:15 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:23:15 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:23:15 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:23:15 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:23:15 --> Model "M_bank" initialized
INFO - 2023-11-02 11:23:15 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:23:15 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 11:23:15 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:23:15 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 11:23:15 --> Final output sent to browser
DEBUG - 2023-11-02 11:23:15 --> Total execution time: 0.4176
ERROR - 2023-11-02 11:24:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:24:03 --> Config Class Initialized
INFO - 2023-11-02 11:24:03 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:24:03 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:24:03 --> Utf8 Class Initialized
INFO - 2023-11-02 11:24:03 --> URI Class Initialized
INFO - 2023-11-02 11:24:03 --> Router Class Initialized
INFO - 2023-11-02 11:24:03 --> Output Class Initialized
INFO - 2023-11-02 11:24:03 --> Security Class Initialized
DEBUG - 2023-11-02 11:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:24:03 --> Input Class Initialized
INFO - 2023-11-02 11:24:03 --> Language Class Initialized
INFO - 2023-11-02 11:24:03 --> Loader Class Initialized
INFO - 2023-11-02 11:24:03 --> Helper loaded: url_helper
INFO - 2023-11-02 11:24:03 --> Helper loaded: form_helper
INFO - 2023-11-02 11:24:03 --> Helper loaded: file_helper
INFO - 2023-11-02 11:24:03 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:24:03 --> Form Validation Class Initialized
INFO - 2023-11-02 11:24:03 --> Upload Class Initialized
INFO - 2023-11-02 11:24:03 --> Model "M_auth" initialized
INFO - 2023-11-02 11:24:03 --> Model "M_user" initialized
INFO - 2023-11-02 11:24:03 --> Model "M_produk" initialized
INFO - 2023-11-02 11:24:03 --> Controller Class Initialized
INFO - 2023-11-02 11:24:03 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:24:03 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:24:03 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:24:03 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:24:03 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:24:03 --> Model "M_bank" initialized
INFO - 2023-11-02 11:24:03 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:24:03 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 11:24:03 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:24:03 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 11:24:03 --> Final output sent to browser
DEBUG - 2023-11-02 11:24:03 --> Total execution time: 0.4568
ERROR - 2023-11-02 11:24:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:24:07 --> Config Class Initialized
INFO - 2023-11-02 11:24:07 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:24:07 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:24:07 --> Utf8 Class Initialized
INFO - 2023-11-02 11:24:07 --> URI Class Initialized
INFO - 2023-11-02 11:24:07 --> Router Class Initialized
INFO - 2023-11-02 11:24:07 --> Output Class Initialized
INFO - 2023-11-02 11:24:07 --> Security Class Initialized
DEBUG - 2023-11-02 11:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:24:07 --> Input Class Initialized
INFO - 2023-11-02 11:24:07 --> Language Class Initialized
INFO - 2023-11-02 11:24:07 --> Loader Class Initialized
INFO - 2023-11-02 11:24:07 --> Helper loaded: url_helper
INFO - 2023-11-02 11:24:07 --> Helper loaded: form_helper
INFO - 2023-11-02 11:24:07 --> Helper loaded: file_helper
INFO - 2023-11-02 11:24:07 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:24:07 --> Form Validation Class Initialized
INFO - 2023-11-02 11:24:07 --> Upload Class Initialized
INFO - 2023-11-02 11:24:07 --> Model "M_auth" initialized
INFO - 2023-11-02 11:24:07 --> Model "M_user" initialized
INFO - 2023-11-02 11:24:07 --> Model "M_produk" initialized
INFO - 2023-11-02 11:24:07 --> Controller Class Initialized
INFO - 2023-11-02 11:24:07 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:24:07 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:24:07 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:24:07 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:24:07 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:24:07 --> Model "M_bank" initialized
INFO - 2023-11-02 11:24:07 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:24:07 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 11:24:07 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:24:07 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 11:24:07 --> Final output sent to browser
DEBUG - 2023-11-02 11:24:07 --> Total execution time: 0.4013
ERROR - 2023-11-02 11:25:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:25:26 --> Config Class Initialized
INFO - 2023-11-02 11:25:26 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:25:26 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:25:26 --> Utf8 Class Initialized
INFO - 2023-11-02 11:25:26 --> URI Class Initialized
DEBUG - 2023-11-02 11:25:26 --> No URI present. Default controller set.
INFO - 2023-11-02 11:25:26 --> Router Class Initialized
INFO - 2023-11-02 11:25:26 --> Output Class Initialized
INFO - 2023-11-02 11:25:26 --> Security Class Initialized
DEBUG - 2023-11-02 11:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:25:26 --> Input Class Initialized
INFO - 2023-11-02 11:25:26 --> Language Class Initialized
INFO - 2023-11-02 11:25:26 --> Loader Class Initialized
INFO - 2023-11-02 11:25:26 --> Helper loaded: url_helper
INFO - 2023-11-02 11:25:26 --> Helper loaded: form_helper
INFO - 2023-11-02 11:25:26 --> Helper loaded: file_helper
INFO - 2023-11-02 11:25:26 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:25:26 --> Form Validation Class Initialized
INFO - 2023-11-02 11:25:26 --> Upload Class Initialized
INFO - 2023-11-02 11:25:26 --> Model "M_auth" initialized
INFO - 2023-11-02 11:25:26 --> Model "M_user" initialized
INFO - 2023-11-02 11:25:26 --> Model "M_produk" initialized
INFO - 2023-11-02 11:25:26 --> Controller Class Initialized
INFO - 2023-11-02 11:25:26 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:25:26 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:25:26 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:25:26 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:25:26 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:25:26 --> Model "M_bank" initialized
INFO - 2023-11-02 11:25:26 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:25:26 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 11:25:26 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:25:26 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/index.php
INFO - 2023-11-02 11:25:26 --> Final output sent to browser
DEBUG - 2023-11-02 11:25:26 --> Total execution time: 0.0598
ERROR - 2023-11-02 11:25:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:25:33 --> Config Class Initialized
INFO - 2023-11-02 11:25:33 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:25:33 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:25:33 --> Utf8 Class Initialized
INFO - 2023-11-02 11:25:33 --> URI Class Initialized
DEBUG - 2023-11-02 11:25:33 --> No URI present. Default controller set.
INFO - 2023-11-02 11:25:33 --> Router Class Initialized
INFO - 2023-11-02 11:25:33 --> Output Class Initialized
INFO - 2023-11-02 11:25:33 --> Security Class Initialized
DEBUG - 2023-11-02 11:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:25:33 --> Input Class Initialized
INFO - 2023-11-02 11:25:33 --> Language Class Initialized
INFO - 2023-11-02 11:25:33 --> Loader Class Initialized
INFO - 2023-11-02 11:25:33 --> Helper loaded: url_helper
INFO - 2023-11-02 11:25:33 --> Helper loaded: form_helper
INFO - 2023-11-02 11:25:33 --> Helper loaded: file_helper
INFO - 2023-11-02 11:25:33 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:25:33 --> Form Validation Class Initialized
INFO - 2023-11-02 11:25:33 --> Upload Class Initialized
INFO - 2023-11-02 11:25:33 --> Model "M_auth" initialized
INFO - 2023-11-02 11:25:33 --> Model "M_user" initialized
INFO - 2023-11-02 11:25:33 --> Model "M_produk" initialized
INFO - 2023-11-02 11:25:33 --> Controller Class Initialized
INFO - 2023-11-02 11:25:33 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:25:33 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:25:33 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:25:33 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:25:33 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:25:33 --> Model "M_bank" initialized
INFO - 2023-11-02 11:25:33 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:25:33 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 11:25:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-11-02 11:25:33 --> Email Class Initialized
INFO - 2023-11-02 11:25:35 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-11-02 11:25:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:25:38 --> Config Class Initialized
INFO - 2023-11-02 11:25:38 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:25:38 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:25:38 --> Utf8 Class Initialized
INFO - 2023-11-02 11:25:38 --> URI Class Initialized
DEBUG - 2023-11-02 11:25:38 --> No URI present. Default controller set.
INFO - 2023-11-02 11:25:38 --> Router Class Initialized
INFO - 2023-11-02 11:25:38 --> Output Class Initialized
INFO - 2023-11-02 11:25:38 --> Security Class Initialized
DEBUG - 2023-11-02 11:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:25:38 --> Input Class Initialized
INFO - 2023-11-02 11:25:38 --> Language Class Initialized
INFO - 2023-11-02 11:25:38 --> Loader Class Initialized
INFO - 2023-11-02 11:25:38 --> Helper loaded: url_helper
INFO - 2023-11-02 11:25:38 --> Helper loaded: form_helper
INFO - 2023-11-02 11:25:38 --> Helper loaded: file_helper
INFO - 2023-11-02 11:25:38 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:25:38 --> Form Validation Class Initialized
INFO - 2023-11-02 11:25:38 --> Upload Class Initialized
INFO - 2023-11-02 11:25:38 --> Model "M_auth" initialized
INFO - 2023-11-02 11:25:38 --> Model "M_user" initialized
INFO - 2023-11-02 11:25:38 --> Model "M_produk" initialized
INFO - 2023-11-02 11:25:38 --> Controller Class Initialized
INFO - 2023-11-02 11:25:38 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:25:38 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:25:38 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:25:38 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:25:38 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:25:38 --> Model "M_bank" initialized
INFO - 2023-11-02 11:25:38 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:25:38 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 11:25:38 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:25:38 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/index.php
INFO - 2023-11-02 11:25:38 --> Final output sent to browser
DEBUG - 2023-11-02 11:25:38 --> Total execution time: 0.0930
ERROR - 2023-11-02 11:25:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:25:43 --> Config Class Initialized
INFO - 2023-11-02 11:25:43 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:25:43 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:25:43 --> Utf8 Class Initialized
INFO - 2023-11-02 11:25:43 --> URI Class Initialized
INFO - 2023-11-02 11:25:43 --> Router Class Initialized
INFO - 2023-11-02 11:25:43 --> Output Class Initialized
INFO - 2023-11-02 11:25:43 --> Security Class Initialized
DEBUG - 2023-11-02 11:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:25:43 --> Input Class Initialized
INFO - 2023-11-02 11:25:43 --> Language Class Initialized
INFO - 2023-11-02 11:25:43 --> Loader Class Initialized
INFO - 2023-11-02 11:25:43 --> Helper loaded: url_helper
INFO - 2023-11-02 11:25:43 --> Helper loaded: form_helper
INFO - 2023-11-02 11:25:43 --> Helper loaded: file_helper
INFO - 2023-11-02 11:25:43 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:25:43 --> Form Validation Class Initialized
INFO - 2023-11-02 11:25:43 --> Upload Class Initialized
INFO - 2023-11-02 11:25:43 --> Model "M_auth" initialized
INFO - 2023-11-02 11:25:43 --> Model "M_user" initialized
INFO - 2023-11-02 11:25:43 --> Model "M_produk" initialized
INFO - 2023-11-02 11:25:43 --> Controller Class Initialized
INFO - 2023-11-02 11:25:43 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:25:43 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:25:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:25:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:25:43 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:25:43 --> Model "M_bank" initialized
INFO - 2023-11-02 11:25:43 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:25:43 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 11:25:44 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:25:44 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 11:25:44 --> Final output sent to browser
DEBUG - 2023-11-02 11:25:44 --> Total execution time: 0.3820
ERROR - 2023-11-02 11:26:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:26:28 --> Config Class Initialized
INFO - 2023-11-02 11:26:28 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:26:28 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:26:28 --> Utf8 Class Initialized
INFO - 2023-11-02 11:26:28 --> URI Class Initialized
INFO - 2023-11-02 11:26:28 --> Router Class Initialized
INFO - 2023-11-02 11:26:28 --> Output Class Initialized
INFO - 2023-11-02 11:26:29 --> Security Class Initialized
DEBUG - 2023-11-02 11:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:26:29 --> Input Class Initialized
INFO - 2023-11-02 11:26:29 --> Language Class Initialized
INFO - 2023-11-02 11:26:29 --> Loader Class Initialized
INFO - 2023-11-02 11:26:29 --> Helper loaded: url_helper
INFO - 2023-11-02 11:26:29 --> Helper loaded: form_helper
INFO - 2023-11-02 11:26:29 --> Helper loaded: file_helper
INFO - 2023-11-02 11:26:29 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:26:29 --> Form Validation Class Initialized
INFO - 2023-11-02 11:26:29 --> Upload Class Initialized
INFO - 2023-11-02 11:26:29 --> Model "M_auth" initialized
INFO - 2023-11-02 11:26:29 --> Model "M_user" initialized
INFO - 2023-11-02 11:26:29 --> Model "M_produk" initialized
INFO - 2023-11-02 11:26:29 --> Controller Class Initialized
INFO - 2023-11-02 11:26:29 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:26:29 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:26:29 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:26:29 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:26:29 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:26:29 --> Model "M_bank" initialized
INFO - 2023-11-02 11:26:29 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:26:29 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 11:26:29 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:26:29 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-11-02 11:26:29 --> Final output sent to browser
DEBUG - 2023-11-02 11:26:29 --> Total execution time: 0.3714
ERROR - 2023-11-02 11:26:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:26:44 --> Config Class Initialized
INFO - 2023-11-02 11:26:44 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:26:44 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:26:44 --> Utf8 Class Initialized
INFO - 2023-11-02 11:26:44 --> URI Class Initialized
INFO - 2023-11-02 11:26:44 --> Router Class Initialized
INFO - 2023-11-02 11:26:44 --> Output Class Initialized
INFO - 2023-11-02 11:26:44 --> Security Class Initialized
DEBUG - 2023-11-02 11:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:26:44 --> Input Class Initialized
INFO - 2023-11-02 11:26:44 --> Language Class Initialized
INFO - 2023-11-02 11:26:44 --> Loader Class Initialized
INFO - 2023-11-02 11:26:44 --> Helper loaded: url_helper
INFO - 2023-11-02 11:26:44 --> Helper loaded: form_helper
INFO - 2023-11-02 11:26:44 --> Helper loaded: file_helper
INFO - 2023-11-02 11:26:44 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:26:44 --> Form Validation Class Initialized
INFO - 2023-11-02 11:26:44 --> Upload Class Initialized
INFO - 2023-11-02 11:26:44 --> Model "M_auth" initialized
INFO - 2023-11-02 11:26:44 --> Model "M_user" initialized
INFO - 2023-11-02 11:26:44 --> Model "M_produk" initialized
INFO - 2023-11-02 11:26:44 --> Controller Class Initialized
INFO - 2023-11-02 11:26:44 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:26:44 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:26:44 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:26:44 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:26:44 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:26:44 --> Model "M_bank" initialized
INFO - 2023-11-02 11:26:44 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:26:44 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
ERROR - 2023-11-02 11:26:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:26:44 --> Config Class Initialized
INFO - 2023-11-02 11:26:44 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:26:44 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:26:44 --> Utf8 Class Initialized
INFO - 2023-11-02 11:26:44 --> URI Class Initialized
DEBUG - 2023-11-02 11:26:44 --> No URI present. Default controller set.
INFO - 2023-11-02 11:26:44 --> Router Class Initialized
INFO - 2023-11-02 11:26:44 --> Output Class Initialized
INFO - 2023-11-02 11:26:44 --> Security Class Initialized
DEBUG - 2023-11-02 11:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:26:44 --> Input Class Initialized
INFO - 2023-11-02 11:26:44 --> Language Class Initialized
INFO - 2023-11-02 11:26:44 --> Loader Class Initialized
INFO - 2023-11-02 11:26:44 --> Helper loaded: url_helper
INFO - 2023-11-02 11:26:44 --> Helper loaded: form_helper
INFO - 2023-11-02 11:26:44 --> Helper loaded: file_helper
INFO - 2023-11-02 11:26:44 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:26:44 --> Form Validation Class Initialized
INFO - 2023-11-02 11:26:44 --> Upload Class Initialized
INFO - 2023-11-02 11:26:44 --> Model "M_auth" initialized
INFO - 2023-11-02 11:26:44 --> Model "M_user" initialized
INFO - 2023-11-02 11:26:44 --> Model "M_produk" initialized
INFO - 2023-11-02 11:26:44 --> Controller Class Initialized
INFO - 2023-11-02 11:26:44 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:26:44 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:26:44 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:26:44 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:26:44 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:26:44 --> Model "M_bank" initialized
INFO - 2023-11-02 11:26:44 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:26:44 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 11:26:44 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:26:44 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/index.php
INFO - 2023-11-02 11:26:44 --> Final output sent to browser
DEBUG - 2023-11-02 11:26:44 --> Total execution time: 0.0556
ERROR - 2023-11-02 11:26:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:26:46 --> Config Class Initialized
INFO - 2023-11-02 11:26:46 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:26:46 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:26:46 --> Utf8 Class Initialized
INFO - 2023-11-02 11:26:46 --> URI Class Initialized
INFO - 2023-11-02 11:26:46 --> Router Class Initialized
INFO - 2023-11-02 11:26:46 --> Output Class Initialized
INFO - 2023-11-02 11:26:46 --> Security Class Initialized
DEBUG - 2023-11-02 11:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:26:46 --> Input Class Initialized
INFO - 2023-11-02 11:26:46 --> Language Class Initialized
INFO - 2023-11-02 11:26:46 --> Loader Class Initialized
INFO - 2023-11-02 11:26:46 --> Helper loaded: url_helper
INFO - 2023-11-02 11:26:46 --> Helper loaded: form_helper
INFO - 2023-11-02 11:26:46 --> Helper loaded: file_helper
INFO - 2023-11-02 11:26:46 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:26:46 --> Form Validation Class Initialized
INFO - 2023-11-02 11:26:46 --> Upload Class Initialized
INFO - 2023-11-02 11:26:46 --> Model "M_auth" initialized
INFO - 2023-11-02 11:26:46 --> Model "M_user" initialized
INFO - 2023-11-02 11:26:46 --> Model "M_produk" initialized
INFO - 2023-11-02 11:26:46 --> Controller Class Initialized
INFO - 2023-11-02 11:26:46 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:26:46 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:26:46 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:26:46 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:26:46 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:26:46 --> Model "M_bank" initialized
INFO - 2023-11-02 11:26:46 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:26:46 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
ERROR - 2023-11-02 11:26:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:26:46 --> Config Class Initialized
INFO - 2023-11-02 11:26:46 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:26:46 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:26:46 --> Utf8 Class Initialized
INFO - 2023-11-02 11:26:46 --> URI Class Initialized
INFO - 2023-11-02 11:26:46 --> Router Class Initialized
INFO - 2023-11-02 11:26:46 --> Output Class Initialized
INFO - 2023-11-02 11:26:46 --> Security Class Initialized
DEBUG - 2023-11-02 11:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:26:46 --> Input Class Initialized
INFO - 2023-11-02 11:26:46 --> Language Class Initialized
INFO - 2023-11-02 11:26:46 --> Loader Class Initialized
INFO - 2023-11-02 11:26:46 --> Helper loaded: url_helper
INFO - 2023-11-02 11:26:46 --> Helper loaded: form_helper
INFO - 2023-11-02 11:26:46 --> Helper loaded: file_helper
INFO - 2023-11-02 11:26:46 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:26:46 --> Form Validation Class Initialized
INFO - 2023-11-02 11:26:46 --> Upload Class Initialized
INFO - 2023-11-02 11:26:46 --> Model "M_auth" initialized
INFO - 2023-11-02 11:26:46 --> Model "M_user" initialized
INFO - 2023-11-02 11:26:46 --> Model "M_produk" initialized
INFO - 2023-11-02 11:26:46 --> Controller Class Initialized
INFO - 2023-11-02 11:26:46 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/not_found.php
INFO - 2023-11-02 11:26:46 --> Final output sent to browser
DEBUG - 2023-11-02 11:26:46 --> Total execution time: 0.0914
ERROR - 2023-11-02 11:27:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:27:06 --> Config Class Initialized
INFO - 2023-11-02 11:27:06 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:27:06 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:27:06 --> Utf8 Class Initialized
INFO - 2023-11-02 11:27:06 --> URI Class Initialized
DEBUG - 2023-11-02 11:27:06 --> No URI present. Default controller set.
INFO - 2023-11-02 11:27:06 --> Router Class Initialized
INFO - 2023-11-02 11:27:06 --> Output Class Initialized
INFO - 2023-11-02 11:27:06 --> Security Class Initialized
DEBUG - 2023-11-02 11:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:27:06 --> Input Class Initialized
INFO - 2023-11-02 11:27:06 --> Language Class Initialized
INFO - 2023-11-02 11:27:06 --> Loader Class Initialized
INFO - 2023-11-02 11:27:06 --> Helper loaded: url_helper
INFO - 2023-11-02 11:27:06 --> Helper loaded: form_helper
INFO - 2023-11-02 11:27:06 --> Helper loaded: file_helper
INFO - 2023-11-02 11:27:06 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:27:06 --> Form Validation Class Initialized
INFO - 2023-11-02 11:27:06 --> Upload Class Initialized
INFO - 2023-11-02 11:27:06 --> Model "M_auth" initialized
INFO - 2023-11-02 11:27:06 --> Model "M_user" initialized
INFO - 2023-11-02 11:27:06 --> Model "M_produk" initialized
INFO - 2023-11-02 11:27:06 --> Controller Class Initialized
INFO - 2023-11-02 11:27:06 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:27:06 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:27:06 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:27:06 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:27:06 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:27:06 --> Model "M_bank" initialized
INFO - 2023-11-02 11:27:06 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:27:06 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 11:27:06 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:27:06 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/index.php
INFO - 2023-11-02 11:27:06 --> Final output sent to browser
DEBUG - 2023-11-02 11:27:06 --> Total execution time: 0.1131
ERROR - 2023-11-02 11:27:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:27:12 --> Config Class Initialized
INFO - 2023-11-02 11:27:12 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:27:12 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:27:12 --> Utf8 Class Initialized
INFO - 2023-11-02 11:27:12 --> URI Class Initialized
DEBUG - 2023-11-02 11:27:12 --> No URI present. Default controller set.
INFO - 2023-11-02 11:27:12 --> Router Class Initialized
INFO - 2023-11-02 11:27:12 --> Output Class Initialized
INFO - 2023-11-02 11:27:12 --> Security Class Initialized
DEBUG - 2023-11-02 11:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:27:12 --> Input Class Initialized
INFO - 2023-11-02 11:27:12 --> Language Class Initialized
INFO - 2023-11-02 11:27:12 --> Loader Class Initialized
INFO - 2023-11-02 11:27:12 --> Helper loaded: url_helper
INFO - 2023-11-02 11:27:12 --> Helper loaded: form_helper
INFO - 2023-11-02 11:27:12 --> Helper loaded: file_helper
INFO - 2023-11-02 11:27:12 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:27:12 --> Form Validation Class Initialized
INFO - 2023-11-02 11:27:12 --> Upload Class Initialized
INFO - 2023-11-02 11:27:12 --> Model "M_auth" initialized
INFO - 2023-11-02 11:27:12 --> Model "M_user" initialized
INFO - 2023-11-02 11:27:12 --> Model "M_produk" initialized
INFO - 2023-11-02 11:27:12 --> Controller Class Initialized
INFO - 2023-11-02 11:27:12 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:27:12 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:27:12 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:27:12 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:27:12 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:27:12 --> Model "M_bank" initialized
INFO - 2023-11-02 11:27:12 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:27:12 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 11:27:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-11-02 11:27:12 --> Email Class Initialized
INFO - 2023-11-02 11:27:13 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-11-02 11:27:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:27:16 --> Config Class Initialized
INFO - 2023-11-02 11:27:16 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:27:16 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:27:16 --> Utf8 Class Initialized
INFO - 2023-11-02 11:27:16 --> URI Class Initialized
DEBUG - 2023-11-02 11:27:16 --> No URI present. Default controller set.
INFO - 2023-11-02 11:27:16 --> Router Class Initialized
INFO - 2023-11-02 11:27:16 --> Output Class Initialized
INFO - 2023-11-02 11:27:16 --> Security Class Initialized
DEBUG - 2023-11-02 11:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:27:16 --> Input Class Initialized
INFO - 2023-11-02 11:27:16 --> Language Class Initialized
INFO - 2023-11-02 11:27:16 --> Loader Class Initialized
INFO - 2023-11-02 11:27:16 --> Helper loaded: url_helper
INFO - 2023-11-02 11:27:16 --> Helper loaded: form_helper
INFO - 2023-11-02 11:27:16 --> Helper loaded: file_helper
INFO - 2023-11-02 11:27:16 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:27:16 --> Form Validation Class Initialized
INFO - 2023-11-02 11:27:16 --> Upload Class Initialized
INFO - 2023-11-02 11:27:16 --> Model "M_auth" initialized
INFO - 2023-11-02 11:27:16 --> Model "M_user" initialized
INFO - 2023-11-02 11:27:16 --> Model "M_produk" initialized
INFO - 2023-11-02 11:27:16 --> Controller Class Initialized
INFO - 2023-11-02 11:27:16 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:27:16 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:27:16 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:27:16 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:27:16 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:27:16 --> Model "M_bank" initialized
INFO - 2023-11-02 11:27:16 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:27:16 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 11:27:16 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:27:16 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/index.php
INFO - 2023-11-02 11:27:16 --> Final output sent to browser
DEBUG - 2023-11-02 11:27:16 --> Total execution time: 0.0692
ERROR - 2023-11-02 11:27:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:27:19 --> Config Class Initialized
INFO - 2023-11-02 11:27:19 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:27:19 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:27:19 --> Utf8 Class Initialized
INFO - 2023-11-02 11:27:19 --> URI Class Initialized
INFO - 2023-11-02 11:27:19 --> Router Class Initialized
INFO - 2023-11-02 11:27:19 --> Output Class Initialized
INFO - 2023-11-02 11:27:19 --> Security Class Initialized
DEBUG - 2023-11-02 11:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:27:19 --> Input Class Initialized
INFO - 2023-11-02 11:27:19 --> Language Class Initialized
INFO - 2023-11-02 11:27:19 --> Loader Class Initialized
INFO - 2023-11-02 11:27:19 --> Helper loaded: url_helper
INFO - 2023-11-02 11:27:19 --> Helper loaded: form_helper
INFO - 2023-11-02 11:27:19 --> Helper loaded: file_helper
INFO - 2023-11-02 11:27:19 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:27:19 --> Form Validation Class Initialized
INFO - 2023-11-02 11:27:19 --> Upload Class Initialized
INFO - 2023-11-02 11:27:19 --> Model "M_auth" initialized
INFO - 2023-11-02 11:27:19 --> Model "M_user" initialized
INFO - 2023-11-02 11:27:19 --> Model "M_produk" initialized
INFO - 2023-11-02 11:27:19 --> Controller Class Initialized
INFO - 2023-11-02 11:27:19 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:27:19 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:27:19 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:27:19 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:27:19 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:27:19 --> Model "M_bank" initialized
INFO - 2023-11-02 11:27:19 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:27:19 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
ERROR - 2023-11-02 11:27:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:27:19 --> Config Class Initialized
INFO - 2023-11-02 11:27:19 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:27:19 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:27:19 --> Utf8 Class Initialized
INFO - 2023-11-02 11:27:19 --> URI Class Initialized
DEBUG - 2023-11-02 11:27:19 --> No URI present. Default controller set.
INFO - 2023-11-02 11:27:19 --> Router Class Initialized
INFO - 2023-11-02 11:27:19 --> Output Class Initialized
INFO - 2023-11-02 11:27:19 --> Security Class Initialized
DEBUG - 2023-11-02 11:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:27:19 --> Input Class Initialized
INFO - 2023-11-02 11:27:19 --> Language Class Initialized
INFO - 2023-11-02 11:27:19 --> Loader Class Initialized
INFO - 2023-11-02 11:27:19 --> Helper loaded: url_helper
INFO - 2023-11-02 11:27:19 --> Helper loaded: form_helper
INFO - 2023-11-02 11:27:19 --> Helper loaded: file_helper
INFO - 2023-11-02 11:27:19 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:27:19 --> Form Validation Class Initialized
INFO - 2023-11-02 11:27:19 --> Upload Class Initialized
INFO - 2023-11-02 11:27:19 --> Model "M_auth" initialized
INFO - 2023-11-02 11:27:19 --> Model "M_user" initialized
INFO - 2023-11-02 11:27:19 --> Model "M_produk" initialized
INFO - 2023-11-02 11:27:19 --> Controller Class Initialized
INFO - 2023-11-02 11:27:19 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:27:19 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:27:19 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:27:19 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:27:19 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:27:19 --> Model "M_bank" initialized
INFO - 2023-11-02 11:27:19 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:27:19 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 11:27:19 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:27:19 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/index.php
INFO - 2023-11-02 11:27:19 --> Final output sent to browser
DEBUG - 2023-11-02 11:27:19 --> Total execution time: 0.0422
ERROR - 2023-11-02 11:27:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:27:21 --> Config Class Initialized
INFO - 2023-11-02 11:27:21 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:27:21 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:27:21 --> Utf8 Class Initialized
INFO - 2023-11-02 11:27:21 --> URI Class Initialized
DEBUG - 2023-11-02 11:27:21 --> No URI present. Default controller set.
INFO - 2023-11-02 11:27:21 --> Router Class Initialized
INFO - 2023-11-02 11:27:21 --> Output Class Initialized
INFO - 2023-11-02 11:27:21 --> Security Class Initialized
DEBUG - 2023-11-02 11:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:27:21 --> Input Class Initialized
INFO - 2023-11-02 11:27:21 --> Language Class Initialized
INFO - 2023-11-02 11:27:21 --> Loader Class Initialized
INFO - 2023-11-02 11:27:21 --> Helper loaded: url_helper
INFO - 2023-11-02 11:27:21 --> Helper loaded: form_helper
INFO - 2023-11-02 11:27:21 --> Helper loaded: file_helper
INFO - 2023-11-02 11:27:21 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:27:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:27:21 --> Form Validation Class Initialized
INFO - 2023-11-02 11:27:21 --> Upload Class Initialized
INFO - 2023-11-02 11:27:21 --> Model "M_auth" initialized
INFO - 2023-11-02 11:27:21 --> Model "M_user" initialized
INFO - 2023-11-02 11:27:21 --> Model "M_produk" initialized
INFO - 2023-11-02 11:27:21 --> Controller Class Initialized
INFO - 2023-11-02 11:27:21 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:27:21 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:27:21 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:27:21 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:27:21 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:27:21 --> Model "M_bank" initialized
INFO - 2023-11-02 11:27:21 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:27:21 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 11:27:21 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:27:21 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/index.php
INFO - 2023-11-02 11:27:21 --> Final output sent to browser
DEBUG - 2023-11-02 11:27:21 --> Total execution time: 0.0665
ERROR - 2023-11-02 11:27:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:27:22 --> Config Class Initialized
INFO - 2023-11-02 11:27:22 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:27:22 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:27:22 --> Utf8 Class Initialized
INFO - 2023-11-02 11:27:22 --> URI Class Initialized
DEBUG - 2023-11-02 11:27:22 --> No URI present. Default controller set.
INFO - 2023-11-02 11:27:22 --> Router Class Initialized
INFO - 2023-11-02 11:27:22 --> Output Class Initialized
INFO - 2023-11-02 11:27:22 --> Security Class Initialized
DEBUG - 2023-11-02 11:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:27:22 --> Input Class Initialized
INFO - 2023-11-02 11:27:22 --> Language Class Initialized
INFO - 2023-11-02 11:27:22 --> Loader Class Initialized
INFO - 2023-11-02 11:27:22 --> Helper loaded: url_helper
INFO - 2023-11-02 11:27:22 --> Helper loaded: form_helper
INFO - 2023-11-02 11:27:22 --> Helper loaded: file_helper
INFO - 2023-11-02 11:27:23 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:27:23 --> Form Validation Class Initialized
INFO - 2023-11-02 11:27:23 --> Upload Class Initialized
INFO - 2023-11-02 11:27:23 --> Model "M_auth" initialized
INFO - 2023-11-02 11:27:23 --> Model "M_user" initialized
INFO - 2023-11-02 11:27:23 --> Model "M_produk" initialized
INFO - 2023-11-02 11:27:23 --> Controller Class Initialized
INFO - 2023-11-02 11:27:23 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:27:23 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:27:23 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:27:23 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:27:23 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:27:23 --> Model "M_bank" initialized
INFO - 2023-11-02 11:27:23 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:27:23 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 11:27:23 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:27:23 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/index.php
INFO - 2023-11-02 11:27:23 --> Final output sent to browser
DEBUG - 2023-11-02 11:27:23 --> Total execution time: 0.0803
ERROR - 2023-11-02 11:27:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:27:25 --> Config Class Initialized
INFO - 2023-11-02 11:27:25 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:27:25 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:27:25 --> Utf8 Class Initialized
INFO - 2023-11-02 11:27:25 --> URI Class Initialized
DEBUG - 2023-11-02 11:27:25 --> No URI present. Default controller set.
INFO - 2023-11-02 11:27:25 --> Router Class Initialized
INFO - 2023-11-02 11:27:25 --> Output Class Initialized
INFO - 2023-11-02 11:27:25 --> Security Class Initialized
DEBUG - 2023-11-02 11:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:27:25 --> Input Class Initialized
INFO - 2023-11-02 11:27:25 --> Language Class Initialized
INFO - 2023-11-02 11:27:25 --> Loader Class Initialized
INFO - 2023-11-02 11:27:25 --> Helper loaded: url_helper
INFO - 2023-11-02 11:27:25 --> Helper loaded: form_helper
INFO - 2023-11-02 11:27:25 --> Helper loaded: file_helper
INFO - 2023-11-02 11:27:25 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:27:25 --> Form Validation Class Initialized
INFO - 2023-11-02 11:27:25 --> Upload Class Initialized
INFO - 2023-11-02 11:27:25 --> Model "M_auth" initialized
INFO - 2023-11-02 11:27:25 --> Model "M_user" initialized
INFO - 2023-11-02 11:27:25 --> Model "M_produk" initialized
INFO - 2023-11-02 11:27:25 --> Controller Class Initialized
INFO - 2023-11-02 11:27:25 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:27:25 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:27:25 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:27:25 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:27:25 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:27:25 --> Model "M_bank" initialized
INFO - 2023-11-02 11:27:25 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:27:25 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 11:27:25 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:27:25 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/index.php
INFO - 2023-11-02 11:27:25 --> Final output sent to browser
DEBUG - 2023-11-02 11:27:25 --> Total execution time: 0.1034
ERROR - 2023-11-02 11:28:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:28:08 --> Config Class Initialized
INFO - 2023-11-02 11:28:08 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:28:08 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:28:08 --> Utf8 Class Initialized
INFO - 2023-11-02 11:28:08 --> URI Class Initialized
INFO - 2023-11-02 11:28:08 --> Router Class Initialized
INFO - 2023-11-02 11:28:08 --> Output Class Initialized
INFO - 2023-11-02 11:28:08 --> Security Class Initialized
DEBUG - 2023-11-02 11:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:28:08 --> Input Class Initialized
INFO - 2023-11-02 11:28:08 --> Language Class Initialized
INFO - 2023-11-02 11:28:08 --> Loader Class Initialized
INFO - 2023-11-02 11:28:08 --> Helper loaded: url_helper
INFO - 2023-11-02 11:28:08 --> Helper loaded: form_helper
INFO - 2023-11-02 11:28:08 --> Helper loaded: file_helper
INFO - 2023-11-02 11:28:08 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:28:08 --> Form Validation Class Initialized
INFO - 2023-11-02 11:28:08 --> Upload Class Initialized
INFO - 2023-11-02 11:28:08 --> Model "M_auth" initialized
INFO - 2023-11-02 11:28:08 --> Model "M_user" initialized
INFO - 2023-11-02 11:28:08 --> Model "M_produk" initialized
INFO - 2023-11-02 11:28:08 --> Controller Class Initialized
INFO - 2023-11-02 11:28:08 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:28:08 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:28:08 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:28:08 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:28:08 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:28:08 --> Model "M_bank" initialized
INFO - 2023-11-02 11:28:08 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:28:08 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 11:28:08 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:28:08 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/v_produk_detail.php
INFO - 2023-11-02 11:28:08 --> Final output sent to browser
DEBUG - 2023-11-02 11:28:08 --> Total execution time: 0.0713
ERROR - 2023-11-02 11:28:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:28:13 --> Config Class Initialized
INFO - 2023-11-02 11:28:13 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:28:13 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:28:13 --> Utf8 Class Initialized
INFO - 2023-11-02 11:28:13 --> URI Class Initialized
DEBUG - 2023-11-02 11:28:13 --> No URI present. Default controller set.
INFO - 2023-11-02 11:28:13 --> Router Class Initialized
INFO - 2023-11-02 11:28:13 --> Output Class Initialized
INFO - 2023-11-02 11:28:13 --> Security Class Initialized
DEBUG - 2023-11-02 11:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:28:13 --> Input Class Initialized
INFO - 2023-11-02 11:28:13 --> Language Class Initialized
INFO - 2023-11-02 11:28:13 --> Loader Class Initialized
INFO - 2023-11-02 11:28:13 --> Helper loaded: url_helper
INFO - 2023-11-02 11:28:13 --> Helper loaded: form_helper
INFO - 2023-11-02 11:28:13 --> Helper loaded: file_helper
INFO - 2023-11-02 11:28:13 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:28:13 --> Form Validation Class Initialized
INFO - 2023-11-02 11:28:13 --> Upload Class Initialized
INFO - 2023-11-02 11:28:13 --> Model "M_auth" initialized
INFO - 2023-11-02 11:28:13 --> Model "M_user" initialized
INFO - 2023-11-02 11:28:13 --> Model "M_produk" initialized
INFO - 2023-11-02 11:28:13 --> Controller Class Initialized
INFO - 2023-11-02 11:28:13 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:28:13 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:28:13 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:28:13 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:28:13 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:28:13 --> Model "M_bank" initialized
INFO - 2023-11-02 11:28:13 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:28:13 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 11:28:13 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:28:13 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/index.php
INFO - 2023-11-02 11:28:13 --> Final output sent to browser
DEBUG - 2023-11-02 11:28:13 --> Total execution time: 0.0763
ERROR - 2023-11-02 11:28:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-11-02 11:28:24 --> Config Class Initialized
INFO - 2023-11-02 11:28:24 --> Hooks Class Initialized
DEBUG - 2023-11-02 11:28:24 --> UTF-8 Support Enabled
INFO - 2023-11-02 11:28:24 --> Utf8 Class Initialized
INFO - 2023-11-02 11:28:24 --> URI Class Initialized
DEBUG - 2023-11-02 11:28:24 --> No URI present. Default controller set.
INFO - 2023-11-02 11:28:24 --> Router Class Initialized
INFO - 2023-11-02 11:28:24 --> Output Class Initialized
INFO - 2023-11-02 11:28:24 --> Security Class Initialized
DEBUG - 2023-11-02 11:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 11:28:24 --> Input Class Initialized
INFO - 2023-11-02 11:28:24 --> Language Class Initialized
INFO - 2023-11-02 11:28:24 --> Loader Class Initialized
INFO - 2023-11-02 11:28:24 --> Helper loaded: url_helper
INFO - 2023-11-02 11:28:24 --> Helper loaded: form_helper
INFO - 2023-11-02 11:28:24 --> Helper loaded: file_helper
INFO - 2023-11-02 11:28:24 --> Database Driver Class Initialized
DEBUG - 2023-11-02 11:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 11:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 11:28:24 --> Form Validation Class Initialized
INFO - 2023-11-02 11:28:24 --> Upload Class Initialized
INFO - 2023-11-02 11:28:24 --> Model "M_auth" initialized
INFO - 2023-11-02 11:28:24 --> Model "M_user" initialized
INFO - 2023-11-02 11:28:24 --> Model "M_produk" initialized
INFO - 2023-11-02 11:28:24 --> Controller Class Initialized
INFO - 2023-11-02 11:28:24 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 11:28:24 --> Model "M_produk" initialized
DEBUG - 2023-11-02 11:28:24 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 11:28:24 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 11:28:24 --> Model "M_transaksi" initialized
INFO - 2023-11-02 11:28:24 --> Model "M_bank" initialized
INFO - 2023-11-02 11:28:24 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 11:28:24 --> Config file loaded: C:\xampp\htdocs\semakar_adventure\application\config/midtrans.php
INFO - 2023-11-02 11:28:24 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/footer.php
INFO - 2023-11-02 11:28:24 --> File loaded: C:\xampp\htdocs\semakar_adventure\application\views\front/index.php
INFO - 2023-11-02 11:28:24 --> Final output sent to browser
DEBUG - 2023-11-02 11:28:24 --> Total execution time: 0.0257
ERROR - 2023-11-02 12:10:31 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:10:31 --> Config Class Initialized
INFO - 2023-11-02 12:10:31 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:10:31 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:10:31 --> Utf8 Class Initialized
INFO - 2023-11-02 12:10:31 --> URI Class Initialized
DEBUG - 2023-11-02 12:10:31 --> No URI present. Default controller set.
INFO - 2023-11-02 12:10:31 --> Router Class Initialized
INFO - 2023-11-02 12:10:31 --> Output Class Initialized
INFO - 2023-11-02 12:10:31 --> Security Class Initialized
DEBUG - 2023-11-02 12:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:10:31 --> Input Class Initialized
INFO - 2023-11-02 12:10:31 --> Language Class Initialized
INFO - 2023-11-02 12:10:31 --> Loader Class Initialized
INFO - 2023-11-02 12:10:31 --> Helper loaded: url_helper
INFO - 2023-11-02 12:10:31 --> Helper loaded: form_helper
INFO - 2023-11-02 12:10:31 --> Helper loaded: file_helper
INFO - 2023-11-02 12:10:31 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:10:31 --> Form Validation Class Initialized
INFO - 2023-11-02 12:10:31 --> Upload Class Initialized
INFO - 2023-11-02 12:10:31 --> Model "M_auth" initialized
INFO - 2023-11-02 12:10:31 --> Model "M_user" initialized
INFO - 2023-11-02 12:10:31 --> Model "M_produk" initialized
INFO - 2023-11-02 12:10:31 --> Controller Class Initialized
INFO - 2023-11-02 12:10:31 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:10:31 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:10:31 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:10:31 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:10:31 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:10:31 --> Model "M_bank" initialized
INFO - 2023-11-02 12:10:31 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:10:31 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 12:10:31 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 12:10:31 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 12:10:31 --> Final output sent to browser
DEBUG - 2023-11-02 12:10:31 --> Total execution time: 0.0358
ERROR - 2023-11-02 12:10:32 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:10:32 --> Config Class Initialized
INFO - 2023-11-02 12:10:32 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:10:32 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:10:32 --> Utf8 Class Initialized
INFO - 2023-11-02 12:10:32 --> URI Class Initialized
INFO - 2023-11-02 12:10:32 --> Router Class Initialized
INFO - 2023-11-02 12:10:32 --> Output Class Initialized
INFO - 2023-11-02 12:10:32 --> Security Class Initialized
DEBUG - 2023-11-02 12:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:10:32 --> Input Class Initialized
INFO - 2023-11-02 12:10:32 --> Language Class Initialized
INFO - 2023-11-02 12:10:32 --> Loader Class Initialized
INFO - 2023-11-02 12:10:32 --> Helper loaded: url_helper
INFO - 2023-11-02 12:10:32 --> Helper loaded: form_helper
INFO - 2023-11-02 12:10:32 --> Helper loaded: file_helper
INFO - 2023-11-02 12:10:32 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2023-11-02 12:10:32 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:10:32 --> Config Class Initialized
INFO - 2023-11-02 12:10:32 --> Hooks Class Initialized
INFO - 2023-11-02 12:10:32 --> Form Validation Class Initialized
INFO - 2023-11-02 12:10:32 --> Upload Class Initialized
DEBUG - 2023-11-02 12:10:32 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:10:32 --> Utf8 Class Initialized
INFO - 2023-11-02 12:10:32 --> Model "M_auth" initialized
INFO - 2023-11-02 12:10:32 --> URI Class Initialized
INFO - 2023-11-02 12:10:32 --> Model "M_user" initialized
INFO - 2023-11-02 12:10:32 --> Model "M_produk" initialized
INFO - 2023-11-02 12:10:32 --> Controller Class Initialized
INFO - 2023-11-02 12:10:32 --> Router Class Initialized
INFO - 2023-11-02 12:10:32 --> Output Class Initialized
INFO - 2023-11-02 12:10:32 --> Security Class Initialized
DEBUG - 2023-11-02 12:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:10:32 --> Input Class Initialized
INFO - 2023-11-02 12:10:32 --> Language Class Initialized
INFO - 2023-11-02 12:10:32 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 12:10:32 --> Final output sent to browser
INFO - 2023-11-02 12:10:32 --> Loader Class Initialized
DEBUG - 2023-11-02 12:10:32 --> Total execution time: 0.0029
INFO - 2023-11-02 12:10:32 --> Helper loaded: url_helper
INFO - 2023-11-02 12:10:32 --> Helper loaded: form_helper
INFO - 2023-11-02 12:10:32 --> Helper loaded: file_helper
INFO - 2023-11-02 12:10:32 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:10:32 --> Form Validation Class Initialized
INFO - 2023-11-02 12:10:32 --> Upload Class Initialized
INFO - 2023-11-02 12:10:32 --> Model "M_auth" initialized
INFO - 2023-11-02 12:10:32 --> Model "M_user" initialized
INFO - 2023-11-02 12:10:32 --> Model "M_produk" initialized
INFO - 2023-11-02 12:10:32 --> Controller Class Initialized
INFO - 2023-11-02 12:10:32 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 12:10:32 --> Final output sent to browser
DEBUG - 2023-11-02 12:10:32 --> Total execution time: 0.0031
ERROR - 2023-11-02 12:10:34 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:10:34 --> Config Class Initialized
INFO - 2023-11-02 12:10:34 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:10:34 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:10:34 --> Utf8 Class Initialized
INFO - 2023-11-02 12:10:34 --> URI Class Initialized
INFO - 2023-11-02 12:10:34 --> Router Class Initialized
INFO - 2023-11-02 12:10:34 --> Output Class Initialized
INFO - 2023-11-02 12:10:34 --> Security Class Initialized
DEBUG - 2023-11-02 12:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:10:34 --> Input Class Initialized
INFO - 2023-11-02 12:10:34 --> Language Class Initialized
INFO - 2023-11-02 12:10:34 --> Loader Class Initialized
INFO - 2023-11-02 12:10:34 --> Helper loaded: url_helper
INFO - 2023-11-02 12:10:34 --> Helper loaded: form_helper
INFO - 2023-11-02 12:10:34 --> Helper loaded: file_helper
INFO - 2023-11-02 12:10:34 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:10:34 --> Form Validation Class Initialized
INFO - 2023-11-02 12:10:34 --> Upload Class Initialized
INFO - 2023-11-02 12:10:34 --> Model "M_auth" initialized
INFO - 2023-11-02 12:10:34 --> Model "M_user" initialized
INFO - 2023-11-02 12:10:34 --> Model "M_produk" initialized
INFO - 2023-11-02 12:10:34 --> Controller Class Initialized
INFO - 2023-11-02 12:10:34 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:10:34 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:10:34 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:10:34 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:10:34 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:10:34 --> Model "M_bank" initialized
INFO - 2023-11-02 12:10:34 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:10:34 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 12:10:34 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 12:10:34 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 12:10:34 --> Final output sent to browser
DEBUG - 2023-11-02 12:10:34 --> Total execution time: 0.2153
ERROR - 2023-11-02 12:13:25 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:13:25 --> Config Class Initialized
INFO - 2023-11-02 12:13:25 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:13:25 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:13:25 --> Utf8 Class Initialized
INFO - 2023-11-02 12:13:25 --> URI Class Initialized
INFO - 2023-11-02 12:13:25 --> Router Class Initialized
INFO - 2023-11-02 12:13:25 --> Output Class Initialized
INFO - 2023-11-02 12:13:25 --> Security Class Initialized
DEBUG - 2023-11-02 12:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:13:25 --> Input Class Initialized
INFO - 2023-11-02 12:13:25 --> Language Class Initialized
INFO - 2023-11-02 12:13:25 --> Loader Class Initialized
INFO - 2023-11-02 12:13:25 --> Helper loaded: url_helper
INFO - 2023-11-02 12:13:25 --> Helper loaded: form_helper
INFO - 2023-11-02 12:13:25 --> Helper loaded: file_helper
INFO - 2023-11-02 12:13:25 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:13:25 --> Form Validation Class Initialized
INFO - 2023-11-02 12:13:25 --> Upload Class Initialized
INFO - 2023-11-02 12:13:25 --> Model "M_auth" initialized
INFO - 2023-11-02 12:13:25 --> Model "M_user" initialized
INFO - 2023-11-02 12:13:25 --> Model "M_produk" initialized
INFO - 2023-11-02 12:13:25 --> Controller Class Initialized
INFO - 2023-11-02 12:13:25 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:13:25 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:13:25 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:13:25 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:13:25 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:13:25 --> Model "M_bank" initialized
INFO - 2023-11-02 12:13:25 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:13:25 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 12:13:25 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 12:13:25 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 12:13:25 --> Final output sent to browser
DEBUG - 2023-11-02 12:13:25 --> Total execution time: 0.1643
ERROR - 2023-11-02 12:13:27 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:13:27 --> Config Class Initialized
INFO - 2023-11-02 12:13:27 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:13:27 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:13:27 --> Utf8 Class Initialized
INFO - 2023-11-02 12:13:27 --> URI Class Initialized
INFO - 2023-11-02 12:13:27 --> Router Class Initialized
INFO - 2023-11-02 12:13:27 --> Output Class Initialized
INFO - 2023-11-02 12:13:27 --> Security Class Initialized
DEBUG - 2023-11-02 12:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:13:27 --> Input Class Initialized
INFO - 2023-11-02 12:13:27 --> Language Class Initialized
INFO - 2023-11-02 12:13:27 --> Loader Class Initialized
INFO - 2023-11-02 12:13:27 --> Helper loaded: url_helper
INFO - 2023-11-02 12:13:27 --> Helper loaded: form_helper
INFO - 2023-11-02 12:13:27 --> Helper loaded: file_helper
INFO - 2023-11-02 12:13:27 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:13:27 --> Form Validation Class Initialized
INFO - 2023-11-02 12:13:27 --> Upload Class Initialized
INFO - 2023-11-02 12:13:27 --> Model "M_auth" initialized
INFO - 2023-11-02 12:13:27 --> Model "M_user" initialized
INFO - 2023-11-02 12:13:27 --> Model "M_produk" initialized
INFO - 2023-11-02 12:13:27 --> Controller Class Initialized
INFO - 2023-11-02 12:13:27 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:13:27 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:13:27 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:13:27 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:13:27 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:13:27 --> Model "M_bank" initialized
INFO - 2023-11-02 12:13:27 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:13:27 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
ERROR - 2023-11-02 12:13:27 --> Severity: Warning --> Undefined variable $snapToken /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_bayar_sekarang.php 198
INFO - 2023-11-02 12:13:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 12:13:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_bayar_sekarang.php
INFO - 2023-11-02 12:13:27 --> Final output sent to browser
DEBUG - 2023-11-02 12:13:27 --> Total execution time: 0.0064
ERROR - 2023-11-02 12:14:16 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:14:16 --> Config Class Initialized
INFO - 2023-11-02 12:14:16 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:14:16 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:14:16 --> Utf8 Class Initialized
INFO - 2023-11-02 12:14:16 --> URI Class Initialized
INFO - 2023-11-02 12:14:16 --> Router Class Initialized
INFO - 2023-11-02 12:14:16 --> Output Class Initialized
INFO - 2023-11-02 12:14:16 --> Security Class Initialized
DEBUG - 2023-11-02 12:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:14:16 --> Input Class Initialized
INFO - 2023-11-02 12:14:16 --> Language Class Initialized
INFO - 2023-11-02 12:14:16 --> Loader Class Initialized
INFO - 2023-11-02 12:14:16 --> Helper loaded: url_helper
INFO - 2023-11-02 12:14:16 --> Helper loaded: form_helper
INFO - 2023-11-02 12:14:16 --> Helper loaded: file_helper
INFO - 2023-11-02 12:14:16 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:14:16 --> Form Validation Class Initialized
INFO - 2023-11-02 12:14:16 --> Upload Class Initialized
INFO - 2023-11-02 12:14:16 --> Model "M_auth" initialized
INFO - 2023-11-02 12:14:16 --> Model "M_user" initialized
INFO - 2023-11-02 12:14:16 --> Model "M_produk" initialized
INFO - 2023-11-02 12:14:16 --> Controller Class Initialized
INFO - 2023-11-02 12:14:16 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:14:16 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:14:16 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:14:16 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:14:16 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:14:16 --> Model "M_bank" initialized
INFO - 2023-11-02 12:14:16 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:14:16 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
ERROR - 2023-11-02 12:14:16 --> Severity: Warning --> Undefined variable $snapToken /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php 256
INFO - 2023-11-02 12:14:16 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 12:14:16 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 12:14:16 --> Final output sent to browser
DEBUG - 2023-11-02 12:14:16 --> Total execution time: 0.0058
ERROR - 2023-11-02 12:14:19 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:14:19 --> Config Class Initialized
INFO - 2023-11-02 12:14:19 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:14:19 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:14:19 --> Utf8 Class Initialized
INFO - 2023-11-02 12:14:19 --> URI Class Initialized
INFO - 2023-11-02 12:14:19 --> Router Class Initialized
INFO - 2023-11-02 12:14:19 --> Output Class Initialized
INFO - 2023-11-02 12:14:19 --> Security Class Initialized
DEBUG - 2023-11-02 12:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:14:19 --> Input Class Initialized
INFO - 2023-11-02 12:14:19 --> Language Class Initialized
INFO - 2023-11-02 12:14:19 --> Loader Class Initialized
INFO - 2023-11-02 12:14:19 --> Helper loaded: url_helper
INFO - 2023-11-02 12:14:19 --> Helper loaded: form_helper
INFO - 2023-11-02 12:14:19 --> Helper loaded: file_helper
INFO - 2023-11-02 12:14:19 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:14:19 --> Form Validation Class Initialized
INFO - 2023-11-02 12:14:19 --> Upload Class Initialized
INFO - 2023-11-02 12:14:19 --> Model "M_auth" initialized
INFO - 2023-11-02 12:14:19 --> Model "M_user" initialized
INFO - 2023-11-02 12:14:19 --> Model "M_produk" initialized
INFO - 2023-11-02 12:14:19 --> Controller Class Initialized
INFO - 2023-11-02 12:14:19 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:14:19 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:14:19 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:14:19 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:14:19 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:14:19 --> Model "M_bank" initialized
INFO - 2023-11-02 12:14:19 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:14:19 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 12:14:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 12:14:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_bayar_sekarang.php
INFO - 2023-11-02 12:14:19 --> Final output sent to browser
DEBUG - 2023-11-02 12:14:19 --> Total execution time: 0.4147
ERROR - 2023-11-02 12:14:29 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:14:29 --> Config Class Initialized
INFO - 2023-11-02 12:14:29 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:14:29 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:14:29 --> Utf8 Class Initialized
INFO - 2023-11-02 12:14:29 --> URI Class Initialized
INFO - 2023-11-02 12:14:29 --> Router Class Initialized
INFO - 2023-11-02 12:14:29 --> Output Class Initialized
INFO - 2023-11-02 12:14:29 --> Security Class Initialized
DEBUG - 2023-11-02 12:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:14:29 --> Input Class Initialized
INFO - 2023-11-02 12:14:29 --> Language Class Initialized
INFO - 2023-11-02 12:14:29 --> Loader Class Initialized
INFO - 2023-11-02 12:14:29 --> Helper loaded: url_helper
INFO - 2023-11-02 12:14:29 --> Helper loaded: form_helper
INFO - 2023-11-02 12:14:29 --> Helper loaded: file_helper
INFO - 2023-11-02 12:14:29 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:14:29 --> Form Validation Class Initialized
INFO - 2023-11-02 12:14:29 --> Upload Class Initialized
INFO - 2023-11-02 12:14:29 --> Model "M_auth" initialized
INFO - 2023-11-02 12:14:29 --> Model "M_user" initialized
INFO - 2023-11-02 12:14:29 --> Model "M_produk" initialized
INFO - 2023-11-02 12:14:29 --> Controller Class Initialized
INFO - 2023-11-02 12:14:29 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:14:29 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:14:29 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:14:29 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:14:29 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:14:29 --> Model "M_bank" initialized
INFO - 2023-11-02 12:14:29 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:14:29 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
ERROR - 2023-11-02 12:14:29 --> Severity: Warning --> Undefined variable $snapToken /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php 256
INFO - 2023-11-02 12:14:29 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 12:14:29 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 12:14:29 --> Final output sent to browser
DEBUG - 2023-11-02 12:14:29 --> Total execution time: 0.0055
ERROR - 2023-11-02 12:16:30 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:16:30 --> Config Class Initialized
INFO - 2023-11-02 12:16:30 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:16:30 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:16:30 --> Utf8 Class Initialized
INFO - 2023-11-02 12:16:30 --> URI Class Initialized
INFO - 2023-11-02 12:16:30 --> Router Class Initialized
INFO - 2023-11-02 12:16:30 --> Output Class Initialized
INFO - 2023-11-02 12:16:30 --> Security Class Initialized
DEBUG - 2023-11-02 12:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:16:30 --> Input Class Initialized
INFO - 2023-11-02 12:16:30 --> Language Class Initialized
INFO - 2023-11-02 12:16:30 --> Loader Class Initialized
INFO - 2023-11-02 12:16:30 --> Helper loaded: url_helper
INFO - 2023-11-02 12:16:30 --> Helper loaded: form_helper
INFO - 2023-11-02 12:16:30 --> Helper loaded: file_helper
INFO - 2023-11-02 12:16:30 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:16:30 --> Form Validation Class Initialized
INFO - 2023-11-02 12:16:30 --> Upload Class Initialized
INFO - 2023-11-02 12:16:30 --> Model "M_auth" initialized
INFO - 2023-11-02 12:16:30 --> Model "M_user" initialized
INFO - 2023-11-02 12:16:30 --> Model "M_produk" initialized
INFO - 2023-11-02 12:16:30 --> Controller Class Initialized
INFO - 2023-11-02 12:16:30 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:16:30 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:16:30 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:16:30 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:16:30 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:16:30 --> Model "M_bank" initialized
INFO - 2023-11-02 12:16:30 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:16:30 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 12:16:30 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 12:16:30 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 12:16:30 --> Final output sent to browser
DEBUG - 2023-11-02 12:16:30 --> Total execution time: 0.1884
ERROR - 2023-11-02 12:16:39 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:16:39 --> Config Class Initialized
INFO - 2023-11-02 12:16:39 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:16:39 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:16:39 --> Utf8 Class Initialized
INFO - 2023-11-02 12:16:39 --> URI Class Initialized
DEBUG - 2023-11-02 12:16:39 --> No URI present. Default controller set.
INFO - 2023-11-02 12:16:39 --> Router Class Initialized
INFO - 2023-11-02 12:16:39 --> Output Class Initialized
INFO - 2023-11-02 12:16:39 --> Security Class Initialized
DEBUG - 2023-11-02 12:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:16:39 --> Input Class Initialized
INFO - 2023-11-02 12:16:39 --> Language Class Initialized
INFO - 2023-11-02 12:16:39 --> Loader Class Initialized
INFO - 2023-11-02 12:16:39 --> Helper loaded: url_helper
INFO - 2023-11-02 12:16:39 --> Helper loaded: form_helper
INFO - 2023-11-02 12:16:39 --> Helper loaded: file_helper
INFO - 2023-11-02 12:16:39 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:16:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:16:39 --> Form Validation Class Initialized
INFO - 2023-11-02 12:16:39 --> Upload Class Initialized
INFO - 2023-11-02 12:16:39 --> Model "M_auth" initialized
INFO - 2023-11-02 12:16:39 --> Model "M_user" initialized
INFO - 2023-11-02 12:16:39 --> Model "M_produk" initialized
INFO - 2023-11-02 12:16:39 --> Controller Class Initialized
INFO - 2023-11-02 12:16:39 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:16:39 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:16:39 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:16:39 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:16:39 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:16:39 --> Model "M_bank" initialized
INFO - 2023-11-02 12:16:39 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:16:39 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 12:16:39 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 12:16:39 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 12:16:39 --> Final output sent to browser
DEBUG - 2023-11-02 12:16:39 --> Total execution time: 0.0038
ERROR - 2023-11-02 12:16:40 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:16:40 --> Config Class Initialized
INFO - 2023-11-02 12:16:40 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:16:40 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:16:40 --> Utf8 Class Initialized
INFO - 2023-11-02 12:16:40 --> URI Class Initialized
INFO - 2023-11-02 12:16:40 --> Router Class Initialized
INFO - 2023-11-02 12:16:40 --> Output Class Initialized
INFO - 2023-11-02 12:16:40 --> Security Class Initialized
DEBUG - 2023-11-02 12:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:16:40 --> Input Class Initialized
INFO - 2023-11-02 12:16:40 --> Language Class Initialized
INFO - 2023-11-02 12:16:40 --> Loader Class Initialized
INFO - 2023-11-02 12:16:40 --> Helper loaded: url_helper
INFO - 2023-11-02 12:16:40 --> Helper loaded: form_helper
INFO - 2023-11-02 12:16:40 --> Helper loaded: file_helper
INFO - 2023-11-02 12:16:40 --> Database Driver Class Initialized
ERROR - 2023-11-02 12:16:40 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:16:40 --> Config Class Initialized
INFO - 2023-11-02 12:16:40 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:16:40 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:16:40 --> Utf8 Class Initialized
INFO - 2023-11-02 12:16:40 --> URI Class Initialized
INFO - 2023-11-02 12:16:40 --> Router Class Initialized
INFO - 2023-11-02 12:16:40 --> Output Class Initialized
INFO - 2023-11-02 12:16:40 --> Security Class Initialized
DEBUG - 2023-11-02 12:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:16:40 --> Input Class Initialized
INFO - 2023-11-02 12:16:40 --> Language Class Initialized
INFO - 2023-11-02 12:16:40 --> Loader Class Initialized
INFO - 2023-11-02 12:16:40 --> Helper loaded: url_helper
INFO - 2023-11-02 12:16:40 --> Helper loaded: form_helper
INFO - 2023-11-02 12:16:40 --> Helper loaded: file_helper
INFO - 2023-11-02 12:16:40 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-11-02 12:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:16:40 --> Form Validation Class Initialized
INFO - 2023-11-02 12:16:40 --> Upload Class Initialized
INFO - 2023-11-02 12:16:40 --> Model "M_auth" initialized
INFO - 2023-11-02 12:16:40 --> Model "M_user" initialized
INFO - 2023-11-02 12:16:40 --> Model "M_produk" initialized
INFO - 2023-11-02 12:16:40 --> Controller Class Initialized
INFO - 2023-11-02 12:16:40 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 12:16:40 --> Final output sent to browser
DEBUG - 2023-11-02 12:16:40 --> Total execution time: 0.0059
INFO - 2023-11-02 12:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:16:40 --> Form Validation Class Initialized
INFO - 2023-11-02 12:16:40 --> Upload Class Initialized
INFO - 2023-11-02 12:16:40 --> Model "M_auth" initialized
INFO - 2023-11-02 12:16:40 --> Model "M_user" initialized
INFO - 2023-11-02 12:16:40 --> Model "M_produk" initialized
INFO - 2023-11-02 12:16:40 --> Controller Class Initialized
INFO - 2023-11-02 12:16:40 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 12:16:40 --> Final output sent to browser
DEBUG - 2023-11-02 12:16:40 --> Total execution time: 0.0038
ERROR - 2023-11-02 12:16:53 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:16:53 --> Config Class Initialized
INFO - 2023-11-02 12:16:53 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:16:53 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:16:53 --> Utf8 Class Initialized
INFO - 2023-11-02 12:16:53 --> URI Class Initialized
INFO - 2023-11-02 12:16:53 --> Router Class Initialized
INFO - 2023-11-02 12:16:53 --> Output Class Initialized
INFO - 2023-11-02 12:16:53 --> Security Class Initialized
DEBUG - 2023-11-02 12:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:16:53 --> Input Class Initialized
INFO - 2023-11-02 12:16:53 --> Language Class Initialized
INFO - 2023-11-02 12:16:53 --> Loader Class Initialized
INFO - 2023-11-02 12:16:53 --> Helper loaded: url_helper
INFO - 2023-11-02 12:16:53 --> Helper loaded: form_helper
INFO - 2023-11-02 12:16:53 --> Helper loaded: file_helper
INFO - 2023-11-02 12:16:53 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:16:53 --> Form Validation Class Initialized
INFO - 2023-11-02 12:16:53 --> Upload Class Initialized
INFO - 2023-11-02 12:16:53 --> Model "M_auth" initialized
INFO - 2023-11-02 12:16:53 --> Model "M_user" initialized
INFO - 2023-11-02 12:16:53 --> Model "M_produk" initialized
INFO - 2023-11-02 12:16:53 --> Controller Class Initialized
INFO - 2023-11-02 12:16:53 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:16:53 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:16:53 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:16:53 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:16:53 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:16:53 --> Model "M_bank" initialized
INFO - 2023-11-02 12:16:53 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:16:53 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 12:16:53 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 12:16:53 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-02 12:16:53 --> Final output sent to browser
DEBUG - 2023-11-02 12:16:53 --> Total execution time: 0.0071
ERROR - 2023-11-02 12:16:54 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:16:54 --> Config Class Initialized
INFO - 2023-11-02 12:16:54 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:16:54 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:16:54 --> Utf8 Class Initialized
INFO - 2023-11-02 12:16:54 --> URI Class Initialized
INFO - 2023-11-02 12:16:54 --> Router Class Initialized
INFO - 2023-11-02 12:16:54 --> Output Class Initialized
INFO - 2023-11-02 12:16:54 --> Security Class Initialized
DEBUG - 2023-11-02 12:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:16:54 --> Input Class Initialized
INFO - 2023-11-02 12:16:54 --> Language Class Initialized
INFO - 2023-11-02 12:16:54 --> Loader Class Initialized
INFO - 2023-11-02 12:16:54 --> Helper loaded: url_helper
INFO - 2023-11-02 12:16:54 --> Helper loaded: form_helper
INFO - 2023-11-02 12:16:54 --> Helper loaded: file_helper
INFO - 2023-11-02 12:16:54 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:16:54 --> Form Validation Class Initialized
INFO - 2023-11-02 12:16:54 --> Upload Class Initialized
INFO - 2023-11-02 12:16:54 --> Model "M_auth" initialized
INFO - 2023-11-02 12:16:54 --> Model "M_user" initialized
INFO - 2023-11-02 12:16:54 --> Model "M_produk" initialized
INFO - 2023-11-02 12:16:54 --> Controller Class Initialized
INFO - 2023-11-02 12:16:54 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 12:16:54 --> Final output sent to browser
DEBUG - 2023-11-02 12:16:54 --> Total execution time: 0.0029
ERROR - 2023-11-02 12:17:01 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:17:01 --> Config Class Initialized
INFO - 2023-11-02 12:17:01 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:17:01 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:17:01 --> Utf8 Class Initialized
INFO - 2023-11-02 12:17:01 --> URI Class Initialized
INFO - 2023-11-02 12:17:01 --> Router Class Initialized
INFO - 2023-11-02 12:17:01 --> Output Class Initialized
INFO - 2023-11-02 12:17:01 --> Security Class Initialized
DEBUG - 2023-11-02 12:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:17:01 --> Input Class Initialized
INFO - 2023-11-02 12:17:01 --> Language Class Initialized
INFO - 2023-11-02 12:17:01 --> Loader Class Initialized
INFO - 2023-11-02 12:17:01 --> Helper loaded: url_helper
INFO - 2023-11-02 12:17:01 --> Helper loaded: form_helper
INFO - 2023-11-02 12:17:01 --> Helper loaded: file_helper
INFO - 2023-11-02 12:17:01 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:17:01 --> Form Validation Class Initialized
INFO - 2023-11-02 12:17:01 --> Upload Class Initialized
INFO - 2023-11-02 12:17:01 --> Model "M_auth" initialized
INFO - 2023-11-02 12:17:01 --> Model "M_user" initialized
INFO - 2023-11-02 12:17:01 --> Model "M_produk" initialized
INFO - 2023-11-02 12:17:01 --> Controller Class Initialized
INFO - 2023-11-02 12:17:01 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:17:01 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:17:01 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:17:01 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:17:01 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:17:01 --> Model "M_bank" initialized
INFO - 2023-11-02 12:17:01 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:17:01 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 12:17:01 --> Email Class Initialized
INFO - 2023-11-02 12:17:02 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-11-02 12:17:04 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:17:04 --> Config Class Initialized
INFO - 2023-11-02 12:17:04 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:17:04 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:17:04 --> Utf8 Class Initialized
INFO - 2023-11-02 12:17:04 --> URI Class Initialized
INFO - 2023-11-02 12:17:04 --> Router Class Initialized
INFO - 2023-11-02 12:17:04 --> Output Class Initialized
INFO - 2023-11-02 12:17:04 --> Security Class Initialized
DEBUG - 2023-11-02 12:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:17:04 --> Input Class Initialized
INFO - 2023-11-02 12:17:04 --> Language Class Initialized
INFO - 2023-11-02 12:17:04 --> Loader Class Initialized
INFO - 2023-11-02 12:17:04 --> Helper loaded: url_helper
INFO - 2023-11-02 12:17:04 --> Helper loaded: form_helper
INFO - 2023-11-02 12:17:04 --> Helper loaded: file_helper
INFO - 2023-11-02 12:17:04 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:17:04 --> Form Validation Class Initialized
INFO - 2023-11-02 12:17:04 --> Upload Class Initialized
INFO - 2023-11-02 12:17:04 --> Model "M_auth" initialized
INFO - 2023-11-02 12:17:04 --> Model "M_user" initialized
INFO - 2023-11-02 12:17:04 --> Model "M_produk" initialized
INFO - 2023-11-02 12:17:04 --> Controller Class Initialized
INFO - 2023-11-02 12:17:04 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:17:04 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:17:04 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:17:04 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:17:04 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:17:04 --> Model "M_bank" initialized
INFO - 2023-11-02 12:17:04 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:17:04 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 12:17:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 12:17:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 12:17:05 --> Final output sent to browser
DEBUG - 2023-11-02 12:17:05 --> Total execution time: 0.4727
ERROR - 2023-11-02 12:17:05 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:17:05 --> Config Class Initialized
INFO - 2023-11-02 12:17:05 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:17:05 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:17:05 --> Utf8 Class Initialized
INFO - 2023-11-02 12:17:05 --> URI Class Initialized
INFO - 2023-11-02 12:17:05 --> Router Class Initialized
INFO - 2023-11-02 12:17:05 --> Output Class Initialized
INFO - 2023-11-02 12:17:05 --> Security Class Initialized
DEBUG - 2023-11-02 12:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:17:05 --> Input Class Initialized
INFO - 2023-11-02 12:17:05 --> Language Class Initialized
INFO - 2023-11-02 12:17:05 --> Loader Class Initialized
INFO - 2023-11-02 12:17:05 --> Helper loaded: url_helper
INFO - 2023-11-02 12:17:05 --> Helper loaded: form_helper
INFO - 2023-11-02 12:17:05 --> Helper loaded: file_helper
INFO - 2023-11-02 12:17:05 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:17:05 --> Form Validation Class Initialized
INFO - 2023-11-02 12:17:05 --> Upload Class Initialized
INFO - 2023-11-02 12:17:05 --> Model "M_auth" initialized
INFO - 2023-11-02 12:17:05 --> Model "M_user" initialized
INFO - 2023-11-02 12:17:05 --> Model "M_produk" initialized
INFO - 2023-11-02 12:17:05 --> Controller Class Initialized
INFO - 2023-11-02 12:17:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 12:17:05 --> Final output sent to browser
DEBUG - 2023-11-02 12:17:05 --> Total execution time: 0.0030
ERROR - 2023-11-02 12:17:10 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:17:10 --> Config Class Initialized
INFO - 2023-11-02 12:17:10 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:17:10 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:17:10 --> Utf8 Class Initialized
INFO - 2023-11-02 12:17:10 --> URI Class Initialized
INFO - 2023-11-02 12:17:10 --> Router Class Initialized
INFO - 2023-11-02 12:17:10 --> Output Class Initialized
INFO - 2023-11-02 12:17:10 --> Security Class Initialized
DEBUG - 2023-11-02 12:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:17:10 --> Input Class Initialized
INFO - 2023-11-02 12:17:10 --> Language Class Initialized
INFO - 2023-11-02 12:17:10 --> Loader Class Initialized
INFO - 2023-11-02 12:17:10 --> Helper loaded: url_helper
INFO - 2023-11-02 12:17:10 --> Helper loaded: form_helper
INFO - 2023-11-02 12:17:10 --> Helper loaded: file_helper
INFO - 2023-11-02 12:17:10 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:17:10 --> Form Validation Class Initialized
INFO - 2023-11-02 12:17:10 --> Upload Class Initialized
INFO - 2023-11-02 12:17:10 --> Model "M_auth" initialized
INFO - 2023-11-02 12:17:10 --> Model "M_user" initialized
INFO - 2023-11-02 12:17:10 --> Model "M_produk" initialized
INFO - 2023-11-02 12:17:10 --> Controller Class Initialized
INFO - 2023-11-02 12:17:10 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:17:10 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:17:10 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:17:10 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:17:10 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:17:10 --> Model "M_bank" initialized
INFO - 2023-11-02 12:17:10 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:17:10 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 12:17:10 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 12:17:10 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 12:17:10 --> Final output sent to browser
DEBUG - 2023-11-02 12:17:10 --> Total execution time: 0.3760
ERROR - 2023-11-02 12:17:16 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:17:16 --> Config Class Initialized
INFO - 2023-11-02 12:17:16 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:17:16 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:17:16 --> Utf8 Class Initialized
INFO - 2023-11-02 12:17:16 --> URI Class Initialized
INFO - 2023-11-02 12:17:16 --> Router Class Initialized
INFO - 2023-11-02 12:17:16 --> Output Class Initialized
INFO - 2023-11-02 12:17:16 --> Security Class Initialized
DEBUG - 2023-11-02 12:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:17:16 --> Input Class Initialized
INFO - 2023-11-02 12:17:16 --> Language Class Initialized
INFO - 2023-11-02 12:17:16 --> Loader Class Initialized
INFO - 2023-11-02 12:17:16 --> Helper loaded: url_helper
INFO - 2023-11-02 12:17:16 --> Helper loaded: form_helper
INFO - 2023-11-02 12:17:16 --> Helper loaded: file_helper
INFO - 2023-11-02 12:17:16 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:17:16 --> Form Validation Class Initialized
INFO - 2023-11-02 12:17:16 --> Upload Class Initialized
INFO - 2023-11-02 12:17:16 --> Model "M_auth" initialized
INFO - 2023-11-02 12:17:16 --> Model "M_user" initialized
INFO - 2023-11-02 12:17:16 --> Model "M_produk" initialized
INFO - 2023-11-02 12:17:16 --> Controller Class Initialized
INFO - 2023-11-02 12:17:16 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:17:16 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:17:16 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:17:16 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:17:16 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:17:16 --> Model "M_bank" initialized
INFO - 2023-11-02 12:17:16 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:17:16 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 12:17:16 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 12:17:16 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 12:17:16 --> Final output sent to browser
DEBUG - 2023-11-02 12:17:16 --> Total execution time: 0.3656
ERROR - 2023-11-02 12:17:54 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:17:54 --> Config Class Initialized
INFO - 2023-11-02 12:17:54 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:17:54 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:17:54 --> Utf8 Class Initialized
INFO - 2023-11-02 12:17:54 --> URI Class Initialized
INFO - 2023-11-02 12:17:54 --> Router Class Initialized
INFO - 2023-11-02 12:17:54 --> Output Class Initialized
INFO - 2023-11-02 12:17:54 --> Security Class Initialized
DEBUG - 2023-11-02 12:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:17:54 --> Input Class Initialized
INFO - 2023-11-02 12:17:54 --> Language Class Initialized
INFO - 2023-11-02 12:17:54 --> Loader Class Initialized
INFO - 2023-11-02 12:17:54 --> Helper loaded: url_helper
INFO - 2023-11-02 12:17:54 --> Helper loaded: form_helper
INFO - 2023-11-02 12:17:54 --> Helper loaded: file_helper
INFO - 2023-11-02 12:17:54 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:17:54 --> Form Validation Class Initialized
INFO - 2023-11-02 12:17:54 --> Upload Class Initialized
INFO - 2023-11-02 12:17:54 --> Model "M_auth" initialized
INFO - 2023-11-02 12:17:54 --> Model "M_user" initialized
INFO - 2023-11-02 12:17:54 --> Model "M_produk" initialized
INFO - 2023-11-02 12:17:54 --> Controller Class Initialized
INFO - 2023-11-02 12:17:54 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:17:54 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:17:54 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:17:54 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:17:54 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:17:54 --> Model "M_bank" initialized
INFO - 2023-11-02 12:17:54 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:17:54 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 12:17:54 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 12:17:54 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 12:17:54 --> Final output sent to browser
DEBUG - 2023-11-02 12:17:54 --> Total execution time: 0.3978
ERROR - 2023-11-02 12:17:55 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:17:55 --> Config Class Initialized
INFO - 2023-11-02 12:17:55 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:17:55 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:17:55 --> Utf8 Class Initialized
INFO - 2023-11-02 12:17:55 --> URI Class Initialized
INFO - 2023-11-02 12:17:55 --> Router Class Initialized
INFO - 2023-11-02 12:17:55 --> Output Class Initialized
INFO - 2023-11-02 12:17:55 --> Security Class Initialized
DEBUG - 2023-11-02 12:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:17:55 --> Input Class Initialized
INFO - 2023-11-02 12:17:55 --> Language Class Initialized
INFO - 2023-11-02 12:17:55 --> Loader Class Initialized
INFO - 2023-11-02 12:17:55 --> Helper loaded: url_helper
INFO - 2023-11-02 12:17:55 --> Helper loaded: form_helper
INFO - 2023-11-02 12:17:55 --> Helper loaded: file_helper
INFO - 2023-11-02 12:17:55 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:17:55 --> Form Validation Class Initialized
INFO - 2023-11-02 12:17:55 --> Upload Class Initialized
INFO - 2023-11-02 12:17:55 --> Model "M_auth" initialized
INFO - 2023-11-02 12:17:55 --> Model "M_user" initialized
INFO - 2023-11-02 12:17:55 --> Model "M_produk" initialized
INFO - 2023-11-02 12:17:55 --> Controller Class Initialized
INFO - 2023-11-02 12:17:55 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 12:17:55 --> Final output sent to browser
DEBUG - 2023-11-02 12:17:55 --> Total execution time: 0.0032
ERROR - 2023-11-02 12:18:53 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:18:53 --> Config Class Initialized
INFO - 2023-11-02 12:18:53 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:18:53 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:18:53 --> Utf8 Class Initialized
INFO - 2023-11-02 12:18:53 --> URI Class Initialized
INFO - 2023-11-02 12:18:53 --> Router Class Initialized
INFO - 2023-11-02 12:18:53 --> Output Class Initialized
INFO - 2023-11-02 12:18:53 --> Security Class Initialized
DEBUG - 2023-11-02 12:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:18:53 --> Input Class Initialized
INFO - 2023-11-02 12:18:53 --> Language Class Initialized
INFO - 2023-11-02 12:18:53 --> Loader Class Initialized
INFO - 2023-11-02 12:18:53 --> Helper loaded: url_helper
INFO - 2023-11-02 12:18:53 --> Helper loaded: form_helper
INFO - 2023-11-02 12:18:53 --> Helper loaded: file_helper
INFO - 2023-11-02 12:18:53 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:18:53 --> Form Validation Class Initialized
INFO - 2023-11-02 12:18:53 --> Upload Class Initialized
INFO - 2023-11-02 12:18:53 --> Model "M_auth" initialized
INFO - 2023-11-02 12:18:53 --> Model "M_user" initialized
INFO - 2023-11-02 12:18:53 --> Model "M_produk" initialized
INFO - 2023-11-02 12:18:53 --> Controller Class Initialized
INFO - 2023-11-02 12:18:53 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 12:18:53 --> Final output sent to browser
DEBUG - 2023-11-02 12:18:53 --> Total execution time: 0.0028
ERROR - 2023-11-02 12:20:09 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:20:09 --> Config Class Initialized
INFO - 2023-11-02 12:20:09 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:20:09 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:20:09 --> Utf8 Class Initialized
INFO - 2023-11-02 12:20:09 --> URI Class Initialized
DEBUG - 2023-11-02 12:20:09 --> No URI present. Default controller set.
INFO - 2023-11-02 12:20:09 --> Router Class Initialized
INFO - 2023-11-02 12:20:09 --> Output Class Initialized
INFO - 2023-11-02 12:20:09 --> Security Class Initialized
DEBUG - 2023-11-02 12:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:20:09 --> Input Class Initialized
INFO - 2023-11-02 12:20:09 --> Language Class Initialized
INFO - 2023-11-02 12:20:09 --> Loader Class Initialized
INFO - 2023-11-02 12:20:09 --> Helper loaded: url_helper
INFO - 2023-11-02 12:20:09 --> Helper loaded: form_helper
INFO - 2023-11-02 12:20:09 --> Helper loaded: file_helper
INFO - 2023-11-02 12:20:09 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:20:09 --> Form Validation Class Initialized
INFO - 2023-11-02 12:20:09 --> Upload Class Initialized
INFO - 2023-11-02 12:20:09 --> Model "M_auth" initialized
INFO - 2023-11-02 12:20:09 --> Model "M_user" initialized
INFO - 2023-11-02 12:20:09 --> Model "M_produk" initialized
INFO - 2023-11-02 12:20:09 --> Controller Class Initialized
INFO - 2023-11-02 12:20:09 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:20:09 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:20:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:20:09 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:20:09 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:20:09 --> Model "M_bank" initialized
INFO - 2023-11-02 12:20:09 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:20:09 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 12:20:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 12:20:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 12:20:09 --> Final output sent to browser
DEBUG - 2023-11-02 12:20:09 --> Total execution time: 0.0182
ERROR - 2023-11-02 12:20:09 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:20:09 --> Config Class Initialized
INFO - 2023-11-02 12:20:09 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:20:09 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:20:09 --> Utf8 Class Initialized
INFO - 2023-11-02 12:20:09 --> URI Class Initialized
INFO - 2023-11-02 12:20:09 --> Router Class Initialized
INFO - 2023-11-02 12:20:09 --> Output Class Initialized
INFO - 2023-11-02 12:20:09 --> Security Class Initialized
DEBUG - 2023-11-02 12:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:20:09 --> Input Class Initialized
INFO - 2023-11-02 12:20:09 --> Language Class Initialized
INFO - 2023-11-02 12:20:09 --> Loader Class Initialized
INFO - 2023-11-02 12:20:09 --> Helper loaded: url_helper
INFO - 2023-11-02 12:20:09 --> Helper loaded: form_helper
INFO - 2023-11-02 12:20:09 --> Helper loaded: file_helper
INFO - 2023-11-02 12:20:09 --> Database Driver Class Initialized
ERROR - 2023-11-02 12:20:09 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:20:09 --> Config Class Initialized
INFO - 2023-11-02 12:20:09 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:20:09 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:20:09 --> Utf8 Class Initialized
INFO - 2023-11-02 12:20:09 --> URI Class Initialized
INFO - 2023-11-02 12:20:09 --> Router Class Initialized
INFO - 2023-11-02 12:20:09 --> Output Class Initialized
INFO - 2023-11-02 12:20:09 --> Security Class Initialized
DEBUG - 2023-11-02 12:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-11-02 12:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:20:09 --> Input Class Initialized
INFO - 2023-11-02 12:20:09 --> Language Class Initialized
INFO - 2023-11-02 12:20:09 --> Loader Class Initialized
INFO - 2023-11-02 12:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:20:09 --> Helper loaded: url_helper
INFO - 2023-11-02 12:20:09 --> Form Validation Class Initialized
INFO - 2023-11-02 12:20:09 --> Helper loaded: form_helper
INFO - 2023-11-02 12:20:09 --> Helper loaded: file_helper
INFO - 2023-11-02 12:20:09 --> Upload Class Initialized
INFO - 2023-11-02 12:20:09 --> Database Driver Class Initialized
INFO - 2023-11-02 12:20:09 --> Model "M_auth" initialized
INFO - 2023-11-02 12:20:09 --> Model "M_user" initialized
INFO - 2023-11-02 12:20:09 --> Model "M_produk" initialized
INFO - 2023-11-02 12:20:09 --> Controller Class Initialized
INFO - 2023-11-02 12:20:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 12:20:09 --> Final output sent to browser
DEBUG - 2023-11-02 12:20:09 --> Total execution time: 0.0051
DEBUG - 2023-11-02 12:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:20:09 --> Form Validation Class Initialized
INFO - 2023-11-02 12:20:09 --> Upload Class Initialized
INFO - 2023-11-02 12:20:09 --> Model "M_auth" initialized
INFO - 2023-11-02 12:20:09 --> Model "M_user" initialized
INFO - 2023-11-02 12:20:09 --> Model "M_produk" initialized
INFO - 2023-11-02 12:20:09 --> Controller Class Initialized
INFO - 2023-11-02 12:20:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 12:20:09 --> Final output sent to browser
DEBUG - 2023-11-02 12:20:09 --> Total execution time: 0.0045
ERROR - 2023-11-02 12:20:11 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:20:11 --> Config Class Initialized
INFO - 2023-11-02 12:20:11 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:20:11 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:20:11 --> Utf8 Class Initialized
INFO - 2023-11-02 12:20:11 --> URI Class Initialized
INFO - 2023-11-02 12:20:11 --> Router Class Initialized
INFO - 2023-11-02 12:20:11 --> Output Class Initialized
INFO - 2023-11-02 12:20:11 --> Security Class Initialized
DEBUG - 2023-11-02 12:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:20:11 --> Input Class Initialized
INFO - 2023-11-02 12:20:11 --> Language Class Initialized
INFO - 2023-11-02 12:20:11 --> Loader Class Initialized
INFO - 2023-11-02 12:20:11 --> Helper loaded: url_helper
INFO - 2023-11-02 12:20:11 --> Helper loaded: form_helper
INFO - 2023-11-02 12:20:11 --> Helper loaded: file_helper
INFO - 2023-11-02 12:20:11 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:20:11 --> Form Validation Class Initialized
INFO - 2023-11-02 12:20:11 --> Upload Class Initialized
INFO - 2023-11-02 12:20:11 --> Model "M_auth" initialized
INFO - 2023-11-02 12:20:11 --> Model "M_user" initialized
INFO - 2023-11-02 12:20:11 --> Model "M_produk" initialized
INFO - 2023-11-02 12:20:11 --> Controller Class Initialized
INFO - 2023-11-02 12:20:11 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:20:11 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:20:11 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:20:11 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:20:11 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:20:11 --> Model "M_bank" initialized
INFO - 2023-11-02 12:20:11 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:20:11 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 12:20:11 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 12:20:11 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 12:20:11 --> Final output sent to browser
DEBUG - 2023-11-02 12:20:11 --> Total execution time: 0.3748
ERROR - 2023-11-02 12:20:12 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:20:12 --> Config Class Initialized
INFO - 2023-11-02 12:20:12 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:20:12 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:20:12 --> Utf8 Class Initialized
INFO - 2023-11-02 12:20:12 --> URI Class Initialized
INFO - 2023-11-02 12:20:12 --> Router Class Initialized
INFO - 2023-11-02 12:20:12 --> Output Class Initialized
INFO - 2023-11-02 12:20:12 --> Security Class Initialized
DEBUG - 2023-11-02 12:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:20:12 --> Input Class Initialized
INFO - 2023-11-02 12:20:12 --> Language Class Initialized
INFO - 2023-11-02 12:20:12 --> Loader Class Initialized
INFO - 2023-11-02 12:20:12 --> Helper loaded: url_helper
INFO - 2023-11-02 12:20:12 --> Helper loaded: form_helper
INFO - 2023-11-02 12:20:12 --> Helper loaded: file_helper
INFO - 2023-11-02 12:20:12 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:20:12 --> Form Validation Class Initialized
INFO - 2023-11-02 12:20:12 --> Upload Class Initialized
INFO - 2023-11-02 12:20:12 --> Model "M_auth" initialized
INFO - 2023-11-02 12:20:12 --> Model "M_user" initialized
INFO - 2023-11-02 12:20:12 --> Model "M_produk" initialized
INFO - 2023-11-02 12:20:12 --> Controller Class Initialized
INFO - 2023-11-02 12:20:12 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 12:20:12 --> Final output sent to browser
DEBUG - 2023-11-02 12:20:12 --> Total execution time: 0.0033
ERROR - 2023-11-02 12:20:13 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:20:13 --> Config Class Initialized
INFO - 2023-11-02 12:20:13 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:20:13 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:20:13 --> Utf8 Class Initialized
INFO - 2023-11-02 12:20:13 --> URI Class Initialized
DEBUG - 2023-11-02 12:20:13 --> No URI present. Default controller set.
INFO - 2023-11-02 12:20:13 --> Router Class Initialized
INFO - 2023-11-02 12:20:13 --> Output Class Initialized
INFO - 2023-11-02 12:20:13 --> Security Class Initialized
DEBUG - 2023-11-02 12:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:20:13 --> Input Class Initialized
INFO - 2023-11-02 12:20:13 --> Language Class Initialized
INFO - 2023-11-02 12:20:13 --> Loader Class Initialized
INFO - 2023-11-02 12:20:13 --> Helper loaded: url_helper
INFO - 2023-11-02 12:20:13 --> Helper loaded: form_helper
INFO - 2023-11-02 12:20:13 --> Helper loaded: file_helper
INFO - 2023-11-02 12:20:13 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:20:13 --> Form Validation Class Initialized
INFO - 2023-11-02 12:20:13 --> Upload Class Initialized
INFO - 2023-11-02 12:20:13 --> Model "M_auth" initialized
INFO - 2023-11-02 12:20:13 --> Model "M_user" initialized
INFO - 2023-11-02 12:20:13 --> Model "M_produk" initialized
INFO - 2023-11-02 12:20:13 --> Controller Class Initialized
INFO - 2023-11-02 12:20:13 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:20:13 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:20:13 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:20:13 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:20:13 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:20:13 --> Model "M_bank" initialized
INFO - 2023-11-02 12:20:13 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:20:13 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 12:20:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 12:20:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 12:20:13 --> Final output sent to browser
DEBUG - 2023-11-02 12:20:13 --> Total execution time: 0.0052
ERROR - 2023-11-02 12:20:13 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
ERROR - 2023-11-02 12:20:13 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:20:13 --> Config Class Initialized
INFO - 2023-11-02 12:20:13 --> Config Class Initialized
INFO - 2023-11-02 12:20:13 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:20:13 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:20:13 --> Utf8 Class Initialized
INFO - 2023-11-02 12:20:13 --> URI Class Initialized
INFO - 2023-11-02 12:20:13 --> Hooks Class Initialized
INFO - 2023-11-02 12:20:13 --> Router Class Initialized
INFO - 2023-11-02 12:20:13 --> Output Class Initialized
DEBUG - 2023-11-02 12:20:13 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:20:13 --> Utf8 Class Initialized
INFO - 2023-11-02 12:20:13 --> Security Class Initialized
INFO - 2023-11-02 12:20:13 --> URI Class Initialized
INFO - 2023-11-02 12:20:13 --> Router Class Initialized
INFO - 2023-11-02 12:20:13 --> Output Class Initialized
INFO - 2023-11-02 12:20:13 --> Security Class Initialized
DEBUG - 2023-11-02 12:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:20:13 --> Input Class Initialized
INFO - 2023-11-02 12:20:13 --> Language Class Initialized
INFO - 2023-11-02 12:20:13 --> Loader Class Initialized
INFO - 2023-11-02 12:20:13 --> Helper loaded: url_helper
INFO - 2023-11-02 12:20:13 --> Helper loaded: form_helper
INFO - 2023-11-02 12:20:13 --> Helper loaded: file_helper
INFO - 2023-11-02 12:20:13 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:20:13 --> Input Class Initialized
INFO - 2023-11-02 12:20:13 --> Language Class Initialized
INFO - 2023-11-02 12:20:13 --> Loader Class Initialized
INFO - 2023-11-02 12:20:13 --> Helper loaded: url_helper
INFO - 2023-11-02 12:20:13 --> Helper loaded: form_helper
INFO - 2023-11-02 12:20:13 --> Helper loaded: file_helper
INFO - 2023-11-02 12:20:13 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:20:13 --> Form Validation Class Initialized
INFO - 2023-11-02 12:20:13 --> Upload Class Initialized
INFO - 2023-11-02 12:20:13 --> Model "M_auth" initialized
INFO - 2023-11-02 12:20:13 --> Model "M_user" initialized
INFO - 2023-11-02 12:20:13 --> Model "M_produk" initialized
INFO - 2023-11-02 12:20:13 --> Controller Class Initialized
INFO - 2023-11-02 12:20:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 12:20:13 --> Final output sent to browser
DEBUG - 2023-11-02 12:20:13 --> Total execution time: 0.0029
DEBUG - 2023-11-02 12:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:20:13 --> Form Validation Class Initialized
INFO - 2023-11-02 12:20:13 --> Upload Class Initialized
INFO - 2023-11-02 12:20:13 --> Model "M_auth" initialized
INFO - 2023-11-02 12:20:13 --> Model "M_user" initialized
INFO - 2023-11-02 12:20:13 --> Model "M_produk" initialized
INFO - 2023-11-02 12:20:13 --> Controller Class Initialized
INFO - 2023-11-02 12:20:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 12:20:13 --> Final output sent to browser
DEBUG - 2023-11-02 12:20:13 --> Total execution time: 0.0051
ERROR - 2023-11-02 12:20:16 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:20:16 --> Config Class Initialized
INFO - 2023-11-02 12:20:16 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:20:16 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:20:16 --> Utf8 Class Initialized
INFO - 2023-11-02 12:20:16 --> URI Class Initialized
INFO - 2023-11-02 12:20:16 --> Router Class Initialized
INFO - 2023-11-02 12:20:16 --> Output Class Initialized
INFO - 2023-11-02 12:20:16 --> Security Class Initialized
DEBUG - 2023-11-02 12:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:20:16 --> Input Class Initialized
INFO - 2023-11-02 12:20:16 --> Language Class Initialized
INFO - 2023-11-02 12:20:16 --> Loader Class Initialized
INFO - 2023-11-02 12:20:16 --> Helper loaded: url_helper
INFO - 2023-11-02 12:20:16 --> Helper loaded: form_helper
INFO - 2023-11-02 12:20:16 --> Helper loaded: file_helper
INFO - 2023-11-02 12:20:16 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:20:16 --> Form Validation Class Initialized
INFO - 2023-11-02 12:20:16 --> Upload Class Initialized
INFO - 2023-11-02 12:20:16 --> Model "M_auth" initialized
INFO - 2023-11-02 12:20:16 --> Model "M_user" initialized
INFO - 2023-11-02 12:20:16 --> Model "M_produk" initialized
INFO - 2023-11-02 12:20:16 --> Controller Class Initialized
INFO - 2023-11-02 12:20:16 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:20:16 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:20:16 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:20:16 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:20:16 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:20:16 --> Model "M_bank" initialized
INFO - 2023-11-02 12:20:16 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:20:16 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 12:20:16 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 12:20:16 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-02 12:20:16 --> Final output sent to browser
DEBUG - 2023-11-02 12:20:16 --> Total execution time: 0.0058
ERROR - 2023-11-02 12:20:16 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:20:16 --> Config Class Initialized
INFO - 2023-11-02 12:20:16 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:20:16 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:20:16 --> Utf8 Class Initialized
INFO - 2023-11-02 12:20:16 --> URI Class Initialized
INFO - 2023-11-02 12:20:16 --> Router Class Initialized
INFO - 2023-11-02 12:20:16 --> Output Class Initialized
INFO - 2023-11-02 12:20:16 --> Security Class Initialized
DEBUG - 2023-11-02 12:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:20:16 --> Input Class Initialized
INFO - 2023-11-02 12:20:16 --> Language Class Initialized
INFO - 2023-11-02 12:20:16 --> Loader Class Initialized
INFO - 2023-11-02 12:20:16 --> Helper loaded: url_helper
INFO - 2023-11-02 12:20:16 --> Helper loaded: form_helper
INFO - 2023-11-02 12:20:16 --> Helper loaded: file_helper
INFO - 2023-11-02 12:20:16 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:20:16 --> Form Validation Class Initialized
INFO - 2023-11-02 12:20:16 --> Upload Class Initialized
INFO - 2023-11-02 12:20:16 --> Model "M_auth" initialized
INFO - 2023-11-02 12:20:16 --> Model "M_user" initialized
INFO - 2023-11-02 12:20:16 --> Model "M_produk" initialized
INFO - 2023-11-02 12:20:16 --> Controller Class Initialized
INFO - 2023-11-02 12:20:16 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 12:20:16 --> Final output sent to browser
DEBUG - 2023-11-02 12:20:16 --> Total execution time: 0.0032
ERROR - 2023-11-02 12:20:24 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:20:24 --> Config Class Initialized
INFO - 2023-11-02 12:20:24 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:20:24 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:20:24 --> Utf8 Class Initialized
INFO - 2023-11-02 12:20:24 --> URI Class Initialized
INFO - 2023-11-02 12:20:24 --> Router Class Initialized
INFO - 2023-11-02 12:20:24 --> Output Class Initialized
INFO - 2023-11-02 12:20:24 --> Security Class Initialized
DEBUG - 2023-11-02 12:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:20:24 --> Input Class Initialized
INFO - 2023-11-02 12:20:24 --> Language Class Initialized
INFO - 2023-11-02 12:20:24 --> Loader Class Initialized
INFO - 2023-11-02 12:20:24 --> Helper loaded: url_helper
INFO - 2023-11-02 12:20:24 --> Helper loaded: form_helper
INFO - 2023-11-02 12:20:24 --> Helper loaded: file_helper
INFO - 2023-11-02 12:20:24 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:20:24 --> Form Validation Class Initialized
INFO - 2023-11-02 12:20:24 --> Upload Class Initialized
INFO - 2023-11-02 12:20:24 --> Model "M_auth" initialized
INFO - 2023-11-02 12:20:24 --> Model "M_user" initialized
INFO - 2023-11-02 12:20:24 --> Model "M_produk" initialized
INFO - 2023-11-02 12:20:24 --> Controller Class Initialized
INFO - 2023-11-02 12:20:24 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:20:24 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:20:24 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:20:24 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:20:24 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:20:24 --> Model "M_bank" initialized
INFO - 2023-11-02 12:20:24 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:20:24 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 12:20:24 --> Email Class Initialized
INFO - 2023-11-02 12:20:25 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-11-02 12:20:27 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:20:27 --> Config Class Initialized
INFO - 2023-11-02 12:20:27 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:20:27 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:20:27 --> Utf8 Class Initialized
INFO - 2023-11-02 12:20:27 --> URI Class Initialized
INFO - 2023-11-02 12:20:27 --> Router Class Initialized
INFO - 2023-11-02 12:20:27 --> Output Class Initialized
INFO - 2023-11-02 12:20:27 --> Security Class Initialized
DEBUG - 2023-11-02 12:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:20:27 --> Input Class Initialized
INFO - 2023-11-02 12:20:27 --> Language Class Initialized
INFO - 2023-11-02 12:20:27 --> Loader Class Initialized
INFO - 2023-11-02 12:20:27 --> Helper loaded: url_helper
INFO - 2023-11-02 12:20:27 --> Helper loaded: form_helper
INFO - 2023-11-02 12:20:27 --> Helper loaded: file_helper
INFO - 2023-11-02 12:20:27 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:20:27 --> Form Validation Class Initialized
INFO - 2023-11-02 12:20:27 --> Upload Class Initialized
INFO - 2023-11-02 12:20:27 --> Model "M_auth" initialized
INFO - 2023-11-02 12:20:27 --> Model "M_user" initialized
INFO - 2023-11-02 12:20:27 --> Model "M_produk" initialized
INFO - 2023-11-02 12:20:27 --> Controller Class Initialized
INFO - 2023-11-02 12:20:27 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:20:27 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:20:27 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:20:27 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:20:27 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:20:27 --> Model "M_bank" initialized
INFO - 2023-11-02 12:20:27 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:20:27 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 12:20:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 12:20:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 12:20:27 --> Final output sent to browser
DEBUG - 2023-11-02 12:20:27 --> Total execution time: 0.4115
ERROR - 2023-11-02 12:20:28 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:20:28 --> Config Class Initialized
INFO - 2023-11-02 12:20:28 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:20:28 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:20:28 --> Utf8 Class Initialized
INFO - 2023-11-02 12:20:28 --> URI Class Initialized
INFO - 2023-11-02 12:20:28 --> Router Class Initialized
INFO - 2023-11-02 12:20:28 --> Output Class Initialized
INFO - 2023-11-02 12:20:28 --> Security Class Initialized
DEBUG - 2023-11-02 12:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:20:28 --> Input Class Initialized
INFO - 2023-11-02 12:20:28 --> Language Class Initialized
INFO - 2023-11-02 12:20:28 --> Loader Class Initialized
INFO - 2023-11-02 12:20:28 --> Helper loaded: url_helper
INFO - 2023-11-02 12:20:28 --> Helper loaded: form_helper
INFO - 2023-11-02 12:20:28 --> Helper loaded: file_helper
INFO - 2023-11-02 12:20:28 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:20:28 --> Form Validation Class Initialized
INFO - 2023-11-02 12:20:28 --> Upload Class Initialized
INFO - 2023-11-02 12:20:28 --> Model "M_auth" initialized
INFO - 2023-11-02 12:20:28 --> Model "M_user" initialized
INFO - 2023-11-02 12:20:28 --> Model "M_produk" initialized
INFO - 2023-11-02 12:20:28 --> Controller Class Initialized
INFO - 2023-11-02 12:20:28 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 12:20:28 --> Final output sent to browser
DEBUG - 2023-11-02 12:20:28 --> Total execution time: 0.0025
ERROR - 2023-11-02 12:20:32 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:20:32 --> Config Class Initialized
INFO - 2023-11-02 12:20:32 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:20:32 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:20:32 --> Utf8 Class Initialized
INFO - 2023-11-02 12:20:32 --> URI Class Initialized
DEBUG - 2023-11-02 12:20:32 --> No URI present. Default controller set.
INFO - 2023-11-02 12:20:32 --> Router Class Initialized
INFO - 2023-11-02 12:20:32 --> Output Class Initialized
INFO - 2023-11-02 12:20:32 --> Security Class Initialized
DEBUG - 2023-11-02 12:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:20:32 --> Input Class Initialized
INFO - 2023-11-02 12:20:32 --> Language Class Initialized
INFO - 2023-11-02 12:20:32 --> Loader Class Initialized
INFO - 2023-11-02 12:20:32 --> Helper loaded: url_helper
INFO - 2023-11-02 12:20:32 --> Helper loaded: form_helper
INFO - 2023-11-02 12:20:32 --> Helper loaded: file_helper
INFO - 2023-11-02 12:20:32 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:20:32 --> Form Validation Class Initialized
INFO - 2023-11-02 12:20:32 --> Upload Class Initialized
INFO - 2023-11-02 12:20:32 --> Model "M_auth" initialized
INFO - 2023-11-02 12:20:32 --> Model "M_user" initialized
INFO - 2023-11-02 12:20:32 --> Model "M_produk" initialized
INFO - 2023-11-02 12:20:32 --> Controller Class Initialized
INFO - 2023-11-02 12:20:32 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:20:32 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:20:32 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:20:32 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:20:32 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:20:32 --> Model "M_bank" initialized
INFO - 2023-11-02 12:20:32 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:20:32 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 12:20:32 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 12:20:32 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 12:20:32 --> Final output sent to browser
DEBUG - 2023-11-02 12:20:32 --> Total execution time: 0.0047
ERROR - 2023-11-02 12:20:32 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
ERROR - 2023-11-02 12:20:32 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:20:32 --> Config Class Initialized
INFO - 2023-11-02 12:20:32 --> Hooks Class Initialized
INFO - 2023-11-02 12:20:32 --> Config Class Initialized
INFO - 2023-11-02 12:20:32 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:20:32 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:20:32 --> Utf8 Class Initialized
DEBUG - 2023-11-02 12:20:32 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:20:32 --> URI Class Initialized
INFO - 2023-11-02 12:20:32 --> Utf8 Class Initialized
INFO - 2023-11-02 12:20:32 --> Router Class Initialized
INFO - 2023-11-02 12:20:32 --> URI Class Initialized
INFO - 2023-11-02 12:20:32 --> Output Class Initialized
INFO - 2023-11-02 12:20:32 --> Security Class Initialized
INFO - 2023-11-02 12:20:32 --> Router Class Initialized
DEBUG - 2023-11-02 12:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:20:32 --> Output Class Initialized
INFO - 2023-11-02 12:20:32 --> Input Class Initialized
INFO - 2023-11-02 12:20:32 --> Language Class Initialized
INFO - 2023-11-02 12:20:32 --> Security Class Initialized
INFO - 2023-11-02 12:20:32 --> Loader Class Initialized
DEBUG - 2023-11-02 12:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:20:32 --> Input Class Initialized
INFO - 2023-11-02 12:20:32 --> Helper loaded: url_helper
INFO - 2023-11-02 12:20:32 --> Language Class Initialized
INFO - 2023-11-02 12:20:32 --> Helper loaded: form_helper
INFO - 2023-11-02 12:20:32 --> Helper loaded: file_helper
INFO - 2023-11-02 12:20:32 --> Loader Class Initialized
INFO - 2023-11-02 12:20:32 --> Database Driver Class Initialized
INFO - 2023-11-02 12:20:32 --> Helper loaded: url_helper
INFO - 2023-11-02 12:20:32 --> Helper loaded: form_helper
INFO - 2023-11-02 12:20:32 --> Helper loaded: file_helper
INFO - 2023-11-02 12:20:32 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:20:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2023-11-02 12:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:20:32 --> Form Validation Class Initialized
INFO - 2023-11-02 12:20:32 --> Upload Class Initialized
INFO - 2023-11-02 12:20:32 --> Model "M_auth" initialized
INFO - 2023-11-02 12:20:32 --> Model "M_user" initialized
INFO - 2023-11-02 12:20:32 --> Model "M_produk" initialized
INFO - 2023-11-02 12:20:32 --> Controller Class Initialized
INFO - 2023-11-02 12:20:32 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 12:20:32 --> Final output sent to browser
DEBUG - 2023-11-02 12:20:32 --> Total execution time: 0.0026
INFO - 2023-11-02 12:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:20:32 --> Form Validation Class Initialized
INFO - 2023-11-02 12:20:32 --> Upload Class Initialized
INFO - 2023-11-02 12:20:32 --> Model "M_auth" initialized
INFO - 2023-11-02 12:20:32 --> Model "M_user" initialized
INFO - 2023-11-02 12:20:32 --> Model "M_produk" initialized
INFO - 2023-11-02 12:20:32 --> Controller Class Initialized
INFO - 2023-11-02 12:20:32 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 12:20:32 --> Final output sent to browser
DEBUG - 2023-11-02 12:20:32 --> Total execution time: 0.0035
ERROR - 2023-11-02 12:20:35 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:20:35 --> Config Class Initialized
INFO - 2023-11-02 12:20:35 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:20:35 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:20:35 --> Utf8 Class Initialized
INFO - 2023-11-02 12:20:35 --> URI Class Initialized
INFO - 2023-11-02 12:20:35 --> Router Class Initialized
INFO - 2023-11-02 12:20:35 --> Output Class Initialized
INFO - 2023-11-02 12:20:35 --> Security Class Initialized
DEBUG - 2023-11-02 12:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:20:35 --> Input Class Initialized
INFO - 2023-11-02 12:20:35 --> Language Class Initialized
INFO - 2023-11-02 12:20:35 --> Loader Class Initialized
INFO - 2023-11-02 12:20:35 --> Helper loaded: url_helper
INFO - 2023-11-02 12:20:35 --> Helper loaded: form_helper
INFO - 2023-11-02 12:20:35 --> Helper loaded: file_helper
INFO - 2023-11-02 12:20:35 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:20:35 --> Form Validation Class Initialized
INFO - 2023-11-02 12:20:35 --> Upload Class Initialized
INFO - 2023-11-02 12:20:35 --> Model "M_auth" initialized
INFO - 2023-11-02 12:20:35 --> Model "M_user" initialized
INFO - 2023-11-02 12:20:35 --> Model "M_produk" initialized
INFO - 2023-11-02 12:20:35 --> Controller Class Initialized
INFO - 2023-11-02 12:20:35 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:20:35 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:20:35 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:20:35 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:20:35 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:20:35 --> Model "M_bank" initialized
INFO - 2023-11-02 12:20:35 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:20:35 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 12:20:35 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 12:20:35 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-02 12:20:35 --> Final output sent to browser
DEBUG - 2023-11-02 12:20:35 --> Total execution time: 0.0055
ERROR - 2023-11-02 12:20:36 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:20:36 --> Config Class Initialized
INFO - 2023-11-02 12:20:36 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:20:36 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:20:36 --> Utf8 Class Initialized
INFO - 2023-11-02 12:20:36 --> URI Class Initialized
INFO - 2023-11-02 12:20:36 --> Router Class Initialized
INFO - 2023-11-02 12:20:36 --> Output Class Initialized
INFO - 2023-11-02 12:20:36 --> Security Class Initialized
DEBUG - 2023-11-02 12:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:20:36 --> Input Class Initialized
INFO - 2023-11-02 12:20:36 --> Language Class Initialized
INFO - 2023-11-02 12:20:36 --> Loader Class Initialized
INFO - 2023-11-02 12:20:36 --> Helper loaded: url_helper
INFO - 2023-11-02 12:20:36 --> Helper loaded: form_helper
INFO - 2023-11-02 12:20:36 --> Helper loaded: file_helper
INFO - 2023-11-02 12:20:36 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:20:36 --> Form Validation Class Initialized
INFO - 2023-11-02 12:20:36 --> Upload Class Initialized
INFO - 2023-11-02 12:20:36 --> Model "M_auth" initialized
INFO - 2023-11-02 12:20:36 --> Model "M_user" initialized
INFO - 2023-11-02 12:20:36 --> Model "M_produk" initialized
INFO - 2023-11-02 12:20:36 --> Controller Class Initialized
INFO - 2023-11-02 12:20:36 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 12:20:36 --> Final output sent to browser
DEBUG - 2023-11-02 12:20:36 --> Total execution time: 0.0030
ERROR - 2023-11-02 12:20:43 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:20:43 --> Config Class Initialized
INFO - 2023-11-02 12:20:43 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:20:43 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:20:43 --> Utf8 Class Initialized
INFO - 2023-11-02 12:20:43 --> URI Class Initialized
INFO - 2023-11-02 12:20:43 --> Router Class Initialized
INFO - 2023-11-02 12:20:43 --> Output Class Initialized
INFO - 2023-11-02 12:20:43 --> Security Class Initialized
DEBUG - 2023-11-02 12:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:20:43 --> Input Class Initialized
INFO - 2023-11-02 12:20:43 --> Language Class Initialized
INFO - 2023-11-02 12:20:43 --> Loader Class Initialized
INFO - 2023-11-02 12:20:43 --> Helper loaded: url_helper
INFO - 2023-11-02 12:20:43 --> Helper loaded: form_helper
INFO - 2023-11-02 12:20:43 --> Helper loaded: file_helper
INFO - 2023-11-02 12:20:43 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:20:43 --> Form Validation Class Initialized
INFO - 2023-11-02 12:20:43 --> Upload Class Initialized
INFO - 2023-11-02 12:20:43 --> Model "M_auth" initialized
INFO - 2023-11-02 12:20:43 --> Model "M_user" initialized
INFO - 2023-11-02 12:20:43 --> Model "M_produk" initialized
INFO - 2023-11-02 12:20:43 --> Controller Class Initialized
INFO - 2023-11-02 12:20:43 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:20:43 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:20:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:20:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:20:43 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:20:43 --> Model "M_bank" initialized
INFO - 2023-11-02 12:20:43 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:20:43 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 12:20:43 --> Email Class Initialized
INFO - 2023-11-02 12:20:44 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-11-02 12:20:46 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:20:46 --> Config Class Initialized
INFO - 2023-11-02 12:20:46 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:20:46 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:20:46 --> Utf8 Class Initialized
INFO - 2023-11-02 12:20:46 --> URI Class Initialized
INFO - 2023-11-02 12:20:46 --> Router Class Initialized
INFO - 2023-11-02 12:20:46 --> Output Class Initialized
INFO - 2023-11-02 12:20:46 --> Security Class Initialized
DEBUG - 2023-11-02 12:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:20:46 --> Input Class Initialized
INFO - 2023-11-02 12:20:46 --> Language Class Initialized
INFO - 2023-11-02 12:20:46 --> Loader Class Initialized
INFO - 2023-11-02 12:20:46 --> Helper loaded: url_helper
INFO - 2023-11-02 12:20:46 --> Helper loaded: form_helper
INFO - 2023-11-02 12:20:46 --> Helper loaded: file_helper
INFO - 2023-11-02 12:20:46 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:20:46 --> Form Validation Class Initialized
INFO - 2023-11-02 12:20:46 --> Upload Class Initialized
INFO - 2023-11-02 12:20:46 --> Model "M_auth" initialized
INFO - 2023-11-02 12:20:46 --> Model "M_user" initialized
INFO - 2023-11-02 12:20:46 --> Model "M_produk" initialized
INFO - 2023-11-02 12:20:46 --> Controller Class Initialized
INFO - 2023-11-02 12:20:46 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:20:46 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:20:46 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:20:46 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:20:46 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:20:46 --> Model "M_bank" initialized
INFO - 2023-11-02 12:20:46 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:20:46 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 12:20:47 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 12:20:47 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 12:20:47 --> Final output sent to browser
DEBUG - 2023-11-02 12:20:47 --> Total execution time: 0.4574
ERROR - 2023-11-02 12:20:47 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:20:47 --> Config Class Initialized
INFO - 2023-11-02 12:20:47 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:20:47 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:20:47 --> Utf8 Class Initialized
INFO - 2023-11-02 12:20:47 --> URI Class Initialized
INFO - 2023-11-02 12:20:47 --> Router Class Initialized
INFO - 2023-11-02 12:20:47 --> Output Class Initialized
INFO - 2023-11-02 12:20:47 --> Security Class Initialized
DEBUG - 2023-11-02 12:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:20:47 --> Input Class Initialized
INFO - 2023-11-02 12:20:47 --> Language Class Initialized
INFO - 2023-11-02 12:20:47 --> Loader Class Initialized
INFO - 2023-11-02 12:20:47 --> Helper loaded: url_helper
INFO - 2023-11-02 12:20:47 --> Helper loaded: form_helper
INFO - 2023-11-02 12:20:47 --> Helper loaded: file_helper
INFO - 2023-11-02 12:20:47 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:20:47 --> Form Validation Class Initialized
INFO - 2023-11-02 12:20:47 --> Upload Class Initialized
INFO - 2023-11-02 12:20:47 --> Model "M_auth" initialized
INFO - 2023-11-02 12:20:47 --> Model "M_user" initialized
INFO - 2023-11-02 12:20:47 --> Model "M_produk" initialized
INFO - 2023-11-02 12:20:47 --> Controller Class Initialized
INFO - 2023-11-02 12:20:47 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 12:20:47 --> Final output sent to browser
DEBUG - 2023-11-02 12:20:47 --> Total execution time: 0.0052
ERROR - 2023-11-02 12:22:13 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:22:13 --> Config Class Initialized
INFO - 2023-11-02 12:22:13 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:22:13 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:22:13 --> Utf8 Class Initialized
INFO - 2023-11-02 12:22:13 --> URI Class Initialized
INFO - 2023-11-02 12:22:13 --> Router Class Initialized
INFO - 2023-11-02 12:22:13 --> Output Class Initialized
INFO - 2023-11-02 12:22:13 --> Security Class Initialized
DEBUG - 2023-11-02 12:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:22:13 --> Input Class Initialized
INFO - 2023-11-02 12:22:13 --> Language Class Initialized
INFO - 2023-11-02 12:22:13 --> Loader Class Initialized
INFO - 2023-11-02 12:22:13 --> Helper loaded: url_helper
INFO - 2023-11-02 12:22:13 --> Helper loaded: form_helper
INFO - 2023-11-02 12:22:13 --> Helper loaded: file_helper
INFO - 2023-11-02 12:22:13 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:22:13 --> Form Validation Class Initialized
INFO - 2023-11-02 12:22:13 --> Upload Class Initialized
INFO - 2023-11-02 12:22:13 --> Model "M_auth" initialized
INFO - 2023-11-02 12:22:13 --> Model "M_user" initialized
INFO - 2023-11-02 12:22:13 --> Model "M_produk" initialized
INFO - 2023-11-02 12:22:13 --> Controller Class Initialized
INFO - 2023-11-02 12:22:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 12:22:13 --> Final output sent to browser
DEBUG - 2023-11-02 12:22:13 --> Total execution time: 0.0047
ERROR - 2023-11-02 12:22:59 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:22:59 --> Config Class Initialized
INFO - 2023-11-02 12:22:59 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:22:59 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:22:59 --> Utf8 Class Initialized
INFO - 2023-11-02 12:22:59 --> URI Class Initialized
DEBUG - 2023-11-02 12:22:59 --> No URI present. Default controller set.
INFO - 2023-11-02 12:22:59 --> Router Class Initialized
INFO - 2023-11-02 12:22:59 --> Output Class Initialized
INFO - 2023-11-02 12:22:59 --> Security Class Initialized
DEBUG - 2023-11-02 12:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:22:59 --> Input Class Initialized
INFO - 2023-11-02 12:22:59 --> Language Class Initialized
INFO - 2023-11-02 12:22:59 --> Loader Class Initialized
INFO - 2023-11-02 12:22:59 --> Helper loaded: url_helper
INFO - 2023-11-02 12:22:59 --> Helper loaded: form_helper
INFO - 2023-11-02 12:22:59 --> Helper loaded: file_helper
INFO - 2023-11-02 12:22:59 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:22:59 --> Form Validation Class Initialized
INFO - 2023-11-02 12:22:59 --> Upload Class Initialized
INFO - 2023-11-02 12:22:59 --> Model "M_auth" initialized
INFO - 2023-11-02 12:22:59 --> Model "M_user" initialized
INFO - 2023-11-02 12:22:59 --> Model "M_produk" initialized
INFO - 2023-11-02 12:22:59 --> Controller Class Initialized
INFO - 2023-11-02 12:22:59 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:22:59 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:22:59 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:22:59 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:22:59 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:22:59 --> Model "M_bank" initialized
INFO - 2023-11-02 12:22:59 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:22:59 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 12:22:59 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 12:22:59 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 12:22:59 --> Final output sent to browser
DEBUG - 2023-11-02 12:22:59 --> Total execution time: 0.0045
ERROR - 2023-11-02 12:23:00 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:23:00 --> Config Class Initialized
INFO - 2023-11-02 12:23:00 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:23:00 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:23:00 --> Utf8 Class Initialized
INFO - 2023-11-02 12:23:00 --> URI Class Initialized
INFO - 2023-11-02 12:23:00 --> Router Class Initialized
INFO - 2023-11-02 12:23:00 --> Output Class Initialized
INFO - 2023-11-02 12:23:00 --> Security Class Initialized
DEBUG - 2023-11-02 12:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:23:00 --> Input Class Initialized
INFO - 2023-11-02 12:23:00 --> Language Class Initialized
INFO - 2023-11-02 12:23:00 --> Loader Class Initialized
INFO - 2023-11-02 12:23:00 --> Helper loaded: url_helper
INFO - 2023-11-02 12:23:00 --> Helper loaded: form_helper
INFO - 2023-11-02 12:23:00 --> Helper loaded: file_helper
INFO - 2023-11-02 12:23:00 --> Database Driver Class Initialized
ERROR - 2023-11-02 12:23:00 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:23:00 --> Config Class Initialized
INFO - 2023-11-02 12:23:00 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:23:00 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:23:00 --> Utf8 Class Initialized
DEBUG - 2023-11-02 12:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:23:00 --> URI Class Initialized
INFO - 2023-11-02 12:23:00 --> Router Class Initialized
INFO - 2023-11-02 12:23:00 --> Output Class Initialized
INFO - 2023-11-02 12:23:00 --> Security Class Initialized
INFO - 2023-11-02 12:23:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2023-11-02 12:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:23:00 --> Input Class Initialized
INFO - 2023-11-02 12:23:00 --> Language Class Initialized
INFO - 2023-11-02 12:23:00 --> Form Validation Class Initialized
INFO - 2023-11-02 12:23:00 --> Loader Class Initialized
INFO - 2023-11-02 12:23:00 --> Upload Class Initialized
INFO - 2023-11-02 12:23:00 --> Helper loaded: url_helper
INFO - 2023-11-02 12:23:00 --> Helper loaded: form_helper
INFO - 2023-11-02 12:23:00 --> Model "M_auth" initialized
INFO - 2023-11-02 12:23:00 --> Helper loaded: file_helper
INFO - 2023-11-02 12:23:00 --> Model "M_user" initialized
INFO - 2023-11-02 12:23:00 --> Database Driver Class Initialized
INFO - 2023-11-02 12:23:00 --> Model "M_produk" initialized
INFO - 2023-11-02 12:23:00 --> Controller Class Initialized
INFO - 2023-11-02 12:23:00 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 12:23:00 --> Final output sent to browser
DEBUG - 2023-11-02 12:23:00 --> Total execution time: 0.0037
DEBUG - 2023-11-02 12:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:23:00 --> Form Validation Class Initialized
INFO - 2023-11-02 12:23:00 --> Upload Class Initialized
INFO - 2023-11-02 12:23:00 --> Model "M_auth" initialized
INFO - 2023-11-02 12:23:00 --> Model "M_user" initialized
INFO - 2023-11-02 12:23:00 --> Model "M_produk" initialized
INFO - 2023-11-02 12:23:00 --> Controller Class Initialized
INFO - 2023-11-02 12:23:00 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 12:23:00 --> Final output sent to browser
DEBUG - 2023-11-02 12:23:00 --> Total execution time: 0.0025
ERROR - 2023-11-02 12:23:27 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:23:27 --> Config Class Initialized
INFO - 2023-11-02 12:23:27 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:23:27 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:23:27 --> Utf8 Class Initialized
INFO - 2023-11-02 12:23:27 --> URI Class Initialized
INFO - 2023-11-02 12:23:27 --> Router Class Initialized
INFO - 2023-11-02 12:23:27 --> Output Class Initialized
INFO - 2023-11-02 12:23:27 --> Security Class Initialized
DEBUG - 2023-11-02 12:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:23:27 --> Input Class Initialized
INFO - 2023-11-02 12:23:27 --> Language Class Initialized
INFO - 2023-11-02 12:23:27 --> Loader Class Initialized
INFO - 2023-11-02 12:23:27 --> Helper loaded: url_helper
INFO - 2023-11-02 12:23:27 --> Helper loaded: form_helper
INFO - 2023-11-02 12:23:27 --> Helper loaded: file_helper
INFO - 2023-11-02 12:23:27 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:23:27 --> Form Validation Class Initialized
INFO - 2023-11-02 12:23:27 --> Upload Class Initialized
INFO - 2023-11-02 12:23:27 --> Model "M_auth" initialized
INFO - 2023-11-02 12:23:27 --> Model "M_user" initialized
INFO - 2023-11-02 12:23:27 --> Model "M_produk" initialized
INFO - 2023-11-02 12:23:27 --> Controller Class Initialized
INFO - 2023-11-02 12:23:27 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:23:27 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:23:27 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:23:27 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:23:27 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:23:27 --> Model "M_bank" initialized
INFO - 2023-11-02 12:23:27 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:23:27 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 12:23:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 12:23:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-02 12:23:27 --> Final output sent to browser
DEBUG - 2023-11-02 12:23:27 --> Total execution time: 0.0057
ERROR - 2023-11-02 12:23:27 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:23:27 --> Config Class Initialized
INFO - 2023-11-02 12:23:27 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:23:27 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:23:27 --> Utf8 Class Initialized
INFO - 2023-11-02 12:23:27 --> URI Class Initialized
INFO - 2023-11-02 12:23:27 --> Router Class Initialized
INFO - 2023-11-02 12:23:27 --> Output Class Initialized
INFO - 2023-11-02 12:23:27 --> Security Class Initialized
DEBUG - 2023-11-02 12:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:23:27 --> Input Class Initialized
INFO - 2023-11-02 12:23:27 --> Language Class Initialized
INFO - 2023-11-02 12:23:27 --> Loader Class Initialized
INFO - 2023-11-02 12:23:27 --> Helper loaded: url_helper
INFO - 2023-11-02 12:23:27 --> Helper loaded: form_helper
INFO - 2023-11-02 12:23:27 --> Helper loaded: file_helper
INFO - 2023-11-02 12:23:27 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:23:27 --> Form Validation Class Initialized
INFO - 2023-11-02 12:23:27 --> Upload Class Initialized
INFO - 2023-11-02 12:23:27 --> Model "M_auth" initialized
INFO - 2023-11-02 12:23:27 --> Model "M_user" initialized
INFO - 2023-11-02 12:23:27 --> Model "M_produk" initialized
INFO - 2023-11-02 12:23:27 --> Controller Class Initialized
INFO - 2023-11-02 12:23:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 12:23:27 --> Final output sent to browser
DEBUG - 2023-11-02 12:23:27 --> Total execution time: 0.0020
ERROR - 2023-11-02 12:23:34 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:23:34 --> Config Class Initialized
INFO - 2023-11-02 12:23:34 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:23:34 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:23:34 --> Utf8 Class Initialized
INFO - 2023-11-02 12:23:34 --> URI Class Initialized
INFO - 2023-11-02 12:23:34 --> Router Class Initialized
INFO - 2023-11-02 12:23:34 --> Output Class Initialized
INFO - 2023-11-02 12:23:34 --> Security Class Initialized
DEBUG - 2023-11-02 12:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:23:34 --> Input Class Initialized
INFO - 2023-11-02 12:23:34 --> Language Class Initialized
INFO - 2023-11-02 12:23:34 --> Loader Class Initialized
INFO - 2023-11-02 12:23:34 --> Helper loaded: url_helper
INFO - 2023-11-02 12:23:34 --> Helper loaded: form_helper
INFO - 2023-11-02 12:23:34 --> Helper loaded: file_helper
INFO - 2023-11-02 12:23:34 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:23:34 --> Form Validation Class Initialized
INFO - 2023-11-02 12:23:34 --> Upload Class Initialized
INFO - 2023-11-02 12:23:34 --> Model "M_auth" initialized
INFO - 2023-11-02 12:23:34 --> Model "M_user" initialized
INFO - 2023-11-02 12:23:34 --> Model "M_produk" initialized
INFO - 2023-11-02 12:23:34 --> Controller Class Initialized
INFO - 2023-11-02 12:23:34 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:23:34 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:23:34 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:23:34 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:23:34 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:23:34 --> Model "M_bank" initialized
INFO - 2023-11-02 12:23:34 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:23:34 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 12:23:34 --> Email Class Initialized
INFO - 2023-11-02 12:23:35 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-11-02 12:23:37 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:23:37 --> Config Class Initialized
INFO - 2023-11-02 12:23:37 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:23:37 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:23:37 --> Utf8 Class Initialized
INFO - 2023-11-02 12:23:37 --> URI Class Initialized
INFO - 2023-11-02 12:23:37 --> Router Class Initialized
INFO - 2023-11-02 12:23:37 --> Output Class Initialized
INFO - 2023-11-02 12:23:37 --> Security Class Initialized
DEBUG - 2023-11-02 12:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:23:37 --> Input Class Initialized
INFO - 2023-11-02 12:23:37 --> Language Class Initialized
INFO - 2023-11-02 12:23:37 --> Loader Class Initialized
INFO - 2023-11-02 12:23:37 --> Helper loaded: url_helper
INFO - 2023-11-02 12:23:37 --> Helper loaded: form_helper
INFO - 2023-11-02 12:23:37 --> Helper loaded: file_helper
INFO - 2023-11-02 12:23:37 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:23:37 --> Form Validation Class Initialized
INFO - 2023-11-02 12:23:37 --> Upload Class Initialized
INFO - 2023-11-02 12:23:37 --> Model "M_auth" initialized
INFO - 2023-11-02 12:23:37 --> Model "M_user" initialized
INFO - 2023-11-02 12:23:37 --> Model "M_produk" initialized
INFO - 2023-11-02 12:23:37 --> Controller Class Initialized
INFO - 2023-11-02 12:23:37 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:23:37 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:23:37 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:23:37 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:23:37 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:23:37 --> Model "M_bank" initialized
INFO - 2023-11-02 12:23:37 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:23:37 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 12:23:38 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 12:23:38 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 12:23:38 --> Final output sent to browser
DEBUG - 2023-11-02 12:23:38 --> Total execution time: 0.4311
ERROR - 2023-11-02 12:23:38 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:23:38 --> Config Class Initialized
INFO - 2023-11-02 12:23:38 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:23:38 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:23:38 --> Utf8 Class Initialized
INFO - 2023-11-02 12:23:38 --> URI Class Initialized
INFO - 2023-11-02 12:23:38 --> Router Class Initialized
INFO - 2023-11-02 12:23:38 --> Output Class Initialized
INFO - 2023-11-02 12:23:38 --> Security Class Initialized
DEBUG - 2023-11-02 12:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:23:38 --> Input Class Initialized
INFO - 2023-11-02 12:23:38 --> Language Class Initialized
INFO - 2023-11-02 12:23:38 --> Loader Class Initialized
INFO - 2023-11-02 12:23:38 --> Helper loaded: url_helper
INFO - 2023-11-02 12:23:38 --> Helper loaded: form_helper
INFO - 2023-11-02 12:23:38 --> Helper loaded: file_helper
INFO - 2023-11-02 12:23:38 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:23:38 --> Form Validation Class Initialized
INFO - 2023-11-02 12:23:38 --> Upload Class Initialized
INFO - 2023-11-02 12:23:38 --> Model "M_auth" initialized
INFO - 2023-11-02 12:23:38 --> Model "M_user" initialized
INFO - 2023-11-02 12:23:38 --> Model "M_produk" initialized
INFO - 2023-11-02 12:23:38 --> Controller Class Initialized
INFO - 2023-11-02 12:23:38 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 12:23:38 --> Final output sent to browser
DEBUG - 2023-11-02 12:23:38 --> Total execution time: 0.0029
ERROR - 2023-11-02 12:24:46 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:24:46 --> Config Class Initialized
INFO - 2023-11-02 12:24:46 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:24:46 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:24:46 --> Utf8 Class Initialized
INFO - 2023-11-02 12:24:46 --> URI Class Initialized
INFO - 2023-11-02 12:24:46 --> Router Class Initialized
INFO - 2023-11-02 12:24:46 --> Output Class Initialized
INFO - 2023-11-02 12:24:46 --> Security Class Initialized
DEBUG - 2023-11-02 12:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:24:46 --> Input Class Initialized
INFO - 2023-11-02 12:24:46 --> Language Class Initialized
INFO - 2023-11-02 12:24:46 --> Loader Class Initialized
INFO - 2023-11-02 12:24:46 --> Helper loaded: url_helper
INFO - 2023-11-02 12:24:46 --> Helper loaded: form_helper
INFO - 2023-11-02 12:24:46 --> Helper loaded: file_helper
INFO - 2023-11-02 12:24:46 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:24:46 --> Form Validation Class Initialized
INFO - 2023-11-02 12:24:46 --> Upload Class Initialized
INFO - 2023-11-02 12:24:46 --> Model "M_auth" initialized
INFO - 2023-11-02 12:24:46 --> Model "M_user" initialized
INFO - 2023-11-02 12:24:46 --> Model "M_produk" initialized
INFO - 2023-11-02 12:24:46 --> Controller Class Initialized
INFO - 2023-11-02 12:24:46 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 12:24:46 --> Final output sent to browser
DEBUG - 2023-11-02 12:24:46 --> Total execution time: 0.0029
ERROR - 2023-11-02 12:25:25 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:25:25 --> Config Class Initialized
INFO - 2023-11-02 12:25:25 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:25:25 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:25:25 --> Utf8 Class Initialized
INFO - 2023-11-02 12:25:25 --> URI Class Initialized
DEBUG - 2023-11-02 12:25:25 --> No URI present. Default controller set.
INFO - 2023-11-02 12:25:25 --> Router Class Initialized
INFO - 2023-11-02 12:25:25 --> Output Class Initialized
INFO - 2023-11-02 12:25:25 --> Security Class Initialized
DEBUG - 2023-11-02 12:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:25:25 --> Input Class Initialized
INFO - 2023-11-02 12:25:25 --> Language Class Initialized
INFO - 2023-11-02 12:25:25 --> Loader Class Initialized
INFO - 2023-11-02 12:25:25 --> Helper loaded: url_helper
INFO - 2023-11-02 12:25:25 --> Helper loaded: form_helper
INFO - 2023-11-02 12:25:25 --> Helper loaded: file_helper
INFO - 2023-11-02 12:25:25 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:25:25 --> Form Validation Class Initialized
INFO - 2023-11-02 12:25:25 --> Upload Class Initialized
INFO - 2023-11-02 12:25:25 --> Model "M_auth" initialized
INFO - 2023-11-02 12:25:25 --> Model "M_user" initialized
INFO - 2023-11-02 12:25:25 --> Model "M_produk" initialized
INFO - 2023-11-02 12:25:25 --> Controller Class Initialized
INFO - 2023-11-02 12:25:25 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:25:25 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:25:25 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:25:25 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:25:25 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:25:25 --> Model "M_bank" initialized
INFO - 2023-11-02 12:25:25 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:25:25 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 12:25:25 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 12:25:25 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 12:25:25 --> Final output sent to browser
DEBUG - 2023-11-02 12:25:25 --> Total execution time: 0.0056
ERROR - 2023-11-02 12:25:25 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:25:25 --> Config Class Initialized
INFO - 2023-11-02 12:25:25 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:25:25 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:25:25 --> Utf8 Class Initialized
INFO - 2023-11-02 12:25:25 --> URI Class Initialized
INFO - 2023-11-02 12:25:25 --> Router Class Initialized
INFO - 2023-11-02 12:25:25 --> Output Class Initialized
INFO - 2023-11-02 12:25:25 --> Security Class Initialized
DEBUG - 2023-11-02 12:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:25:25 --> Input Class Initialized
INFO - 2023-11-02 12:25:25 --> Language Class Initialized
INFO - 2023-11-02 12:25:25 --> Loader Class Initialized
INFO - 2023-11-02 12:25:25 --> Helper loaded: url_helper
INFO - 2023-11-02 12:25:25 --> Helper loaded: form_helper
INFO - 2023-11-02 12:25:25 --> Helper loaded: file_helper
INFO - 2023-11-02 12:25:25 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:25:25 --> Form Validation Class Initialized
INFO - 2023-11-02 12:25:25 --> Upload Class Initialized
INFO - 2023-11-02 12:25:25 --> Model "M_auth" initialized
INFO - 2023-11-02 12:25:25 --> Model "M_user" initialized
INFO - 2023-11-02 12:25:25 --> Model "M_produk" initialized
INFO - 2023-11-02 12:25:25 --> Controller Class Initialized
INFO - 2023-11-02 12:25:25 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 12:25:25 --> Final output sent to browser
DEBUG - 2023-11-02 12:25:25 --> Total execution time: 0.0027
ERROR - 2023-11-02 12:25:25 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:25:25 --> Config Class Initialized
INFO - 2023-11-02 12:25:25 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:25:25 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:25:25 --> Utf8 Class Initialized
INFO - 2023-11-02 12:25:25 --> URI Class Initialized
INFO - 2023-11-02 12:25:25 --> Router Class Initialized
INFO - 2023-11-02 12:25:25 --> Output Class Initialized
INFO - 2023-11-02 12:25:25 --> Security Class Initialized
DEBUG - 2023-11-02 12:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:25:25 --> Input Class Initialized
INFO - 2023-11-02 12:25:25 --> Language Class Initialized
INFO - 2023-11-02 12:25:25 --> Loader Class Initialized
INFO - 2023-11-02 12:25:25 --> Helper loaded: url_helper
INFO - 2023-11-02 12:25:25 --> Helper loaded: form_helper
INFO - 2023-11-02 12:25:25 --> Helper loaded: file_helper
INFO - 2023-11-02 12:25:25 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:25:25 --> Form Validation Class Initialized
INFO - 2023-11-02 12:25:25 --> Upload Class Initialized
INFO - 2023-11-02 12:25:25 --> Model "M_auth" initialized
INFO - 2023-11-02 12:25:25 --> Model "M_user" initialized
INFO - 2023-11-02 12:25:25 --> Model "M_produk" initialized
INFO - 2023-11-02 12:25:25 --> Controller Class Initialized
INFO - 2023-11-02 12:25:25 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 12:25:25 --> Final output sent to browser
DEBUG - 2023-11-02 12:25:25 --> Total execution time: 0.0028
ERROR - 2023-11-02 12:45:37 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:45:37 --> Config Class Initialized
INFO - 2023-11-02 12:45:37 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:45:37 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:45:37 --> Utf8 Class Initialized
INFO - 2023-11-02 12:45:37 --> URI Class Initialized
DEBUG - 2023-11-02 12:45:37 --> No URI present. Default controller set.
INFO - 2023-11-02 12:45:37 --> Router Class Initialized
INFO - 2023-11-02 12:45:37 --> Output Class Initialized
INFO - 2023-11-02 12:45:37 --> Security Class Initialized
DEBUG - 2023-11-02 12:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:45:37 --> Input Class Initialized
INFO - 2023-11-02 12:45:37 --> Language Class Initialized
INFO - 2023-11-02 12:45:37 --> Loader Class Initialized
INFO - 2023-11-02 12:45:37 --> Helper loaded: url_helper
INFO - 2023-11-02 12:45:37 --> Helper loaded: form_helper
INFO - 2023-11-02 12:45:37 --> Helper loaded: file_helper
INFO - 2023-11-02 12:45:37 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:45:37 --> Form Validation Class Initialized
INFO - 2023-11-02 12:45:37 --> Upload Class Initialized
INFO - 2023-11-02 12:45:37 --> Model "M_auth" initialized
INFO - 2023-11-02 12:45:37 --> Model "M_user" initialized
INFO - 2023-11-02 12:45:37 --> Model "M_produk" initialized
INFO - 2023-11-02 12:45:37 --> Controller Class Initialized
INFO - 2023-11-02 12:45:37 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:45:37 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:45:37 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:45:37 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:45:37 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:45:37 --> Model "M_bank" initialized
INFO - 2023-11-02 12:45:37 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:45:37 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 12:45:37 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 12:45:37 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 12:45:37 --> Final output sent to browser
DEBUG - 2023-11-02 12:45:37 --> Total execution time: 0.0423
ERROR - 2023-11-02 12:45:39 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:45:39 --> Config Class Initialized
INFO - 2023-11-02 12:45:39 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:45:39 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:45:39 --> Utf8 Class Initialized
INFO - 2023-11-02 12:45:39 --> URI Class Initialized
INFO - 2023-11-02 12:45:39 --> Router Class Initialized
INFO - 2023-11-02 12:45:39 --> Output Class Initialized
INFO - 2023-11-02 12:45:39 --> Security Class Initialized
DEBUG - 2023-11-02 12:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:45:39 --> Input Class Initialized
INFO - 2023-11-02 12:45:39 --> Language Class Initialized
INFO - 2023-11-02 12:45:39 --> Loader Class Initialized
INFO - 2023-11-02 12:45:39 --> Helper loaded: url_helper
INFO - 2023-11-02 12:45:39 --> Helper loaded: form_helper
INFO - 2023-11-02 12:45:39 --> Helper loaded: file_helper
INFO - 2023-11-02 12:45:39 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:45:39 --> Session: Class initialized using 'files' driver.
ERROR - 2023-11-02 12:45:39 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:45:39 --> Form Validation Class Initialized
INFO - 2023-11-02 12:45:39 --> Config Class Initialized
INFO - 2023-11-02 12:45:39 --> Upload Class Initialized
INFO - 2023-11-02 12:45:39 --> Hooks Class Initialized
INFO - 2023-11-02 12:45:39 --> Model "M_auth" initialized
DEBUG - 2023-11-02 12:45:39 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:45:39 --> Model "M_user" initialized
INFO - 2023-11-02 12:45:39 --> Utf8 Class Initialized
INFO - 2023-11-02 12:45:39 --> Model "M_produk" initialized
INFO - 2023-11-02 12:45:39 --> Controller Class Initialized
INFO - 2023-11-02 12:45:39 --> URI Class Initialized
INFO - 2023-11-02 12:45:39 --> Router Class Initialized
INFO - 2023-11-02 12:45:39 --> Output Class Initialized
INFO - 2023-11-02 12:45:39 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 12:45:39 --> Security Class Initialized
INFO - 2023-11-02 12:45:39 --> Final output sent to browser
DEBUG - 2023-11-02 12:45:39 --> Total execution time: 0.0029
DEBUG - 2023-11-02 12:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:45:39 --> Input Class Initialized
INFO - 2023-11-02 12:45:39 --> Language Class Initialized
INFO - 2023-11-02 12:45:39 --> Loader Class Initialized
INFO - 2023-11-02 12:45:39 --> Helper loaded: url_helper
INFO - 2023-11-02 12:45:39 --> Helper loaded: form_helper
INFO - 2023-11-02 12:45:39 --> Helper loaded: file_helper
INFO - 2023-11-02 12:45:39 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:45:39 --> Form Validation Class Initialized
INFO - 2023-11-02 12:45:39 --> Upload Class Initialized
INFO - 2023-11-02 12:45:39 --> Model "M_auth" initialized
INFO - 2023-11-02 12:45:39 --> Model "M_user" initialized
INFO - 2023-11-02 12:45:39 --> Model "M_produk" initialized
INFO - 2023-11-02 12:45:39 --> Controller Class Initialized
INFO - 2023-11-02 12:45:39 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 12:45:39 --> Final output sent to browser
DEBUG - 2023-11-02 12:45:39 --> Total execution time: 0.0031
ERROR - 2023-11-02 12:45:41 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:45:41 --> Config Class Initialized
INFO - 2023-11-02 12:45:41 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:45:41 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:45:41 --> Utf8 Class Initialized
INFO - 2023-11-02 12:45:41 --> URI Class Initialized
INFO - 2023-11-02 12:45:41 --> Router Class Initialized
INFO - 2023-11-02 12:45:41 --> Output Class Initialized
INFO - 2023-11-02 12:45:41 --> Security Class Initialized
DEBUG - 2023-11-02 12:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:45:41 --> Input Class Initialized
INFO - 2023-11-02 12:45:41 --> Language Class Initialized
INFO - 2023-11-02 12:45:41 --> Loader Class Initialized
INFO - 2023-11-02 12:45:41 --> Helper loaded: url_helper
INFO - 2023-11-02 12:45:41 --> Helper loaded: form_helper
INFO - 2023-11-02 12:45:41 --> Helper loaded: file_helper
INFO - 2023-11-02 12:45:41 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:45:41 --> Form Validation Class Initialized
INFO - 2023-11-02 12:45:41 --> Upload Class Initialized
INFO - 2023-11-02 12:45:41 --> Model "M_auth" initialized
INFO - 2023-11-02 12:45:41 --> Model "M_user" initialized
INFO - 2023-11-02 12:45:41 --> Model "M_produk" initialized
INFO - 2023-11-02 12:45:41 --> Controller Class Initialized
INFO - 2023-11-02 12:45:41 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:45:41 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:45:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:45:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:45:41 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:45:41 --> Model "M_bank" initialized
INFO - 2023-11-02 12:45:41 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:45:41 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 12:45:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 12:45:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-02 12:45:41 --> Final output sent to browser
DEBUG - 2023-11-02 12:45:41 --> Total execution time: 0.0054
ERROR - 2023-11-02 12:45:42 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:45:42 --> Config Class Initialized
INFO - 2023-11-02 12:45:42 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:45:42 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:45:42 --> Utf8 Class Initialized
INFO - 2023-11-02 12:45:42 --> URI Class Initialized
INFO - 2023-11-02 12:45:42 --> Router Class Initialized
INFO - 2023-11-02 12:45:42 --> Output Class Initialized
INFO - 2023-11-02 12:45:42 --> Security Class Initialized
DEBUG - 2023-11-02 12:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:45:42 --> Input Class Initialized
INFO - 2023-11-02 12:45:42 --> Language Class Initialized
INFO - 2023-11-02 12:45:42 --> Loader Class Initialized
INFO - 2023-11-02 12:45:42 --> Helper loaded: url_helper
INFO - 2023-11-02 12:45:42 --> Helper loaded: form_helper
INFO - 2023-11-02 12:45:42 --> Helper loaded: file_helper
INFO - 2023-11-02 12:45:42 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:45:42 --> Form Validation Class Initialized
INFO - 2023-11-02 12:45:42 --> Upload Class Initialized
INFO - 2023-11-02 12:45:42 --> Model "M_auth" initialized
INFO - 2023-11-02 12:45:42 --> Model "M_user" initialized
INFO - 2023-11-02 12:45:42 --> Model "M_produk" initialized
INFO - 2023-11-02 12:45:42 --> Controller Class Initialized
INFO - 2023-11-02 12:45:42 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 12:45:42 --> Final output sent to browser
DEBUG - 2023-11-02 12:45:42 --> Total execution time: 0.0019
ERROR - 2023-11-02 12:46:01 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:46:01 --> Config Class Initialized
INFO - 2023-11-02 12:46:01 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:46:01 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:46:01 --> Utf8 Class Initialized
INFO - 2023-11-02 12:46:01 --> URI Class Initialized
INFO - 2023-11-02 12:46:01 --> Router Class Initialized
INFO - 2023-11-02 12:46:01 --> Output Class Initialized
INFO - 2023-11-02 12:46:01 --> Security Class Initialized
DEBUG - 2023-11-02 12:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:46:01 --> Input Class Initialized
INFO - 2023-11-02 12:46:01 --> Language Class Initialized
INFO - 2023-11-02 12:46:01 --> Loader Class Initialized
INFO - 2023-11-02 12:46:01 --> Helper loaded: url_helper
INFO - 2023-11-02 12:46:01 --> Helper loaded: form_helper
INFO - 2023-11-02 12:46:01 --> Helper loaded: file_helper
INFO - 2023-11-02 12:46:01 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:46:01 --> Form Validation Class Initialized
INFO - 2023-11-02 12:46:01 --> Upload Class Initialized
INFO - 2023-11-02 12:46:01 --> Model "M_auth" initialized
INFO - 2023-11-02 12:46:01 --> Model "M_user" initialized
INFO - 2023-11-02 12:46:01 --> Model "M_produk" initialized
INFO - 2023-11-02 12:46:01 --> Controller Class Initialized
INFO - 2023-11-02 12:46:01 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:46:01 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:46:01 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:46:01 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:46:01 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:46:01 --> Model "M_bank" initialized
INFO - 2023-11-02 12:46:01 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:46:01 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 12:46:01 --> Email Class Initialized
INFO - 2023-11-02 12:46:02 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-11-02 12:46:04 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:46:04 --> Config Class Initialized
INFO - 2023-11-02 12:46:04 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:46:04 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:46:04 --> Utf8 Class Initialized
INFO - 2023-11-02 12:46:04 --> URI Class Initialized
INFO - 2023-11-02 12:46:04 --> Router Class Initialized
INFO - 2023-11-02 12:46:04 --> Output Class Initialized
INFO - 2023-11-02 12:46:04 --> Security Class Initialized
DEBUG - 2023-11-02 12:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:46:04 --> Input Class Initialized
INFO - 2023-11-02 12:46:04 --> Language Class Initialized
INFO - 2023-11-02 12:46:04 --> Loader Class Initialized
INFO - 2023-11-02 12:46:04 --> Helper loaded: url_helper
INFO - 2023-11-02 12:46:04 --> Helper loaded: form_helper
INFO - 2023-11-02 12:46:04 --> Helper loaded: file_helper
INFO - 2023-11-02 12:46:04 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:46:04 --> Form Validation Class Initialized
INFO - 2023-11-02 12:46:04 --> Upload Class Initialized
INFO - 2023-11-02 12:46:04 --> Model "M_auth" initialized
INFO - 2023-11-02 12:46:04 --> Model "M_user" initialized
INFO - 2023-11-02 12:46:04 --> Model "M_produk" initialized
INFO - 2023-11-02 12:46:04 --> Controller Class Initialized
INFO - 2023-11-02 12:46:04 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:46:04 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:46:04 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:46:04 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:46:04 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:46:04 --> Model "M_bank" initialized
INFO - 2023-11-02 12:46:04 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:46:04 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 12:46:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 12:46:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 12:46:05 --> Final output sent to browser
DEBUG - 2023-11-02 12:46:05 --> Total execution time: 0.4449
ERROR - 2023-11-02 12:46:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:46:45 --> Config Class Initialized
INFO - 2023-11-02 12:46:45 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:46:45 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:46:45 --> Utf8 Class Initialized
INFO - 2023-11-02 12:46:45 --> URI Class Initialized
INFO - 2023-11-02 12:46:45 --> Router Class Initialized
INFO - 2023-11-02 12:46:45 --> Output Class Initialized
INFO - 2023-11-02 12:46:45 --> Security Class Initialized
DEBUG - 2023-11-02 12:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:46:45 --> Input Class Initialized
INFO - 2023-11-02 12:46:45 --> Language Class Initialized
INFO - 2023-11-02 12:46:45 --> Loader Class Initialized
INFO - 2023-11-02 12:46:45 --> Helper loaded: url_helper
INFO - 2023-11-02 12:46:45 --> Helper loaded: form_helper
INFO - 2023-11-02 12:46:45 --> Helper loaded: file_helper
INFO - 2023-11-02 12:46:45 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:46:45 --> Form Validation Class Initialized
INFO - 2023-11-02 12:46:45 --> Upload Class Initialized
INFO - 2023-11-02 12:46:45 --> Model "M_auth" initialized
INFO - 2023-11-02 12:46:45 --> Model "M_user" initialized
INFO - 2023-11-02 12:46:45 --> Model "M_produk" initialized
INFO - 2023-11-02 12:46:45 --> Controller Class Initialized
INFO - 2023-11-02 12:46:45 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:46:45 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:46:45 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:46:45 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:46:45 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:46:45 --> Model "M_bank" initialized
INFO - 2023-11-02 12:46:45 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:46:45 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
ERROR - 2023-11-02 12:46:45 --> Severity: Warning --> Undefined variable $snapToken /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php 256
ERROR - 2023-11-02 12:46:45 --> Severity: Warning --> Undefined variable $snapToken /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php 256
ERROR - 2023-11-02 12:46:45 --> Severity: Warning --> Undefined variable $snapToken /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php 256
ERROR - 2023-11-02 12:46:45 --> Severity: Warning --> Undefined variable $snapToken /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php 256
ERROR - 2023-11-02 12:46:45 --> Severity: Warning --> Undefined variable $snapToken /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php 256
ERROR - 2023-11-02 12:46:45 --> Severity: Warning --> Undefined variable $snapToken /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php 256
INFO - 2023-11-02 12:46:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 12:46:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 12:46:45 --> Final output sent to browser
DEBUG - 2023-11-02 12:46:45 --> Total execution time: 0.0070
ERROR - 2023-11-02 12:46:46 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:46:46 --> Config Class Initialized
INFO - 2023-11-02 12:46:46 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:46:46 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:46:46 --> Utf8 Class Initialized
INFO - 2023-11-02 12:46:46 --> URI Class Initialized
INFO - 2023-11-02 12:46:46 --> Router Class Initialized
INFO - 2023-11-02 12:46:46 --> Output Class Initialized
INFO - 2023-11-02 12:46:46 --> Security Class Initialized
DEBUG - 2023-11-02 12:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:46:46 --> Input Class Initialized
INFO - 2023-11-02 12:46:46 --> Language Class Initialized
INFO - 2023-11-02 12:46:46 --> Loader Class Initialized
INFO - 2023-11-02 12:46:46 --> Helper loaded: url_helper
INFO - 2023-11-02 12:46:46 --> Helper loaded: form_helper
INFO - 2023-11-02 12:46:46 --> Helper loaded: file_helper
INFO - 2023-11-02 12:46:46 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:46:46 --> Form Validation Class Initialized
INFO - 2023-11-02 12:46:46 --> Upload Class Initialized
INFO - 2023-11-02 12:46:46 --> Model "M_auth" initialized
INFO - 2023-11-02 12:46:46 --> Model "M_user" initialized
INFO - 2023-11-02 12:46:46 --> Model "M_produk" initialized
INFO - 2023-11-02 12:46:46 --> Controller Class Initialized
INFO - 2023-11-02 12:46:46 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 12:46:46 --> Final output sent to browser
DEBUG - 2023-11-02 12:46:46 --> Total execution time: 0.0023
ERROR - 2023-11-02 12:49:43 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:49:43 --> Config Class Initialized
INFO - 2023-11-02 12:49:43 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:49:43 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:49:43 --> Utf8 Class Initialized
INFO - 2023-11-02 12:49:43 --> URI Class Initialized
INFO - 2023-11-02 12:49:43 --> Router Class Initialized
INFO - 2023-11-02 12:49:43 --> Output Class Initialized
INFO - 2023-11-02 12:49:43 --> Security Class Initialized
DEBUG - 2023-11-02 12:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:49:43 --> Input Class Initialized
INFO - 2023-11-02 12:49:43 --> Language Class Initialized
INFO - 2023-11-02 12:49:43 --> Loader Class Initialized
INFO - 2023-11-02 12:49:43 --> Helper loaded: url_helper
INFO - 2023-11-02 12:49:43 --> Helper loaded: form_helper
INFO - 2023-11-02 12:49:43 --> Helper loaded: file_helper
INFO - 2023-11-02 12:49:43 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:49:43 --> Form Validation Class Initialized
INFO - 2023-11-02 12:49:43 --> Upload Class Initialized
INFO - 2023-11-02 12:49:43 --> Model "M_auth" initialized
INFO - 2023-11-02 12:49:43 --> Model "M_user" initialized
INFO - 2023-11-02 12:49:43 --> Model "M_produk" initialized
INFO - 2023-11-02 12:49:43 --> Controller Class Initialized
INFO - 2023-11-02 12:49:43 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 12:49:43 --> Final output sent to browser
DEBUG - 2023-11-02 12:49:43 --> Total execution time: 0.0038
ERROR - 2023-11-02 12:49:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 12:49:45 --> Config Class Initialized
INFO - 2023-11-02 12:49:45 --> Hooks Class Initialized
DEBUG - 2023-11-02 12:49:45 --> UTF-8 Support Enabled
INFO - 2023-11-02 12:49:45 --> Utf8 Class Initialized
INFO - 2023-11-02 12:49:45 --> URI Class Initialized
DEBUG - 2023-11-02 12:49:45 --> No URI present. Default controller set.
INFO - 2023-11-02 12:49:45 --> Router Class Initialized
INFO - 2023-11-02 12:49:45 --> Output Class Initialized
INFO - 2023-11-02 12:49:45 --> Security Class Initialized
DEBUG - 2023-11-02 12:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 12:49:45 --> Input Class Initialized
INFO - 2023-11-02 12:49:45 --> Language Class Initialized
INFO - 2023-11-02 12:49:45 --> Loader Class Initialized
INFO - 2023-11-02 12:49:45 --> Helper loaded: url_helper
INFO - 2023-11-02 12:49:45 --> Helper loaded: form_helper
INFO - 2023-11-02 12:49:45 --> Helper loaded: file_helper
INFO - 2023-11-02 12:49:45 --> Database Driver Class Initialized
DEBUG - 2023-11-02 12:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 12:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 12:49:45 --> Form Validation Class Initialized
INFO - 2023-11-02 12:49:45 --> Upload Class Initialized
INFO - 2023-11-02 12:49:45 --> Model "M_auth" initialized
INFO - 2023-11-02 12:49:45 --> Model "M_user" initialized
INFO - 2023-11-02 12:49:45 --> Model "M_produk" initialized
INFO - 2023-11-02 12:49:45 --> Controller Class Initialized
INFO - 2023-11-02 12:49:45 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 12:49:45 --> Model "M_produk" initialized
DEBUG - 2023-11-02 12:49:45 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 12:49:45 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 12:49:45 --> Model "M_transaksi" initialized
INFO - 2023-11-02 12:49:45 --> Model "M_bank" initialized
INFO - 2023-11-02 12:49:45 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 12:49:45 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 12:49:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 12:49:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 12:49:45 --> Final output sent to browser
DEBUG - 2023-11-02 12:49:45 --> Total execution time: 0.0033
ERROR - 2023-11-02 13:05:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:05:45 --> Config Class Initialized
INFO - 2023-11-02 13:05:45 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:05:45 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:05:45 --> Utf8 Class Initialized
INFO - 2023-11-02 13:05:45 --> URI Class Initialized
DEBUG - 2023-11-02 13:05:45 --> No URI present. Default controller set.
INFO - 2023-11-02 13:05:45 --> Router Class Initialized
INFO - 2023-11-02 13:05:45 --> Output Class Initialized
INFO - 2023-11-02 13:05:45 --> Security Class Initialized
DEBUG - 2023-11-02 13:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:05:45 --> Input Class Initialized
INFO - 2023-11-02 13:05:45 --> Language Class Initialized
INFO - 2023-11-02 13:05:45 --> Loader Class Initialized
INFO - 2023-11-02 13:05:45 --> Helper loaded: url_helper
INFO - 2023-11-02 13:05:45 --> Helper loaded: form_helper
INFO - 2023-11-02 13:05:45 --> Helper loaded: file_helper
INFO - 2023-11-02 13:05:45 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:05:45 --> Form Validation Class Initialized
INFO - 2023-11-02 13:05:45 --> Upload Class Initialized
INFO - 2023-11-02 13:05:45 --> Model "M_auth" initialized
INFO - 2023-11-02 13:05:45 --> Model "M_user" initialized
INFO - 2023-11-02 13:05:45 --> Model "M_produk" initialized
INFO - 2023-11-02 13:05:45 --> Controller Class Initialized
INFO - 2023-11-02 13:05:45 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:05:45 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:05:45 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:05:45 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:05:45 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:05:45 --> Model "M_bank" initialized
INFO - 2023-11-02 13:05:45 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:05:45 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:05:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:05:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 13:05:45 --> Final output sent to browser
DEBUG - 2023-11-02 13:05:45 --> Total execution time: 0.0532
ERROR - 2023-11-02 13:05:47 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:05:47 --> Config Class Initialized
INFO - 2023-11-02 13:05:47 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:05:47 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:05:47 --> Utf8 Class Initialized
INFO - 2023-11-02 13:05:47 --> URI Class Initialized
INFO - 2023-11-02 13:05:47 --> Router Class Initialized
INFO - 2023-11-02 13:05:47 --> Output Class Initialized
INFO - 2023-11-02 13:05:47 --> Security Class Initialized
DEBUG - 2023-11-02 13:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:05:47 --> Input Class Initialized
INFO - 2023-11-02 13:05:47 --> Language Class Initialized
INFO - 2023-11-02 13:05:47 --> Loader Class Initialized
INFO - 2023-11-02 13:05:47 --> Helper loaded: url_helper
INFO - 2023-11-02 13:05:47 --> Helper loaded: form_helper
INFO - 2023-11-02 13:05:47 --> Helper loaded: file_helper
INFO - 2023-11-02 13:05:47 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:05:47 --> Session: Class initialized using 'files' driver.
ERROR - 2023-11-02 13:05:47 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:05:47 --> Form Validation Class Initialized
INFO - 2023-11-02 13:05:47 --> Config Class Initialized
INFO - 2023-11-02 13:05:47 --> Hooks Class Initialized
INFO - 2023-11-02 13:05:47 --> Upload Class Initialized
DEBUG - 2023-11-02 13:05:47 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:05:47 --> Model "M_auth" initialized
INFO - 2023-11-02 13:05:47 --> Utf8 Class Initialized
INFO - 2023-11-02 13:05:47 --> Model "M_user" initialized
INFO - 2023-11-02 13:05:47 --> URI Class Initialized
INFO - 2023-11-02 13:05:47 --> Model "M_produk" initialized
INFO - 2023-11-02 13:05:47 --> Controller Class Initialized
INFO - 2023-11-02 13:05:47 --> Router Class Initialized
INFO - 2023-11-02 13:05:47 --> Output Class Initialized
INFO - 2023-11-02 13:05:47 --> Security Class Initialized
DEBUG - 2023-11-02 13:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:05:47 --> Input Class Initialized
INFO - 2023-11-02 13:05:47 --> Language Class Initialized
INFO - 2023-11-02 13:05:47 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:05:47 --> Loader Class Initialized
INFO - 2023-11-02 13:05:47 --> Final output sent to browser
INFO - 2023-11-02 13:05:47 --> Helper loaded: url_helper
DEBUG - 2023-11-02 13:05:47 --> Total execution time: 0.0033
INFO - 2023-11-02 13:05:47 --> Helper loaded: form_helper
INFO - 2023-11-02 13:05:47 --> Helper loaded: file_helper
INFO - 2023-11-02 13:05:47 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:05:47 --> Form Validation Class Initialized
INFO - 2023-11-02 13:05:47 --> Upload Class Initialized
INFO - 2023-11-02 13:05:47 --> Model "M_auth" initialized
INFO - 2023-11-02 13:05:47 --> Model "M_user" initialized
INFO - 2023-11-02 13:05:47 --> Model "M_produk" initialized
INFO - 2023-11-02 13:05:47 --> Controller Class Initialized
INFO - 2023-11-02 13:05:47 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:05:47 --> Final output sent to browser
DEBUG - 2023-11-02 13:05:47 --> Total execution time: 0.0032
ERROR - 2023-11-02 13:05:49 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:05:49 --> Config Class Initialized
INFO - 2023-11-02 13:05:49 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:05:49 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:05:49 --> Utf8 Class Initialized
INFO - 2023-11-02 13:05:49 --> URI Class Initialized
INFO - 2023-11-02 13:05:49 --> Router Class Initialized
INFO - 2023-11-02 13:05:49 --> Output Class Initialized
INFO - 2023-11-02 13:05:49 --> Security Class Initialized
DEBUG - 2023-11-02 13:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:05:49 --> Input Class Initialized
INFO - 2023-11-02 13:05:49 --> Language Class Initialized
INFO - 2023-11-02 13:05:49 --> Loader Class Initialized
INFO - 2023-11-02 13:05:49 --> Helper loaded: url_helper
INFO - 2023-11-02 13:05:49 --> Helper loaded: form_helper
INFO - 2023-11-02 13:05:49 --> Helper loaded: file_helper
INFO - 2023-11-02 13:05:49 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:05:49 --> Form Validation Class Initialized
INFO - 2023-11-02 13:05:49 --> Upload Class Initialized
INFO - 2023-11-02 13:05:49 --> Model "M_auth" initialized
INFO - 2023-11-02 13:05:49 --> Model "M_user" initialized
INFO - 2023-11-02 13:05:49 --> Model "M_produk" initialized
INFO - 2023-11-02 13:05:49 --> Controller Class Initialized
INFO - 2023-11-02 13:05:49 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:05:49 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:05:49 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:05:49 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:05:49 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:05:49 --> Model "M_bank" initialized
INFO - 2023-11-02 13:05:49 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:05:49 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:05:50 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:05:50 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:05:50 --> Final output sent to browser
DEBUG - 2023-11-02 13:05:50 --> Total execution time: 0.7101
ERROR - 2023-11-02 13:06:20 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:06:20 --> Config Class Initialized
INFO - 2023-11-02 13:06:20 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:06:20 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:06:20 --> Utf8 Class Initialized
INFO - 2023-11-02 13:06:20 --> URI Class Initialized
INFO - 2023-11-02 13:06:20 --> Router Class Initialized
INFO - 2023-11-02 13:06:20 --> Output Class Initialized
INFO - 2023-11-02 13:06:20 --> Security Class Initialized
DEBUG - 2023-11-02 13:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:06:20 --> Input Class Initialized
INFO - 2023-11-02 13:06:20 --> Language Class Initialized
INFO - 2023-11-02 13:06:20 --> Loader Class Initialized
INFO - 2023-11-02 13:06:20 --> Helper loaded: url_helper
INFO - 2023-11-02 13:06:20 --> Helper loaded: form_helper
INFO - 2023-11-02 13:06:20 --> Helper loaded: file_helper
INFO - 2023-11-02 13:06:20 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:06:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:06:20 --> Form Validation Class Initialized
INFO - 2023-11-02 13:06:20 --> Upload Class Initialized
INFO - 2023-11-02 13:06:20 --> Model "M_auth" initialized
INFO - 2023-11-02 13:06:20 --> Model "M_user" initialized
INFO - 2023-11-02 13:06:20 --> Model "M_produk" initialized
INFO - 2023-11-02 13:06:20 --> Controller Class Initialized
INFO - 2023-11-02 13:06:20 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:06:20 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:06:20 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:06:20 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:06:20 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:06:20 --> Model "M_bank" initialized
INFO - 2023-11-02 13:06:20 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:06:20 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:06:20 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:06:20 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:06:20 --> Final output sent to browser
DEBUG - 2023-11-02 13:06:20 --> Total execution time: 0.7110
ERROR - 2023-11-02 13:06:29 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:06:29 --> Config Class Initialized
INFO - 2023-11-02 13:06:29 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:06:29 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:06:29 --> Utf8 Class Initialized
INFO - 2023-11-02 13:06:29 --> URI Class Initialized
DEBUG - 2023-11-02 13:06:29 --> No URI present. Default controller set.
INFO - 2023-11-02 13:06:29 --> Router Class Initialized
INFO - 2023-11-02 13:06:29 --> Output Class Initialized
INFO - 2023-11-02 13:06:29 --> Security Class Initialized
DEBUG - 2023-11-02 13:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:06:29 --> Input Class Initialized
INFO - 2023-11-02 13:06:29 --> Language Class Initialized
INFO - 2023-11-02 13:06:29 --> Loader Class Initialized
INFO - 2023-11-02 13:06:29 --> Helper loaded: url_helper
INFO - 2023-11-02 13:06:29 --> Helper loaded: form_helper
INFO - 2023-11-02 13:06:29 --> Helper loaded: file_helper
INFO - 2023-11-02 13:06:29 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:06:29 --> Form Validation Class Initialized
INFO - 2023-11-02 13:06:29 --> Upload Class Initialized
INFO - 2023-11-02 13:06:29 --> Model "M_auth" initialized
INFO - 2023-11-02 13:06:29 --> Model "M_user" initialized
INFO - 2023-11-02 13:06:29 --> Model "M_produk" initialized
INFO - 2023-11-02 13:06:29 --> Controller Class Initialized
INFO - 2023-11-02 13:06:29 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:06:29 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:06:29 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:06:29 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:06:29 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:06:29 --> Model "M_bank" initialized
INFO - 2023-11-02 13:06:29 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:06:29 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:06:29 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:06:29 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 13:06:29 --> Final output sent to browser
DEBUG - 2023-11-02 13:06:29 --> Total execution time: 0.0037
ERROR - 2023-11-02 13:06:29 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:06:29 --> Config Class Initialized
INFO - 2023-11-02 13:06:29 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:06:29 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:06:29 --> Utf8 Class Initialized
INFO - 2023-11-02 13:06:29 --> URI Class Initialized
INFO - 2023-11-02 13:06:29 --> Router Class Initialized
INFO - 2023-11-02 13:06:29 --> Output Class Initialized
INFO - 2023-11-02 13:06:29 --> Security Class Initialized
DEBUG - 2023-11-02 13:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:06:29 --> Input Class Initialized
INFO - 2023-11-02 13:06:29 --> Language Class Initialized
INFO - 2023-11-02 13:06:29 --> Loader Class Initialized
INFO - 2023-11-02 13:06:29 --> Helper loaded: url_helper
INFO - 2023-11-02 13:06:29 --> Helper loaded: form_helper
INFO - 2023-11-02 13:06:29 --> Helper loaded: file_helper
INFO - 2023-11-02 13:06:29 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:06:29 --> Form Validation Class Initialized
ERROR - 2023-11-02 13:06:29 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:06:29 --> Upload Class Initialized
INFO - 2023-11-02 13:06:29 --> Config Class Initialized
INFO - 2023-11-02 13:06:29 --> Model "M_auth" initialized
INFO - 2023-11-02 13:06:29 --> Hooks Class Initialized
INFO - 2023-11-02 13:06:29 --> Model "M_user" initialized
DEBUG - 2023-11-02 13:06:29 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:06:29 --> Model "M_produk" initialized
INFO - 2023-11-02 13:06:29 --> Utf8 Class Initialized
INFO - 2023-11-02 13:06:29 --> Controller Class Initialized
INFO - 2023-11-02 13:06:29 --> URI Class Initialized
INFO - 2023-11-02 13:06:29 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:06:29 --> Router Class Initialized
INFO - 2023-11-02 13:06:29 --> Final output sent to browser
INFO - 2023-11-02 13:06:29 --> Output Class Initialized
DEBUG - 2023-11-02 13:06:29 --> Total execution time: 0.0028
INFO - 2023-11-02 13:06:29 --> Security Class Initialized
DEBUG - 2023-11-02 13:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:06:29 --> Input Class Initialized
INFO - 2023-11-02 13:06:29 --> Language Class Initialized
INFO - 2023-11-02 13:06:29 --> Loader Class Initialized
INFO - 2023-11-02 13:06:29 --> Helper loaded: url_helper
INFO - 2023-11-02 13:06:29 --> Helper loaded: form_helper
INFO - 2023-11-02 13:06:29 --> Helper loaded: file_helper
INFO - 2023-11-02 13:06:29 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:06:29 --> Form Validation Class Initialized
INFO - 2023-11-02 13:06:29 --> Upload Class Initialized
INFO - 2023-11-02 13:06:29 --> Model "M_auth" initialized
INFO - 2023-11-02 13:06:29 --> Model "M_user" initialized
INFO - 2023-11-02 13:06:29 --> Model "M_produk" initialized
INFO - 2023-11-02 13:06:29 --> Controller Class Initialized
INFO - 2023-11-02 13:06:29 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:06:29 --> Final output sent to browser
DEBUG - 2023-11-02 13:06:29 --> Total execution time: 0.0030
ERROR - 2023-11-02 13:06:32 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:06:32 --> Config Class Initialized
INFO - 2023-11-02 13:06:32 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:06:32 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:06:32 --> Utf8 Class Initialized
INFO - 2023-11-02 13:06:32 --> URI Class Initialized
INFO - 2023-11-02 13:06:32 --> Router Class Initialized
INFO - 2023-11-02 13:06:32 --> Output Class Initialized
INFO - 2023-11-02 13:06:32 --> Security Class Initialized
DEBUG - 2023-11-02 13:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:06:32 --> Input Class Initialized
INFO - 2023-11-02 13:06:32 --> Language Class Initialized
INFO - 2023-11-02 13:06:32 --> Loader Class Initialized
INFO - 2023-11-02 13:06:32 --> Helper loaded: url_helper
INFO - 2023-11-02 13:06:32 --> Helper loaded: form_helper
INFO - 2023-11-02 13:06:32 --> Helper loaded: file_helper
INFO - 2023-11-02 13:06:32 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:06:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:06:32 --> Form Validation Class Initialized
INFO - 2023-11-02 13:06:32 --> Upload Class Initialized
INFO - 2023-11-02 13:06:32 --> Model "M_auth" initialized
INFO - 2023-11-02 13:06:32 --> Model "M_user" initialized
INFO - 2023-11-02 13:06:32 --> Model "M_produk" initialized
INFO - 2023-11-02 13:06:32 --> Controller Class Initialized
INFO - 2023-11-02 13:06:32 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:06:32 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:06:32 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:06:32 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:06:32 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:06:32 --> Model "M_bank" initialized
INFO - 2023-11-02 13:06:32 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:06:32 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:06:32 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:06:32 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-02 13:06:32 --> Final output sent to browser
DEBUG - 2023-11-02 13:06:32 --> Total execution time: 0.0051
ERROR - 2023-11-02 13:06:32 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:06:32 --> Config Class Initialized
INFO - 2023-11-02 13:06:32 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:06:32 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:06:32 --> Utf8 Class Initialized
INFO - 2023-11-02 13:06:32 --> URI Class Initialized
INFO - 2023-11-02 13:06:32 --> Router Class Initialized
INFO - 2023-11-02 13:06:32 --> Output Class Initialized
INFO - 2023-11-02 13:06:32 --> Security Class Initialized
DEBUG - 2023-11-02 13:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:06:32 --> Input Class Initialized
INFO - 2023-11-02 13:06:32 --> Language Class Initialized
INFO - 2023-11-02 13:06:32 --> Loader Class Initialized
INFO - 2023-11-02 13:06:32 --> Helper loaded: url_helper
INFO - 2023-11-02 13:06:32 --> Helper loaded: form_helper
INFO - 2023-11-02 13:06:32 --> Helper loaded: file_helper
INFO - 2023-11-02 13:06:32 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:06:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:06:32 --> Form Validation Class Initialized
INFO - 2023-11-02 13:06:32 --> Upload Class Initialized
INFO - 2023-11-02 13:06:32 --> Model "M_auth" initialized
INFO - 2023-11-02 13:06:32 --> Model "M_user" initialized
INFO - 2023-11-02 13:06:32 --> Model "M_produk" initialized
INFO - 2023-11-02 13:06:32 --> Controller Class Initialized
INFO - 2023-11-02 13:06:32 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:06:32 --> Final output sent to browser
DEBUG - 2023-11-02 13:06:32 --> Total execution time: 0.0028
ERROR - 2023-11-02 13:06:39 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:06:39 --> Config Class Initialized
INFO - 2023-11-02 13:06:39 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:06:39 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:06:39 --> Utf8 Class Initialized
INFO - 2023-11-02 13:06:39 --> URI Class Initialized
INFO - 2023-11-02 13:06:39 --> Router Class Initialized
INFO - 2023-11-02 13:06:39 --> Output Class Initialized
INFO - 2023-11-02 13:06:39 --> Security Class Initialized
DEBUG - 2023-11-02 13:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:06:39 --> Input Class Initialized
INFO - 2023-11-02 13:06:39 --> Language Class Initialized
INFO - 2023-11-02 13:06:39 --> Loader Class Initialized
INFO - 2023-11-02 13:06:39 --> Helper loaded: url_helper
INFO - 2023-11-02 13:06:39 --> Helper loaded: form_helper
INFO - 2023-11-02 13:06:39 --> Helper loaded: file_helper
INFO - 2023-11-02 13:06:39 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:06:39 --> Form Validation Class Initialized
INFO - 2023-11-02 13:06:39 --> Upload Class Initialized
INFO - 2023-11-02 13:06:39 --> Model "M_auth" initialized
INFO - 2023-11-02 13:06:39 --> Model "M_user" initialized
INFO - 2023-11-02 13:06:39 --> Model "M_produk" initialized
INFO - 2023-11-02 13:06:39 --> Controller Class Initialized
INFO - 2023-11-02 13:06:39 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:06:39 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:06:39 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:06:39 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:06:39 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:06:39 --> Model "M_bank" initialized
INFO - 2023-11-02 13:06:39 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:06:39 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:06:39 --> Email Class Initialized
INFO - 2023-11-02 13:06:40 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-11-02 13:06:42 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:06:42 --> Config Class Initialized
INFO - 2023-11-02 13:06:42 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:06:42 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:06:42 --> Utf8 Class Initialized
INFO - 2023-11-02 13:06:42 --> URI Class Initialized
INFO - 2023-11-02 13:06:42 --> Router Class Initialized
INFO - 2023-11-02 13:06:42 --> Output Class Initialized
INFO - 2023-11-02 13:06:42 --> Security Class Initialized
DEBUG - 2023-11-02 13:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:06:42 --> Input Class Initialized
INFO - 2023-11-02 13:06:42 --> Language Class Initialized
INFO - 2023-11-02 13:06:42 --> Loader Class Initialized
INFO - 2023-11-02 13:06:42 --> Helper loaded: url_helper
INFO - 2023-11-02 13:06:42 --> Helper loaded: form_helper
INFO - 2023-11-02 13:06:42 --> Helper loaded: file_helper
INFO - 2023-11-02 13:06:42 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:06:42 --> Form Validation Class Initialized
INFO - 2023-11-02 13:06:42 --> Upload Class Initialized
INFO - 2023-11-02 13:06:42 --> Model "M_auth" initialized
INFO - 2023-11-02 13:06:42 --> Model "M_user" initialized
INFO - 2023-11-02 13:06:42 --> Model "M_produk" initialized
INFO - 2023-11-02 13:06:42 --> Controller Class Initialized
INFO - 2023-11-02 13:06:42 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:06:42 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:06:42 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:06:42 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:06:42 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:06:42 --> Model "M_bank" initialized
INFO - 2023-11-02 13:06:42 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:06:42 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:06:43 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:06:43 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:06:43 --> Final output sent to browser
DEBUG - 2023-11-02 13:06:43 --> Total execution time: 0.6895
ERROR - 2023-11-02 13:06:44 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:06:44 --> Config Class Initialized
INFO - 2023-11-02 13:06:44 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:06:44 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:06:44 --> Utf8 Class Initialized
INFO - 2023-11-02 13:06:44 --> URI Class Initialized
INFO - 2023-11-02 13:06:44 --> Router Class Initialized
INFO - 2023-11-02 13:06:44 --> Output Class Initialized
INFO - 2023-11-02 13:06:44 --> Security Class Initialized
DEBUG - 2023-11-02 13:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:06:44 --> Input Class Initialized
INFO - 2023-11-02 13:06:44 --> Language Class Initialized
INFO - 2023-11-02 13:06:44 --> Loader Class Initialized
INFO - 2023-11-02 13:06:44 --> Helper loaded: url_helper
INFO - 2023-11-02 13:06:44 --> Helper loaded: form_helper
INFO - 2023-11-02 13:06:44 --> Helper loaded: file_helper
INFO - 2023-11-02 13:06:44 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:06:44 --> Form Validation Class Initialized
INFO - 2023-11-02 13:06:44 --> Upload Class Initialized
INFO - 2023-11-02 13:06:44 --> Model "M_auth" initialized
INFO - 2023-11-02 13:06:44 --> Model "M_user" initialized
INFO - 2023-11-02 13:06:44 --> Model "M_produk" initialized
INFO - 2023-11-02 13:06:44 --> Controller Class Initialized
INFO - 2023-11-02 13:06:44 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:06:44 --> Final output sent to browser
DEBUG - 2023-11-02 13:06:44 --> Total execution time: 0.0033
ERROR - 2023-11-02 13:06:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:06:45 --> Config Class Initialized
INFO - 2023-11-02 13:06:45 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:06:45 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:06:45 --> Utf8 Class Initialized
INFO - 2023-11-02 13:06:45 --> URI Class Initialized
DEBUG - 2023-11-02 13:06:45 --> No URI present. Default controller set.
INFO - 2023-11-02 13:06:45 --> Router Class Initialized
INFO - 2023-11-02 13:06:45 --> Output Class Initialized
INFO - 2023-11-02 13:06:45 --> Security Class Initialized
DEBUG - 2023-11-02 13:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:06:45 --> Input Class Initialized
INFO - 2023-11-02 13:06:45 --> Language Class Initialized
INFO - 2023-11-02 13:06:45 --> Loader Class Initialized
INFO - 2023-11-02 13:06:45 --> Helper loaded: url_helper
INFO - 2023-11-02 13:06:45 --> Helper loaded: form_helper
INFO - 2023-11-02 13:06:45 --> Helper loaded: file_helper
INFO - 2023-11-02 13:06:45 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:06:45 --> Form Validation Class Initialized
INFO - 2023-11-02 13:06:45 --> Upload Class Initialized
INFO - 2023-11-02 13:06:45 --> Model "M_auth" initialized
INFO - 2023-11-02 13:06:45 --> Model "M_user" initialized
INFO - 2023-11-02 13:06:45 --> Model "M_produk" initialized
INFO - 2023-11-02 13:06:45 --> Controller Class Initialized
INFO - 2023-11-02 13:06:45 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:06:45 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:06:45 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:06:45 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:06:45 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:06:45 --> Model "M_bank" initialized
INFO - 2023-11-02 13:06:45 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:06:45 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:06:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:06:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 13:06:45 --> Final output sent to browser
DEBUG - 2023-11-02 13:06:45 --> Total execution time: 0.0042
ERROR - 2023-11-02 13:06:46 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:06:46 --> Config Class Initialized
INFO - 2023-11-02 13:06:46 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:06:46 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:06:46 --> Utf8 Class Initialized
INFO - 2023-11-02 13:06:46 --> URI Class Initialized
INFO - 2023-11-02 13:06:46 --> Router Class Initialized
INFO - 2023-11-02 13:06:46 --> Output Class Initialized
INFO - 2023-11-02 13:06:46 --> Security Class Initialized
DEBUG - 2023-11-02 13:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:06:46 --> Input Class Initialized
INFO - 2023-11-02 13:06:46 --> Language Class Initialized
INFO - 2023-11-02 13:06:46 --> Loader Class Initialized
INFO - 2023-11-02 13:06:46 --> Helper loaded: url_helper
INFO - 2023-11-02 13:06:46 --> Helper loaded: form_helper
INFO - 2023-11-02 13:06:46 --> Helper loaded: file_helper
INFO - 2023-11-02 13:06:46 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:06:46 --> Form Validation Class Initialized
INFO - 2023-11-02 13:06:46 --> Upload Class Initialized
INFO - 2023-11-02 13:06:46 --> Model "M_auth" initialized
INFO - 2023-11-02 13:06:46 --> Model "M_user" initialized
INFO - 2023-11-02 13:06:46 --> Model "M_produk" initialized
INFO - 2023-11-02 13:06:46 --> Controller Class Initialized
INFO - 2023-11-02 13:06:46 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:06:46 --> Final output sent to browser
DEBUG - 2023-11-02 13:06:46 --> Total execution time: 0.0028
ERROR - 2023-11-02 13:06:46 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:06:46 --> Config Class Initialized
INFO - 2023-11-02 13:06:46 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:06:46 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:06:46 --> Utf8 Class Initialized
INFO - 2023-11-02 13:06:46 --> URI Class Initialized
INFO - 2023-11-02 13:06:46 --> Router Class Initialized
INFO - 2023-11-02 13:06:46 --> Output Class Initialized
INFO - 2023-11-02 13:06:46 --> Security Class Initialized
DEBUG - 2023-11-02 13:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:06:46 --> Input Class Initialized
INFO - 2023-11-02 13:06:46 --> Language Class Initialized
INFO - 2023-11-02 13:06:46 --> Loader Class Initialized
INFO - 2023-11-02 13:06:46 --> Helper loaded: url_helper
INFO - 2023-11-02 13:06:46 --> Helper loaded: form_helper
INFO - 2023-11-02 13:06:46 --> Helper loaded: file_helper
INFO - 2023-11-02 13:06:46 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:06:46 --> Form Validation Class Initialized
INFO - 2023-11-02 13:06:46 --> Upload Class Initialized
INFO - 2023-11-02 13:06:46 --> Model "M_auth" initialized
INFO - 2023-11-02 13:06:46 --> Model "M_user" initialized
INFO - 2023-11-02 13:06:46 --> Model "M_produk" initialized
INFO - 2023-11-02 13:06:46 --> Controller Class Initialized
INFO - 2023-11-02 13:06:46 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:06:46 --> Final output sent to browser
DEBUG - 2023-11-02 13:06:46 --> Total execution time: 0.0022
ERROR - 2023-11-02 13:06:48 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:06:48 --> Config Class Initialized
INFO - 2023-11-02 13:06:48 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:06:48 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:06:48 --> Utf8 Class Initialized
INFO - 2023-11-02 13:06:48 --> URI Class Initialized
INFO - 2023-11-02 13:06:48 --> Router Class Initialized
INFO - 2023-11-02 13:06:48 --> Output Class Initialized
INFO - 2023-11-02 13:06:48 --> Security Class Initialized
DEBUG - 2023-11-02 13:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:06:48 --> Input Class Initialized
INFO - 2023-11-02 13:06:48 --> Language Class Initialized
INFO - 2023-11-02 13:06:48 --> Loader Class Initialized
INFO - 2023-11-02 13:06:48 --> Helper loaded: url_helper
INFO - 2023-11-02 13:06:48 --> Helper loaded: form_helper
INFO - 2023-11-02 13:06:48 --> Helper loaded: file_helper
INFO - 2023-11-02 13:06:48 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:06:48 --> Form Validation Class Initialized
INFO - 2023-11-02 13:06:48 --> Upload Class Initialized
INFO - 2023-11-02 13:06:48 --> Model "M_auth" initialized
INFO - 2023-11-02 13:06:48 --> Model "M_user" initialized
INFO - 2023-11-02 13:06:48 --> Model "M_produk" initialized
INFO - 2023-11-02 13:06:48 --> Controller Class Initialized
INFO - 2023-11-02 13:06:48 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:06:48 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:06:48 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:06:48 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:06:48 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:06:48 --> Model "M_bank" initialized
INFO - 2023-11-02 13:06:48 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:06:48 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:06:48 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:06:48 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-02 13:06:48 --> Final output sent to browser
DEBUG - 2023-11-02 13:06:48 --> Total execution time: 0.0042
ERROR - 2023-11-02 13:06:48 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:06:48 --> Config Class Initialized
INFO - 2023-11-02 13:06:48 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:06:48 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:06:48 --> Utf8 Class Initialized
INFO - 2023-11-02 13:06:48 --> URI Class Initialized
INFO - 2023-11-02 13:06:48 --> Router Class Initialized
INFO - 2023-11-02 13:06:48 --> Output Class Initialized
INFO - 2023-11-02 13:06:48 --> Security Class Initialized
DEBUG - 2023-11-02 13:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:06:48 --> Input Class Initialized
INFO - 2023-11-02 13:06:48 --> Language Class Initialized
INFO - 2023-11-02 13:06:48 --> Loader Class Initialized
INFO - 2023-11-02 13:06:48 --> Helper loaded: url_helper
INFO - 2023-11-02 13:06:48 --> Helper loaded: form_helper
INFO - 2023-11-02 13:06:48 --> Helper loaded: file_helper
INFO - 2023-11-02 13:06:48 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:06:48 --> Form Validation Class Initialized
INFO - 2023-11-02 13:06:48 --> Upload Class Initialized
INFO - 2023-11-02 13:06:48 --> Model "M_auth" initialized
INFO - 2023-11-02 13:06:48 --> Model "M_user" initialized
INFO - 2023-11-02 13:06:48 --> Model "M_produk" initialized
INFO - 2023-11-02 13:06:48 --> Controller Class Initialized
INFO - 2023-11-02 13:06:48 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:06:48 --> Final output sent to browser
DEBUG - 2023-11-02 13:06:48 --> Total execution time: 0.0024
ERROR - 2023-11-02 13:06:56 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:06:56 --> Config Class Initialized
INFO - 2023-11-02 13:06:56 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:06:56 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:06:56 --> Utf8 Class Initialized
INFO - 2023-11-02 13:06:56 --> URI Class Initialized
INFO - 2023-11-02 13:06:56 --> Router Class Initialized
INFO - 2023-11-02 13:06:56 --> Output Class Initialized
INFO - 2023-11-02 13:06:56 --> Security Class Initialized
DEBUG - 2023-11-02 13:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:06:56 --> Input Class Initialized
INFO - 2023-11-02 13:06:56 --> Language Class Initialized
INFO - 2023-11-02 13:06:56 --> Loader Class Initialized
INFO - 2023-11-02 13:06:56 --> Helper loaded: url_helper
INFO - 2023-11-02 13:06:56 --> Helper loaded: form_helper
INFO - 2023-11-02 13:06:56 --> Helper loaded: file_helper
INFO - 2023-11-02 13:06:56 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:06:56 --> Form Validation Class Initialized
INFO - 2023-11-02 13:06:56 --> Upload Class Initialized
INFO - 2023-11-02 13:06:56 --> Model "M_auth" initialized
INFO - 2023-11-02 13:06:56 --> Model "M_user" initialized
INFO - 2023-11-02 13:06:56 --> Model "M_produk" initialized
INFO - 2023-11-02 13:06:56 --> Controller Class Initialized
INFO - 2023-11-02 13:06:56 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:06:56 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:06:56 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:06:56 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:06:56 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:06:56 --> Model "M_bank" initialized
INFO - 2023-11-02 13:06:56 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:06:56 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:06:56 --> Email Class Initialized
INFO - 2023-11-02 13:06:56 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-11-02 13:06:58 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:06:58 --> Config Class Initialized
INFO - 2023-11-02 13:06:58 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:06:58 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:06:58 --> Utf8 Class Initialized
INFO - 2023-11-02 13:06:58 --> URI Class Initialized
INFO - 2023-11-02 13:06:58 --> Router Class Initialized
INFO - 2023-11-02 13:06:58 --> Output Class Initialized
INFO - 2023-11-02 13:06:58 --> Security Class Initialized
DEBUG - 2023-11-02 13:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:06:58 --> Input Class Initialized
INFO - 2023-11-02 13:06:58 --> Language Class Initialized
INFO - 2023-11-02 13:06:58 --> Loader Class Initialized
INFO - 2023-11-02 13:06:58 --> Helper loaded: url_helper
INFO - 2023-11-02 13:06:58 --> Helper loaded: form_helper
INFO - 2023-11-02 13:06:58 --> Helper loaded: file_helper
INFO - 2023-11-02 13:06:58 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:06:58 --> Form Validation Class Initialized
INFO - 2023-11-02 13:06:58 --> Upload Class Initialized
INFO - 2023-11-02 13:06:58 --> Model "M_auth" initialized
INFO - 2023-11-02 13:06:58 --> Model "M_user" initialized
INFO - 2023-11-02 13:06:58 --> Model "M_produk" initialized
INFO - 2023-11-02 13:06:58 --> Controller Class Initialized
INFO - 2023-11-02 13:06:58 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:06:58 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:06:58 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:06:58 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:06:58 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:06:58 --> Model "M_bank" initialized
INFO - 2023-11-02 13:06:58 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:06:58 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:06:59 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:06:59 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:06:59 --> Final output sent to browser
DEBUG - 2023-11-02 13:06:59 --> Total execution time: 0.6672
ERROR - 2023-11-02 13:07:03 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:07:03 --> Config Class Initialized
INFO - 2023-11-02 13:07:03 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:07:03 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:07:03 --> Utf8 Class Initialized
INFO - 2023-11-02 13:07:03 --> URI Class Initialized
INFO - 2023-11-02 13:07:03 --> Router Class Initialized
INFO - 2023-11-02 13:07:03 --> Output Class Initialized
INFO - 2023-11-02 13:07:03 --> Security Class Initialized
DEBUG - 2023-11-02 13:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:07:03 --> Input Class Initialized
INFO - 2023-11-02 13:07:03 --> Language Class Initialized
INFO - 2023-11-02 13:07:03 --> Loader Class Initialized
INFO - 2023-11-02 13:07:03 --> Helper loaded: url_helper
INFO - 2023-11-02 13:07:03 --> Helper loaded: form_helper
INFO - 2023-11-02 13:07:03 --> Helper loaded: file_helper
INFO - 2023-11-02 13:07:03 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:07:03 --> Form Validation Class Initialized
INFO - 2023-11-02 13:07:03 --> Upload Class Initialized
INFO - 2023-11-02 13:07:03 --> Model "M_auth" initialized
INFO - 2023-11-02 13:07:03 --> Model "M_user" initialized
INFO - 2023-11-02 13:07:03 --> Model "M_produk" initialized
INFO - 2023-11-02 13:07:03 --> Controller Class Initialized
INFO - 2023-11-02 13:07:03 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:07:03 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:07:03 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:07:03 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:07:03 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:07:03 --> Model "M_bank" initialized
INFO - 2023-11-02 13:07:03 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:07:03 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:07:03 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:07:03 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-02 13:07:03 --> Final output sent to browser
DEBUG - 2023-11-02 13:07:03 --> Total execution time: 0.0072
ERROR - 2023-11-02 13:07:03 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:07:03 --> Config Class Initialized
INFO - 2023-11-02 13:07:03 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:07:03 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:07:03 --> Utf8 Class Initialized
INFO - 2023-11-02 13:07:03 --> URI Class Initialized
INFO - 2023-11-02 13:07:03 --> Router Class Initialized
INFO - 2023-11-02 13:07:03 --> Output Class Initialized
INFO - 2023-11-02 13:07:03 --> Security Class Initialized
DEBUG - 2023-11-02 13:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:07:03 --> Input Class Initialized
INFO - 2023-11-02 13:07:03 --> Language Class Initialized
INFO - 2023-11-02 13:07:03 --> Loader Class Initialized
INFO - 2023-11-02 13:07:03 --> Helper loaded: url_helper
INFO - 2023-11-02 13:07:03 --> Helper loaded: form_helper
INFO - 2023-11-02 13:07:03 --> Helper loaded: file_helper
INFO - 2023-11-02 13:07:03 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:07:03 --> Form Validation Class Initialized
INFO - 2023-11-02 13:07:03 --> Upload Class Initialized
INFO - 2023-11-02 13:07:03 --> Model "M_auth" initialized
INFO - 2023-11-02 13:07:03 --> Model "M_user" initialized
INFO - 2023-11-02 13:07:03 --> Model "M_produk" initialized
INFO - 2023-11-02 13:07:03 --> Controller Class Initialized
INFO - 2023-11-02 13:07:03 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:07:03 --> Final output sent to browser
DEBUG - 2023-11-02 13:07:03 --> Total execution time: 0.0027
ERROR - 2023-11-02 13:07:06 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:07:06 --> Config Class Initialized
INFO - 2023-11-02 13:07:06 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:07:06 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:07:06 --> Utf8 Class Initialized
INFO - 2023-11-02 13:07:06 --> URI Class Initialized
INFO - 2023-11-02 13:07:06 --> Router Class Initialized
INFO - 2023-11-02 13:07:06 --> Output Class Initialized
INFO - 2023-11-02 13:07:06 --> Security Class Initialized
DEBUG - 2023-11-02 13:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:07:06 --> Input Class Initialized
INFO - 2023-11-02 13:07:06 --> Language Class Initialized
INFO - 2023-11-02 13:07:06 --> Loader Class Initialized
INFO - 2023-11-02 13:07:06 --> Helper loaded: url_helper
INFO - 2023-11-02 13:07:06 --> Helper loaded: form_helper
INFO - 2023-11-02 13:07:06 --> Helper loaded: file_helper
INFO - 2023-11-02 13:07:06 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:07:06 --> Form Validation Class Initialized
INFO - 2023-11-02 13:07:06 --> Upload Class Initialized
INFO - 2023-11-02 13:07:06 --> Model "M_auth" initialized
INFO - 2023-11-02 13:07:06 --> Model "M_user" initialized
INFO - 2023-11-02 13:07:06 --> Model "M_produk" initialized
INFO - 2023-11-02 13:07:06 --> Controller Class Initialized
INFO - 2023-11-02 13:07:06 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:07:06 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:07:06 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:07:06 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:07:06 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:07:06 --> Model "M_bank" initialized
INFO - 2023-11-02 13:07:06 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:07:06 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:07:07 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:07:07 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:07:07 --> Final output sent to browser
DEBUG - 2023-11-02 13:07:07 --> Total execution time: 0.7010
ERROR - 2023-11-02 13:07:07 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:07:07 --> Config Class Initialized
INFO - 2023-11-02 13:07:07 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:07:07 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:07:07 --> Utf8 Class Initialized
INFO - 2023-11-02 13:07:07 --> URI Class Initialized
INFO - 2023-11-02 13:07:07 --> Router Class Initialized
INFO - 2023-11-02 13:07:07 --> Output Class Initialized
INFO - 2023-11-02 13:07:07 --> Security Class Initialized
DEBUG - 2023-11-02 13:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:07:07 --> Input Class Initialized
INFO - 2023-11-02 13:07:07 --> Language Class Initialized
INFO - 2023-11-02 13:07:07 --> Loader Class Initialized
INFO - 2023-11-02 13:07:07 --> Helper loaded: url_helper
INFO - 2023-11-02 13:07:07 --> Helper loaded: form_helper
INFO - 2023-11-02 13:07:07 --> Helper loaded: file_helper
INFO - 2023-11-02 13:07:07 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:07:07 --> Form Validation Class Initialized
INFO - 2023-11-02 13:07:07 --> Upload Class Initialized
INFO - 2023-11-02 13:07:07 --> Model "M_auth" initialized
INFO - 2023-11-02 13:07:07 --> Model "M_user" initialized
INFO - 2023-11-02 13:07:07 --> Model "M_produk" initialized
INFO - 2023-11-02 13:07:07 --> Controller Class Initialized
INFO - 2023-11-02 13:07:07 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:07:07 --> Final output sent to browser
DEBUG - 2023-11-02 13:07:07 --> Total execution time: 0.0026
ERROR - 2023-11-02 13:07:08 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:07:08 --> Config Class Initialized
INFO - 2023-11-02 13:07:08 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:07:08 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:07:08 --> Utf8 Class Initialized
INFO - 2023-11-02 13:07:08 --> URI Class Initialized
DEBUG - 2023-11-02 13:07:08 --> No URI present. Default controller set.
INFO - 2023-11-02 13:07:08 --> Router Class Initialized
INFO - 2023-11-02 13:07:08 --> Output Class Initialized
INFO - 2023-11-02 13:07:08 --> Security Class Initialized
DEBUG - 2023-11-02 13:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:07:08 --> Input Class Initialized
INFO - 2023-11-02 13:07:08 --> Language Class Initialized
INFO - 2023-11-02 13:07:08 --> Loader Class Initialized
INFO - 2023-11-02 13:07:08 --> Helper loaded: url_helper
INFO - 2023-11-02 13:07:08 --> Helper loaded: form_helper
INFO - 2023-11-02 13:07:08 --> Helper loaded: file_helper
INFO - 2023-11-02 13:07:08 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:07:08 --> Form Validation Class Initialized
INFO - 2023-11-02 13:07:08 --> Upload Class Initialized
INFO - 2023-11-02 13:07:08 --> Model "M_auth" initialized
INFO - 2023-11-02 13:07:08 --> Model "M_user" initialized
INFO - 2023-11-02 13:07:08 --> Model "M_produk" initialized
INFO - 2023-11-02 13:07:08 --> Controller Class Initialized
INFO - 2023-11-02 13:07:08 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:07:08 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:07:08 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:07:08 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:07:08 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:07:08 --> Model "M_bank" initialized
INFO - 2023-11-02 13:07:08 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:07:08 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:07:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:07:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 13:07:08 --> Final output sent to browser
DEBUG - 2023-11-02 13:07:08 --> Total execution time: 0.0031
ERROR - 2023-11-02 13:07:09 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:07:09 --> Config Class Initialized
INFO - 2023-11-02 13:07:09 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:07:09 --> UTF-8 Support Enabled
ERROR - 2023-11-02 13:07:09 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:07:09 --> Utf8 Class Initialized
INFO - 2023-11-02 13:07:09 --> Config Class Initialized
INFO - 2023-11-02 13:07:09 --> Hooks Class Initialized
INFO - 2023-11-02 13:07:09 --> URI Class Initialized
DEBUG - 2023-11-02 13:07:09 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:07:09 --> Router Class Initialized
INFO - 2023-11-02 13:07:09 --> Utf8 Class Initialized
INFO - 2023-11-02 13:07:09 --> Output Class Initialized
INFO - 2023-11-02 13:07:09 --> URI Class Initialized
INFO - 2023-11-02 13:07:09 --> Security Class Initialized
DEBUG - 2023-11-02 13:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:07:09 --> Router Class Initialized
INFO - 2023-11-02 13:07:09 --> Input Class Initialized
INFO - 2023-11-02 13:07:09 --> Output Class Initialized
INFO - 2023-11-02 13:07:09 --> Language Class Initialized
INFO - 2023-11-02 13:07:09 --> Security Class Initialized
INFO - 2023-11-02 13:07:09 --> Loader Class Initialized
DEBUG - 2023-11-02 13:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:07:09 --> Input Class Initialized
INFO - 2023-11-02 13:07:09 --> Language Class Initialized
INFO - 2023-11-02 13:07:09 --> Helper loaded: url_helper
INFO - 2023-11-02 13:07:09 --> Helper loaded: form_helper
INFO - 2023-11-02 13:07:09 --> Loader Class Initialized
INFO - 2023-11-02 13:07:09 --> Helper loaded: file_helper
INFO - 2023-11-02 13:07:09 --> Helper loaded: url_helper
INFO - 2023-11-02 13:07:09 --> Helper loaded: form_helper
INFO - 2023-11-02 13:07:09 --> Database Driver Class Initialized
INFO - 2023-11-02 13:07:09 --> Helper loaded: file_helper
INFO - 2023-11-02 13:07:09 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:07:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2023-11-02 13:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:07:09 --> Form Validation Class Initialized
INFO - 2023-11-02 13:07:09 --> Upload Class Initialized
INFO - 2023-11-02 13:07:09 --> Model "M_auth" initialized
INFO - 2023-11-02 13:07:09 --> Model "M_user" initialized
INFO - 2023-11-02 13:07:09 --> Model "M_produk" initialized
INFO - 2023-11-02 13:07:09 --> Controller Class Initialized
INFO - 2023-11-02 13:07:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:07:09 --> Final output sent to browser
DEBUG - 2023-11-02 13:07:09 --> Total execution time: 0.0029
INFO - 2023-11-02 13:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:07:09 --> Form Validation Class Initialized
INFO - 2023-11-02 13:07:09 --> Upload Class Initialized
INFO - 2023-11-02 13:07:09 --> Model "M_auth" initialized
INFO - 2023-11-02 13:07:09 --> Model "M_user" initialized
INFO - 2023-11-02 13:07:09 --> Model "M_produk" initialized
INFO - 2023-11-02 13:07:09 --> Controller Class Initialized
INFO - 2023-11-02 13:07:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:07:09 --> Final output sent to browser
DEBUG - 2023-11-02 13:07:09 --> Total execution time: 0.0033
ERROR - 2023-11-02 13:07:11 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:07:11 --> Config Class Initialized
INFO - 2023-11-02 13:07:11 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:07:11 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:07:11 --> Utf8 Class Initialized
INFO - 2023-11-02 13:07:11 --> URI Class Initialized
INFO - 2023-11-02 13:07:11 --> Router Class Initialized
INFO - 2023-11-02 13:07:11 --> Output Class Initialized
INFO - 2023-11-02 13:07:11 --> Security Class Initialized
DEBUG - 2023-11-02 13:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:07:11 --> Input Class Initialized
INFO - 2023-11-02 13:07:11 --> Language Class Initialized
INFO - 2023-11-02 13:07:11 --> Loader Class Initialized
INFO - 2023-11-02 13:07:11 --> Helper loaded: url_helper
INFO - 2023-11-02 13:07:11 --> Helper loaded: form_helper
INFO - 2023-11-02 13:07:11 --> Helper loaded: file_helper
INFO - 2023-11-02 13:07:11 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:07:11 --> Form Validation Class Initialized
INFO - 2023-11-02 13:07:11 --> Upload Class Initialized
INFO - 2023-11-02 13:07:11 --> Model "M_auth" initialized
INFO - 2023-11-02 13:07:11 --> Model "M_user" initialized
INFO - 2023-11-02 13:07:11 --> Model "M_produk" initialized
INFO - 2023-11-02 13:07:11 --> Controller Class Initialized
INFO - 2023-11-02 13:07:11 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:07:11 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:07:11 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:07:11 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:07:11 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:07:11 --> Model "M_bank" initialized
INFO - 2023-11-02 13:07:11 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:07:11 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:07:11 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:07:11 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-02 13:07:11 --> Final output sent to browser
DEBUG - 2023-11-02 13:07:11 --> Total execution time: 0.0040
ERROR - 2023-11-02 13:07:12 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:07:12 --> Config Class Initialized
INFO - 2023-11-02 13:07:12 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:07:12 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:07:12 --> Utf8 Class Initialized
INFO - 2023-11-02 13:07:12 --> URI Class Initialized
INFO - 2023-11-02 13:07:12 --> Router Class Initialized
INFO - 2023-11-02 13:07:12 --> Output Class Initialized
INFO - 2023-11-02 13:07:12 --> Security Class Initialized
DEBUG - 2023-11-02 13:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:07:12 --> Input Class Initialized
INFO - 2023-11-02 13:07:12 --> Language Class Initialized
INFO - 2023-11-02 13:07:12 --> Loader Class Initialized
INFO - 2023-11-02 13:07:12 --> Helper loaded: url_helper
INFO - 2023-11-02 13:07:12 --> Helper loaded: form_helper
INFO - 2023-11-02 13:07:12 --> Helper loaded: file_helper
INFO - 2023-11-02 13:07:12 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:07:12 --> Form Validation Class Initialized
INFO - 2023-11-02 13:07:12 --> Upload Class Initialized
INFO - 2023-11-02 13:07:12 --> Model "M_auth" initialized
INFO - 2023-11-02 13:07:12 --> Model "M_user" initialized
INFO - 2023-11-02 13:07:12 --> Model "M_produk" initialized
INFO - 2023-11-02 13:07:12 --> Controller Class Initialized
INFO - 2023-11-02 13:07:12 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:07:12 --> Final output sent to browser
DEBUG - 2023-11-02 13:07:12 --> Total execution time: 0.0022
ERROR - 2023-11-02 13:07:13 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:07:13 --> Config Class Initialized
INFO - 2023-11-02 13:07:13 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:07:13 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:07:13 --> Utf8 Class Initialized
INFO - 2023-11-02 13:07:13 --> URI Class Initialized
INFO - 2023-11-02 13:07:13 --> Router Class Initialized
INFO - 2023-11-02 13:07:13 --> Output Class Initialized
INFO - 2023-11-02 13:07:13 --> Security Class Initialized
DEBUG - 2023-11-02 13:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:07:13 --> Input Class Initialized
INFO - 2023-11-02 13:07:13 --> Language Class Initialized
INFO - 2023-11-02 13:07:13 --> Loader Class Initialized
INFO - 2023-11-02 13:07:13 --> Helper loaded: url_helper
INFO - 2023-11-02 13:07:13 --> Helper loaded: form_helper
INFO - 2023-11-02 13:07:13 --> Helper loaded: file_helper
INFO - 2023-11-02 13:07:13 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:07:13 --> Form Validation Class Initialized
INFO - 2023-11-02 13:07:13 --> Upload Class Initialized
INFO - 2023-11-02 13:07:13 --> Model "M_auth" initialized
INFO - 2023-11-02 13:07:13 --> Model "M_user" initialized
INFO - 2023-11-02 13:07:13 --> Model "M_produk" initialized
INFO - 2023-11-02 13:07:13 --> Controller Class Initialized
INFO - 2023-11-02 13:07:13 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:07:13 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:07:13 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:07:13 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:07:13 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:07:13 --> Model "M_bank" initialized
INFO - 2023-11-02 13:07:13 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:07:13 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:07:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:07:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-02 13:07:13 --> Final output sent to browser
DEBUG - 2023-11-02 13:07:13 --> Total execution time: 0.0037
ERROR - 2023-11-02 13:07:13 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:07:13 --> Config Class Initialized
INFO - 2023-11-02 13:07:13 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:07:13 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:07:13 --> Utf8 Class Initialized
INFO - 2023-11-02 13:07:13 --> URI Class Initialized
INFO - 2023-11-02 13:07:13 --> Router Class Initialized
INFO - 2023-11-02 13:07:13 --> Output Class Initialized
INFO - 2023-11-02 13:07:13 --> Security Class Initialized
DEBUG - 2023-11-02 13:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:07:13 --> Input Class Initialized
INFO - 2023-11-02 13:07:13 --> Language Class Initialized
INFO - 2023-11-02 13:07:13 --> Loader Class Initialized
INFO - 2023-11-02 13:07:13 --> Helper loaded: url_helper
INFO - 2023-11-02 13:07:13 --> Helper loaded: form_helper
INFO - 2023-11-02 13:07:13 --> Helper loaded: file_helper
INFO - 2023-11-02 13:07:13 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:07:13 --> Form Validation Class Initialized
INFO - 2023-11-02 13:07:13 --> Upload Class Initialized
INFO - 2023-11-02 13:07:13 --> Model "M_auth" initialized
INFO - 2023-11-02 13:07:13 --> Model "M_user" initialized
INFO - 2023-11-02 13:07:13 --> Model "M_produk" initialized
INFO - 2023-11-02 13:07:13 --> Controller Class Initialized
INFO - 2023-11-02 13:07:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:07:13 --> Final output sent to browser
DEBUG - 2023-11-02 13:07:13 --> Total execution time: 0.0024
ERROR - 2023-11-02 13:07:20 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:07:20 --> Config Class Initialized
INFO - 2023-11-02 13:07:20 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:07:20 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:07:20 --> Utf8 Class Initialized
INFO - 2023-11-02 13:07:20 --> URI Class Initialized
INFO - 2023-11-02 13:07:20 --> Router Class Initialized
INFO - 2023-11-02 13:07:20 --> Output Class Initialized
INFO - 2023-11-02 13:07:20 --> Security Class Initialized
DEBUG - 2023-11-02 13:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:07:20 --> Input Class Initialized
INFO - 2023-11-02 13:07:20 --> Language Class Initialized
INFO - 2023-11-02 13:07:20 --> Loader Class Initialized
INFO - 2023-11-02 13:07:20 --> Helper loaded: url_helper
INFO - 2023-11-02 13:07:20 --> Helper loaded: form_helper
INFO - 2023-11-02 13:07:20 --> Helper loaded: file_helper
INFO - 2023-11-02 13:07:20 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:07:20 --> Form Validation Class Initialized
INFO - 2023-11-02 13:07:20 --> Upload Class Initialized
INFO - 2023-11-02 13:07:20 --> Model "M_auth" initialized
INFO - 2023-11-02 13:07:20 --> Model "M_user" initialized
INFO - 2023-11-02 13:07:20 --> Model "M_produk" initialized
INFO - 2023-11-02 13:07:20 --> Controller Class Initialized
INFO - 2023-11-02 13:07:20 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:07:20 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:07:20 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:07:20 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:07:20 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:07:20 --> Model "M_bank" initialized
INFO - 2023-11-02 13:07:20 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:07:20 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:07:20 --> Email Class Initialized
INFO - 2023-11-02 13:07:21 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-11-02 13:07:23 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:07:23 --> Config Class Initialized
INFO - 2023-11-02 13:07:23 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:07:23 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:07:23 --> Utf8 Class Initialized
INFO - 2023-11-02 13:07:23 --> URI Class Initialized
INFO - 2023-11-02 13:07:23 --> Router Class Initialized
INFO - 2023-11-02 13:07:23 --> Output Class Initialized
INFO - 2023-11-02 13:07:23 --> Security Class Initialized
DEBUG - 2023-11-02 13:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:07:23 --> Input Class Initialized
INFO - 2023-11-02 13:07:23 --> Language Class Initialized
INFO - 2023-11-02 13:07:23 --> Loader Class Initialized
INFO - 2023-11-02 13:07:23 --> Helper loaded: url_helper
INFO - 2023-11-02 13:07:23 --> Helper loaded: form_helper
INFO - 2023-11-02 13:07:23 --> Helper loaded: file_helper
INFO - 2023-11-02 13:07:23 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:07:23 --> Form Validation Class Initialized
INFO - 2023-11-02 13:07:23 --> Upload Class Initialized
INFO - 2023-11-02 13:07:23 --> Model "M_auth" initialized
INFO - 2023-11-02 13:07:23 --> Model "M_user" initialized
INFO - 2023-11-02 13:07:23 --> Model "M_produk" initialized
INFO - 2023-11-02 13:07:23 --> Controller Class Initialized
INFO - 2023-11-02 13:07:23 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:07:23 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:07:23 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:07:23 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:07:23 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:07:23 --> Model "M_bank" initialized
INFO - 2023-11-02 13:07:23 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:07:23 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:07:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:07:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:07:24 --> Final output sent to browser
DEBUG - 2023-11-02 13:07:24 --> Total execution time: 0.6882
ERROR - 2023-11-02 13:07:24 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:07:24 --> Config Class Initialized
INFO - 2023-11-02 13:07:24 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:07:24 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:07:24 --> Utf8 Class Initialized
INFO - 2023-11-02 13:07:24 --> URI Class Initialized
INFO - 2023-11-02 13:07:24 --> Router Class Initialized
INFO - 2023-11-02 13:07:24 --> Output Class Initialized
INFO - 2023-11-02 13:07:24 --> Security Class Initialized
DEBUG - 2023-11-02 13:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:07:24 --> Input Class Initialized
INFO - 2023-11-02 13:07:24 --> Language Class Initialized
INFO - 2023-11-02 13:07:24 --> Loader Class Initialized
INFO - 2023-11-02 13:07:24 --> Helper loaded: url_helper
INFO - 2023-11-02 13:07:24 --> Helper loaded: form_helper
INFO - 2023-11-02 13:07:24 --> Helper loaded: file_helper
INFO - 2023-11-02 13:07:24 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:07:24 --> Form Validation Class Initialized
INFO - 2023-11-02 13:07:24 --> Upload Class Initialized
INFO - 2023-11-02 13:07:24 --> Model "M_auth" initialized
INFO - 2023-11-02 13:07:24 --> Model "M_user" initialized
INFO - 2023-11-02 13:07:24 --> Model "M_produk" initialized
INFO - 2023-11-02 13:07:24 --> Controller Class Initialized
INFO - 2023-11-02 13:07:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:07:24 --> Final output sent to browser
DEBUG - 2023-11-02 13:07:24 --> Total execution time: 0.0035
ERROR - 2023-11-02 13:07:26 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:07:26 --> Config Class Initialized
INFO - 2023-11-02 13:07:26 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:07:26 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:07:26 --> Utf8 Class Initialized
INFO - 2023-11-02 13:07:26 --> URI Class Initialized
DEBUG - 2023-11-02 13:07:26 --> No URI present. Default controller set.
INFO - 2023-11-02 13:07:26 --> Router Class Initialized
INFO - 2023-11-02 13:07:26 --> Output Class Initialized
INFO - 2023-11-02 13:07:26 --> Security Class Initialized
DEBUG - 2023-11-02 13:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:07:26 --> Input Class Initialized
INFO - 2023-11-02 13:07:26 --> Language Class Initialized
INFO - 2023-11-02 13:07:26 --> Loader Class Initialized
INFO - 2023-11-02 13:07:26 --> Helper loaded: url_helper
INFO - 2023-11-02 13:07:26 --> Helper loaded: form_helper
INFO - 2023-11-02 13:07:26 --> Helper loaded: file_helper
INFO - 2023-11-02 13:07:26 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:07:26 --> Form Validation Class Initialized
INFO - 2023-11-02 13:07:26 --> Upload Class Initialized
INFO - 2023-11-02 13:07:26 --> Model "M_auth" initialized
INFO - 2023-11-02 13:07:26 --> Model "M_user" initialized
INFO - 2023-11-02 13:07:26 --> Model "M_produk" initialized
INFO - 2023-11-02 13:07:26 --> Controller Class Initialized
INFO - 2023-11-02 13:07:26 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:07:26 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:07:26 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:07:26 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:07:26 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:07:26 --> Model "M_bank" initialized
INFO - 2023-11-02 13:07:26 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:07:26 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:07:26 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:07:26 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 13:07:26 --> Final output sent to browser
DEBUG - 2023-11-02 13:07:26 --> Total execution time: 0.0034
ERROR - 2023-11-02 13:07:26 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:07:26 --> Config Class Initialized
INFO - 2023-11-02 13:07:26 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:07:26 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:07:26 --> Utf8 Class Initialized
INFO - 2023-11-02 13:07:26 --> URI Class Initialized
INFO - 2023-11-02 13:07:26 --> Router Class Initialized
INFO - 2023-11-02 13:07:26 --> Output Class Initialized
INFO - 2023-11-02 13:07:26 --> Security Class Initialized
DEBUG - 2023-11-02 13:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:07:26 --> Input Class Initialized
INFO - 2023-11-02 13:07:26 --> Language Class Initialized
INFO - 2023-11-02 13:07:26 --> Loader Class Initialized
INFO - 2023-11-02 13:07:26 --> Helper loaded: url_helper
INFO - 2023-11-02 13:07:26 --> Helper loaded: form_helper
INFO - 2023-11-02 13:07:26 --> Helper loaded: file_helper
INFO - 2023-11-02 13:07:26 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:07:26 --> Form Validation Class Initialized
INFO - 2023-11-02 13:07:26 --> Upload Class Initialized
INFO - 2023-11-02 13:07:26 --> Model "M_auth" initialized
INFO - 2023-11-02 13:07:26 --> Model "M_user" initialized
INFO - 2023-11-02 13:07:26 --> Model "M_produk" initialized
INFO - 2023-11-02 13:07:26 --> Controller Class Initialized
INFO - 2023-11-02 13:07:26 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:07:26 --> Final output sent to browser
DEBUG - 2023-11-02 13:07:26 --> Total execution time: 0.0026
ERROR - 2023-11-02 13:07:26 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:07:26 --> Config Class Initialized
INFO - 2023-11-02 13:07:26 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:07:26 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:07:26 --> Utf8 Class Initialized
INFO - 2023-11-02 13:07:26 --> URI Class Initialized
INFO - 2023-11-02 13:07:26 --> Router Class Initialized
INFO - 2023-11-02 13:07:26 --> Output Class Initialized
INFO - 2023-11-02 13:07:26 --> Security Class Initialized
DEBUG - 2023-11-02 13:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:07:26 --> Input Class Initialized
INFO - 2023-11-02 13:07:26 --> Language Class Initialized
INFO - 2023-11-02 13:07:26 --> Loader Class Initialized
INFO - 2023-11-02 13:07:26 --> Helper loaded: url_helper
INFO - 2023-11-02 13:07:26 --> Helper loaded: form_helper
INFO - 2023-11-02 13:07:26 --> Helper loaded: file_helper
INFO - 2023-11-02 13:07:26 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:07:26 --> Form Validation Class Initialized
INFO - 2023-11-02 13:07:26 --> Upload Class Initialized
INFO - 2023-11-02 13:07:26 --> Model "M_auth" initialized
INFO - 2023-11-02 13:07:26 --> Model "M_user" initialized
INFO - 2023-11-02 13:07:26 --> Model "M_produk" initialized
INFO - 2023-11-02 13:07:26 --> Controller Class Initialized
INFO - 2023-11-02 13:07:26 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:07:26 --> Final output sent to browser
DEBUG - 2023-11-02 13:07:26 --> Total execution time: 0.0017
ERROR - 2023-11-02 13:07:29 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:07:29 --> Config Class Initialized
INFO - 2023-11-02 13:07:29 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:07:29 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:07:29 --> Utf8 Class Initialized
INFO - 2023-11-02 13:07:29 --> URI Class Initialized
INFO - 2023-11-02 13:07:29 --> Router Class Initialized
INFO - 2023-11-02 13:07:29 --> Output Class Initialized
INFO - 2023-11-02 13:07:29 --> Security Class Initialized
DEBUG - 2023-11-02 13:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:07:29 --> Input Class Initialized
INFO - 2023-11-02 13:07:29 --> Language Class Initialized
INFO - 2023-11-02 13:07:29 --> Loader Class Initialized
INFO - 2023-11-02 13:07:29 --> Helper loaded: url_helper
INFO - 2023-11-02 13:07:29 --> Helper loaded: form_helper
INFO - 2023-11-02 13:07:29 --> Helper loaded: file_helper
INFO - 2023-11-02 13:07:29 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:07:29 --> Form Validation Class Initialized
INFO - 2023-11-02 13:07:29 --> Upload Class Initialized
INFO - 2023-11-02 13:07:29 --> Model "M_auth" initialized
INFO - 2023-11-02 13:07:29 --> Model "M_user" initialized
INFO - 2023-11-02 13:07:29 --> Model "M_produk" initialized
INFO - 2023-11-02 13:07:29 --> Controller Class Initialized
INFO - 2023-11-02 13:07:29 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:07:29 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:07:29 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:07:29 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:07:29 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:07:29 --> Model "M_bank" initialized
INFO - 2023-11-02 13:07:29 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:07:29 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:07:29 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:07:29 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-02 13:07:29 --> Final output sent to browser
DEBUG - 2023-11-02 13:07:29 --> Total execution time: 0.0042
ERROR - 2023-11-02 13:07:29 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:07:29 --> Config Class Initialized
INFO - 2023-11-02 13:07:29 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:07:29 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:07:29 --> Utf8 Class Initialized
INFO - 2023-11-02 13:07:29 --> URI Class Initialized
INFO - 2023-11-02 13:07:29 --> Router Class Initialized
INFO - 2023-11-02 13:07:29 --> Output Class Initialized
INFO - 2023-11-02 13:07:29 --> Security Class Initialized
DEBUG - 2023-11-02 13:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:07:29 --> Input Class Initialized
INFO - 2023-11-02 13:07:29 --> Language Class Initialized
INFO - 2023-11-02 13:07:29 --> Loader Class Initialized
INFO - 2023-11-02 13:07:29 --> Helper loaded: url_helper
INFO - 2023-11-02 13:07:29 --> Helper loaded: form_helper
INFO - 2023-11-02 13:07:29 --> Helper loaded: file_helper
INFO - 2023-11-02 13:07:29 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:07:29 --> Form Validation Class Initialized
INFO - 2023-11-02 13:07:29 --> Upload Class Initialized
INFO - 2023-11-02 13:07:29 --> Model "M_auth" initialized
INFO - 2023-11-02 13:07:29 --> Model "M_user" initialized
INFO - 2023-11-02 13:07:29 --> Model "M_produk" initialized
INFO - 2023-11-02 13:07:29 --> Controller Class Initialized
INFO - 2023-11-02 13:07:29 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:07:29 --> Final output sent to browser
DEBUG - 2023-11-02 13:07:29 --> Total execution time: 0.0026
ERROR - 2023-11-02 13:07:36 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:07:36 --> Config Class Initialized
INFO - 2023-11-02 13:07:36 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:07:36 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:07:36 --> Utf8 Class Initialized
INFO - 2023-11-02 13:07:36 --> URI Class Initialized
INFO - 2023-11-02 13:07:36 --> Router Class Initialized
INFO - 2023-11-02 13:07:36 --> Output Class Initialized
INFO - 2023-11-02 13:07:36 --> Security Class Initialized
DEBUG - 2023-11-02 13:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:07:36 --> Input Class Initialized
INFO - 2023-11-02 13:07:36 --> Language Class Initialized
INFO - 2023-11-02 13:07:36 --> Loader Class Initialized
INFO - 2023-11-02 13:07:36 --> Helper loaded: url_helper
INFO - 2023-11-02 13:07:36 --> Helper loaded: form_helper
INFO - 2023-11-02 13:07:36 --> Helper loaded: file_helper
INFO - 2023-11-02 13:07:36 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:07:36 --> Form Validation Class Initialized
INFO - 2023-11-02 13:07:36 --> Upload Class Initialized
INFO - 2023-11-02 13:07:36 --> Model "M_auth" initialized
INFO - 2023-11-02 13:07:36 --> Model "M_user" initialized
INFO - 2023-11-02 13:07:36 --> Model "M_produk" initialized
INFO - 2023-11-02 13:07:36 --> Controller Class Initialized
INFO - 2023-11-02 13:07:36 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:07:36 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:07:36 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:07:36 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:07:36 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:07:36 --> Model "M_bank" initialized
INFO - 2023-11-02 13:07:36 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:07:36 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:07:36 --> Email Class Initialized
INFO - 2023-11-02 13:07:37 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-11-02 13:07:39 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:07:39 --> Config Class Initialized
INFO - 2023-11-02 13:07:39 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:07:39 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:07:39 --> Utf8 Class Initialized
INFO - 2023-11-02 13:07:39 --> URI Class Initialized
INFO - 2023-11-02 13:07:39 --> Router Class Initialized
INFO - 2023-11-02 13:07:39 --> Output Class Initialized
INFO - 2023-11-02 13:07:39 --> Security Class Initialized
DEBUG - 2023-11-02 13:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:07:39 --> Input Class Initialized
INFO - 2023-11-02 13:07:39 --> Language Class Initialized
INFO - 2023-11-02 13:07:39 --> Loader Class Initialized
INFO - 2023-11-02 13:07:39 --> Helper loaded: url_helper
INFO - 2023-11-02 13:07:39 --> Helper loaded: form_helper
INFO - 2023-11-02 13:07:39 --> Helper loaded: file_helper
INFO - 2023-11-02 13:07:39 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:07:39 --> Form Validation Class Initialized
INFO - 2023-11-02 13:07:39 --> Upload Class Initialized
INFO - 2023-11-02 13:07:39 --> Model "M_auth" initialized
INFO - 2023-11-02 13:07:39 --> Model "M_user" initialized
INFO - 2023-11-02 13:07:39 --> Model "M_produk" initialized
INFO - 2023-11-02 13:07:39 --> Controller Class Initialized
INFO - 2023-11-02 13:07:39 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:07:39 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:07:39 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:07:39 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:07:39 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:07:39 --> Model "M_bank" initialized
INFO - 2023-11-02 13:07:39 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:07:39 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:07:40 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:07:40 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:07:40 --> Final output sent to browser
DEBUG - 2023-11-02 13:07:40 --> Total execution time: 0.6833
ERROR - 2023-11-02 13:07:40 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:07:40 --> Config Class Initialized
INFO - 2023-11-02 13:07:40 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:07:40 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:07:40 --> Utf8 Class Initialized
INFO - 2023-11-02 13:07:40 --> URI Class Initialized
INFO - 2023-11-02 13:07:40 --> Router Class Initialized
INFO - 2023-11-02 13:07:40 --> Output Class Initialized
INFO - 2023-11-02 13:07:40 --> Security Class Initialized
DEBUG - 2023-11-02 13:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:07:40 --> Input Class Initialized
INFO - 2023-11-02 13:07:40 --> Language Class Initialized
INFO - 2023-11-02 13:07:40 --> Loader Class Initialized
INFO - 2023-11-02 13:07:40 --> Helper loaded: url_helper
INFO - 2023-11-02 13:07:40 --> Helper loaded: form_helper
INFO - 2023-11-02 13:07:40 --> Helper loaded: file_helper
INFO - 2023-11-02 13:07:40 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:07:40 --> Form Validation Class Initialized
INFO - 2023-11-02 13:07:40 --> Upload Class Initialized
INFO - 2023-11-02 13:07:40 --> Model "M_auth" initialized
INFO - 2023-11-02 13:07:40 --> Model "M_user" initialized
INFO - 2023-11-02 13:07:40 --> Model "M_produk" initialized
INFO - 2023-11-02 13:07:40 --> Controller Class Initialized
INFO - 2023-11-02 13:07:40 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:07:40 --> Final output sent to browser
DEBUG - 2023-11-02 13:07:40 --> Total execution time: 0.0039
ERROR - 2023-11-02 13:07:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:07:45 --> Config Class Initialized
INFO - 2023-11-02 13:07:45 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:07:45 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:07:45 --> Utf8 Class Initialized
INFO - 2023-11-02 13:07:45 --> URI Class Initialized
INFO - 2023-11-02 13:07:45 --> Router Class Initialized
INFO - 2023-11-02 13:07:45 --> Output Class Initialized
INFO - 2023-11-02 13:07:45 --> Security Class Initialized
DEBUG - 2023-11-02 13:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:07:45 --> Input Class Initialized
INFO - 2023-11-02 13:07:45 --> Language Class Initialized
INFO - 2023-11-02 13:07:45 --> Loader Class Initialized
INFO - 2023-11-02 13:07:45 --> Helper loaded: url_helper
INFO - 2023-11-02 13:07:45 --> Helper loaded: form_helper
INFO - 2023-11-02 13:07:45 --> Helper loaded: file_helper
INFO - 2023-11-02 13:07:45 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:07:45 --> Form Validation Class Initialized
INFO - 2023-11-02 13:07:45 --> Upload Class Initialized
INFO - 2023-11-02 13:07:45 --> Model "M_auth" initialized
INFO - 2023-11-02 13:07:45 --> Model "M_user" initialized
INFO - 2023-11-02 13:07:45 --> Model "M_produk" initialized
INFO - 2023-11-02 13:07:45 --> Controller Class Initialized
INFO - 2023-11-02 13:07:45 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:07:45 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:07:45 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:07:45 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:07:45 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:07:45 --> Model "M_bank" initialized
INFO - 2023-11-02 13:07:45 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:07:45 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:07:46 --> Final output sent to browser
DEBUG - 2023-11-02 13:07:46 --> Total execution time: 0.7233
ERROR - 2023-11-02 13:07:54 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:07:54 --> Config Class Initialized
INFO - 2023-11-02 13:07:54 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:07:54 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:07:54 --> Utf8 Class Initialized
INFO - 2023-11-02 13:07:54 --> URI Class Initialized
INFO - 2023-11-02 13:07:54 --> Router Class Initialized
INFO - 2023-11-02 13:07:54 --> Output Class Initialized
INFO - 2023-11-02 13:07:54 --> Security Class Initialized
DEBUG - 2023-11-02 13:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:07:54 --> Input Class Initialized
INFO - 2023-11-02 13:07:54 --> Language Class Initialized
INFO - 2023-11-02 13:07:54 --> Loader Class Initialized
INFO - 2023-11-02 13:07:54 --> Helper loaded: url_helper
INFO - 2023-11-02 13:07:54 --> Helper loaded: form_helper
INFO - 2023-11-02 13:07:54 --> Helper loaded: file_helper
INFO - 2023-11-02 13:07:54 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:07:54 --> Form Validation Class Initialized
INFO - 2023-11-02 13:07:54 --> Upload Class Initialized
INFO - 2023-11-02 13:07:54 --> Model "M_auth" initialized
INFO - 2023-11-02 13:07:54 --> Model "M_user" initialized
INFO - 2023-11-02 13:07:54 --> Model "M_produk" initialized
INFO - 2023-11-02 13:07:54 --> Controller Class Initialized
INFO - 2023-11-02 13:07:54 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:07:54 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:07:54 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:07:54 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:07:54 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:07:54 --> Model "M_bank" initialized
INFO - 2023-11-02 13:07:54 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:07:54 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:07:55 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:07:55 --> Final output sent to browser
DEBUG - 2023-11-02 13:07:55 --> Total execution time: 0.6860
ERROR - 2023-11-02 13:08:51 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:08:51 --> Config Class Initialized
INFO - 2023-11-02 13:08:51 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:08:51 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:08:51 --> Utf8 Class Initialized
INFO - 2023-11-02 13:08:51 --> URI Class Initialized
INFO - 2023-11-02 13:08:51 --> Router Class Initialized
INFO - 2023-11-02 13:08:51 --> Output Class Initialized
INFO - 2023-11-02 13:08:51 --> Security Class Initialized
DEBUG - 2023-11-02 13:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:08:51 --> Input Class Initialized
INFO - 2023-11-02 13:08:51 --> Language Class Initialized
INFO - 2023-11-02 13:08:51 --> Loader Class Initialized
INFO - 2023-11-02 13:08:51 --> Helper loaded: url_helper
INFO - 2023-11-02 13:08:51 --> Helper loaded: form_helper
INFO - 2023-11-02 13:08:51 --> Helper loaded: file_helper
INFO - 2023-11-02 13:08:51 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:08:51 --> Form Validation Class Initialized
INFO - 2023-11-02 13:08:51 --> Upload Class Initialized
INFO - 2023-11-02 13:08:51 --> Model "M_auth" initialized
INFO - 2023-11-02 13:08:51 --> Model "M_user" initialized
INFO - 2023-11-02 13:08:51 --> Model "M_produk" initialized
INFO - 2023-11-02 13:08:51 --> Controller Class Initialized
INFO - 2023-11-02 13:08:51 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:08:51 --> Final output sent to browser
DEBUG - 2023-11-02 13:08:51 --> Total execution time: 0.0030
ERROR - 2023-11-02 13:09:00 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:09:00 --> Config Class Initialized
INFO - 2023-11-02 13:09:00 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:09:00 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:09:00 --> Utf8 Class Initialized
INFO - 2023-11-02 13:09:00 --> URI Class Initialized
DEBUG - 2023-11-02 13:09:00 --> No URI present. Default controller set.
INFO - 2023-11-02 13:09:00 --> Router Class Initialized
INFO - 2023-11-02 13:09:00 --> Output Class Initialized
INFO - 2023-11-02 13:09:00 --> Security Class Initialized
DEBUG - 2023-11-02 13:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:09:00 --> Input Class Initialized
INFO - 2023-11-02 13:09:00 --> Language Class Initialized
INFO - 2023-11-02 13:09:00 --> Loader Class Initialized
INFO - 2023-11-02 13:09:00 --> Helper loaded: url_helper
INFO - 2023-11-02 13:09:00 --> Helper loaded: form_helper
INFO - 2023-11-02 13:09:00 --> Helper loaded: file_helper
INFO - 2023-11-02 13:09:00 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:09:00 --> Form Validation Class Initialized
INFO - 2023-11-02 13:09:00 --> Upload Class Initialized
INFO - 2023-11-02 13:09:00 --> Model "M_auth" initialized
INFO - 2023-11-02 13:09:00 --> Model "M_user" initialized
INFO - 2023-11-02 13:09:00 --> Model "M_produk" initialized
INFO - 2023-11-02 13:09:00 --> Controller Class Initialized
INFO - 2023-11-02 13:09:00 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:09:00 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:09:00 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:09:00 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:09:00 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:09:00 --> Model "M_bank" initialized
INFO - 2023-11-02 13:09:00 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:09:00 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:09:00 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:09:00 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 13:09:00 --> Final output sent to browser
DEBUG - 2023-11-02 13:09:00 --> Total execution time: 0.0050
ERROR - 2023-11-02 13:09:00 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:09:00 --> Config Class Initialized
INFO - 2023-11-02 13:09:00 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:09:00 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:09:00 --> Utf8 Class Initialized
INFO - 2023-11-02 13:09:00 --> URI Class Initialized
INFO - 2023-11-02 13:09:00 --> Router Class Initialized
INFO - 2023-11-02 13:09:00 --> Output Class Initialized
INFO - 2023-11-02 13:09:00 --> Security Class Initialized
DEBUG - 2023-11-02 13:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:09:00 --> Input Class Initialized
INFO - 2023-11-02 13:09:00 --> Language Class Initialized
INFO - 2023-11-02 13:09:00 --> Loader Class Initialized
INFO - 2023-11-02 13:09:00 --> Helper loaded: url_helper
INFO - 2023-11-02 13:09:00 --> Helper loaded: form_helper
INFO - 2023-11-02 13:09:00 --> Helper loaded: file_helper
INFO - 2023-11-02 13:09:00 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:09:00 --> Form Validation Class Initialized
INFO - 2023-11-02 13:09:00 --> Upload Class Initialized
INFO - 2023-11-02 13:09:00 --> Model "M_auth" initialized
INFO - 2023-11-02 13:09:00 --> Model "M_user" initialized
INFO - 2023-11-02 13:09:00 --> Model "M_produk" initialized
INFO - 2023-11-02 13:09:00 --> Controller Class Initialized
INFO - 2023-11-02 13:09:00 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:09:00 --> Final output sent to browser
DEBUG - 2023-11-02 13:09:00 --> Total execution time: 0.0031
ERROR - 2023-11-02 13:09:00 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:09:00 --> Config Class Initialized
INFO - 2023-11-02 13:09:00 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:09:00 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:09:00 --> Utf8 Class Initialized
INFO - 2023-11-02 13:09:00 --> URI Class Initialized
INFO - 2023-11-02 13:09:00 --> Router Class Initialized
INFO - 2023-11-02 13:09:00 --> Output Class Initialized
INFO - 2023-11-02 13:09:00 --> Security Class Initialized
DEBUG - 2023-11-02 13:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:09:00 --> Input Class Initialized
INFO - 2023-11-02 13:09:00 --> Language Class Initialized
INFO - 2023-11-02 13:09:00 --> Loader Class Initialized
INFO - 2023-11-02 13:09:00 --> Helper loaded: url_helper
INFO - 2023-11-02 13:09:00 --> Helper loaded: form_helper
INFO - 2023-11-02 13:09:00 --> Helper loaded: file_helper
INFO - 2023-11-02 13:09:00 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:09:00 --> Form Validation Class Initialized
INFO - 2023-11-02 13:09:00 --> Upload Class Initialized
INFO - 2023-11-02 13:09:00 --> Model "M_auth" initialized
INFO - 2023-11-02 13:09:00 --> Model "M_user" initialized
INFO - 2023-11-02 13:09:00 --> Model "M_produk" initialized
INFO - 2023-11-02 13:09:00 --> Controller Class Initialized
INFO - 2023-11-02 13:09:00 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:09:00 --> Final output sent to browser
DEBUG - 2023-11-02 13:09:00 --> Total execution time: 0.0026
ERROR - 2023-11-02 13:09:02 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:09:02 --> Config Class Initialized
INFO - 2023-11-02 13:09:02 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:09:02 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:09:02 --> Utf8 Class Initialized
INFO - 2023-11-02 13:09:02 --> URI Class Initialized
INFO - 2023-11-02 13:09:02 --> Router Class Initialized
INFO - 2023-11-02 13:09:02 --> Output Class Initialized
INFO - 2023-11-02 13:09:02 --> Security Class Initialized
DEBUG - 2023-11-02 13:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:09:02 --> Input Class Initialized
INFO - 2023-11-02 13:09:02 --> Language Class Initialized
INFO - 2023-11-02 13:09:02 --> Loader Class Initialized
INFO - 2023-11-02 13:09:02 --> Helper loaded: url_helper
INFO - 2023-11-02 13:09:02 --> Helper loaded: form_helper
INFO - 2023-11-02 13:09:02 --> Helper loaded: file_helper
INFO - 2023-11-02 13:09:02 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:09:02 --> Form Validation Class Initialized
INFO - 2023-11-02 13:09:02 --> Upload Class Initialized
INFO - 2023-11-02 13:09:02 --> Model "M_auth" initialized
INFO - 2023-11-02 13:09:02 --> Model "M_user" initialized
INFO - 2023-11-02 13:09:02 --> Model "M_produk" initialized
INFO - 2023-11-02 13:09:02 --> Controller Class Initialized
INFO - 2023-11-02 13:09:02 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:09:02 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:09:02 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:09:02 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:09:02 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:09:02 --> Model "M_bank" initialized
INFO - 2023-11-02 13:09:02 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:09:02 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:09:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:09:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:09:02 --> Final output sent to browser
DEBUG - 2023-11-02 13:09:02 --> Total execution time: 0.7022
ERROR - 2023-11-02 13:09:17 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:09:17 --> Config Class Initialized
INFO - 2023-11-02 13:09:17 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:09:17 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:09:17 --> Utf8 Class Initialized
INFO - 2023-11-02 13:09:17 --> URI Class Initialized
DEBUG - 2023-11-02 13:09:17 --> No URI present. Default controller set.
INFO - 2023-11-02 13:09:17 --> Router Class Initialized
INFO - 2023-11-02 13:09:17 --> Output Class Initialized
INFO - 2023-11-02 13:09:17 --> Security Class Initialized
DEBUG - 2023-11-02 13:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:09:17 --> Input Class Initialized
INFO - 2023-11-02 13:09:17 --> Language Class Initialized
INFO - 2023-11-02 13:09:17 --> Loader Class Initialized
INFO - 2023-11-02 13:09:17 --> Helper loaded: url_helper
INFO - 2023-11-02 13:09:17 --> Helper loaded: form_helper
INFO - 2023-11-02 13:09:17 --> Helper loaded: file_helper
INFO - 2023-11-02 13:09:17 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:09:17 --> Form Validation Class Initialized
INFO - 2023-11-02 13:09:17 --> Upload Class Initialized
INFO - 2023-11-02 13:09:17 --> Model "M_auth" initialized
INFO - 2023-11-02 13:09:17 --> Model "M_user" initialized
INFO - 2023-11-02 13:09:17 --> Model "M_produk" initialized
INFO - 2023-11-02 13:09:17 --> Controller Class Initialized
INFO - 2023-11-02 13:09:17 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:09:17 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:09:17 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:09:17 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:09:17 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:09:17 --> Model "M_bank" initialized
INFO - 2023-11-02 13:09:17 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:09:17 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:09:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:09:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 13:09:17 --> Final output sent to browser
DEBUG - 2023-11-02 13:09:17 --> Total execution time: 0.0036
ERROR - 2023-11-02 13:09:17 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:09:17 --> Config Class Initialized
INFO - 2023-11-02 13:09:17 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:09:17 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:09:17 --> Utf8 Class Initialized
INFO - 2023-11-02 13:09:17 --> URI Class Initialized
INFO - 2023-11-02 13:09:17 --> Router Class Initialized
INFO - 2023-11-02 13:09:17 --> Output Class Initialized
INFO - 2023-11-02 13:09:17 --> Security Class Initialized
DEBUG - 2023-11-02 13:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:09:17 --> Input Class Initialized
INFO - 2023-11-02 13:09:17 --> Language Class Initialized
INFO - 2023-11-02 13:09:17 --> Loader Class Initialized
INFO - 2023-11-02 13:09:17 --> Helper loaded: url_helper
INFO - 2023-11-02 13:09:17 --> Helper loaded: form_helper
INFO - 2023-11-02 13:09:17 --> Helper loaded: file_helper
INFO - 2023-11-02 13:09:17 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:09:17 --> Form Validation Class Initialized
INFO - 2023-11-02 13:09:17 --> Upload Class Initialized
INFO - 2023-11-02 13:09:17 --> Model "M_auth" initialized
INFO - 2023-11-02 13:09:17 --> Model "M_user" initialized
INFO - 2023-11-02 13:09:17 --> Model "M_produk" initialized
INFO - 2023-11-02 13:09:17 --> Controller Class Initialized
INFO - 2023-11-02 13:09:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:09:17 --> Final output sent to browser
DEBUG - 2023-11-02 13:09:17 --> Total execution time: 0.0027
ERROR - 2023-11-02 13:09:17 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:09:17 --> Config Class Initialized
INFO - 2023-11-02 13:09:17 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:09:17 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:09:17 --> Utf8 Class Initialized
INFO - 2023-11-02 13:09:17 --> URI Class Initialized
INFO - 2023-11-02 13:09:17 --> Router Class Initialized
INFO - 2023-11-02 13:09:17 --> Output Class Initialized
INFO - 2023-11-02 13:09:17 --> Security Class Initialized
DEBUG - 2023-11-02 13:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:09:17 --> Input Class Initialized
INFO - 2023-11-02 13:09:17 --> Language Class Initialized
INFO - 2023-11-02 13:09:17 --> Loader Class Initialized
INFO - 2023-11-02 13:09:17 --> Helper loaded: url_helper
INFO - 2023-11-02 13:09:17 --> Helper loaded: form_helper
INFO - 2023-11-02 13:09:17 --> Helper loaded: file_helper
INFO - 2023-11-02 13:09:17 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:09:17 --> Form Validation Class Initialized
INFO - 2023-11-02 13:09:17 --> Upload Class Initialized
INFO - 2023-11-02 13:09:17 --> Model "M_auth" initialized
INFO - 2023-11-02 13:09:17 --> Model "M_user" initialized
INFO - 2023-11-02 13:09:17 --> Model "M_produk" initialized
INFO - 2023-11-02 13:09:17 --> Controller Class Initialized
INFO - 2023-11-02 13:09:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:09:17 --> Final output sent to browser
DEBUG - 2023-11-02 13:09:17 --> Total execution time: 0.0025
ERROR - 2023-11-02 13:09:20 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:09:20 --> Config Class Initialized
INFO - 2023-11-02 13:09:20 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:09:20 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:09:20 --> Utf8 Class Initialized
INFO - 2023-11-02 13:09:20 --> URI Class Initialized
INFO - 2023-11-02 13:09:20 --> Router Class Initialized
INFO - 2023-11-02 13:09:20 --> Output Class Initialized
INFO - 2023-11-02 13:09:20 --> Security Class Initialized
DEBUG - 2023-11-02 13:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:09:20 --> Input Class Initialized
INFO - 2023-11-02 13:09:20 --> Language Class Initialized
INFO - 2023-11-02 13:09:20 --> Loader Class Initialized
INFO - 2023-11-02 13:09:20 --> Helper loaded: url_helper
INFO - 2023-11-02 13:09:20 --> Helper loaded: form_helper
INFO - 2023-11-02 13:09:20 --> Helper loaded: file_helper
INFO - 2023-11-02 13:09:20 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:09:20 --> Form Validation Class Initialized
INFO - 2023-11-02 13:09:20 --> Upload Class Initialized
INFO - 2023-11-02 13:09:20 --> Model "M_auth" initialized
INFO - 2023-11-02 13:09:20 --> Model "M_user" initialized
INFO - 2023-11-02 13:09:20 --> Model "M_produk" initialized
INFO - 2023-11-02 13:09:20 --> Controller Class Initialized
INFO - 2023-11-02 13:09:20 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:09:20 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:09:20 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:09:20 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:09:20 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:09:20 --> Model "M_bank" initialized
INFO - 2023-11-02 13:09:20 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:09:20 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:09:20 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:09:20 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-02 13:09:20 --> Final output sent to browser
DEBUG - 2023-11-02 13:09:20 --> Total execution time: 0.0050
ERROR - 2023-11-02 13:09:20 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:09:20 --> Config Class Initialized
INFO - 2023-11-02 13:09:20 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:09:20 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:09:20 --> Utf8 Class Initialized
INFO - 2023-11-02 13:09:20 --> URI Class Initialized
INFO - 2023-11-02 13:09:20 --> Router Class Initialized
INFO - 2023-11-02 13:09:20 --> Output Class Initialized
INFO - 2023-11-02 13:09:20 --> Security Class Initialized
DEBUG - 2023-11-02 13:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:09:20 --> Input Class Initialized
INFO - 2023-11-02 13:09:20 --> Language Class Initialized
INFO - 2023-11-02 13:09:20 --> Loader Class Initialized
INFO - 2023-11-02 13:09:20 --> Helper loaded: url_helper
INFO - 2023-11-02 13:09:20 --> Helper loaded: form_helper
INFO - 2023-11-02 13:09:20 --> Helper loaded: file_helper
INFO - 2023-11-02 13:09:20 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:09:20 --> Form Validation Class Initialized
INFO - 2023-11-02 13:09:20 --> Upload Class Initialized
INFO - 2023-11-02 13:09:20 --> Model "M_auth" initialized
INFO - 2023-11-02 13:09:20 --> Model "M_user" initialized
INFO - 2023-11-02 13:09:20 --> Model "M_produk" initialized
INFO - 2023-11-02 13:09:20 --> Controller Class Initialized
INFO - 2023-11-02 13:09:20 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:09:20 --> Final output sent to browser
DEBUG - 2023-11-02 13:09:20 --> Total execution time: 0.0024
ERROR - 2023-11-02 13:09:29 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:09:29 --> Config Class Initialized
INFO - 2023-11-02 13:09:29 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:09:29 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:09:29 --> Utf8 Class Initialized
INFO - 2023-11-02 13:09:29 --> URI Class Initialized
INFO - 2023-11-02 13:09:29 --> Router Class Initialized
INFO - 2023-11-02 13:09:29 --> Output Class Initialized
INFO - 2023-11-02 13:09:29 --> Security Class Initialized
DEBUG - 2023-11-02 13:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:09:29 --> Input Class Initialized
INFO - 2023-11-02 13:09:29 --> Language Class Initialized
INFO - 2023-11-02 13:09:29 --> Loader Class Initialized
INFO - 2023-11-02 13:09:29 --> Helper loaded: url_helper
INFO - 2023-11-02 13:09:29 --> Helper loaded: form_helper
INFO - 2023-11-02 13:09:29 --> Helper loaded: file_helper
INFO - 2023-11-02 13:09:29 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:09:29 --> Form Validation Class Initialized
INFO - 2023-11-02 13:09:29 --> Upload Class Initialized
INFO - 2023-11-02 13:09:29 --> Model "M_auth" initialized
INFO - 2023-11-02 13:09:29 --> Model "M_user" initialized
INFO - 2023-11-02 13:09:29 --> Model "M_produk" initialized
INFO - 2023-11-02 13:09:29 --> Controller Class Initialized
INFO - 2023-11-02 13:09:29 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:09:29 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:09:29 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:09:29 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:09:29 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:09:29 --> Model "M_bank" initialized
INFO - 2023-11-02 13:09:29 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:09:29 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:09:29 --> Email Class Initialized
INFO - 2023-11-02 13:09:30 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-11-02 13:09:33 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:09:33 --> Config Class Initialized
INFO - 2023-11-02 13:09:33 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:09:33 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:09:33 --> Utf8 Class Initialized
INFO - 2023-11-02 13:09:33 --> URI Class Initialized
INFO - 2023-11-02 13:09:33 --> Router Class Initialized
INFO - 2023-11-02 13:09:33 --> Output Class Initialized
INFO - 2023-11-02 13:09:33 --> Security Class Initialized
DEBUG - 2023-11-02 13:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:09:33 --> Input Class Initialized
INFO - 2023-11-02 13:09:33 --> Language Class Initialized
INFO - 2023-11-02 13:09:33 --> Loader Class Initialized
INFO - 2023-11-02 13:09:33 --> Helper loaded: url_helper
INFO - 2023-11-02 13:09:33 --> Helper loaded: form_helper
INFO - 2023-11-02 13:09:33 --> Helper loaded: file_helper
INFO - 2023-11-02 13:09:33 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:09:33 --> Form Validation Class Initialized
INFO - 2023-11-02 13:09:33 --> Upload Class Initialized
INFO - 2023-11-02 13:09:33 --> Model "M_auth" initialized
INFO - 2023-11-02 13:09:33 --> Model "M_user" initialized
INFO - 2023-11-02 13:09:33 --> Model "M_produk" initialized
INFO - 2023-11-02 13:09:33 --> Controller Class Initialized
INFO - 2023-11-02 13:09:33 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:09:33 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:09:33 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:09:33 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:09:33 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:09:33 --> Model "M_bank" initialized
INFO - 2023-11-02 13:09:33 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:09:33 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:09:34 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:09:34 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:09:34 --> Final output sent to browser
DEBUG - 2023-11-02 13:09:34 --> Total execution time: 0.7093
ERROR - 2023-11-02 13:09:34 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:09:34 --> Config Class Initialized
INFO - 2023-11-02 13:09:34 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:09:34 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:09:34 --> Utf8 Class Initialized
INFO - 2023-11-02 13:09:34 --> URI Class Initialized
INFO - 2023-11-02 13:09:34 --> Router Class Initialized
INFO - 2023-11-02 13:09:34 --> Output Class Initialized
INFO - 2023-11-02 13:09:34 --> Security Class Initialized
DEBUG - 2023-11-02 13:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:09:34 --> Input Class Initialized
INFO - 2023-11-02 13:09:34 --> Language Class Initialized
INFO - 2023-11-02 13:09:34 --> Loader Class Initialized
INFO - 2023-11-02 13:09:34 --> Helper loaded: url_helper
INFO - 2023-11-02 13:09:34 --> Helper loaded: form_helper
INFO - 2023-11-02 13:09:34 --> Helper loaded: file_helper
INFO - 2023-11-02 13:09:34 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:09:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:09:34 --> Form Validation Class Initialized
INFO - 2023-11-02 13:09:34 --> Upload Class Initialized
INFO - 2023-11-02 13:09:34 --> Model "M_auth" initialized
INFO - 2023-11-02 13:09:34 --> Model "M_user" initialized
INFO - 2023-11-02 13:09:34 --> Model "M_produk" initialized
INFO - 2023-11-02 13:09:34 --> Controller Class Initialized
INFO - 2023-11-02 13:09:34 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:09:34 --> Final output sent to browser
DEBUG - 2023-11-02 13:09:34 --> Total execution time: 0.0031
ERROR - 2023-11-02 13:09:39 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:09:39 --> Config Class Initialized
INFO - 2023-11-02 13:09:39 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:09:39 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:09:39 --> Utf8 Class Initialized
INFO - 2023-11-02 13:09:39 --> URI Class Initialized
INFO - 2023-11-02 13:09:39 --> Router Class Initialized
INFO - 2023-11-02 13:09:39 --> Output Class Initialized
INFO - 2023-11-02 13:09:39 --> Security Class Initialized
DEBUG - 2023-11-02 13:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:09:39 --> Input Class Initialized
INFO - 2023-11-02 13:09:39 --> Language Class Initialized
INFO - 2023-11-02 13:09:39 --> Loader Class Initialized
INFO - 2023-11-02 13:09:39 --> Helper loaded: url_helper
INFO - 2023-11-02 13:09:39 --> Helper loaded: form_helper
INFO - 2023-11-02 13:09:39 --> Helper loaded: file_helper
INFO - 2023-11-02 13:09:39 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:09:39 --> Form Validation Class Initialized
INFO - 2023-11-02 13:09:39 --> Upload Class Initialized
INFO - 2023-11-02 13:09:39 --> Model "M_auth" initialized
INFO - 2023-11-02 13:09:39 --> Model "M_user" initialized
INFO - 2023-11-02 13:09:39 --> Model "M_produk" initialized
INFO - 2023-11-02 13:09:39 --> Controller Class Initialized
INFO - 2023-11-02 13:09:39 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:09:39 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:09:39 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:09:39 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:09:39 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:09:39 --> Model "M_bank" initialized
INFO - 2023-11-02 13:09:39 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:09:39 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
ERROR - 2023-11-02 13:09:39 --> Severity: error --> Exception: Midtrans API is returning API error. HTTP status code: 500 API response: {"status_code":"500","status_message":"Sorry. Our system is recovering from unexpected issues. Please retry.","id":"e5012723-3445-4e9d-9838-0af2b279378e"} /home/u967005227/domains/travelkuy.fun/public_html/application/libraries/Mid/Midtrans/ApiRequestor.php 165
ERROR - 2023-11-02 13:09:46 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:09:46 --> Config Class Initialized
INFO - 2023-11-02 13:09:46 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:09:46 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:09:46 --> Utf8 Class Initialized
INFO - 2023-11-02 13:09:46 --> URI Class Initialized
INFO - 2023-11-02 13:09:46 --> Router Class Initialized
INFO - 2023-11-02 13:09:46 --> Output Class Initialized
INFO - 2023-11-02 13:09:46 --> Security Class Initialized
DEBUG - 2023-11-02 13:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:09:46 --> Input Class Initialized
INFO - 2023-11-02 13:09:46 --> Language Class Initialized
INFO - 2023-11-02 13:09:46 --> Loader Class Initialized
INFO - 2023-11-02 13:09:46 --> Helper loaded: url_helper
INFO - 2023-11-02 13:09:46 --> Helper loaded: form_helper
INFO - 2023-11-02 13:09:46 --> Helper loaded: file_helper
INFO - 2023-11-02 13:09:46 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:09:46 --> Form Validation Class Initialized
INFO - 2023-11-02 13:09:46 --> Upload Class Initialized
INFO - 2023-11-02 13:09:46 --> Model "M_auth" initialized
INFO - 2023-11-02 13:09:46 --> Model "M_user" initialized
INFO - 2023-11-02 13:09:46 --> Model "M_produk" initialized
INFO - 2023-11-02 13:09:46 --> Controller Class Initialized
INFO - 2023-11-02 13:09:46 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:09:46 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:09:46 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:09:46 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:09:46 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:09:46 --> Model "M_bank" initialized
INFO - 2023-11-02 13:09:46 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:09:46 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:09:46 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:09:46 --> Final output sent to browser
DEBUG - 2023-11-02 13:09:46 --> Total execution time: 0.6826
ERROR - 2023-11-02 13:10:09 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:10:09 --> Config Class Initialized
INFO - 2023-11-02 13:10:09 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:10:09 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:10:09 --> Utf8 Class Initialized
INFO - 2023-11-02 13:10:09 --> URI Class Initialized
INFO - 2023-11-02 13:10:09 --> Router Class Initialized
INFO - 2023-11-02 13:10:09 --> Output Class Initialized
INFO - 2023-11-02 13:10:09 --> Security Class Initialized
DEBUG - 2023-11-02 13:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:10:09 --> Input Class Initialized
INFO - 2023-11-02 13:10:09 --> Language Class Initialized
INFO - 2023-11-02 13:10:09 --> Loader Class Initialized
INFO - 2023-11-02 13:10:09 --> Helper loaded: url_helper
INFO - 2023-11-02 13:10:09 --> Helper loaded: form_helper
INFO - 2023-11-02 13:10:09 --> Helper loaded: file_helper
INFO - 2023-11-02 13:10:09 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:10:09 --> Form Validation Class Initialized
INFO - 2023-11-02 13:10:09 --> Upload Class Initialized
INFO - 2023-11-02 13:10:09 --> Model "M_auth" initialized
INFO - 2023-11-02 13:10:09 --> Model "M_user" initialized
INFO - 2023-11-02 13:10:09 --> Model "M_produk" initialized
INFO - 2023-11-02 13:10:09 --> Controller Class Initialized
INFO - 2023-11-02 13:10:09 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:10:09 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:10:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:10:09 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:10:09 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:10:09 --> Model "M_bank" initialized
INFO - 2023-11-02 13:10:09 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:10:09 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:10:10 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:10:10 --> Final output sent to browser
DEBUG - 2023-11-02 13:10:10 --> Total execution time: 1.6231
ERROR - 2023-11-02 13:10:15 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:10:15 --> Config Class Initialized
INFO - 2023-11-02 13:10:15 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:10:15 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:10:15 --> Utf8 Class Initialized
INFO - 2023-11-02 13:10:15 --> URI Class Initialized
INFO - 2023-11-02 13:10:15 --> Router Class Initialized
INFO - 2023-11-02 13:10:15 --> Output Class Initialized
INFO - 2023-11-02 13:10:15 --> Security Class Initialized
DEBUG - 2023-11-02 13:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:10:15 --> Input Class Initialized
INFO - 2023-11-02 13:10:15 --> Language Class Initialized
INFO - 2023-11-02 13:10:15 --> Loader Class Initialized
INFO - 2023-11-02 13:10:15 --> Helper loaded: url_helper
INFO - 2023-11-02 13:10:15 --> Helper loaded: form_helper
INFO - 2023-11-02 13:10:15 --> Helper loaded: file_helper
INFO - 2023-11-02 13:10:15 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:10:15 --> Form Validation Class Initialized
INFO - 2023-11-02 13:10:15 --> Upload Class Initialized
INFO - 2023-11-02 13:10:15 --> Model "M_auth" initialized
INFO - 2023-11-02 13:10:15 --> Model "M_user" initialized
INFO - 2023-11-02 13:10:15 --> Model "M_produk" initialized
INFO - 2023-11-02 13:10:15 --> Controller Class Initialized
INFO - 2023-11-02 13:10:15 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:10:15 --> Final output sent to browser
DEBUG - 2023-11-02 13:10:15 --> Total execution time: 0.0029
ERROR - 2023-11-02 13:10:18 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:10:18 --> Config Class Initialized
INFO - 2023-11-02 13:10:18 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:10:18 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:10:18 --> Utf8 Class Initialized
INFO - 2023-11-02 13:10:18 --> URI Class Initialized
DEBUG - 2023-11-02 13:10:18 --> No URI present. Default controller set.
INFO - 2023-11-02 13:10:18 --> Router Class Initialized
INFO - 2023-11-02 13:10:18 --> Output Class Initialized
INFO - 2023-11-02 13:10:18 --> Security Class Initialized
DEBUG - 2023-11-02 13:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:10:18 --> Input Class Initialized
INFO - 2023-11-02 13:10:18 --> Language Class Initialized
INFO - 2023-11-02 13:10:18 --> Loader Class Initialized
INFO - 2023-11-02 13:10:18 --> Helper loaded: url_helper
INFO - 2023-11-02 13:10:18 --> Helper loaded: form_helper
INFO - 2023-11-02 13:10:18 --> Helper loaded: file_helper
INFO - 2023-11-02 13:10:18 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:10:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:10:18 --> Form Validation Class Initialized
INFO - 2023-11-02 13:10:18 --> Upload Class Initialized
INFO - 2023-11-02 13:10:18 --> Model "M_auth" initialized
INFO - 2023-11-02 13:10:18 --> Model "M_user" initialized
INFO - 2023-11-02 13:10:18 --> Model "M_produk" initialized
INFO - 2023-11-02 13:10:18 --> Controller Class Initialized
INFO - 2023-11-02 13:10:18 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:10:18 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:10:18 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:10:18 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:10:18 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:10:18 --> Model "M_bank" initialized
INFO - 2023-11-02 13:10:18 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:10:18 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:10:18 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:10:18 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 13:10:18 --> Final output sent to browser
DEBUG - 2023-11-02 13:10:18 --> Total execution time: 0.0099
ERROR - 2023-11-02 13:10:19 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:10:19 --> Config Class Initialized
INFO - 2023-11-02 13:10:19 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:10:19 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:10:19 --> Utf8 Class Initialized
INFO - 2023-11-02 13:10:19 --> URI Class Initialized
INFO - 2023-11-02 13:10:19 --> Router Class Initialized
INFO - 2023-11-02 13:10:19 --> Output Class Initialized
INFO - 2023-11-02 13:10:19 --> Security Class Initialized
DEBUG - 2023-11-02 13:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:10:19 --> Input Class Initialized
INFO - 2023-11-02 13:10:19 --> Language Class Initialized
INFO - 2023-11-02 13:10:19 --> Loader Class Initialized
INFO - 2023-11-02 13:10:19 --> Helper loaded: url_helper
INFO - 2023-11-02 13:10:19 --> Helper loaded: form_helper
INFO - 2023-11-02 13:10:19 --> Helper loaded: file_helper
INFO - 2023-11-02 13:10:19 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:10:19 --> Form Validation Class Initialized
INFO - 2023-11-02 13:10:19 --> Upload Class Initialized
INFO - 2023-11-02 13:10:19 --> Model "M_auth" initialized
INFO - 2023-11-02 13:10:19 --> Model "M_user" initialized
INFO - 2023-11-02 13:10:19 --> Model "M_produk" initialized
INFO - 2023-11-02 13:10:19 --> Controller Class Initialized
INFO - 2023-11-02 13:10:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:10:19 --> Final output sent to browser
DEBUG - 2023-11-02 13:10:19 --> Total execution time: 0.0031
ERROR - 2023-11-02 13:10:19 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:10:19 --> Config Class Initialized
INFO - 2023-11-02 13:10:19 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:10:19 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:10:19 --> Utf8 Class Initialized
INFO - 2023-11-02 13:10:19 --> URI Class Initialized
INFO - 2023-11-02 13:10:19 --> Router Class Initialized
INFO - 2023-11-02 13:10:19 --> Output Class Initialized
INFO - 2023-11-02 13:10:19 --> Security Class Initialized
DEBUG - 2023-11-02 13:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:10:19 --> Input Class Initialized
INFO - 2023-11-02 13:10:19 --> Language Class Initialized
INFO - 2023-11-02 13:10:19 --> Loader Class Initialized
INFO - 2023-11-02 13:10:19 --> Helper loaded: url_helper
INFO - 2023-11-02 13:10:19 --> Helper loaded: form_helper
INFO - 2023-11-02 13:10:19 --> Helper loaded: file_helper
INFO - 2023-11-02 13:10:19 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:10:19 --> Form Validation Class Initialized
INFO - 2023-11-02 13:10:19 --> Upload Class Initialized
INFO - 2023-11-02 13:10:19 --> Model "M_auth" initialized
INFO - 2023-11-02 13:10:19 --> Model "M_user" initialized
INFO - 2023-11-02 13:10:19 --> Model "M_produk" initialized
INFO - 2023-11-02 13:10:19 --> Controller Class Initialized
INFO - 2023-11-02 13:10:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:10:19 --> Final output sent to browser
DEBUG - 2023-11-02 13:10:19 --> Total execution time: 0.0037
ERROR - 2023-11-02 13:10:20 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:10:20 --> Config Class Initialized
INFO - 2023-11-02 13:10:20 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:10:20 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:10:20 --> Utf8 Class Initialized
INFO - 2023-11-02 13:10:20 --> URI Class Initialized
INFO - 2023-11-02 13:10:20 --> Router Class Initialized
INFO - 2023-11-02 13:10:20 --> Output Class Initialized
INFO - 2023-11-02 13:10:20 --> Security Class Initialized
DEBUG - 2023-11-02 13:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:10:20 --> Input Class Initialized
INFO - 2023-11-02 13:10:20 --> Language Class Initialized
INFO - 2023-11-02 13:10:20 --> Loader Class Initialized
INFO - 2023-11-02 13:10:20 --> Helper loaded: url_helper
INFO - 2023-11-02 13:10:20 --> Helper loaded: form_helper
INFO - 2023-11-02 13:10:20 --> Helper loaded: file_helper
INFO - 2023-11-02 13:10:20 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:10:20 --> Form Validation Class Initialized
INFO - 2023-11-02 13:10:20 --> Upload Class Initialized
INFO - 2023-11-02 13:10:20 --> Model "M_auth" initialized
INFO - 2023-11-02 13:10:20 --> Model "M_user" initialized
INFO - 2023-11-02 13:10:20 --> Model "M_produk" initialized
INFO - 2023-11-02 13:10:20 --> Controller Class Initialized
INFO - 2023-11-02 13:10:20 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:10:20 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:10:20 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:10:20 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:10:20 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:10:20 --> Model "M_bank" initialized
INFO - 2023-11-02 13:10:20 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:10:20 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:10:21 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:10:21 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:10:21 --> Final output sent to browser
DEBUG - 2023-11-02 13:10:21 --> Total execution time: 0.7014
ERROR - 2023-11-02 13:10:21 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:10:21 --> Config Class Initialized
INFO - 2023-11-02 13:10:21 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:10:21 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:10:21 --> Utf8 Class Initialized
INFO - 2023-11-02 13:10:21 --> URI Class Initialized
INFO - 2023-11-02 13:10:21 --> Router Class Initialized
INFO - 2023-11-02 13:10:21 --> Output Class Initialized
INFO - 2023-11-02 13:10:21 --> Security Class Initialized
DEBUG - 2023-11-02 13:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:10:21 --> Input Class Initialized
INFO - 2023-11-02 13:10:21 --> Language Class Initialized
INFO - 2023-11-02 13:10:21 --> Loader Class Initialized
INFO - 2023-11-02 13:10:21 --> Helper loaded: url_helper
INFO - 2023-11-02 13:10:21 --> Helper loaded: form_helper
INFO - 2023-11-02 13:10:21 --> Helper loaded: file_helper
INFO - 2023-11-02 13:10:21 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:10:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:10:21 --> Form Validation Class Initialized
INFO - 2023-11-02 13:10:21 --> Upload Class Initialized
INFO - 2023-11-02 13:10:21 --> Model "M_auth" initialized
INFO - 2023-11-02 13:10:21 --> Model "M_user" initialized
INFO - 2023-11-02 13:10:21 --> Model "M_produk" initialized
INFO - 2023-11-02 13:10:21 --> Controller Class Initialized
INFO - 2023-11-02 13:10:21 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:10:21 --> Final output sent to browser
DEBUG - 2023-11-02 13:10:21 --> Total execution time: 0.0029
ERROR - 2023-11-02 13:14:57 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:14:57 --> Config Class Initialized
INFO - 2023-11-02 13:14:57 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:14:57 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:14:57 --> Utf8 Class Initialized
INFO - 2023-11-02 13:14:57 --> URI Class Initialized
INFO - 2023-11-02 13:14:57 --> Router Class Initialized
INFO - 2023-11-02 13:14:57 --> Output Class Initialized
INFO - 2023-11-02 13:14:57 --> Security Class Initialized
DEBUG - 2023-11-02 13:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:14:57 --> Input Class Initialized
INFO - 2023-11-02 13:14:57 --> Language Class Initialized
INFO - 2023-11-02 13:14:57 --> Loader Class Initialized
INFO - 2023-11-02 13:14:57 --> Helper loaded: url_helper
INFO - 2023-11-02 13:14:57 --> Helper loaded: form_helper
INFO - 2023-11-02 13:14:57 --> Helper loaded: file_helper
INFO - 2023-11-02 13:14:57 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:14:57 --> Form Validation Class Initialized
INFO - 2023-11-02 13:14:57 --> Upload Class Initialized
INFO - 2023-11-02 13:14:57 --> Model "M_auth" initialized
INFO - 2023-11-02 13:14:57 --> Model "M_user" initialized
INFO - 2023-11-02 13:14:57 --> Model "M_produk" initialized
INFO - 2023-11-02 13:14:57 --> Controller Class Initialized
INFO - 2023-11-02 13:14:57 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:14:57 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:14:57 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:14:57 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:14:57 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:14:57 --> Model "M_bank" initialized
INFO - 2023-11-02 13:14:57 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:14:57 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:14:58 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:14:58 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:14:58 --> Final output sent to browser
DEBUG - 2023-11-02 13:14:58 --> Total execution time: 0.9070
ERROR - 2023-11-02 13:14:59 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:14:59 --> Config Class Initialized
INFO - 2023-11-02 13:14:59 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:14:59 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:14:59 --> Utf8 Class Initialized
INFO - 2023-11-02 13:14:59 --> URI Class Initialized
INFO - 2023-11-02 13:14:59 --> Router Class Initialized
INFO - 2023-11-02 13:14:59 --> Output Class Initialized
INFO - 2023-11-02 13:14:59 --> Security Class Initialized
DEBUG - 2023-11-02 13:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:14:59 --> Input Class Initialized
INFO - 2023-11-02 13:14:59 --> Language Class Initialized
INFO - 2023-11-02 13:14:59 --> Loader Class Initialized
INFO - 2023-11-02 13:14:59 --> Helper loaded: url_helper
INFO - 2023-11-02 13:14:59 --> Helper loaded: form_helper
INFO - 2023-11-02 13:14:59 --> Helper loaded: file_helper
INFO - 2023-11-02 13:14:59 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:14:59 --> Form Validation Class Initialized
INFO - 2023-11-02 13:14:59 --> Upload Class Initialized
INFO - 2023-11-02 13:14:59 --> Model "M_auth" initialized
INFO - 2023-11-02 13:14:59 --> Model "M_user" initialized
INFO - 2023-11-02 13:14:59 --> Model "M_produk" initialized
INFO - 2023-11-02 13:14:59 --> Controller Class Initialized
INFO - 2023-11-02 13:14:59 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:14:59 --> Final output sent to browser
DEBUG - 2023-11-02 13:14:59 --> Total execution time: 0.0028
ERROR - 2023-11-02 13:15:09 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:15:09 --> Config Class Initialized
INFO - 2023-11-02 13:15:09 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:15:09 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:15:09 --> Utf8 Class Initialized
INFO - 2023-11-02 13:15:09 --> URI Class Initialized
INFO - 2023-11-02 13:15:09 --> Router Class Initialized
INFO - 2023-11-02 13:15:09 --> Output Class Initialized
INFO - 2023-11-02 13:15:09 --> Security Class Initialized
DEBUG - 2023-11-02 13:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:15:09 --> Input Class Initialized
INFO - 2023-11-02 13:15:09 --> Language Class Initialized
INFO - 2023-11-02 13:15:09 --> Loader Class Initialized
INFO - 2023-11-02 13:15:09 --> Helper loaded: url_helper
INFO - 2023-11-02 13:15:09 --> Helper loaded: form_helper
INFO - 2023-11-02 13:15:09 --> Helper loaded: file_helper
INFO - 2023-11-02 13:15:09 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:15:09 --> Form Validation Class Initialized
INFO - 2023-11-02 13:15:09 --> Upload Class Initialized
INFO - 2023-11-02 13:15:09 --> Model "M_auth" initialized
INFO - 2023-11-02 13:15:09 --> Model "M_user" initialized
INFO - 2023-11-02 13:15:09 --> Model "M_produk" initialized
INFO - 2023-11-02 13:15:09 --> Controller Class Initialized
INFO - 2023-11-02 13:15:09 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:15:09 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:15:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:15:09 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:15:09 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:15:09 --> Model "M_bank" initialized
INFO - 2023-11-02 13:15:09 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:15:09 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:15:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:15:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:15:09 --> Final output sent to browser
DEBUG - 2023-11-02 13:15:09 --> Total execution time: 0.6663
ERROR - 2023-11-02 13:15:10 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:15:10 --> Config Class Initialized
INFO - 2023-11-02 13:15:10 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:15:10 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:15:10 --> Utf8 Class Initialized
INFO - 2023-11-02 13:15:10 --> URI Class Initialized
INFO - 2023-11-02 13:15:10 --> Router Class Initialized
INFO - 2023-11-02 13:15:10 --> Output Class Initialized
INFO - 2023-11-02 13:15:10 --> Security Class Initialized
DEBUG - 2023-11-02 13:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:15:10 --> Input Class Initialized
INFO - 2023-11-02 13:15:10 --> Language Class Initialized
INFO - 2023-11-02 13:15:10 --> Loader Class Initialized
INFO - 2023-11-02 13:15:10 --> Helper loaded: url_helper
INFO - 2023-11-02 13:15:10 --> Helper loaded: form_helper
INFO - 2023-11-02 13:15:10 --> Helper loaded: file_helper
INFO - 2023-11-02 13:15:10 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:15:10 --> Form Validation Class Initialized
INFO - 2023-11-02 13:15:10 --> Upload Class Initialized
INFO - 2023-11-02 13:15:10 --> Model "M_auth" initialized
INFO - 2023-11-02 13:15:10 --> Model "M_user" initialized
INFO - 2023-11-02 13:15:10 --> Model "M_produk" initialized
INFO - 2023-11-02 13:15:10 --> Controller Class Initialized
INFO - 2023-11-02 13:15:10 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:15:10 --> Final output sent to browser
DEBUG - 2023-11-02 13:15:10 --> Total execution time: 0.0030
ERROR - 2023-11-02 13:16:07 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:16:07 --> Config Class Initialized
INFO - 2023-11-02 13:16:07 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:16:07 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:16:07 --> Utf8 Class Initialized
INFO - 2023-11-02 13:16:07 --> URI Class Initialized
INFO - 2023-11-02 13:16:07 --> Router Class Initialized
INFO - 2023-11-02 13:16:07 --> Output Class Initialized
INFO - 2023-11-02 13:16:07 --> Security Class Initialized
DEBUG - 2023-11-02 13:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:16:07 --> Input Class Initialized
INFO - 2023-11-02 13:16:07 --> Language Class Initialized
INFO - 2023-11-02 13:16:07 --> Loader Class Initialized
INFO - 2023-11-02 13:16:07 --> Helper loaded: url_helper
INFO - 2023-11-02 13:16:07 --> Helper loaded: form_helper
INFO - 2023-11-02 13:16:07 --> Helper loaded: file_helper
INFO - 2023-11-02 13:16:07 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:16:07 --> Form Validation Class Initialized
INFO - 2023-11-02 13:16:07 --> Upload Class Initialized
INFO - 2023-11-02 13:16:07 --> Model "M_auth" initialized
INFO - 2023-11-02 13:16:07 --> Model "M_user" initialized
INFO - 2023-11-02 13:16:07 --> Model "M_produk" initialized
INFO - 2023-11-02 13:16:07 --> Controller Class Initialized
INFO - 2023-11-02 13:16:07 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:16:07 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:16:07 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:16:07 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:16:07 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:16:07 --> Model "M_bank" initialized
INFO - 2023-11-02 13:16:07 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:16:07 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:16:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:16:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:16:08 --> Final output sent to browser
DEBUG - 2023-11-02 13:16:08 --> Total execution time: 0.6694
ERROR - 2023-11-02 13:16:08 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:16:08 --> Config Class Initialized
INFO - 2023-11-02 13:16:08 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:16:08 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:16:08 --> Utf8 Class Initialized
INFO - 2023-11-02 13:16:08 --> URI Class Initialized
INFO - 2023-11-02 13:16:08 --> Router Class Initialized
INFO - 2023-11-02 13:16:08 --> Output Class Initialized
INFO - 2023-11-02 13:16:08 --> Security Class Initialized
DEBUG - 2023-11-02 13:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:16:08 --> Input Class Initialized
INFO - 2023-11-02 13:16:08 --> Language Class Initialized
INFO - 2023-11-02 13:16:08 --> Loader Class Initialized
INFO - 2023-11-02 13:16:08 --> Helper loaded: url_helper
INFO - 2023-11-02 13:16:08 --> Helper loaded: form_helper
INFO - 2023-11-02 13:16:08 --> Helper loaded: file_helper
INFO - 2023-11-02 13:16:08 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:16:08 --> Form Validation Class Initialized
INFO - 2023-11-02 13:16:08 --> Upload Class Initialized
INFO - 2023-11-02 13:16:08 --> Model "M_auth" initialized
INFO - 2023-11-02 13:16:08 --> Model "M_user" initialized
INFO - 2023-11-02 13:16:08 --> Model "M_produk" initialized
INFO - 2023-11-02 13:16:08 --> Controller Class Initialized
INFO - 2023-11-02 13:16:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:16:08 --> Final output sent to browser
DEBUG - 2023-11-02 13:16:08 --> Total execution time: 0.0030
ERROR - 2023-11-02 13:16:10 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:16:10 --> Config Class Initialized
INFO - 2023-11-02 13:16:10 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:16:10 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:16:10 --> Utf8 Class Initialized
INFO - 2023-11-02 13:16:10 --> URI Class Initialized
INFO - 2023-11-02 13:16:10 --> Router Class Initialized
INFO - 2023-11-02 13:16:10 --> Output Class Initialized
INFO - 2023-11-02 13:16:10 --> Security Class Initialized
DEBUG - 2023-11-02 13:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:16:10 --> Input Class Initialized
INFO - 2023-11-02 13:16:10 --> Language Class Initialized
INFO - 2023-11-02 13:16:10 --> Loader Class Initialized
INFO - 2023-11-02 13:16:10 --> Helper loaded: url_helper
INFO - 2023-11-02 13:16:10 --> Helper loaded: form_helper
INFO - 2023-11-02 13:16:10 --> Helper loaded: file_helper
INFO - 2023-11-02 13:16:10 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:16:10 --> Form Validation Class Initialized
INFO - 2023-11-02 13:16:10 --> Upload Class Initialized
INFO - 2023-11-02 13:16:10 --> Model "M_auth" initialized
INFO - 2023-11-02 13:16:10 --> Model "M_user" initialized
INFO - 2023-11-02 13:16:10 --> Model "M_produk" initialized
INFO - 2023-11-02 13:16:10 --> Controller Class Initialized
INFO - 2023-11-02 13:16:10 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:16:10 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:16:10 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:16:10 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:16:10 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:16:10 --> Model "M_bank" initialized
INFO - 2023-11-02 13:16:10 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:16:10 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:16:11 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:16:11 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:16:11 --> Final output sent to browser
DEBUG - 2023-11-02 13:16:11 --> Total execution time: 0.7003
ERROR - 2023-11-02 13:16:11 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:16:11 --> Config Class Initialized
INFO - 2023-11-02 13:16:11 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:16:11 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:16:11 --> Utf8 Class Initialized
INFO - 2023-11-02 13:16:11 --> URI Class Initialized
INFO - 2023-11-02 13:16:11 --> Router Class Initialized
INFO - 2023-11-02 13:16:11 --> Output Class Initialized
INFO - 2023-11-02 13:16:11 --> Security Class Initialized
DEBUG - 2023-11-02 13:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:16:11 --> Input Class Initialized
INFO - 2023-11-02 13:16:11 --> Language Class Initialized
INFO - 2023-11-02 13:16:11 --> Loader Class Initialized
INFO - 2023-11-02 13:16:11 --> Helper loaded: url_helper
INFO - 2023-11-02 13:16:11 --> Helper loaded: form_helper
INFO - 2023-11-02 13:16:11 --> Helper loaded: file_helper
INFO - 2023-11-02 13:16:11 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:16:11 --> Form Validation Class Initialized
INFO - 2023-11-02 13:16:11 --> Upload Class Initialized
INFO - 2023-11-02 13:16:11 --> Model "M_auth" initialized
INFO - 2023-11-02 13:16:11 --> Model "M_user" initialized
INFO - 2023-11-02 13:16:11 --> Model "M_produk" initialized
INFO - 2023-11-02 13:16:11 --> Controller Class Initialized
INFO - 2023-11-02 13:16:11 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:16:11 --> Final output sent to browser
DEBUG - 2023-11-02 13:16:11 --> Total execution time: 0.0025
ERROR - 2023-11-02 13:16:23 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:16:23 --> Config Class Initialized
INFO - 2023-11-02 13:16:23 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:16:23 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:16:23 --> Utf8 Class Initialized
INFO - 2023-11-02 13:16:23 --> URI Class Initialized
INFO - 2023-11-02 13:16:23 --> Router Class Initialized
INFO - 2023-11-02 13:16:23 --> Output Class Initialized
INFO - 2023-11-02 13:16:23 --> Security Class Initialized
DEBUG - 2023-11-02 13:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:16:23 --> Input Class Initialized
INFO - 2023-11-02 13:16:23 --> Language Class Initialized
INFO - 2023-11-02 13:16:23 --> Loader Class Initialized
INFO - 2023-11-02 13:16:23 --> Helper loaded: url_helper
INFO - 2023-11-02 13:16:23 --> Helper loaded: form_helper
INFO - 2023-11-02 13:16:23 --> Helper loaded: file_helper
INFO - 2023-11-02 13:16:23 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:16:23 --> Form Validation Class Initialized
INFO - 2023-11-02 13:16:23 --> Upload Class Initialized
INFO - 2023-11-02 13:16:23 --> Model "M_auth" initialized
INFO - 2023-11-02 13:16:23 --> Model "M_user" initialized
INFO - 2023-11-02 13:16:23 --> Model "M_produk" initialized
INFO - 2023-11-02 13:16:23 --> Controller Class Initialized
INFO - 2023-11-02 13:16:23 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:16:23 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:16:23 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:16:23 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:16:23 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:16:23 --> Model "M_bank" initialized
INFO - 2023-11-02 13:16:23 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:16:23 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:16:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:16:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:16:24 --> Final output sent to browser
DEBUG - 2023-11-02 13:16:24 --> Total execution time: 0.6681
ERROR - 2023-11-02 13:16:25 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:16:25 --> Config Class Initialized
INFO - 2023-11-02 13:16:25 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:16:25 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:16:25 --> Utf8 Class Initialized
INFO - 2023-11-02 13:16:25 --> URI Class Initialized
INFO - 2023-11-02 13:16:25 --> Router Class Initialized
INFO - 2023-11-02 13:16:25 --> Output Class Initialized
INFO - 2023-11-02 13:16:25 --> Security Class Initialized
DEBUG - 2023-11-02 13:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:16:25 --> Input Class Initialized
INFO - 2023-11-02 13:16:25 --> Language Class Initialized
INFO - 2023-11-02 13:16:25 --> Loader Class Initialized
INFO - 2023-11-02 13:16:25 --> Helper loaded: url_helper
INFO - 2023-11-02 13:16:25 --> Helper loaded: form_helper
INFO - 2023-11-02 13:16:25 --> Helper loaded: file_helper
INFO - 2023-11-02 13:16:25 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:16:25 --> Form Validation Class Initialized
INFO - 2023-11-02 13:16:25 --> Upload Class Initialized
INFO - 2023-11-02 13:16:25 --> Model "M_auth" initialized
INFO - 2023-11-02 13:16:25 --> Model "M_user" initialized
INFO - 2023-11-02 13:16:25 --> Model "M_produk" initialized
INFO - 2023-11-02 13:16:25 --> Controller Class Initialized
INFO - 2023-11-02 13:16:25 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:16:25 --> Final output sent to browser
DEBUG - 2023-11-02 13:16:25 --> Total execution time: 0.0028
ERROR - 2023-11-02 13:16:26 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:16:26 --> Config Class Initialized
INFO - 2023-11-02 13:16:26 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:16:26 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:16:26 --> Utf8 Class Initialized
INFO - 2023-11-02 13:16:26 --> URI Class Initialized
INFO - 2023-11-02 13:16:26 --> Router Class Initialized
INFO - 2023-11-02 13:16:26 --> Output Class Initialized
INFO - 2023-11-02 13:16:26 --> Security Class Initialized
DEBUG - 2023-11-02 13:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:16:26 --> Input Class Initialized
INFO - 2023-11-02 13:16:26 --> Language Class Initialized
INFO - 2023-11-02 13:16:26 --> Loader Class Initialized
INFO - 2023-11-02 13:16:26 --> Helper loaded: url_helper
INFO - 2023-11-02 13:16:26 --> Helper loaded: form_helper
INFO - 2023-11-02 13:16:26 --> Helper loaded: file_helper
INFO - 2023-11-02 13:16:26 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:16:26 --> Form Validation Class Initialized
INFO - 2023-11-02 13:16:26 --> Upload Class Initialized
INFO - 2023-11-02 13:16:26 --> Model "M_auth" initialized
INFO - 2023-11-02 13:16:26 --> Model "M_user" initialized
INFO - 2023-11-02 13:16:26 --> Model "M_produk" initialized
INFO - 2023-11-02 13:16:26 --> Controller Class Initialized
INFO - 2023-11-02 13:16:26 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:16:26 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:16:26 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:16:26 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:16:26 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:16:26 --> Model "M_bank" initialized
INFO - 2023-11-02 13:16:26 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:16:26 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:16:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:16:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:16:27 --> Final output sent to browser
DEBUG - 2023-11-02 13:16:27 --> Total execution time: 0.6513
ERROR - 2023-11-02 13:16:27 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:16:27 --> Config Class Initialized
INFO - 2023-11-02 13:16:27 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:16:27 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:16:27 --> Utf8 Class Initialized
INFO - 2023-11-02 13:16:27 --> URI Class Initialized
INFO - 2023-11-02 13:16:27 --> Router Class Initialized
INFO - 2023-11-02 13:16:27 --> Output Class Initialized
INFO - 2023-11-02 13:16:27 --> Security Class Initialized
DEBUG - 2023-11-02 13:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:16:27 --> Input Class Initialized
INFO - 2023-11-02 13:16:27 --> Language Class Initialized
INFO - 2023-11-02 13:16:27 --> Loader Class Initialized
INFO - 2023-11-02 13:16:27 --> Helper loaded: url_helper
INFO - 2023-11-02 13:16:27 --> Helper loaded: form_helper
INFO - 2023-11-02 13:16:27 --> Helper loaded: file_helper
INFO - 2023-11-02 13:16:27 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:16:27 --> Form Validation Class Initialized
INFO - 2023-11-02 13:16:27 --> Upload Class Initialized
INFO - 2023-11-02 13:16:27 --> Model "M_auth" initialized
INFO - 2023-11-02 13:16:27 --> Model "M_user" initialized
INFO - 2023-11-02 13:16:27 --> Model "M_produk" initialized
INFO - 2023-11-02 13:16:27 --> Controller Class Initialized
INFO - 2023-11-02 13:16:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:16:27 --> Final output sent to browser
DEBUG - 2023-11-02 13:16:27 --> Total execution time: 0.0031
ERROR - 2023-11-02 13:16:29 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:16:29 --> Config Class Initialized
INFO - 2023-11-02 13:16:29 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:16:29 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:16:29 --> Utf8 Class Initialized
INFO - 2023-11-02 13:16:29 --> URI Class Initialized
DEBUG - 2023-11-02 13:16:29 --> No URI present. Default controller set.
INFO - 2023-11-02 13:16:29 --> Router Class Initialized
INFO - 2023-11-02 13:16:29 --> Output Class Initialized
INFO - 2023-11-02 13:16:29 --> Security Class Initialized
DEBUG - 2023-11-02 13:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:16:29 --> Input Class Initialized
INFO - 2023-11-02 13:16:29 --> Language Class Initialized
INFO - 2023-11-02 13:16:29 --> Loader Class Initialized
INFO - 2023-11-02 13:16:29 --> Helper loaded: url_helper
INFO - 2023-11-02 13:16:29 --> Helper loaded: form_helper
INFO - 2023-11-02 13:16:29 --> Helper loaded: file_helper
INFO - 2023-11-02 13:16:29 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:16:29 --> Form Validation Class Initialized
INFO - 2023-11-02 13:16:29 --> Upload Class Initialized
INFO - 2023-11-02 13:16:29 --> Model "M_auth" initialized
INFO - 2023-11-02 13:16:29 --> Model "M_user" initialized
INFO - 2023-11-02 13:16:29 --> Model "M_produk" initialized
INFO - 2023-11-02 13:16:29 --> Controller Class Initialized
INFO - 2023-11-02 13:16:29 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:16:29 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:16:29 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:16:29 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:16:29 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:16:29 --> Model "M_bank" initialized
INFO - 2023-11-02 13:16:29 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:16:29 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:16:29 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:16:29 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 13:16:29 --> Final output sent to browser
DEBUG - 2023-11-02 13:16:29 --> Total execution time: 0.0027
ERROR - 2023-11-02 13:16:30 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:16:30 --> Config Class Initialized
INFO - 2023-11-02 13:16:30 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:16:30 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:16:30 --> Utf8 Class Initialized
INFO - 2023-11-02 13:16:30 --> URI Class Initialized
INFO - 2023-11-02 13:16:30 --> Router Class Initialized
INFO - 2023-11-02 13:16:30 --> Output Class Initialized
INFO - 2023-11-02 13:16:30 --> Security Class Initialized
DEBUG - 2023-11-02 13:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:16:30 --> Input Class Initialized
INFO - 2023-11-02 13:16:30 --> Language Class Initialized
INFO - 2023-11-02 13:16:30 --> Loader Class Initialized
INFO - 2023-11-02 13:16:30 --> Helper loaded: url_helper
INFO - 2023-11-02 13:16:30 --> Helper loaded: form_helper
INFO - 2023-11-02 13:16:30 --> Helper loaded: file_helper
INFO - 2023-11-02 13:16:30 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:16:30 --> Form Validation Class Initialized
INFO - 2023-11-02 13:16:30 --> Upload Class Initialized
INFO - 2023-11-02 13:16:30 --> Model "M_auth" initialized
INFO - 2023-11-02 13:16:30 --> Model "M_user" initialized
INFO - 2023-11-02 13:16:30 --> Model "M_produk" initialized
INFO - 2023-11-02 13:16:30 --> Controller Class Initialized
INFO - 2023-11-02 13:16:30 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:16:30 --> Final output sent to browser
DEBUG - 2023-11-02 13:16:30 --> Total execution time: 0.0025
ERROR - 2023-11-02 13:16:30 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:16:30 --> Config Class Initialized
INFO - 2023-11-02 13:16:30 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:16:30 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:16:30 --> Utf8 Class Initialized
INFO - 2023-11-02 13:16:30 --> URI Class Initialized
INFO - 2023-11-02 13:16:30 --> Router Class Initialized
INFO - 2023-11-02 13:16:30 --> Output Class Initialized
INFO - 2023-11-02 13:16:30 --> Security Class Initialized
DEBUG - 2023-11-02 13:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:16:30 --> Input Class Initialized
INFO - 2023-11-02 13:16:30 --> Language Class Initialized
INFO - 2023-11-02 13:16:30 --> Loader Class Initialized
INFO - 2023-11-02 13:16:30 --> Helper loaded: url_helper
INFO - 2023-11-02 13:16:30 --> Helper loaded: form_helper
INFO - 2023-11-02 13:16:30 --> Helper loaded: file_helper
INFO - 2023-11-02 13:16:30 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:16:30 --> Form Validation Class Initialized
INFO - 2023-11-02 13:16:30 --> Upload Class Initialized
INFO - 2023-11-02 13:16:30 --> Model "M_auth" initialized
INFO - 2023-11-02 13:16:30 --> Model "M_user" initialized
INFO - 2023-11-02 13:16:30 --> Model "M_produk" initialized
INFO - 2023-11-02 13:16:30 --> Controller Class Initialized
INFO - 2023-11-02 13:16:30 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:16:30 --> Final output sent to browser
DEBUG - 2023-11-02 13:16:30 --> Total execution time: 0.0025
ERROR - 2023-11-02 13:16:32 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:16:32 --> Config Class Initialized
INFO - 2023-11-02 13:16:32 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:16:32 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:16:32 --> Utf8 Class Initialized
INFO - 2023-11-02 13:16:32 --> URI Class Initialized
INFO - 2023-11-02 13:16:32 --> Router Class Initialized
INFO - 2023-11-02 13:16:32 --> Output Class Initialized
INFO - 2023-11-02 13:16:32 --> Security Class Initialized
DEBUG - 2023-11-02 13:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:16:32 --> Input Class Initialized
INFO - 2023-11-02 13:16:32 --> Language Class Initialized
INFO - 2023-11-02 13:16:32 --> Loader Class Initialized
INFO - 2023-11-02 13:16:32 --> Helper loaded: url_helper
INFO - 2023-11-02 13:16:32 --> Helper loaded: form_helper
INFO - 2023-11-02 13:16:32 --> Helper loaded: file_helper
INFO - 2023-11-02 13:16:32 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:16:32 --> Form Validation Class Initialized
INFO - 2023-11-02 13:16:32 --> Upload Class Initialized
INFO - 2023-11-02 13:16:32 --> Model "M_auth" initialized
INFO - 2023-11-02 13:16:32 --> Model "M_user" initialized
INFO - 2023-11-02 13:16:32 --> Model "M_produk" initialized
INFO - 2023-11-02 13:16:32 --> Controller Class Initialized
INFO - 2023-11-02 13:16:32 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:16:32 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:16:32 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:16:32 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:16:32 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:16:32 --> Model "M_bank" initialized
INFO - 2023-11-02 13:16:32 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:16:32 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:16:32 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:16:32 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-02 13:16:32 --> Final output sent to browser
DEBUG - 2023-11-02 13:16:32 --> Total execution time: 0.0046
ERROR - 2023-11-02 13:16:33 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:16:33 --> Config Class Initialized
INFO - 2023-11-02 13:16:33 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:16:33 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:16:33 --> Utf8 Class Initialized
INFO - 2023-11-02 13:16:33 --> URI Class Initialized
INFO - 2023-11-02 13:16:33 --> Router Class Initialized
INFO - 2023-11-02 13:16:33 --> Output Class Initialized
INFO - 2023-11-02 13:16:33 --> Security Class Initialized
DEBUG - 2023-11-02 13:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:16:33 --> Input Class Initialized
INFO - 2023-11-02 13:16:33 --> Language Class Initialized
INFO - 2023-11-02 13:16:33 --> Loader Class Initialized
INFO - 2023-11-02 13:16:33 --> Helper loaded: url_helper
INFO - 2023-11-02 13:16:33 --> Helper loaded: form_helper
INFO - 2023-11-02 13:16:33 --> Helper loaded: file_helper
INFO - 2023-11-02 13:16:33 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:16:33 --> Form Validation Class Initialized
INFO - 2023-11-02 13:16:33 --> Upload Class Initialized
INFO - 2023-11-02 13:16:33 --> Model "M_auth" initialized
INFO - 2023-11-02 13:16:33 --> Model "M_user" initialized
INFO - 2023-11-02 13:16:33 --> Model "M_produk" initialized
INFO - 2023-11-02 13:16:33 --> Controller Class Initialized
INFO - 2023-11-02 13:16:33 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:16:33 --> Final output sent to browser
DEBUG - 2023-11-02 13:16:33 --> Total execution time: 0.0029
ERROR - 2023-11-02 13:16:39 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:16:39 --> Config Class Initialized
INFO - 2023-11-02 13:16:39 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:16:39 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:16:39 --> Utf8 Class Initialized
INFO - 2023-11-02 13:16:39 --> URI Class Initialized
INFO - 2023-11-02 13:16:39 --> Router Class Initialized
INFO - 2023-11-02 13:16:39 --> Output Class Initialized
INFO - 2023-11-02 13:16:39 --> Security Class Initialized
DEBUG - 2023-11-02 13:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:16:39 --> Input Class Initialized
INFO - 2023-11-02 13:16:39 --> Language Class Initialized
INFO - 2023-11-02 13:16:39 --> Loader Class Initialized
INFO - 2023-11-02 13:16:39 --> Helper loaded: url_helper
INFO - 2023-11-02 13:16:39 --> Helper loaded: form_helper
INFO - 2023-11-02 13:16:39 --> Helper loaded: file_helper
INFO - 2023-11-02 13:16:39 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:16:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:16:39 --> Form Validation Class Initialized
INFO - 2023-11-02 13:16:39 --> Upload Class Initialized
INFO - 2023-11-02 13:16:39 --> Model "M_auth" initialized
INFO - 2023-11-02 13:16:39 --> Model "M_user" initialized
INFO - 2023-11-02 13:16:39 --> Model "M_produk" initialized
INFO - 2023-11-02 13:16:39 --> Controller Class Initialized
INFO - 2023-11-02 13:16:39 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:16:39 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:16:39 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:16:39 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:16:39 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:16:39 --> Model "M_bank" initialized
INFO - 2023-11-02 13:16:39 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:16:39 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:16:39 --> Email Class Initialized
INFO - 2023-11-02 13:16:40 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-11-02 13:16:43 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:16:43 --> Config Class Initialized
INFO - 2023-11-02 13:16:43 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:16:43 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:16:43 --> Utf8 Class Initialized
INFO - 2023-11-02 13:16:43 --> URI Class Initialized
INFO - 2023-11-02 13:16:43 --> Router Class Initialized
INFO - 2023-11-02 13:16:43 --> Output Class Initialized
INFO - 2023-11-02 13:16:43 --> Security Class Initialized
DEBUG - 2023-11-02 13:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:16:43 --> Input Class Initialized
INFO - 2023-11-02 13:16:43 --> Language Class Initialized
INFO - 2023-11-02 13:16:43 --> Loader Class Initialized
INFO - 2023-11-02 13:16:43 --> Helper loaded: url_helper
INFO - 2023-11-02 13:16:43 --> Helper loaded: form_helper
INFO - 2023-11-02 13:16:43 --> Helper loaded: file_helper
INFO - 2023-11-02 13:16:43 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:16:43 --> Form Validation Class Initialized
INFO - 2023-11-02 13:16:43 --> Upload Class Initialized
INFO - 2023-11-02 13:16:43 --> Model "M_auth" initialized
INFO - 2023-11-02 13:16:43 --> Model "M_user" initialized
INFO - 2023-11-02 13:16:43 --> Model "M_produk" initialized
INFO - 2023-11-02 13:16:43 --> Controller Class Initialized
INFO - 2023-11-02 13:16:43 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:16:43 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:16:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:16:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:16:43 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:16:43 --> Model "M_bank" initialized
INFO - 2023-11-02 13:16:43 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:16:43 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:16:43 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:16:43 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:16:43 --> Final output sent to browser
DEBUG - 2023-11-02 13:16:43 --> Total execution time: 0.7146
ERROR - 2023-11-02 13:16:51 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:16:51 --> Config Class Initialized
INFO - 2023-11-02 13:16:51 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:16:51 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:16:51 --> Utf8 Class Initialized
INFO - 2023-11-02 13:16:51 --> URI Class Initialized
INFO - 2023-11-02 13:16:51 --> Router Class Initialized
INFO - 2023-11-02 13:16:51 --> Output Class Initialized
INFO - 2023-11-02 13:16:51 --> Security Class Initialized
DEBUG - 2023-11-02 13:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:16:51 --> Input Class Initialized
INFO - 2023-11-02 13:16:51 --> Language Class Initialized
INFO - 2023-11-02 13:16:51 --> Loader Class Initialized
INFO - 2023-11-02 13:16:51 --> Helper loaded: url_helper
INFO - 2023-11-02 13:16:51 --> Helper loaded: form_helper
INFO - 2023-11-02 13:16:51 --> Helper loaded: file_helper
INFO - 2023-11-02 13:16:51 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:16:51 --> Form Validation Class Initialized
INFO - 2023-11-02 13:16:51 --> Upload Class Initialized
INFO - 2023-11-02 13:16:51 --> Model "M_auth" initialized
INFO - 2023-11-02 13:16:51 --> Model "M_user" initialized
INFO - 2023-11-02 13:16:51 --> Model "M_produk" initialized
INFO - 2023-11-02 13:16:51 --> Controller Class Initialized
INFO - 2023-11-02 13:16:51 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:16:51 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:16:51 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:16:51 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:16:51 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:16:51 --> Model "M_bank" initialized
INFO - 2023-11-02 13:16:51 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:16:51 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
ERROR - 2023-11-02 13:16:55 --> Severity: error --> Exception: Midtrans API is returning API error. HTTP status code: 500 API response: {"status_code":"500","status_message":"Sorry. Our system is recovering from unexpected issues. Please retry.","id":"c74110e3-150e-4406-9052-fa60475d1fd4"} /home/u967005227/domains/travelkuy.fun/public_html/application/libraries/Mid/Midtrans/ApiRequestor.php 165
ERROR - 2023-11-02 13:17:01 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:17:01 --> Config Class Initialized
INFO - 2023-11-02 13:17:01 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:17:01 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:17:01 --> Utf8 Class Initialized
INFO - 2023-11-02 13:17:01 --> URI Class Initialized
INFO - 2023-11-02 13:17:01 --> Router Class Initialized
INFO - 2023-11-02 13:17:01 --> Output Class Initialized
INFO - 2023-11-02 13:17:01 --> Security Class Initialized
DEBUG - 2023-11-02 13:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:17:01 --> Input Class Initialized
INFO - 2023-11-02 13:17:01 --> Language Class Initialized
INFO - 2023-11-02 13:17:01 --> Loader Class Initialized
INFO - 2023-11-02 13:17:01 --> Helper loaded: url_helper
INFO - 2023-11-02 13:17:01 --> Helper loaded: form_helper
INFO - 2023-11-02 13:17:01 --> Helper loaded: file_helper
INFO - 2023-11-02 13:17:01 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:17:01 --> Form Validation Class Initialized
INFO - 2023-11-02 13:17:01 --> Upload Class Initialized
INFO - 2023-11-02 13:17:01 --> Model "M_auth" initialized
INFO - 2023-11-02 13:17:01 --> Model "M_user" initialized
INFO - 2023-11-02 13:17:01 --> Model "M_produk" initialized
INFO - 2023-11-02 13:17:01 --> Controller Class Initialized
INFO - 2023-11-02 13:17:01 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:17:01 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:17:01 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:17:01 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:17:01 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:17:01 --> Model "M_bank" initialized
INFO - 2023-11-02 13:17:01 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:17:01 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
ERROR - 2023-11-02 13:17:10 --> Severity: error --> Exception: Midtrans API is returning API error. HTTP status code: 500 API response: {"status_code":"500","status_message":"Sorry. Our system is recovering from unexpected issues. Please retry.","id":"3ec68699-ebf7-475e-9ac4-bf672b3661a1"} /home/u967005227/domains/travelkuy.fun/public_html/application/libraries/Mid/Midtrans/ApiRequestor.php 165
ERROR - 2023-11-02 13:17:36 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:17:36 --> Config Class Initialized
INFO - 2023-11-02 13:17:36 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:17:36 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:17:36 --> Utf8 Class Initialized
INFO - 2023-11-02 13:17:36 --> URI Class Initialized
INFO - 2023-11-02 13:17:36 --> Router Class Initialized
INFO - 2023-11-02 13:17:36 --> Output Class Initialized
INFO - 2023-11-02 13:17:36 --> Security Class Initialized
DEBUG - 2023-11-02 13:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:17:36 --> Input Class Initialized
INFO - 2023-11-02 13:17:36 --> Language Class Initialized
INFO - 2023-11-02 13:17:36 --> Loader Class Initialized
INFO - 2023-11-02 13:17:36 --> Helper loaded: url_helper
INFO - 2023-11-02 13:17:36 --> Helper loaded: form_helper
INFO - 2023-11-02 13:17:36 --> Helper loaded: file_helper
INFO - 2023-11-02 13:17:36 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:17:36 --> Form Validation Class Initialized
INFO - 2023-11-02 13:17:36 --> Upload Class Initialized
INFO - 2023-11-02 13:17:36 --> Model "M_auth" initialized
INFO - 2023-11-02 13:17:36 --> Model "M_user" initialized
INFO - 2023-11-02 13:17:36 --> Model "M_produk" initialized
INFO - 2023-11-02 13:17:36 --> Controller Class Initialized
INFO - 2023-11-02 13:17:36 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:17:36 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:17:36 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:17:36 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:17:36 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:17:36 --> Model "M_bank" initialized
INFO - 2023-11-02 13:17:36 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:17:36 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:17:37 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:17:37 --> Final output sent to browser
DEBUG - 2023-11-02 13:17:37 --> Total execution time: 0.6807
ERROR - 2023-11-02 13:17:57 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:17:57 --> Config Class Initialized
INFO - 2023-11-02 13:17:57 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:17:57 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:17:57 --> Utf8 Class Initialized
INFO - 2023-11-02 13:17:57 --> URI Class Initialized
INFO - 2023-11-02 13:17:57 --> Router Class Initialized
INFO - 2023-11-02 13:17:57 --> Output Class Initialized
INFO - 2023-11-02 13:17:57 --> Security Class Initialized
DEBUG - 2023-11-02 13:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:17:57 --> Input Class Initialized
INFO - 2023-11-02 13:17:57 --> Language Class Initialized
INFO - 2023-11-02 13:17:57 --> Loader Class Initialized
INFO - 2023-11-02 13:17:57 --> Helper loaded: url_helper
INFO - 2023-11-02 13:17:57 --> Helper loaded: form_helper
INFO - 2023-11-02 13:17:57 --> Helper loaded: file_helper
INFO - 2023-11-02 13:17:57 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:17:57 --> Form Validation Class Initialized
INFO - 2023-11-02 13:17:57 --> Upload Class Initialized
INFO - 2023-11-02 13:17:57 --> Model "M_auth" initialized
INFO - 2023-11-02 13:17:57 --> Model "M_user" initialized
INFO - 2023-11-02 13:17:57 --> Model "M_produk" initialized
INFO - 2023-11-02 13:17:57 --> Controller Class Initialized
INFO - 2023-11-02 13:17:57 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:17:57 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:17:57 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:17:57 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:17:57 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:17:57 --> Model "M_bank" initialized
INFO - 2023-11-02 13:17:57 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:17:57 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:17:57 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:17:57 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:17:57 --> Final output sent to browser
DEBUG - 2023-11-02 13:17:57 --> Total execution time: 0.6065
ERROR - 2023-11-02 13:17:58 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:17:58 --> Config Class Initialized
INFO - 2023-11-02 13:17:58 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:17:58 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:17:58 --> Utf8 Class Initialized
INFO - 2023-11-02 13:17:58 --> URI Class Initialized
INFO - 2023-11-02 13:17:58 --> Router Class Initialized
INFO - 2023-11-02 13:17:58 --> Output Class Initialized
INFO - 2023-11-02 13:17:58 --> Security Class Initialized
DEBUG - 2023-11-02 13:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:17:58 --> Input Class Initialized
INFO - 2023-11-02 13:17:58 --> Language Class Initialized
INFO - 2023-11-02 13:17:58 --> Loader Class Initialized
INFO - 2023-11-02 13:17:58 --> Helper loaded: url_helper
INFO - 2023-11-02 13:17:58 --> Helper loaded: form_helper
INFO - 2023-11-02 13:17:58 --> Helper loaded: file_helper
INFO - 2023-11-02 13:17:58 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:17:58 --> Form Validation Class Initialized
INFO - 2023-11-02 13:17:58 --> Upload Class Initialized
INFO - 2023-11-02 13:17:58 --> Model "M_auth" initialized
INFO - 2023-11-02 13:17:58 --> Model "M_user" initialized
INFO - 2023-11-02 13:17:58 --> Model "M_produk" initialized
INFO - 2023-11-02 13:17:58 --> Controller Class Initialized
INFO - 2023-11-02 13:17:58 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:17:58 --> Final output sent to browser
DEBUG - 2023-11-02 13:17:58 --> Total execution time: 0.0025
ERROR - 2023-11-02 13:18:38 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:18:38 --> Config Class Initialized
INFO - 2023-11-02 13:18:38 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:18:38 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:18:38 --> Utf8 Class Initialized
INFO - 2023-11-02 13:18:38 --> URI Class Initialized
DEBUG - 2023-11-02 13:18:38 --> No URI present. Default controller set.
INFO - 2023-11-02 13:18:38 --> Router Class Initialized
INFO - 2023-11-02 13:18:38 --> Output Class Initialized
INFO - 2023-11-02 13:18:38 --> Security Class Initialized
DEBUG - 2023-11-02 13:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:18:38 --> Input Class Initialized
INFO - 2023-11-02 13:18:38 --> Language Class Initialized
INFO - 2023-11-02 13:18:38 --> Loader Class Initialized
INFO - 2023-11-02 13:18:38 --> Helper loaded: url_helper
INFO - 2023-11-02 13:18:38 --> Helper loaded: form_helper
INFO - 2023-11-02 13:18:38 --> Helper loaded: file_helper
INFO - 2023-11-02 13:18:38 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:18:38 --> Form Validation Class Initialized
INFO - 2023-11-02 13:18:38 --> Upload Class Initialized
INFO - 2023-11-02 13:18:38 --> Model "M_auth" initialized
INFO - 2023-11-02 13:18:38 --> Model "M_user" initialized
INFO - 2023-11-02 13:18:38 --> Model "M_produk" initialized
INFO - 2023-11-02 13:18:38 --> Controller Class Initialized
INFO - 2023-11-02 13:18:38 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:18:38 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:18:38 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:18:38 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:18:38 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:18:38 --> Model "M_bank" initialized
INFO - 2023-11-02 13:18:38 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:18:38 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:18:38 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:18:38 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 13:18:38 --> Final output sent to browser
DEBUG - 2023-11-02 13:18:38 --> Total execution time: 0.0051
ERROR - 2023-11-02 13:18:39 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:18:39 --> Config Class Initialized
INFO - 2023-11-02 13:18:39 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:18:39 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:18:39 --> Utf8 Class Initialized
INFO - 2023-11-02 13:18:39 --> URI Class Initialized
INFO - 2023-11-02 13:18:39 --> Router Class Initialized
INFO - 2023-11-02 13:18:39 --> Output Class Initialized
INFO - 2023-11-02 13:18:39 --> Security Class Initialized
DEBUG - 2023-11-02 13:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:18:39 --> Input Class Initialized
INFO - 2023-11-02 13:18:39 --> Language Class Initialized
INFO - 2023-11-02 13:18:39 --> Loader Class Initialized
INFO - 2023-11-02 13:18:39 --> Helper loaded: url_helper
INFO - 2023-11-02 13:18:39 --> Helper loaded: form_helper
INFO - 2023-11-02 13:18:39 --> Helper loaded: file_helper
INFO - 2023-11-02 13:18:39 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:18:39 --> Form Validation Class Initialized
INFO - 2023-11-02 13:18:39 --> Upload Class Initialized
INFO - 2023-11-02 13:18:39 --> Model "M_auth" initialized
INFO - 2023-11-02 13:18:39 --> Model "M_user" initialized
INFO - 2023-11-02 13:18:39 --> Model "M_produk" initialized
INFO - 2023-11-02 13:18:39 --> Controller Class Initialized
INFO - 2023-11-02 13:18:39 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:18:39 --> Final output sent to browser
DEBUG - 2023-11-02 13:18:39 --> Total execution time: 0.0020
ERROR - 2023-11-02 13:18:39 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:18:39 --> Config Class Initialized
INFO - 2023-11-02 13:18:39 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:18:39 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:18:39 --> Utf8 Class Initialized
INFO - 2023-11-02 13:18:39 --> URI Class Initialized
INFO - 2023-11-02 13:18:39 --> Router Class Initialized
INFO - 2023-11-02 13:18:39 --> Output Class Initialized
INFO - 2023-11-02 13:18:39 --> Security Class Initialized
DEBUG - 2023-11-02 13:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:18:39 --> Input Class Initialized
INFO - 2023-11-02 13:18:39 --> Language Class Initialized
INFO - 2023-11-02 13:18:39 --> Loader Class Initialized
INFO - 2023-11-02 13:18:39 --> Helper loaded: url_helper
INFO - 2023-11-02 13:18:39 --> Helper loaded: form_helper
INFO - 2023-11-02 13:18:39 --> Helper loaded: file_helper
INFO - 2023-11-02 13:18:39 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:18:39 --> Form Validation Class Initialized
INFO - 2023-11-02 13:18:39 --> Upload Class Initialized
INFO - 2023-11-02 13:18:39 --> Model "M_auth" initialized
INFO - 2023-11-02 13:18:39 --> Model "M_user" initialized
INFO - 2023-11-02 13:18:39 --> Model "M_produk" initialized
INFO - 2023-11-02 13:18:39 --> Controller Class Initialized
INFO - 2023-11-02 13:18:39 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:18:39 --> Final output sent to browser
DEBUG - 2023-11-02 13:18:39 --> Total execution time: 0.0018
ERROR - 2023-11-02 13:18:42 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:18:42 --> Config Class Initialized
INFO - 2023-11-02 13:18:42 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:18:42 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:18:42 --> Utf8 Class Initialized
INFO - 2023-11-02 13:18:42 --> URI Class Initialized
INFO - 2023-11-02 13:18:42 --> Router Class Initialized
INFO - 2023-11-02 13:18:42 --> Output Class Initialized
INFO - 2023-11-02 13:18:42 --> Security Class Initialized
DEBUG - 2023-11-02 13:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:18:42 --> Input Class Initialized
INFO - 2023-11-02 13:18:42 --> Language Class Initialized
INFO - 2023-11-02 13:18:42 --> Loader Class Initialized
INFO - 2023-11-02 13:18:42 --> Helper loaded: url_helper
INFO - 2023-11-02 13:18:42 --> Helper loaded: form_helper
INFO - 2023-11-02 13:18:42 --> Helper loaded: file_helper
INFO - 2023-11-02 13:18:42 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:18:42 --> Form Validation Class Initialized
INFO - 2023-11-02 13:18:42 --> Upload Class Initialized
INFO - 2023-11-02 13:18:42 --> Model "M_auth" initialized
INFO - 2023-11-02 13:18:42 --> Model "M_user" initialized
INFO - 2023-11-02 13:18:42 --> Model "M_produk" initialized
INFO - 2023-11-02 13:18:42 --> Controller Class Initialized
INFO - 2023-11-02 13:18:42 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:18:42 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:18:42 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:18:42 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:18:42 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:18:42 --> Model "M_bank" initialized
INFO - 2023-11-02 13:18:42 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:18:42 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:18:42 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:18:42 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-02 13:18:42 --> Final output sent to browser
DEBUG - 2023-11-02 13:18:42 --> Total execution time: 0.0037
ERROR - 2023-11-02 13:18:42 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:18:42 --> Config Class Initialized
INFO - 2023-11-02 13:18:42 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:18:42 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:18:42 --> Utf8 Class Initialized
INFO - 2023-11-02 13:18:42 --> URI Class Initialized
INFO - 2023-11-02 13:18:42 --> Router Class Initialized
INFO - 2023-11-02 13:18:42 --> Output Class Initialized
INFO - 2023-11-02 13:18:42 --> Security Class Initialized
DEBUG - 2023-11-02 13:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:18:42 --> Input Class Initialized
INFO - 2023-11-02 13:18:42 --> Language Class Initialized
INFO - 2023-11-02 13:18:42 --> Loader Class Initialized
INFO - 2023-11-02 13:18:42 --> Helper loaded: url_helper
INFO - 2023-11-02 13:18:42 --> Helper loaded: form_helper
INFO - 2023-11-02 13:18:42 --> Helper loaded: file_helper
INFO - 2023-11-02 13:18:42 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:18:42 --> Form Validation Class Initialized
INFO - 2023-11-02 13:18:42 --> Upload Class Initialized
INFO - 2023-11-02 13:18:42 --> Model "M_auth" initialized
INFO - 2023-11-02 13:18:42 --> Model "M_user" initialized
INFO - 2023-11-02 13:18:42 --> Model "M_produk" initialized
INFO - 2023-11-02 13:18:42 --> Controller Class Initialized
INFO - 2023-11-02 13:18:42 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:18:42 --> Final output sent to browser
DEBUG - 2023-11-02 13:18:42 --> Total execution time: 0.0025
ERROR - 2023-11-02 13:18:50 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:18:50 --> Config Class Initialized
INFO - 2023-11-02 13:18:50 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:18:50 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:18:50 --> Utf8 Class Initialized
INFO - 2023-11-02 13:18:50 --> URI Class Initialized
INFO - 2023-11-02 13:18:50 --> Router Class Initialized
INFO - 2023-11-02 13:18:50 --> Output Class Initialized
INFO - 2023-11-02 13:18:50 --> Security Class Initialized
DEBUG - 2023-11-02 13:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:18:50 --> Input Class Initialized
INFO - 2023-11-02 13:18:50 --> Language Class Initialized
INFO - 2023-11-02 13:18:50 --> Loader Class Initialized
INFO - 2023-11-02 13:18:50 --> Helper loaded: url_helper
INFO - 2023-11-02 13:18:50 --> Helper loaded: form_helper
INFO - 2023-11-02 13:18:50 --> Helper loaded: file_helper
INFO - 2023-11-02 13:18:50 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:18:50 --> Form Validation Class Initialized
INFO - 2023-11-02 13:18:50 --> Upload Class Initialized
INFO - 2023-11-02 13:18:50 --> Model "M_auth" initialized
INFO - 2023-11-02 13:18:50 --> Model "M_user" initialized
INFO - 2023-11-02 13:18:50 --> Model "M_produk" initialized
INFO - 2023-11-02 13:18:50 --> Controller Class Initialized
INFO - 2023-11-02 13:18:50 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:18:50 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:18:50 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:18:50 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:18:50 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:18:50 --> Model "M_bank" initialized
INFO - 2023-11-02 13:18:50 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:18:50 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:18:50 --> Email Class Initialized
INFO - 2023-11-02 13:18:51 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-11-02 13:18:58 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:18:58 --> Config Class Initialized
INFO - 2023-11-02 13:18:58 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:18:58 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:18:58 --> Utf8 Class Initialized
INFO - 2023-11-02 13:18:58 --> URI Class Initialized
INFO - 2023-11-02 13:18:58 --> Router Class Initialized
INFO - 2023-11-02 13:18:58 --> Output Class Initialized
INFO - 2023-11-02 13:18:58 --> Security Class Initialized
DEBUG - 2023-11-02 13:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:18:58 --> Input Class Initialized
INFO - 2023-11-02 13:18:58 --> Language Class Initialized
INFO - 2023-11-02 13:18:58 --> Loader Class Initialized
INFO - 2023-11-02 13:18:58 --> Helper loaded: url_helper
INFO - 2023-11-02 13:18:58 --> Helper loaded: form_helper
INFO - 2023-11-02 13:18:58 --> Helper loaded: file_helper
INFO - 2023-11-02 13:18:58 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:18:58 --> Form Validation Class Initialized
INFO - 2023-11-02 13:18:58 --> Upload Class Initialized
INFO - 2023-11-02 13:18:58 --> Model "M_auth" initialized
INFO - 2023-11-02 13:18:58 --> Model "M_user" initialized
INFO - 2023-11-02 13:18:58 --> Model "M_produk" initialized
INFO - 2023-11-02 13:18:58 --> Controller Class Initialized
INFO - 2023-11-02 13:18:58 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:18:58 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:18:58 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:18:58 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:18:58 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:18:58 --> Model "M_bank" initialized
INFO - 2023-11-02 13:18:58 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:18:58 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:18:58 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:18:58 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:18:58 --> Final output sent to browser
DEBUG - 2023-11-02 13:18:58 --> Total execution time: 0.7167
ERROR - 2023-11-02 13:19:01 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:19:01 --> Config Class Initialized
INFO - 2023-11-02 13:19:01 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:19:01 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:19:01 --> Utf8 Class Initialized
INFO - 2023-11-02 13:19:01 --> URI Class Initialized
INFO - 2023-11-02 13:19:01 --> Router Class Initialized
INFO - 2023-11-02 13:19:01 --> Output Class Initialized
INFO - 2023-11-02 13:19:01 --> Security Class Initialized
DEBUG - 2023-11-02 13:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:19:01 --> Input Class Initialized
INFO - 2023-11-02 13:19:01 --> Language Class Initialized
INFO - 2023-11-02 13:19:01 --> Loader Class Initialized
INFO - 2023-11-02 13:19:01 --> Helper loaded: url_helper
INFO - 2023-11-02 13:19:01 --> Helper loaded: form_helper
INFO - 2023-11-02 13:19:01 --> Helper loaded: file_helper
INFO - 2023-11-02 13:19:01 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:19:01 --> Form Validation Class Initialized
INFO - 2023-11-02 13:19:01 --> Upload Class Initialized
INFO - 2023-11-02 13:19:01 --> Model "M_auth" initialized
INFO - 2023-11-02 13:19:01 --> Model "M_user" initialized
INFO - 2023-11-02 13:19:01 --> Model "M_produk" initialized
INFO - 2023-11-02 13:19:01 --> Controller Class Initialized
INFO - 2023-11-02 13:19:01 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:19:01 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:19:01 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:19:01 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:19:01 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:19:01 --> Model "M_bank" initialized
INFO - 2023-11-02 13:19:01 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:19:01 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:19:02 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:19:02 --> Final output sent to browser
DEBUG - 2023-11-02 13:19:02 --> Total execution time: 0.6344
ERROR - 2023-11-02 13:19:13 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:19:13 --> Config Class Initialized
INFO - 2023-11-02 13:19:13 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:19:13 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:19:13 --> Utf8 Class Initialized
INFO - 2023-11-02 13:19:13 --> URI Class Initialized
INFO - 2023-11-02 13:19:13 --> Router Class Initialized
INFO - 2023-11-02 13:19:13 --> Output Class Initialized
INFO - 2023-11-02 13:19:13 --> Security Class Initialized
DEBUG - 2023-11-02 13:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:19:13 --> Input Class Initialized
INFO - 2023-11-02 13:19:13 --> Language Class Initialized
INFO - 2023-11-02 13:19:13 --> Loader Class Initialized
INFO - 2023-11-02 13:19:13 --> Helper loaded: url_helper
INFO - 2023-11-02 13:19:13 --> Helper loaded: form_helper
INFO - 2023-11-02 13:19:13 --> Helper loaded: file_helper
INFO - 2023-11-02 13:19:13 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:19:13 --> Form Validation Class Initialized
INFO - 2023-11-02 13:19:13 --> Upload Class Initialized
INFO - 2023-11-02 13:19:13 --> Model "M_auth" initialized
INFO - 2023-11-02 13:19:13 --> Model "M_user" initialized
INFO - 2023-11-02 13:19:13 --> Model "M_produk" initialized
INFO - 2023-11-02 13:19:13 --> Controller Class Initialized
INFO - 2023-11-02 13:19:13 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:19:13 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:19:13 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:19:13 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:19:13 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:19:13 --> Model "M_bank" initialized
INFO - 2023-11-02 13:19:13 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:19:13 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:19:19 --> Final output sent to browser
DEBUG - 2023-11-02 13:19:19 --> Total execution time: 5.7173
ERROR - 2023-11-02 13:19:19 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:19:19 --> Config Class Initialized
INFO - 2023-11-02 13:19:19 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:19:19 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:19:19 --> Utf8 Class Initialized
INFO - 2023-11-02 13:19:19 --> URI Class Initialized
INFO - 2023-11-02 13:19:19 --> Router Class Initialized
INFO - 2023-11-02 13:19:19 --> Output Class Initialized
INFO - 2023-11-02 13:19:19 --> Security Class Initialized
DEBUG - 2023-11-02 13:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:19:19 --> Input Class Initialized
INFO - 2023-11-02 13:19:19 --> Language Class Initialized
INFO - 2023-11-02 13:19:19 --> Loader Class Initialized
INFO - 2023-11-02 13:19:19 --> Helper loaded: url_helper
INFO - 2023-11-02 13:19:19 --> Helper loaded: form_helper
INFO - 2023-11-02 13:19:19 --> Helper loaded: file_helper
INFO - 2023-11-02 13:19:19 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:19:19 --> Form Validation Class Initialized
INFO - 2023-11-02 13:19:19 --> Upload Class Initialized
INFO - 2023-11-02 13:19:19 --> Model "M_auth" initialized
INFO - 2023-11-02 13:19:19 --> Model "M_user" initialized
INFO - 2023-11-02 13:19:19 --> Model "M_produk" initialized
INFO - 2023-11-02 13:19:19 --> Controller Class Initialized
INFO - 2023-11-02 13:19:19 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:19:19 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:19:19 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:19:19 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:19:19 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:19:19 --> Model "M_bank" initialized
INFO - 2023-11-02 13:19:19 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:19:19 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:19:20 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:19:20 --> Final output sent to browser
DEBUG - 2023-11-02 13:19:20 --> Total execution time: 0.6755
ERROR - 2023-11-02 13:21:08 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:21:08 --> Config Class Initialized
INFO - 2023-11-02 13:21:08 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:21:08 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:21:08 --> Utf8 Class Initialized
INFO - 2023-11-02 13:21:08 --> URI Class Initialized
INFO - 2023-11-02 13:21:08 --> Router Class Initialized
INFO - 2023-11-02 13:21:08 --> Output Class Initialized
INFO - 2023-11-02 13:21:08 --> Security Class Initialized
DEBUG - 2023-11-02 13:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:21:08 --> Input Class Initialized
INFO - 2023-11-02 13:21:08 --> Language Class Initialized
INFO - 2023-11-02 13:21:08 --> Loader Class Initialized
INFO - 2023-11-02 13:21:08 --> Helper loaded: url_helper
INFO - 2023-11-02 13:21:08 --> Helper loaded: form_helper
INFO - 2023-11-02 13:21:08 --> Helper loaded: file_helper
INFO - 2023-11-02 13:21:08 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:21:08 --> Form Validation Class Initialized
INFO - 2023-11-02 13:21:08 --> Upload Class Initialized
INFO - 2023-11-02 13:21:08 --> Model "M_auth" initialized
INFO - 2023-11-02 13:21:08 --> Model "M_user" initialized
INFO - 2023-11-02 13:21:08 --> Model "M_produk" initialized
INFO - 2023-11-02 13:21:08 --> Controller Class Initialized
INFO - 2023-11-02 13:21:08 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:21:08 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:21:08 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:21:08 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:21:08 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:21:08 --> Model "M_bank" initialized
INFO - 2023-11-02 13:21:08 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:21:08 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:21:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:21:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:21:09 --> Final output sent to browser
DEBUG - 2023-11-02 13:21:09 --> Total execution time: 0.8790
ERROR - 2023-11-02 13:21:09 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:21:09 --> Config Class Initialized
INFO - 2023-11-02 13:21:09 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:21:09 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:21:09 --> Utf8 Class Initialized
INFO - 2023-11-02 13:21:09 --> URI Class Initialized
INFO - 2023-11-02 13:21:09 --> Router Class Initialized
INFO - 2023-11-02 13:21:09 --> Output Class Initialized
INFO - 2023-11-02 13:21:09 --> Security Class Initialized
DEBUG - 2023-11-02 13:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:21:09 --> Input Class Initialized
INFO - 2023-11-02 13:21:09 --> Language Class Initialized
INFO - 2023-11-02 13:21:09 --> Loader Class Initialized
INFO - 2023-11-02 13:21:09 --> Helper loaded: url_helper
INFO - 2023-11-02 13:21:09 --> Helper loaded: form_helper
INFO - 2023-11-02 13:21:09 --> Helper loaded: file_helper
INFO - 2023-11-02 13:21:09 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:21:09 --> Form Validation Class Initialized
INFO - 2023-11-02 13:21:09 --> Upload Class Initialized
INFO - 2023-11-02 13:21:09 --> Model "M_auth" initialized
INFO - 2023-11-02 13:21:09 --> Model "M_user" initialized
INFO - 2023-11-02 13:21:09 --> Model "M_produk" initialized
INFO - 2023-11-02 13:21:09 --> Controller Class Initialized
INFO - 2023-11-02 13:21:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:21:09 --> Final output sent to browser
DEBUG - 2023-11-02 13:21:09 --> Total execution time: 0.0030
ERROR - 2023-11-02 13:21:23 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:21:23 --> Config Class Initialized
INFO - 2023-11-02 13:21:23 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:21:23 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:21:23 --> Utf8 Class Initialized
INFO - 2023-11-02 13:21:23 --> URI Class Initialized
INFO - 2023-11-02 13:21:23 --> Router Class Initialized
INFO - 2023-11-02 13:21:23 --> Output Class Initialized
INFO - 2023-11-02 13:21:23 --> Security Class Initialized
DEBUG - 2023-11-02 13:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:21:23 --> Input Class Initialized
INFO - 2023-11-02 13:21:23 --> Language Class Initialized
INFO - 2023-11-02 13:21:23 --> Loader Class Initialized
INFO - 2023-11-02 13:21:23 --> Helper loaded: url_helper
INFO - 2023-11-02 13:21:23 --> Helper loaded: form_helper
INFO - 2023-11-02 13:21:23 --> Helper loaded: file_helper
INFO - 2023-11-02 13:21:23 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:21:23 --> Form Validation Class Initialized
INFO - 2023-11-02 13:21:23 --> Upload Class Initialized
INFO - 2023-11-02 13:21:23 --> Model "M_auth" initialized
INFO - 2023-11-02 13:21:23 --> Model "M_user" initialized
INFO - 2023-11-02 13:21:23 --> Model "M_produk" initialized
INFO - 2023-11-02 13:21:23 --> Controller Class Initialized
INFO - 2023-11-02 13:21:23 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:21:23 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:21:23 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:21:23 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:21:23 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:21:23 --> Model "M_bank" initialized
INFO - 2023-11-02 13:21:23 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:21:23 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:21:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:21:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:21:24 --> Final output sent to browser
DEBUG - 2023-11-02 13:21:24 --> Total execution time: 0.6768
ERROR - 2023-11-02 13:21:24 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:21:24 --> Config Class Initialized
INFO - 2023-11-02 13:21:24 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:21:24 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:21:24 --> Utf8 Class Initialized
INFO - 2023-11-02 13:21:24 --> URI Class Initialized
INFO - 2023-11-02 13:21:24 --> Router Class Initialized
INFO - 2023-11-02 13:21:24 --> Output Class Initialized
INFO - 2023-11-02 13:21:24 --> Security Class Initialized
DEBUG - 2023-11-02 13:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:21:24 --> Input Class Initialized
INFO - 2023-11-02 13:21:24 --> Language Class Initialized
INFO - 2023-11-02 13:21:24 --> Loader Class Initialized
INFO - 2023-11-02 13:21:24 --> Helper loaded: url_helper
INFO - 2023-11-02 13:21:24 --> Helper loaded: form_helper
INFO - 2023-11-02 13:21:24 --> Helper loaded: file_helper
INFO - 2023-11-02 13:21:24 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:21:24 --> Form Validation Class Initialized
INFO - 2023-11-02 13:21:24 --> Upload Class Initialized
INFO - 2023-11-02 13:21:24 --> Model "M_auth" initialized
INFO - 2023-11-02 13:21:24 --> Model "M_user" initialized
INFO - 2023-11-02 13:21:24 --> Model "M_produk" initialized
INFO - 2023-11-02 13:21:24 --> Controller Class Initialized
INFO - 2023-11-02 13:21:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:21:24 --> Final output sent to browser
DEBUG - 2023-11-02 13:21:24 --> Total execution time: 0.0029
ERROR - 2023-11-02 13:22:12 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:22:12 --> Config Class Initialized
INFO - 2023-11-02 13:22:12 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:22:12 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:22:12 --> Utf8 Class Initialized
INFO - 2023-11-02 13:22:12 --> URI Class Initialized
DEBUG - 2023-11-02 13:22:12 --> No URI present. Default controller set.
INFO - 2023-11-02 13:22:12 --> Router Class Initialized
INFO - 2023-11-02 13:22:12 --> Output Class Initialized
INFO - 2023-11-02 13:22:12 --> Security Class Initialized
DEBUG - 2023-11-02 13:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:22:12 --> Input Class Initialized
INFO - 2023-11-02 13:22:12 --> Language Class Initialized
INFO - 2023-11-02 13:22:12 --> Loader Class Initialized
INFO - 2023-11-02 13:22:12 --> Helper loaded: url_helper
INFO - 2023-11-02 13:22:12 --> Helper loaded: form_helper
INFO - 2023-11-02 13:22:12 --> Helper loaded: file_helper
INFO - 2023-11-02 13:22:12 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:22:12 --> Form Validation Class Initialized
INFO - 2023-11-02 13:22:12 --> Upload Class Initialized
INFO - 2023-11-02 13:22:12 --> Model "M_auth" initialized
INFO - 2023-11-02 13:22:12 --> Model "M_user" initialized
INFO - 2023-11-02 13:22:12 --> Model "M_produk" initialized
INFO - 2023-11-02 13:22:12 --> Controller Class Initialized
INFO - 2023-11-02 13:22:12 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:22:12 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:22:12 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:22:12 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:22:12 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:22:12 --> Model "M_bank" initialized
INFO - 2023-11-02 13:22:12 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:22:12 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:22:12 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:22:12 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 13:22:12 --> Final output sent to browser
DEBUG - 2023-11-02 13:22:12 --> Total execution time: 0.0037
ERROR - 2023-11-02 13:22:13 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:22:13 --> Config Class Initialized
INFO - 2023-11-02 13:22:13 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:22:13 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:22:13 --> Utf8 Class Initialized
INFO - 2023-11-02 13:22:13 --> URI Class Initialized
INFO - 2023-11-02 13:22:13 --> Router Class Initialized
INFO - 2023-11-02 13:22:13 --> Output Class Initialized
INFO - 2023-11-02 13:22:13 --> Security Class Initialized
DEBUG - 2023-11-02 13:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:22:13 --> Input Class Initialized
INFO - 2023-11-02 13:22:13 --> Language Class Initialized
INFO - 2023-11-02 13:22:13 --> Loader Class Initialized
INFO - 2023-11-02 13:22:13 --> Helper loaded: url_helper
INFO - 2023-11-02 13:22:13 --> Helper loaded: form_helper
INFO - 2023-11-02 13:22:13 --> Helper loaded: file_helper
INFO - 2023-11-02 13:22:13 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:22:13 --> Form Validation Class Initialized
INFO - 2023-11-02 13:22:13 --> Upload Class Initialized
INFO - 2023-11-02 13:22:13 --> Model "M_auth" initialized
INFO - 2023-11-02 13:22:13 --> Model "M_user" initialized
ERROR - 2023-11-02 13:22:13 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:22:13 --> Model "M_produk" initialized
INFO - 2023-11-02 13:22:13 --> Controller Class Initialized
INFO - 2023-11-02 13:22:13 --> Config Class Initialized
INFO - 2023-11-02 13:22:13 --> Hooks Class Initialized
INFO - 2023-11-02 13:22:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:22:13 --> Final output sent to browser
DEBUG - 2023-11-02 13:22:13 --> UTF-8 Support Enabled
DEBUG - 2023-11-02 13:22:13 --> Total execution time: 0.0026
INFO - 2023-11-02 13:22:13 --> Utf8 Class Initialized
INFO - 2023-11-02 13:22:13 --> URI Class Initialized
INFO - 2023-11-02 13:22:13 --> Router Class Initialized
INFO - 2023-11-02 13:22:13 --> Output Class Initialized
INFO - 2023-11-02 13:22:13 --> Security Class Initialized
DEBUG - 2023-11-02 13:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:22:13 --> Input Class Initialized
INFO - 2023-11-02 13:22:13 --> Language Class Initialized
INFO - 2023-11-02 13:22:13 --> Loader Class Initialized
INFO - 2023-11-02 13:22:13 --> Helper loaded: url_helper
INFO - 2023-11-02 13:22:13 --> Helper loaded: form_helper
INFO - 2023-11-02 13:22:13 --> Helper loaded: file_helper
INFO - 2023-11-02 13:22:13 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:22:13 --> Form Validation Class Initialized
INFO - 2023-11-02 13:22:13 --> Upload Class Initialized
INFO - 2023-11-02 13:22:13 --> Model "M_auth" initialized
INFO - 2023-11-02 13:22:13 --> Model "M_user" initialized
INFO - 2023-11-02 13:22:13 --> Model "M_produk" initialized
INFO - 2023-11-02 13:22:13 --> Controller Class Initialized
INFO - 2023-11-02 13:22:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:22:13 --> Final output sent to browser
DEBUG - 2023-11-02 13:22:13 --> Total execution time: 0.0027
ERROR - 2023-11-02 13:22:17 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:22:17 --> Config Class Initialized
INFO - 2023-11-02 13:22:17 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:22:17 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:22:17 --> Utf8 Class Initialized
INFO - 2023-11-02 13:22:17 --> URI Class Initialized
INFO - 2023-11-02 13:22:17 --> Router Class Initialized
INFO - 2023-11-02 13:22:17 --> Output Class Initialized
INFO - 2023-11-02 13:22:17 --> Security Class Initialized
DEBUG - 2023-11-02 13:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:22:17 --> Input Class Initialized
INFO - 2023-11-02 13:22:17 --> Language Class Initialized
INFO - 2023-11-02 13:22:17 --> Loader Class Initialized
INFO - 2023-11-02 13:22:17 --> Helper loaded: url_helper
INFO - 2023-11-02 13:22:17 --> Helper loaded: form_helper
INFO - 2023-11-02 13:22:17 --> Helper loaded: file_helper
INFO - 2023-11-02 13:22:17 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:22:17 --> Form Validation Class Initialized
INFO - 2023-11-02 13:22:17 --> Upload Class Initialized
INFO - 2023-11-02 13:22:17 --> Model "M_auth" initialized
INFO - 2023-11-02 13:22:17 --> Model "M_user" initialized
INFO - 2023-11-02 13:22:17 --> Model "M_produk" initialized
INFO - 2023-11-02 13:22:17 --> Controller Class Initialized
INFO - 2023-11-02 13:22:17 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:22:17 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:22:17 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:22:17 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:22:17 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:22:17 --> Model "M_bank" initialized
INFO - 2023-11-02 13:22:17 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:22:17 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:22:18 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:22:18 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:22:18 --> Final output sent to browser
DEBUG - 2023-11-02 13:22:18 --> Total execution time: 0.6625
ERROR - 2023-11-02 13:22:18 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:22:18 --> Config Class Initialized
INFO - 2023-11-02 13:22:18 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:22:18 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:22:18 --> Utf8 Class Initialized
INFO - 2023-11-02 13:22:18 --> URI Class Initialized
INFO - 2023-11-02 13:22:18 --> Router Class Initialized
INFO - 2023-11-02 13:22:18 --> Output Class Initialized
INFO - 2023-11-02 13:22:18 --> Security Class Initialized
DEBUG - 2023-11-02 13:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:22:18 --> Input Class Initialized
INFO - 2023-11-02 13:22:18 --> Language Class Initialized
INFO - 2023-11-02 13:22:18 --> Loader Class Initialized
INFO - 2023-11-02 13:22:18 --> Helper loaded: url_helper
INFO - 2023-11-02 13:22:18 --> Helper loaded: form_helper
INFO - 2023-11-02 13:22:18 --> Helper loaded: file_helper
INFO - 2023-11-02 13:22:18 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:22:18 --> Form Validation Class Initialized
INFO - 2023-11-02 13:22:18 --> Upload Class Initialized
INFO - 2023-11-02 13:22:18 --> Model "M_auth" initialized
INFO - 2023-11-02 13:22:18 --> Model "M_user" initialized
INFO - 2023-11-02 13:22:18 --> Model "M_produk" initialized
INFO - 2023-11-02 13:22:18 --> Controller Class Initialized
INFO - 2023-11-02 13:22:18 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:22:18 --> Final output sent to browser
DEBUG - 2023-11-02 13:22:18 --> Total execution time: 0.0034
ERROR - 2023-11-02 13:22:26 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:22:26 --> Config Class Initialized
INFO - 2023-11-02 13:22:26 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:22:26 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:22:26 --> Utf8 Class Initialized
INFO - 2023-11-02 13:22:26 --> URI Class Initialized
INFO - 2023-11-02 13:22:26 --> Router Class Initialized
INFO - 2023-11-02 13:22:26 --> Output Class Initialized
INFO - 2023-11-02 13:22:26 --> Security Class Initialized
DEBUG - 2023-11-02 13:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:22:26 --> Input Class Initialized
INFO - 2023-11-02 13:22:26 --> Language Class Initialized
INFO - 2023-11-02 13:22:26 --> Loader Class Initialized
INFO - 2023-11-02 13:22:26 --> Helper loaded: url_helper
INFO - 2023-11-02 13:22:26 --> Helper loaded: form_helper
INFO - 2023-11-02 13:22:26 --> Helper loaded: file_helper
INFO - 2023-11-02 13:22:26 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:22:26 --> Form Validation Class Initialized
INFO - 2023-11-02 13:22:26 --> Upload Class Initialized
INFO - 2023-11-02 13:22:26 --> Model "M_auth" initialized
INFO - 2023-11-02 13:22:26 --> Model "M_user" initialized
INFO - 2023-11-02 13:22:26 --> Model "M_produk" initialized
INFO - 2023-11-02 13:22:26 --> Controller Class Initialized
INFO - 2023-11-02 13:22:26 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:22:26 --> Final output sent to browser
DEBUG - 2023-11-02 13:22:26 --> Total execution time: 0.0027
ERROR - 2023-11-02 13:22:52 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:22:52 --> Config Class Initialized
INFO - 2023-11-02 13:22:52 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:22:52 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:22:52 --> Utf8 Class Initialized
INFO - 2023-11-02 13:22:52 --> URI Class Initialized
INFO - 2023-11-02 13:22:52 --> Router Class Initialized
INFO - 2023-11-02 13:22:52 --> Output Class Initialized
INFO - 2023-11-02 13:22:52 --> Security Class Initialized
DEBUG - 2023-11-02 13:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:22:52 --> Input Class Initialized
INFO - 2023-11-02 13:22:52 --> Language Class Initialized
INFO - 2023-11-02 13:22:52 --> Loader Class Initialized
INFO - 2023-11-02 13:22:52 --> Helper loaded: url_helper
INFO - 2023-11-02 13:22:52 --> Helper loaded: form_helper
INFO - 2023-11-02 13:22:52 --> Helper loaded: file_helper
INFO - 2023-11-02 13:22:52 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:22:52 --> Form Validation Class Initialized
INFO - 2023-11-02 13:22:52 --> Upload Class Initialized
INFO - 2023-11-02 13:22:52 --> Model "M_auth" initialized
INFO - 2023-11-02 13:22:52 --> Model "M_user" initialized
INFO - 2023-11-02 13:22:52 --> Model "M_produk" initialized
INFO - 2023-11-02 13:22:52 --> Controller Class Initialized
INFO - 2023-11-02 13:22:52 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:22:52 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:22:52 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:22:52 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:22:52 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:22:52 --> Model "M_bank" initialized
INFO - 2023-11-02 13:22:52 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:22:52 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:22:53 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:22:53 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:22:53 --> Final output sent to browser
DEBUG - 2023-11-02 13:22:53 --> Total execution time: 0.6755
ERROR - 2023-11-02 13:22:53 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:22:53 --> Config Class Initialized
INFO - 2023-11-02 13:22:53 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:22:53 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:22:53 --> Utf8 Class Initialized
INFO - 2023-11-02 13:22:53 --> URI Class Initialized
INFO - 2023-11-02 13:22:53 --> Router Class Initialized
INFO - 2023-11-02 13:22:53 --> Output Class Initialized
INFO - 2023-11-02 13:22:53 --> Security Class Initialized
DEBUG - 2023-11-02 13:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:22:53 --> Input Class Initialized
INFO - 2023-11-02 13:22:53 --> Language Class Initialized
INFO - 2023-11-02 13:22:53 --> Loader Class Initialized
INFO - 2023-11-02 13:22:53 --> Helper loaded: url_helper
INFO - 2023-11-02 13:22:53 --> Helper loaded: form_helper
INFO - 2023-11-02 13:22:53 --> Helper loaded: file_helper
INFO - 2023-11-02 13:22:53 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:22:53 --> Form Validation Class Initialized
INFO - 2023-11-02 13:22:53 --> Upload Class Initialized
INFO - 2023-11-02 13:22:53 --> Model "M_auth" initialized
INFO - 2023-11-02 13:22:53 --> Model "M_user" initialized
INFO - 2023-11-02 13:22:53 --> Model "M_produk" initialized
INFO - 2023-11-02 13:22:53 --> Controller Class Initialized
INFO - 2023-11-02 13:22:53 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:22:53 --> Final output sent to browser
DEBUG - 2023-11-02 13:22:53 --> Total execution time: 0.0030
ERROR - 2023-11-02 13:27:12 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:27:12 --> Config Class Initialized
INFO - 2023-11-02 13:27:12 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:27:12 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:27:12 --> Utf8 Class Initialized
INFO - 2023-11-02 13:27:12 --> URI Class Initialized
DEBUG - 2023-11-02 13:27:12 --> No URI present. Default controller set.
INFO - 2023-11-02 13:27:12 --> Router Class Initialized
INFO - 2023-11-02 13:27:12 --> Output Class Initialized
INFO - 2023-11-02 13:27:12 --> Security Class Initialized
DEBUG - 2023-11-02 13:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:27:12 --> Input Class Initialized
INFO - 2023-11-02 13:27:12 --> Language Class Initialized
INFO - 2023-11-02 13:27:12 --> Loader Class Initialized
INFO - 2023-11-02 13:27:12 --> Helper loaded: url_helper
INFO - 2023-11-02 13:27:12 --> Helper loaded: form_helper
INFO - 2023-11-02 13:27:12 --> Helper loaded: file_helper
INFO - 2023-11-02 13:27:12 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:27:12 --> Form Validation Class Initialized
INFO - 2023-11-02 13:27:12 --> Upload Class Initialized
INFO - 2023-11-02 13:27:12 --> Model "M_auth" initialized
INFO - 2023-11-02 13:27:12 --> Model "M_user" initialized
INFO - 2023-11-02 13:27:12 --> Model "M_produk" initialized
INFO - 2023-11-02 13:27:12 --> Controller Class Initialized
INFO - 2023-11-02 13:27:12 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:27:12 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:27:12 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:27:12 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:27:12 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:27:12 --> Model "M_bank" initialized
INFO - 2023-11-02 13:27:12 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:27:12 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:27:12 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:27:12 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 13:27:12 --> Final output sent to browser
DEBUG - 2023-11-02 13:27:12 --> Total execution time: 0.0044
ERROR - 2023-11-02 13:27:13 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:27:13 --> Config Class Initialized
INFO - 2023-11-02 13:27:13 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:27:13 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:27:13 --> Utf8 Class Initialized
INFO - 2023-11-02 13:27:13 --> URI Class Initialized
INFO - 2023-11-02 13:27:13 --> Router Class Initialized
INFO - 2023-11-02 13:27:13 --> Output Class Initialized
INFO - 2023-11-02 13:27:13 --> Security Class Initialized
DEBUG - 2023-11-02 13:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:27:13 --> Input Class Initialized
INFO - 2023-11-02 13:27:13 --> Language Class Initialized
INFO - 2023-11-02 13:27:13 --> Loader Class Initialized
INFO - 2023-11-02 13:27:13 --> Helper loaded: url_helper
INFO - 2023-11-02 13:27:13 --> Helper loaded: form_helper
INFO - 2023-11-02 13:27:13 --> Helper loaded: file_helper
INFO - 2023-11-02 13:27:13 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:27:13 --> Form Validation Class Initialized
INFO - 2023-11-02 13:27:13 --> Upload Class Initialized
INFO - 2023-11-02 13:27:13 --> Model "M_auth" initialized
INFO - 2023-11-02 13:27:13 --> Model "M_user" initialized
INFO - 2023-11-02 13:27:13 --> Model "M_produk" initialized
INFO - 2023-11-02 13:27:13 --> Controller Class Initialized
INFO - 2023-11-02 13:27:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
ERROR - 2023-11-02 13:27:13 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:27:13 --> Final output sent to browser
DEBUG - 2023-11-02 13:27:13 --> Total execution time: 0.0023
INFO - 2023-11-02 13:27:13 --> Config Class Initialized
INFO - 2023-11-02 13:27:13 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:27:13 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:27:13 --> Utf8 Class Initialized
INFO - 2023-11-02 13:27:13 --> URI Class Initialized
INFO - 2023-11-02 13:27:13 --> Router Class Initialized
INFO - 2023-11-02 13:27:13 --> Output Class Initialized
INFO - 2023-11-02 13:27:13 --> Security Class Initialized
DEBUG - 2023-11-02 13:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:27:13 --> Input Class Initialized
INFO - 2023-11-02 13:27:13 --> Language Class Initialized
INFO - 2023-11-02 13:27:13 --> Loader Class Initialized
INFO - 2023-11-02 13:27:13 --> Helper loaded: url_helper
INFO - 2023-11-02 13:27:13 --> Helper loaded: form_helper
INFO - 2023-11-02 13:27:13 --> Helper loaded: file_helper
INFO - 2023-11-02 13:27:13 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:27:13 --> Form Validation Class Initialized
INFO - 2023-11-02 13:27:13 --> Upload Class Initialized
INFO - 2023-11-02 13:27:13 --> Model "M_auth" initialized
INFO - 2023-11-02 13:27:13 --> Model "M_user" initialized
INFO - 2023-11-02 13:27:13 --> Model "M_produk" initialized
INFO - 2023-11-02 13:27:13 --> Controller Class Initialized
INFO - 2023-11-02 13:27:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:27:13 --> Final output sent to browser
DEBUG - 2023-11-02 13:27:13 --> Total execution time: 0.0031
ERROR - 2023-11-02 13:27:17 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:27:17 --> Config Class Initialized
INFO - 2023-11-02 13:27:17 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:27:17 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:27:17 --> Utf8 Class Initialized
INFO - 2023-11-02 13:27:17 --> URI Class Initialized
INFO - 2023-11-02 13:27:17 --> Router Class Initialized
INFO - 2023-11-02 13:27:17 --> Output Class Initialized
INFO - 2023-11-02 13:27:17 --> Security Class Initialized
DEBUG - 2023-11-02 13:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:27:17 --> Input Class Initialized
INFO - 2023-11-02 13:27:17 --> Language Class Initialized
INFO - 2023-11-02 13:27:17 --> Loader Class Initialized
INFO - 2023-11-02 13:27:17 --> Helper loaded: url_helper
INFO - 2023-11-02 13:27:17 --> Helper loaded: form_helper
INFO - 2023-11-02 13:27:17 --> Helper loaded: file_helper
INFO - 2023-11-02 13:27:17 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:27:17 --> Form Validation Class Initialized
INFO - 2023-11-02 13:27:17 --> Upload Class Initialized
INFO - 2023-11-02 13:27:17 --> Model "M_auth" initialized
INFO - 2023-11-02 13:27:17 --> Model "M_user" initialized
INFO - 2023-11-02 13:27:17 --> Model "M_produk" initialized
INFO - 2023-11-02 13:27:17 --> Controller Class Initialized
INFO - 2023-11-02 13:27:17 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:27:17 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:27:17 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:27:17 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:27:17 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:27:17 --> Model "M_bank" initialized
INFO - 2023-11-02 13:27:17 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:27:17 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:27:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:27:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-02 13:27:17 --> Final output sent to browser
DEBUG - 2023-11-02 13:27:17 --> Total execution time: 0.0044
ERROR - 2023-11-02 13:27:17 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:27:17 --> Config Class Initialized
INFO - 2023-11-02 13:27:17 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:27:17 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:27:17 --> Utf8 Class Initialized
INFO - 2023-11-02 13:27:17 --> URI Class Initialized
INFO - 2023-11-02 13:27:17 --> Router Class Initialized
INFO - 2023-11-02 13:27:17 --> Output Class Initialized
INFO - 2023-11-02 13:27:17 --> Security Class Initialized
DEBUG - 2023-11-02 13:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:27:17 --> Input Class Initialized
INFO - 2023-11-02 13:27:17 --> Language Class Initialized
INFO - 2023-11-02 13:27:17 --> Loader Class Initialized
INFO - 2023-11-02 13:27:17 --> Helper loaded: url_helper
INFO - 2023-11-02 13:27:17 --> Helper loaded: form_helper
INFO - 2023-11-02 13:27:17 --> Helper loaded: file_helper
INFO - 2023-11-02 13:27:17 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:27:17 --> Form Validation Class Initialized
INFO - 2023-11-02 13:27:17 --> Upload Class Initialized
INFO - 2023-11-02 13:27:17 --> Model "M_auth" initialized
INFO - 2023-11-02 13:27:17 --> Model "M_user" initialized
INFO - 2023-11-02 13:27:17 --> Model "M_produk" initialized
INFO - 2023-11-02 13:27:17 --> Controller Class Initialized
INFO - 2023-11-02 13:27:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:27:17 --> Final output sent to browser
DEBUG - 2023-11-02 13:27:17 --> Total execution time: 0.0023
ERROR - 2023-11-02 13:27:23 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:27:23 --> Config Class Initialized
INFO - 2023-11-02 13:27:23 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:27:23 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:27:23 --> Utf8 Class Initialized
INFO - 2023-11-02 13:27:23 --> URI Class Initialized
INFO - 2023-11-02 13:27:23 --> Router Class Initialized
INFO - 2023-11-02 13:27:23 --> Output Class Initialized
INFO - 2023-11-02 13:27:23 --> Security Class Initialized
DEBUG - 2023-11-02 13:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:27:23 --> Input Class Initialized
INFO - 2023-11-02 13:27:23 --> Language Class Initialized
INFO - 2023-11-02 13:27:23 --> Loader Class Initialized
INFO - 2023-11-02 13:27:23 --> Helper loaded: url_helper
INFO - 2023-11-02 13:27:23 --> Helper loaded: form_helper
INFO - 2023-11-02 13:27:23 --> Helper loaded: file_helper
INFO - 2023-11-02 13:27:23 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:27:23 --> Form Validation Class Initialized
INFO - 2023-11-02 13:27:23 --> Upload Class Initialized
INFO - 2023-11-02 13:27:23 --> Model "M_auth" initialized
INFO - 2023-11-02 13:27:23 --> Model "M_user" initialized
INFO - 2023-11-02 13:27:23 --> Model "M_produk" initialized
INFO - 2023-11-02 13:27:23 --> Controller Class Initialized
INFO - 2023-11-02 13:27:23 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:27:23 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:27:23 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:27:23 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:27:23 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:27:23 --> Model "M_bank" initialized
INFO - 2023-11-02 13:27:23 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:27:23 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:27:23 --> Email Class Initialized
INFO - 2023-11-02 13:27:24 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-11-02 13:27:26 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:27:26 --> Config Class Initialized
INFO - 2023-11-02 13:27:26 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:27:26 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:27:26 --> Utf8 Class Initialized
INFO - 2023-11-02 13:27:26 --> URI Class Initialized
INFO - 2023-11-02 13:27:26 --> Router Class Initialized
INFO - 2023-11-02 13:27:26 --> Output Class Initialized
INFO - 2023-11-02 13:27:26 --> Security Class Initialized
DEBUG - 2023-11-02 13:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:27:26 --> Input Class Initialized
INFO - 2023-11-02 13:27:26 --> Language Class Initialized
INFO - 2023-11-02 13:27:26 --> Loader Class Initialized
INFO - 2023-11-02 13:27:26 --> Helper loaded: url_helper
INFO - 2023-11-02 13:27:26 --> Helper loaded: form_helper
INFO - 2023-11-02 13:27:26 --> Helper loaded: file_helper
INFO - 2023-11-02 13:27:26 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:27:26 --> Form Validation Class Initialized
INFO - 2023-11-02 13:27:26 --> Upload Class Initialized
INFO - 2023-11-02 13:27:26 --> Model "M_auth" initialized
INFO - 2023-11-02 13:27:26 --> Model "M_user" initialized
INFO - 2023-11-02 13:27:26 --> Model "M_produk" initialized
INFO - 2023-11-02 13:27:26 --> Controller Class Initialized
INFO - 2023-11-02 13:27:26 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:27:26 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:27:26 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:27:26 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:27:26 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:27:26 --> Model "M_bank" initialized
INFO - 2023-11-02 13:27:26 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:27:26 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:27:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:27:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:27:27 --> Final output sent to browser
DEBUG - 2023-11-02 13:27:27 --> Total execution time: 0.7029
ERROR - 2023-11-02 13:27:32 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:27:32 --> Config Class Initialized
INFO - 2023-11-02 13:27:32 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:27:32 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:27:32 --> Utf8 Class Initialized
INFO - 2023-11-02 13:27:32 --> URI Class Initialized
INFO - 2023-11-02 13:27:32 --> Router Class Initialized
INFO - 2023-11-02 13:27:32 --> Output Class Initialized
INFO - 2023-11-02 13:27:32 --> Security Class Initialized
DEBUG - 2023-11-02 13:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:27:32 --> Input Class Initialized
INFO - 2023-11-02 13:27:32 --> Language Class Initialized
INFO - 2023-11-02 13:27:32 --> Loader Class Initialized
INFO - 2023-11-02 13:27:32 --> Helper loaded: url_helper
INFO - 2023-11-02 13:27:32 --> Helper loaded: form_helper
INFO - 2023-11-02 13:27:32 --> Helper loaded: file_helper
INFO - 2023-11-02 13:27:32 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:27:32 --> Form Validation Class Initialized
INFO - 2023-11-02 13:27:32 --> Upload Class Initialized
INFO - 2023-11-02 13:27:32 --> Model "M_auth" initialized
INFO - 2023-11-02 13:27:32 --> Model "M_user" initialized
INFO - 2023-11-02 13:27:32 --> Model "M_produk" initialized
INFO - 2023-11-02 13:27:32 --> Controller Class Initialized
INFO - 2023-11-02 13:27:32 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:27:32 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:27:32 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:27:32 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:27:32 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:27:32 --> Model "M_bank" initialized
INFO - 2023-11-02 13:27:32 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:27:32 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:27:33 --> Final output sent to browser
DEBUG - 2023-11-02 13:27:33 --> Total execution time: 0.7248
ERROR - 2023-11-02 13:27:42 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:27:42 --> Config Class Initialized
INFO - 2023-11-02 13:27:42 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:27:42 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:27:42 --> Utf8 Class Initialized
INFO - 2023-11-02 13:27:42 --> URI Class Initialized
INFO - 2023-11-02 13:27:42 --> Router Class Initialized
INFO - 2023-11-02 13:27:42 --> Output Class Initialized
INFO - 2023-11-02 13:27:42 --> Security Class Initialized
DEBUG - 2023-11-02 13:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:27:42 --> Input Class Initialized
INFO - 2023-11-02 13:27:42 --> Language Class Initialized
INFO - 2023-11-02 13:27:42 --> Loader Class Initialized
INFO - 2023-11-02 13:27:42 --> Helper loaded: url_helper
INFO - 2023-11-02 13:27:42 --> Helper loaded: form_helper
INFO - 2023-11-02 13:27:42 --> Helper loaded: file_helper
INFO - 2023-11-02 13:27:42 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:27:42 --> Form Validation Class Initialized
INFO - 2023-11-02 13:27:42 --> Upload Class Initialized
INFO - 2023-11-02 13:27:42 --> Model "M_auth" initialized
INFO - 2023-11-02 13:27:42 --> Model "M_user" initialized
INFO - 2023-11-02 13:27:42 --> Model "M_produk" initialized
INFO - 2023-11-02 13:27:42 --> Controller Class Initialized
INFO - 2023-11-02 13:27:42 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:27:42 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:27:42 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:27:42 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:27:42 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:27:42 --> Model "M_bank" initialized
INFO - 2023-11-02 13:27:42 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:27:42 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:27:42 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:27:42 --> Final output sent to browser
DEBUG - 2023-11-02 13:27:42 --> Total execution time: 0.6302
ERROR - 2023-11-02 13:28:19 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:28:19 --> Config Class Initialized
INFO - 2023-11-02 13:28:19 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:28:19 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:28:19 --> Utf8 Class Initialized
INFO - 2023-11-02 13:28:19 --> URI Class Initialized
INFO - 2023-11-02 13:28:19 --> Router Class Initialized
INFO - 2023-11-02 13:28:19 --> Output Class Initialized
INFO - 2023-11-02 13:28:19 --> Security Class Initialized
DEBUG - 2023-11-02 13:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:28:19 --> Input Class Initialized
INFO - 2023-11-02 13:28:19 --> Language Class Initialized
INFO - 2023-11-02 13:28:19 --> Loader Class Initialized
INFO - 2023-11-02 13:28:19 --> Helper loaded: url_helper
INFO - 2023-11-02 13:28:19 --> Helper loaded: form_helper
INFO - 2023-11-02 13:28:19 --> Helper loaded: file_helper
INFO - 2023-11-02 13:28:19 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:28:19 --> Form Validation Class Initialized
INFO - 2023-11-02 13:28:19 --> Upload Class Initialized
INFO - 2023-11-02 13:28:19 --> Model "M_auth" initialized
INFO - 2023-11-02 13:28:19 --> Model "M_user" initialized
INFO - 2023-11-02 13:28:19 --> Model "M_produk" initialized
INFO - 2023-11-02 13:28:19 --> Controller Class Initialized
INFO - 2023-11-02 13:28:19 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:28:19 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:28:19 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:28:19 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:28:19 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:28:19 --> Model "M_bank" initialized
INFO - 2023-11-02 13:28:19 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:28:19 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:28:20 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:28:20 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:28:20 --> Final output sent to browser
DEBUG - 2023-11-02 13:28:20 --> Total execution time: 0.6553
ERROR - 2023-11-02 13:28:20 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:28:20 --> Config Class Initialized
INFO - 2023-11-02 13:28:20 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:28:20 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:28:20 --> Utf8 Class Initialized
INFO - 2023-11-02 13:28:20 --> URI Class Initialized
INFO - 2023-11-02 13:28:20 --> Router Class Initialized
INFO - 2023-11-02 13:28:20 --> Output Class Initialized
INFO - 2023-11-02 13:28:20 --> Security Class Initialized
DEBUG - 2023-11-02 13:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:28:20 --> Input Class Initialized
INFO - 2023-11-02 13:28:20 --> Language Class Initialized
INFO - 2023-11-02 13:28:20 --> Loader Class Initialized
INFO - 2023-11-02 13:28:20 --> Helper loaded: url_helper
INFO - 2023-11-02 13:28:20 --> Helper loaded: form_helper
INFO - 2023-11-02 13:28:20 --> Helper loaded: file_helper
INFO - 2023-11-02 13:28:20 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:28:20 --> Form Validation Class Initialized
INFO - 2023-11-02 13:28:20 --> Upload Class Initialized
INFO - 2023-11-02 13:28:20 --> Model "M_auth" initialized
INFO - 2023-11-02 13:28:20 --> Model "M_user" initialized
INFO - 2023-11-02 13:28:20 --> Model "M_produk" initialized
INFO - 2023-11-02 13:28:20 --> Controller Class Initialized
INFO - 2023-11-02 13:28:20 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:28:20 --> Final output sent to browser
DEBUG - 2023-11-02 13:28:20 --> Total execution time: 0.0033
ERROR - 2023-11-02 13:28:29 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:28:29 --> Config Class Initialized
INFO - 2023-11-02 13:28:29 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:28:29 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:28:29 --> Utf8 Class Initialized
INFO - 2023-11-02 13:28:29 --> URI Class Initialized
INFO - 2023-11-02 13:28:29 --> Router Class Initialized
INFO - 2023-11-02 13:28:29 --> Output Class Initialized
INFO - 2023-11-02 13:28:29 --> Security Class Initialized
DEBUG - 2023-11-02 13:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:28:29 --> Input Class Initialized
INFO - 2023-11-02 13:28:29 --> Language Class Initialized
INFO - 2023-11-02 13:28:29 --> Loader Class Initialized
INFO - 2023-11-02 13:28:29 --> Helper loaded: url_helper
INFO - 2023-11-02 13:28:29 --> Helper loaded: form_helper
INFO - 2023-11-02 13:28:29 --> Helper loaded: file_helper
INFO - 2023-11-02 13:28:29 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:28:29 --> Form Validation Class Initialized
INFO - 2023-11-02 13:28:29 --> Upload Class Initialized
INFO - 2023-11-02 13:28:29 --> Model "M_auth" initialized
INFO - 2023-11-02 13:28:29 --> Model "M_user" initialized
INFO - 2023-11-02 13:28:29 --> Model "M_produk" initialized
INFO - 2023-11-02 13:28:29 --> Controller Class Initialized
INFO - 2023-11-02 13:28:29 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:28:29 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:28:29 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:28:29 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:28:29 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:28:29 --> Model "M_bank" initialized
INFO - 2023-11-02 13:28:29 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:28:29 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:28:30 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:28:30 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:28:30 --> Final output sent to browser
DEBUG - 2023-11-02 13:28:30 --> Total execution time: 0.6702
ERROR - 2023-11-02 13:28:30 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:28:30 --> Config Class Initialized
INFO - 2023-11-02 13:28:30 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:28:30 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:28:30 --> Utf8 Class Initialized
INFO - 2023-11-02 13:28:30 --> URI Class Initialized
INFO - 2023-11-02 13:28:30 --> Router Class Initialized
INFO - 2023-11-02 13:28:30 --> Output Class Initialized
INFO - 2023-11-02 13:28:30 --> Security Class Initialized
DEBUG - 2023-11-02 13:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:28:30 --> Input Class Initialized
INFO - 2023-11-02 13:28:30 --> Language Class Initialized
INFO - 2023-11-02 13:28:30 --> Loader Class Initialized
INFO - 2023-11-02 13:28:30 --> Helper loaded: url_helper
INFO - 2023-11-02 13:28:30 --> Helper loaded: form_helper
INFO - 2023-11-02 13:28:30 --> Helper loaded: file_helper
INFO - 2023-11-02 13:28:30 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:28:30 --> Form Validation Class Initialized
INFO - 2023-11-02 13:28:30 --> Upload Class Initialized
INFO - 2023-11-02 13:28:30 --> Model "M_auth" initialized
INFO - 2023-11-02 13:28:30 --> Model "M_user" initialized
INFO - 2023-11-02 13:28:30 --> Model "M_produk" initialized
INFO - 2023-11-02 13:28:30 --> Controller Class Initialized
INFO - 2023-11-02 13:28:30 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:28:30 --> Final output sent to browser
DEBUG - 2023-11-02 13:28:30 --> Total execution time: 0.0033
ERROR - 2023-11-02 13:28:44 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:28:44 --> Config Class Initialized
INFO - 2023-11-02 13:28:44 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:28:44 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:28:44 --> Utf8 Class Initialized
INFO - 2023-11-02 13:28:44 --> URI Class Initialized
INFO - 2023-11-02 13:28:44 --> Router Class Initialized
INFO - 2023-11-02 13:28:44 --> Output Class Initialized
INFO - 2023-11-02 13:28:44 --> Security Class Initialized
DEBUG - 2023-11-02 13:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:28:44 --> Input Class Initialized
INFO - 2023-11-02 13:28:44 --> Language Class Initialized
INFO - 2023-11-02 13:28:44 --> Loader Class Initialized
INFO - 2023-11-02 13:28:44 --> Helper loaded: url_helper
INFO - 2023-11-02 13:28:44 --> Helper loaded: form_helper
INFO - 2023-11-02 13:28:44 --> Helper loaded: file_helper
INFO - 2023-11-02 13:28:44 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:28:44 --> Form Validation Class Initialized
INFO - 2023-11-02 13:28:44 --> Upload Class Initialized
INFO - 2023-11-02 13:28:44 --> Model "M_auth" initialized
INFO - 2023-11-02 13:28:44 --> Model "M_user" initialized
INFO - 2023-11-02 13:28:44 --> Model "M_produk" initialized
INFO - 2023-11-02 13:28:44 --> Controller Class Initialized
INFO - 2023-11-02 13:28:44 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:28:44 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:28:44 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:28:44 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:28:44 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:28:44 --> Model "M_bank" initialized
INFO - 2023-11-02 13:28:44 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:28:44 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:28:44 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:28:44 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:28:44 --> Final output sent to browser
DEBUG - 2023-11-02 13:28:44 --> Total execution time: 0.6663
ERROR - 2023-11-02 13:28:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:28:45 --> Config Class Initialized
INFO - 2023-11-02 13:28:45 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:28:45 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:28:45 --> Utf8 Class Initialized
INFO - 2023-11-02 13:28:45 --> URI Class Initialized
INFO - 2023-11-02 13:28:45 --> Router Class Initialized
INFO - 2023-11-02 13:28:45 --> Output Class Initialized
INFO - 2023-11-02 13:28:45 --> Security Class Initialized
DEBUG - 2023-11-02 13:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:28:45 --> Input Class Initialized
INFO - 2023-11-02 13:28:45 --> Language Class Initialized
INFO - 2023-11-02 13:28:45 --> Loader Class Initialized
INFO - 2023-11-02 13:28:45 --> Helper loaded: url_helper
INFO - 2023-11-02 13:28:45 --> Helper loaded: form_helper
INFO - 2023-11-02 13:28:45 --> Helper loaded: file_helper
INFO - 2023-11-02 13:28:45 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:28:45 --> Form Validation Class Initialized
INFO - 2023-11-02 13:28:45 --> Upload Class Initialized
INFO - 2023-11-02 13:28:45 --> Model "M_auth" initialized
INFO - 2023-11-02 13:28:45 --> Model "M_user" initialized
INFO - 2023-11-02 13:28:45 --> Model "M_produk" initialized
INFO - 2023-11-02 13:28:45 --> Controller Class Initialized
INFO - 2023-11-02 13:28:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:28:45 --> Final output sent to browser
DEBUG - 2023-11-02 13:28:45 --> Total execution time: 0.0030
ERROR - 2023-11-02 13:29:06 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:29:06 --> Config Class Initialized
INFO - 2023-11-02 13:29:06 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:29:06 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:29:06 --> Utf8 Class Initialized
INFO - 2023-11-02 13:29:06 --> URI Class Initialized
DEBUG - 2023-11-02 13:29:06 --> No URI present. Default controller set.
INFO - 2023-11-02 13:29:06 --> Router Class Initialized
INFO - 2023-11-02 13:29:06 --> Output Class Initialized
INFO - 2023-11-02 13:29:06 --> Security Class Initialized
DEBUG - 2023-11-02 13:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:29:06 --> Input Class Initialized
INFO - 2023-11-02 13:29:06 --> Language Class Initialized
INFO - 2023-11-02 13:29:06 --> Loader Class Initialized
INFO - 2023-11-02 13:29:06 --> Helper loaded: url_helper
INFO - 2023-11-02 13:29:06 --> Helper loaded: form_helper
INFO - 2023-11-02 13:29:06 --> Helper loaded: file_helper
INFO - 2023-11-02 13:29:06 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:29:06 --> Form Validation Class Initialized
INFO - 2023-11-02 13:29:06 --> Upload Class Initialized
INFO - 2023-11-02 13:29:06 --> Model "M_auth" initialized
INFO - 2023-11-02 13:29:06 --> Model "M_user" initialized
INFO - 2023-11-02 13:29:06 --> Model "M_produk" initialized
INFO - 2023-11-02 13:29:06 --> Controller Class Initialized
INFO - 2023-11-02 13:29:06 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:29:06 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:29:06 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:29:06 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:29:06 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:29:06 --> Model "M_bank" initialized
INFO - 2023-11-02 13:29:06 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:29:06 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:29:06 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:29:06 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 13:29:06 --> Final output sent to browser
DEBUG - 2023-11-02 13:29:06 --> Total execution time: 0.0046
ERROR - 2023-11-02 13:29:07 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:29:07 --> Config Class Initialized
INFO - 2023-11-02 13:29:07 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:29:07 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:29:07 --> Utf8 Class Initialized
INFO - 2023-11-02 13:29:07 --> URI Class Initialized
INFO - 2023-11-02 13:29:07 --> Router Class Initialized
INFO - 2023-11-02 13:29:07 --> Output Class Initialized
INFO - 2023-11-02 13:29:07 --> Security Class Initialized
DEBUG - 2023-11-02 13:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:29:07 --> Input Class Initialized
INFO - 2023-11-02 13:29:07 --> Language Class Initialized
INFO - 2023-11-02 13:29:07 --> Loader Class Initialized
INFO - 2023-11-02 13:29:07 --> Helper loaded: url_helper
INFO - 2023-11-02 13:29:07 --> Helper loaded: form_helper
INFO - 2023-11-02 13:29:07 --> Helper loaded: file_helper
INFO - 2023-11-02 13:29:07 --> Database Driver Class Initialized
ERROR - 2023-11-02 13:29:07 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:29:07 --> Config Class Initialized
INFO - 2023-11-02 13:29:07 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-11-02 13:29:07 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:29:07 --> Utf8 Class Initialized
INFO - 2023-11-02 13:29:07 --> URI Class Initialized
INFO - 2023-11-02 13:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:29:07 --> Form Validation Class Initialized
INFO - 2023-11-02 13:29:07 --> Router Class Initialized
INFO - 2023-11-02 13:29:07 --> Upload Class Initialized
INFO - 2023-11-02 13:29:07 --> Output Class Initialized
INFO - 2023-11-02 13:29:07 --> Security Class Initialized
INFO - 2023-11-02 13:29:07 --> Model "M_auth" initialized
DEBUG - 2023-11-02 13:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:29:07 --> Model "M_user" initialized
INFO - 2023-11-02 13:29:07 --> Input Class Initialized
INFO - 2023-11-02 13:29:07 --> Model "M_produk" initialized
INFO - 2023-11-02 13:29:07 --> Language Class Initialized
INFO - 2023-11-02 13:29:07 --> Controller Class Initialized
INFO - 2023-11-02 13:29:07 --> Loader Class Initialized
INFO - 2023-11-02 13:29:07 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:29:07 --> Helper loaded: url_helper
INFO - 2023-11-02 13:29:07 --> Final output sent to browser
DEBUG - 2023-11-02 13:29:07 --> Total execution time: 0.0028
INFO - 2023-11-02 13:29:07 --> Helper loaded: form_helper
INFO - 2023-11-02 13:29:07 --> Helper loaded: file_helper
INFO - 2023-11-02 13:29:07 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:29:07 --> Form Validation Class Initialized
INFO - 2023-11-02 13:29:07 --> Upload Class Initialized
INFO - 2023-11-02 13:29:07 --> Model "M_auth" initialized
INFO - 2023-11-02 13:29:07 --> Model "M_user" initialized
INFO - 2023-11-02 13:29:07 --> Model "M_produk" initialized
INFO - 2023-11-02 13:29:07 --> Controller Class Initialized
INFO - 2023-11-02 13:29:07 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:29:07 --> Final output sent to browser
DEBUG - 2023-11-02 13:29:07 --> Total execution time: 0.0028
ERROR - 2023-11-02 13:29:09 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:29:09 --> Config Class Initialized
INFO - 2023-11-02 13:29:09 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:29:09 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:29:09 --> Utf8 Class Initialized
INFO - 2023-11-02 13:29:09 --> URI Class Initialized
INFO - 2023-11-02 13:29:09 --> Router Class Initialized
INFO - 2023-11-02 13:29:09 --> Output Class Initialized
INFO - 2023-11-02 13:29:09 --> Security Class Initialized
DEBUG - 2023-11-02 13:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:29:09 --> Input Class Initialized
INFO - 2023-11-02 13:29:09 --> Language Class Initialized
INFO - 2023-11-02 13:29:09 --> Loader Class Initialized
INFO - 2023-11-02 13:29:09 --> Helper loaded: url_helper
INFO - 2023-11-02 13:29:09 --> Helper loaded: form_helper
INFO - 2023-11-02 13:29:09 --> Helper loaded: file_helper
INFO - 2023-11-02 13:29:09 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:29:09 --> Form Validation Class Initialized
INFO - 2023-11-02 13:29:09 --> Upload Class Initialized
INFO - 2023-11-02 13:29:09 --> Model "M_auth" initialized
INFO - 2023-11-02 13:29:09 --> Model "M_user" initialized
INFO - 2023-11-02 13:29:09 --> Model "M_produk" initialized
INFO - 2023-11-02 13:29:09 --> Controller Class Initialized
INFO - 2023-11-02 13:29:09 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:29:09 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:29:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:29:09 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:29:09 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:29:09 --> Model "M_bank" initialized
INFO - 2023-11-02 13:29:09 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:29:09 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:29:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:29:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-02 13:29:09 --> Final output sent to browser
DEBUG - 2023-11-02 13:29:09 --> Total execution time: 0.0037
ERROR - 2023-11-02 13:29:10 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:29:10 --> Config Class Initialized
INFO - 2023-11-02 13:29:10 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:29:10 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:29:10 --> Utf8 Class Initialized
INFO - 2023-11-02 13:29:10 --> URI Class Initialized
INFO - 2023-11-02 13:29:10 --> Router Class Initialized
INFO - 2023-11-02 13:29:10 --> Output Class Initialized
INFO - 2023-11-02 13:29:10 --> Security Class Initialized
DEBUG - 2023-11-02 13:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:29:10 --> Input Class Initialized
INFO - 2023-11-02 13:29:10 --> Language Class Initialized
INFO - 2023-11-02 13:29:10 --> Loader Class Initialized
INFO - 2023-11-02 13:29:10 --> Helper loaded: url_helper
INFO - 2023-11-02 13:29:10 --> Helper loaded: form_helper
INFO - 2023-11-02 13:29:10 --> Helper loaded: file_helper
INFO - 2023-11-02 13:29:10 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:29:10 --> Form Validation Class Initialized
INFO - 2023-11-02 13:29:10 --> Upload Class Initialized
INFO - 2023-11-02 13:29:10 --> Model "M_auth" initialized
INFO - 2023-11-02 13:29:10 --> Model "M_user" initialized
INFO - 2023-11-02 13:29:10 --> Model "M_produk" initialized
INFO - 2023-11-02 13:29:10 --> Controller Class Initialized
INFO - 2023-11-02 13:29:10 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:29:10 --> Final output sent to browser
DEBUG - 2023-11-02 13:29:10 --> Total execution time: 0.0026
ERROR - 2023-11-02 13:29:17 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:29:17 --> Config Class Initialized
INFO - 2023-11-02 13:29:17 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:29:17 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:29:17 --> Utf8 Class Initialized
INFO - 2023-11-02 13:29:17 --> URI Class Initialized
INFO - 2023-11-02 13:29:17 --> Router Class Initialized
INFO - 2023-11-02 13:29:17 --> Output Class Initialized
INFO - 2023-11-02 13:29:17 --> Security Class Initialized
DEBUG - 2023-11-02 13:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:29:17 --> Input Class Initialized
INFO - 2023-11-02 13:29:17 --> Language Class Initialized
INFO - 2023-11-02 13:29:17 --> Loader Class Initialized
INFO - 2023-11-02 13:29:17 --> Helper loaded: url_helper
INFO - 2023-11-02 13:29:17 --> Helper loaded: form_helper
INFO - 2023-11-02 13:29:17 --> Helper loaded: file_helper
INFO - 2023-11-02 13:29:17 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:29:17 --> Form Validation Class Initialized
INFO - 2023-11-02 13:29:17 --> Upload Class Initialized
INFO - 2023-11-02 13:29:17 --> Model "M_auth" initialized
INFO - 2023-11-02 13:29:17 --> Model "M_user" initialized
INFO - 2023-11-02 13:29:17 --> Model "M_produk" initialized
INFO - 2023-11-02 13:29:17 --> Controller Class Initialized
INFO - 2023-11-02 13:29:17 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:29:17 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:29:17 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:29:17 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:29:17 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:29:17 --> Model "M_bank" initialized
INFO - 2023-11-02 13:29:17 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:29:17 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:29:17 --> Email Class Initialized
INFO - 2023-11-02 13:29:18 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-11-02 13:29:20 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:29:20 --> Config Class Initialized
INFO - 2023-11-02 13:29:20 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:29:20 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:29:20 --> Utf8 Class Initialized
INFO - 2023-11-02 13:29:20 --> URI Class Initialized
INFO - 2023-11-02 13:29:20 --> Router Class Initialized
INFO - 2023-11-02 13:29:20 --> Output Class Initialized
INFO - 2023-11-02 13:29:20 --> Security Class Initialized
DEBUG - 2023-11-02 13:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:29:20 --> Input Class Initialized
INFO - 2023-11-02 13:29:20 --> Language Class Initialized
INFO - 2023-11-02 13:29:20 --> Loader Class Initialized
INFO - 2023-11-02 13:29:20 --> Helper loaded: url_helper
INFO - 2023-11-02 13:29:20 --> Helper loaded: form_helper
INFO - 2023-11-02 13:29:20 --> Helper loaded: file_helper
INFO - 2023-11-02 13:29:20 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:29:20 --> Form Validation Class Initialized
INFO - 2023-11-02 13:29:20 --> Upload Class Initialized
INFO - 2023-11-02 13:29:20 --> Model "M_auth" initialized
INFO - 2023-11-02 13:29:20 --> Model "M_user" initialized
INFO - 2023-11-02 13:29:20 --> Model "M_produk" initialized
INFO - 2023-11-02 13:29:20 --> Controller Class Initialized
INFO - 2023-11-02 13:29:20 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:29:20 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:29:20 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:29:20 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:29:20 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:29:20 --> Model "M_bank" initialized
INFO - 2023-11-02 13:29:20 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:29:20 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:29:21 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:29:21 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:29:21 --> Final output sent to browser
DEBUG - 2023-11-02 13:29:21 --> Total execution time: 0.6784
ERROR - 2023-11-02 13:29:21 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:29:21 --> Config Class Initialized
INFO - 2023-11-02 13:29:21 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:29:21 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:29:21 --> Utf8 Class Initialized
INFO - 2023-11-02 13:29:21 --> URI Class Initialized
INFO - 2023-11-02 13:29:21 --> Router Class Initialized
INFO - 2023-11-02 13:29:21 --> Output Class Initialized
INFO - 2023-11-02 13:29:21 --> Security Class Initialized
DEBUG - 2023-11-02 13:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:29:21 --> Input Class Initialized
INFO - 2023-11-02 13:29:21 --> Language Class Initialized
INFO - 2023-11-02 13:29:21 --> Loader Class Initialized
INFO - 2023-11-02 13:29:21 --> Helper loaded: url_helper
INFO - 2023-11-02 13:29:21 --> Helper loaded: form_helper
INFO - 2023-11-02 13:29:21 --> Helper loaded: file_helper
INFO - 2023-11-02 13:29:21 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:29:21 --> Form Validation Class Initialized
INFO - 2023-11-02 13:29:21 --> Upload Class Initialized
INFO - 2023-11-02 13:29:21 --> Model "M_auth" initialized
INFO - 2023-11-02 13:29:21 --> Model "M_user" initialized
INFO - 2023-11-02 13:29:21 --> Model "M_produk" initialized
INFO - 2023-11-02 13:29:21 --> Controller Class Initialized
INFO - 2023-11-02 13:29:21 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:29:21 --> Final output sent to browser
DEBUG - 2023-11-02 13:29:21 --> Total execution time: 0.0024
ERROR - 2023-11-02 13:29:25 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:29:25 --> Config Class Initialized
INFO - 2023-11-02 13:29:25 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:29:25 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:29:25 --> Utf8 Class Initialized
INFO - 2023-11-02 13:29:25 --> URI Class Initialized
INFO - 2023-11-02 13:29:25 --> Router Class Initialized
INFO - 2023-11-02 13:29:25 --> Output Class Initialized
INFO - 2023-11-02 13:29:25 --> Security Class Initialized
DEBUG - 2023-11-02 13:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:29:25 --> Input Class Initialized
INFO - 2023-11-02 13:29:25 --> Language Class Initialized
INFO - 2023-11-02 13:29:25 --> Loader Class Initialized
INFO - 2023-11-02 13:29:25 --> Helper loaded: url_helper
INFO - 2023-11-02 13:29:25 --> Helper loaded: form_helper
INFO - 2023-11-02 13:29:25 --> Helper loaded: file_helper
INFO - 2023-11-02 13:29:25 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:29:25 --> Form Validation Class Initialized
INFO - 2023-11-02 13:29:25 --> Upload Class Initialized
INFO - 2023-11-02 13:29:25 --> Model "M_auth" initialized
INFO - 2023-11-02 13:29:25 --> Model "M_user" initialized
INFO - 2023-11-02 13:29:25 --> Model "M_produk" initialized
INFO - 2023-11-02 13:29:25 --> Controller Class Initialized
INFO - 2023-11-02 13:29:25 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:29:25 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:29:25 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:29:25 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:29:25 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:29:25 --> Model "M_bank" initialized
INFO - 2023-11-02 13:29:25 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:29:25 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:29:26 --> Final output sent to browser
DEBUG - 2023-11-02 13:29:26 --> Total execution time: 0.6904
ERROR - 2023-11-02 13:29:31 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:29:31 --> Config Class Initialized
INFO - 2023-11-02 13:29:31 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:29:31 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:29:31 --> Utf8 Class Initialized
INFO - 2023-11-02 13:29:31 --> URI Class Initialized
INFO - 2023-11-02 13:29:31 --> Router Class Initialized
INFO - 2023-11-02 13:29:31 --> Output Class Initialized
INFO - 2023-11-02 13:29:31 --> Security Class Initialized
DEBUG - 2023-11-02 13:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:29:31 --> Input Class Initialized
INFO - 2023-11-02 13:29:31 --> Language Class Initialized
INFO - 2023-11-02 13:29:31 --> Loader Class Initialized
INFO - 2023-11-02 13:29:31 --> Helper loaded: url_helper
INFO - 2023-11-02 13:29:31 --> Helper loaded: form_helper
INFO - 2023-11-02 13:29:31 --> Helper loaded: file_helper
INFO - 2023-11-02 13:29:31 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:29:31 --> Form Validation Class Initialized
INFO - 2023-11-02 13:29:31 --> Upload Class Initialized
INFO - 2023-11-02 13:29:31 --> Model "M_auth" initialized
INFO - 2023-11-02 13:29:31 --> Model "M_user" initialized
INFO - 2023-11-02 13:29:31 --> Model "M_produk" initialized
INFO - 2023-11-02 13:29:31 --> Controller Class Initialized
INFO - 2023-11-02 13:29:31 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:29:31 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:29:31 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:29:31 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:29:31 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:29:31 --> Model "M_bank" initialized
INFO - 2023-11-02 13:29:31 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:29:31 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:29:32 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:29:32 --> Final output sent to browser
DEBUG - 2023-11-02 13:29:32 --> Total execution time: 0.6902
ERROR - 2023-11-02 13:30:39 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:30:39 --> Config Class Initialized
INFO - 2023-11-02 13:30:39 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:30:39 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:30:39 --> Utf8 Class Initialized
INFO - 2023-11-02 13:30:39 --> URI Class Initialized
INFO - 2023-11-02 13:30:39 --> Router Class Initialized
INFO - 2023-11-02 13:30:39 --> Output Class Initialized
INFO - 2023-11-02 13:30:39 --> Security Class Initialized
DEBUG - 2023-11-02 13:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:30:39 --> Input Class Initialized
INFO - 2023-11-02 13:30:39 --> Language Class Initialized
INFO - 2023-11-02 13:30:39 --> Loader Class Initialized
INFO - 2023-11-02 13:30:39 --> Helper loaded: url_helper
INFO - 2023-11-02 13:30:39 --> Helper loaded: form_helper
INFO - 2023-11-02 13:30:39 --> Helper loaded: file_helper
INFO - 2023-11-02 13:30:39 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:30:39 --> Form Validation Class Initialized
INFO - 2023-11-02 13:30:39 --> Upload Class Initialized
INFO - 2023-11-02 13:30:39 --> Model "M_auth" initialized
INFO - 2023-11-02 13:30:39 --> Model "M_user" initialized
INFO - 2023-11-02 13:30:39 --> Model "M_produk" initialized
INFO - 2023-11-02 13:30:39 --> Controller Class Initialized
INFO - 2023-11-02 13:30:39 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:30:39 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:30:39 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:30:39 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:30:39 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:30:39 --> Model "M_bank" initialized
INFO - 2023-11-02 13:30:39 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:30:39 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:30:39 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:30:39 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:30:39 --> Final output sent to browser
DEBUG - 2023-11-02 13:30:39 --> Total execution time: 0.6962
ERROR - 2023-11-02 13:30:40 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:30:40 --> Config Class Initialized
INFO - 2023-11-02 13:30:40 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:30:40 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:30:40 --> Utf8 Class Initialized
INFO - 2023-11-02 13:30:40 --> URI Class Initialized
INFO - 2023-11-02 13:30:40 --> Router Class Initialized
INFO - 2023-11-02 13:30:40 --> Output Class Initialized
INFO - 2023-11-02 13:30:40 --> Security Class Initialized
DEBUG - 2023-11-02 13:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:30:40 --> Input Class Initialized
INFO - 2023-11-02 13:30:40 --> Language Class Initialized
INFO - 2023-11-02 13:30:40 --> Loader Class Initialized
INFO - 2023-11-02 13:30:40 --> Helper loaded: url_helper
INFO - 2023-11-02 13:30:40 --> Helper loaded: form_helper
INFO - 2023-11-02 13:30:40 --> Helper loaded: file_helper
INFO - 2023-11-02 13:30:40 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:30:40 --> Form Validation Class Initialized
INFO - 2023-11-02 13:30:40 --> Upload Class Initialized
INFO - 2023-11-02 13:30:40 --> Model "M_auth" initialized
INFO - 2023-11-02 13:30:40 --> Model "M_user" initialized
INFO - 2023-11-02 13:30:40 --> Model "M_produk" initialized
INFO - 2023-11-02 13:30:40 --> Controller Class Initialized
INFO - 2023-11-02 13:30:40 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:30:40 --> Final output sent to browser
DEBUG - 2023-11-02 13:30:40 --> Total execution time: 0.0046
ERROR - 2023-11-02 13:30:52 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:30:52 --> Config Class Initialized
INFO - 2023-11-02 13:30:52 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:30:52 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:30:52 --> Utf8 Class Initialized
INFO - 2023-11-02 13:30:52 --> URI Class Initialized
INFO - 2023-11-02 13:30:52 --> Router Class Initialized
INFO - 2023-11-02 13:30:52 --> Output Class Initialized
INFO - 2023-11-02 13:30:52 --> Security Class Initialized
DEBUG - 2023-11-02 13:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:30:52 --> Input Class Initialized
INFO - 2023-11-02 13:30:52 --> Language Class Initialized
INFO - 2023-11-02 13:30:52 --> Loader Class Initialized
INFO - 2023-11-02 13:30:52 --> Helper loaded: url_helper
INFO - 2023-11-02 13:30:52 --> Helper loaded: form_helper
INFO - 2023-11-02 13:30:52 --> Helper loaded: file_helper
INFO - 2023-11-02 13:30:52 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:30:52 --> Form Validation Class Initialized
INFO - 2023-11-02 13:30:52 --> Upload Class Initialized
INFO - 2023-11-02 13:30:52 --> Model "M_auth" initialized
INFO - 2023-11-02 13:30:52 --> Model "M_user" initialized
INFO - 2023-11-02 13:30:52 --> Model "M_produk" initialized
INFO - 2023-11-02 13:30:52 --> Controller Class Initialized
INFO - 2023-11-02 13:30:52 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:30:52 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:30:52 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:30:52 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:30:52 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:30:52 --> Model "M_bank" initialized
INFO - 2023-11-02 13:30:52 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:30:52 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:30:52 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:30:52 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_edit_profile_pelanggan.php
INFO - 2023-11-02 13:30:52 --> Final output sent to browser
DEBUG - 2023-11-02 13:30:52 --> Total execution time: 0.0129
ERROR - 2023-11-02 13:30:52 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:30:52 --> Config Class Initialized
INFO - 2023-11-02 13:30:52 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:30:52 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:30:52 --> Utf8 Class Initialized
INFO - 2023-11-02 13:30:52 --> URI Class Initialized
INFO - 2023-11-02 13:30:52 --> Router Class Initialized
INFO - 2023-11-02 13:30:52 --> Output Class Initialized
INFO - 2023-11-02 13:30:52 --> Security Class Initialized
DEBUG - 2023-11-02 13:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:30:52 --> Input Class Initialized
INFO - 2023-11-02 13:30:52 --> Language Class Initialized
INFO - 2023-11-02 13:30:52 --> Loader Class Initialized
INFO - 2023-11-02 13:30:52 --> Helper loaded: url_helper
INFO - 2023-11-02 13:30:52 --> Helper loaded: form_helper
INFO - 2023-11-02 13:30:52 --> Helper loaded: file_helper
INFO - 2023-11-02 13:30:52 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:30:52 --> Form Validation Class Initialized
INFO - 2023-11-02 13:30:52 --> Upload Class Initialized
INFO - 2023-11-02 13:30:52 --> Model "M_auth" initialized
INFO - 2023-11-02 13:30:52 --> Model "M_user" initialized
INFO - 2023-11-02 13:30:52 --> Model "M_produk" initialized
INFO - 2023-11-02 13:30:52 --> Controller Class Initialized
INFO - 2023-11-02 13:30:52 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:30:52 --> Final output sent to browser
DEBUG - 2023-11-02 13:30:52 --> Total execution time: 0.0036
ERROR - 2023-11-02 13:30:56 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:30:56 --> Config Class Initialized
INFO - 2023-11-02 13:30:56 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:30:56 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:30:56 --> Utf8 Class Initialized
INFO - 2023-11-02 13:30:56 --> URI Class Initialized
INFO - 2023-11-02 13:30:56 --> Router Class Initialized
INFO - 2023-11-02 13:30:56 --> Output Class Initialized
INFO - 2023-11-02 13:30:56 --> Security Class Initialized
DEBUG - 2023-11-02 13:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:30:56 --> Input Class Initialized
INFO - 2023-11-02 13:30:56 --> Language Class Initialized
INFO - 2023-11-02 13:30:56 --> Loader Class Initialized
INFO - 2023-11-02 13:30:56 --> Helper loaded: url_helper
INFO - 2023-11-02 13:30:56 --> Helper loaded: form_helper
INFO - 2023-11-02 13:30:56 --> Helper loaded: file_helper
INFO - 2023-11-02 13:30:56 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:30:56 --> Form Validation Class Initialized
INFO - 2023-11-02 13:30:56 --> Upload Class Initialized
INFO - 2023-11-02 13:30:56 --> Model "M_auth" initialized
INFO - 2023-11-02 13:30:56 --> Model "M_user" initialized
INFO - 2023-11-02 13:30:56 --> Model "M_produk" initialized
INFO - 2023-11-02 13:30:56 --> Controller Class Initialized
INFO - 2023-11-02 13:30:56 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:30:56 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:30:56 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:30:56 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:30:56 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:30:56 --> Model "M_bank" initialized
INFO - 2023-11-02 13:30:56 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:30:56 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:30:56 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:30:56 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:30:56 --> Final output sent to browser
DEBUG - 2023-11-02 13:30:56 --> Total execution time: 0.6779
ERROR - 2023-11-02 13:30:57 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:30:57 --> Config Class Initialized
INFO - 2023-11-02 13:30:57 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:30:57 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:30:57 --> Utf8 Class Initialized
INFO - 2023-11-02 13:30:57 --> URI Class Initialized
INFO - 2023-11-02 13:30:57 --> Router Class Initialized
INFO - 2023-11-02 13:30:57 --> Output Class Initialized
INFO - 2023-11-02 13:30:57 --> Security Class Initialized
DEBUG - 2023-11-02 13:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:30:57 --> Input Class Initialized
INFO - 2023-11-02 13:30:57 --> Language Class Initialized
INFO - 2023-11-02 13:30:57 --> Loader Class Initialized
INFO - 2023-11-02 13:30:57 --> Helper loaded: url_helper
INFO - 2023-11-02 13:30:57 --> Helper loaded: form_helper
INFO - 2023-11-02 13:30:57 --> Helper loaded: file_helper
INFO - 2023-11-02 13:30:57 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:30:57 --> Form Validation Class Initialized
INFO - 2023-11-02 13:30:57 --> Upload Class Initialized
INFO - 2023-11-02 13:30:57 --> Model "M_auth" initialized
INFO - 2023-11-02 13:30:57 --> Model "M_user" initialized
INFO - 2023-11-02 13:30:57 --> Model "M_produk" initialized
INFO - 2023-11-02 13:30:57 --> Controller Class Initialized
INFO - 2023-11-02 13:30:57 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:30:57 --> Final output sent to browser
DEBUG - 2023-11-02 13:30:57 --> Total execution time: 0.0054
ERROR - 2023-11-02 13:35:14 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:35:14 --> Config Class Initialized
INFO - 2023-11-02 13:35:14 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:35:14 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:35:14 --> Utf8 Class Initialized
INFO - 2023-11-02 13:35:14 --> URI Class Initialized
INFO - 2023-11-02 13:35:14 --> Router Class Initialized
INFO - 2023-11-02 13:35:14 --> Output Class Initialized
INFO - 2023-11-02 13:35:14 --> Security Class Initialized
DEBUG - 2023-11-02 13:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:35:14 --> Input Class Initialized
INFO - 2023-11-02 13:35:14 --> Language Class Initialized
INFO - 2023-11-02 13:35:14 --> Loader Class Initialized
INFO - 2023-11-02 13:35:14 --> Helper loaded: url_helper
INFO - 2023-11-02 13:35:14 --> Helper loaded: form_helper
INFO - 2023-11-02 13:35:14 --> Helper loaded: file_helper
INFO - 2023-11-02 13:35:14 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:35:14 --> Form Validation Class Initialized
INFO - 2023-11-02 13:35:14 --> Upload Class Initialized
INFO - 2023-11-02 13:35:14 --> Model "M_auth" initialized
INFO - 2023-11-02 13:35:14 --> Model "M_user" initialized
INFO - 2023-11-02 13:35:14 --> Model "M_produk" initialized
INFO - 2023-11-02 13:35:14 --> Controller Class Initialized
INFO - 2023-11-02 13:35:14 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:35:14 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:35:14 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:35:14 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:35:14 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:35:14 --> Model "M_bank" initialized
INFO - 2023-11-02 13:35:14 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:35:14 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:35:15 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:35:15 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:35:15 --> Final output sent to browser
DEBUG - 2023-11-02 13:35:15 --> Total execution time: 0.8359
ERROR - 2023-11-02 13:35:15 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:35:15 --> Config Class Initialized
INFO - 2023-11-02 13:35:15 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:35:15 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:35:15 --> Utf8 Class Initialized
INFO - 2023-11-02 13:35:15 --> URI Class Initialized
INFO - 2023-11-02 13:35:15 --> Router Class Initialized
INFO - 2023-11-02 13:35:15 --> Output Class Initialized
INFO - 2023-11-02 13:35:15 --> Security Class Initialized
DEBUG - 2023-11-02 13:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:35:15 --> Input Class Initialized
INFO - 2023-11-02 13:35:15 --> Language Class Initialized
INFO - 2023-11-02 13:35:15 --> Loader Class Initialized
INFO - 2023-11-02 13:35:15 --> Helper loaded: url_helper
INFO - 2023-11-02 13:35:15 --> Helper loaded: form_helper
INFO - 2023-11-02 13:35:15 --> Helper loaded: file_helper
INFO - 2023-11-02 13:35:15 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:35:15 --> Form Validation Class Initialized
INFO - 2023-11-02 13:35:15 --> Upload Class Initialized
INFO - 2023-11-02 13:35:15 --> Model "M_auth" initialized
INFO - 2023-11-02 13:35:15 --> Model "M_user" initialized
INFO - 2023-11-02 13:35:15 --> Model "M_produk" initialized
INFO - 2023-11-02 13:35:15 --> Controller Class Initialized
INFO - 2023-11-02 13:35:15 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:35:15 --> Final output sent to browser
DEBUG - 2023-11-02 13:35:15 --> Total execution time: 0.0027
ERROR - 2023-11-02 13:35:54 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:35:54 --> Config Class Initialized
INFO - 2023-11-02 13:35:54 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:35:54 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:35:54 --> Utf8 Class Initialized
INFO - 2023-11-02 13:35:54 --> URI Class Initialized
DEBUG - 2023-11-02 13:35:54 --> No URI present. Default controller set.
INFO - 2023-11-02 13:35:54 --> Router Class Initialized
INFO - 2023-11-02 13:35:54 --> Output Class Initialized
INFO - 2023-11-02 13:35:54 --> Security Class Initialized
DEBUG - 2023-11-02 13:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:35:54 --> Input Class Initialized
INFO - 2023-11-02 13:35:54 --> Language Class Initialized
INFO - 2023-11-02 13:35:54 --> Loader Class Initialized
INFO - 2023-11-02 13:35:54 --> Helper loaded: url_helper
INFO - 2023-11-02 13:35:54 --> Helper loaded: form_helper
INFO - 2023-11-02 13:35:54 --> Helper loaded: file_helper
INFO - 2023-11-02 13:35:54 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:35:54 --> Form Validation Class Initialized
INFO - 2023-11-02 13:35:54 --> Upload Class Initialized
INFO - 2023-11-02 13:35:54 --> Model "M_auth" initialized
INFO - 2023-11-02 13:35:54 --> Model "M_user" initialized
INFO - 2023-11-02 13:35:54 --> Model "M_produk" initialized
INFO - 2023-11-02 13:35:54 --> Controller Class Initialized
INFO - 2023-11-02 13:35:54 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:35:54 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:35:54 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:35:54 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:35:54 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:35:54 --> Model "M_bank" initialized
INFO - 2023-11-02 13:35:54 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:35:54 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:35:54 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:35:54 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 13:35:54 --> Final output sent to browser
DEBUG - 2023-11-02 13:35:54 --> Total execution time: 0.0045
ERROR - 2023-11-02 13:35:55 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:35:55 --> Config Class Initialized
INFO - 2023-11-02 13:35:55 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:35:55 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:35:55 --> Utf8 Class Initialized
INFO - 2023-11-02 13:35:55 --> URI Class Initialized
INFO - 2023-11-02 13:35:55 --> Router Class Initialized
INFO - 2023-11-02 13:35:55 --> Output Class Initialized
INFO - 2023-11-02 13:35:55 --> Security Class Initialized
DEBUG - 2023-11-02 13:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:35:55 --> Input Class Initialized
INFO - 2023-11-02 13:35:55 --> Language Class Initialized
INFO - 2023-11-02 13:35:55 --> Loader Class Initialized
INFO - 2023-11-02 13:35:55 --> Helper loaded: url_helper
INFO - 2023-11-02 13:35:55 --> Helper loaded: form_helper
INFO - 2023-11-02 13:35:55 --> Helper loaded: file_helper
INFO - 2023-11-02 13:35:55 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:35:55 --> Form Validation Class Initialized
INFO - 2023-11-02 13:35:55 --> Upload Class Initialized
INFO - 2023-11-02 13:35:55 --> Model "M_auth" initialized
INFO - 2023-11-02 13:35:55 --> Model "M_user" initialized
INFO - 2023-11-02 13:35:55 --> Model "M_produk" initialized
INFO - 2023-11-02 13:35:55 --> Controller Class Initialized
INFO - 2023-11-02 13:35:55 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:35:55 --> Final output sent to browser
DEBUG - 2023-11-02 13:35:55 --> Total execution time: 0.0020
ERROR - 2023-11-02 13:35:55 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:35:55 --> Config Class Initialized
INFO - 2023-11-02 13:35:55 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:35:55 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:35:55 --> Utf8 Class Initialized
INFO - 2023-11-02 13:35:55 --> URI Class Initialized
INFO - 2023-11-02 13:35:55 --> Router Class Initialized
INFO - 2023-11-02 13:35:55 --> Output Class Initialized
INFO - 2023-11-02 13:35:55 --> Security Class Initialized
DEBUG - 2023-11-02 13:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:35:55 --> Input Class Initialized
INFO - 2023-11-02 13:35:55 --> Language Class Initialized
INFO - 2023-11-02 13:35:55 --> Loader Class Initialized
INFO - 2023-11-02 13:35:55 --> Helper loaded: url_helper
INFO - 2023-11-02 13:35:55 --> Helper loaded: form_helper
INFO - 2023-11-02 13:35:55 --> Helper loaded: file_helper
INFO - 2023-11-02 13:35:55 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:35:55 --> Form Validation Class Initialized
INFO - 2023-11-02 13:35:55 --> Upload Class Initialized
INFO - 2023-11-02 13:35:55 --> Model "M_auth" initialized
INFO - 2023-11-02 13:35:55 --> Model "M_user" initialized
INFO - 2023-11-02 13:35:55 --> Model "M_produk" initialized
INFO - 2023-11-02 13:35:55 --> Controller Class Initialized
INFO - 2023-11-02 13:35:55 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:35:55 --> Final output sent to browser
DEBUG - 2023-11-02 13:35:55 --> Total execution time: 0.0018
ERROR - 2023-11-02 13:36:03 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:36:03 --> Config Class Initialized
INFO - 2023-11-02 13:36:03 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:36:03 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:36:03 --> Utf8 Class Initialized
INFO - 2023-11-02 13:36:03 --> URI Class Initialized
INFO - 2023-11-02 13:36:03 --> Router Class Initialized
INFO - 2023-11-02 13:36:03 --> Output Class Initialized
INFO - 2023-11-02 13:36:03 --> Security Class Initialized
DEBUG - 2023-11-02 13:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:36:03 --> Input Class Initialized
INFO - 2023-11-02 13:36:03 --> Language Class Initialized
INFO - 2023-11-02 13:36:03 --> Loader Class Initialized
INFO - 2023-11-02 13:36:03 --> Helper loaded: url_helper
INFO - 2023-11-02 13:36:03 --> Helper loaded: form_helper
INFO - 2023-11-02 13:36:03 --> Helper loaded: file_helper
INFO - 2023-11-02 13:36:03 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:36:03 --> Form Validation Class Initialized
INFO - 2023-11-02 13:36:03 --> Upload Class Initialized
INFO - 2023-11-02 13:36:03 --> Model "M_auth" initialized
INFO - 2023-11-02 13:36:03 --> Model "M_user" initialized
INFO - 2023-11-02 13:36:03 --> Model "M_produk" initialized
INFO - 2023-11-02 13:36:03 --> Controller Class Initialized
INFO - 2023-11-02 13:36:03 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:36:03 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:36:03 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:36:03 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:36:03 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:36:03 --> Model "M_bank" initialized
INFO - 2023-11-02 13:36:03 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:36:03 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:36:03 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:36:03 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-02 13:36:03 --> Final output sent to browser
DEBUG - 2023-11-02 13:36:03 --> Total execution time: 0.0050
ERROR - 2023-11-02 13:36:04 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:36:04 --> Config Class Initialized
INFO - 2023-11-02 13:36:04 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:36:04 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:36:04 --> Utf8 Class Initialized
INFO - 2023-11-02 13:36:04 --> URI Class Initialized
INFO - 2023-11-02 13:36:04 --> Router Class Initialized
INFO - 2023-11-02 13:36:04 --> Output Class Initialized
INFO - 2023-11-02 13:36:04 --> Security Class Initialized
DEBUG - 2023-11-02 13:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:36:04 --> Input Class Initialized
INFO - 2023-11-02 13:36:04 --> Language Class Initialized
INFO - 2023-11-02 13:36:04 --> Loader Class Initialized
INFO - 2023-11-02 13:36:04 --> Helper loaded: url_helper
INFO - 2023-11-02 13:36:04 --> Helper loaded: form_helper
INFO - 2023-11-02 13:36:04 --> Helper loaded: file_helper
INFO - 2023-11-02 13:36:04 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:36:04 --> Form Validation Class Initialized
INFO - 2023-11-02 13:36:04 --> Upload Class Initialized
INFO - 2023-11-02 13:36:04 --> Model "M_auth" initialized
INFO - 2023-11-02 13:36:04 --> Model "M_user" initialized
INFO - 2023-11-02 13:36:04 --> Model "M_produk" initialized
INFO - 2023-11-02 13:36:04 --> Controller Class Initialized
INFO - 2023-11-02 13:36:04 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:36:04 --> Final output sent to browser
DEBUG - 2023-11-02 13:36:04 --> Total execution time: 0.0025
ERROR - 2023-11-02 13:36:15 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:36:15 --> Config Class Initialized
INFO - 2023-11-02 13:36:15 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:36:15 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:36:15 --> Utf8 Class Initialized
INFO - 2023-11-02 13:36:15 --> URI Class Initialized
INFO - 2023-11-02 13:36:15 --> Router Class Initialized
INFO - 2023-11-02 13:36:15 --> Output Class Initialized
INFO - 2023-11-02 13:36:15 --> Security Class Initialized
DEBUG - 2023-11-02 13:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:36:15 --> Input Class Initialized
INFO - 2023-11-02 13:36:15 --> Language Class Initialized
INFO - 2023-11-02 13:36:15 --> Loader Class Initialized
INFO - 2023-11-02 13:36:15 --> Helper loaded: url_helper
INFO - 2023-11-02 13:36:15 --> Helper loaded: form_helper
INFO - 2023-11-02 13:36:15 --> Helper loaded: file_helper
INFO - 2023-11-02 13:36:15 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:36:15 --> Form Validation Class Initialized
INFO - 2023-11-02 13:36:15 --> Upload Class Initialized
INFO - 2023-11-02 13:36:15 --> Model "M_auth" initialized
INFO - 2023-11-02 13:36:15 --> Model "M_user" initialized
INFO - 2023-11-02 13:36:15 --> Model "M_produk" initialized
INFO - 2023-11-02 13:36:15 --> Controller Class Initialized
INFO - 2023-11-02 13:36:15 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:36:15 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:36:15 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:36:15 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:36:15 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:36:15 --> Model "M_bank" initialized
INFO - 2023-11-02 13:36:15 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:36:15 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:36:15 --> Email Class Initialized
INFO - 2023-11-02 13:36:16 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-11-02 13:36:18 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:36:18 --> Config Class Initialized
INFO - 2023-11-02 13:36:18 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:36:18 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:36:18 --> Utf8 Class Initialized
INFO - 2023-11-02 13:36:18 --> URI Class Initialized
INFO - 2023-11-02 13:36:18 --> Router Class Initialized
INFO - 2023-11-02 13:36:18 --> Output Class Initialized
INFO - 2023-11-02 13:36:18 --> Security Class Initialized
DEBUG - 2023-11-02 13:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:36:18 --> Input Class Initialized
INFO - 2023-11-02 13:36:18 --> Language Class Initialized
INFO - 2023-11-02 13:36:18 --> Loader Class Initialized
INFO - 2023-11-02 13:36:18 --> Helper loaded: url_helper
INFO - 2023-11-02 13:36:18 --> Helper loaded: form_helper
INFO - 2023-11-02 13:36:18 --> Helper loaded: file_helper
INFO - 2023-11-02 13:36:18 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:36:18 --> Form Validation Class Initialized
INFO - 2023-11-02 13:36:18 --> Upload Class Initialized
INFO - 2023-11-02 13:36:18 --> Model "M_auth" initialized
INFO - 2023-11-02 13:36:18 --> Model "M_user" initialized
INFO - 2023-11-02 13:36:18 --> Model "M_produk" initialized
INFO - 2023-11-02 13:36:18 --> Controller Class Initialized
INFO - 2023-11-02 13:36:18 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:36:18 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:36:18 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:36:18 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:36:18 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:36:18 --> Model "M_bank" initialized
INFO - 2023-11-02 13:36:18 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:36:18 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:36:18 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:36:18 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:36:18 --> Final output sent to browser
DEBUG - 2023-11-02 13:36:18 --> Total execution time: 0.7186
ERROR - 2023-11-02 13:36:36 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:36:36 --> Config Class Initialized
INFO - 2023-11-02 13:36:36 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:36:36 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:36:36 --> Utf8 Class Initialized
INFO - 2023-11-02 13:36:36 --> URI Class Initialized
INFO - 2023-11-02 13:36:36 --> Router Class Initialized
INFO - 2023-11-02 13:36:36 --> Output Class Initialized
INFO - 2023-11-02 13:36:36 --> Security Class Initialized
DEBUG - 2023-11-02 13:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:36:36 --> Input Class Initialized
INFO - 2023-11-02 13:36:36 --> Language Class Initialized
INFO - 2023-11-02 13:36:36 --> Loader Class Initialized
INFO - 2023-11-02 13:36:36 --> Helper loaded: url_helper
INFO - 2023-11-02 13:36:36 --> Helper loaded: form_helper
INFO - 2023-11-02 13:36:36 --> Helper loaded: file_helper
INFO - 2023-11-02 13:36:36 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:36:36 --> Form Validation Class Initialized
INFO - 2023-11-02 13:36:36 --> Upload Class Initialized
INFO - 2023-11-02 13:36:36 --> Model "M_auth" initialized
INFO - 2023-11-02 13:36:36 --> Model "M_user" initialized
INFO - 2023-11-02 13:36:36 --> Model "M_produk" initialized
INFO - 2023-11-02 13:36:36 --> Controller Class Initialized
INFO - 2023-11-02 13:36:36 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:36:36 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:36:36 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:36:36 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:36:36 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:36:36 --> Model "M_bank" initialized
INFO - 2023-11-02 13:36:36 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:36:36 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:36:41 --> Final output sent to browser
DEBUG - 2023-11-02 13:36:41 --> Total execution time: 5.2514
ERROR - 2023-11-02 13:36:57 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:36:57 --> Config Class Initialized
INFO - 2023-11-02 13:36:57 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:36:57 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:36:57 --> Utf8 Class Initialized
INFO - 2023-11-02 13:36:57 --> URI Class Initialized
INFO - 2023-11-02 13:36:57 --> Router Class Initialized
INFO - 2023-11-02 13:36:57 --> Output Class Initialized
INFO - 2023-11-02 13:36:57 --> Security Class Initialized
DEBUG - 2023-11-02 13:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:36:57 --> Input Class Initialized
INFO - 2023-11-02 13:36:57 --> Language Class Initialized
INFO - 2023-11-02 13:36:57 --> Loader Class Initialized
INFO - 2023-11-02 13:36:57 --> Helper loaded: url_helper
INFO - 2023-11-02 13:36:57 --> Helper loaded: form_helper
INFO - 2023-11-02 13:36:57 --> Helper loaded: file_helper
INFO - 2023-11-02 13:36:57 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:36:57 --> Form Validation Class Initialized
INFO - 2023-11-02 13:36:57 --> Upload Class Initialized
INFO - 2023-11-02 13:36:57 --> Model "M_auth" initialized
INFO - 2023-11-02 13:36:57 --> Model "M_user" initialized
INFO - 2023-11-02 13:36:57 --> Model "M_produk" initialized
INFO - 2023-11-02 13:36:57 --> Controller Class Initialized
INFO - 2023-11-02 13:36:57 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:36:57 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:36:57 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:36:57 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:36:57 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:36:57 --> Model "M_bank" initialized
INFO - 2023-11-02 13:36:57 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:36:57 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:36:57 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:36:57 --> Final output sent to browser
DEBUG - 2023-11-02 13:36:57 --> Total execution time: 0.6550
ERROR - 2023-11-02 13:37:12 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:37:12 --> Config Class Initialized
INFO - 2023-11-02 13:37:12 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:37:12 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:37:12 --> Utf8 Class Initialized
INFO - 2023-11-02 13:37:12 --> URI Class Initialized
INFO - 2023-11-02 13:37:12 --> Router Class Initialized
INFO - 2023-11-02 13:37:12 --> Output Class Initialized
INFO - 2023-11-02 13:37:12 --> Security Class Initialized
DEBUG - 2023-11-02 13:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:37:12 --> Input Class Initialized
INFO - 2023-11-02 13:37:12 --> Language Class Initialized
INFO - 2023-11-02 13:37:12 --> Loader Class Initialized
INFO - 2023-11-02 13:37:12 --> Helper loaded: url_helper
INFO - 2023-11-02 13:37:12 --> Helper loaded: form_helper
INFO - 2023-11-02 13:37:12 --> Helper loaded: file_helper
INFO - 2023-11-02 13:37:12 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:37:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:37:12 --> Form Validation Class Initialized
INFO - 2023-11-02 13:37:12 --> Upload Class Initialized
INFO - 2023-11-02 13:37:12 --> Model "M_auth" initialized
INFO - 2023-11-02 13:37:12 --> Model "M_user" initialized
INFO - 2023-11-02 13:37:12 --> Model "M_produk" initialized
INFO - 2023-11-02 13:37:12 --> Controller Class Initialized
INFO - 2023-11-02 13:37:12 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:37:12 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:37:12 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:37:12 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:37:12 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:37:12 --> Model "M_bank" initialized
INFO - 2023-11-02 13:37:12 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:37:12 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:37:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:37:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-02 13:37:13 --> Final output sent to browser
DEBUG - 2023-11-02 13:37:13 --> Total execution time: 0.6693
ERROR - 2023-11-02 13:37:13 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:37:13 --> Config Class Initialized
INFO - 2023-11-02 13:37:13 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:37:13 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:37:13 --> Utf8 Class Initialized
INFO - 2023-11-02 13:37:13 --> URI Class Initialized
INFO - 2023-11-02 13:37:13 --> Router Class Initialized
INFO - 2023-11-02 13:37:13 --> Output Class Initialized
INFO - 2023-11-02 13:37:13 --> Security Class Initialized
DEBUG - 2023-11-02 13:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:37:13 --> Input Class Initialized
INFO - 2023-11-02 13:37:13 --> Language Class Initialized
INFO - 2023-11-02 13:37:13 --> Loader Class Initialized
INFO - 2023-11-02 13:37:13 --> Helper loaded: url_helper
INFO - 2023-11-02 13:37:13 --> Helper loaded: form_helper
INFO - 2023-11-02 13:37:13 --> Helper loaded: file_helper
INFO - 2023-11-02 13:37:13 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:37:13 --> Form Validation Class Initialized
INFO - 2023-11-02 13:37:13 --> Upload Class Initialized
INFO - 2023-11-02 13:37:13 --> Model "M_auth" initialized
INFO - 2023-11-02 13:37:13 --> Model "M_user" initialized
INFO - 2023-11-02 13:37:13 --> Model "M_produk" initialized
INFO - 2023-11-02 13:37:13 --> Controller Class Initialized
INFO - 2023-11-02 13:37:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:37:13 --> Final output sent to browser
DEBUG - 2023-11-02 13:37:13 --> Total execution time: 0.0025
ERROR - 2023-11-02 13:57:59 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:57:59 --> Config Class Initialized
INFO - 2023-11-02 13:57:59 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:57:59 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:57:59 --> Utf8 Class Initialized
INFO - 2023-11-02 13:57:59 --> URI Class Initialized
INFO - 2023-11-02 13:57:59 --> Router Class Initialized
INFO - 2023-11-02 13:57:59 --> Output Class Initialized
INFO - 2023-11-02 13:57:59 --> Security Class Initialized
DEBUG - 2023-11-02 13:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:57:59 --> Input Class Initialized
INFO - 2023-11-02 13:57:59 --> Language Class Initialized
INFO - 2023-11-02 13:57:59 --> Loader Class Initialized
INFO - 2023-11-02 13:57:59 --> Helper loaded: url_helper
INFO - 2023-11-02 13:57:59 --> Helper loaded: form_helper
INFO - 2023-11-02 13:57:59 --> Helper loaded: file_helper
INFO - 2023-11-02 13:57:59 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:57:59 --> Form Validation Class Initialized
INFO - 2023-11-02 13:57:59 --> Upload Class Initialized
INFO - 2023-11-02 13:57:59 --> Model "M_auth" initialized
INFO - 2023-11-02 13:57:59 --> Model "M_user" initialized
INFO - 2023-11-02 13:57:59 --> Model "M_produk" initialized
INFO - 2023-11-02 13:57:59 --> Controller Class Initialized
INFO - 2023-11-02 13:57:59 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:57:59 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:57:59 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:57:59 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:57:59 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:57:59 --> Model "M_bank" initialized
INFO - 2023-11-02 13:57:59 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:57:59 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
ERROR - 2023-11-02 13:57:59 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:57:59 --> Config Class Initialized
INFO - 2023-11-02 13:57:59 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:57:59 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:57:59 --> Utf8 Class Initialized
INFO - 2023-11-02 13:57:59 --> URI Class Initialized
INFO - 2023-11-02 13:57:59 --> Router Class Initialized
INFO - 2023-11-02 13:57:59 --> Output Class Initialized
INFO - 2023-11-02 13:57:59 --> Security Class Initialized
DEBUG - 2023-11-02 13:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:57:59 --> Input Class Initialized
INFO - 2023-11-02 13:57:59 --> Language Class Initialized
INFO - 2023-11-02 13:57:59 --> Loader Class Initialized
INFO - 2023-11-02 13:57:59 --> Helper loaded: url_helper
INFO - 2023-11-02 13:57:59 --> Helper loaded: form_helper
INFO - 2023-11-02 13:57:59 --> Helper loaded: file_helper
INFO - 2023-11-02 13:57:59 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:57:59 --> Form Validation Class Initialized
INFO - 2023-11-02 13:57:59 --> Upload Class Initialized
INFO - 2023-11-02 13:57:59 --> Model "M_auth" initialized
INFO - 2023-11-02 13:57:59 --> Model "M_user" initialized
INFO - 2023-11-02 13:57:59 --> Model "M_produk" initialized
INFO - 2023-11-02 13:57:59 --> Controller Class Initialized
INFO - 2023-11-02 13:57:59 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:57:59 --> Final output sent to browser
DEBUG - 2023-11-02 13:57:59 --> Total execution time: 0.0031
ERROR - 2023-11-02 13:57:59 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:57:59 --> Config Class Initialized
INFO - 2023-11-02 13:57:59 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:57:59 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:57:59 --> Utf8 Class Initialized
INFO - 2023-11-02 13:57:59 --> URI Class Initialized
INFO - 2023-11-02 13:57:59 --> Router Class Initialized
INFO - 2023-11-02 13:57:59 --> Output Class Initialized
INFO - 2023-11-02 13:57:59 --> Security Class Initialized
DEBUG - 2023-11-02 13:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:57:59 --> Input Class Initialized
INFO - 2023-11-02 13:57:59 --> Language Class Initialized
INFO - 2023-11-02 13:57:59 --> Loader Class Initialized
INFO - 2023-11-02 13:57:59 --> Helper loaded: url_helper
INFO - 2023-11-02 13:57:59 --> Helper loaded: form_helper
INFO - 2023-11-02 13:57:59 --> Helper loaded: file_helper
INFO - 2023-11-02 13:57:59 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:57:59 --> Form Validation Class Initialized
INFO - 2023-11-02 13:57:59 --> Upload Class Initialized
INFO - 2023-11-02 13:57:59 --> Model "M_auth" initialized
INFO - 2023-11-02 13:57:59 --> Model "M_user" initialized
INFO - 2023-11-02 13:57:59 --> Model "M_produk" initialized
INFO - 2023-11-02 13:57:59 --> Controller Class Initialized
INFO - 2023-11-02 13:57:59 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:57:59 --> Final output sent to browser
DEBUG - 2023-11-02 13:57:59 --> Total execution time: 0.0028
ERROR - 2023-11-02 13:58:00 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:58:00 --> Config Class Initialized
INFO - 2023-11-02 13:58:00 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:58:00 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:58:00 --> Utf8 Class Initialized
INFO - 2023-11-02 13:58:00 --> URI Class Initialized
INFO - 2023-11-02 13:58:00 --> Router Class Initialized
INFO - 2023-11-02 13:58:00 --> Output Class Initialized
INFO - 2023-11-02 13:58:00 --> Security Class Initialized
DEBUG - 2023-11-02 13:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:58:00 --> Input Class Initialized
INFO - 2023-11-02 13:58:00 --> Language Class Initialized
INFO - 2023-11-02 13:58:00 --> Loader Class Initialized
INFO - 2023-11-02 13:58:00 --> Helper loaded: url_helper
INFO - 2023-11-02 13:58:00 --> Helper loaded: form_helper
INFO - 2023-11-02 13:58:00 --> Helper loaded: file_helper
INFO - 2023-11-02 13:58:00 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:58:00 --> Form Validation Class Initialized
INFO - 2023-11-02 13:58:00 --> Upload Class Initialized
INFO - 2023-11-02 13:58:00 --> Model "M_auth" initialized
INFO - 2023-11-02 13:58:00 --> Model "M_user" initialized
INFO - 2023-11-02 13:58:00 --> Model "M_produk" initialized
INFO - 2023-11-02 13:58:00 --> Controller Class Initialized
INFO - 2023-11-02 13:58:00 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 13:58:00 --> Final output sent to browser
DEBUG - 2023-11-02 13:58:00 --> Total execution time: 0.0020
ERROR - 2023-11-02 13:58:14 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:58:14 --> Config Class Initialized
INFO - 2023-11-02 13:58:14 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:58:14 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:58:14 --> Utf8 Class Initialized
INFO - 2023-11-02 13:58:14 --> URI Class Initialized
DEBUG - 2023-11-02 13:58:14 --> No URI present. Default controller set.
INFO - 2023-11-02 13:58:14 --> Router Class Initialized
INFO - 2023-11-02 13:58:14 --> Output Class Initialized
INFO - 2023-11-02 13:58:14 --> Security Class Initialized
DEBUG - 2023-11-02 13:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:58:14 --> Input Class Initialized
INFO - 2023-11-02 13:58:14 --> Language Class Initialized
INFO - 2023-11-02 13:58:14 --> Loader Class Initialized
INFO - 2023-11-02 13:58:14 --> Helper loaded: url_helper
INFO - 2023-11-02 13:58:14 --> Helper loaded: form_helper
INFO - 2023-11-02 13:58:14 --> Helper loaded: file_helper
INFO - 2023-11-02 13:58:14 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:58:14 --> Form Validation Class Initialized
INFO - 2023-11-02 13:58:14 --> Upload Class Initialized
INFO - 2023-11-02 13:58:14 --> Model "M_auth" initialized
INFO - 2023-11-02 13:58:14 --> Model "M_user" initialized
INFO - 2023-11-02 13:58:14 --> Model "M_produk" initialized
INFO - 2023-11-02 13:58:14 --> Controller Class Initialized
INFO - 2023-11-02 13:58:14 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:58:14 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:58:14 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:58:14 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:58:14 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:58:14 --> Model "M_bank" initialized
INFO - 2023-11-02 13:58:14 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:58:14 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:58:14 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:58:14 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 13:58:14 --> Final output sent to browser
DEBUG - 2023-11-02 13:58:14 --> Total execution time: 0.0078
ERROR - 2023-11-02 13:58:41 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:58:41 --> Config Class Initialized
INFO - 2023-11-02 13:58:41 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:58:41 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:58:41 --> Utf8 Class Initialized
INFO - 2023-11-02 13:58:41 --> URI Class Initialized
INFO - 2023-11-02 13:58:41 --> Router Class Initialized
INFO - 2023-11-02 13:58:41 --> Output Class Initialized
INFO - 2023-11-02 13:58:41 --> Security Class Initialized
DEBUG - 2023-11-02 13:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:58:41 --> Input Class Initialized
INFO - 2023-11-02 13:58:41 --> Language Class Initialized
INFO - 2023-11-02 13:58:41 --> Loader Class Initialized
INFO - 2023-11-02 13:58:41 --> Helper loaded: url_helper
INFO - 2023-11-02 13:58:41 --> Helper loaded: form_helper
INFO - 2023-11-02 13:58:41 --> Helper loaded: file_helper
INFO - 2023-11-02 13:58:41 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:58:41 --> Form Validation Class Initialized
INFO - 2023-11-02 13:58:41 --> Upload Class Initialized
INFO - 2023-11-02 13:58:41 --> Model "M_auth" initialized
INFO - 2023-11-02 13:58:41 --> Model "M_user" initialized
INFO - 2023-11-02 13:58:41 --> Model "M_produk" initialized
INFO - 2023-11-02 13:58:41 --> Controller Class Initialized
INFO - 2023-11-02 13:58:41 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:58:41 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:58:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:58:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:58:41 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:58:41 --> Model "M_bank" initialized
INFO - 2023-11-02 13:58:41 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:58:41 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:58:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:58:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-02 13:58:41 --> Final output sent to browser
DEBUG - 2023-11-02 13:58:41 --> Total execution time: 0.0065
ERROR - 2023-11-02 13:59:00 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 13:59:00 --> Config Class Initialized
INFO - 2023-11-02 13:59:00 --> Hooks Class Initialized
DEBUG - 2023-11-02 13:59:00 --> UTF-8 Support Enabled
INFO - 2023-11-02 13:59:00 --> Utf8 Class Initialized
INFO - 2023-11-02 13:59:00 --> URI Class Initialized
DEBUG - 2023-11-02 13:59:00 --> No URI present. Default controller set.
INFO - 2023-11-02 13:59:00 --> Router Class Initialized
INFO - 2023-11-02 13:59:00 --> Output Class Initialized
INFO - 2023-11-02 13:59:00 --> Security Class Initialized
DEBUG - 2023-11-02 13:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 13:59:00 --> Input Class Initialized
INFO - 2023-11-02 13:59:00 --> Language Class Initialized
INFO - 2023-11-02 13:59:00 --> Loader Class Initialized
INFO - 2023-11-02 13:59:00 --> Helper loaded: url_helper
INFO - 2023-11-02 13:59:00 --> Helper loaded: form_helper
INFO - 2023-11-02 13:59:00 --> Helper loaded: file_helper
INFO - 2023-11-02 13:59:00 --> Database Driver Class Initialized
DEBUG - 2023-11-02 13:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 13:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 13:59:00 --> Form Validation Class Initialized
INFO - 2023-11-02 13:59:00 --> Upload Class Initialized
INFO - 2023-11-02 13:59:00 --> Model "M_auth" initialized
INFO - 2023-11-02 13:59:00 --> Model "M_user" initialized
INFO - 2023-11-02 13:59:00 --> Model "M_produk" initialized
INFO - 2023-11-02 13:59:00 --> Controller Class Initialized
INFO - 2023-11-02 13:59:00 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 13:59:00 --> Model "M_produk" initialized
DEBUG - 2023-11-02 13:59:00 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 13:59:00 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 13:59:00 --> Model "M_transaksi" initialized
INFO - 2023-11-02 13:59:00 --> Model "M_bank" initialized
INFO - 2023-11-02 13:59:00 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 13:59:00 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 13:59:00 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 13:59:00 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 13:59:00 --> Final output sent to browser
DEBUG - 2023-11-02 13:59:00 --> Total execution time: 0.0047
ERROR - 2023-11-02 14:01:09 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 14:01:09 --> Config Class Initialized
INFO - 2023-11-02 14:01:09 --> Hooks Class Initialized
DEBUG - 2023-11-02 14:01:09 --> UTF-8 Support Enabled
INFO - 2023-11-02 14:01:09 --> Utf8 Class Initialized
INFO - 2023-11-02 14:01:09 --> URI Class Initialized
DEBUG - 2023-11-02 14:01:09 --> No URI present. Default controller set.
INFO - 2023-11-02 14:01:09 --> Router Class Initialized
INFO - 2023-11-02 14:01:09 --> Output Class Initialized
INFO - 2023-11-02 14:01:09 --> Security Class Initialized
DEBUG - 2023-11-02 14:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 14:01:09 --> Input Class Initialized
INFO - 2023-11-02 14:01:09 --> Language Class Initialized
INFO - 2023-11-02 14:01:09 --> Loader Class Initialized
INFO - 2023-11-02 14:01:09 --> Helper loaded: url_helper
INFO - 2023-11-02 14:01:09 --> Helper loaded: form_helper
INFO - 2023-11-02 14:01:09 --> Helper loaded: file_helper
INFO - 2023-11-02 14:01:09 --> Database Driver Class Initialized
DEBUG - 2023-11-02 14:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 14:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 14:01:09 --> Form Validation Class Initialized
INFO - 2023-11-02 14:01:09 --> Upload Class Initialized
INFO - 2023-11-02 14:01:09 --> Model "M_auth" initialized
INFO - 2023-11-02 14:01:09 --> Model "M_user" initialized
INFO - 2023-11-02 14:01:09 --> Model "M_produk" initialized
INFO - 2023-11-02 14:01:09 --> Controller Class Initialized
INFO - 2023-11-02 14:01:09 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 14:01:09 --> Model "M_produk" initialized
DEBUG - 2023-11-02 14:01:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 14:01:09 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 14:01:09 --> Model "M_transaksi" initialized
INFO - 2023-11-02 14:01:09 --> Model "M_bank" initialized
INFO - 2023-11-02 14:01:09 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 14:01:09 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 14:01:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 14:01:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 14:01:09 --> Final output sent to browser
DEBUG - 2023-11-02 14:01:09 --> Total execution time: 0.0050
ERROR - 2023-11-02 14:01:49 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 14:01:49 --> Config Class Initialized
INFO - 2023-11-02 14:01:49 --> Hooks Class Initialized
DEBUG - 2023-11-02 14:01:49 --> UTF-8 Support Enabled
INFO - 2023-11-02 14:01:49 --> Utf8 Class Initialized
INFO - 2023-11-02 14:01:49 --> URI Class Initialized
INFO - 2023-11-02 14:01:49 --> Router Class Initialized
INFO - 2023-11-02 14:01:49 --> Output Class Initialized
INFO - 2023-11-02 14:01:49 --> Security Class Initialized
DEBUG - 2023-11-02 14:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 14:01:49 --> Input Class Initialized
INFO - 2023-11-02 14:01:49 --> Language Class Initialized
INFO - 2023-11-02 14:01:49 --> Loader Class Initialized
INFO - 2023-11-02 14:01:49 --> Helper loaded: url_helper
INFO - 2023-11-02 14:01:49 --> Helper loaded: form_helper
INFO - 2023-11-02 14:01:49 --> Helper loaded: file_helper
INFO - 2023-11-02 14:01:49 --> Database Driver Class Initialized
DEBUG - 2023-11-02 14:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 14:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 14:01:49 --> Form Validation Class Initialized
INFO - 2023-11-02 14:01:49 --> Upload Class Initialized
INFO - 2023-11-02 14:01:49 --> Model "M_auth" initialized
INFO - 2023-11-02 14:01:49 --> Model "M_user" initialized
INFO - 2023-11-02 14:01:49 --> Model "M_produk" initialized
INFO - 2023-11-02 14:01:49 --> Controller Class Initialized
INFO - 2023-11-02 14:01:49 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 14:01:49 --> Model "M_produk" initialized
DEBUG - 2023-11-02 14:01:49 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 14:01:49 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 14:01:49 --> Model "M_transaksi" initialized
INFO - 2023-11-02 14:01:49 --> Model "M_bank" initialized
INFO - 2023-11-02 14:01:49 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 14:01:49 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 14:01:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-11-02 14:01:49 --> Email Class Initialized
INFO - 2023-11-02 14:01:50 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-11-02 14:01:53 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 14:01:53 --> Config Class Initialized
INFO - 2023-11-02 14:01:53 --> Hooks Class Initialized
DEBUG - 2023-11-02 14:01:53 --> UTF-8 Support Enabled
INFO - 2023-11-02 14:01:53 --> Utf8 Class Initialized
INFO - 2023-11-02 14:01:53 --> URI Class Initialized
DEBUG - 2023-11-02 14:01:53 --> No URI present. Default controller set.
INFO - 2023-11-02 14:01:53 --> Router Class Initialized
INFO - 2023-11-02 14:01:53 --> Output Class Initialized
INFO - 2023-11-02 14:01:53 --> Security Class Initialized
DEBUG - 2023-11-02 14:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 14:01:53 --> Input Class Initialized
INFO - 2023-11-02 14:01:53 --> Language Class Initialized
INFO - 2023-11-02 14:01:53 --> Loader Class Initialized
INFO - 2023-11-02 14:01:53 --> Helper loaded: url_helper
INFO - 2023-11-02 14:01:53 --> Helper loaded: form_helper
INFO - 2023-11-02 14:01:53 --> Helper loaded: file_helper
INFO - 2023-11-02 14:01:53 --> Database Driver Class Initialized
DEBUG - 2023-11-02 14:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 14:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 14:01:53 --> Form Validation Class Initialized
INFO - 2023-11-02 14:01:53 --> Upload Class Initialized
INFO - 2023-11-02 14:01:53 --> Model "M_auth" initialized
INFO - 2023-11-02 14:01:53 --> Model "M_user" initialized
INFO - 2023-11-02 14:01:53 --> Model "M_produk" initialized
INFO - 2023-11-02 14:01:53 --> Controller Class Initialized
INFO - 2023-11-02 14:01:53 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 14:01:53 --> Model "M_produk" initialized
DEBUG - 2023-11-02 14:01:53 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 14:01:53 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 14:01:53 --> Model "M_transaksi" initialized
INFO - 2023-11-02 14:01:53 --> Model "M_bank" initialized
INFO - 2023-11-02 14:01:53 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 14:01:53 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 14:01:53 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 14:01:53 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 14:01:53 --> Final output sent to browser
DEBUG - 2023-11-02 14:01:53 --> Total execution time: 0.0040
ERROR - 2023-11-02 14:02:07 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 14:02:07 --> Config Class Initialized
INFO - 2023-11-02 14:02:07 --> Hooks Class Initialized
DEBUG - 2023-11-02 14:02:07 --> UTF-8 Support Enabled
INFO - 2023-11-02 14:02:07 --> Utf8 Class Initialized
INFO - 2023-11-02 14:02:07 --> URI Class Initialized
INFO - 2023-11-02 14:02:07 --> Router Class Initialized
INFO - 2023-11-02 14:02:07 --> Output Class Initialized
INFO - 2023-11-02 14:02:07 --> Security Class Initialized
DEBUG - 2023-11-02 14:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 14:02:07 --> Input Class Initialized
INFO - 2023-11-02 14:02:07 --> Language Class Initialized
INFO - 2023-11-02 14:02:07 --> Loader Class Initialized
INFO - 2023-11-02 14:02:07 --> Helper loaded: url_helper
INFO - 2023-11-02 14:02:07 --> Helper loaded: form_helper
INFO - 2023-11-02 14:02:07 --> Helper loaded: file_helper
INFO - 2023-11-02 14:02:07 --> Database Driver Class Initialized
DEBUG - 2023-11-02 14:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 14:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 14:02:07 --> Form Validation Class Initialized
INFO - 2023-11-02 14:02:07 --> Upload Class Initialized
INFO - 2023-11-02 14:02:07 --> Model "M_auth" initialized
INFO - 2023-11-02 14:02:07 --> Model "M_user" initialized
INFO - 2023-11-02 14:02:07 --> Model "M_produk" initialized
INFO - 2023-11-02 14:02:07 --> Controller Class Initialized
INFO - 2023-11-02 14:02:07 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 14:02:07 --> Model "M_produk" initialized
DEBUG - 2023-11-02 14:02:07 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 14:02:07 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 14:02:07 --> Model "M_transaksi" initialized
INFO - 2023-11-02 14:02:07 --> Model "M_bank" initialized
INFO - 2023-11-02 14:02:07 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 14:02:07 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 14:02:07 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 14:02:07 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-02 14:02:07 --> Final output sent to browser
DEBUG - 2023-11-02 14:02:07 --> Total execution time: 0.0049
ERROR - 2023-11-02 14:02:18 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 14:02:18 --> Config Class Initialized
INFO - 2023-11-02 14:02:18 --> Hooks Class Initialized
DEBUG - 2023-11-02 14:02:18 --> UTF-8 Support Enabled
INFO - 2023-11-02 14:02:18 --> Utf8 Class Initialized
INFO - 2023-11-02 14:02:18 --> URI Class Initialized
INFO - 2023-11-02 14:02:18 --> Router Class Initialized
INFO - 2023-11-02 14:02:18 --> Output Class Initialized
INFO - 2023-11-02 14:02:18 --> Security Class Initialized
DEBUG - 2023-11-02 14:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 14:02:18 --> Input Class Initialized
INFO - 2023-11-02 14:02:18 --> Language Class Initialized
INFO - 2023-11-02 14:02:18 --> Loader Class Initialized
INFO - 2023-11-02 14:02:18 --> Helper loaded: url_helper
INFO - 2023-11-02 14:02:18 --> Helper loaded: form_helper
INFO - 2023-11-02 14:02:18 --> Helper loaded: file_helper
INFO - 2023-11-02 14:02:18 --> Database Driver Class Initialized
DEBUG - 2023-11-02 14:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 14:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 14:02:18 --> Form Validation Class Initialized
INFO - 2023-11-02 14:02:18 --> Upload Class Initialized
INFO - 2023-11-02 14:02:18 --> Model "M_auth" initialized
INFO - 2023-11-02 14:02:18 --> Model "M_user" initialized
INFO - 2023-11-02 14:02:18 --> Model "M_produk" initialized
INFO - 2023-11-02 14:02:18 --> Controller Class Initialized
INFO - 2023-11-02 14:02:18 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 14:02:18 --> Model "M_produk" initialized
DEBUG - 2023-11-02 14:02:18 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 14:02:18 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 14:02:18 --> Model "M_transaksi" initialized
INFO - 2023-11-02 14:02:18 --> Model "M_bank" initialized
INFO - 2023-11-02 14:02:18 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 14:02:18 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 14:02:18 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2023-11-02 14:02:19 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 14:02:19 --> Config Class Initialized
INFO - 2023-11-02 14:02:19 --> Hooks Class Initialized
DEBUG - 2023-11-02 14:02:19 --> UTF-8 Support Enabled
INFO - 2023-11-02 14:02:19 --> Utf8 Class Initialized
INFO - 2023-11-02 14:02:19 --> URI Class Initialized
DEBUG - 2023-11-02 14:02:19 --> No URI present. Default controller set.
INFO - 2023-11-02 14:02:19 --> Router Class Initialized
INFO - 2023-11-02 14:02:19 --> Output Class Initialized
INFO - 2023-11-02 14:02:19 --> Security Class Initialized
DEBUG - 2023-11-02 14:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 14:02:19 --> Input Class Initialized
INFO - 2023-11-02 14:02:19 --> Language Class Initialized
INFO - 2023-11-02 14:02:19 --> Loader Class Initialized
INFO - 2023-11-02 14:02:19 --> Helper loaded: url_helper
INFO - 2023-11-02 14:02:19 --> Helper loaded: form_helper
INFO - 2023-11-02 14:02:19 --> Helper loaded: file_helper
INFO - 2023-11-02 14:02:19 --> Database Driver Class Initialized
DEBUG - 2023-11-02 14:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 14:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 14:02:19 --> Form Validation Class Initialized
INFO - 2023-11-02 14:02:19 --> Upload Class Initialized
INFO - 2023-11-02 14:02:19 --> Model "M_auth" initialized
INFO - 2023-11-02 14:02:19 --> Model "M_user" initialized
INFO - 2023-11-02 14:02:19 --> Model "M_produk" initialized
INFO - 2023-11-02 14:02:19 --> Controller Class Initialized
INFO - 2023-11-02 14:02:19 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 14:02:19 --> Model "M_produk" initialized
DEBUG - 2023-11-02 14:02:19 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 14:02:19 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 14:02:19 --> Model "M_transaksi" initialized
INFO - 2023-11-02 14:02:19 --> Model "M_bank" initialized
INFO - 2023-11-02 14:02:19 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 14:02:19 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 14:02:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 14:02:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 14:02:19 --> Final output sent to browser
DEBUG - 2023-11-02 14:02:19 --> Total execution time: 0.0038
ERROR - 2023-11-02 14:02:32 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 14:02:32 --> Config Class Initialized
INFO - 2023-11-02 14:02:32 --> Hooks Class Initialized
DEBUG - 2023-11-02 14:02:32 --> UTF-8 Support Enabled
INFO - 2023-11-02 14:02:32 --> Utf8 Class Initialized
INFO - 2023-11-02 14:02:32 --> URI Class Initialized
DEBUG - 2023-11-02 14:02:32 --> No URI present. Default controller set.
INFO - 2023-11-02 14:02:32 --> Router Class Initialized
INFO - 2023-11-02 14:02:32 --> Output Class Initialized
INFO - 2023-11-02 14:02:32 --> Security Class Initialized
DEBUG - 2023-11-02 14:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 14:02:32 --> Input Class Initialized
INFO - 2023-11-02 14:02:32 --> Language Class Initialized
INFO - 2023-11-02 14:02:32 --> Loader Class Initialized
INFO - 2023-11-02 14:02:32 --> Helper loaded: url_helper
INFO - 2023-11-02 14:02:32 --> Helper loaded: form_helper
INFO - 2023-11-02 14:02:32 --> Helper loaded: file_helper
INFO - 2023-11-02 14:02:32 --> Database Driver Class Initialized
DEBUG - 2023-11-02 14:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 14:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 14:02:32 --> Form Validation Class Initialized
INFO - 2023-11-02 14:02:32 --> Upload Class Initialized
INFO - 2023-11-02 14:02:32 --> Model "M_auth" initialized
INFO - 2023-11-02 14:02:32 --> Model "M_user" initialized
INFO - 2023-11-02 14:02:32 --> Model "M_produk" initialized
INFO - 2023-11-02 14:02:32 --> Controller Class Initialized
INFO - 2023-11-02 14:02:32 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 14:02:32 --> Model "M_produk" initialized
DEBUG - 2023-11-02 14:02:32 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 14:02:32 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 14:02:32 --> Model "M_transaksi" initialized
INFO - 2023-11-02 14:02:32 --> Model "M_bank" initialized
INFO - 2023-11-02 14:02:32 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 14:02:32 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 14:02:32 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2023-11-02 14:02:32 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 14:02:32 --> Config Class Initialized
INFO - 2023-11-02 14:02:32 --> Hooks Class Initialized
DEBUG - 2023-11-02 14:02:32 --> UTF-8 Support Enabled
INFO - 2023-11-02 14:02:32 --> Utf8 Class Initialized
INFO - 2023-11-02 14:02:32 --> URI Class Initialized
DEBUG - 2023-11-02 14:02:32 --> No URI present. Default controller set.
INFO - 2023-11-02 14:02:32 --> Router Class Initialized
INFO - 2023-11-02 14:02:32 --> Output Class Initialized
INFO - 2023-11-02 14:02:32 --> Security Class Initialized
DEBUG - 2023-11-02 14:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 14:02:32 --> Input Class Initialized
INFO - 2023-11-02 14:02:32 --> Language Class Initialized
INFO - 2023-11-02 14:02:32 --> Loader Class Initialized
INFO - 2023-11-02 14:02:32 --> Helper loaded: url_helper
INFO - 2023-11-02 14:02:32 --> Helper loaded: form_helper
INFO - 2023-11-02 14:02:32 --> Helper loaded: file_helper
INFO - 2023-11-02 14:02:32 --> Database Driver Class Initialized
DEBUG - 2023-11-02 14:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 14:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 14:02:32 --> Form Validation Class Initialized
INFO - 2023-11-02 14:02:32 --> Upload Class Initialized
INFO - 2023-11-02 14:02:32 --> Model "M_auth" initialized
INFO - 2023-11-02 14:02:32 --> Model "M_user" initialized
INFO - 2023-11-02 14:02:32 --> Model "M_produk" initialized
INFO - 2023-11-02 14:02:32 --> Controller Class Initialized
INFO - 2023-11-02 14:02:32 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 14:02:32 --> Model "M_produk" initialized
DEBUG - 2023-11-02 14:02:32 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 14:02:32 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 14:02:32 --> Model "M_transaksi" initialized
INFO - 2023-11-02 14:02:32 --> Model "M_bank" initialized
INFO - 2023-11-02 14:02:32 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 14:02:32 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 14:02:32 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 14:02:32 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 14:02:32 --> Final output sent to browser
DEBUG - 2023-11-02 14:02:32 --> Total execution time: 0.0102
ERROR - 2023-11-02 14:03:05 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 14:03:05 --> Config Class Initialized
INFO - 2023-11-02 14:03:05 --> Hooks Class Initialized
DEBUG - 2023-11-02 14:03:05 --> UTF-8 Support Enabled
INFO - 2023-11-02 14:03:05 --> Utf8 Class Initialized
INFO - 2023-11-02 14:03:05 --> URI Class Initialized
INFO - 2023-11-02 14:03:05 --> Router Class Initialized
INFO - 2023-11-02 14:03:05 --> Output Class Initialized
INFO - 2023-11-02 14:03:05 --> Security Class Initialized
DEBUG - 2023-11-02 14:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 14:03:05 --> Input Class Initialized
INFO - 2023-11-02 14:03:05 --> Language Class Initialized
INFO - 2023-11-02 14:03:05 --> Loader Class Initialized
INFO - 2023-11-02 14:03:05 --> Helper loaded: url_helper
INFO - 2023-11-02 14:03:05 --> Helper loaded: form_helper
INFO - 2023-11-02 14:03:05 --> Helper loaded: file_helper
INFO - 2023-11-02 14:03:05 --> Database Driver Class Initialized
DEBUG - 2023-11-02 14:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 14:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 14:03:05 --> Form Validation Class Initialized
INFO - 2023-11-02 14:03:05 --> Upload Class Initialized
INFO - 2023-11-02 14:03:05 --> Model "M_auth" initialized
INFO - 2023-11-02 14:03:05 --> Model "M_user" initialized
INFO - 2023-11-02 14:03:05 --> Model "M_produk" initialized
INFO - 2023-11-02 14:03:05 --> Controller Class Initialized
INFO - 2023-11-02 14:03:05 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 14:03:05 --> Model "M_produk" initialized
DEBUG - 2023-11-02 14:03:05 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 14:03:05 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 14:03:05 --> Model "M_transaksi" initialized
INFO - 2023-11-02 14:03:05 --> Model "M_bank" initialized
INFO - 2023-11-02 14:03:05 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 14:03:05 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
ERROR - 2023-11-02 14:03:05 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 14:03:05 --> Config Class Initialized
INFO - 2023-11-02 14:03:05 --> Hooks Class Initialized
DEBUG - 2023-11-02 14:03:05 --> UTF-8 Support Enabled
INFO - 2023-11-02 14:03:05 --> Utf8 Class Initialized
INFO - 2023-11-02 14:03:05 --> URI Class Initialized
DEBUG - 2023-11-02 14:03:05 --> No URI present. Default controller set.
INFO - 2023-11-02 14:03:05 --> Router Class Initialized
INFO - 2023-11-02 14:03:05 --> Output Class Initialized
INFO - 2023-11-02 14:03:05 --> Security Class Initialized
DEBUG - 2023-11-02 14:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 14:03:05 --> Input Class Initialized
INFO - 2023-11-02 14:03:05 --> Language Class Initialized
INFO - 2023-11-02 14:03:05 --> Loader Class Initialized
INFO - 2023-11-02 14:03:05 --> Helper loaded: url_helper
INFO - 2023-11-02 14:03:05 --> Helper loaded: form_helper
INFO - 2023-11-02 14:03:05 --> Helper loaded: file_helper
INFO - 2023-11-02 14:03:05 --> Database Driver Class Initialized
DEBUG - 2023-11-02 14:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 14:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 14:03:05 --> Form Validation Class Initialized
INFO - 2023-11-02 14:03:05 --> Upload Class Initialized
INFO - 2023-11-02 14:03:05 --> Model "M_auth" initialized
INFO - 2023-11-02 14:03:05 --> Model "M_user" initialized
INFO - 2023-11-02 14:03:05 --> Model "M_produk" initialized
INFO - 2023-11-02 14:03:05 --> Controller Class Initialized
INFO - 2023-11-02 14:03:05 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 14:03:05 --> Model "M_produk" initialized
DEBUG - 2023-11-02 14:03:05 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 14:03:05 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 14:03:05 --> Model "M_transaksi" initialized
INFO - 2023-11-02 14:03:05 --> Model "M_bank" initialized
INFO - 2023-11-02 14:03:05 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 14:03:05 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 14:03:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 14:03:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 14:03:05 --> Final output sent to browser
DEBUG - 2023-11-02 14:03:05 --> Total execution time: 0.0039
ERROR - 2023-11-02 14:03:06 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 14:03:06 --> Config Class Initialized
INFO - 2023-11-02 14:03:06 --> Hooks Class Initialized
DEBUG - 2023-11-02 14:03:06 --> UTF-8 Support Enabled
INFO - 2023-11-02 14:03:06 --> Utf8 Class Initialized
INFO - 2023-11-02 14:03:06 --> URI Class Initialized
INFO - 2023-11-02 14:03:06 --> Router Class Initialized
INFO - 2023-11-02 14:03:06 --> Output Class Initialized
INFO - 2023-11-02 14:03:06 --> Security Class Initialized
DEBUG - 2023-11-02 14:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 14:03:06 --> Input Class Initialized
INFO - 2023-11-02 14:03:06 --> Language Class Initialized
INFO - 2023-11-02 14:03:06 --> Loader Class Initialized
INFO - 2023-11-02 14:03:06 --> Helper loaded: url_helper
INFO - 2023-11-02 14:03:06 --> Helper loaded: form_helper
INFO - 2023-11-02 14:03:06 --> Helper loaded: file_helper
INFO - 2023-11-02 14:03:06 --> Database Driver Class Initialized
DEBUG - 2023-11-02 14:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 14:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 14:03:06 --> Form Validation Class Initialized
INFO - 2023-11-02 14:03:06 --> Upload Class Initialized
INFO - 2023-11-02 14:03:06 --> Model "M_auth" initialized
INFO - 2023-11-02 14:03:06 --> Model "M_user" initialized
INFO - 2023-11-02 14:03:06 --> Model "M_produk" initialized
INFO - 2023-11-02 14:03:06 --> Controller Class Initialized
INFO - 2023-11-02 14:03:06 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 14:03:06 --> Model "M_produk" initialized
DEBUG - 2023-11-02 14:03:06 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 14:03:06 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 14:03:06 --> Model "M_transaksi" initialized
INFO - 2023-11-02 14:03:06 --> Model "M_bank" initialized
INFO - 2023-11-02 14:03:06 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 14:03:06 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
ERROR - 2023-11-02 14:03:09 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 14:03:09 --> Config Class Initialized
INFO - 2023-11-02 14:03:09 --> Hooks Class Initialized
DEBUG - 2023-11-02 14:03:09 --> UTF-8 Support Enabled
INFO - 2023-11-02 14:03:09 --> Utf8 Class Initialized
INFO - 2023-11-02 14:03:09 --> URI Class Initialized
DEBUG - 2023-11-02 14:03:09 --> No URI present. Default controller set.
INFO - 2023-11-02 14:03:09 --> Router Class Initialized
INFO - 2023-11-02 14:03:09 --> Output Class Initialized
INFO - 2023-11-02 14:03:09 --> Security Class Initialized
DEBUG - 2023-11-02 14:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 14:03:09 --> Input Class Initialized
INFO - 2023-11-02 14:03:09 --> Language Class Initialized
INFO - 2023-11-02 14:03:09 --> Loader Class Initialized
INFO - 2023-11-02 14:03:09 --> Helper loaded: url_helper
INFO - 2023-11-02 14:03:09 --> Helper loaded: form_helper
INFO - 2023-11-02 14:03:09 --> Helper loaded: file_helper
INFO - 2023-11-02 14:03:09 --> Database Driver Class Initialized
DEBUG - 2023-11-02 14:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 14:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 14:03:09 --> Form Validation Class Initialized
INFO - 2023-11-02 14:03:09 --> Upload Class Initialized
INFO - 2023-11-02 14:03:09 --> Model "M_auth" initialized
INFO - 2023-11-02 14:03:09 --> Model "M_user" initialized
INFO - 2023-11-02 14:03:09 --> Model "M_produk" initialized
INFO - 2023-11-02 14:03:09 --> Controller Class Initialized
INFO - 2023-11-02 14:03:09 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 14:03:09 --> Model "M_produk" initialized
DEBUG - 2023-11-02 14:03:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 14:03:09 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 14:03:09 --> Model "M_transaksi" initialized
INFO - 2023-11-02 14:03:09 --> Model "M_bank" initialized
INFO - 2023-11-02 14:03:09 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 14:03:09 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 14:03:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 14:03:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 14:03:09 --> Final output sent to browser
DEBUG - 2023-11-02 14:03:09 --> Total execution time: 0.0039
ERROR - 2023-11-02 14:03:14 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 14:03:14 --> Config Class Initialized
INFO - 2023-11-02 14:03:14 --> Hooks Class Initialized
DEBUG - 2023-11-02 14:03:14 --> UTF-8 Support Enabled
INFO - 2023-11-02 14:03:14 --> Utf8 Class Initialized
INFO - 2023-11-02 14:03:14 --> URI Class Initialized
INFO - 2023-11-02 14:03:14 --> Router Class Initialized
INFO - 2023-11-02 14:03:14 --> Output Class Initialized
INFO - 2023-11-02 14:03:14 --> Security Class Initialized
DEBUG - 2023-11-02 14:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 14:03:14 --> Input Class Initialized
INFO - 2023-11-02 14:03:14 --> Language Class Initialized
INFO - 2023-11-02 14:03:14 --> Loader Class Initialized
INFO - 2023-11-02 14:03:14 --> Helper loaded: url_helper
INFO - 2023-11-02 14:03:14 --> Helper loaded: form_helper
INFO - 2023-11-02 14:03:14 --> Helper loaded: file_helper
INFO - 2023-11-02 14:03:14 --> Database Driver Class Initialized
DEBUG - 2023-11-02 14:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 14:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 14:03:14 --> Form Validation Class Initialized
INFO - 2023-11-02 14:03:14 --> Upload Class Initialized
INFO - 2023-11-02 14:03:14 --> Model "M_auth" initialized
INFO - 2023-11-02 14:03:14 --> Model "M_user" initialized
INFO - 2023-11-02 14:03:14 --> Model "M_produk" initialized
INFO - 2023-11-02 14:03:14 --> Controller Class Initialized
INFO - 2023-11-02 14:03:14 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 14:03:14 --> Model "M_produk" initialized
DEBUG - 2023-11-02 14:03:14 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 14:03:14 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 14:03:14 --> Model "M_transaksi" initialized
INFO - 2023-11-02 14:03:14 --> Model "M_bank" initialized
INFO - 2023-11-02 14:03:14 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 14:03:14 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 14:03:14 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 14:03:14 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-02 14:03:14 --> Final output sent to browser
DEBUG - 2023-11-02 14:03:14 --> Total execution time: 0.0044
ERROR - 2023-11-02 14:03:25 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 14:03:25 --> Config Class Initialized
INFO - 2023-11-02 14:03:25 --> Hooks Class Initialized
DEBUG - 2023-11-02 14:03:25 --> UTF-8 Support Enabled
INFO - 2023-11-02 14:03:25 --> Utf8 Class Initialized
INFO - 2023-11-02 14:03:25 --> URI Class Initialized
INFO - 2023-11-02 14:03:25 --> Router Class Initialized
INFO - 2023-11-02 14:03:25 --> Output Class Initialized
INFO - 2023-11-02 14:03:25 --> Security Class Initialized
DEBUG - 2023-11-02 14:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 14:03:25 --> Input Class Initialized
INFO - 2023-11-02 14:03:25 --> Language Class Initialized
INFO - 2023-11-02 14:03:25 --> Loader Class Initialized
INFO - 2023-11-02 14:03:25 --> Helper loaded: url_helper
INFO - 2023-11-02 14:03:25 --> Helper loaded: form_helper
INFO - 2023-11-02 14:03:25 --> Helper loaded: file_helper
INFO - 2023-11-02 14:03:25 --> Database Driver Class Initialized
DEBUG - 2023-11-02 14:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 14:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 14:03:25 --> Form Validation Class Initialized
INFO - 2023-11-02 14:03:25 --> Upload Class Initialized
INFO - 2023-11-02 14:03:25 --> Model "M_auth" initialized
INFO - 2023-11-02 14:03:25 --> Model "M_user" initialized
INFO - 2023-11-02 14:03:25 --> Model "M_produk" initialized
INFO - 2023-11-02 14:03:25 --> Controller Class Initialized
INFO - 2023-11-02 14:03:25 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 14:03:25 --> Model "M_produk" initialized
DEBUG - 2023-11-02 14:03:25 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 14:03:25 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 14:03:25 --> Model "M_transaksi" initialized
INFO - 2023-11-02 14:03:25 --> Model "M_bank" initialized
INFO - 2023-11-02 14:03:25 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 14:03:25 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 14:03:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-11-02 14:03:25 --> Email Class Initialized
INFO - 2023-11-02 14:03:26 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-11-02 14:03:28 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 14:03:28 --> Config Class Initialized
INFO - 2023-11-02 14:03:28 --> Hooks Class Initialized
DEBUG - 2023-11-02 14:03:28 --> UTF-8 Support Enabled
INFO - 2023-11-02 14:03:28 --> Utf8 Class Initialized
INFO - 2023-11-02 14:03:28 --> URI Class Initialized
DEBUG - 2023-11-02 14:03:28 --> No URI present. Default controller set.
INFO - 2023-11-02 14:03:28 --> Router Class Initialized
INFO - 2023-11-02 14:03:28 --> Output Class Initialized
INFO - 2023-11-02 14:03:28 --> Security Class Initialized
DEBUG - 2023-11-02 14:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 14:03:28 --> Input Class Initialized
INFO - 2023-11-02 14:03:28 --> Language Class Initialized
INFO - 2023-11-02 14:03:28 --> Loader Class Initialized
INFO - 2023-11-02 14:03:28 --> Helper loaded: url_helper
INFO - 2023-11-02 14:03:28 --> Helper loaded: form_helper
INFO - 2023-11-02 14:03:28 --> Helper loaded: file_helper
INFO - 2023-11-02 14:03:28 --> Database Driver Class Initialized
DEBUG - 2023-11-02 14:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 14:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 14:03:28 --> Form Validation Class Initialized
INFO - 2023-11-02 14:03:28 --> Upload Class Initialized
INFO - 2023-11-02 14:03:28 --> Model "M_auth" initialized
INFO - 2023-11-02 14:03:28 --> Model "M_user" initialized
INFO - 2023-11-02 14:03:28 --> Model "M_produk" initialized
INFO - 2023-11-02 14:03:28 --> Controller Class Initialized
INFO - 2023-11-02 14:03:28 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 14:03:28 --> Model "M_produk" initialized
DEBUG - 2023-11-02 14:03:28 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 14:03:28 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 14:03:28 --> Model "M_transaksi" initialized
INFO - 2023-11-02 14:03:28 --> Model "M_bank" initialized
INFO - 2023-11-02 14:03:28 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 14:03:28 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 14:03:28 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 14:03:28 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 14:03:28 --> Final output sent to browser
DEBUG - 2023-11-02 14:03:28 --> Total execution time: 0.0043
ERROR - 2023-11-02 14:03:37 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 14:03:37 --> Config Class Initialized
INFO - 2023-11-02 14:03:37 --> Hooks Class Initialized
DEBUG - 2023-11-02 14:03:37 --> UTF-8 Support Enabled
INFO - 2023-11-02 14:03:37 --> Utf8 Class Initialized
INFO - 2023-11-02 14:03:37 --> URI Class Initialized
INFO - 2023-11-02 14:03:37 --> Router Class Initialized
INFO - 2023-11-02 14:03:37 --> Output Class Initialized
INFO - 2023-11-02 14:03:37 --> Security Class Initialized
DEBUG - 2023-11-02 14:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 14:03:37 --> Input Class Initialized
INFO - 2023-11-02 14:03:37 --> Language Class Initialized
INFO - 2023-11-02 14:03:37 --> Loader Class Initialized
INFO - 2023-11-02 14:03:37 --> Helper loaded: url_helper
INFO - 2023-11-02 14:03:37 --> Helper loaded: form_helper
INFO - 2023-11-02 14:03:37 --> Helper loaded: file_helper
INFO - 2023-11-02 14:03:37 --> Database Driver Class Initialized
DEBUG - 2023-11-02 14:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 14:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 14:03:37 --> Form Validation Class Initialized
INFO - 2023-11-02 14:03:37 --> Upload Class Initialized
INFO - 2023-11-02 14:03:37 --> Model "M_auth" initialized
INFO - 2023-11-02 14:03:37 --> Model "M_user" initialized
INFO - 2023-11-02 14:03:37 --> Model "M_produk" initialized
INFO - 2023-11-02 14:03:37 --> Controller Class Initialized
INFO - 2023-11-02 14:03:37 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 14:03:37 --> Model "M_produk" initialized
DEBUG - 2023-11-02 14:03:37 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 14:03:37 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 14:03:37 --> Model "M_transaksi" initialized
INFO - 2023-11-02 14:03:37 --> Model "M_bank" initialized
INFO - 2023-11-02 14:03:37 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 14:03:37 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
ERROR - 2023-11-02 14:03:37 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 14:03:37 --> Config Class Initialized
INFO - 2023-11-02 14:03:37 --> Hooks Class Initialized
DEBUG - 2023-11-02 14:03:37 --> UTF-8 Support Enabled
INFO - 2023-11-02 14:03:37 --> Utf8 Class Initialized
INFO - 2023-11-02 14:03:37 --> URI Class Initialized
INFO - 2023-11-02 14:03:37 --> Router Class Initialized
INFO - 2023-11-02 14:03:37 --> Output Class Initialized
INFO - 2023-11-02 14:03:37 --> Security Class Initialized
DEBUG - 2023-11-02 14:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 14:03:37 --> Input Class Initialized
INFO - 2023-11-02 14:03:37 --> Language Class Initialized
INFO - 2023-11-02 14:03:37 --> Loader Class Initialized
INFO - 2023-11-02 14:03:37 --> Helper loaded: url_helper
INFO - 2023-11-02 14:03:37 --> Helper loaded: form_helper
INFO - 2023-11-02 14:03:37 --> Helper loaded: file_helper
INFO - 2023-11-02 14:03:37 --> Database Driver Class Initialized
DEBUG - 2023-11-02 14:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 14:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 14:03:37 --> Form Validation Class Initialized
INFO - 2023-11-02 14:03:37 --> Upload Class Initialized
INFO - 2023-11-02 14:03:37 --> Model "M_auth" initialized
INFO - 2023-11-02 14:03:37 --> Model "M_user" initialized
INFO - 2023-11-02 14:03:37 --> Model "M_produk" initialized
INFO - 2023-11-02 14:03:37 --> Controller Class Initialized
INFO - 2023-11-02 14:03:37 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 14:03:37 --> Model "M_produk" initialized
DEBUG - 2023-11-02 14:03:37 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 14:03:37 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 14:03:37 --> Model "M_transaksi" initialized
INFO - 2023-11-02 14:03:37 --> Model "M_bank" initialized
INFO - 2023-11-02 14:03:37 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 14:03:37 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 14:03:37 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 14:03:37 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_edit_profile_pelanggan.php
INFO - 2023-11-02 14:03:37 --> Final output sent to browser
DEBUG - 2023-11-02 14:03:37 --> Total execution time: 0.0045
ERROR - 2023-11-02 14:04:17 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 14:04:17 --> Config Class Initialized
INFO - 2023-11-02 14:04:17 --> Hooks Class Initialized
DEBUG - 2023-11-02 14:04:17 --> UTF-8 Support Enabled
INFO - 2023-11-02 14:04:17 --> Utf8 Class Initialized
INFO - 2023-11-02 14:04:17 --> URI Class Initialized
DEBUG - 2023-11-02 14:04:17 --> No URI present. Default controller set.
INFO - 2023-11-02 14:04:17 --> Router Class Initialized
INFO - 2023-11-02 14:04:17 --> Output Class Initialized
INFO - 2023-11-02 14:04:17 --> Security Class Initialized
DEBUG - 2023-11-02 14:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 14:04:17 --> Input Class Initialized
INFO - 2023-11-02 14:04:17 --> Language Class Initialized
INFO - 2023-11-02 14:04:17 --> Loader Class Initialized
INFO - 2023-11-02 14:04:17 --> Helper loaded: url_helper
INFO - 2023-11-02 14:04:17 --> Helper loaded: form_helper
INFO - 2023-11-02 14:04:17 --> Helper loaded: file_helper
INFO - 2023-11-02 14:04:17 --> Database Driver Class Initialized
DEBUG - 2023-11-02 14:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 14:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 14:04:17 --> Form Validation Class Initialized
INFO - 2023-11-02 14:04:17 --> Upload Class Initialized
INFO - 2023-11-02 14:04:17 --> Model "M_auth" initialized
INFO - 2023-11-02 14:04:17 --> Model "M_user" initialized
INFO - 2023-11-02 14:04:17 --> Model "M_produk" initialized
INFO - 2023-11-02 14:04:17 --> Controller Class Initialized
INFO - 2023-11-02 14:04:17 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 14:04:17 --> Model "M_produk" initialized
DEBUG - 2023-11-02 14:04:17 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 14:04:17 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 14:04:17 --> Model "M_transaksi" initialized
INFO - 2023-11-02 14:04:17 --> Model "M_bank" initialized
INFO - 2023-11-02 14:04:17 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 14:04:17 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 14:04:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 14:04:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 14:04:17 --> Final output sent to browser
DEBUG - 2023-11-02 14:04:17 --> Total execution time: 0.0047
ERROR - 2023-11-02 14:04:19 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 14:04:19 --> Config Class Initialized
INFO - 2023-11-02 14:04:19 --> Hooks Class Initialized
DEBUG - 2023-11-02 14:04:19 --> UTF-8 Support Enabled
INFO - 2023-11-02 14:04:19 --> Utf8 Class Initialized
INFO - 2023-11-02 14:04:19 --> URI Class Initialized
DEBUG - 2023-11-02 14:04:19 --> No URI present. Default controller set.
INFO - 2023-11-02 14:04:19 --> Router Class Initialized
INFO - 2023-11-02 14:04:19 --> Output Class Initialized
INFO - 2023-11-02 14:04:19 --> Security Class Initialized
DEBUG - 2023-11-02 14:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 14:04:19 --> Input Class Initialized
INFO - 2023-11-02 14:04:19 --> Language Class Initialized
INFO - 2023-11-02 14:04:19 --> Loader Class Initialized
INFO - 2023-11-02 14:04:19 --> Helper loaded: url_helper
INFO - 2023-11-02 14:04:19 --> Helper loaded: form_helper
INFO - 2023-11-02 14:04:19 --> Helper loaded: file_helper
INFO - 2023-11-02 14:04:19 --> Database Driver Class Initialized
DEBUG - 2023-11-02 14:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 14:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 14:04:19 --> Form Validation Class Initialized
INFO - 2023-11-02 14:04:19 --> Upload Class Initialized
INFO - 2023-11-02 14:04:19 --> Model "M_auth" initialized
INFO - 2023-11-02 14:04:19 --> Model "M_user" initialized
INFO - 2023-11-02 14:04:19 --> Model "M_produk" initialized
INFO - 2023-11-02 14:04:19 --> Controller Class Initialized
INFO - 2023-11-02 14:04:19 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 14:04:19 --> Model "M_produk" initialized
DEBUG - 2023-11-02 14:04:19 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 14:04:19 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 14:04:19 --> Model "M_transaksi" initialized
INFO - 2023-11-02 14:04:19 --> Model "M_bank" initialized
INFO - 2023-11-02 14:04:19 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 14:04:19 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 14:04:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 14:04:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 14:04:19 --> Final output sent to browser
DEBUG - 2023-11-02 14:04:19 --> Total execution time: 0.0037
ERROR - 2023-11-02 14:06:35 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 14:06:35 --> Config Class Initialized
INFO - 2023-11-02 14:06:35 --> Hooks Class Initialized
DEBUG - 2023-11-02 14:06:35 --> UTF-8 Support Enabled
INFO - 2023-11-02 14:06:35 --> Utf8 Class Initialized
INFO - 2023-11-02 14:06:35 --> URI Class Initialized
INFO - 2023-11-02 14:06:35 --> Router Class Initialized
INFO - 2023-11-02 14:06:35 --> Output Class Initialized
INFO - 2023-11-02 14:06:35 --> Security Class Initialized
DEBUG - 2023-11-02 14:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 14:06:35 --> Input Class Initialized
INFO - 2023-11-02 14:06:35 --> Language Class Initialized
INFO - 2023-11-02 14:06:35 --> Loader Class Initialized
INFO - 2023-11-02 14:06:35 --> Helper loaded: url_helper
INFO - 2023-11-02 14:06:35 --> Helper loaded: form_helper
INFO - 2023-11-02 14:06:35 --> Helper loaded: file_helper
INFO - 2023-11-02 14:06:35 --> Database Driver Class Initialized
DEBUG - 2023-11-02 14:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 14:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 14:06:35 --> Form Validation Class Initialized
INFO - 2023-11-02 14:06:35 --> Upload Class Initialized
INFO - 2023-11-02 14:06:35 --> Model "M_auth" initialized
INFO - 2023-11-02 14:06:35 --> Model "M_user" initialized
INFO - 2023-11-02 14:06:35 --> Model "M_produk" initialized
INFO - 2023-11-02 14:06:35 --> Controller Class Initialized
INFO - 2023-11-02 14:06:35 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 14:06:35 --> Model "M_produk" initialized
DEBUG - 2023-11-02 14:06:35 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 14:06:35 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 14:06:35 --> Model "M_transaksi" initialized
INFO - 2023-11-02 14:06:35 --> Model "M_bank" initialized
INFO - 2023-11-02 14:06:35 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 14:06:35 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
ERROR - 2023-11-02 14:06:35 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 14:06:35 --> Config Class Initialized
INFO - 2023-11-02 14:06:35 --> Hooks Class Initialized
DEBUG - 2023-11-02 14:06:35 --> UTF-8 Support Enabled
INFO - 2023-11-02 14:06:35 --> Utf8 Class Initialized
INFO - 2023-11-02 14:06:35 --> URI Class Initialized
DEBUG - 2023-11-02 14:06:35 --> No URI present. Default controller set.
INFO - 2023-11-02 14:06:35 --> Router Class Initialized
INFO - 2023-11-02 14:06:35 --> Output Class Initialized
INFO - 2023-11-02 14:06:35 --> Security Class Initialized
DEBUG - 2023-11-02 14:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 14:06:35 --> Input Class Initialized
INFO - 2023-11-02 14:06:35 --> Language Class Initialized
INFO - 2023-11-02 14:06:35 --> Loader Class Initialized
INFO - 2023-11-02 14:06:35 --> Helper loaded: url_helper
INFO - 2023-11-02 14:06:35 --> Helper loaded: form_helper
INFO - 2023-11-02 14:06:35 --> Helper loaded: file_helper
INFO - 2023-11-02 14:06:35 --> Database Driver Class Initialized
DEBUG - 2023-11-02 14:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 14:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 14:06:35 --> Form Validation Class Initialized
INFO - 2023-11-02 14:06:35 --> Upload Class Initialized
INFO - 2023-11-02 14:06:35 --> Model "M_auth" initialized
INFO - 2023-11-02 14:06:35 --> Model "M_user" initialized
INFO - 2023-11-02 14:06:35 --> Model "M_produk" initialized
INFO - 2023-11-02 14:06:35 --> Controller Class Initialized
INFO - 2023-11-02 14:06:35 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 14:06:35 --> Model "M_produk" initialized
DEBUG - 2023-11-02 14:06:35 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 14:06:35 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 14:06:35 --> Model "M_transaksi" initialized
INFO - 2023-11-02 14:06:35 --> Model "M_bank" initialized
INFO - 2023-11-02 14:06:35 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 14:06:35 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 14:06:35 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 14:06:35 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 14:06:35 --> Final output sent to browser
DEBUG - 2023-11-02 14:06:35 --> Total execution time: 0.0030
ERROR - 2023-11-02 15:32:11 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 15:32:11 --> Config Class Initialized
INFO - 2023-11-02 15:32:11 --> Hooks Class Initialized
DEBUG - 2023-11-02 15:32:11 --> UTF-8 Support Enabled
INFO - 2023-11-02 15:32:11 --> Utf8 Class Initialized
INFO - 2023-11-02 15:32:11 --> URI Class Initialized
INFO - 2023-11-02 15:32:11 --> Router Class Initialized
INFO - 2023-11-02 15:32:11 --> Output Class Initialized
INFO - 2023-11-02 15:32:11 --> Security Class Initialized
DEBUG - 2023-11-02 15:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 15:32:11 --> Input Class Initialized
INFO - 2023-11-02 15:32:11 --> Language Class Initialized
INFO - 2023-11-02 15:32:11 --> Loader Class Initialized
INFO - 2023-11-02 15:32:11 --> Helper loaded: url_helper
INFO - 2023-11-02 15:32:11 --> Helper loaded: form_helper
INFO - 2023-11-02 15:32:11 --> Helper loaded: file_helper
INFO - 2023-11-02 15:32:11 --> Database Driver Class Initialized
DEBUG - 2023-11-02 15:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 15:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 15:32:11 --> Form Validation Class Initialized
INFO - 2023-11-02 15:32:11 --> Upload Class Initialized
INFO - 2023-11-02 15:32:11 --> Model "M_auth" initialized
INFO - 2023-11-02 15:32:11 --> Model "M_user" initialized
INFO - 2023-11-02 15:32:11 --> Model "M_produk" initialized
INFO - 2023-11-02 15:32:11 --> Controller Class Initialized
INFO - 2023-11-02 15:32:11 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 15:32:11 --> Model "M_produk" initialized
DEBUG - 2023-11-02 15:32:11 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 15:32:11 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 15:32:11 --> Model "M_transaksi" initialized
INFO - 2023-11-02 15:32:11 --> Model "M_bank" initialized
INFO - 2023-11-02 15:32:11 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 15:32:11 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 15:32:11 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 15:32:11 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-02 15:32:11 --> Final output sent to browser
DEBUG - 2023-11-02 15:32:11 --> Total execution time: 0.0389
ERROR - 2023-11-02 16:37:41 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 16:37:41 --> Config Class Initialized
INFO - 2023-11-02 16:37:41 --> Hooks Class Initialized
DEBUG - 2023-11-02 16:37:41 --> UTF-8 Support Enabled
INFO - 2023-11-02 16:37:41 --> Utf8 Class Initialized
INFO - 2023-11-02 16:37:41 --> URI Class Initialized
INFO - 2023-11-02 16:37:41 --> Router Class Initialized
INFO - 2023-11-02 16:37:41 --> Output Class Initialized
INFO - 2023-11-02 16:37:41 --> Security Class Initialized
DEBUG - 2023-11-02 16:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 16:37:41 --> Input Class Initialized
INFO - 2023-11-02 16:37:41 --> Language Class Initialized
INFO - 2023-11-02 16:37:41 --> Loader Class Initialized
INFO - 2023-11-02 16:37:41 --> Helper loaded: url_helper
INFO - 2023-11-02 16:37:41 --> Helper loaded: form_helper
INFO - 2023-11-02 16:37:41 --> Helper loaded: file_helper
INFO - 2023-11-02 16:37:41 --> Database Driver Class Initialized
DEBUG - 2023-11-02 16:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 16:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 16:37:41 --> Form Validation Class Initialized
INFO - 2023-11-02 16:37:41 --> Upload Class Initialized
INFO - 2023-11-02 16:37:41 --> Model "M_auth" initialized
INFO - 2023-11-02 16:37:41 --> Model "M_user" initialized
INFO - 2023-11-02 16:37:41 --> Model "M_produk" initialized
INFO - 2023-11-02 16:37:41 --> Controller Class Initialized
INFO - 2023-11-02 16:37:41 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 16:37:41 --> Model "M_produk" initialized
DEBUG - 2023-11-02 16:37:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 16:37:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 16:37:41 --> Model "M_transaksi" initialized
INFO - 2023-11-02 16:37:41 --> Model "M_bank" initialized
INFO - 2023-11-02 16:37:41 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 16:37:41 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
ERROR - 2023-11-02 16:37:41 --> Severity: Warning --> Attempt to read property "nama_merek" on null /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_kategori_detail.php 112
INFO - 2023-11-02 16:37:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 16:37:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_kategori_detail.php
INFO - 2023-11-02 16:37:41 --> Final output sent to browser
DEBUG - 2023-11-02 16:37:41 --> Total execution time: 0.0411
ERROR - 2023-11-02 17:31:18 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 17:31:18 --> Config Class Initialized
INFO - 2023-11-02 17:31:18 --> Hooks Class Initialized
DEBUG - 2023-11-02 17:31:18 --> UTF-8 Support Enabled
INFO - 2023-11-02 17:31:18 --> Utf8 Class Initialized
INFO - 2023-11-02 17:31:18 --> URI Class Initialized
INFO - 2023-11-02 17:31:18 --> Router Class Initialized
INFO - 2023-11-02 17:31:18 --> Output Class Initialized
INFO - 2023-11-02 17:31:18 --> Security Class Initialized
DEBUG - 2023-11-02 17:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 17:31:18 --> Input Class Initialized
INFO - 2023-11-02 17:31:18 --> Language Class Initialized
INFO - 2023-11-02 17:31:18 --> Loader Class Initialized
INFO - 2023-11-02 17:31:18 --> Helper loaded: url_helper
INFO - 2023-11-02 17:31:18 --> Helper loaded: form_helper
INFO - 2023-11-02 17:31:18 --> Helper loaded: file_helper
INFO - 2023-11-02 17:31:18 --> Database Driver Class Initialized
DEBUG - 2023-11-02 17:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 17:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 17:31:18 --> Form Validation Class Initialized
INFO - 2023-11-02 17:31:18 --> Upload Class Initialized
INFO - 2023-11-02 17:31:18 --> Model "M_auth" initialized
INFO - 2023-11-02 17:31:18 --> Model "M_user" initialized
INFO - 2023-11-02 17:31:18 --> Model "M_produk" initialized
INFO - 2023-11-02 17:31:18 --> Controller Class Initialized
INFO - 2023-11-02 17:31:18 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 17:31:18 --> Model "M_produk" initialized
DEBUG - 2023-11-02 17:31:18 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 17:31:18 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 17:31:18 --> Model "M_transaksi" initialized
INFO - 2023-11-02 17:31:18 --> Model "M_bank" initialized
INFO - 2023-11-02 17:31:18 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 17:31:18 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 17:31:18 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 17:31:18 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_kategori_detail.php
INFO - 2023-11-02 17:31:18 --> Final output sent to browser
DEBUG - 2023-11-02 17:31:18 --> Total execution time: 0.0469
ERROR - 2023-11-02 19:00:40 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 19:00:40 --> Config Class Initialized
INFO - 2023-11-02 19:00:40 --> Hooks Class Initialized
DEBUG - 2023-11-02 19:00:40 --> UTF-8 Support Enabled
INFO - 2023-11-02 19:00:40 --> Utf8 Class Initialized
INFO - 2023-11-02 19:00:40 --> URI Class Initialized
DEBUG - 2023-11-02 19:00:40 --> No URI present. Default controller set.
INFO - 2023-11-02 19:00:40 --> Router Class Initialized
INFO - 2023-11-02 19:00:40 --> Output Class Initialized
INFO - 2023-11-02 19:00:40 --> Security Class Initialized
DEBUG - 2023-11-02 19:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 19:00:40 --> Input Class Initialized
INFO - 2023-11-02 19:00:40 --> Language Class Initialized
INFO - 2023-11-02 19:00:40 --> Loader Class Initialized
INFO - 2023-11-02 19:00:40 --> Helper loaded: url_helper
INFO - 2023-11-02 19:00:40 --> Helper loaded: form_helper
INFO - 2023-11-02 19:00:40 --> Helper loaded: file_helper
INFO - 2023-11-02 19:00:40 --> Database Driver Class Initialized
DEBUG - 2023-11-02 19:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 19:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 19:00:40 --> Form Validation Class Initialized
INFO - 2023-11-02 19:00:40 --> Upload Class Initialized
INFO - 2023-11-02 19:00:40 --> Model "M_auth" initialized
INFO - 2023-11-02 19:00:40 --> Model "M_user" initialized
INFO - 2023-11-02 19:00:40 --> Model "M_produk" initialized
INFO - 2023-11-02 19:00:40 --> Controller Class Initialized
INFO - 2023-11-02 19:00:40 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 19:00:40 --> Model "M_produk" initialized
DEBUG - 2023-11-02 19:00:40 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 19:00:40 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 19:00:40 --> Model "M_transaksi" initialized
INFO - 2023-11-02 19:00:40 --> Model "M_bank" initialized
INFO - 2023-11-02 19:00:40 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 19:00:40 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 19:00:40 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 19:00:40 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 19:00:40 --> Final output sent to browser
DEBUG - 2023-11-02 19:00:40 --> Total execution time: 0.0459
ERROR - 2023-11-02 19:05:41 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 19:05:41 --> Config Class Initialized
INFO - 2023-11-02 19:05:41 --> Hooks Class Initialized
DEBUG - 2023-11-02 19:05:41 --> UTF-8 Support Enabled
INFO - 2023-11-02 19:05:41 --> Utf8 Class Initialized
INFO - 2023-11-02 19:05:41 --> URI Class Initialized
DEBUG - 2023-11-02 19:05:41 --> No URI present. Default controller set.
INFO - 2023-11-02 19:05:41 --> Router Class Initialized
INFO - 2023-11-02 19:05:41 --> Output Class Initialized
INFO - 2023-11-02 19:05:41 --> Security Class Initialized
DEBUG - 2023-11-02 19:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 19:05:41 --> Input Class Initialized
INFO - 2023-11-02 19:05:41 --> Language Class Initialized
INFO - 2023-11-02 19:05:41 --> Loader Class Initialized
INFO - 2023-11-02 19:05:41 --> Helper loaded: url_helper
INFO - 2023-11-02 19:05:41 --> Helper loaded: form_helper
INFO - 2023-11-02 19:05:41 --> Helper loaded: file_helper
INFO - 2023-11-02 19:05:41 --> Database Driver Class Initialized
DEBUG - 2023-11-02 19:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 19:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 19:05:41 --> Form Validation Class Initialized
INFO - 2023-11-02 19:05:41 --> Upload Class Initialized
INFO - 2023-11-02 19:05:41 --> Model "M_auth" initialized
INFO - 2023-11-02 19:05:41 --> Model "M_user" initialized
INFO - 2023-11-02 19:05:41 --> Model "M_produk" initialized
INFO - 2023-11-02 19:05:41 --> Controller Class Initialized
INFO - 2023-11-02 19:05:41 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 19:05:41 --> Model "M_produk" initialized
DEBUG - 2023-11-02 19:05:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 19:05:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 19:05:41 --> Model "M_transaksi" initialized
INFO - 2023-11-02 19:05:41 --> Model "M_bank" initialized
INFO - 2023-11-02 19:05:41 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 19:05:41 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 19:05:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 19:05:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 19:05:41 --> Final output sent to browser
DEBUG - 2023-11-02 19:05:41 --> Total execution time: 0.0041
ERROR - 2023-11-02 20:53:12 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 20:53:12 --> Config Class Initialized
INFO - 2023-11-02 20:53:12 --> Hooks Class Initialized
DEBUG - 2023-11-02 20:53:12 --> UTF-8 Support Enabled
INFO - 2023-11-02 20:53:12 --> Utf8 Class Initialized
INFO - 2023-11-02 20:53:12 --> URI Class Initialized
DEBUG - 2023-11-02 20:53:12 --> No URI present. Default controller set.
INFO - 2023-11-02 20:53:12 --> Router Class Initialized
INFO - 2023-11-02 20:53:12 --> Output Class Initialized
INFO - 2023-11-02 20:53:12 --> Security Class Initialized
DEBUG - 2023-11-02 20:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 20:53:12 --> Input Class Initialized
INFO - 2023-11-02 20:53:12 --> Language Class Initialized
INFO - 2023-11-02 20:53:12 --> Loader Class Initialized
INFO - 2023-11-02 20:53:12 --> Helper loaded: url_helper
INFO - 2023-11-02 20:53:12 --> Helper loaded: form_helper
INFO - 2023-11-02 20:53:12 --> Helper loaded: file_helper
INFO - 2023-11-02 20:53:12 --> Database Driver Class Initialized
DEBUG - 2023-11-02 20:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 20:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 20:53:12 --> Form Validation Class Initialized
INFO - 2023-11-02 20:53:12 --> Upload Class Initialized
INFO - 2023-11-02 20:53:12 --> Model "M_auth" initialized
INFO - 2023-11-02 20:53:12 --> Model "M_user" initialized
INFO - 2023-11-02 20:53:12 --> Model "M_produk" initialized
INFO - 2023-11-02 20:53:12 --> Controller Class Initialized
INFO - 2023-11-02 20:53:12 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 20:53:12 --> Model "M_produk" initialized
DEBUG - 2023-11-02 20:53:12 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 20:53:12 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 20:53:12 --> Model "M_transaksi" initialized
INFO - 2023-11-02 20:53:12 --> Model "M_bank" initialized
INFO - 2023-11-02 20:53:12 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 20:53:12 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 20:53:12 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 20:53:12 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 20:53:12 --> Final output sent to browser
DEBUG - 2023-11-02 20:53:12 --> Total execution time: 0.0406
ERROR - 2023-11-02 21:00:31 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 21:00:31 --> Config Class Initialized
INFO - 2023-11-02 21:00:31 --> Hooks Class Initialized
DEBUG - 2023-11-02 21:00:31 --> UTF-8 Support Enabled
INFO - 2023-11-02 21:00:31 --> Utf8 Class Initialized
INFO - 2023-11-02 21:00:31 --> URI Class Initialized
INFO - 2023-11-02 21:00:31 --> Router Class Initialized
INFO - 2023-11-02 21:00:31 --> Output Class Initialized
INFO - 2023-11-02 21:00:31 --> Security Class Initialized
DEBUG - 2023-11-02 21:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 21:00:31 --> Input Class Initialized
INFO - 2023-11-02 21:00:31 --> Language Class Initialized
INFO - 2023-11-02 21:00:31 --> Loader Class Initialized
INFO - 2023-11-02 21:00:31 --> Helper loaded: url_helper
INFO - 2023-11-02 21:00:31 --> Helper loaded: form_helper
INFO - 2023-11-02 21:00:31 --> Helper loaded: file_helper
INFO - 2023-11-02 21:00:31 --> Database Driver Class Initialized
DEBUG - 2023-11-02 21:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 21:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 21:00:31 --> Form Validation Class Initialized
INFO - 2023-11-02 21:00:31 --> Upload Class Initialized
INFO - 2023-11-02 21:00:31 --> Model "M_auth" initialized
INFO - 2023-11-02 21:00:31 --> Model "M_user" initialized
INFO - 2023-11-02 21:00:31 --> Model "M_produk" initialized
INFO - 2023-11-02 21:00:31 --> Controller Class Initialized
INFO - 2023-11-02 21:00:31 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-02 21:00:31 --> Final output sent to browser
DEBUG - 2023-11-02 21:00:31 --> Total execution time: 0.1802
ERROR - 2023-11-02 21:01:22 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 21:01:22 --> Config Class Initialized
INFO - 2023-11-02 21:01:22 --> Hooks Class Initialized
DEBUG - 2023-11-02 21:01:22 --> UTF-8 Support Enabled
INFO - 2023-11-02 21:01:22 --> Utf8 Class Initialized
INFO - 2023-11-02 21:01:22 --> URI Class Initialized
DEBUG - 2023-11-02 21:01:22 --> No URI present. Default controller set.
INFO - 2023-11-02 21:01:22 --> Router Class Initialized
INFO - 2023-11-02 21:01:22 --> Output Class Initialized
INFO - 2023-11-02 21:01:22 --> Security Class Initialized
DEBUG - 2023-11-02 21:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 21:01:22 --> Input Class Initialized
INFO - 2023-11-02 21:01:22 --> Language Class Initialized
INFO - 2023-11-02 21:01:22 --> Loader Class Initialized
INFO - 2023-11-02 21:01:22 --> Helper loaded: url_helper
INFO - 2023-11-02 21:01:22 --> Helper loaded: form_helper
INFO - 2023-11-02 21:01:22 --> Helper loaded: file_helper
INFO - 2023-11-02 21:01:22 --> Database Driver Class Initialized
DEBUG - 2023-11-02 21:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 21:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 21:01:22 --> Form Validation Class Initialized
INFO - 2023-11-02 21:01:22 --> Upload Class Initialized
INFO - 2023-11-02 21:01:22 --> Model "M_auth" initialized
INFO - 2023-11-02 21:01:22 --> Model "M_user" initialized
INFO - 2023-11-02 21:01:22 --> Model "M_produk" initialized
INFO - 2023-11-02 21:01:22 --> Controller Class Initialized
INFO - 2023-11-02 21:01:22 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 21:01:22 --> Model "M_produk" initialized
DEBUG - 2023-11-02 21:01:22 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 21:01:22 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 21:01:22 --> Model "M_transaksi" initialized
INFO - 2023-11-02 21:01:22 --> Model "M_bank" initialized
INFO - 2023-11-02 21:01:22 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 21:01:22 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 21:01:22 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 21:01:22 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 21:01:22 --> Final output sent to browser
DEBUG - 2023-11-02 21:01:22 --> Total execution time: 0.0098
ERROR - 2023-11-02 21:01:56 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-02 21:01:56 --> Config Class Initialized
INFO - 2023-11-02 21:01:56 --> Hooks Class Initialized
DEBUG - 2023-11-02 21:01:56 --> UTF-8 Support Enabled
INFO - 2023-11-02 21:01:56 --> Utf8 Class Initialized
INFO - 2023-11-02 21:01:56 --> URI Class Initialized
DEBUG - 2023-11-02 21:01:56 --> No URI present. Default controller set.
INFO - 2023-11-02 21:01:56 --> Router Class Initialized
INFO - 2023-11-02 21:01:56 --> Output Class Initialized
INFO - 2023-11-02 21:01:56 --> Security Class Initialized
DEBUG - 2023-11-02 21:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-02 21:01:56 --> Input Class Initialized
INFO - 2023-11-02 21:01:56 --> Language Class Initialized
INFO - 2023-11-02 21:01:56 --> Loader Class Initialized
INFO - 2023-11-02 21:01:56 --> Helper loaded: url_helper
INFO - 2023-11-02 21:01:56 --> Helper loaded: form_helper
INFO - 2023-11-02 21:01:56 --> Helper loaded: file_helper
INFO - 2023-11-02 21:01:56 --> Database Driver Class Initialized
DEBUG - 2023-11-02 21:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-02 21:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-02 21:01:56 --> Form Validation Class Initialized
INFO - 2023-11-02 21:01:56 --> Upload Class Initialized
INFO - 2023-11-02 21:01:56 --> Model "M_auth" initialized
INFO - 2023-11-02 21:01:56 --> Model "M_user" initialized
INFO - 2023-11-02 21:01:56 --> Model "M_produk" initialized
INFO - 2023-11-02 21:01:56 --> Controller Class Initialized
INFO - 2023-11-02 21:01:56 --> Model "M_pelanggan" initialized
INFO - 2023-11-02 21:01:56 --> Model "M_produk" initialized
DEBUG - 2023-11-02 21:01:56 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-02 21:01:56 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-02 21:01:56 --> Model "M_transaksi" initialized
INFO - 2023-11-02 21:01:56 --> Model "M_bank" initialized
INFO - 2023-11-02 21:01:56 --> Model "M_pesan" initialized
DEBUG - 2023-11-02 21:01:56 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-02 21:01:56 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-02 21:01:56 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-02 21:01:56 --> Final output sent to browser
DEBUG - 2023-11-02 21:01:56 --> Total execution time: 0.0047
