<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-05 00:38:56 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-05 00:38:56 --> Config Class Initialized
INFO - 2023-11-05 00:38:56 --> Hooks Class Initialized
DEBUG - 2023-11-05 00:38:56 --> UTF-8 Support Enabled
INFO - 2023-11-05 00:38:56 --> Utf8 Class Initialized
INFO - 2023-11-05 00:38:56 --> URI Class Initialized
DEBUG - 2023-11-05 00:38:56 --> No URI present. Default controller set.
INFO - 2023-11-05 00:38:56 --> Router Class Initialized
INFO - 2023-11-05 00:38:56 --> Output Class Initialized
INFO - 2023-11-05 00:38:56 --> Security Class Initialized
DEBUG - 2023-11-05 00:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 00:38:56 --> Input Class Initialized
INFO - 2023-11-05 00:38:56 --> Language Class Initialized
INFO - 2023-11-05 00:38:56 --> Loader Class Initialized
INFO - 2023-11-05 00:38:56 --> Helper loaded: url_helper
INFO - 2023-11-05 00:38:56 --> Helper loaded: form_helper
INFO - 2023-11-05 00:38:56 --> Helper loaded: file_helper
INFO - 2023-11-05 00:38:56 --> Database Driver Class Initialized
DEBUG - 2023-11-05 00:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 00:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 00:38:56 --> Form Validation Class Initialized
INFO - 2023-11-05 00:38:56 --> Upload Class Initialized
INFO - 2023-11-05 00:38:56 --> Model "M_auth" initialized
INFO - 2023-11-05 00:38:56 --> Model "M_user" initialized
INFO - 2023-11-05 00:38:56 --> Model "M_produk" initialized
INFO - 2023-11-05 00:38:56 --> Controller Class Initialized
INFO - 2023-11-05 00:38:56 --> Model "M_pelanggan" initialized
INFO - 2023-11-05 00:38:56 --> Model "M_produk" initialized
DEBUG - 2023-11-05 00:38:56 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 00:38:56 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-05 00:38:56 --> Model "M_transaksi" initialized
INFO - 2023-11-05 00:38:56 --> Model "M_bank" initialized
INFO - 2023-11-05 00:38:56 --> Model "M_pesan" initialized
DEBUG - 2023-11-05 00:38:56 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-05 00:38:56 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-05 00:38:56 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-05 00:38:56 --> Final output sent to browser
DEBUG - 2023-11-05 00:38:56 --> Total execution time: 0.0421
ERROR - 2023-11-05 03:23:56 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-05 03:23:56 --> Config Class Initialized
INFO - 2023-11-05 03:23:56 --> Hooks Class Initialized
DEBUG - 2023-11-05 03:23:56 --> UTF-8 Support Enabled
INFO - 2023-11-05 03:23:56 --> Utf8 Class Initialized
INFO - 2023-11-05 03:23:56 --> URI Class Initialized
INFO - 2023-11-05 03:23:56 --> Router Class Initialized
INFO - 2023-11-05 03:23:56 --> Output Class Initialized
INFO - 2023-11-05 03:23:56 --> Security Class Initialized
DEBUG - 2023-11-05 03:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 03:23:56 --> Input Class Initialized
INFO - 2023-11-05 03:23:56 --> Language Class Initialized
INFO - 2023-11-05 03:23:56 --> Loader Class Initialized
INFO - 2023-11-05 03:23:56 --> Helper loaded: url_helper
INFO - 2023-11-05 03:23:56 --> Helper loaded: form_helper
INFO - 2023-11-05 03:23:56 --> Helper loaded: file_helper
INFO - 2023-11-05 03:23:56 --> Database Driver Class Initialized
DEBUG - 2023-11-05 03:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 03:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 03:23:56 --> Form Validation Class Initialized
INFO - 2023-11-05 03:23:56 --> Upload Class Initialized
INFO - 2023-11-05 03:23:56 --> Model "M_auth" initialized
INFO - 2023-11-05 03:23:56 --> Model "M_user" initialized
INFO - 2023-11-05 03:23:56 --> Model "M_produk" initialized
INFO - 2023-11-05 03:23:56 --> Controller Class Initialized
INFO - 2023-11-05 03:23:56 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-05 03:23:56 --> Final output sent to browser
DEBUG - 2023-11-05 03:23:56 --> Total execution time: 0.0321
ERROR - 2023-11-05 04:03:03 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-05 04:03:03 --> Config Class Initialized
INFO - 2023-11-05 04:03:03 --> Hooks Class Initialized
DEBUG - 2023-11-05 04:03:03 --> UTF-8 Support Enabled
INFO - 2023-11-05 04:03:03 --> Utf8 Class Initialized
INFO - 2023-11-05 04:03:03 --> URI Class Initialized
DEBUG - 2023-11-05 04:03:03 --> No URI present. Default controller set.
INFO - 2023-11-05 04:03:03 --> Router Class Initialized
INFO - 2023-11-05 04:03:03 --> Output Class Initialized
INFO - 2023-11-05 04:03:03 --> Security Class Initialized
DEBUG - 2023-11-05 04:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 04:03:03 --> Input Class Initialized
INFO - 2023-11-05 04:03:03 --> Language Class Initialized
INFO - 2023-11-05 04:03:03 --> Loader Class Initialized
INFO - 2023-11-05 04:03:03 --> Helper loaded: url_helper
INFO - 2023-11-05 04:03:03 --> Helper loaded: form_helper
INFO - 2023-11-05 04:03:03 --> Helper loaded: file_helper
INFO - 2023-11-05 04:03:03 --> Database Driver Class Initialized
DEBUG - 2023-11-05 04:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 04:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 04:03:03 --> Form Validation Class Initialized
INFO - 2023-11-05 04:03:03 --> Upload Class Initialized
INFO - 2023-11-05 04:03:03 --> Model "M_auth" initialized
INFO - 2023-11-05 04:03:03 --> Model "M_user" initialized
INFO - 2023-11-05 04:03:03 --> Model "M_produk" initialized
INFO - 2023-11-05 04:03:03 --> Controller Class Initialized
INFO - 2023-11-05 04:03:03 --> Model "M_pelanggan" initialized
INFO - 2023-11-05 04:03:03 --> Model "M_produk" initialized
DEBUG - 2023-11-05 04:03:03 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 04:03:03 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-05 04:03:03 --> Model "M_transaksi" initialized
INFO - 2023-11-05 04:03:03 --> Model "M_bank" initialized
INFO - 2023-11-05 04:03:03 --> Model "M_pesan" initialized
DEBUG - 2023-11-05 04:03:03 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-05 04:03:03 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-05 04:03:03 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-05 04:03:03 --> Final output sent to browser
DEBUG - 2023-11-05 04:03:03 --> Total execution time: 0.0349
ERROR - 2023-11-05 08:34:55 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-05 08:34:55 --> Config Class Initialized
INFO - 2023-11-05 08:34:55 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:34:55 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:34:55 --> Utf8 Class Initialized
INFO - 2023-11-05 08:34:55 --> URI Class Initialized
DEBUG - 2023-11-05 08:34:55 --> No URI present. Default controller set.
INFO - 2023-11-05 08:34:55 --> Router Class Initialized
INFO - 2023-11-05 08:34:55 --> Output Class Initialized
INFO - 2023-11-05 08:34:55 --> Security Class Initialized
DEBUG - 2023-11-05 08:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:34:55 --> Input Class Initialized
INFO - 2023-11-05 08:34:55 --> Language Class Initialized
INFO - 2023-11-05 08:34:55 --> Loader Class Initialized
INFO - 2023-11-05 08:34:55 --> Helper loaded: url_helper
INFO - 2023-11-05 08:34:55 --> Helper loaded: form_helper
INFO - 2023-11-05 08:34:55 --> Helper loaded: file_helper
INFO - 2023-11-05 08:34:55 --> Database Driver Class Initialized
DEBUG - 2023-11-05 08:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 08:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 08:34:55 --> Form Validation Class Initialized
INFO - 2023-11-05 08:34:55 --> Upload Class Initialized
INFO - 2023-11-05 08:34:55 --> Model "M_auth" initialized
INFO - 2023-11-05 08:34:55 --> Model "M_user" initialized
INFO - 2023-11-05 08:34:55 --> Model "M_produk" initialized
INFO - 2023-11-05 08:34:55 --> Controller Class Initialized
INFO - 2023-11-05 08:34:55 --> Model "M_pelanggan" initialized
INFO - 2023-11-05 08:34:55 --> Model "M_produk" initialized
DEBUG - 2023-11-05 08:34:55 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 08:34:55 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-05 08:34:55 --> Model "M_transaksi" initialized
INFO - 2023-11-05 08:34:55 --> Model "M_bank" initialized
INFO - 2023-11-05 08:34:55 --> Model "M_pesan" initialized
DEBUG - 2023-11-05 08:34:55 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-05 08:34:55 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-05 08:34:55 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-05 08:34:55 --> Final output sent to browser
DEBUG - 2023-11-05 08:34:55 --> Total execution time: 0.0370
ERROR - 2023-11-05 08:49:09 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-05 08:49:09 --> Config Class Initialized
INFO - 2023-11-05 08:49:09 --> Hooks Class Initialized
DEBUG - 2023-11-05 08:49:09 --> UTF-8 Support Enabled
INFO - 2023-11-05 08:49:09 --> Utf8 Class Initialized
INFO - 2023-11-05 08:49:09 --> URI Class Initialized
DEBUG - 2023-11-05 08:49:09 --> No URI present. Default controller set.
INFO - 2023-11-05 08:49:09 --> Router Class Initialized
INFO - 2023-11-05 08:49:09 --> Output Class Initialized
INFO - 2023-11-05 08:49:09 --> Security Class Initialized
DEBUG - 2023-11-05 08:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 08:49:09 --> Input Class Initialized
INFO - 2023-11-05 08:49:09 --> Language Class Initialized
INFO - 2023-11-05 08:49:09 --> Loader Class Initialized
INFO - 2023-11-05 08:49:09 --> Helper loaded: url_helper
INFO - 2023-11-05 08:49:09 --> Helper loaded: form_helper
INFO - 2023-11-05 08:49:09 --> Helper loaded: file_helper
INFO - 2023-11-05 08:49:09 --> Database Driver Class Initialized
DEBUG - 2023-11-05 08:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 08:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 08:49:09 --> Form Validation Class Initialized
INFO - 2023-11-05 08:49:09 --> Upload Class Initialized
INFO - 2023-11-05 08:49:09 --> Model "M_auth" initialized
INFO - 2023-11-05 08:49:09 --> Model "M_user" initialized
INFO - 2023-11-05 08:49:09 --> Model "M_produk" initialized
INFO - 2023-11-05 08:49:09 --> Controller Class Initialized
INFO - 2023-11-05 08:49:09 --> Model "M_pelanggan" initialized
INFO - 2023-11-05 08:49:09 --> Model "M_produk" initialized
DEBUG - 2023-11-05 08:49:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 08:49:09 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-05 08:49:09 --> Model "M_transaksi" initialized
INFO - 2023-11-05 08:49:09 --> Model "M_bank" initialized
INFO - 2023-11-05 08:49:09 --> Model "M_pesan" initialized
DEBUG - 2023-11-05 08:49:09 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-05 08:49:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-05 08:49:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-05 08:49:09 --> Final output sent to browser
DEBUG - 2023-11-05 08:49:09 --> Total execution time: 0.0316
ERROR - 2023-11-05 10:27:48 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-05 10:27:48 --> Config Class Initialized
INFO - 2023-11-05 10:27:48 --> Hooks Class Initialized
DEBUG - 2023-11-05 10:27:48 --> UTF-8 Support Enabled
INFO - 2023-11-05 10:27:48 --> Utf8 Class Initialized
INFO - 2023-11-05 10:27:48 --> URI Class Initialized
INFO - 2023-11-05 10:27:48 --> Router Class Initialized
INFO - 2023-11-05 10:27:48 --> Output Class Initialized
INFO - 2023-11-05 10:27:48 --> Security Class Initialized
DEBUG - 2023-11-05 10:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 10:27:48 --> Input Class Initialized
INFO - 2023-11-05 10:27:48 --> Language Class Initialized
INFO - 2023-11-05 10:27:48 --> Loader Class Initialized
INFO - 2023-11-05 10:27:48 --> Helper loaded: url_helper
INFO - 2023-11-05 10:27:48 --> Helper loaded: form_helper
INFO - 2023-11-05 10:27:48 --> Helper loaded: file_helper
INFO - 2023-11-05 10:27:48 --> Database Driver Class Initialized
DEBUG - 2023-11-05 10:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 10:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 10:27:48 --> Form Validation Class Initialized
INFO - 2023-11-05 10:27:48 --> Upload Class Initialized
INFO - 2023-11-05 10:27:48 --> Model "M_auth" initialized
INFO - 2023-11-05 10:27:48 --> Model "M_user" initialized
INFO - 2023-11-05 10:27:48 --> Model "M_produk" initialized
INFO - 2023-11-05 10:27:48 --> Controller Class Initialized
INFO - 2023-11-05 10:27:48 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-05 10:27:48 --> Final output sent to browser
DEBUG - 2023-11-05 10:27:48 --> Total execution time: 0.0344
ERROR - 2023-11-05 12:30:21 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-05 12:30:21 --> Config Class Initialized
INFO - 2023-11-05 12:30:21 --> Hooks Class Initialized
DEBUG - 2023-11-05 12:30:21 --> UTF-8 Support Enabled
INFO - 2023-11-05 12:30:21 --> Utf8 Class Initialized
INFO - 2023-11-05 12:30:21 --> URI Class Initialized
INFO - 2023-11-05 12:30:21 --> Router Class Initialized
INFO - 2023-11-05 12:30:21 --> Output Class Initialized
INFO - 2023-11-05 12:30:21 --> Security Class Initialized
DEBUG - 2023-11-05 12:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 12:30:21 --> Input Class Initialized
INFO - 2023-11-05 12:30:21 --> Language Class Initialized
INFO - 2023-11-05 12:30:21 --> Loader Class Initialized
INFO - 2023-11-05 12:30:21 --> Helper loaded: url_helper
INFO - 2023-11-05 12:30:21 --> Helper loaded: form_helper
INFO - 2023-11-05 12:30:21 --> Helper loaded: file_helper
INFO - 2023-11-05 12:30:21 --> Database Driver Class Initialized
DEBUG - 2023-11-05 12:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 12:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 12:30:21 --> Form Validation Class Initialized
INFO - 2023-11-05 12:30:21 --> Upload Class Initialized
INFO - 2023-11-05 12:30:21 --> Model "M_auth" initialized
INFO - 2023-11-05 12:30:21 --> Model "M_user" initialized
INFO - 2023-11-05 12:30:21 --> Model "M_produk" initialized
INFO - 2023-11-05 12:30:21 --> Controller Class Initialized
INFO - 2023-11-05 12:30:21 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-05 12:30:21 --> Final output sent to browser
DEBUG - 2023-11-05 12:30:21 --> Total execution time: 0.0252
ERROR - 2023-11-05 12:30:23 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-05 12:30:23 --> Config Class Initialized
INFO - 2023-11-05 12:30:23 --> Hooks Class Initialized
DEBUG - 2023-11-05 12:30:23 --> UTF-8 Support Enabled
INFO - 2023-11-05 12:30:23 --> Utf8 Class Initialized
INFO - 2023-11-05 12:30:23 --> URI Class Initialized
DEBUG - 2023-11-05 12:30:23 --> No URI present. Default controller set.
INFO - 2023-11-05 12:30:23 --> Router Class Initialized
INFO - 2023-11-05 12:30:23 --> Output Class Initialized
INFO - 2023-11-05 12:30:23 --> Security Class Initialized
DEBUG - 2023-11-05 12:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 12:30:23 --> Input Class Initialized
INFO - 2023-11-05 12:30:23 --> Language Class Initialized
INFO - 2023-11-05 12:30:23 --> Loader Class Initialized
INFO - 2023-11-05 12:30:23 --> Helper loaded: url_helper
INFO - 2023-11-05 12:30:23 --> Helper loaded: form_helper
INFO - 2023-11-05 12:30:23 --> Helper loaded: file_helper
INFO - 2023-11-05 12:30:23 --> Database Driver Class Initialized
DEBUG - 2023-11-05 12:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 12:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 12:30:23 --> Form Validation Class Initialized
INFO - 2023-11-05 12:30:23 --> Upload Class Initialized
INFO - 2023-11-05 12:30:23 --> Model "M_auth" initialized
INFO - 2023-11-05 12:30:23 --> Model "M_user" initialized
INFO - 2023-11-05 12:30:23 --> Model "M_produk" initialized
INFO - 2023-11-05 12:30:23 --> Controller Class Initialized
INFO - 2023-11-05 12:30:23 --> Model "M_pelanggan" initialized
INFO - 2023-11-05 12:30:23 --> Model "M_produk" initialized
DEBUG - 2023-11-05 12:30:23 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 12:30:23 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-05 12:30:23 --> Model "M_transaksi" initialized
INFO - 2023-11-05 12:30:23 --> Model "M_bank" initialized
INFO - 2023-11-05 12:30:23 --> Model "M_pesan" initialized
DEBUG - 2023-11-05 12:30:23 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-05 12:30:23 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-05 12:30:23 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-05 12:30:23 --> Final output sent to browser
DEBUG - 2023-11-05 12:30:23 --> Total execution time: 0.0086
ERROR - 2023-11-05 13:55:24 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-05 13:55:24 --> Config Class Initialized
INFO - 2023-11-05 13:55:24 --> Hooks Class Initialized
DEBUG - 2023-11-05 13:55:24 --> UTF-8 Support Enabled
INFO - 2023-11-05 13:55:24 --> Utf8 Class Initialized
INFO - 2023-11-05 13:55:24 --> URI Class Initialized
INFO - 2023-11-05 13:55:24 --> Router Class Initialized
INFO - 2023-11-05 13:55:24 --> Output Class Initialized
INFO - 2023-11-05 13:55:24 --> Security Class Initialized
DEBUG - 2023-11-05 13:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 13:55:24 --> Input Class Initialized
INFO - 2023-11-05 13:55:24 --> Language Class Initialized
INFO - 2023-11-05 13:55:24 --> Loader Class Initialized
INFO - 2023-11-05 13:55:24 --> Helper loaded: url_helper
INFO - 2023-11-05 13:55:24 --> Helper loaded: form_helper
INFO - 2023-11-05 13:55:24 --> Helper loaded: file_helper
INFO - 2023-11-05 13:55:24 --> Database Driver Class Initialized
DEBUG - 2023-11-05 13:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 13:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 13:55:24 --> Form Validation Class Initialized
INFO - 2023-11-05 13:55:24 --> Upload Class Initialized
INFO - 2023-11-05 13:55:24 --> Model "M_auth" initialized
INFO - 2023-11-05 13:55:24 --> Model "M_user" initialized
INFO - 2023-11-05 13:55:24 --> Model "M_produk" initialized
INFO - 2023-11-05 13:55:24 --> Controller Class Initialized
INFO - 2023-11-05 13:55:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-05 13:55:24 --> Final output sent to browser
DEBUG - 2023-11-05 13:55:24 --> Total execution time: 0.0291
ERROR - 2023-11-05 13:55:25 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-05 13:55:25 --> Config Class Initialized
INFO - 2023-11-05 13:55:25 --> Hooks Class Initialized
DEBUG - 2023-11-05 13:55:25 --> UTF-8 Support Enabled
INFO - 2023-11-05 13:55:25 --> Utf8 Class Initialized
INFO - 2023-11-05 13:55:25 --> URI Class Initialized
DEBUG - 2023-11-05 13:55:25 --> No URI present. Default controller set.
INFO - 2023-11-05 13:55:25 --> Router Class Initialized
INFO - 2023-11-05 13:55:25 --> Output Class Initialized
INFO - 2023-11-05 13:55:25 --> Security Class Initialized
DEBUG - 2023-11-05 13:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 13:55:25 --> Input Class Initialized
INFO - 2023-11-05 13:55:25 --> Language Class Initialized
INFO - 2023-11-05 13:55:25 --> Loader Class Initialized
INFO - 2023-11-05 13:55:25 --> Helper loaded: url_helper
INFO - 2023-11-05 13:55:25 --> Helper loaded: form_helper
INFO - 2023-11-05 13:55:25 --> Helper loaded: file_helper
INFO - 2023-11-05 13:55:25 --> Database Driver Class Initialized
DEBUG - 2023-11-05 13:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 13:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 13:55:25 --> Form Validation Class Initialized
INFO - 2023-11-05 13:55:25 --> Upload Class Initialized
INFO - 2023-11-05 13:55:25 --> Model "M_auth" initialized
INFO - 2023-11-05 13:55:25 --> Model "M_user" initialized
INFO - 2023-11-05 13:55:25 --> Model "M_produk" initialized
INFO - 2023-11-05 13:55:25 --> Controller Class Initialized
INFO - 2023-11-05 13:55:25 --> Model "M_pelanggan" initialized
INFO - 2023-11-05 13:55:25 --> Model "M_produk" initialized
DEBUG - 2023-11-05 13:55:25 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 13:55:25 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-05 13:55:25 --> Model "M_transaksi" initialized
INFO - 2023-11-05 13:55:25 --> Model "M_bank" initialized
INFO - 2023-11-05 13:55:25 --> Model "M_pesan" initialized
DEBUG - 2023-11-05 13:55:25 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-05 13:55:25 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-05 13:55:25 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-05 13:55:25 --> Final output sent to browser
DEBUG - 2023-11-05 13:55:25 --> Total execution time: 0.0120
ERROR - 2023-11-05 14:47:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-05 14:47:45 --> Config Class Initialized
INFO - 2023-11-05 14:47:45 --> Hooks Class Initialized
DEBUG - 2023-11-05 14:47:45 --> UTF-8 Support Enabled
INFO - 2023-11-05 14:47:45 --> Utf8 Class Initialized
INFO - 2023-11-05 14:47:45 --> URI Class Initialized
DEBUG - 2023-11-05 14:47:45 --> No URI present. Default controller set.
INFO - 2023-11-05 14:47:45 --> Router Class Initialized
INFO - 2023-11-05 14:47:45 --> Output Class Initialized
INFO - 2023-11-05 14:47:45 --> Security Class Initialized
DEBUG - 2023-11-05 14:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 14:47:45 --> Input Class Initialized
INFO - 2023-11-05 14:47:45 --> Language Class Initialized
INFO - 2023-11-05 14:47:45 --> Loader Class Initialized
INFO - 2023-11-05 14:47:45 --> Helper loaded: url_helper
INFO - 2023-11-05 14:47:45 --> Helper loaded: form_helper
INFO - 2023-11-05 14:47:45 --> Helper loaded: file_helper
INFO - 2023-11-05 14:47:45 --> Database Driver Class Initialized
DEBUG - 2023-11-05 14:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 14:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 14:47:45 --> Form Validation Class Initialized
INFO - 2023-11-05 14:47:45 --> Upload Class Initialized
INFO - 2023-11-05 14:47:45 --> Model "M_auth" initialized
INFO - 2023-11-05 14:47:45 --> Model "M_user" initialized
INFO - 2023-11-05 14:47:45 --> Model "M_produk" initialized
INFO - 2023-11-05 14:47:45 --> Controller Class Initialized
INFO - 2023-11-05 14:47:45 --> Model "M_pelanggan" initialized
INFO - 2023-11-05 14:47:45 --> Model "M_produk" initialized
DEBUG - 2023-11-05 14:47:45 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 14:47:45 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-05 14:47:45 --> Model "M_transaksi" initialized
INFO - 2023-11-05 14:47:45 --> Model "M_bank" initialized
INFO - 2023-11-05 14:47:45 --> Model "M_pesan" initialized
DEBUG - 2023-11-05 14:47:45 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-05 14:47:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-05 14:47:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-05 14:47:45 --> Final output sent to browser
DEBUG - 2023-11-05 14:47:45 --> Total execution time: 0.0367
ERROR - 2023-11-05 15:07:38 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-05 15:07:38 --> Config Class Initialized
INFO - 2023-11-05 15:07:38 --> Hooks Class Initialized
DEBUG - 2023-11-05 15:07:38 --> UTF-8 Support Enabled
INFO - 2023-11-05 15:07:38 --> Utf8 Class Initialized
INFO - 2023-11-05 15:07:38 --> URI Class Initialized
INFO - 2023-11-05 15:07:38 --> Router Class Initialized
INFO - 2023-11-05 15:07:38 --> Output Class Initialized
INFO - 2023-11-05 15:07:38 --> Security Class Initialized
DEBUG - 2023-11-05 15:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 15:07:38 --> Input Class Initialized
INFO - 2023-11-05 15:07:38 --> Language Class Initialized
INFO - 2023-11-05 15:07:38 --> Loader Class Initialized
INFO - 2023-11-05 15:07:38 --> Helper loaded: url_helper
INFO - 2023-11-05 15:07:38 --> Helper loaded: form_helper
INFO - 2023-11-05 15:07:38 --> Helper loaded: file_helper
INFO - 2023-11-05 15:07:38 --> Database Driver Class Initialized
DEBUG - 2023-11-05 15:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 15:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 15:07:38 --> Form Validation Class Initialized
INFO - 2023-11-05 15:07:38 --> Upload Class Initialized
INFO - 2023-11-05 15:07:38 --> Model "M_auth" initialized
INFO - 2023-11-05 15:07:38 --> Model "M_user" initialized
INFO - 2023-11-05 15:07:38 --> Model "M_produk" initialized
INFO - 2023-11-05 15:07:38 --> Controller Class Initialized
INFO - 2023-11-05 15:07:38 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-05 15:07:38 --> Final output sent to browser
DEBUG - 2023-11-05 15:07:38 --> Total execution time: 0.0280
ERROR - 2023-11-05 18:50:38 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-05 18:50:38 --> Config Class Initialized
INFO - 2023-11-05 18:50:38 --> Hooks Class Initialized
DEBUG - 2023-11-05 18:50:38 --> UTF-8 Support Enabled
INFO - 2023-11-05 18:50:38 --> Utf8 Class Initialized
INFO - 2023-11-05 18:50:38 --> URI Class Initialized
DEBUG - 2023-11-05 18:50:38 --> No URI present. Default controller set.
INFO - 2023-11-05 18:50:38 --> Router Class Initialized
INFO - 2023-11-05 18:50:38 --> Output Class Initialized
INFO - 2023-11-05 18:50:38 --> Security Class Initialized
DEBUG - 2023-11-05 18:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 18:50:38 --> Input Class Initialized
INFO - 2023-11-05 18:50:38 --> Language Class Initialized
INFO - 2023-11-05 18:50:38 --> Loader Class Initialized
INFO - 2023-11-05 18:50:38 --> Helper loaded: url_helper
INFO - 2023-11-05 18:50:38 --> Helper loaded: form_helper
INFO - 2023-11-05 18:50:38 --> Helper loaded: file_helper
INFO - 2023-11-05 18:50:38 --> Database Driver Class Initialized
DEBUG - 2023-11-05 18:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 18:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 18:50:38 --> Form Validation Class Initialized
INFO - 2023-11-05 18:50:38 --> Upload Class Initialized
INFO - 2023-11-05 18:50:38 --> Model "M_auth" initialized
INFO - 2023-11-05 18:50:38 --> Model "M_user" initialized
INFO - 2023-11-05 18:50:38 --> Model "M_produk" initialized
INFO - 2023-11-05 18:50:38 --> Controller Class Initialized
INFO - 2023-11-05 18:50:38 --> Model "M_pelanggan" initialized
INFO - 2023-11-05 18:50:38 --> Model "M_produk" initialized
DEBUG - 2023-11-05 18:50:38 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 18:50:38 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:50:38 --> Model "M_transaksi" initialized
INFO - 2023-11-05 18:50:38 --> Model "M_bank" initialized
INFO - 2023-11-05 18:50:38 --> Model "M_pesan" initialized
DEBUG - 2023-11-05 18:50:38 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-05 18:50:38 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-05 18:50:38 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-05 18:50:38 --> Final output sent to browser
DEBUG - 2023-11-05 18:50:38 --> Total execution time: 0.0403
ERROR - 2023-11-05 18:58:08 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-05 18:58:08 --> Config Class Initialized
INFO - 2023-11-05 18:58:08 --> Hooks Class Initialized
DEBUG - 2023-11-05 18:58:08 --> UTF-8 Support Enabled
INFO - 2023-11-05 18:58:08 --> Utf8 Class Initialized
INFO - 2023-11-05 18:58:08 --> URI Class Initialized
DEBUG - 2023-11-05 18:58:08 --> No URI present. Default controller set.
INFO - 2023-11-05 18:58:08 --> Router Class Initialized
INFO - 2023-11-05 18:58:08 --> Output Class Initialized
INFO - 2023-11-05 18:58:08 --> Security Class Initialized
DEBUG - 2023-11-05 18:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 18:58:08 --> Input Class Initialized
INFO - 2023-11-05 18:58:08 --> Language Class Initialized
INFO - 2023-11-05 18:58:08 --> Loader Class Initialized
INFO - 2023-11-05 18:58:08 --> Helper loaded: url_helper
INFO - 2023-11-05 18:58:08 --> Helper loaded: form_helper
INFO - 2023-11-05 18:58:08 --> Helper loaded: file_helper
INFO - 2023-11-05 18:58:08 --> Database Driver Class Initialized
DEBUG - 2023-11-05 18:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 18:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 18:58:08 --> Form Validation Class Initialized
INFO - 2023-11-05 18:58:08 --> Upload Class Initialized
INFO - 2023-11-05 18:58:08 --> Model "M_auth" initialized
INFO - 2023-11-05 18:58:08 --> Model "M_user" initialized
INFO - 2023-11-05 18:58:08 --> Model "M_produk" initialized
INFO - 2023-11-05 18:58:08 --> Controller Class Initialized
INFO - 2023-11-05 18:58:08 --> Model "M_pelanggan" initialized
INFO - 2023-11-05 18:58:08 --> Model "M_produk" initialized
DEBUG - 2023-11-05 18:58:08 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-05 18:58:08 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-05 18:58:08 --> Model "M_transaksi" initialized
INFO - 2023-11-05 18:58:08 --> Model "M_bank" initialized
INFO - 2023-11-05 18:58:08 --> Model "M_pesan" initialized
DEBUG - 2023-11-05 18:58:08 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-05 18:58:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-05 18:58:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-05 18:58:08 --> Final output sent to browser
DEBUG - 2023-11-05 18:58:08 --> Total execution time: 0.0323
ERROR - 2023-11-05 18:58:12 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-05 18:58:12 --> Config Class Initialized
INFO - 2023-11-05 18:58:12 --> Hooks Class Initialized
DEBUG - 2023-11-05 18:58:12 --> UTF-8 Support Enabled
INFO - 2023-11-05 18:58:12 --> Utf8 Class Initialized
INFO - 2023-11-05 18:58:12 --> URI Class Initialized
INFO - 2023-11-05 18:58:12 --> Router Class Initialized
INFO - 2023-11-05 18:58:12 --> Output Class Initialized
INFO - 2023-11-05 18:58:12 --> Security Class Initialized
DEBUG - 2023-11-05 18:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 18:58:12 --> Input Class Initialized
INFO - 2023-11-05 18:58:12 --> Language Class Initialized
INFO - 2023-11-05 18:58:12 --> Loader Class Initialized
INFO - 2023-11-05 18:58:12 --> Helper loaded: url_helper
INFO - 2023-11-05 18:58:12 --> Helper loaded: form_helper
INFO - 2023-11-05 18:58:12 --> Helper loaded: file_helper
INFO - 2023-11-05 18:58:12 --> Database Driver Class Initialized
DEBUG - 2023-11-05 18:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 18:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 18:58:12 --> Form Validation Class Initialized
INFO - 2023-11-05 18:58:12 --> Upload Class Initialized
INFO - 2023-11-05 18:58:12 --> Model "M_auth" initialized
INFO - 2023-11-05 18:58:12 --> Model "M_user" initialized
INFO - 2023-11-05 18:58:12 --> Model "M_produk" initialized
INFO - 2023-11-05 18:58:12 --> Controller Class Initialized
INFO - 2023-11-05 18:58:12 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-05 18:58:12 --> Final output sent to browser
DEBUG - 2023-11-05 18:58:12 --> Total execution time: 0.0026
ERROR - 2023-11-05 18:58:15 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-05 18:58:15 --> Config Class Initialized
INFO - 2023-11-05 18:58:15 --> Hooks Class Initialized
DEBUG - 2023-11-05 18:58:15 --> UTF-8 Support Enabled
INFO - 2023-11-05 18:58:15 --> Utf8 Class Initialized
INFO - 2023-11-05 18:58:15 --> URI Class Initialized
INFO - 2023-11-05 18:58:15 --> Router Class Initialized
INFO - 2023-11-05 18:58:15 --> Output Class Initialized
INFO - 2023-11-05 18:58:15 --> Security Class Initialized
DEBUG - 2023-11-05 18:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-05 18:58:15 --> Input Class Initialized
INFO - 2023-11-05 18:58:15 --> Language Class Initialized
INFO - 2023-11-05 18:58:15 --> Loader Class Initialized
INFO - 2023-11-05 18:58:15 --> Helper loaded: url_helper
INFO - 2023-11-05 18:58:15 --> Helper loaded: form_helper
INFO - 2023-11-05 18:58:15 --> Helper loaded: file_helper
INFO - 2023-11-05 18:58:15 --> Database Driver Class Initialized
DEBUG - 2023-11-05 18:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-05 18:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-05 18:58:15 --> Form Validation Class Initialized
INFO - 2023-11-05 18:58:15 --> Upload Class Initialized
INFO - 2023-11-05 18:58:15 --> Model "M_auth" initialized
INFO - 2023-11-05 18:58:15 --> Model "M_user" initialized
INFO - 2023-11-05 18:58:15 --> Model "M_produk" initialized
INFO - 2023-11-05 18:58:15 --> Controller Class Initialized
INFO - 2023-11-05 18:58:15 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-05 18:58:15 --> Final output sent to browser
DEBUG - 2023-11-05 18:58:15 --> Total execution time: 0.0025
