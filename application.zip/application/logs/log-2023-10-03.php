<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-10-03 13:04:07 --> Config Class Initialized
INFO - 2023-10-03 13:04:07 --> Hooks Class Initialized
DEBUG - 2023-10-03 13:04:07 --> UTF-8 Support Enabled
INFO - 2023-10-03 13:04:07 --> Utf8 Class Initialized
INFO - 2023-10-03 13:04:07 --> URI Class Initialized
DEBUG - 2023-10-03 13:04:07 --> No URI present. Default controller set.
INFO - 2023-10-03 13:04:07 --> Router Class Initialized
INFO - 2023-10-03 13:04:07 --> Output Class Initialized
INFO - 2023-10-03 13:04:07 --> Security Class Initialized
DEBUG - 2023-10-03 13:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-03 13:04:07 --> Input Class Initialized
INFO - 2023-10-03 13:04:07 --> Language Class Initialized
INFO - 2023-10-03 13:04:07 --> Loader Class Initialized
INFO - 2023-10-03 13:04:07 --> Helper loaded: url_helper
INFO - 2023-10-03 13:04:07 --> Helper loaded: form_helper
INFO - 2023-10-03 13:04:07 --> Helper loaded: file_helper
INFO - 2023-10-03 13:04:07 --> Database Driver Class Initialized
ERROR - 2023-10-03 13:04:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'aan_1' C:\xampp\htdocs\4_aan\semakar_adventure\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-10-03 13:04:07 --> Unable to connect to the database
INFO - 2023-10-03 13:04:07 --> Language file loaded: language/english/db_lang.php
INFO - 2023-10-03 13:08:20 --> Config Class Initialized
INFO - 2023-10-03 13:08:20 --> Hooks Class Initialized
DEBUG - 2023-10-03 13:08:20 --> UTF-8 Support Enabled
INFO - 2023-10-03 13:08:20 --> Utf8 Class Initialized
INFO - 2023-10-03 13:08:20 --> URI Class Initialized
DEBUG - 2023-10-03 13:08:20 --> No URI present. Default controller set.
INFO - 2023-10-03 13:08:20 --> Router Class Initialized
INFO - 2023-10-03 13:08:20 --> Output Class Initialized
INFO - 2023-10-03 13:08:20 --> Security Class Initialized
DEBUG - 2023-10-03 13:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-03 13:08:20 --> Input Class Initialized
INFO - 2023-10-03 13:08:20 --> Language Class Initialized
INFO - 2023-10-03 13:08:20 --> Loader Class Initialized
INFO - 2023-10-03 13:08:20 --> Helper loaded: url_helper
INFO - 2023-10-03 13:08:20 --> Helper loaded: form_helper
INFO - 2023-10-03 13:08:20 --> Helper loaded: file_helper
INFO - 2023-10-03 13:08:20 --> Database Driver Class Initialized
DEBUG - 2023-10-03 13:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-03 13:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-03 13:08:20 --> Form Validation Class Initialized
INFO - 2023-10-03 13:08:20 --> Upload Class Initialized
INFO - 2023-10-03 13:08:20 --> Model "M_auth" initialized
INFO - 2023-10-03 13:08:21 --> Model "M_user" initialized
INFO - 2023-10-03 13:08:21 --> Model "M_produk" initialized
INFO - 2023-10-03 13:08:21 --> Controller Class Initialized
INFO - 2023-10-03 13:08:21 --> Model "M_pelanggan" initialized
INFO - 2023-10-03 13:08:21 --> Model "M_produk" initialized
DEBUG - 2023-10-03 13:08:21 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-03 13:08:21 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-03 13:08:21 --> Model "M_transaksi" initialized
INFO - 2023-10-03 13:08:21 --> Model "M_bank" initialized
INFO - 2023-10-03 13:08:21 --> Model "M_pesan" initialized
INFO - 2023-10-03 13:08:21 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-03 13:08:21 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-03 13:08:21 --> Final output sent to browser
DEBUG - 2023-10-03 13:08:21 --> Total execution time: 0.9249
INFO - 2023-10-03 13:08:54 --> Config Class Initialized
INFO - 2023-10-03 13:08:54 --> Hooks Class Initialized
DEBUG - 2023-10-03 13:08:54 --> UTF-8 Support Enabled
INFO - 2023-10-03 13:08:54 --> Utf8 Class Initialized
INFO - 2023-10-03 13:08:54 --> URI Class Initialized
INFO - 2023-10-03 13:08:54 --> Router Class Initialized
INFO - 2023-10-03 13:08:54 --> Output Class Initialized
INFO - 2023-10-03 13:08:54 --> Security Class Initialized
DEBUG - 2023-10-03 13:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-03 13:08:54 --> Input Class Initialized
INFO - 2023-10-03 13:08:54 --> Language Class Initialized
INFO - 2023-10-03 13:08:54 --> Loader Class Initialized
INFO - 2023-10-03 13:08:54 --> Helper loaded: url_helper
INFO - 2023-10-03 13:08:54 --> Helper loaded: form_helper
INFO - 2023-10-03 13:08:54 --> Helper loaded: file_helper
INFO - 2023-10-03 13:08:54 --> Database Driver Class Initialized
DEBUG - 2023-10-03 13:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-03 13:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-03 13:08:54 --> Form Validation Class Initialized
INFO - 2023-10-03 13:08:54 --> Upload Class Initialized
INFO - 2023-10-03 13:08:54 --> Model "M_auth" initialized
INFO - 2023-10-03 13:08:54 --> Model "M_user" initialized
INFO - 2023-10-03 13:08:54 --> Model "M_produk" initialized
INFO - 2023-10-03 13:08:54 --> Controller Class Initialized
INFO - 2023-10-03 13:08:54 --> Model "M_pelanggan" initialized
INFO - 2023-10-03 13:08:54 --> Model "M_produk" initialized
DEBUG - 2023-10-03 13:08:54 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-03 13:08:54 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-03 13:08:54 --> Model "M_transaksi" initialized
INFO - 2023-10-03 13:08:54 --> Model "M_bank" initialized
INFO - 2023-10-03 13:08:54 --> Model "M_pesan" initialized
INFO - 2023-10-03 13:08:54 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-03 13:08:54 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_produk_detail.php
INFO - 2023-10-03 13:08:54 --> Final output sent to browser
DEBUG - 2023-10-03 13:08:54 --> Total execution time: 0.1014
INFO - 2023-10-03 13:10:03 --> Config Class Initialized
INFO - 2023-10-03 13:10:03 --> Hooks Class Initialized
DEBUG - 2023-10-03 13:10:03 --> UTF-8 Support Enabled
INFO - 2023-10-03 13:10:03 --> Utf8 Class Initialized
INFO - 2023-10-03 13:10:03 --> URI Class Initialized
INFO - 2023-10-03 13:10:03 --> Router Class Initialized
INFO - 2023-10-03 13:10:03 --> Output Class Initialized
INFO - 2023-10-03 13:10:03 --> Security Class Initialized
DEBUG - 2023-10-03 13:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-03 13:10:03 --> Input Class Initialized
INFO - 2023-10-03 13:10:03 --> Language Class Initialized
INFO - 2023-10-03 13:10:03 --> Loader Class Initialized
INFO - 2023-10-03 13:10:03 --> Helper loaded: url_helper
INFO - 2023-10-03 13:10:03 --> Helper loaded: form_helper
INFO - 2023-10-03 13:10:03 --> Helper loaded: file_helper
INFO - 2023-10-03 13:10:03 --> Database Driver Class Initialized
DEBUG - 2023-10-03 13:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-03 13:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-03 13:10:03 --> Form Validation Class Initialized
INFO - 2023-10-03 13:10:03 --> Upload Class Initialized
INFO - 2023-10-03 13:10:03 --> Model "M_auth" initialized
INFO - 2023-10-03 13:10:03 --> Model "M_user" initialized
INFO - 2023-10-03 13:10:03 --> Model "M_produk" initialized
INFO - 2023-10-03 13:10:03 --> Controller Class Initialized
INFO - 2023-10-03 13:10:03 --> Model "M_pelanggan" initialized
INFO - 2023-10-03 13:10:03 --> Model "M_produk" initialized
DEBUG - 2023-10-03 13:10:03 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-03 13:10:03 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-03 13:10:03 --> Model "M_transaksi" initialized
INFO - 2023-10-03 13:10:03 --> Model "M_bank" initialized
INFO - 2023-10-03 13:10:03 --> Model "M_pesan" initialized
INFO - 2023-10-03 13:10:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-10-03 13:10:03 --> Email Class Initialized
INFO - 2023-10-03 13:10:04 --> Language file loaded: language/english/email_lang.php
INFO - 2023-10-03 13:10:07 --> Config Class Initialized
INFO - 2023-10-03 13:10:07 --> Hooks Class Initialized
DEBUG - 2023-10-03 13:10:07 --> UTF-8 Support Enabled
INFO - 2023-10-03 13:10:07 --> Utf8 Class Initialized
INFO - 2023-10-03 13:10:07 --> URI Class Initialized
DEBUG - 2023-10-03 13:10:07 --> No URI present. Default controller set.
INFO - 2023-10-03 13:10:07 --> Router Class Initialized
INFO - 2023-10-03 13:10:07 --> Output Class Initialized
INFO - 2023-10-03 13:10:07 --> Security Class Initialized
DEBUG - 2023-10-03 13:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-03 13:10:07 --> Input Class Initialized
INFO - 2023-10-03 13:10:07 --> Language Class Initialized
INFO - 2023-10-03 13:10:07 --> Loader Class Initialized
INFO - 2023-10-03 13:10:07 --> Helper loaded: url_helper
INFO - 2023-10-03 13:10:07 --> Helper loaded: form_helper
INFO - 2023-10-03 13:10:07 --> Helper loaded: file_helper
INFO - 2023-10-03 13:10:07 --> Database Driver Class Initialized
DEBUG - 2023-10-03 13:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-03 13:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-03 13:10:07 --> Form Validation Class Initialized
INFO - 2023-10-03 13:10:07 --> Upload Class Initialized
INFO - 2023-10-03 13:10:07 --> Model "M_auth" initialized
INFO - 2023-10-03 13:10:07 --> Model "M_user" initialized
INFO - 2023-10-03 13:10:07 --> Model "M_produk" initialized
INFO - 2023-10-03 13:10:07 --> Controller Class Initialized
INFO - 2023-10-03 13:10:07 --> Model "M_pelanggan" initialized
INFO - 2023-10-03 13:10:07 --> Model "M_produk" initialized
DEBUG - 2023-10-03 13:10:07 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-03 13:10:07 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-03 13:10:07 --> Model "M_transaksi" initialized
INFO - 2023-10-03 13:10:07 --> Model "M_bank" initialized
INFO - 2023-10-03 13:10:07 --> Model "M_pesan" initialized
INFO - 2023-10-03 13:10:07 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-03 13:10:07 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-03 13:10:07 --> Final output sent to browser
DEBUG - 2023-10-03 13:10:07 --> Total execution time: 0.0329
