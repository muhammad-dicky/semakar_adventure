<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-07-18 02:59:08 --> Config Class Initialized
INFO - 2023-07-18 02:59:08 --> Hooks Class Initialized
DEBUG - 2023-07-18 02:59:08 --> UTF-8 Support Enabled
INFO - 2023-07-18 02:59:08 --> Utf8 Class Initialized
INFO - 2023-07-18 02:59:08 --> URI Class Initialized
DEBUG - 2023-07-18 02:59:08 --> No URI present. Default controller set.
INFO - 2023-07-18 02:59:08 --> Router Class Initialized
INFO - 2023-07-18 02:59:08 --> Output Class Initialized
INFO - 2023-07-18 02:59:08 --> Security Class Initialized
DEBUG - 2023-07-18 02:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-18 02:59:09 --> Input Class Initialized
INFO - 2023-07-18 02:59:09 --> Language Class Initialized
INFO - 2023-07-18 02:59:09 --> Loader Class Initialized
INFO - 2023-07-18 02:59:09 --> Helper loaded: url_helper
INFO - 2023-07-18 02:59:09 --> Helper loaded: form_helper
INFO - 2023-07-18 02:59:09 --> Helper loaded: file_helper
INFO - 2023-07-18 02:59:09 --> Database Driver Class Initialized
DEBUG - 2023-07-18 02:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-18 02:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-18 02:59:10 --> Form Validation Class Initialized
INFO - 2023-07-18 02:59:10 --> Upload Class Initialized
INFO - 2023-07-18 02:59:10 --> Model "M_auth" initialized
INFO - 2023-07-18 02:59:10 --> Model "M_user" initialized
INFO - 2023-07-18 02:59:10 --> Model "M_produk" initialized
INFO - 2023-07-18 02:59:10 --> Controller Class Initialized
INFO - 2023-07-18 02:59:10 --> Model "M_pelanggan" initialized
INFO - 2023-07-18 02:59:10 --> Model "M_produk" initialized
DEBUG - 2023-07-18 02:59:10 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-07-18 02:59:10 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-07-18 02:59:10 --> Model "M_transaksi" initialized
INFO - 2023-07-18 02:59:10 --> Model "M_bank" initialized
INFO - 2023-07-18 02:59:10 --> Model "M_pesan" initialized
ERROR - 2023-07-18 02:59:10 --> Query error: Table 'aan_1.tbl_produk' doesn't exist in engine - Invalid query: SELECT *
FROM `tbl_produk`
LEFT JOIN `tbl_type` ON `tbl_type`.`id_type` = `tbl_produk`.`id_type`
LEFT JOIN `tbl_merek` ON `tbl_merek`.`id_merek` = `tbl_produk`.`id_merek`
ORDER BY `tbl_produk`.`id_produk` DESC
 LIMIT 9
INFO - 2023-07-18 02:59:10 --> Language file loaded: language/english/db_lang.php
