<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-10-11 10:25:12 --> Config Class Initialized
INFO - 2023-10-11 10:25:12 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:25:12 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:25:12 --> Utf8 Class Initialized
INFO - 2023-10-11 10:25:12 --> URI Class Initialized
DEBUG - 2023-10-11 10:25:12 --> No URI present. Default controller set.
INFO - 2023-10-11 10:25:12 --> Router Class Initialized
INFO - 2023-10-11 10:25:12 --> Output Class Initialized
INFO - 2023-10-11 10:25:12 --> Security Class Initialized
DEBUG - 2023-10-11 10:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:25:12 --> Input Class Initialized
INFO - 2023-10-11 10:25:12 --> Language Class Initialized
INFO - 2023-10-11 10:25:12 --> Loader Class Initialized
INFO - 2023-10-11 10:25:12 --> Helper loaded: url_helper
INFO - 2023-10-11 10:25:12 --> Helper loaded: form_helper
INFO - 2023-10-11 10:25:12 --> Helper loaded: file_helper
INFO - 2023-10-11 10:25:12 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:25:12 --> Form Validation Class Initialized
INFO - 2023-10-11 10:25:12 --> Upload Class Initialized
INFO - 2023-10-11 10:25:12 --> Model "M_auth" initialized
INFO - 2023-10-11 10:25:12 --> Model "M_user" initialized
INFO - 2023-10-11 10:25:12 --> Model "M_produk" initialized
INFO - 2023-10-11 10:25:12 --> Controller Class Initialized
INFO - 2023-10-11 10:25:12 --> Model "M_pelanggan" initialized
INFO - 2023-10-11 10:25:12 --> Model "M_produk" initialized
DEBUG - 2023-10-11 10:25:12 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-11 10:25:12 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-11 10:25:12 --> Model "M_transaksi" initialized
INFO - 2023-10-11 10:25:12 --> Model "M_bank" initialized
INFO - 2023-10-11 10:25:12 --> Model "M_pesan" initialized
INFO - 2023-10-11 10:25:12 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-11 10:25:12 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-11 10:25:12 --> Final output sent to browser
DEBUG - 2023-10-11 10:25:12 --> Total execution time: 0.0587
INFO - 2023-10-11 10:25:19 --> Config Class Initialized
INFO - 2023-10-11 10:25:19 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:25:19 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:25:19 --> Utf8 Class Initialized
INFO - 2023-10-11 10:25:19 --> URI Class Initialized
INFO - 2023-10-11 10:25:19 --> Router Class Initialized
INFO - 2023-10-11 10:25:19 --> Output Class Initialized
INFO - 2023-10-11 10:25:19 --> Security Class Initialized
DEBUG - 2023-10-11 10:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:25:19 --> Input Class Initialized
INFO - 2023-10-11 10:25:19 --> Language Class Initialized
INFO - 2023-10-11 10:25:19 --> Loader Class Initialized
INFO - 2023-10-11 10:25:19 --> Helper loaded: url_helper
INFO - 2023-10-11 10:25:19 --> Helper loaded: form_helper
INFO - 2023-10-11 10:25:19 --> Helper loaded: file_helper
INFO - 2023-10-11 10:25:19 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:25:19 --> Form Validation Class Initialized
INFO - 2023-10-11 10:25:19 --> Upload Class Initialized
INFO - 2023-10-11 10:25:19 --> Model "M_auth" initialized
INFO - 2023-10-11 10:25:19 --> Model "M_user" initialized
INFO - 2023-10-11 10:25:19 --> Model "M_produk" initialized
INFO - 2023-10-11 10:25:19 --> Controller Class Initialized
INFO - 2023-10-11 10:25:19 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-10-11 10:25:19 --> Final output sent to browser
DEBUG - 2023-10-11 10:25:19 --> Total execution time: 0.0379
INFO - 2023-10-11 10:25:33 --> Config Class Initialized
INFO - 2023-10-11 10:25:33 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:25:33 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:25:33 --> Utf8 Class Initialized
INFO - 2023-10-11 10:25:33 --> URI Class Initialized
INFO - 2023-10-11 10:25:33 --> Router Class Initialized
INFO - 2023-10-11 10:25:33 --> Output Class Initialized
INFO - 2023-10-11 10:25:33 --> Security Class Initialized
DEBUG - 2023-10-11 10:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:25:33 --> Input Class Initialized
INFO - 2023-10-11 10:25:33 --> Language Class Initialized
INFO - 2023-10-11 10:25:33 --> Loader Class Initialized
INFO - 2023-10-11 10:25:33 --> Helper loaded: url_helper
INFO - 2023-10-11 10:25:33 --> Helper loaded: form_helper
INFO - 2023-10-11 10:25:33 --> Helper loaded: file_helper
INFO - 2023-10-11 10:25:33 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:25:33 --> Form Validation Class Initialized
INFO - 2023-10-11 10:25:33 --> Upload Class Initialized
INFO - 2023-10-11 10:25:33 --> Model "M_auth" initialized
INFO - 2023-10-11 10:25:33 --> Model "M_user" initialized
INFO - 2023-10-11 10:25:33 --> Model "M_produk" initialized
INFO - 2023-10-11 10:25:33 --> Controller Class Initialized
INFO - 2023-10-11 10:25:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-10-11 10:25:33 --> Config Class Initialized
INFO - 2023-10-11 10:25:33 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:25:33 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:25:33 --> Utf8 Class Initialized
INFO - 2023-10-11 10:25:33 --> URI Class Initialized
INFO - 2023-10-11 10:25:33 --> Router Class Initialized
INFO - 2023-10-11 10:25:33 --> Output Class Initialized
INFO - 2023-10-11 10:25:33 --> Security Class Initialized
DEBUG - 2023-10-11 10:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:25:33 --> Input Class Initialized
INFO - 2023-10-11 10:25:33 --> Language Class Initialized
INFO - 2023-10-11 10:25:33 --> Loader Class Initialized
INFO - 2023-10-11 10:25:33 --> Helper loaded: url_helper
INFO - 2023-10-11 10:25:33 --> Helper loaded: form_helper
INFO - 2023-10-11 10:25:33 --> Helper loaded: file_helper
INFO - 2023-10-11 10:25:33 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:25:33 --> Form Validation Class Initialized
INFO - 2023-10-11 10:25:33 --> Upload Class Initialized
INFO - 2023-10-11 10:25:33 --> Model "M_auth" initialized
INFO - 2023-10-11 10:25:33 --> Model "M_user" initialized
INFO - 2023-10-11 10:25:33 --> Model "M_produk" initialized
INFO - 2023-10-11 10:25:33 --> Controller Class Initialized
INFO - 2023-10-11 10:25:33 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-10-11 10:25:33 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-11 10:25:33 --> Final output sent to browser
DEBUG - 2023-10-11 10:25:33 --> Total execution time: 0.0909
INFO - 2023-10-11 10:25:39 --> Config Class Initialized
INFO - 2023-10-11 10:25:39 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:25:39 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:25:39 --> Utf8 Class Initialized
INFO - 2023-10-11 10:25:39 --> URI Class Initialized
INFO - 2023-10-11 10:25:39 --> Router Class Initialized
INFO - 2023-10-11 10:25:39 --> Output Class Initialized
INFO - 2023-10-11 10:25:39 --> Security Class Initialized
DEBUG - 2023-10-11 10:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:25:39 --> Input Class Initialized
INFO - 2023-10-11 10:25:39 --> Language Class Initialized
INFO - 2023-10-11 10:25:39 --> Loader Class Initialized
INFO - 2023-10-11 10:25:39 --> Helper loaded: url_helper
INFO - 2023-10-11 10:25:39 --> Helper loaded: form_helper
INFO - 2023-10-11 10:25:39 --> Helper loaded: file_helper
INFO - 2023-10-11 10:25:39 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:25:39 --> Form Validation Class Initialized
INFO - 2023-10-11 10:25:39 --> Upload Class Initialized
INFO - 2023-10-11 10:25:39 --> Model "M_auth" initialized
INFO - 2023-10-11 10:25:39 --> Model "M_user" initialized
INFO - 2023-10-11 10:25:39 --> Model "M_produk" initialized
INFO - 2023-10-11 10:25:39 --> Controller Class Initialized
INFO - 2023-10-11 10:25:39 --> Model "M_produk" initialized
INFO - 2023-10-11 10:25:39 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-10-11 10:25:39 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-11 10:25:39 --> Final output sent to browser
DEBUG - 2023-10-11 10:25:39 --> Total execution time: 0.0542
INFO - 2023-10-11 10:27:48 --> Config Class Initialized
INFO - 2023-10-11 10:27:48 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:27:48 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:27:48 --> Utf8 Class Initialized
INFO - 2023-10-11 10:27:48 --> URI Class Initialized
INFO - 2023-10-11 10:27:48 --> Router Class Initialized
INFO - 2023-10-11 10:27:48 --> Output Class Initialized
INFO - 2023-10-11 10:27:48 --> Security Class Initialized
DEBUG - 2023-10-11 10:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:27:48 --> Input Class Initialized
INFO - 2023-10-11 10:27:48 --> Language Class Initialized
INFO - 2023-10-11 10:27:48 --> Loader Class Initialized
INFO - 2023-10-11 10:27:48 --> Helper loaded: url_helper
INFO - 2023-10-11 10:27:48 --> Helper loaded: form_helper
INFO - 2023-10-11 10:27:48 --> Helper loaded: file_helper
INFO - 2023-10-11 10:27:48 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:27:48 --> Form Validation Class Initialized
INFO - 2023-10-11 10:27:48 --> Upload Class Initialized
INFO - 2023-10-11 10:27:48 --> Model "M_auth" initialized
INFO - 2023-10-11 10:27:48 --> Model "M_user" initialized
INFO - 2023-10-11 10:27:48 --> Model "M_produk" initialized
INFO - 2023-10-11 10:27:48 --> Controller Class Initialized
INFO - 2023-10-11 10:27:48 --> Model "M_produk" initialized
INFO - 2023-10-11 10:27:48 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-10-11 10:27:48 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-11 10:27:48 --> Final output sent to browser
DEBUG - 2023-10-11 10:27:48 --> Total execution time: 0.0251
INFO - 2023-10-11 10:27:53 --> Config Class Initialized
INFO - 2023-10-11 10:27:53 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:27:53 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:27:53 --> Utf8 Class Initialized
INFO - 2023-10-11 10:27:53 --> URI Class Initialized
INFO - 2023-10-11 10:27:53 --> Router Class Initialized
INFO - 2023-10-11 10:27:53 --> Output Class Initialized
INFO - 2023-10-11 10:27:53 --> Security Class Initialized
DEBUG - 2023-10-11 10:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:27:53 --> Input Class Initialized
INFO - 2023-10-11 10:27:53 --> Language Class Initialized
INFO - 2023-10-11 10:27:53 --> Loader Class Initialized
INFO - 2023-10-11 10:27:53 --> Helper loaded: url_helper
INFO - 2023-10-11 10:27:53 --> Helper loaded: form_helper
INFO - 2023-10-11 10:27:53 --> Helper loaded: file_helper
INFO - 2023-10-11 10:27:53 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:27:53 --> Form Validation Class Initialized
INFO - 2023-10-11 10:27:53 --> Upload Class Initialized
INFO - 2023-10-11 10:27:53 --> Model "M_auth" initialized
INFO - 2023-10-11 10:27:53 --> Model "M_user" initialized
INFO - 2023-10-11 10:27:53 --> Model "M_produk" initialized
INFO - 2023-10-11 10:27:53 --> Controller Class Initialized
INFO - 2023-10-11 10:27:53 --> Model "M_produk" initialized
INFO - 2023-10-11 10:27:53 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_add_produk.php
INFO - 2023-10-11 10:27:53 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-11 10:27:53 --> Final output sent to browser
DEBUG - 2023-10-11 10:27:53 --> Total execution time: 0.0263
INFO - 2023-10-11 10:27:56 --> Config Class Initialized
INFO - 2023-10-11 10:27:56 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:27:56 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:27:56 --> Utf8 Class Initialized
INFO - 2023-10-11 10:27:56 --> URI Class Initialized
INFO - 2023-10-11 10:27:56 --> Router Class Initialized
INFO - 2023-10-11 10:27:56 --> Output Class Initialized
INFO - 2023-10-11 10:27:56 --> Security Class Initialized
DEBUG - 2023-10-11 10:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:27:56 --> Input Class Initialized
INFO - 2023-10-11 10:27:56 --> Language Class Initialized
INFO - 2023-10-11 10:27:56 --> Loader Class Initialized
INFO - 2023-10-11 10:27:56 --> Helper loaded: url_helper
INFO - 2023-10-11 10:27:56 --> Helper loaded: form_helper
INFO - 2023-10-11 10:27:56 --> Helper loaded: file_helper
INFO - 2023-10-11 10:27:56 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:27:56 --> Form Validation Class Initialized
INFO - 2023-10-11 10:27:56 --> Upload Class Initialized
INFO - 2023-10-11 10:27:56 --> Model "M_auth" initialized
INFO - 2023-10-11 10:27:56 --> Model "M_user" initialized
INFO - 2023-10-11 10:27:56 --> Model "M_produk" initialized
INFO - 2023-10-11 10:27:56 --> Controller Class Initialized
INFO - 2023-10-11 10:27:56 --> Model "M_produk" initialized
INFO - 2023-10-11 10:27:56 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-10-11 10:27:56 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-11 10:27:56 --> Final output sent to browser
DEBUG - 2023-10-11 10:27:56 --> Total execution time: 0.0254
INFO - 2023-10-11 10:27:58 --> Config Class Initialized
INFO - 2023-10-11 10:27:58 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:27:58 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:27:58 --> Utf8 Class Initialized
INFO - 2023-10-11 10:27:58 --> URI Class Initialized
INFO - 2023-10-11 10:27:58 --> Router Class Initialized
INFO - 2023-10-11 10:27:58 --> Output Class Initialized
INFO - 2023-10-11 10:27:58 --> Security Class Initialized
DEBUG - 2023-10-11 10:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:27:58 --> Input Class Initialized
INFO - 2023-10-11 10:27:58 --> Language Class Initialized
INFO - 2023-10-11 10:27:58 --> Loader Class Initialized
INFO - 2023-10-11 10:27:58 --> Helper loaded: url_helper
INFO - 2023-10-11 10:27:58 --> Helper loaded: form_helper
INFO - 2023-10-11 10:27:58 --> Helper loaded: file_helper
INFO - 2023-10-11 10:27:58 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:27:58 --> Form Validation Class Initialized
INFO - 2023-10-11 10:27:58 --> Upload Class Initialized
INFO - 2023-10-11 10:27:58 --> Model "M_auth" initialized
INFO - 2023-10-11 10:27:58 --> Model "M_user" initialized
INFO - 2023-10-11 10:27:58 --> Model "M_produk" initialized
INFO - 2023-10-11 10:27:58 --> Controller Class Initialized
INFO - 2023-10-11 10:27:58 --> Model "M_produk" initialized
INFO - 2023-10-11 10:27:58 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_edit_produk.php
INFO - 2023-10-11 10:27:58 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-11 10:27:58 --> Final output sent to browser
DEBUG - 2023-10-11 10:27:58 --> Total execution time: 0.0238
INFO - 2023-10-11 10:28:38 --> Config Class Initialized
INFO - 2023-10-11 10:28:38 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:28:38 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:28:38 --> Utf8 Class Initialized
INFO - 2023-10-11 10:28:38 --> URI Class Initialized
INFO - 2023-10-11 10:28:38 --> Router Class Initialized
INFO - 2023-10-11 10:28:38 --> Output Class Initialized
INFO - 2023-10-11 10:28:38 --> Security Class Initialized
DEBUG - 2023-10-11 10:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:28:38 --> Input Class Initialized
INFO - 2023-10-11 10:28:38 --> Language Class Initialized
INFO - 2023-10-11 10:28:38 --> Loader Class Initialized
INFO - 2023-10-11 10:28:38 --> Helper loaded: url_helper
INFO - 2023-10-11 10:28:38 --> Helper loaded: form_helper
INFO - 2023-10-11 10:28:38 --> Helper loaded: file_helper
INFO - 2023-10-11 10:28:38 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:28:38 --> Form Validation Class Initialized
INFO - 2023-10-11 10:28:38 --> Upload Class Initialized
INFO - 2023-10-11 10:28:38 --> Model "M_auth" initialized
INFO - 2023-10-11 10:28:38 --> Model "M_user" initialized
INFO - 2023-10-11 10:28:38 --> Model "M_produk" initialized
INFO - 2023-10-11 10:28:38 --> Controller Class Initialized
INFO - 2023-10-11 10:28:38 --> Model "M_produk" initialized
INFO - 2023-10-11 10:28:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-10-11 10:28:38 --> Config Class Initialized
INFO - 2023-10-11 10:28:38 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:28:38 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:28:38 --> Utf8 Class Initialized
INFO - 2023-10-11 10:28:38 --> URI Class Initialized
INFO - 2023-10-11 10:28:38 --> Router Class Initialized
INFO - 2023-10-11 10:28:38 --> Output Class Initialized
INFO - 2023-10-11 10:28:38 --> Security Class Initialized
DEBUG - 2023-10-11 10:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:28:38 --> Input Class Initialized
INFO - 2023-10-11 10:28:38 --> Language Class Initialized
INFO - 2023-10-11 10:28:38 --> Loader Class Initialized
INFO - 2023-10-11 10:28:38 --> Helper loaded: url_helper
INFO - 2023-10-11 10:28:38 --> Helper loaded: form_helper
INFO - 2023-10-11 10:28:38 --> Helper loaded: file_helper
INFO - 2023-10-11 10:28:38 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:28:38 --> Form Validation Class Initialized
INFO - 2023-10-11 10:28:38 --> Upload Class Initialized
INFO - 2023-10-11 10:28:38 --> Model "M_auth" initialized
INFO - 2023-10-11 10:28:38 --> Model "M_user" initialized
INFO - 2023-10-11 10:28:38 --> Model "M_produk" initialized
INFO - 2023-10-11 10:28:38 --> Controller Class Initialized
INFO - 2023-10-11 10:28:38 --> Model "M_produk" initialized
INFO - 2023-10-11 10:28:38 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-10-11 10:28:38 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-11 10:28:38 --> Final output sent to browser
DEBUG - 2023-10-11 10:28:38 --> Total execution time: 0.0232
INFO - 2023-10-11 10:29:06 --> Config Class Initialized
INFO - 2023-10-11 10:29:06 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:29:06 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:29:06 --> Utf8 Class Initialized
INFO - 2023-10-11 10:29:06 --> URI Class Initialized
INFO - 2023-10-11 10:29:06 --> Router Class Initialized
INFO - 2023-10-11 10:29:06 --> Output Class Initialized
INFO - 2023-10-11 10:29:06 --> Security Class Initialized
DEBUG - 2023-10-11 10:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:29:06 --> Input Class Initialized
INFO - 2023-10-11 10:29:06 --> Language Class Initialized
INFO - 2023-10-11 10:29:06 --> Loader Class Initialized
INFO - 2023-10-11 10:29:06 --> Helper loaded: url_helper
INFO - 2023-10-11 10:29:06 --> Helper loaded: form_helper
INFO - 2023-10-11 10:29:06 --> Helper loaded: file_helper
INFO - 2023-10-11 10:29:06 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:29:06 --> Form Validation Class Initialized
INFO - 2023-10-11 10:29:06 --> Upload Class Initialized
INFO - 2023-10-11 10:29:06 --> Model "M_auth" initialized
INFO - 2023-10-11 10:29:06 --> Model "M_user" initialized
INFO - 2023-10-11 10:29:06 --> Model "M_produk" initialized
INFO - 2023-10-11 10:29:06 --> Controller Class Initialized
INFO - 2023-10-11 10:29:06 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-10-11 10:29:06 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-11 10:29:06 --> Final output sent to browser
DEBUG - 2023-10-11 10:29:06 --> Total execution time: 0.0240
INFO - 2023-10-11 10:29:08 --> Config Class Initialized
INFO - 2023-10-11 10:29:08 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:29:08 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:29:08 --> Utf8 Class Initialized
INFO - 2023-10-11 10:29:08 --> URI Class Initialized
INFO - 2023-10-11 10:29:08 --> Router Class Initialized
INFO - 2023-10-11 10:29:08 --> Output Class Initialized
INFO - 2023-10-11 10:29:08 --> Security Class Initialized
DEBUG - 2023-10-11 10:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:29:08 --> Input Class Initialized
INFO - 2023-10-11 10:29:08 --> Language Class Initialized
INFO - 2023-10-11 10:29:08 --> Loader Class Initialized
INFO - 2023-10-11 10:29:08 --> Helper loaded: url_helper
INFO - 2023-10-11 10:29:08 --> Helper loaded: form_helper
INFO - 2023-10-11 10:29:08 --> Helper loaded: file_helper
INFO - 2023-10-11 10:29:08 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:29:08 --> Form Validation Class Initialized
INFO - 2023-10-11 10:29:08 --> Upload Class Initialized
INFO - 2023-10-11 10:29:08 --> Model "M_auth" initialized
INFO - 2023-10-11 10:29:08 --> Model "M_user" initialized
INFO - 2023-10-11 10:29:08 --> Model "M_produk" initialized
INFO - 2023-10-11 10:29:08 --> Controller Class Initialized
INFO - 2023-10-11 10:29:08 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-10-11 10:29:08 --> Final output sent to browser
DEBUG - 2023-10-11 10:29:08 --> Total execution time: 0.0218
INFO - 2023-10-11 10:29:10 --> Config Class Initialized
INFO - 2023-10-11 10:29:10 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:29:10 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:29:10 --> Utf8 Class Initialized
INFO - 2023-10-11 10:29:10 --> URI Class Initialized
INFO - 2023-10-11 10:29:10 --> Router Class Initialized
INFO - 2023-10-11 10:29:10 --> Output Class Initialized
INFO - 2023-10-11 10:29:10 --> Security Class Initialized
DEBUG - 2023-10-11 10:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:29:10 --> Input Class Initialized
INFO - 2023-10-11 10:29:10 --> Language Class Initialized
INFO - 2023-10-11 10:29:10 --> Loader Class Initialized
INFO - 2023-10-11 10:29:10 --> Helper loaded: url_helper
INFO - 2023-10-11 10:29:10 --> Helper loaded: form_helper
INFO - 2023-10-11 10:29:10 --> Helper loaded: file_helper
INFO - 2023-10-11 10:29:10 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:29:10 --> Form Validation Class Initialized
INFO - 2023-10-11 10:29:10 --> Upload Class Initialized
INFO - 2023-10-11 10:29:10 --> Model "M_auth" initialized
INFO - 2023-10-11 10:29:10 --> Model "M_user" initialized
INFO - 2023-10-11 10:29:10 --> Model "M_produk" initialized
INFO - 2023-10-11 10:29:10 --> Controller Class Initialized
INFO - 2023-10-11 10:29:10 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-10-11 10:29:10 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-11 10:29:10 --> Final output sent to browser
DEBUG - 2023-10-11 10:29:10 --> Total execution time: 0.0233
INFO - 2023-10-11 10:29:44 --> Config Class Initialized
INFO - 2023-10-11 10:29:44 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:29:44 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:29:44 --> Utf8 Class Initialized
INFO - 2023-10-11 10:29:44 --> URI Class Initialized
INFO - 2023-10-11 10:29:44 --> Router Class Initialized
INFO - 2023-10-11 10:29:44 --> Output Class Initialized
INFO - 2023-10-11 10:29:44 --> Security Class Initialized
DEBUG - 2023-10-11 10:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:29:44 --> Input Class Initialized
INFO - 2023-10-11 10:29:44 --> Language Class Initialized
INFO - 2023-10-11 10:29:44 --> Loader Class Initialized
INFO - 2023-10-11 10:29:44 --> Helper loaded: url_helper
INFO - 2023-10-11 10:29:44 --> Helper loaded: form_helper
INFO - 2023-10-11 10:29:44 --> Helper loaded: file_helper
INFO - 2023-10-11 10:29:44 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:29:44 --> Form Validation Class Initialized
INFO - 2023-10-11 10:29:44 --> Upload Class Initialized
INFO - 2023-10-11 10:29:44 --> Model "M_auth" initialized
INFO - 2023-10-11 10:29:44 --> Model "M_user" initialized
INFO - 2023-10-11 10:29:44 --> Model "M_produk" initialized
INFO - 2023-10-11 10:29:44 --> Controller Class Initialized
INFO - 2023-10-11 10:29:44 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-10-11 10:29:44 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-11 10:29:44 --> Final output sent to browser
DEBUG - 2023-10-11 10:29:44 --> Total execution time: 0.0408
INFO - 2023-10-11 10:29:47 --> Config Class Initialized
INFO - 2023-10-11 10:29:47 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:29:47 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:29:47 --> Utf8 Class Initialized
INFO - 2023-10-11 10:29:47 --> URI Class Initialized
INFO - 2023-10-11 10:29:47 --> Router Class Initialized
INFO - 2023-10-11 10:29:47 --> Output Class Initialized
INFO - 2023-10-11 10:29:47 --> Security Class Initialized
DEBUG - 2023-10-11 10:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:29:47 --> Input Class Initialized
INFO - 2023-10-11 10:29:47 --> Language Class Initialized
INFO - 2023-10-11 10:29:47 --> Loader Class Initialized
INFO - 2023-10-11 10:29:47 --> Helper loaded: url_helper
INFO - 2023-10-11 10:29:47 --> Helper loaded: form_helper
INFO - 2023-10-11 10:29:47 --> Helper loaded: file_helper
INFO - 2023-10-11 10:29:47 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:29:47 --> Form Validation Class Initialized
INFO - 2023-10-11 10:29:47 --> Upload Class Initialized
INFO - 2023-10-11 10:29:47 --> Model "M_auth" initialized
INFO - 2023-10-11 10:29:47 --> Model "M_user" initialized
INFO - 2023-10-11 10:29:47 --> Model "M_produk" initialized
INFO - 2023-10-11 10:29:47 --> Controller Class Initialized
INFO - 2023-10-11 10:29:47 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-10-11 10:29:47 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-11 10:29:47 --> Final output sent to browser
DEBUG - 2023-10-11 10:29:47 --> Total execution time: 0.0226
INFO - 2023-10-11 10:30:16 --> Config Class Initialized
INFO - 2023-10-11 10:30:16 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:30:16 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:30:16 --> Utf8 Class Initialized
INFO - 2023-10-11 10:30:16 --> URI Class Initialized
INFO - 2023-10-11 10:30:16 --> Router Class Initialized
INFO - 2023-10-11 10:30:16 --> Output Class Initialized
INFO - 2023-10-11 10:30:16 --> Security Class Initialized
DEBUG - 2023-10-11 10:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:30:16 --> Input Class Initialized
INFO - 2023-10-11 10:30:16 --> Language Class Initialized
INFO - 2023-10-11 10:30:16 --> Loader Class Initialized
INFO - 2023-10-11 10:30:16 --> Helper loaded: url_helper
INFO - 2023-10-11 10:30:16 --> Helper loaded: form_helper
INFO - 2023-10-11 10:30:16 --> Helper loaded: file_helper
INFO - 2023-10-11 10:30:16 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:30:16 --> Form Validation Class Initialized
INFO - 2023-10-11 10:30:16 --> Upload Class Initialized
INFO - 2023-10-11 10:30:16 --> Model "M_auth" initialized
INFO - 2023-10-11 10:30:16 --> Model "M_user" initialized
INFO - 2023-10-11 10:30:16 --> Model "M_produk" initialized
INFO - 2023-10-11 10:30:16 --> Controller Class Initialized
INFO - 2023-10-11 10:30:16 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-10-11 10:30:16 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-11 10:30:16 --> Final output sent to browser
DEBUG - 2023-10-11 10:30:16 --> Total execution time: 0.0268
INFO - 2023-10-11 10:30:16 --> Config Class Initialized
INFO - 2023-10-11 10:30:16 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:30:16 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:30:16 --> Utf8 Class Initialized
INFO - 2023-10-11 10:30:16 --> URI Class Initialized
INFO - 2023-10-11 10:30:16 --> Router Class Initialized
INFO - 2023-10-11 10:30:16 --> Output Class Initialized
INFO - 2023-10-11 10:30:16 --> Security Class Initialized
DEBUG - 2023-10-11 10:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:30:16 --> Input Class Initialized
INFO - 2023-10-11 10:30:16 --> Language Class Initialized
INFO - 2023-10-11 10:30:16 --> Loader Class Initialized
INFO - 2023-10-11 10:30:16 --> Helper loaded: url_helper
INFO - 2023-10-11 10:30:16 --> Helper loaded: form_helper
INFO - 2023-10-11 10:30:16 --> Helper loaded: file_helper
INFO - 2023-10-11 10:30:16 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:30:16 --> Form Validation Class Initialized
INFO - 2023-10-11 10:30:16 --> Upload Class Initialized
INFO - 2023-10-11 10:30:16 --> Model "M_auth" initialized
INFO - 2023-10-11 10:30:16 --> Model "M_user" initialized
INFO - 2023-10-11 10:30:16 --> Model "M_produk" initialized
INFO - 2023-10-11 10:30:16 --> Controller Class Initialized
INFO - 2023-10-11 10:30:16 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-10-11 10:30:16 --> Final output sent to browser
DEBUG - 2023-10-11 10:30:16 --> Total execution time: 0.0239
INFO - 2023-10-11 10:30:23 --> Config Class Initialized
INFO - 2023-10-11 10:30:23 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:30:23 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:30:23 --> Utf8 Class Initialized
INFO - 2023-10-11 10:30:23 --> URI Class Initialized
INFO - 2023-10-11 10:30:23 --> Router Class Initialized
INFO - 2023-10-11 10:30:23 --> Output Class Initialized
INFO - 2023-10-11 10:30:23 --> Security Class Initialized
DEBUG - 2023-10-11 10:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:30:23 --> Input Class Initialized
INFO - 2023-10-11 10:30:23 --> Language Class Initialized
INFO - 2023-10-11 10:30:23 --> Loader Class Initialized
INFO - 2023-10-11 10:30:23 --> Helper loaded: url_helper
INFO - 2023-10-11 10:30:23 --> Helper loaded: form_helper
INFO - 2023-10-11 10:30:23 --> Helper loaded: file_helper
INFO - 2023-10-11 10:30:23 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:30:23 --> Form Validation Class Initialized
INFO - 2023-10-11 10:30:23 --> Upload Class Initialized
INFO - 2023-10-11 10:30:23 --> Model "M_auth" initialized
INFO - 2023-10-11 10:30:23 --> Model "M_user" initialized
INFO - 2023-10-11 10:30:23 --> Model "M_produk" initialized
INFO - 2023-10-11 10:30:23 --> Controller Class Initialized
INFO - 2023-10-11 10:30:23 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-10-11 10:30:23 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-11 10:30:23 --> Final output sent to browser
DEBUG - 2023-10-11 10:30:23 --> Total execution time: 0.0252
INFO - 2023-10-11 10:30:32 --> Config Class Initialized
INFO - 2023-10-11 10:30:32 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:30:32 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:30:32 --> Utf8 Class Initialized
INFO - 2023-10-11 10:30:32 --> URI Class Initialized
INFO - 2023-10-11 10:30:32 --> Router Class Initialized
INFO - 2023-10-11 10:30:32 --> Output Class Initialized
INFO - 2023-10-11 10:30:32 --> Security Class Initialized
DEBUG - 2023-10-11 10:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:30:32 --> Input Class Initialized
INFO - 2023-10-11 10:30:32 --> Language Class Initialized
INFO - 2023-10-11 10:30:32 --> Loader Class Initialized
INFO - 2023-10-11 10:30:32 --> Helper loaded: url_helper
INFO - 2023-10-11 10:30:32 --> Helper loaded: form_helper
INFO - 2023-10-11 10:30:32 --> Helper loaded: file_helper
INFO - 2023-10-11 10:30:32 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:30:32 --> Form Validation Class Initialized
INFO - 2023-10-11 10:30:32 --> Upload Class Initialized
INFO - 2023-10-11 10:30:32 --> Model "M_auth" initialized
INFO - 2023-10-11 10:30:32 --> Model "M_user" initialized
INFO - 2023-10-11 10:30:32 --> Model "M_produk" initialized
INFO - 2023-10-11 10:30:32 --> Controller Class Initialized
INFO - 2023-10-11 10:30:32 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-10-11 10:30:32 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-11 10:30:32 --> Final output sent to browser
DEBUG - 2023-10-11 10:30:32 --> Total execution time: 0.0262
INFO - 2023-10-11 10:30:33 --> Config Class Initialized
INFO - 2023-10-11 10:30:33 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:30:33 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:30:33 --> Utf8 Class Initialized
INFO - 2023-10-11 10:30:33 --> URI Class Initialized
DEBUG - 2023-10-11 10:30:33 --> No URI present. Default controller set.
INFO - 2023-10-11 10:30:33 --> Router Class Initialized
INFO - 2023-10-11 10:30:33 --> Output Class Initialized
INFO - 2023-10-11 10:30:33 --> Security Class Initialized
DEBUG - 2023-10-11 10:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:30:33 --> Input Class Initialized
INFO - 2023-10-11 10:30:33 --> Language Class Initialized
INFO - 2023-10-11 10:30:33 --> Loader Class Initialized
INFO - 2023-10-11 10:30:33 --> Helper loaded: url_helper
INFO - 2023-10-11 10:30:33 --> Helper loaded: form_helper
INFO - 2023-10-11 10:30:33 --> Helper loaded: file_helper
INFO - 2023-10-11 10:30:33 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:30:33 --> Form Validation Class Initialized
INFO - 2023-10-11 10:30:33 --> Upload Class Initialized
INFO - 2023-10-11 10:30:33 --> Model "M_auth" initialized
INFO - 2023-10-11 10:30:33 --> Model "M_user" initialized
INFO - 2023-10-11 10:30:33 --> Model "M_produk" initialized
INFO - 2023-10-11 10:30:33 --> Controller Class Initialized
INFO - 2023-10-11 10:30:33 --> Model "M_pelanggan" initialized
INFO - 2023-10-11 10:30:33 --> Model "M_produk" initialized
DEBUG - 2023-10-11 10:30:33 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-11 10:30:33 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-11 10:30:33 --> Model "M_transaksi" initialized
INFO - 2023-10-11 10:30:33 --> Model "M_bank" initialized
INFO - 2023-10-11 10:30:33 --> Model "M_pesan" initialized
INFO - 2023-10-11 10:30:33 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-11 10:30:33 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-11 10:30:33 --> Final output sent to browser
DEBUG - 2023-10-11 10:30:33 --> Total execution time: 0.0242
INFO - 2023-10-11 10:30:37 --> Config Class Initialized
INFO - 2023-10-11 10:30:37 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:30:37 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:30:37 --> Utf8 Class Initialized
INFO - 2023-10-11 10:30:37 --> URI Class Initialized
INFO - 2023-10-11 10:30:37 --> Router Class Initialized
INFO - 2023-10-11 10:30:37 --> Output Class Initialized
INFO - 2023-10-11 10:30:37 --> Security Class Initialized
DEBUG - 2023-10-11 10:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:30:37 --> Input Class Initialized
INFO - 2023-10-11 10:30:37 --> Language Class Initialized
INFO - 2023-10-11 10:30:37 --> Loader Class Initialized
INFO - 2023-10-11 10:30:37 --> Helper loaded: url_helper
INFO - 2023-10-11 10:30:37 --> Helper loaded: form_helper
INFO - 2023-10-11 10:30:37 --> Helper loaded: file_helper
INFO - 2023-10-11 10:30:37 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:30:37 --> Form Validation Class Initialized
INFO - 2023-10-11 10:30:37 --> Upload Class Initialized
INFO - 2023-10-11 10:30:37 --> Model "M_auth" initialized
INFO - 2023-10-11 10:30:37 --> Model "M_user" initialized
INFO - 2023-10-11 10:30:37 --> Model "M_produk" initialized
INFO - 2023-10-11 10:30:37 --> Controller Class Initialized
INFO - 2023-10-11 10:30:37 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-10-11 10:30:37 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-11 10:30:37 --> Final output sent to browser
DEBUG - 2023-10-11 10:30:37 --> Total execution time: 0.0491
INFO - 2023-10-11 10:30:38 --> Config Class Initialized
INFO - 2023-10-11 10:30:38 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:30:38 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:30:38 --> Utf8 Class Initialized
INFO - 2023-10-11 10:30:38 --> URI Class Initialized
DEBUG - 2023-10-11 10:30:38 --> No URI present. Default controller set.
INFO - 2023-10-11 10:30:38 --> Router Class Initialized
INFO - 2023-10-11 10:30:38 --> Output Class Initialized
INFO - 2023-10-11 10:30:38 --> Security Class Initialized
DEBUG - 2023-10-11 10:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:30:38 --> Input Class Initialized
INFO - 2023-10-11 10:30:38 --> Language Class Initialized
INFO - 2023-10-11 10:30:38 --> Loader Class Initialized
INFO - 2023-10-11 10:30:38 --> Helper loaded: url_helper
INFO - 2023-10-11 10:30:38 --> Helper loaded: form_helper
INFO - 2023-10-11 10:30:38 --> Helper loaded: file_helper
INFO - 2023-10-11 10:30:38 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:30:38 --> Form Validation Class Initialized
INFO - 2023-10-11 10:30:38 --> Upload Class Initialized
INFO - 2023-10-11 10:30:38 --> Model "M_auth" initialized
INFO - 2023-10-11 10:30:38 --> Model "M_user" initialized
INFO - 2023-10-11 10:30:38 --> Model "M_produk" initialized
INFO - 2023-10-11 10:30:38 --> Controller Class Initialized
INFO - 2023-10-11 10:30:38 --> Model "M_pelanggan" initialized
INFO - 2023-10-11 10:30:38 --> Model "M_produk" initialized
DEBUG - 2023-10-11 10:30:38 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-11 10:30:38 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-11 10:30:38 --> Model "M_transaksi" initialized
INFO - 2023-10-11 10:30:38 --> Model "M_bank" initialized
INFO - 2023-10-11 10:30:38 --> Model "M_pesan" initialized
INFO - 2023-10-11 10:30:38 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-11 10:30:38 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-11 10:30:38 --> Final output sent to browser
DEBUG - 2023-10-11 10:30:38 --> Total execution time: 0.0252
INFO - 2023-10-11 10:30:41 --> Config Class Initialized
INFO - 2023-10-11 10:30:41 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:30:41 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:30:41 --> Utf8 Class Initialized
INFO - 2023-10-11 10:30:41 --> URI Class Initialized
INFO - 2023-10-11 10:30:41 --> Router Class Initialized
INFO - 2023-10-11 10:30:41 --> Output Class Initialized
INFO - 2023-10-11 10:30:41 --> Security Class Initialized
DEBUG - 2023-10-11 10:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:30:41 --> Input Class Initialized
INFO - 2023-10-11 10:30:41 --> Language Class Initialized
INFO - 2023-10-11 10:30:41 --> Loader Class Initialized
INFO - 2023-10-11 10:30:41 --> Helper loaded: url_helper
INFO - 2023-10-11 10:30:41 --> Helper loaded: form_helper
INFO - 2023-10-11 10:30:41 --> Helper loaded: file_helper
INFO - 2023-10-11 10:30:41 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:30:41 --> Form Validation Class Initialized
INFO - 2023-10-11 10:30:41 --> Upload Class Initialized
INFO - 2023-10-11 10:30:41 --> Model "M_auth" initialized
INFO - 2023-10-11 10:30:41 --> Model "M_user" initialized
INFO - 2023-10-11 10:30:41 --> Model "M_produk" initialized
INFO - 2023-10-11 10:30:41 --> Controller Class Initialized
INFO - 2023-10-11 10:30:41 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-10-11 10:30:41 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-11 10:30:41 --> Final output sent to browser
DEBUG - 2023-10-11 10:30:41 --> Total execution time: 0.0240
INFO - 2023-10-11 10:30:42 --> Config Class Initialized
INFO - 2023-10-11 10:30:42 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:30:42 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:30:42 --> Utf8 Class Initialized
INFO - 2023-10-11 10:30:42 --> URI Class Initialized
DEBUG - 2023-10-11 10:30:42 --> No URI present. Default controller set.
INFO - 2023-10-11 10:30:42 --> Router Class Initialized
INFO - 2023-10-11 10:30:42 --> Output Class Initialized
INFO - 2023-10-11 10:30:42 --> Security Class Initialized
DEBUG - 2023-10-11 10:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:30:42 --> Input Class Initialized
INFO - 2023-10-11 10:30:42 --> Language Class Initialized
INFO - 2023-10-11 10:30:42 --> Loader Class Initialized
INFO - 2023-10-11 10:30:42 --> Helper loaded: url_helper
INFO - 2023-10-11 10:30:42 --> Helper loaded: form_helper
INFO - 2023-10-11 10:30:42 --> Helper loaded: file_helper
INFO - 2023-10-11 10:30:42 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:30:42 --> Form Validation Class Initialized
INFO - 2023-10-11 10:30:42 --> Upload Class Initialized
INFO - 2023-10-11 10:30:42 --> Model "M_auth" initialized
INFO - 2023-10-11 10:30:42 --> Model "M_user" initialized
INFO - 2023-10-11 10:30:42 --> Model "M_produk" initialized
INFO - 2023-10-11 10:30:42 --> Controller Class Initialized
INFO - 2023-10-11 10:30:42 --> Model "M_pelanggan" initialized
INFO - 2023-10-11 10:30:42 --> Model "M_produk" initialized
DEBUG - 2023-10-11 10:30:42 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-11 10:30:42 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-11 10:30:42 --> Model "M_transaksi" initialized
INFO - 2023-10-11 10:30:42 --> Model "M_bank" initialized
INFO - 2023-10-11 10:30:42 --> Model "M_pesan" initialized
INFO - 2023-10-11 10:30:42 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-11 10:30:42 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-11 10:30:42 --> Final output sent to browser
DEBUG - 2023-10-11 10:30:42 --> Total execution time: 0.0267
INFO - 2023-10-11 10:30:44 --> Config Class Initialized
INFO - 2023-10-11 10:30:44 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:30:44 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:30:44 --> Utf8 Class Initialized
INFO - 2023-10-11 10:30:44 --> URI Class Initialized
INFO - 2023-10-11 10:30:44 --> Router Class Initialized
INFO - 2023-10-11 10:30:44 --> Output Class Initialized
INFO - 2023-10-11 10:30:44 --> Security Class Initialized
DEBUG - 2023-10-11 10:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:30:44 --> Input Class Initialized
INFO - 2023-10-11 10:30:44 --> Language Class Initialized
INFO - 2023-10-11 10:30:44 --> Loader Class Initialized
INFO - 2023-10-11 10:30:44 --> Helper loaded: url_helper
INFO - 2023-10-11 10:30:44 --> Helper loaded: form_helper
INFO - 2023-10-11 10:30:44 --> Helper loaded: file_helper
INFO - 2023-10-11 10:30:44 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:30:44 --> Form Validation Class Initialized
INFO - 2023-10-11 10:30:44 --> Upload Class Initialized
INFO - 2023-10-11 10:30:44 --> Model "M_auth" initialized
INFO - 2023-10-11 10:30:44 --> Model "M_user" initialized
INFO - 2023-10-11 10:30:44 --> Model "M_produk" initialized
INFO - 2023-10-11 10:30:44 --> Controller Class Initialized
INFO - 2023-10-11 10:30:44 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-10-11 10:30:44 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-11 10:30:44 --> Final output sent to browser
DEBUG - 2023-10-11 10:30:44 --> Total execution time: 0.0222
INFO - 2023-10-11 10:30:47 --> Config Class Initialized
INFO - 2023-10-11 10:30:47 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:30:47 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:30:47 --> Utf8 Class Initialized
INFO - 2023-10-11 10:30:47 --> URI Class Initialized
INFO - 2023-10-11 10:30:47 --> Router Class Initialized
INFO - 2023-10-11 10:30:47 --> Output Class Initialized
INFO - 2023-10-11 10:30:47 --> Security Class Initialized
DEBUG - 2023-10-11 10:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:30:47 --> Input Class Initialized
INFO - 2023-10-11 10:30:47 --> Language Class Initialized
INFO - 2023-10-11 10:30:47 --> Loader Class Initialized
INFO - 2023-10-11 10:30:47 --> Helper loaded: url_helper
INFO - 2023-10-11 10:30:47 --> Helper loaded: form_helper
INFO - 2023-10-11 10:30:47 --> Helper loaded: file_helper
INFO - 2023-10-11 10:30:47 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:30:47 --> Form Validation Class Initialized
INFO - 2023-10-11 10:30:47 --> Upload Class Initialized
INFO - 2023-10-11 10:30:47 --> Model "M_auth" initialized
INFO - 2023-10-11 10:30:47 --> Model "M_user" initialized
INFO - 2023-10-11 10:30:47 --> Model "M_produk" initialized
INFO - 2023-10-11 10:30:47 --> Controller Class Initialized
INFO - 2023-10-11 10:30:47 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-10-11 10:30:47 --> Final output sent to browser
DEBUG - 2023-10-11 10:30:47 --> Total execution time: 0.0227
INFO - 2023-10-11 10:30:49 --> Config Class Initialized
INFO - 2023-10-11 10:30:49 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:30:49 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:30:49 --> Utf8 Class Initialized
INFO - 2023-10-11 10:30:49 --> URI Class Initialized
INFO - 2023-10-11 10:30:49 --> Router Class Initialized
INFO - 2023-10-11 10:30:49 --> Output Class Initialized
INFO - 2023-10-11 10:30:49 --> Security Class Initialized
DEBUG - 2023-10-11 10:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:30:49 --> Input Class Initialized
INFO - 2023-10-11 10:30:49 --> Language Class Initialized
INFO - 2023-10-11 10:30:49 --> Loader Class Initialized
INFO - 2023-10-11 10:30:49 --> Helper loaded: url_helper
INFO - 2023-10-11 10:30:49 --> Helper loaded: form_helper
INFO - 2023-10-11 10:30:49 --> Helper loaded: file_helper
INFO - 2023-10-11 10:30:49 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:30:49 --> Form Validation Class Initialized
INFO - 2023-10-11 10:30:49 --> Upload Class Initialized
INFO - 2023-10-11 10:30:49 --> Model "M_auth" initialized
INFO - 2023-10-11 10:30:49 --> Model "M_user" initialized
INFO - 2023-10-11 10:30:49 --> Model "M_produk" initialized
INFO - 2023-10-11 10:30:49 --> Controller Class Initialized
INFO - 2023-10-11 10:30:49 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-10-11 10:30:49 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-11 10:30:49 --> Final output sent to browser
DEBUG - 2023-10-11 10:30:49 --> Total execution time: 0.0266
INFO - 2023-10-11 10:31:11 --> Config Class Initialized
INFO - 2023-10-11 10:31:11 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:31:11 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:31:11 --> Utf8 Class Initialized
INFO - 2023-10-11 10:31:11 --> URI Class Initialized
INFO - 2023-10-11 10:31:11 --> Router Class Initialized
INFO - 2023-10-11 10:31:11 --> Output Class Initialized
INFO - 2023-10-11 10:31:11 --> Security Class Initialized
DEBUG - 2023-10-11 10:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:31:11 --> Input Class Initialized
INFO - 2023-10-11 10:31:11 --> Language Class Initialized
INFO - 2023-10-11 10:31:11 --> Loader Class Initialized
INFO - 2023-10-11 10:31:11 --> Helper loaded: url_helper
INFO - 2023-10-11 10:31:11 --> Helper loaded: form_helper
INFO - 2023-10-11 10:31:11 --> Helper loaded: file_helper
INFO - 2023-10-11 10:31:11 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:31:11 --> Form Validation Class Initialized
INFO - 2023-10-11 10:31:11 --> Upload Class Initialized
INFO - 2023-10-11 10:31:11 --> Model "M_auth" initialized
INFO - 2023-10-11 10:31:11 --> Model "M_user" initialized
INFO - 2023-10-11 10:31:11 --> Model "M_produk" initialized
INFO - 2023-10-11 10:31:11 --> Controller Class Initialized
INFO - 2023-10-11 10:31:11 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-10-11 10:31:11 --> Final output sent to browser
DEBUG - 2023-10-11 10:31:11 --> Total execution time: 0.0218
INFO - 2023-10-11 10:31:13 --> Config Class Initialized
INFO - 2023-10-11 10:31:13 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:31:13 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:31:13 --> Utf8 Class Initialized
INFO - 2023-10-11 10:31:13 --> URI Class Initialized
INFO - 2023-10-11 10:31:13 --> Router Class Initialized
INFO - 2023-10-11 10:31:13 --> Output Class Initialized
INFO - 2023-10-11 10:31:13 --> Security Class Initialized
DEBUG - 2023-10-11 10:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:31:13 --> Input Class Initialized
INFO - 2023-10-11 10:31:13 --> Language Class Initialized
INFO - 2023-10-11 10:31:13 --> Loader Class Initialized
INFO - 2023-10-11 10:31:13 --> Helper loaded: url_helper
INFO - 2023-10-11 10:31:13 --> Helper loaded: form_helper
INFO - 2023-10-11 10:31:13 --> Helper loaded: file_helper
INFO - 2023-10-11 10:31:13 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:31:13 --> Form Validation Class Initialized
INFO - 2023-10-11 10:31:13 --> Upload Class Initialized
INFO - 2023-10-11 10:31:13 --> Model "M_auth" initialized
INFO - 2023-10-11 10:31:13 --> Model "M_user" initialized
INFO - 2023-10-11 10:31:13 --> Model "M_produk" initialized
INFO - 2023-10-11 10:31:13 --> Controller Class Initialized
INFO - 2023-10-11 10:31:13 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-10-11 10:31:13 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-11 10:31:13 --> Final output sent to browser
DEBUG - 2023-10-11 10:31:13 --> Total execution time: 0.0222
INFO - 2023-10-11 10:31:14 --> Config Class Initialized
INFO - 2023-10-11 10:31:14 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:31:14 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:31:14 --> Utf8 Class Initialized
INFO - 2023-10-11 10:31:14 --> URI Class Initialized
DEBUG - 2023-10-11 10:31:14 --> No URI present. Default controller set.
INFO - 2023-10-11 10:31:14 --> Router Class Initialized
INFO - 2023-10-11 10:31:14 --> Output Class Initialized
INFO - 2023-10-11 10:31:14 --> Security Class Initialized
DEBUG - 2023-10-11 10:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:31:14 --> Input Class Initialized
INFO - 2023-10-11 10:31:14 --> Language Class Initialized
INFO - 2023-10-11 10:31:14 --> Loader Class Initialized
INFO - 2023-10-11 10:31:14 --> Helper loaded: url_helper
INFO - 2023-10-11 10:31:14 --> Helper loaded: form_helper
INFO - 2023-10-11 10:31:14 --> Helper loaded: file_helper
INFO - 2023-10-11 10:31:14 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:31:14 --> Form Validation Class Initialized
INFO - 2023-10-11 10:31:14 --> Upload Class Initialized
INFO - 2023-10-11 10:31:14 --> Model "M_auth" initialized
INFO - 2023-10-11 10:31:14 --> Model "M_user" initialized
INFO - 2023-10-11 10:31:14 --> Model "M_produk" initialized
INFO - 2023-10-11 10:31:14 --> Controller Class Initialized
INFO - 2023-10-11 10:31:14 --> Model "M_pelanggan" initialized
INFO - 2023-10-11 10:31:14 --> Model "M_produk" initialized
DEBUG - 2023-10-11 10:31:14 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-11 10:31:14 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-11 10:31:14 --> Model "M_transaksi" initialized
INFO - 2023-10-11 10:31:14 --> Model "M_bank" initialized
INFO - 2023-10-11 10:31:14 --> Model "M_pesan" initialized
INFO - 2023-10-11 10:31:14 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-11 10:31:14 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-11 10:31:14 --> Final output sent to browser
DEBUG - 2023-10-11 10:31:14 --> Total execution time: 0.0259
INFO - 2023-10-11 10:31:16 --> Config Class Initialized
INFO - 2023-10-11 10:31:16 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:31:16 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:31:16 --> Utf8 Class Initialized
INFO - 2023-10-11 10:31:16 --> URI Class Initialized
DEBUG - 2023-10-11 10:31:16 --> No URI present. Default controller set.
INFO - 2023-10-11 10:31:16 --> Router Class Initialized
INFO - 2023-10-11 10:31:16 --> Output Class Initialized
INFO - 2023-10-11 10:31:16 --> Security Class Initialized
DEBUG - 2023-10-11 10:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:31:16 --> Input Class Initialized
INFO - 2023-10-11 10:31:16 --> Language Class Initialized
INFO - 2023-10-11 10:31:16 --> Loader Class Initialized
INFO - 2023-10-11 10:31:16 --> Helper loaded: url_helper
INFO - 2023-10-11 10:31:16 --> Helper loaded: form_helper
INFO - 2023-10-11 10:31:16 --> Helper loaded: file_helper
INFO - 2023-10-11 10:31:16 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:31:16 --> Form Validation Class Initialized
INFO - 2023-10-11 10:31:16 --> Upload Class Initialized
INFO - 2023-10-11 10:31:16 --> Model "M_auth" initialized
INFO - 2023-10-11 10:31:16 --> Model "M_user" initialized
INFO - 2023-10-11 10:31:16 --> Model "M_produk" initialized
INFO - 2023-10-11 10:31:16 --> Controller Class Initialized
INFO - 2023-10-11 10:31:16 --> Model "M_pelanggan" initialized
INFO - 2023-10-11 10:31:16 --> Model "M_produk" initialized
DEBUG - 2023-10-11 10:31:16 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-11 10:31:16 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-11 10:31:16 --> Model "M_transaksi" initialized
INFO - 2023-10-11 10:31:16 --> Model "M_bank" initialized
INFO - 2023-10-11 10:31:16 --> Model "M_pesan" initialized
INFO - 2023-10-11 10:31:16 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-11 10:31:16 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-11 10:31:16 --> Final output sent to browser
DEBUG - 2023-10-11 10:31:16 --> Total execution time: 0.0240
INFO - 2023-10-11 10:31:18 --> Config Class Initialized
INFO - 2023-10-11 10:31:18 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:31:18 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:31:18 --> Utf8 Class Initialized
INFO - 2023-10-11 10:31:18 --> URI Class Initialized
DEBUG - 2023-10-11 10:31:18 --> No URI present. Default controller set.
INFO - 2023-10-11 10:31:18 --> Router Class Initialized
INFO - 2023-10-11 10:31:18 --> Output Class Initialized
INFO - 2023-10-11 10:31:18 --> Security Class Initialized
DEBUG - 2023-10-11 10:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:31:18 --> Input Class Initialized
INFO - 2023-10-11 10:31:18 --> Language Class Initialized
INFO - 2023-10-11 10:31:18 --> Loader Class Initialized
INFO - 2023-10-11 10:31:18 --> Helper loaded: url_helper
INFO - 2023-10-11 10:31:18 --> Helper loaded: form_helper
INFO - 2023-10-11 10:31:18 --> Helper loaded: file_helper
INFO - 2023-10-11 10:31:18 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:31:18 --> Form Validation Class Initialized
INFO - 2023-10-11 10:31:18 --> Upload Class Initialized
INFO - 2023-10-11 10:31:18 --> Model "M_auth" initialized
INFO - 2023-10-11 10:31:18 --> Model "M_user" initialized
INFO - 2023-10-11 10:31:18 --> Model "M_produk" initialized
INFO - 2023-10-11 10:31:18 --> Controller Class Initialized
INFO - 2023-10-11 10:31:18 --> Model "M_pelanggan" initialized
INFO - 2023-10-11 10:31:18 --> Model "M_produk" initialized
DEBUG - 2023-10-11 10:31:18 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-11 10:31:18 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-11 10:31:18 --> Model "M_transaksi" initialized
INFO - 2023-10-11 10:31:18 --> Model "M_bank" initialized
INFO - 2023-10-11 10:31:18 --> Model "M_pesan" initialized
INFO - 2023-10-11 10:31:18 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-11 10:31:18 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-11 10:31:18 --> Final output sent to browser
DEBUG - 2023-10-11 10:31:18 --> Total execution time: 0.0283
INFO - 2023-10-11 10:31:18 --> Config Class Initialized
INFO - 2023-10-11 10:31:18 --> Hooks Class Initialized
DEBUG - 2023-10-11 10:31:18 --> UTF-8 Support Enabled
INFO - 2023-10-11 10:31:18 --> Utf8 Class Initialized
INFO - 2023-10-11 10:31:18 --> URI Class Initialized
INFO - 2023-10-11 10:31:18 --> Router Class Initialized
INFO - 2023-10-11 10:31:18 --> Output Class Initialized
INFO - 2023-10-11 10:31:18 --> Security Class Initialized
DEBUG - 2023-10-11 10:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-11 10:31:18 --> Input Class Initialized
INFO - 2023-10-11 10:31:18 --> Language Class Initialized
INFO - 2023-10-11 10:31:18 --> Loader Class Initialized
INFO - 2023-10-11 10:31:18 --> Helper loaded: url_helper
INFO - 2023-10-11 10:31:18 --> Helper loaded: form_helper
INFO - 2023-10-11 10:31:18 --> Helper loaded: file_helper
INFO - 2023-10-11 10:31:18 --> Database Driver Class Initialized
DEBUG - 2023-10-11 10:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-11 10:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-11 10:31:18 --> Form Validation Class Initialized
INFO - 2023-10-11 10:31:18 --> Upload Class Initialized
INFO - 2023-10-11 10:31:18 --> Model "M_auth" initialized
INFO - 2023-10-11 10:31:18 --> Model "M_user" initialized
INFO - 2023-10-11 10:31:18 --> Model "M_produk" initialized
INFO - 2023-10-11 10:31:18 --> Controller Class Initialized
INFO - 2023-10-11 10:31:18 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-10-11 10:31:18 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-11 10:31:18 --> Final output sent to browser
DEBUG - 2023-10-11 10:31:18 --> Total execution time: 0.0259
