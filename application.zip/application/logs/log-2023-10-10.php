<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-10-10 17:29:37 --> Config Class Initialized
INFO - 2023-10-10 17:29:37 --> Hooks Class Initialized
DEBUG - 2023-10-10 17:29:37 --> UTF-8 Support Enabled
INFO - 2023-10-10 17:29:37 --> Utf8 Class Initialized
INFO - 2023-10-10 17:29:37 --> URI Class Initialized
DEBUG - 2023-10-10 17:29:37 --> No URI present. Default controller set.
INFO - 2023-10-10 17:29:37 --> Router Class Initialized
INFO - 2023-10-10 17:29:37 --> Output Class Initialized
INFO - 2023-10-10 17:29:38 --> Security Class Initialized
DEBUG - 2023-10-10 17:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-10 17:29:38 --> Input Class Initialized
INFO - 2023-10-10 17:29:38 --> Language Class Initialized
INFO - 2023-10-10 17:29:38 --> Loader Class Initialized
INFO - 2023-10-10 17:29:38 --> Helper loaded: url_helper
INFO - 2023-10-10 17:29:38 --> Helper loaded: form_helper
INFO - 2023-10-10 17:29:38 --> Helper loaded: file_helper
INFO - 2023-10-10 17:29:38 --> Database Driver Class Initialized
DEBUG - 2023-10-10 17:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-10 17:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-10 17:29:38 --> Form Validation Class Initialized
INFO - 2023-10-10 17:29:38 --> Upload Class Initialized
INFO - 2023-10-10 17:29:38 --> Model "M_auth" initialized
INFO - 2023-10-10 17:29:38 --> Model "M_user" initialized
INFO - 2023-10-10 17:29:38 --> Model "M_produk" initialized
INFO - 2023-10-10 17:29:38 --> Controller Class Initialized
INFO - 2023-10-10 17:29:38 --> Model "M_pelanggan" initialized
INFO - 2023-10-10 17:29:38 --> Model "M_produk" initialized
DEBUG - 2023-10-10 17:29:38 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-10 17:29:38 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-10 17:29:39 --> Model "M_transaksi" initialized
INFO - 2023-10-10 17:29:39 --> Model "M_bank" initialized
INFO - 2023-10-10 17:29:39 --> Model "M_pesan" initialized
INFO - 2023-10-10 17:29:39 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-10 17:29:39 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-10 17:29:39 --> Final output sent to browser
DEBUG - 2023-10-10 17:29:39 --> Total execution time: 1.2281
