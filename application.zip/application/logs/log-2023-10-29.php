<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-10-29 00:22:17 --> Config Class Initialized
INFO - 2023-10-29 00:22:17 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:22:17 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:22:17 --> Utf8 Class Initialized
INFO - 2023-10-29 00:22:17 --> URI Class Initialized
DEBUG - 2023-10-29 00:22:17 --> No URI present. Default controller set.
INFO - 2023-10-29 00:22:17 --> Router Class Initialized
INFO - 2023-10-29 00:22:17 --> Output Class Initialized
INFO - 2023-10-29 00:22:17 --> Security Class Initialized
DEBUG - 2023-10-29 00:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:22:17 --> Input Class Initialized
INFO - 2023-10-29 00:22:17 --> Language Class Initialized
INFO - 2023-10-29 00:22:17 --> Loader Class Initialized
INFO - 2023-10-29 00:22:17 --> Helper loaded: url_helper
INFO - 2023-10-29 00:22:17 --> Helper loaded: form_helper
INFO - 2023-10-29 00:22:17 --> Helper loaded: file_helper
INFO - 2023-10-29 00:22:17 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:22:17 --> Form Validation Class Initialized
INFO - 2023-10-29 00:22:17 --> Upload Class Initialized
INFO - 2023-10-29 00:22:17 --> Model "M_auth" initialized
INFO - 2023-10-29 00:22:17 --> Model "M_user" initialized
INFO - 2023-10-29 00:22:17 --> Model "M_produk" initialized
INFO - 2023-10-29 00:22:17 --> Controller Class Initialized
INFO - 2023-10-29 00:22:17 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 00:22:17 --> Model "M_produk" initialized
DEBUG - 2023-10-29 00:22:17 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 00:22:17 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 00:22:17 --> Model "M_transaksi" initialized
INFO - 2023-10-29 00:22:17 --> Model "M_bank" initialized
INFO - 2023-10-29 00:22:17 --> Model "M_pesan" initialized
INFO - 2023-10-29 00:22:17 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-29 00:22:17 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-29 00:22:17 --> Final output sent to browser
DEBUG - 2023-10-29 00:22:17 --> Total execution time: 0.1879
INFO - 2023-10-29 00:22:21 --> Config Class Initialized
INFO - 2023-10-29 00:22:21 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:22:21 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:22:21 --> Utf8 Class Initialized
INFO - 2023-10-29 00:22:21 --> URI Class Initialized
INFO - 2023-10-29 00:22:21 --> Router Class Initialized
INFO - 2023-10-29 00:22:21 --> Output Class Initialized
INFO - 2023-10-29 00:22:21 --> Security Class Initialized
DEBUG - 2023-10-29 00:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:22:21 --> Input Class Initialized
INFO - 2023-10-29 00:22:21 --> Language Class Initialized
INFO - 2023-10-29 00:22:21 --> Loader Class Initialized
INFO - 2023-10-29 00:22:21 --> Helper loaded: url_helper
INFO - 2023-10-29 00:22:21 --> Helper loaded: form_helper
INFO - 2023-10-29 00:22:21 --> Helper loaded: file_helper
INFO - 2023-10-29 00:22:21 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:22:21 --> Form Validation Class Initialized
INFO - 2023-10-29 00:22:21 --> Upload Class Initialized
INFO - 2023-10-29 00:22:21 --> Model "M_auth" initialized
INFO - 2023-10-29 00:22:21 --> Model "M_user" initialized
INFO - 2023-10-29 00:22:21 --> Model "M_produk" initialized
INFO - 2023-10-29 00:22:21 --> Controller Class Initialized
INFO - 2023-10-29 00:22:21 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 00:22:21 --> Final output sent to browser
DEBUG - 2023-10-29 00:22:21 --> Total execution time: 0.0721
INFO - 2023-10-29 00:22:25 --> Config Class Initialized
INFO - 2023-10-29 00:22:25 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:22:25 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:22:25 --> Utf8 Class Initialized
INFO - 2023-10-29 00:22:25 --> URI Class Initialized
INFO - 2023-10-29 00:22:25 --> Router Class Initialized
INFO - 2023-10-29 00:22:25 --> Output Class Initialized
INFO - 2023-10-29 00:22:25 --> Security Class Initialized
DEBUG - 2023-10-29 00:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:22:25 --> Input Class Initialized
INFO - 2023-10-29 00:22:25 --> Language Class Initialized
INFO - 2023-10-29 00:22:25 --> Loader Class Initialized
INFO - 2023-10-29 00:22:25 --> Helper loaded: url_helper
INFO - 2023-10-29 00:22:25 --> Helper loaded: form_helper
INFO - 2023-10-29 00:22:25 --> Helper loaded: file_helper
INFO - 2023-10-29 00:22:25 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:22:25 --> Form Validation Class Initialized
INFO - 2023-10-29 00:22:25 --> Upload Class Initialized
INFO - 2023-10-29 00:22:25 --> Model "M_auth" initialized
INFO - 2023-10-29 00:22:25 --> Model "M_user" initialized
INFO - 2023-10-29 00:22:25 --> Model "M_produk" initialized
INFO - 2023-10-29 00:22:25 --> Controller Class Initialized
ERROR - 2023-10-29 00:22:25 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:26:14 --> Config Class Initialized
INFO - 2023-10-29 00:26:14 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:26:14 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:26:14 --> Utf8 Class Initialized
INFO - 2023-10-29 00:26:14 --> URI Class Initialized
INFO - 2023-10-29 00:26:14 --> Router Class Initialized
INFO - 2023-10-29 00:26:14 --> Output Class Initialized
INFO - 2023-10-29 00:26:14 --> Security Class Initialized
DEBUG - 2023-10-29 00:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:26:14 --> Input Class Initialized
INFO - 2023-10-29 00:26:14 --> Language Class Initialized
INFO - 2023-10-29 00:26:14 --> Loader Class Initialized
INFO - 2023-10-29 00:26:14 --> Helper loaded: url_helper
INFO - 2023-10-29 00:26:14 --> Helper loaded: form_helper
INFO - 2023-10-29 00:26:14 --> Helper loaded: file_helper
INFO - 2023-10-29 00:26:14 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:26:14 --> Form Validation Class Initialized
INFO - 2023-10-29 00:26:14 --> Upload Class Initialized
INFO - 2023-10-29 00:26:14 --> Model "M_auth" initialized
INFO - 2023-10-29 00:26:14 --> Model "M_user" initialized
INFO - 2023-10-29 00:26:14 --> Model "M_produk" initialized
INFO - 2023-10-29 00:26:14 --> Controller Class Initialized
INFO - 2023-10-29 00:26:14 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 00:26:14 --> Final output sent to browser
DEBUG - 2023-10-29 00:26:14 --> Total execution time: 0.0832
INFO - 2023-10-29 00:26:15 --> Config Class Initialized
INFO - 2023-10-29 00:26:15 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:26:15 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:26:15 --> Utf8 Class Initialized
INFO - 2023-10-29 00:26:15 --> URI Class Initialized
INFO - 2023-10-29 00:26:15 --> Router Class Initialized
INFO - 2023-10-29 00:26:15 --> Output Class Initialized
INFO - 2023-10-29 00:26:15 --> Security Class Initialized
DEBUG - 2023-10-29 00:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:26:15 --> Input Class Initialized
INFO - 2023-10-29 00:26:15 --> Language Class Initialized
INFO - 2023-10-29 00:26:15 --> Loader Class Initialized
INFO - 2023-10-29 00:26:15 --> Helper loaded: url_helper
INFO - 2023-10-29 00:26:15 --> Helper loaded: form_helper
INFO - 2023-10-29 00:26:15 --> Helper loaded: file_helper
INFO - 2023-10-29 00:26:15 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:26:15 --> Form Validation Class Initialized
INFO - 2023-10-29 00:26:15 --> Upload Class Initialized
INFO - 2023-10-29 00:26:15 --> Model "M_auth" initialized
INFO - 2023-10-29 00:26:15 --> Model "M_user" initialized
INFO - 2023-10-29 00:26:15 --> Model "M_produk" initialized
INFO - 2023-10-29 00:26:15 --> Controller Class Initialized
ERROR - 2023-10-29 00:26:15 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:26:17 --> Config Class Initialized
INFO - 2023-10-29 00:26:17 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:26:17 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:26:17 --> Utf8 Class Initialized
INFO - 2023-10-29 00:26:17 --> URI Class Initialized
INFO - 2023-10-29 00:26:17 --> Router Class Initialized
INFO - 2023-10-29 00:26:17 --> Output Class Initialized
INFO - 2023-10-29 00:26:17 --> Security Class Initialized
DEBUG - 2023-10-29 00:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:26:17 --> Input Class Initialized
INFO - 2023-10-29 00:26:17 --> Language Class Initialized
INFO - 2023-10-29 00:26:17 --> Loader Class Initialized
INFO - 2023-10-29 00:26:17 --> Helper loaded: url_helper
INFO - 2023-10-29 00:26:17 --> Helper loaded: form_helper
INFO - 2023-10-29 00:26:17 --> Helper loaded: file_helper
INFO - 2023-10-29 00:26:17 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:26:17 --> Form Validation Class Initialized
INFO - 2023-10-29 00:26:17 --> Upload Class Initialized
INFO - 2023-10-29 00:26:17 --> Model "M_auth" initialized
INFO - 2023-10-29 00:26:17 --> Model "M_user" initialized
INFO - 2023-10-29 00:26:17 --> Model "M_produk" initialized
INFO - 2023-10-29 00:26:17 --> Controller Class Initialized
INFO - 2023-10-29 00:26:17 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 00:26:17 --> Final output sent to browser
DEBUG - 2023-10-29 00:26:17 --> Total execution time: 0.0811
INFO - 2023-10-29 00:26:18 --> Config Class Initialized
INFO - 2023-10-29 00:26:18 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:26:18 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:26:18 --> Utf8 Class Initialized
INFO - 2023-10-29 00:26:18 --> URI Class Initialized
INFO - 2023-10-29 00:26:18 --> Router Class Initialized
INFO - 2023-10-29 00:26:18 --> Output Class Initialized
INFO - 2023-10-29 00:26:18 --> Security Class Initialized
DEBUG - 2023-10-29 00:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:26:18 --> Input Class Initialized
INFO - 2023-10-29 00:26:18 --> Language Class Initialized
INFO - 2023-10-29 00:26:18 --> Loader Class Initialized
INFO - 2023-10-29 00:26:18 --> Helper loaded: url_helper
INFO - 2023-10-29 00:26:18 --> Helper loaded: form_helper
INFO - 2023-10-29 00:26:18 --> Helper loaded: file_helper
INFO - 2023-10-29 00:26:18 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:26:18 --> Form Validation Class Initialized
INFO - 2023-10-29 00:26:18 --> Upload Class Initialized
INFO - 2023-10-29 00:26:18 --> Model "M_auth" initialized
INFO - 2023-10-29 00:26:18 --> Model "M_user" initialized
INFO - 2023-10-29 00:26:18 --> Model "M_produk" initialized
INFO - 2023-10-29 00:26:18 --> Controller Class Initialized
INFO - 2023-10-29 00:26:18 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 00:26:18 --> Final output sent to browser
DEBUG - 2023-10-29 00:26:18 --> Total execution time: 0.0301
INFO - 2023-10-29 00:26:18 --> Config Class Initialized
INFO - 2023-10-29 00:26:18 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:26:18 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:26:18 --> Utf8 Class Initialized
INFO - 2023-10-29 00:26:18 --> URI Class Initialized
INFO - 2023-10-29 00:26:18 --> Router Class Initialized
INFO - 2023-10-29 00:26:18 --> Output Class Initialized
INFO - 2023-10-29 00:26:18 --> Security Class Initialized
DEBUG - 2023-10-29 00:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:26:18 --> Input Class Initialized
INFO - 2023-10-29 00:26:18 --> Language Class Initialized
INFO - 2023-10-29 00:26:18 --> Loader Class Initialized
INFO - 2023-10-29 00:26:18 --> Helper loaded: url_helper
INFO - 2023-10-29 00:26:18 --> Helper loaded: form_helper
INFO - 2023-10-29 00:26:19 --> Helper loaded: file_helper
INFO - 2023-10-29 00:26:19 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:26:19 --> Form Validation Class Initialized
INFO - 2023-10-29 00:26:19 --> Upload Class Initialized
INFO - 2023-10-29 00:26:19 --> Model "M_auth" initialized
INFO - 2023-10-29 00:26:19 --> Model "M_user" initialized
INFO - 2023-10-29 00:26:19 --> Model "M_produk" initialized
INFO - 2023-10-29 00:26:19 --> Controller Class Initialized
INFO - 2023-10-29 00:26:19 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 00:26:19 --> Final output sent to browser
DEBUG - 2023-10-29 00:26:19 --> Total execution time: 0.0349
INFO - 2023-10-29 00:26:19 --> Config Class Initialized
INFO - 2023-10-29 00:26:19 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:26:19 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:26:19 --> Utf8 Class Initialized
INFO - 2023-10-29 00:26:19 --> URI Class Initialized
INFO - 2023-10-29 00:26:19 --> Router Class Initialized
INFO - 2023-10-29 00:26:19 --> Output Class Initialized
INFO - 2023-10-29 00:26:19 --> Security Class Initialized
DEBUG - 2023-10-29 00:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:26:19 --> Input Class Initialized
INFO - 2023-10-29 00:26:19 --> Language Class Initialized
INFO - 2023-10-29 00:26:19 --> Loader Class Initialized
INFO - 2023-10-29 00:26:19 --> Helper loaded: url_helper
INFO - 2023-10-29 00:26:19 --> Helper loaded: form_helper
INFO - 2023-10-29 00:26:19 --> Helper loaded: file_helper
INFO - 2023-10-29 00:26:19 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:26:19 --> Form Validation Class Initialized
INFO - 2023-10-29 00:26:19 --> Upload Class Initialized
INFO - 2023-10-29 00:26:19 --> Model "M_auth" initialized
INFO - 2023-10-29 00:26:19 --> Model "M_user" initialized
INFO - 2023-10-29 00:26:19 --> Model "M_produk" initialized
INFO - 2023-10-29 00:26:19 --> Controller Class Initialized
INFO - 2023-10-29 00:26:19 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 00:26:19 --> Final output sent to browser
DEBUG - 2023-10-29 00:26:19 --> Total execution time: 0.0703
INFO - 2023-10-29 00:26:19 --> Config Class Initialized
INFO - 2023-10-29 00:26:19 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:26:19 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:26:19 --> Utf8 Class Initialized
INFO - 2023-10-29 00:26:19 --> URI Class Initialized
INFO - 2023-10-29 00:26:19 --> Router Class Initialized
INFO - 2023-10-29 00:26:19 --> Output Class Initialized
INFO - 2023-10-29 00:26:19 --> Security Class Initialized
DEBUG - 2023-10-29 00:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:26:19 --> Input Class Initialized
INFO - 2023-10-29 00:26:19 --> Language Class Initialized
INFO - 2023-10-29 00:26:19 --> Loader Class Initialized
INFO - 2023-10-29 00:26:19 --> Helper loaded: url_helper
INFO - 2023-10-29 00:26:19 --> Helper loaded: form_helper
INFO - 2023-10-29 00:26:19 --> Helper loaded: file_helper
INFO - 2023-10-29 00:26:19 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:26:19 --> Form Validation Class Initialized
INFO - 2023-10-29 00:26:19 --> Upload Class Initialized
INFO - 2023-10-29 00:26:19 --> Model "M_auth" initialized
INFO - 2023-10-29 00:26:19 --> Model "M_user" initialized
INFO - 2023-10-29 00:26:19 --> Model "M_produk" initialized
INFO - 2023-10-29 00:26:19 --> Controller Class Initialized
INFO - 2023-10-29 00:26:19 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 00:26:19 --> Final output sent to browser
DEBUG - 2023-10-29 00:26:19 --> Total execution time: 0.0786
INFO - 2023-10-29 00:26:20 --> Config Class Initialized
INFO - 2023-10-29 00:26:20 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:26:20 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:26:20 --> Utf8 Class Initialized
INFO - 2023-10-29 00:26:20 --> URI Class Initialized
INFO - 2023-10-29 00:26:20 --> Router Class Initialized
INFO - 2023-10-29 00:26:20 --> Output Class Initialized
INFO - 2023-10-29 00:26:20 --> Security Class Initialized
DEBUG - 2023-10-29 00:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:26:20 --> Input Class Initialized
INFO - 2023-10-29 00:26:20 --> Language Class Initialized
INFO - 2023-10-29 00:26:20 --> Loader Class Initialized
INFO - 2023-10-29 00:26:20 --> Helper loaded: url_helper
INFO - 2023-10-29 00:26:20 --> Helper loaded: form_helper
INFO - 2023-10-29 00:26:20 --> Helper loaded: file_helper
INFO - 2023-10-29 00:26:20 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:26:20 --> Form Validation Class Initialized
INFO - 2023-10-29 00:26:20 --> Upload Class Initialized
INFO - 2023-10-29 00:26:20 --> Model "M_auth" initialized
INFO - 2023-10-29 00:26:20 --> Model "M_user" initialized
INFO - 2023-10-29 00:26:20 --> Model "M_produk" initialized
INFO - 2023-10-29 00:26:20 --> Controller Class Initialized
ERROR - 2023-10-29 00:26:21 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:27:07 --> Config Class Initialized
INFO - 2023-10-29 00:27:07 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:27:07 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:27:07 --> Utf8 Class Initialized
INFO - 2023-10-29 00:27:07 --> URI Class Initialized
INFO - 2023-10-29 00:27:07 --> Router Class Initialized
INFO - 2023-10-29 00:27:07 --> Output Class Initialized
INFO - 2023-10-29 00:27:07 --> Security Class Initialized
DEBUG - 2023-10-29 00:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:27:07 --> Input Class Initialized
INFO - 2023-10-29 00:27:07 --> Language Class Initialized
INFO - 2023-10-29 00:27:07 --> Loader Class Initialized
INFO - 2023-10-29 00:27:07 --> Helper loaded: url_helper
INFO - 2023-10-29 00:27:07 --> Helper loaded: form_helper
INFO - 2023-10-29 00:27:07 --> Helper loaded: file_helper
INFO - 2023-10-29 00:27:07 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:27:07 --> Form Validation Class Initialized
INFO - 2023-10-29 00:27:07 --> Upload Class Initialized
INFO - 2023-10-29 00:27:07 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:27:07 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:27:08 --> Config Class Initialized
INFO - 2023-10-29 00:27:08 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:27:08 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:27:08 --> Utf8 Class Initialized
INFO - 2023-10-29 00:27:08 --> URI Class Initialized
DEBUG - 2023-10-29 00:27:08 --> No URI present. Default controller set.
INFO - 2023-10-29 00:27:08 --> Router Class Initialized
INFO - 2023-10-29 00:27:08 --> Output Class Initialized
INFO - 2023-10-29 00:27:08 --> Security Class Initialized
DEBUG - 2023-10-29 00:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:27:08 --> Input Class Initialized
INFO - 2023-10-29 00:27:08 --> Language Class Initialized
INFO - 2023-10-29 00:27:08 --> Loader Class Initialized
INFO - 2023-10-29 00:27:08 --> Helper loaded: url_helper
INFO - 2023-10-29 00:27:08 --> Helper loaded: form_helper
INFO - 2023-10-29 00:27:08 --> Helper loaded: file_helper
INFO - 2023-10-29 00:27:08 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:27:09 --> Form Validation Class Initialized
INFO - 2023-10-29 00:27:09 --> Upload Class Initialized
INFO - 2023-10-29 00:27:09 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:27:09 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:27:09 --> Config Class Initialized
INFO - 2023-10-29 00:27:09 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:27:09 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:27:09 --> Utf8 Class Initialized
INFO - 2023-10-29 00:27:09 --> URI Class Initialized
INFO - 2023-10-29 00:27:09 --> Router Class Initialized
INFO - 2023-10-29 00:27:09 --> Output Class Initialized
INFO - 2023-10-29 00:27:09 --> Security Class Initialized
DEBUG - 2023-10-29 00:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:27:09 --> Input Class Initialized
INFO - 2023-10-29 00:27:09 --> Language Class Initialized
INFO - 2023-10-29 00:27:09 --> Loader Class Initialized
INFO - 2023-10-29 00:27:09 --> Helper loaded: url_helper
INFO - 2023-10-29 00:27:09 --> Helper loaded: form_helper
INFO - 2023-10-29 00:27:09 --> Helper loaded: file_helper
INFO - 2023-10-29 00:27:09 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:27:09 --> Form Validation Class Initialized
INFO - 2023-10-29 00:27:09 --> Upload Class Initialized
INFO - 2023-10-29 00:27:09 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:27:09 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:27:13 --> Config Class Initialized
INFO - 2023-10-29 00:27:13 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:27:13 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:27:13 --> Utf8 Class Initialized
INFO - 2023-10-29 00:27:13 --> URI Class Initialized
DEBUG - 2023-10-29 00:27:13 --> No URI present. Default controller set.
INFO - 2023-10-29 00:27:13 --> Router Class Initialized
INFO - 2023-10-29 00:27:13 --> Output Class Initialized
INFO - 2023-10-29 00:27:13 --> Security Class Initialized
DEBUG - 2023-10-29 00:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:27:13 --> Input Class Initialized
INFO - 2023-10-29 00:27:13 --> Language Class Initialized
INFO - 2023-10-29 00:27:13 --> Loader Class Initialized
INFO - 2023-10-29 00:27:13 --> Helper loaded: url_helper
INFO - 2023-10-29 00:27:13 --> Helper loaded: form_helper
INFO - 2023-10-29 00:27:13 --> Helper loaded: file_helper
INFO - 2023-10-29 00:27:13 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:27:13 --> Form Validation Class Initialized
INFO - 2023-10-29 00:27:13 --> Upload Class Initialized
INFO - 2023-10-29 00:27:13 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:27:13 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:27:18 --> Config Class Initialized
INFO - 2023-10-29 00:27:18 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:27:18 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:27:18 --> Utf8 Class Initialized
INFO - 2023-10-29 00:27:18 --> URI Class Initialized
INFO - 2023-10-29 00:27:18 --> Router Class Initialized
INFO - 2023-10-29 00:27:18 --> Output Class Initialized
INFO - 2023-10-29 00:27:18 --> Security Class Initialized
DEBUG - 2023-10-29 00:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:27:18 --> Input Class Initialized
INFO - 2023-10-29 00:27:18 --> Language Class Initialized
INFO - 2023-10-29 00:27:18 --> Loader Class Initialized
INFO - 2023-10-29 00:27:18 --> Helper loaded: url_helper
INFO - 2023-10-29 00:27:18 --> Helper loaded: form_helper
INFO - 2023-10-29 00:27:18 --> Helper loaded: file_helper
INFO - 2023-10-29 00:27:18 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:27:18 --> Form Validation Class Initialized
INFO - 2023-10-29 00:27:18 --> Upload Class Initialized
INFO - 2023-10-29 00:27:18 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:27:18 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:28:38 --> Config Class Initialized
INFO - 2023-10-29 00:28:38 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:28:38 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:28:38 --> Utf8 Class Initialized
INFO - 2023-10-29 00:28:38 --> URI Class Initialized
INFO - 2023-10-29 00:28:38 --> Router Class Initialized
INFO - 2023-10-29 00:28:38 --> Output Class Initialized
INFO - 2023-10-29 00:28:38 --> Security Class Initialized
DEBUG - 2023-10-29 00:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:28:38 --> Input Class Initialized
INFO - 2023-10-29 00:28:38 --> Language Class Initialized
INFO - 2023-10-29 00:28:38 --> Loader Class Initialized
INFO - 2023-10-29 00:28:38 --> Helper loaded: url_helper
INFO - 2023-10-29 00:28:38 --> Helper loaded: form_helper
INFO - 2023-10-29 00:28:38 --> Helper loaded: file_helper
INFO - 2023-10-29 00:28:38 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:28:38 --> Form Validation Class Initialized
INFO - 2023-10-29 00:28:38 --> Upload Class Initialized
INFO - 2023-10-29 00:28:38 --> Model "M_auth" initialized
INFO - 2023-10-29 00:28:38 --> Model "M_user" initialized
INFO - 2023-10-29 00:28:38 --> Model "M_produk" initialized
INFO - 2023-10-29 00:28:38 --> Controller Class Initialized
INFO - 2023-10-29 00:28:38 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 00:28:38 --> Final output sent to browser
DEBUG - 2023-10-29 00:28:38 --> Total execution time: 0.0725
INFO - 2023-10-29 00:28:39 --> Config Class Initialized
INFO - 2023-10-29 00:28:39 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:28:39 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:28:39 --> Utf8 Class Initialized
INFO - 2023-10-29 00:28:39 --> URI Class Initialized
INFO - 2023-10-29 00:28:39 --> Router Class Initialized
INFO - 2023-10-29 00:28:39 --> Output Class Initialized
INFO - 2023-10-29 00:28:39 --> Security Class Initialized
DEBUG - 2023-10-29 00:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:28:39 --> Input Class Initialized
INFO - 2023-10-29 00:28:39 --> Language Class Initialized
INFO - 2023-10-29 00:28:39 --> Loader Class Initialized
INFO - 2023-10-29 00:28:39 --> Helper loaded: url_helper
INFO - 2023-10-29 00:28:39 --> Helper loaded: form_helper
INFO - 2023-10-29 00:28:39 --> Helper loaded: file_helper
INFO - 2023-10-29 00:28:39 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:28:39 --> Form Validation Class Initialized
INFO - 2023-10-29 00:28:39 --> Upload Class Initialized
INFO - 2023-10-29 00:28:39 --> Model "M_auth" initialized
INFO - 2023-10-29 00:28:39 --> Model "M_user" initialized
INFO - 2023-10-29 00:28:39 --> Model "M_produk" initialized
INFO - 2023-10-29 00:28:39 --> Controller Class Initialized
ERROR - 2023-10-29 00:28:39 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:28:40 --> Config Class Initialized
INFO - 2023-10-29 00:28:40 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:28:40 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:28:40 --> Utf8 Class Initialized
INFO - 2023-10-29 00:28:40 --> URI Class Initialized
INFO - 2023-10-29 00:28:40 --> Router Class Initialized
INFO - 2023-10-29 00:28:40 --> Output Class Initialized
INFO - 2023-10-29 00:28:40 --> Security Class Initialized
DEBUG - 2023-10-29 00:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:28:40 --> Input Class Initialized
INFO - 2023-10-29 00:28:40 --> Language Class Initialized
INFO - 2023-10-29 00:28:40 --> Loader Class Initialized
INFO - 2023-10-29 00:28:40 --> Helper loaded: url_helper
INFO - 2023-10-29 00:28:40 --> Helper loaded: form_helper
INFO - 2023-10-29 00:28:40 --> Helper loaded: file_helper
INFO - 2023-10-29 00:28:40 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:28:40 --> Form Validation Class Initialized
INFO - 2023-10-29 00:28:40 --> Upload Class Initialized
INFO - 2023-10-29 00:28:40 --> Model "M_auth" initialized
INFO - 2023-10-29 00:28:40 --> Model "M_user" initialized
INFO - 2023-10-29 00:28:40 --> Model "M_produk" initialized
INFO - 2023-10-29 00:28:40 --> Controller Class Initialized
INFO - 2023-10-29 00:28:40 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 00:28:40 --> Final output sent to browser
DEBUG - 2023-10-29 00:28:40 --> Total execution time: 0.0879
INFO - 2023-10-29 00:29:09 --> Config Class Initialized
INFO - 2023-10-29 00:29:09 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:29:09 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:29:09 --> Utf8 Class Initialized
INFO - 2023-10-29 00:29:09 --> URI Class Initialized
INFO - 2023-10-29 00:29:09 --> Router Class Initialized
INFO - 2023-10-29 00:29:09 --> Output Class Initialized
INFO - 2023-10-29 00:29:09 --> Security Class Initialized
DEBUG - 2023-10-29 00:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:29:09 --> Input Class Initialized
INFO - 2023-10-29 00:29:09 --> Language Class Initialized
INFO - 2023-10-29 00:29:09 --> Loader Class Initialized
INFO - 2023-10-29 00:29:09 --> Helper loaded: url_helper
INFO - 2023-10-29 00:29:09 --> Helper loaded: form_helper
INFO - 2023-10-29 00:29:09 --> Helper loaded: file_helper
INFO - 2023-10-29 00:29:09 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:29:09 --> Form Validation Class Initialized
INFO - 2023-10-29 00:29:09 --> Upload Class Initialized
INFO - 2023-10-29 00:29:09 --> Model "M_auth" initialized
INFO - 2023-10-29 00:29:09 --> Model "M_user" initialized
INFO - 2023-10-29 00:29:09 --> Model "M_produk" initialized
INFO - 2023-10-29 00:29:09 --> Controller Class Initialized
INFO - 2023-10-29 00:29:09 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 00:29:09 --> Final output sent to browser
DEBUG - 2023-10-29 00:29:09 --> Total execution time: 0.0812
INFO - 2023-10-29 00:29:11 --> Config Class Initialized
INFO - 2023-10-29 00:29:11 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:29:11 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:29:11 --> Utf8 Class Initialized
INFO - 2023-10-29 00:29:11 --> URI Class Initialized
INFO - 2023-10-29 00:29:11 --> Router Class Initialized
INFO - 2023-10-29 00:29:11 --> Output Class Initialized
INFO - 2023-10-29 00:29:11 --> Security Class Initialized
DEBUG - 2023-10-29 00:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:29:11 --> Input Class Initialized
INFO - 2023-10-29 00:29:11 --> Language Class Initialized
INFO - 2023-10-29 00:29:11 --> Loader Class Initialized
INFO - 2023-10-29 00:29:11 --> Helper loaded: url_helper
INFO - 2023-10-29 00:29:11 --> Helper loaded: form_helper
INFO - 2023-10-29 00:29:11 --> Helper loaded: file_helper
INFO - 2023-10-29 00:29:11 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:29:11 --> Form Validation Class Initialized
INFO - 2023-10-29 00:29:11 --> Upload Class Initialized
INFO - 2023-10-29 00:29:11 --> Model "M_auth" initialized
INFO - 2023-10-29 00:29:11 --> Model "M_user" initialized
INFO - 2023-10-29 00:29:11 --> Model "M_produk" initialized
INFO - 2023-10-29 00:29:11 --> Controller Class Initialized
INFO - 2023-10-29 00:29:11 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 00:29:11 --> Final output sent to browser
DEBUG - 2023-10-29 00:29:11 --> Total execution time: 0.0843
INFO - 2023-10-29 00:29:12 --> Config Class Initialized
INFO - 2023-10-29 00:29:12 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:29:12 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:29:12 --> Utf8 Class Initialized
INFO - 2023-10-29 00:29:12 --> URI Class Initialized
INFO - 2023-10-29 00:29:12 --> Router Class Initialized
INFO - 2023-10-29 00:29:12 --> Output Class Initialized
INFO - 2023-10-29 00:29:12 --> Security Class Initialized
DEBUG - 2023-10-29 00:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:29:12 --> Input Class Initialized
INFO - 2023-10-29 00:29:12 --> Language Class Initialized
INFO - 2023-10-29 00:29:12 --> Loader Class Initialized
INFO - 2023-10-29 00:29:12 --> Helper loaded: url_helper
INFO - 2023-10-29 00:29:12 --> Helper loaded: form_helper
INFO - 2023-10-29 00:29:12 --> Helper loaded: file_helper
INFO - 2023-10-29 00:29:12 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:29:12 --> Form Validation Class Initialized
INFO - 2023-10-29 00:29:12 --> Upload Class Initialized
INFO - 2023-10-29 00:29:12 --> Model "M_auth" initialized
INFO - 2023-10-29 00:29:12 --> Model "M_user" initialized
INFO - 2023-10-29 00:29:12 --> Model "M_produk" initialized
INFO - 2023-10-29 00:29:12 --> Controller Class Initialized
ERROR - 2023-10-29 00:29:12 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:30:59 --> Config Class Initialized
INFO - 2023-10-29 00:30:59 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:30:59 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:30:59 --> Utf8 Class Initialized
INFO - 2023-10-29 00:30:59 --> URI Class Initialized
INFO - 2023-10-29 00:30:59 --> Router Class Initialized
INFO - 2023-10-29 00:30:59 --> Output Class Initialized
INFO - 2023-10-29 00:30:59 --> Security Class Initialized
DEBUG - 2023-10-29 00:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:30:59 --> Input Class Initialized
INFO - 2023-10-29 00:30:59 --> Language Class Initialized
INFO - 2023-10-29 00:30:59 --> Loader Class Initialized
INFO - 2023-10-29 00:30:59 --> Helper loaded: url_helper
INFO - 2023-10-29 00:30:59 --> Helper loaded: form_helper
INFO - 2023-10-29 00:30:59 --> Helper loaded: file_helper
INFO - 2023-10-29 00:30:59 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:30:59 --> Form Validation Class Initialized
INFO - 2023-10-29 00:30:59 --> Upload Class Initialized
INFO - 2023-10-29 00:30:59 --> Model "M_auth" initialized
INFO - 2023-10-29 00:30:59 --> Model "M_user" initialized
INFO - 2023-10-29 00:30:59 --> Model "M_produk" initialized
INFO - 2023-10-29 00:30:59 --> Controller Class Initialized
ERROR - 2023-10-29 00:30:59 --> Non-existent class: Midtrans
INFO - 2023-10-29 00:31:01 --> Config Class Initialized
INFO - 2023-10-29 00:31:01 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:31:01 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:31:01 --> Utf8 Class Initialized
INFO - 2023-10-29 00:31:01 --> URI Class Initialized
INFO - 2023-10-29 00:31:01 --> Router Class Initialized
INFO - 2023-10-29 00:31:01 --> Output Class Initialized
INFO - 2023-10-29 00:31:01 --> Security Class Initialized
DEBUG - 2023-10-29 00:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:31:01 --> Input Class Initialized
INFO - 2023-10-29 00:31:01 --> Language Class Initialized
INFO - 2023-10-29 00:31:01 --> Loader Class Initialized
INFO - 2023-10-29 00:31:01 --> Helper loaded: url_helper
INFO - 2023-10-29 00:31:01 --> Helper loaded: form_helper
INFO - 2023-10-29 00:31:01 --> Helper loaded: file_helper
INFO - 2023-10-29 00:31:01 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:31:01 --> Form Validation Class Initialized
INFO - 2023-10-29 00:31:01 --> Upload Class Initialized
INFO - 2023-10-29 00:31:01 --> Model "M_auth" initialized
INFO - 2023-10-29 00:31:01 --> Model "M_user" initialized
INFO - 2023-10-29 00:31:01 --> Model "M_produk" initialized
INFO - 2023-10-29 00:31:01 --> Controller Class Initialized
INFO - 2023-10-29 00:31:01 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 00:31:01 --> Final output sent to browser
DEBUG - 2023-10-29 00:31:01 --> Total execution time: 0.0413
INFO - 2023-10-29 00:31:02 --> Config Class Initialized
INFO - 2023-10-29 00:31:02 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:31:02 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:31:02 --> Utf8 Class Initialized
INFO - 2023-10-29 00:31:02 --> URI Class Initialized
INFO - 2023-10-29 00:31:02 --> Router Class Initialized
INFO - 2023-10-29 00:31:02 --> Output Class Initialized
INFO - 2023-10-29 00:31:02 --> Security Class Initialized
DEBUG - 2023-10-29 00:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:31:02 --> Input Class Initialized
INFO - 2023-10-29 00:31:02 --> Language Class Initialized
INFO - 2023-10-29 00:31:02 --> Loader Class Initialized
INFO - 2023-10-29 00:31:02 --> Helper loaded: url_helper
INFO - 2023-10-29 00:31:02 --> Helper loaded: form_helper
INFO - 2023-10-29 00:31:02 --> Helper loaded: file_helper
INFO - 2023-10-29 00:31:02 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:31:02 --> Form Validation Class Initialized
INFO - 2023-10-29 00:31:02 --> Upload Class Initialized
INFO - 2023-10-29 00:31:02 --> Model "M_auth" initialized
INFO - 2023-10-29 00:31:02 --> Model "M_user" initialized
INFO - 2023-10-29 00:31:02 --> Model "M_produk" initialized
INFO - 2023-10-29 00:31:02 --> Controller Class Initialized
ERROR - 2023-10-29 00:31:02 --> Non-existent class: Midtrans
INFO - 2023-10-29 00:31:11 --> Config Class Initialized
INFO - 2023-10-29 00:31:11 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:31:11 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:31:11 --> Utf8 Class Initialized
INFO - 2023-10-29 00:31:11 --> URI Class Initialized
INFO - 2023-10-29 00:31:11 --> Router Class Initialized
INFO - 2023-10-29 00:31:11 --> Output Class Initialized
INFO - 2023-10-29 00:31:11 --> Security Class Initialized
DEBUG - 2023-10-29 00:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:31:11 --> Input Class Initialized
INFO - 2023-10-29 00:31:11 --> Language Class Initialized
INFO - 2023-10-29 00:31:11 --> Loader Class Initialized
INFO - 2023-10-29 00:31:11 --> Helper loaded: url_helper
INFO - 2023-10-29 00:31:11 --> Helper loaded: form_helper
INFO - 2023-10-29 00:31:11 --> Helper loaded: file_helper
INFO - 2023-10-29 00:31:11 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:31:11 --> Form Validation Class Initialized
INFO - 2023-10-29 00:31:11 --> Upload Class Initialized
INFO - 2023-10-29 00:31:11 --> Model "M_auth" initialized
INFO - 2023-10-29 00:31:11 --> Model "M_user" initialized
INFO - 2023-10-29 00:31:11 --> Model "M_produk" initialized
INFO - 2023-10-29 00:31:11 --> Controller Class Initialized
ERROR - 2023-10-29 00:31:11 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:35:21 --> Config Class Initialized
INFO - 2023-10-29 00:35:21 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:35:21 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:35:21 --> Utf8 Class Initialized
INFO - 2023-10-29 00:35:21 --> URI Class Initialized
INFO - 2023-10-29 00:35:21 --> Router Class Initialized
INFO - 2023-10-29 00:35:21 --> Output Class Initialized
INFO - 2023-10-29 00:35:21 --> Security Class Initialized
DEBUG - 2023-10-29 00:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:35:21 --> Input Class Initialized
INFO - 2023-10-29 00:35:21 --> Language Class Initialized
INFO - 2023-10-29 00:35:21 --> Loader Class Initialized
INFO - 2023-10-29 00:35:21 --> Helper loaded: url_helper
INFO - 2023-10-29 00:35:21 --> Helper loaded: form_helper
INFO - 2023-10-29 00:35:21 --> Helper loaded: file_helper
INFO - 2023-10-29 00:35:21 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:35:21 --> Form Validation Class Initialized
INFO - 2023-10-29 00:35:21 --> Upload Class Initialized
INFO - 2023-10-29 00:35:21 --> Model "M_auth" initialized
INFO - 2023-10-29 00:35:21 --> Model "M_user" initialized
INFO - 2023-10-29 00:35:21 --> Model "M_produk" initialized
INFO - 2023-10-29 00:35:21 --> Controller Class Initialized
ERROR - 2023-10-29 00:35:21 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:35:33 --> Config Class Initialized
INFO - 2023-10-29 00:35:33 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:35:33 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:35:33 --> Utf8 Class Initialized
INFO - 2023-10-29 00:35:33 --> URI Class Initialized
INFO - 2023-10-29 00:35:33 --> Router Class Initialized
INFO - 2023-10-29 00:35:33 --> Output Class Initialized
INFO - 2023-10-29 00:35:33 --> Security Class Initialized
DEBUG - 2023-10-29 00:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:35:33 --> Input Class Initialized
INFO - 2023-10-29 00:35:33 --> Language Class Initialized
INFO - 2023-10-29 00:35:33 --> Loader Class Initialized
INFO - 2023-10-29 00:35:33 --> Helper loaded: url_helper
INFO - 2023-10-29 00:35:33 --> Helper loaded: form_helper
INFO - 2023-10-29 00:35:33 --> Helper loaded: file_helper
INFO - 2023-10-29 00:35:33 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:35:33 --> Form Validation Class Initialized
INFO - 2023-10-29 00:35:33 --> Upload Class Initialized
INFO - 2023-10-29 00:35:33 --> Model "M_auth" initialized
INFO - 2023-10-29 00:35:33 --> Model "M_user" initialized
INFO - 2023-10-29 00:35:33 --> Model "M_produk" initialized
INFO - 2023-10-29 00:35:33 --> Controller Class Initialized
ERROR - 2023-10-29 00:35:33 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:35:35 --> Config Class Initialized
INFO - 2023-10-29 00:35:35 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:35:35 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:35:35 --> Utf8 Class Initialized
INFO - 2023-10-29 00:35:35 --> URI Class Initialized
INFO - 2023-10-29 00:35:35 --> Router Class Initialized
INFO - 2023-10-29 00:35:35 --> Output Class Initialized
INFO - 2023-10-29 00:35:35 --> Security Class Initialized
DEBUG - 2023-10-29 00:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:35:35 --> Input Class Initialized
INFO - 2023-10-29 00:35:35 --> Language Class Initialized
INFO - 2023-10-29 00:35:35 --> Loader Class Initialized
INFO - 2023-10-29 00:35:35 --> Helper loaded: url_helper
INFO - 2023-10-29 00:35:35 --> Helper loaded: form_helper
INFO - 2023-10-29 00:35:35 --> Helper loaded: file_helper
INFO - 2023-10-29 00:35:35 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:35:35 --> Form Validation Class Initialized
INFO - 2023-10-29 00:35:35 --> Upload Class Initialized
INFO - 2023-10-29 00:35:35 --> Model "M_auth" initialized
INFO - 2023-10-29 00:35:35 --> Model "M_user" initialized
INFO - 2023-10-29 00:35:35 --> Model "M_produk" initialized
INFO - 2023-10-29 00:35:35 --> Controller Class Initialized
ERROR - 2023-10-29 00:35:35 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:35:42 --> Config Class Initialized
INFO - 2023-10-29 00:35:42 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:35:42 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:35:42 --> Utf8 Class Initialized
INFO - 2023-10-29 00:35:42 --> URI Class Initialized
INFO - 2023-10-29 00:35:42 --> Router Class Initialized
INFO - 2023-10-29 00:35:42 --> Output Class Initialized
INFO - 2023-10-29 00:35:42 --> Security Class Initialized
DEBUG - 2023-10-29 00:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:35:42 --> Input Class Initialized
INFO - 2023-10-29 00:35:42 --> Language Class Initialized
INFO - 2023-10-29 00:35:42 --> Loader Class Initialized
INFO - 2023-10-29 00:35:42 --> Helper loaded: url_helper
INFO - 2023-10-29 00:35:42 --> Helper loaded: form_helper
INFO - 2023-10-29 00:35:42 --> Helper loaded: file_helper
INFO - 2023-10-29 00:35:42 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:35:42 --> Form Validation Class Initialized
INFO - 2023-10-29 00:35:42 --> Upload Class Initialized
INFO - 2023-10-29 00:35:42 --> Model "M_auth" initialized
INFO - 2023-10-29 00:35:42 --> Model "M_user" initialized
INFO - 2023-10-29 00:35:42 --> Model "M_produk" initialized
INFO - 2023-10-29 00:35:42 --> Controller Class Initialized
ERROR - 2023-10-29 00:35:42 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:35:52 --> Config Class Initialized
INFO - 2023-10-29 00:35:52 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:35:52 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:35:52 --> Utf8 Class Initialized
INFO - 2023-10-29 00:35:52 --> URI Class Initialized
INFO - 2023-10-29 00:35:52 --> Router Class Initialized
INFO - 2023-10-29 00:35:52 --> Output Class Initialized
INFO - 2023-10-29 00:35:52 --> Security Class Initialized
DEBUG - 2023-10-29 00:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:35:52 --> Input Class Initialized
INFO - 2023-10-29 00:35:52 --> Language Class Initialized
INFO - 2023-10-29 00:35:52 --> Loader Class Initialized
INFO - 2023-10-29 00:35:52 --> Helper loaded: url_helper
INFO - 2023-10-29 00:35:52 --> Helper loaded: form_helper
INFO - 2023-10-29 00:35:52 --> Helper loaded: file_helper
INFO - 2023-10-29 00:35:52 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:35:52 --> Form Validation Class Initialized
INFO - 2023-10-29 00:35:52 --> Upload Class Initialized
INFO - 2023-10-29 00:35:52 --> Model "M_auth" initialized
INFO - 2023-10-29 00:35:52 --> Model "M_user" initialized
INFO - 2023-10-29 00:35:52 --> Model "M_produk" initialized
INFO - 2023-10-29 00:35:52 --> Controller Class Initialized
ERROR - 2023-10-29 00:35:52 --> Non-existent class: Midtrans
INFO - 2023-10-29 00:36:03 --> Config Class Initialized
INFO - 2023-10-29 00:36:03 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:36:03 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:36:03 --> Utf8 Class Initialized
INFO - 2023-10-29 00:36:03 --> URI Class Initialized
INFO - 2023-10-29 00:36:03 --> Router Class Initialized
INFO - 2023-10-29 00:36:03 --> Output Class Initialized
INFO - 2023-10-29 00:36:03 --> Security Class Initialized
DEBUG - 2023-10-29 00:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:36:03 --> Input Class Initialized
INFO - 2023-10-29 00:36:03 --> Language Class Initialized
INFO - 2023-10-29 00:36:03 --> Loader Class Initialized
INFO - 2023-10-29 00:36:03 --> Helper loaded: url_helper
INFO - 2023-10-29 00:36:03 --> Helper loaded: form_helper
INFO - 2023-10-29 00:36:03 --> Helper loaded: file_helper
INFO - 2023-10-29 00:36:03 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:36:03 --> Form Validation Class Initialized
INFO - 2023-10-29 00:36:03 --> Upload Class Initialized
INFO - 2023-10-29 00:36:03 --> Model "M_auth" initialized
INFO - 2023-10-29 00:36:03 --> Model "M_user" initialized
INFO - 2023-10-29 00:36:03 --> Model "M_produk" initialized
INFO - 2023-10-29 00:36:03 --> Controller Class Initialized
ERROR - 2023-10-29 00:36:03 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:36:11 --> Config Class Initialized
INFO - 2023-10-29 00:36:11 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:36:11 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:36:11 --> Utf8 Class Initialized
INFO - 2023-10-29 00:36:11 --> URI Class Initialized
INFO - 2023-10-29 00:36:11 --> Router Class Initialized
INFO - 2023-10-29 00:36:11 --> Output Class Initialized
INFO - 2023-10-29 00:36:11 --> Security Class Initialized
DEBUG - 2023-10-29 00:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:36:11 --> Input Class Initialized
INFO - 2023-10-29 00:36:11 --> Language Class Initialized
INFO - 2023-10-29 00:36:11 --> Loader Class Initialized
INFO - 2023-10-29 00:36:11 --> Helper loaded: url_helper
INFO - 2023-10-29 00:36:11 --> Helper loaded: form_helper
INFO - 2023-10-29 00:36:11 --> Helper loaded: file_helper
INFO - 2023-10-29 00:36:11 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:36:11 --> Form Validation Class Initialized
INFO - 2023-10-29 00:36:11 --> Upload Class Initialized
INFO - 2023-10-29 00:36:11 --> Model "M_auth" initialized
INFO - 2023-10-29 00:36:11 --> Model "M_user" initialized
INFO - 2023-10-29 00:36:11 --> Model "M_produk" initialized
INFO - 2023-10-29 00:36:11 --> Controller Class Initialized
INFO - 2023-10-29 00:36:11 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 00:36:11 --> Final output sent to browser
DEBUG - 2023-10-29 00:36:11 --> Total execution time: 0.0877
INFO - 2023-10-29 00:36:20 --> Config Class Initialized
INFO - 2023-10-29 00:36:20 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:36:20 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:36:20 --> Utf8 Class Initialized
INFO - 2023-10-29 00:36:20 --> URI Class Initialized
INFO - 2023-10-29 00:36:20 --> Router Class Initialized
INFO - 2023-10-29 00:36:20 --> Output Class Initialized
INFO - 2023-10-29 00:36:20 --> Security Class Initialized
DEBUG - 2023-10-29 00:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:36:20 --> Input Class Initialized
INFO - 2023-10-29 00:36:20 --> Language Class Initialized
INFO - 2023-10-29 00:36:20 --> Loader Class Initialized
INFO - 2023-10-29 00:36:20 --> Helper loaded: url_helper
INFO - 2023-10-29 00:36:20 --> Helper loaded: form_helper
INFO - 2023-10-29 00:36:20 --> Helper loaded: file_helper
INFO - 2023-10-29 00:36:20 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:36:20 --> Form Validation Class Initialized
INFO - 2023-10-29 00:36:20 --> Upload Class Initialized
INFO - 2023-10-29 00:36:20 --> Model "M_auth" initialized
INFO - 2023-10-29 00:36:20 --> Model "M_user" initialized
INFO - 2023-10-29 00:36:20 --> Model "M_produk" initialized
INFO - 2023-10-29 00:36:20 --> Controller Class Initialized
ERROR - 2023-10-29 00:36:20 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:37:58 --> Config Class Initialized
INFO - 2023-10-29 00:37:58 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:37:58 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:37:58 --> Utf8 Class Initialized
INFO - 2023-10-29 00:37:58 --> URI Class Initialized
INFO - 2023-10-29 00:37:58 --> Router Class Initialized
INFO - 2023-10-29 00:37:58 --> Output Class Initialized
INFO - 2023-10-29 00:37:58 --> Security Class Initialized
DEBUG - 2023-10-29 00:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:37:58 --> Input Class Initialized
INFO - 2023-10-29 00:37:58 --> Language Class Initialized
INFO - 2023-10-29 00:37:58 --> Loader Class Initialized
INFO - 2023-10-29 00:37:58 --> Helper loaded: url_helper
INFO - 2023-10-29 00:37:58 --> Helper loaded: form_helper
INFO - 2023-10-29 00:37:58 --> Helper loaded: file_helper
INFO - 2023-10-29 00:37:58 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:37:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:37:58 --> Form Validation Class Initialized
INFO - 2023-10-29 00:37:58 --> Upload Class Initialized
INFO - 2023-10-29 00:37:58 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:37:58 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:41:11 --> Config Class Initialized
INFO - 2023-10-29 00:41:11 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:41:11 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:41:11 --> Utf8 Class Initialized
INFO - 2023-10-29 00:41:11 --> URI Class Initialized
INFO - 2023-10-29 00:41:11 --> Router Class Initialized
INFO - 2023-10-29 00:41:11 --> Output Class Initialized
INFO - 2023-10-29 00:41:11 --> Security Class Initialized
DEBUG - 2023-10-29 00:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:41:11 --> Input Class Initialized
INFO - 2023-10-29 00:41:11 --> Language Class Initialized
INFO - 2023-10-29 00:41:11 --> Loader Class Initialized
INFO - 2023-10-29 00:41:11 --> Helper loaded: url_helper
INFO - 2023-10-29 00:41:11 --> Helper loaded: form_helper
INFO - 2023-10-29 00:41:11 --> Helper loaded: file_helper
INFO - 2023-10-29 00:41:11 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:41:11 --> Form Validation Class Initialized
INFO - 2023-10-29 00:41:11 --> Upload Class Initialized
INFO - 2023-10-29 00:41:11 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:41:11 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:42:58 --> Config Class Initialized
INFO - 2023-10-29 00:42:58 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:42:58 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:42:58 --> Utf8 Class Initialized
INFO - 2023-10-29 00:42:58 --> URI Class Initialized
INFO - 2023-10-29 00:42:58 --> Router Class Initialized
INFO - 2023-10-29 00:42:58 --> Output Class Initialized
INFO - 2023-10-29 00:42:58 --> Security Class Initialized
DEBUG - 2023-10-29 00:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:42:58 --> Input Class Initialized
INFO - 2023-10-29 00:42:58 --> Language Class Initialized
INFO - 2023-10-29 00:42:58 --> Loader Class Initialized
INFO - 2023-10-29 00:42:58 --> Helper loaded: url_helper
INFO - 2023-10-29 00:42:58 --> Helper loaded: form_helper
INFO - 2023-10-29 00:42:58 --> Helper loaded: file_helper
INFO - 2023-10-29 00:42:58 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:42:58 --> Form Validation Class Initialized
INFO - 2023-10-29 00:42:58 --> Upload Class Initialized
INFO - 2023-10-29 00:42:58 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:42:58 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:45:45 --> Config Class Initialized
INFO - 2023-10-29 00:45:45 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:45:45 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:45:45 --> Utf8 Class Initialized
INFO - 2023-10-29 00:45:45 --> URI Class Initialized
INFO - 2023-10-29 00:45:45 --> Router Class Initialized
INFO - 2023-10-29 00:45:45 --> Output Class Initialized
INFO - 2023-10-29 00:45:45 --> Security Class Initialized
DEBUG - 2023-10-29 00:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:45:45 --> Input Class Initialized
INFO - 2023-10-29 00:45:45 --> Language Class Initialized
INFO - 2023-10-29 00:45:45 --> Loader Class Initialized
INFO - 2023-10-29 00:45:45 --> Helper loaded: url_helper
INFO - 2023-10-29 00:45:45 --> Helper loaded: form_helper
INFO - 2023-10-29 00:45:45 --> Helper loaded: file_helper
INFO - 2023-10-29 00:45:45 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:45:45 --> Form Validation Class Initialized
INFO - 2023-10-29 00:45:45 --> Upload Class Initialized
INFO - 2023-10-29 00:45:45 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:45:45 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:45:53 --> Config Class Initialized
INFO - 2023-10-29 00:45:53 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:45:53 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:45:53 --> Utf8 Class Initialized
INFO - 2023-10-29 00:45:53 --> URI Class Initialized
DEBUG - 2023-10-29 00:45:53 --> No URI present. Default controller set.
INFO - 2023-10-29 00:45:53 --> Router Class Initialized
INFO - 2023-10-29 00:45:53 --> Output Class Initialized
INFO - 2023-10-29 00:45:53 --> Security Class Initialized
DEBUG - 2023-10-29 00:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:45:53 --> Input Class Initialized
INFO - 2023-10-29 00:45:53 --> Language Class Initialized
INFO - 2023-10-29 00:45:53 --> Loader Class Initialized
INFO - 2023-10-29 00:45:53 --> Helper loaded: url_helper
INFO - 2023-10-29 00:45:53 --> Helper loaded: form_helper
INFO - 2023-10-29 00:45:53 --> Helper loaded: file_helper
INFO - 2023-10-29 00:45:53 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:45:53 --> Form Validation Class Initialized
INFO - 2023-10-29 00:45:53 --> Upload Class Initialized
INFO - 2023-10-29 00:45:53 --> Model "M_auth" initialized
INFO - 2023-10-29 00:45:53 --> Model "M_user" initialized
INFO - 2023-10-29 00:45:53 --> Model "M_produk" initialized
INFO - 2023-10-29 00:45:53 --> Controller Class Initialized
INFO - 2023-10-29 00:45:53 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 00:45:53 --> Model "M_produk" initialized
DEBUG - 2023-10-29 00:45:53 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 00:45:53 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 00:45:53 --> Model "M_transaksi" initialized
INFO - 2023-10-29 00:45:53 --> Model "M_bank" initialized
INFO - 2023-10-29 00:45:53 --> Model "M_pesan" initialized
INFO - 2023-10-29 00:45:53 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-29 00:45:53 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-29 00:45:53 --> Final output sent to browser
DEBUG - 2023-10-29 00:45:53 --> Total execution time: 0.0660
INFO - 2023-10-29 00:46:05 --> Config Class Initialized
INFO - 2023-10-29 00:46:05 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:46:05 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:46:05 --> Utf8 Class Initialized
INFO - 2023-10-29 00:46:05 --> URI Class Initialized
INFO - 2023-10-29 00:46:05 --> Router Class Initialized
INFO - 2023-10-29 00:46:05 --> Output Class Initialized
INFO - 2023-10-29 00:46:05 --> Security Class Initialized
DEBUG - 2023-10-29 00:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:46:05 --> Input Class Initialized
INFO - 2023-10-29 00:46:05 --> Language Class Initialized
INFO - 2023-10-29 00:46:05 --> Loader Class Initialized
INFO - 2023-10-29 00:46:05 --> Helper loaded: url_helper
INFO - 2023-10-29 00:46:05 --> Helper loaded: form_helper
INFO - 2023-10-29 00:46:05 --> Helper loaded: file_helper
INFO - 2023-10-29 00:46:05 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:46:05 --> Form Validation Class Initialized
INFO - 2023-10-29 00:46:05 --> Upload Class Initialized
INFO - 2023-10-29 00:46:05 --> Model "M_auth" initialized
INFO - 2023-10-29 00:46:05 --> Model "M_user" initialized
INFO - 2023-10-29 00:46:05 --> Model "M_produk" initialized
INFO - 2023-10-29 00:46:05 --> Controller Class Initialized
INFO - 2023-10-29 00:46:05 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 00:46:05 --> Model "M_produk" initialized
DEBUG - 2023-10-29 00:46:05 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 00:46:05 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 00:46:05 --> Model "M_transaksi" initialized
INFO - 2023-10-29 00:46:05 --> Model "M_bank" initialized
INFO - 2023-10-29 00:46:05 --> Model "M_pesan" initialized
INFO - 2023-10-29 00:46:05 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-29 00:46:05 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_produk_detail.php
INFO - 2023-10-29 00:46:05 --> Final output sent to browser
DEBUG - 2023-10-29 00:46:05 --> Total execution time: 0.1113
INFO - 2023-10-29 00:46:05 --> Config Class Initialized
INFO - 2023-10-29 00:46:05 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:46:05 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:46:05 --> Utf8 Class Initialized
INFO - 2023-10-29 00:46:05 --> URI Class Initialized
INFO - 2023-10-29 00:46:05 --> Router Class Initialized
INFO - 2023-10-29 00:46:05 --> Output Class Initialized
INFO - 2023-10-29 00:46:05 --> Security Class Initialized
DEBUG - 2023-10-29 00:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:46:05 --> Input Class Initialized
INFO - 2023-10-29 00:46:05 --> Language Class Initialized
INFO - 2023-10-29 00:46:05 --> Loader Class Initialized
INFO - 2023-10-29 00:46:05 --> Helper loaded: url_helper
INFO - 2023-10-29 00:46:05 --> Helper loaded: form_helper
INFO - 2023-10-29 00:46:05 --> Helper loaded: file_helper
INFO - 2023-10-29 00:46:05 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:46:05 --> Form Validation Class Initialized
INFO - 2023-10-29 00:46:05 --> Upload Class Initialized
INFO - 2023-10-29 00:46:05 --> Model "M_auth" initialized
INFO - 2023-10-29 00:46:05 --> Model "M_user" initialized
INFO - 2023-10-29 00:46:05 --> Model "M_produk" initialized
INFO - 2023-10-29 00:46:05 --> Controller Class Initialized
INFO - 2023-10-29 00:46:05 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-10-29 00:46:05 --> Final output sent to browser
DEBUG - 2023-10-29 00:46:05 --> Total execution time: 0.0225
INFO - 2023-10-29 00:46:11 --> Config Class Initialized
INFO - 2023-10-29 00:46:11 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:46:11 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:46:11 --> Utf8 Class Initialized
INFO - 2023-10-29 00:46:11 --> URI Class Initialized
DEBUG - 2023-10-29 00:46:11 --> No URI present. Default controller set.
INFO - 2023-10-29 00:46:11 --> Router Class Initialized
INFO - 2023-10-29 00:46:11 --> Output Class Initialized
INFO - 2023-10-29 00:46:11 --> Security Class Initialized
DEBUG - 2023-10-29 00:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:46:11 --> Input Class Initialized
INFO - 2023-10-29 00:46:11 --> Language Class Initialized
INFO - 2023-10-29 00:46:11 --> Loader Class Initialized
INFO - 2023-10-29 00:46:11 --> Helper loaded: url_helper
INFO - 2023-10-29 00:46:11 --> Helper loaded: form_helper
INFO - 2023-10-29 00:46:11 --> Helper loaded: file_helper
INFO - 2023-10-29 00:46:11 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:46:11 --> Form Validation Class Initialized
INFO - 2023-10-29 00:46:11 --> Upload Class Initialized
INFO - 2023-10-29 00:46:11 --> Model "M_auth" initialized
INFO - 2023-10-29 00:46:11 --> Model "M_user" initialized
INFO - 2023-10-29 00:46:11 --> Model "M_produk" initialized
INFO - 2023-10-29 00:46:11 --> Controller Class Initialized
INFO - 2023-10-29 00:46:11 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 00:46:11 --> Model "M_produk" initialized
DEBUG - 2023-10-29 00:46:11 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 00:46:11 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 00:46:11 --> Model "M_transaksi" initialized
INFO - 2023-10-29 00:46:11 --> Model "M_bank" initialized
INFO - 2023-10-29 00:46:11 --> Model "M_pesan" initialized
INFO - 2023-10-29 00:46:11 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-29 00:46:11 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-29 00:46:11 --> Final output sent to browser
DEBUG - 2023-10-29 00:46:11 --> Total execution time: 0.1090
INFO - 2023-10-29 00:46:15 --> Config Class Initialized
INFO - 2023-10-29 00:46:15 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:46:15 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:46:15 --> Utf8 Class Initialized
INFO - 2023-10-29 00:46:15 --> URI Class Initialized
INFO - 2023-10-29 00:46:15 --> Router Class Initialized
INFO - 2023-10-29 00:46:15 --> Output Class Initialized
INFO - 2023-10-29 00:46:15 --> Security Class Initialized
DEBUG - 2023-10-29 00:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:46:15 --> Input Class Initialized
INFO - 2023-10-29 00:46:15 --> Language Class Initialized
INFO - 2023-10-29 00:46:15 --> Loader Class Initialized
INFO - 2023-10-29 00:46:15 --> Helper loaded: url_helper
INFO - 2023-10-29 00:46:15 --> Helper loaded: form_helper
INFO - 2023-10-29 00:46:15 --> Helper loaded: file_helper
INFO - 2023-10-29 00:46:15 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:46:15 --> Form Validation Class Initialized
INFO - 2023-10-29 00:46:15 --> Upload Class Initialized
INFO - 2023-10-29 00:46:15 --> Model "M_auth" initialized
INFO - 2023-10-29 00:46:15 --> Model "M_user" initialized
INFO - 2023-10-29 00:46:15 --> Model "M_produk" initialized
INFO - 2023-10-29 00:46:15 --> Controller Class Initialized
INFO - 2023-10-29 00:46:15 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 00:46:15 --> Final output sent to browser
DEBUG - 2023-10-29 00:46:15 --> Total execution time: 0.0526
INFO - 2023-10-29 00:46:22 --> Config Class Initialized
INFO - 2023-10-29 00:46:22 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:46:22 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:46:22 --> Utf8 Class Initialized
INFO - 2023-10-29 00:46:22 --> URI Class Initialized
INFO - 2023-10-29 00:46:22 --> Router Class Initialized
INFO - 2023-10-29 00:46:22 --> Output Class Initialized
INFO - 2023-10-29 00:46:22 --> Security Class Initialized
DEBUG - 2023-10-29 00:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:46:22 --> Input Class Initialized
INFO - 2023-10-29 00:46:22 --> Language Class Initialized
INFO - 2023-10-29 00:46:22 --> Loader Class Initialized
INFO - 2023-10-29 00:46:22 --> Helper loaded: url_helper
INFO - 2023-10-29 00:46:22 --> Helper loaded: form_helper
INFO - 2023-10-29 00:46:22 --> Helper loaded: file_helper
INFO - 2023-10-29 00:46:22 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:46:22 --> Form Validation Class Initialized
INFO - 2023-10-29 00:46:22 --> Upload Class Initialized
INFO - 2023-10-29 00:46:22 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:46:22 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:46:58 --> Config Class Initialized
INFO - 2023-10-29 00:46:58 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:46:58 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:46:58 --> Utf8 Class Initialized
INFO - 2023-10-29 00:46:58 --> URI Class Initialized
INFO - 2023-10-29 00:46:58 --> Router Class Initialized
INFO - 2023-10-29 00:46:58 --> Output Class Initialized
INFO - 2023-10-29 00:46:58 --> Security Class Initialized
DEBUG - 2023-10-29 00:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:46:58 --> Input Class Initialized
INFO - 2023-10-29 00:46:58 --> Language Class Initialized
INFO - 2023-10-29 00:46:58 --> Loader Class Initialized
INFO - 2023-10-29 00:46:58 --> Helper loaded: url_helper
INFO - 2023-10-29 00:46:58 --> Helper loaded: form_helper
INFO - 2023-10-29 00:46:58 --> Helper loaded: file_helper
INFO - 2023-10-29 00:46:58 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:46:58 --> Form Validation Class Initialized
INFO - 2023-10-29 00:46:58 --> Upload Class Initialized
INFO - 2023-10-29 00:46:58 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:46:58 --> Severity: Warning --> require_once(Midtrans/Config.php): Failed to open stream: No such file or directory C:\xampp\htdocs\4_aan\semakar_adventure\application\libraries\Midtrans.php 18
ERROR - 2023-10-29 00:46:59 --> Severity: error --> Exception: Failed opening required 'Midtrans/Config.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\4_aan\semakar_adventure\application\libraries\Midtrans.php 18
INFO - 2023-10-29 00:47:16 --> Config Class Initialized
INFO - 2023-10-29 00:47:16 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:47:16 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:47:16 --> Utf8 Class Initialized
INFO - 2023-10-29 00:47:16 --> URI Class Initialized
INFO - 2023-10-29 00:47:16 --> Router Class Initialized
INFO - 2023-10-29 00:47:16 --> Output Class Initialized
INFO - 2023-10-29 00:47:16 --> Security Class Initialized
DEBUG - 2023-10-29 00:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:47:16 --> Input Class Initialized
INFO - 2023-10-29 00:47:16 --> Language Class Initialized
INFO - 2023-10-29 00:47:16 --> Loader Class Initialized
INFO - 2023-10-29 00:47:16 --> Helper loaded: url_helper
INFO - 2023-10-29 00:47:16 --> Helper loaded: form_helper
INFO - 2023-10-29 00:47:16 --> Helper loaded: file_helper
INFO - 2023-10-29 00:47:16 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:47:16 --> Form Validation Class Initialized
INFO - 2023-10-29 00:47:16 --> Upload Class Initialized
INFO - 2023-10-29 00:47:16 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:47:16 --> Severity: Warning --> require_once(Midtrans/Config.php): Failed to open stream: No such file or directory C:\xampp\htdocs\4_aan\semakar_adventure\application\libraries\Midtrans.php 18
ERROR - 2023-10-29 00:47:16 --> Severity: error --> Exception: Failed opening required 'Midtrans/Config.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\4_aan\semakar_adventure\application\libraries\Midtrans.php 18
INFO - 2023-10-29 00:48:13 --> Config Class Initialized
INFO - 2023-10-29 00:48:13 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:48:13 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:48:13 --> Utf8 Class Initialized
INFO - 2023-10-29 00:48:13 --> URI Class Initialized
INFO - 2023-10-29 00:48:13 --> Router Class Initialized
INFO - 2023-10-29 00:48:13 --> Output Class Initialized
INFO - 2023-10-29 00:48:13 --> Security Class Initialized
DEBUG - 2023-10-29 00:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:48:13 --> Input Class Initialized
INFO - 2023-10-29 00:48:13 --> Language Class Initialized
INFO - 2023-10-29 00:48:13 --> Loader Class Initialized
INFO - 2023-10-29 00:48:13 --> Helper loaded: url_helper
INFO - 2023-10-29 00:48:13 --> Helper loaded: form_helper
INFO - 2023-10-29 00:48:13 --> Helper loaded: file_helper
INFO - 2023-10-29 00:48:13 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:48:13 --> Form Validation Class Initialized
INFO - 2023-10-29 00:48:13 --> Upload Class Initialized
INFO - 2023-10-29 00:48:13 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:48:13 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:48:25 --> Config Class Initialized
INFO - 2023-10-29 00:48:25 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:48:25 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:48:25 --> Utf8 Class Initialized
INFO - 2023-10-29 00:48:25 --> URI Class Initialized
INFO - 2023-10-29 00:48:25 --> Router Class Initialized
INFO - 2023-10-29 00:48:25 --> Output Class Initialized
INFO - 2023-10-29 00:48:25 --> Security Class Initialized
DEBUG - 2023-10-29 00:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:48:25 --> Input Class Initialized
INFO - 2023-10-29 00:48:25 --> Language Class Initialized
INFO - 2023-10-29 00:48:25 --> Loader Class Initialized
INFO - 2023-10-29 00:48:25 --> Helper loaded: url_helper
INFO - 2023-10-29 00:48:25 --> Helper loaded: form_helper
INFO - 2023-10-29 00:48:25 --> Helper loaded: file_helper
INFO - 2023-10-29 00:48:25 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:48:25 --> Form Validation Class Initialized
INFO - 2023-10-29 00:48:25 --> Upload Class Initialized
INFO - 2023-10-29 00:48:25 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:48:25 --> Unable to load the requested class: Midtrans-php
INFO - 2023-10-29 00:48:30 --> Config Class Initialized
INFO - 2023-10-29 00:48:30 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:48:30 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:48:30 --> Utf8 Class Initialized
INFO - 2023-10-29 00:48:30 --> URI Class Initialized
INFO - 2023-10-29 00:48:30 --> Router Class Initialized
INFO - 2023-10-29 00:48:30 --> Output Class Initialized
INFO - 2023-10-29 00:48:30 --> Security Class Initialized
DEBUG - 2023-10-29 00:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:48:30 --> Input Class Initialized
INFO - 2023-10-29 00:48:30 --> Language Class Initialized
INFO - 2023-10-29 00:48:30 --> Loader Class Initialized
INFO - 2023-10-29 00:48:30 --> Helper loaded: url_helper
INFO - 2023-10-29 00:48:30 --> Helper loaded: form_helper
INFO - 2023-10-29 00:48:30 --> Helper loaded: file_helper
INFO - 2023-10-29 00:48:30 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:48:30 --> Form Validation Class Initialized
INFO - 2023-10-29 00:48:30 --> Upload Class Initialized
INFO - 2023-10-29 00:48:30 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:48:30 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:48:44 --> Config Class Initialized
INFO - 2023-10-29 00:48:44 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:48:44 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:48:44 --> Utf8 Class Initialized
INFO - 2023-10-29 00:48:44 --> URI Class Initialized
INFO - 2023-10-29 00:48:44 --> Router Class Initialized
INFO - 2023-10-29 00:48:44 --> Output Class Initialized
INFO - 2023-10-29 00:48:44 --> Security Class Initialized
DEBUG - 2023-10-29 00:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:48:44 --> Input Class Initialized
INFO - 2023-10-29 00:48:44 --> Language Class Initialized
INFO - 2023-10-29 00:48:44 --> Loader Class Initialized
INFO - 2023-10-29 00:48:44 --> Helper loaded: url_helper
INFO - 2023-10-29 00:48:44 --> Helper loaded: form_helper
INFO - 2023-10-29 00:48:44 --> Helper loaded: file_helper
INFO - 2023-10-29 00:48:44 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:48:44 --> Form Validation Class Initialized
INFO - 2023-10-29 00:48:44 --> Upload Class Initialized
INFO - 2023-10-29 00:48:44 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:48:44 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:48:45 --> Config Class Initialized
INFO - 2023-10-29 00:48:45 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:48:45 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:48:45 --> Utf8 Class Initialized
INFO - 2023-10-29 00:48:45 --> URI Class Initialized
INFO - 2023-10-29 00:48:45 --> Router Class Initialized
INFO - 2023-10-29 00:48:45 --> Output Class Initialized
INFO - 2023-10-29 00:48:45 --> Security Class Initialized
DEBUG - 2023-10-29 00:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:48:45 --> Input Class Initialized
INFO - 2023-10-29 00:48:45 --> Language Class Initialized
INFO - 2023-10-29 00:48:45 --> Loader Class Initialized
INFO - 2023-10-29 00:48:45 --> Helper loaded: url_helper
INFO - 2023-10-29 00:48:45 --> Helper loaded: form_helper
INFO - 2023-10-29 00:48:45 --> Helper loaded: file_helper
INFO - 2023-10-29 00:48:45 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:48:45 --> Form Validation Class Initialized
INFO - 2023-10-29 00:48:45 --> Upload Class Initialized
INFO - 2023-10-29 00:48:45 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:48:45 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:48:45 --> Config Class Initialized
INFO - 2023-10-29 00:48:45 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:48:45 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:48:45 --> Utf8 Class Initialized
INFO - 2023-10-29 00:48:45 --> URI Class Initialized
INFO - 2023-10-29 00:48:45 --> Router Class Initialized
INFO - 2023-10-29 00:48:45 --> Output Class Initialized
INFO - 2023-10-29 00:48:45 --> Security Class Initialized
DEBUG - 2023-10-29 00:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:48:45 --> Input Class Initialized
INFO - 2023-10-29 00:48:45 --> Language Class Initialized
INFO - 2023-10-29 00:48:45 --> Loader Class Initialized
INFO - 2023-10-29 00:48:45 --> Helper loaded: url_helper
INFO - 2023-10-29 00:48:45 --> Helper loaded: form_helper
INFO - 2023-10-29 00:48:45 --> Helper loaded: file_helper
INFO - 2023-10-29 00:48:45 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:48:45 --> Form Validation Class Initialized
INFO - 2023-10-29 00:48:45 --> Upload Class Initialized
INFO - 2023-10-29 00:48:45 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:48:45 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:48:46 --> Config Class Initialized
INFO - 2023-10-29 00:48:46 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:48:46 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:48:46 --> Utf8 Class Initialized
INFO - 2023-10-29 00:48:46 --> URI Class Initialized
INFO - 2023-10-29 00:48:46 --> Router Class Initialized
INFO - 2023-10-29 00:48:46 --> Output Class Initialized
INFO - 2023-10-29 00:48:46 --> Security Class Initialized
DEBUG - 2023-10-29 00:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:48:46 --> Input Class Initialized
INFO - 2023-10-29 00:48:46 --> Language Class Initialized
INFO - 2023-10-29 00:48:46 --> Loader Class Initialized
INFO - 2023-10-29 00:48:46 --> Helper loaded: url_helper
INFO - 2023-10-29 00:48:46 --> Helper loaded: form_helper
INFO - 2023-10-29 00:48:46 --> Helper loaded: file_helper
INFO - 2023-10-29 00:48:46 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:48:46 --> Form Validation Class Initialized
INFO - 2023-10-29 00:48:46 --> Upload Class Initialized
INFO - 2023-10-29 00:48:46 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:48:46 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:48:46 --> Config Class Initialized
INFO - 2023-10-29 00:48:46 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:48:46 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:48:46 --> Utf8 Class Initialized
INFO - 2023-10-29 00:48:46 --> URI Class Initialized
INFO - 2023-10-29 00:48:46 --> Router Class Initialized
INFO - 2023-10-29 00:48:46 --> Output Class Initialized
INFO - 2023-10-29 00:48:46 --> Security Class Initialized
DEBUG - 2023-10-29 00:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:48:46 --> Input Class Initialized
INFO - 2023-10-29 00:48:46 --> Language Class Initialized
INFO - 2023-10-29 00:48:46 --> Loader Class Initialized
INFO - 2023-10-29 00:48:46 --> Helper loaded: url_helper
INFO - 2023-10-29 00:48:46 --> Helper loaded: form_helper
INFO - 2023-10-29 00:48:46 --> Helper loaded: file_helper
INFO - 2023-10-29 00:48:46 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:48:46 --> Form Validation Class Initialized
INFO - 2023-10-29 00:48:46 --> Upload Class Initialized
INFO - 2023-10-29 00:48:46 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:48:46 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:48:46 --> Config Class Initialized
INFO - 2023-10-29 00:48:46 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:48:46 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:48:46 --> Utf8 Class Initialized
INFO - 2023-10-29 00:48:46 --> URI Class Initialized
INFO - 2023-10-29 00:48:46 --> Router Class Initialized
INFO - 2023-10-29 00:48:46 --> Output Class Initialized
INFO - 2023-10-29 00:48:46 --> Security Class Initialized
DEBUG - 2023-10-29 00:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:48:46 --> Input Class Initialized
INFO - 2023-10-29 00:48:46 --> Language Class Initialized
INFO - 2023-10-29 00:48:46 --> Loader Class Initialized
INFO - 2023-10-29 00:48:46 --> Helper loaded: url_helper
INFO - 2023-10-29 00:48:46 --> Helper loaded: form_helper
INFO - 2023-10-29 00:48:46 --> Helper loaded: file_helper
INFO - 2023-10-29 00:48:46 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:48:46 --> Form Validation Class Initialized
INFO - 2023-10-29 00:48:46 --> Upload Class Initialized
INFO - 2023-10-29 00:48:46 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:48:46 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:48:46 --> Config Class Initialized
INFO - 2023-10-29 00:48:46 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:48:46 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:48:46 --> Utf8 Class Initialized
INFO - 2023-10-29 00:48:46 --> URI Class Initialized
INFO - 2023-10-29 00:48:46 --> Router Class Initialized
INFO - 2023-10-29 00:48:46 --> Output Class Initialized
INFO - 2023-10-29 00:48:46 --> Security Class Initialized
DEBUG - 2023-10-29 00:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:48:46 --> Input Class Initialized
INFO - 2023-10-29 00:48:46 --> Language Class Initialized
INFO - 2023-10-29 00:48:46 --> Loader Class Initialized
INFO - 2023-10-29 00:48:46 --> Helper loaded: url_helper
INFO - 2023-10-29 00:48:46 --> Helper loaded: form_helper
INFO - 2023-10-29 00:48:46 --> Helper loaded: file_helper
INFO - 2023-10-29 00:48:46 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:48:46 --> Form Validation Class Initialized
INFO - 2023-10-29 00:48:46 --> Upload Class Initialized
INFO - 2023-10-29 00:48:46 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:48:46 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:48:46 --> Config Class Initialized
INFO - 2023-10-29 00:48:46 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:48:46 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:48:46 --> Utf8 Class Initialized
INFO - 2023-10-29 00:48:46 --> URI Class Initialized
INFO - 2023-10-29 00:48:46 --> Router Class Initialized
INFO - 2023-10-29 00:48:46 --> Output Class Initialized
INFO - 2023-10-29 00:48:46 --> Security Class Initialized
DEBUG - 2023-10-29 00:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:48:46 --> Input Class Initialized
INFO - 2023-10-29 00:48:46 --> Language Class Initialized
INFO - 2023-10-29 00:48:46 --> Loader Class Initialized
INFO - 2023-10-29 00:48:46 --> Helper loaded: url_helper
INFO - 2023-10-29 00:48:46 --> Helper loaded: form_helper
INFO - 2023-10-29 00:48:46 --> Helper loaded: file_helper
INFO - 2023-10-29 00:48:46 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:48:46 --> Form Validation Class Initialized
INFO - 2023-10-29 00:48:46 --> Upload Class Initialized
INFO - 2023-10-29 00:48:46 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:48:46 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:48:46 --> Config Class Initialized
INFO - 2023-10-29 00:48:46 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:48:46 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:48:46 --> Utf8 Class Initialized
INFO - 2023-10-29 00:48:46 --> URI Class Initialized
INFO - 2023-10-29 00:48:46 --> Router Class Initialized
INFO - 2023-10-29 00:48:46 --> Output Class Initialized
INFO - 2023-10-29 00:48:46 --> Security Class Initialized
DEBUG - 2023-10-29 00:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:48:46 --> Input Class Initialized
INFO - 2023-10-29 00:48:46 --> Language Class Initialized
INFO - 2023-10-29 00:48:46 --> Loader Class Initialized
INFO - 2023-10-29 00:48:46 --> Helper loaded: url_helper
INFO - 2023-10-29 00:48:46 --> Helper loaded: form_helper
INFO - 2023-10-29 00:48:46 --> Helper loaded: file_helper
INFO - 2023-10-29 00:48:46 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:48:46 --> Form Validation Class Initialized
INFO - 2023-10-29 00:48:46 --> Upload Class Initialized
INFO - 2023-10-29 00:48:46 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:48:46 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:49:10 --> Config Class Initialized
INFO - 2023-10-29 00:49:10 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:49:10 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:49:10 --> Utf8 Class Initialized
INFO - 2023-10-29 00:49:10 --> URI Class Initialized
INFO - 2023-10-29 00:49:10 --> Router Class Initialized
INFO - 2023-10-29 00:49:10 --> Output Class Initialized
INFO - 2023-10-29 00:49:10 --> Security Class Initialized
DEBUG - 2023-10-29 00:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:49:10 --> Input Class Initialized
INFO - 2023-10-29 00:49:10 --> Language Class Initialized
INFO - 2023-10-29 00:49:10 --> Loader Class Initialized
INFO - 2023-10-29 00:49:10 --> Helper loaded: url_helper
INFO - 2023-10-29 00:49:10 --> Helper loaded: form_helper
INFO - 2023-10-29 00:49:10 --> Helper loaded: file_helper
INFO - 2023-10-29 00:49:10 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:49:10 --> Form Validation Class Initialized
INFO - 2023-10-29 00:49:10 --> Upload Class Initialized
INFO - 2023-10-29 00:49:10 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:49:10 --> Non-existent class: Midtrans
INFO - 2023-10-29 00:49:22 --> Config Class Initialized
INFO - 2023-10-29 00:49:22 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:49:22 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:49:22 --> Utf8 Class Initialized
INFO - 2023-10-29 00:49:22 --> URI Class Initialized
INFO - 2023-10-29 00:49:22 --> Router Class Initialized
INFO - 2023-10-29 00:49:22 --> Output Class Initialized
INFO - 2023-10-29 00:49:22 --> Security Class Initialized
DEBUG - 2023-10-29 00:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:49:22 --> Input Class Initialized
INFO - 2023-10-29 00:49:22 --> Language Class Initialized
INFO - 2023-10-29 00:49:22 --> Loader Class Initialized
INFO - 2023-10-29 00:49:22 --> Helper loaded: url_helper
INFO - 2023-10-29 00:49:22 --> Helper loaded: form_helper
INFO - 2023-10-29 00:49:22 --> Helper loaded: file_helper
INFO - 2023-10-29 00:49:22 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:49:22 --> Form Validation Class Initialized
INFO - 2023-10-29 00:49:22 --> Upload Class Initialized
INFO - 2023-10-29 00:49:22 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:49:22 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:53:07 --> Config Class Initialized
INFO - 2023-10-29 00:53:07 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:53:07 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:53:07 --> Utf8 Class Initialized
INFO - 2023-10-29 00:53:07 --> URI Class Initialized
INFO - 2023-10-29 00:53:07 --> Router Class Initialized
INFO - 2023-10-29 00:53:07 --> Output Class Initialized
INFO - 2023-10-29 00:53:07 --> Security Class Initialized
DEBUG - 2023-10-29 00:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:53:07 --> Input Class Initialized
INFO - 2023-10-29 00:53:07 --> Language Class Initialized
INFO - 2023-10-29 00:53:07 --> Loader Class Initialized
INFO - 2023-10-29 00:53:07 --> Helper loaded: url_helper
INFO - 2023-10-29 00:53:07 --> Helper loaded: form_helper
INFO - 2023-10-29 00:53:07 --> Helper loaded: file_helper
INFO - 2023-10-29 00:53:07 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:53:07 --> Form Validation Class Initialized
INFO - 2023-10-29 00:53:07 --> Upload Class Initialized
INFO - 2023-10-29 00:53:07 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:53:07 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:53:08 --> Config Class Initialized
INFO - 2023-10-29 00:53:08 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:53:08 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:53:08 --> Utf8 Class Initialized
INFO - 2023-10-29 00:53:08 --> URI Class Initialized
INFO - 2023-10-29 00:53:08 --> Router Class Initialized
INFO - 2023-10-29 00:53:08 --> Output Class Initialized
INFO - 2023-10-29 00:53:08 --> Security Class Initialized
DEBUG - 2023-10-29 00:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:53:08 --> Input Class Initialized
INFO - 2023-10-29 00:53:08 --> Language Class Initialized
INFO - 2023-10-29 00:53:08 --> Loader Class Initialized
INFO - 2023-10-29 00:53:08 --> Helper loaded: url_helper
INFO - 2023-10-29 00:53:08 --> Helper loaded: form_helper
INFO - 2023-10-29 00:53:08 --> Helper loaded: file_helper
INFO - 2023-10-29 00:53:08 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:53:08 --> Form Validation Class Initialized
INFO - 2023-10-29 00:53:08 --> Upload Class Initialized
INFO - 2023-10-29 00:53:08 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:53:08 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:53:09 --> Config Class Initialized
INFO - 2023-10-29 00:53:09 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:53:09 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:53:09 --> Utf8 Class Initialized
INFO - 2023-10-29 00:53:09 --> URI Class Initialized
INFO - 2023-10-29 00:53:09 --> Router Class Initialized
INFO - 2023-10-29 00:53:09 --> Output Class Initialized
INFO - 2023-10-29 00:53:09 --> Security Class Initialized
DEBUG - 2023-10-29 00:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:53:09 --> Input Class Initialized
INFO - 2023-10-29 00:53:09 --> Language Class Initialized
INFO - 2023-10-29 00:53:09 --> Loader Class Initialized
INFO - 2023-10-29 00:53:09 --> Helper loaded: url_helper
INFO - 2023-10-29 00:53:09 --> Helper loaded: form_helper
INFO - 2023-10-29 00:53:09 --> Helper loaded: file_helper
INFO - 2023-10-29 00:53:09 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:53:09 --> Form Validation Class Initialized
INFO - 2023-10-29 00:53:09 --> Upload Class Initialized
INFO - 2023-10-29 00:53:09 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:53:09 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:53:09 --> Config Class Initialized
INFO - 2023-10-29 00:53:09 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:53:09 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:53:09 --> Utf8 Class Initialized
INFO - 2023-10-29 00:53:09 --> URI Class Initialized
INFO - 2023-10-29 00:53:09 --> Router Class Initialized
INFO - 2023-10-29 00:53:09 --> Output Class Initialized
INFO - 2023-10-29 00:53:09 --> Security Class Initialized
DEBUG - 2023-10-29 00:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:53:09 --> Input Class Initialized
INFO - 2023-10-29 00:53:09 --> Language Class Initialized
INFO - 2023-10-29 00:53:09 --> Loader Class Initialized
INFO - 2023-10-29 00:53:09 --> Helper loaded: url_helper
INFO - 2023-10-29 00:53:09 --> Helper loaded: form_helper
INFO - 2023-10-29 00:53:09 --> Helper loaded: file_helper
INFO - 2023-10-29 00:53:09 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:53:09 --> Form Validation Class Initialized
INFO - 2023-10-29 00:53:09 --> Upload Class Initialized
INFO - 2023-10-29 00:53:09 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:53:09 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:53:42 --> Config Class Initialized
INFO - 2023-10-29 00:53:42 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:53:42 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:53:42 --> Utf8 Class Initialized
INFO - 2023-10-29 00:53:42 --> URI Class Initialized
INFO - 2023-10-29 00:53:42 --> Router Class Initialized
INFO - 2023-10-29 00:53:42 --> Output Class Initialized
INFO - 2023-10-29 00:53:42 --> Security Class Initialized
DEBUG - 2023-10-29 00:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:53:42 --> Input Class Initialized
INFO - 2023-10-29 00:53:42 --> Language Class Initialized
INFO - 2023-10-29 00:53:42 --> Loader Class Initialized
INFO - 2023-10-29 00:53:42 --> Helper loaded: url_helper
INFO - 2023-10-29 00:53:42 --> Helper loaded: form_helper
INFO - 2023-10-29 00:53:42 --> Helper loaded: file_helper
INFO - 2023-10-29 00:53:42 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:53:42 --> Form Validation Class Initialized
INFO - 2023-10-29 00:53:42 --> Upload Class Initialized
INFO - 2023-10-29 00:53:42 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:53:42 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:53:42 --> Config Class Initialized
INFO - 2023-10-29 00:53:42 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:53:42 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:53:42 --> Utf8 Class Initialized
INFO - 2023-10-29 00:53:42 --> URI Class Initialized
INFO - 2023-10-29 00:53:42 --> Router Class Initialized
INFO - 2023-10-29 00:53:42 --> Output Class Initialized
INFO - 2023-10-29 00:53:42 --> Security Class Initialized
DEBUG - 2023-10-29 00:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:53:42 --> Input Class Initialized
INFO - 2023-10-29 00:53:42 --> Language Class Initialized
INFO - 2023-10-29 00:53:42 --> Loader Class Initialized
INFO - 2023-10-29 00:53:42 --> Helper loaded: url_helper
INFO - 2023-10-29 00:53:42 --> Helper loaded: form_helper
INFO - 2023-10-29 00:53:42 --> Helper loaded: file_helper
INFO - 2023-10-29 00:53:42 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:53:42 --> Form Validation Class Initialized
INFO - 2023-10-29 00:53:42 --> Upload Class Initialized
INFO - 2023-10-29 00:53:42 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:53:42 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:53:43 --> Config Class Initialized
INFO - 2023-10-29 00:53:43 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:53:43 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:53:43 --> Utf8 Class Initialized
INFO - 2023-10-29 00:53:43 --> URI Class Initialized
INFO - 2023-10-29 00:53:43 --> Router Class Initialized
INFO - 2023-10-29 00:53:43 --> Output Class Initialized
INFO - 2023-10-29 00:53:43 --> Security Class Initialized
DEBUG - 2023-10-29 00:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:53:43 --> Input Class Initialized
INFO - 2023-10-29 00:53:43 --> Language Class Initialized
INFO - 2023-10-29 00:53:43 --> Loader Class Initialized
INFO - 2023-10-29 00:53:43 --> Helper loaded: url_helper
INFO - 2023-10-29 00:53:43 --> Helper loaded: form_helper
INFO - 2023-10-29 00:53:43 --> Helper loaded: file_helper
INFO - 2023-10-29 00:53:43 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:53:43 --> Form Validation Class Initialized
INFO - 2023-10-29 00:53:43 --> Upload Class Initialized
INFO - 2023-10-29 00:53:43 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:53:43 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:53:43 --> Config Class Initialized
INFO - 2023-10-29 00:53:43 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:53:43 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:53:43 --> Utf8 Class Initialized
INFO - 2023-10-29 00:53:43 --> URI Class Initialized
INFO - 2023-10-29 00:53:43 --> Router Class Initialized
INFO - 2023-10-29 00:53:43 --> Output Class Initialized
INFO - 2023-10-29 00:53:43 --> Security Class Initialized
DEBUG - 2023-10-29 00:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:53:43 --> Input Class Initialized
INFO - 2023-10-29 00:53:43 --> Language Class Initialized
INFO - 2023-10-29 00:53:43 --> Loader Class Initialized
INFO - 2023-10-29 00:53:43 --> Helper loaded: url_helper
INFO - 2023-10-29 00:53:43 --> Helper loaded: form_helper
INFO - 2023-10-29 00:53:43 --> Helper loaded: file_helper
INFO - 2023-10-29 00:53:43 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:53:43 --> Form Validation Class Initialized
INFO - 2023-10-29 00:53:43 --> Upload Class Initialized
INFO - 2023-10-29 00:53:43 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:53:43 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:53:43 --> Config Class Initialized
INFO - 2023-10-29 00:53:43 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:53:43 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:53:43 --> Utf8 Class Initialized
INFO - 2023-10-29 00:53:43 --> URI Class Initialized
INFO - 2023-10-29 00:53:43 --> Router Class Initialized
INFO - 2023-10-29 00:53:43 --> Output Class Initialized
INFO - 2023-10-29 00:53:43 --> Security Class Initialized
DEBUG - 2023-10-29 00:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:53:43 --> Input Class Initialized
INFO - 2023-10-29 00:53:43 --> Language Class Initialized
INFO - 2023-10-29 00:53:43 --> Loader Class Initialized
INFO - 2023-10-29 00:53:43 --> Helper loaded: url_helper
INFO - 2023-10-29 00:53:43 --> Helper loaded: form_helper
INFO - 2023-10-29 00:53:43 --> Helper loaded: file_helper
INFO - 2023-10-29 00:53:43 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:53:43 --> Form Validation Class Initialized
INFO - 2023-10-29 00:53:43 --> Upload Class Initialized
INFO - 2023-10-29 00:53:43 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:53:43 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:54:16 --> Config Class Initialized
INFO - 2023-10-29 00:54:16 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:54:16 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:54:16 --> Utf8 Class Initialized
INFO - 2023-10-29 00:54:16 --> URI Class Initialized
INFO - 2023-10-29 00:54:16 --> Router Class Initialized
INFO - 2023-10-29 00:54:16 --> Output Class Initialized
INFO - 2023-10-29 00:54:16 --> Security Class Initialized
DEBUG - 2023-10-29 00:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:54:16 --> Input Class Initialized
INFO - 2023-10-29 00:54:16 --> Language Class Initialized
INFO - 2023-10-29 00:54:16 --> Loader Class Initialized
INFO - 2023-10-29 00:54:16 --> Helper loaded: url_helper
INFO - 2023-10-29 00:54:16 --> Helper loaded: form_helper
INFO - 2023-10-29 00:54:16 --> Helper loaded: file_helper
INFO - 2023-10-29 00:54:16 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:54:16 --> Form Validation Class Initialized
INFO - 2023-10-29 00:54:16 --> Upload Class Initialized
INFO - 2023-10-29 00:54:16 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:54:16 --> Unable to load the requested class: Midtrans
INFO - 2023-10-29 00:54:17 --> Config Class Initialized
INFO - 2023-10-29 00:54:17 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:54:17 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:54:17 --> Utf8 Class Initialized
INFO - 2023-10-29 00:54:17 --> URI Class Initialized
INFO - 2023-10-29 00:54:17 --> Router Class Initialized
INFO - 2023-10-29 00:54:17 --> Output Class Initialized
INFO - 2023-10-29 00:54:17 --> Security Class Initialized
DEBUG - 2023-10-29 00:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:54:17 --> Input Class Initialized
INFO - 2023-10-29 00:54:17 --> Language Class Initialized
INFO - 2023-10-29 00:54:17 --> Loader Class Initialized
INFO - 2023-10-29 00:54:17 --> Helper loaded: url_helper
INFO - 2023-10-29 00:54:17 --> Helper loaded: form_helper
INFO - 2023-10-29 00:54:17 --> Helper loaded: file_helper
INFO - 2023-10-29 00:54:17 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:54:17 --> Form Validation Class Initialized
INFO - 2023-10-29 00:54:17 --> Upload Class Initialized
INFO - 2023-10-29 00:54:17 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:54:17 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 00:55:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 00:55:38 --> Config Class Initialized
INFO - 2023-10-29 00:55:38 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:55:38 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:55:38 --> Utf8 Class Initialized
INFO - 2023-10-29 00:55:38 --> URI Class Initialized
INFO - 2023-10-29 00:55:38 --> Router Class Initialized
INFO - 2023-10-29 00:55:38 --> Output Class Initialized
INFO - 2023-10-29 00:55:38 --> Security Class Initialized
DEBUG - 2023-10-29 00:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:55:38 --> Input Class Initialized
INFO - 2023-10-29 00:55:38 --> Language Class Initialized
INFO - 2023-10-29 00:55:38 --> Loader Class Initialized
INFO - 2023-10-29 00:55:38 --> Helper loaded: url_helper
INFO - 2023-10-29 00:55:38 --> Helper loaded: form_helper
INFO - 2023-10-29 00:55:38 --> Helper loaded: file_helper
INFO - 2023-10-29 00:55:38 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:55:38 --> Form Validation Class Initialized
INFO - 2023-10-29 00:55:38 --> Upload Class Initialized
INFO - 2023-10-29 00:55:38 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:55:38 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 00:55:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 00:55:38 --> Config Class Initialized
INFO - 2023-10-29 00:55:38 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:55:38 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:55:38 --> Utf8 Class Initialized
INFO - 2023-10-29 00:55:38 --> URI Class Initialized
INFO - 2023-10-29 00:55:38 --> Router Class Initialized
INFO - 2023-10-29 00:55:38 --> Output Class Initialized
INFO - 2023-10-29 00:55:38 --> Security Class Initialized
DEBUG - 2023-10-29 00:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:55:38 --> Input Class Initialized
INFO - 2023-10-29 00:55:38 --> Language Class Initialized
INFO - 2023-10-29 00:55:38 --> Loader Class Initialized
INFO - 2023-10-29 00:55:38 --> Helper loaded: url_helper
INFO - 2023-10-29 00:55:38 --> Helper loaded: form_helper
INFO - 2023-10-29 00:55:38 --> Helper loaded: file_helper
INFO - 2023-10-29 00:55:38 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:55:38 --> Form Validation Class Initialized
INFO - 2023-10-29 00:55:38 --> Upload Class Initialized
INFO - 2023-10-29 00:55:38 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:55:38 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 00:55:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 00:55:39 --> Config Class Initialized
INFO - 2023-10-29 00:55:39 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:55:39 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:55:39 --> Utf8 Class Initialized
INFO - 2023-10-29 00:55:39 --> URI Class Initialized
INFO - 2023-10-29 00:55:39 --> Router Class Initialized
INFO - 2023-10-29 00:55:39 --> Output Class Initialized
INFO - 2023-10-29 00:55:39 --> Security Class Initialized
DEBUG - 2023-10-29 00:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:55:39 --> Input Class Initialized
INFO - 2023-10-29 00:55:39 --> Language Class Initialized
INFO - 2023-10-29 00:55:39 --> Loader Class Initialized
INFO - 2023-10-29 00:55:39 --> Helper loaded: url_helper
INFO - 2023-10-29 00:55:39 --> Helper loaded: form_helper
INFO - 2023-10-29 00:55:39 --> Helper loaded: file_helper
INFO - 2023-10-29 00:55:39 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:55:39 --> Form Validation Class Initialized
INFO - 2023-10-29 00:55:39 --> Upload Class Initialized
INFO - 2023-10-29 00:55:39 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:55:39 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 00:55:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 00:55:54 --> Config Class Initialized
INFO - 2023-10-29 00:55:54 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:55:54 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:55:54 --> Utf8 Class Initialized
INFO - 2023-10-29 00:55:54 --> URI Class Initialized
INFO - 2023-10-29 00:55:54 --> Router Class Initialized
INFO - 2023-10-29 00:55:54 --> Output Class Initialized
INFO - 2023-10-29 00:55:54 --> Security Class Initialized
DEBUG - 2023-10-29 00:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:55:54 --> Input Class Initialized
INFO - 2023-10-29 00:55:54 --> Language Class Initialized
INFO - 2023-10-29 00:55:54 --> Loader Class Initialized
INFO - 2023-10-29 00:55:54 --> Helper loaded: url_helper
INFO - 2023-10-29 00:55:54 --> Helper loaded: form_helper
INFO - 2023-10-29 00:55:54 --> Helper loaded: file_helper
INFO - 2023-10-29 00:55:54 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:55:54 --> Form Validation Class Initialized
INFO - 2023-10-29 00:55:54 --> Upload Class Initialized
INFO - 2023-10-29 00:55:54 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:55:54 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 00:55:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 00:55:54 --> Config Class Initialized
INFO - 2023-10-29 00:55:54 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:55:54 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:55:54 --> Utf8 Class Initialized
INFO - 2023-10-29 00:55:54 --> URI Class Initialized
INFO - 2023-10-29 00:55:54 --> Router Class Initialized
INFO - 2023-10-29 00:55:54 --> Output Class Initialized
INFO - 2023-10-29 00:55:54 --> Security Class Initialized
DEBUG - 2023-10-29 00:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:55:54 --> Input Class Initialized
INFO - 2023-10-29 00:55:54 --> Language Class Initialized
INFO - 2023-10-29 00:55:54 --> Loader Class Initialized
INFO - 2023-10-29 00:55:54 --> Helper loaded: url_helper
INFO - 2023-10-29 00:55:54 --> Helper loaded: form_helper
INFO - 2023-10-29 00:55:54 --> Helper loaded: file_helper
INFO - 2023-10-29 00:55:54 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:55:54 --> Form Validation Class Initialized
INFO - 2023-10-29 00:55:54 --> Upload Class Initialized
INFO - 2023-10-29 00:55:54 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:55:54 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 00:55:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 00:55:55 --> Config Class Initialized
INFO - 2023-10-29 00:55:55 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:55:55 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:55:55 --> Utf8 Class Initialized
INFO - 2023-10-29 00:55:55 --> URI Class Initialized
INFO - 2023-10-29 00:55:55 --> Router Class Initialized
INFO - 2023-10-29 00:55:55 --> Output Class Initialized
INFO - 2023-10-29 00:55:55 --> Security Class Initialized
DEBUG - 2023-10-29 00:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:55:55 --> Input Class Initialized
INFO - 2023-10-29 00:55:55 --> Language Class Initialized
INFO - 2023-10-29 00:55:55 --> Loader Class Initialized
INFO - 2023-10-29 00:55:55 --> Helper loaded: url_helper
INFO - 2023-10-29 00:55:55 --> Helper loaded: form_helper
INFO - 2023-10-29 00:55:55 --> Helper loaded: file_helper
INFO - 2023-10-29 00:55:55 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:55:55 --> Form Validation Class Initialized
INFO - 2023-10-29 00:55:55 --> Upload Class Initialized
INFO - 2023-10-29 00:55:55 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:55:55 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 00:55:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 00:55:55 --> Config Class Initialized
INFO - 2023-10-29 00:55:55 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:55:55 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:55:55 --> Utf8 Class Initialized
INFO - 2023-10-29 00:55:55 --> URI Class Initialized
INFO - 2023-10-29 00:55:55 --> Router Class Initialized
INFO - 2023-10-29 00:55:55 --> Output Class Initialized
INFO - 2023-10-29 00:55:55 --> Security Class Initialized
DEBUG - 2023-10-29 00:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:55:55 --> Input Class Initialized
INFO - 2023-10-29 00:55:55 --> Language Class Initialized
INFO - 2023-10-29 00:55:55 --> Loader Class Initialized
INFO - 2023-10-29 00:55:55 --> Helper loaded: url_helper
INFO - 2023-10-29 00:55:55 --> Helper loaded: form_helper
INFO - 2023-10-29 00:55:55 --> Helper loaded: file_helper
INFO - 2023-10-29 00:55:55 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:55:55 --> Form Validation Class Initialized
INFO - 2023-10-29 00:55:55 --> Upload Class Initialized
INFO - 2023-10-29 00:55:55 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:55:55 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 00:55:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 00:55:55 --> Config Class Initialized
INFO - 2023-10-29 00:55:55 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:55:55 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:55:55 --> Utf8 Class Initialized
INFO - 2023-10-29 00:55:55 --> URI Class Initialized
INFO - 2023-10-29 00:55:55 --> Router Class Initialized
INFO - 2023-10-29 00:55:55 --> Output Class Initialized
INFO - 2023-10-29 00:55:55 --> Security Class Initialized
DEBUG - 2023-10-29 00:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:55:55 --> Input Class Initialized
INFO - 2023-10-29 00:55:55 --> Language Class Initialized
INFO - 2023-10-29 00:55:55 --> Loader Class Initialized
INFO - 2023-10-29 00:55:55 --> Helper loaded: url_helper
INFO - 2023-10-29 00:55:55 --> Helper loaded: form_helper
INFO - 2023-10-29 00:55:55 --> Helper loaded: file_helper
INFO - 2023-10-29 00:55:55 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:55:55 --> Form Validation Class Initialized
INFO - 2023-10-29 00:55:55 --> Upload Class Initialized
INFO - 2023-10-29 00:55:55 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:55:55 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 00:55:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 00:55:55 --> Config Class Initialized
INFO - 2023-10-29 00:55:55 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:55:55 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:55:55 --> Utf8 Class Initialized
INFO - 2023-10-29 00:55:55 --> URI Class Initialized
INFO - 2023-10-29 00:55:55 --> Router Class Initialized
INFO - 2023-10-29 00:55:55 --> Output Class Initialized
INFO - 2023-10-29 00:55:55 --> Security Class Initialized
DEBUG - 2023-10-29 00:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:55:55 --> Input Class Initialized
INFO - 2023-10-29 00:55:55 --> Language Class Initialized
INFO - 2023-10-29 00:55:55 --> Loader Class Initialized
INFO - 2023-10-29 00:55:55 --> Helper loaded: url_helper
INFO - 2023-10-29 00:55:55 --> Helper loaded: form_helper
INFO - 2023-10-29 00:55:55 --> Helper loaded: file_helper
INFO - 2023-10-29 00:55:55 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:55:55 --> Form Validation Class Initialized
INFO - 2023-10-29 00:55:55 --> Upload Class Initialized
INFO - 2023-10-29 00:55:55 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:55:55 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 00:55:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 00:55:56 --> Config Class Initialized
INFO - 2023-10-29 00:55:56 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:55:56 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:55:56 --> Utf8 Class Initialized
INFO - 2023-10-29 00:55:56 --> URI Class Initialized
INFO - 2023-10-29 00:55:56 --> Router Class Initialized
INFO - 2023-10-29 00:55:56 --> Output Class Initialized
INFO - 2023-10-29 00:55:56 --> Security Class Initialized
DEBUG - 2023-10-29 00:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:55:56 --> Input Class Initialized
INFO - 2023-10-29 00:55:56 --> Language Class Initialized
INFO - 2023-10-29 00:55:56 --> Loader Class Initialized
INFO - 2023-10-29 00:55:56 --> Helper loaded: url_helper
INFO - 2023-10-29 00:55:56 --> Helper loaded: form_helper
INFO - 2023-10-29 00:55:56 --> Helper loaded: file_helper
INFO - 2023-10-29 00:55:56 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:55:56 --> Form Validation Class Initialized
INFO - 2023-10-29 00:55:56 --> Upload Class Initialized
INFO - 2023-10-29 00:55:56 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:55:56 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 00:55:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 00:55:57 --> Config Class Initialized
INFO - 2023-10-29 00:55:57 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:55:57 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:55:57 --> Utf8 Class Initialized
INFO - 2023-10-29 00:55:57 --> URI Class Initialized
INFO - 2023-10-29 00:55:57 --> Router Class Initialized
INFO - 2023-10-29 00:55:57 --> Output Class Initialized
INFO - 2023-10-29 00:55:57 --> Security Class Initialized
DEBUG - 2023-10-29 00:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:55:58 --> Input Class Initialized
INFO - 2023-10-29 00:55:58 --> Language Class Initialized
INFO - 2023-10-29 00:55:58 --> Loader Class Initialized
INFO - 2023-10-29 00:55:58 --> Helper loaded: url_helper
INFO - 2023-10-29 00:55:58 --> Helper loaded: form_helper
INFO - 2023-10-29 00:55:58 --> Helper loaded: file_helper
INFO - 2023-10-29 00:55:58 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:55:58 --> Form Validation Class Initialized
INFO - 2023-10-29 00:55:58 --> Upload Class Initialized
INFO - 2023-10-29 00:55:58 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:55:58 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 00:55:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 00:55:58 --> Config Class Initialized
INFO - 2023-10-29 00:55:58 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:55:58 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:55:58 --> Utf8 Class Initialized
INFO - 2023-10-29 00:55:58 --> URI Class Initialized
INFO - 2023-10-29 00:55:58 --> Router Class Initialized
INFO - 2023-10-29 00:55:58 --> Output Class Initialized
INFO - 2023-10-29 00:55:58 --> Security Class Initialized
DEBUG - 2023-10-29 00:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:55:58 --> Input Class Initialized
INFO - 2023-10-29 00:55:58 --> Language Class Initialized
INFO - 2023-10-29 00:55:58 --> Loader Class Initialized
INFO - 2023-10-29 00:55:58 --> Helper loaded: url_helper
INFO - 2023-10-29 00:55:58 --> Helper loaded: form_helper
INFO - 2023-10-29 00:55:58 --> Helper loaded: file_helper
INFO - 2023-10-29 00:55:58 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:55:58 --> Form Validation Class Initialized
INFO - 2023-10-29 00:55:58 --> Upload Class Initialized
INFO - 2023-10-29 00:55:58 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:55:58 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 00:55:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 00:55:58 --> Config Class Initialized
INFO - 2023-10-29 00:55:58 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:55:58 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:55:58 --> Utf8 Class Initialized
INFO - 2023-10-29 00:55:58 --> URI Class Initialized
INFO - 2023-10-29 00:55:58 --> Router Class Initialized
INFO - 2023-10-29 00:55:58 --> Output Class Initialized
INFO - 2023-10-29 00:55:58 --> Security Class Initialized
DEBUG - 2023-10-29 00:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:55:58 --> Input Class Initialized
INFO - 2023-10-29 00:55:58 --> Language Class Initialized
INFO - 2023-10-29 00:55:58 --> Loader Class Initialized
INFO - 2023-10-29 00:55:58 --> Helper loaded: url_helper
INFO - 2023-10-29 00:55:58 --> Helper loaded: form_helper
INFO - 2023-10-29 00:55:58 --> Helper loaded: file_helper
INFO - 2023-10-29 00:55:58 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:55:58 --> Form Validation Class Initialized
INFO - 2023-10-29 00:55:58 --> Upload Class Initialized
INFO - 2023-10-29 00:55:58 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:55:58 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 00:55:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 00:55:58 --> Config Class Initialized
INFO - 2023-10-29 00:55:58 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:55:58 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:55:58 --> Utf8 Class Initialized
INFO - 2023-10-29 00:55:58 --> URI Class Initialized
INFO - 2023-10-29 00:55:58 --> Router Class Initialized
INFO - 2023-10-29 00:55:58 --> Output Class Initialized
INFO - 2023-10-29 00:55:58 --> Security Class Initialized
DEBUG - 2023-10-29 00:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:55:58 --> Input Class Initialized
INFO - 2023-10-29 00:55:58 --> Language Class Initialized
INFO - 2023-10-29 00:55:58 --> Loader Class Initialized
INFO - 2023-10-29 00:55:58 --> Helper loaded: url_helper
INFO - 2023-10-29 00:55:58 --> Helper loaded: form_helper
INFO - 2023-10-29 00:55:58 --> Helper loaded: file_helper
INFO - 2023-10-29 00:55:58 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:55:58 --> Form Validation Class Initialized
INFO - 2023-10-29 00:55:58 --> Upload Class Initialized
INFO - 2023-10-29 00:55:58 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:55:58 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 00:55:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 00:55:58 --> Config Class Initialized
INFO - 2023-10-29 00:55:58 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:55:58 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:55:58 --> Utf8 Class Initialized
INFO - 2023-10-29 00:55:58 --> URI Class Initialized
INFO - 2023-10-29 00:55:58 --> Router Class Initialized
INFO - 2023-10-29 00:55:58 --> Output Class Initialized
INFO - 2023-10-29 00:55:58 --> Security Class Initialized
DEBUG - 2023-10-29 00:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:55:58 --> Input Class Initialized
INFO - 2023-10-29 00:55:58 --> Language Class Initialized
INFO - 2023-10-29 00:55:58 --> Loader Class Initialized
INFO - 2023-10-29 00:55:58 --> Helper loaded: url_helper
INFO - 2023-10-29 00:55:58 --> Helper loaded: form_helper
INFO - 2023-10-29 00:55:58 --> Helper loaded: file_helper
INFO - 2023-10-29 00:55:58 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:55:58 --> Form Validation Class Initialized
INFO - 2023-10-29 00:55:58 --> Upload Class Initialized
INFO - 2023-10-29 00:55:58 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:55:58 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 00:55:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 00:55:58 --> Config Class Initialized
INFO - 2023-10-29 00:55:58 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:55:58 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:55:58 --> Utf8 Class Initialized
INFO - 2023-10-29 00:55:58 --> URI Class Initialized
INFO - 2023-10-29 00:55:58 --> Router Class Initialized
INFO - 2023-10-29 00:55:58 --> Output Class Initialized
INFO - 2023-10-29 00:55:58 --> Security Class Initialized
DEBUG - 2023-10-29 00:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:55:58 --> Input Class Initialized
INFO - 2023-10-29 00:55:58 --> Language Class Initialized
INFO - 2023-10-29 00:55:58 --> Loader Class Initialized
INFO - 2023-10-29 00:55:58 --> Helper loaded: url_helper
INFO - 2023-10-29 00:55:58 --> Helper loaded: form_helper
INFO - 2023-10-29 00:55:58 --> Helper loaded: file_helper
INFO - 2023-10-29 00:55:58 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:55:58 --> Form Validation Class Initialized
INFO - 2023-10-29 00:55:58 --> Upload Class Initialized
INFO - 2023-10-29 00:55:58 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:55:58 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 00:55:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 00:55:58 --> Config Class Initialized
INFO - 2023-10-29 00:55:58 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:55:58 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:55:58 --> Utf8 Class Initialized
INFO - 2023-10-29 00:55:58 --> URI Class Initialized
INFO - 2023-10-29 00:55:58 --> Router Class Initialized
INFO - 2023-10-29 00:55:58 --> Output Class Initialized
INFO - 2023-10-29 00:55:58 --> Security Class Initialized
DEBUG - 2023-10-29 00:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:55:58 --> Input Class Initialized
INFO - 2023-10-29 00:55:58 --> Language Class Initialized
INFO - 2023-10-29 00:55:58 --> Loader Class Initialized
INFO - 2023-10-29 00:55:58 --> Helper loaded: url_helper
INFO - 2023-10-29 00:55:58 --> Helper loaded: form_helper
INFO - 2023-10-29 00:55:58 --> Helper loaded: file_helper
INFO - 2023-10-29 00:55:58 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:55:58 --> Form Validation Class Initialized
INFO - 2023-10-29 00:55:58 --> Upload Class Initialized
INFO - 2023-10-29 00:55:58 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:55:58 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 00:55:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 00:55:58 --> Config Class Initialized
INFO - 2023-10-29 00:55:58 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:55:58 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:55:58 --> Utf8 Class Initialized
INFO - 2023-10-29 00:55:58 --> URI Class Initialized
INFO - 2023-10-29 00:55:58 --> Router Class Initialized
INFO - 2023-10-29 00:55:58 --> Output Class Initialized
INFO - 2023-10-29 00:55:58 --> Security Class Initialized
DEBUG - 2023-10-29 00:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:55:59 --> Input Class Initialized
INFO - 2023-10-29 00:55:59 --> Language Class Initialized
INFO - 2023-10-29 00:55:59 --> Loader Class Initialized
INFO - 2023-10-29 00:55:59 --> Helper loaded: url_helper
INFO - 2023-10-29 00:55:59 --> Helper loaded: form_helper
INFO - 2023-10-29 00:55:59 --> Helper loaded: file_helper
INFO - 2023-10-29 00:55:59 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:55:59 --> Form Validation Class Initialized
INFO - 2023-10-29 00:55:59 --> Upload Class Initialized
INFO - 2023-10-29 00:55:59 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:55:59 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 00:55:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 00:55:59 --> Config Class Initialized
INFO - 2023-10-29 00:55:59 --> Hooks Class Initialized
DEBUG - 2023-10-29 00:55:59 --> UTF-8 Support Enabled
INFO - 2023-10-29 00:55:59 --> Utf8 Class Initialized
INFO - 2023-10-29 00:55:59 --> URI Class Initialized
INFO - 2023-10-29 00:55:59 --> Router Class Initialized
INFO - 2023-10-29 00:55:59 --> Output Class Initialized
INFO - 2023-10-29 00:55:59 --> Security Class Initialized
DEBUG - 2023-10-29 00:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 00:55:59 --> Input Class Initialized
INFO - 2023-10-29 00:55:59 --> Language Class Initialized
INFO - 2023-10-29 00:55:59 --> Loader Class Initialized
INFO - 2023-10-29 00:55:59 --> Helper loaded: url_helper
INFO - 2023-10-29 00:55:59 --> Helper loaded: form_helper
INFO - 2023-10-29 00:55:59 --> Helper loaded: file_helper
INFO - 2023-10-29 00:55:59 --> Database Driver Class Initialized
DEBUG - 2023-10-29 00:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 00:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 00:55:59 --> Form Validation Class Initialized
INFO - 2023-10-29 00:55:59 --> Upload Class Initialized
INFO - 2023-10-29 00:55:59 --> Model "M_auth" initialized
ERROR - 2023-10-29 00:55:59 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 01:04:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:04:18 --> Config Class Initialized
INFO - 2023-10-29 01:04:18 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:04:18 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:04:18 --> Utf8 Class Initialized
INFO - 2023-10-29 01:04:18 --> URI Class Initialized
INFO - 2023-10-29 01:04:18 --> Router Class Initialized
INFO - 2023-10-29 01:04:18 --> Output Class Initialized
INFO - 2023-10-29 01:04:18 --> Security Class Initialized
DEBUG - 2023-10-29 01:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:04:18 --> Input Class Initialized
INFO - 2023-10-29 01:04:18 --> Language Class Initialized
INFO - 2023-10-29 01:04:18 --> Loader Class Initialized
INFO - 2023-10-29 01:04:18 --> Helper loaded: url_helper
INFO - 2023-10-29 01:04:18 --> Helper loaded: form_helper
INFO - 2023-10-29 01:04:18 --> Helper loaded: file_helper
INFO - 2023-10-29 01:04:18 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:04:18 --> Form Validation Class Initialized
INFO - 2023-10-29 01:04:18 --> Upload Class Initialized
INFO - 2023-10-29 01:04:18 --> Model "M_auth" initialized
ERROR - 2023-10-29 01:04:18 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 01:04:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:04:18 --> Config Class Initialized
INFO - 2023-10-29 01:04:18 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:04:18 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:04:18 --> Utf8 Class Initialized
INFO - 2023-10-29 01:04:18 --> URI Class Initialized
INFO - 2023-10-29 01:04:18 --> Router Class Initialized
INFO - 2023-10-29 01:04:18 --> Output Class Initialized
INFO - 2023-10-29 01:04:18 --> Security Class Initialized
DEBUG - 2023-10-29 01:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:04:18 --> Input Class Initialized
INFO - 2023-10-29 01:04:18 --> Language Class Initialized
INFO - 2023-10-29 01:04:18 --> Loader Class Initialized
INFO - 2023-10-29 01:04:18 --> Helper loaded: url_helper
INFO - 2023-10-29 01:04:18 --> Helper loaded: form_helper
INFO - 2023-10-29 01:04:18 --> Helper loaded: file_helper
INFO - 2023-10-29 01:04:18 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:04:18 --> Form Validation Class Initialized
INFO - 2023-10-29 01:04:18 --> Upload Class Initialized
INFO - 2023-10-29 01:04:18 --> Model "M_auth" initialized
ERROR - 2023-10-29 01:04:18 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 01:04:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:04:19 --> Config Class Initialized
INFO - 2023-10-29 01:04:19 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:04:19 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:04:19 --> Utf8 Class Initialized
INFO - 2023-10-29 01:04:19 --> URI Class Initialized
INFO - 2023-10-29 01:04:19 --> Router Class Initialized
INFO - 2023-10-29 01:04:19 --> Output Class Initialized
INFO - 2023-10-29 01:04:19 --> Security Class Initialized
DEBUG - 2023-10-29 01:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:04:19 --> Input Class Initialized
INFO - 2023-10-29 01:04:19 --> Language Class Initialized
INFO - 2023-10-29 01:04:19 --> Loader Class Initialized
INFO - 2023-10-29 01:04:19 --> Helper loaded: url_helper
INFO - 2023-10-29 01:04:19 --> Helper loaded: form_helper
INFO - 2023-10-29 01:04:19 --> Helper loaded: file_helper
INFO - 2023-10-29 01:04:19 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:04:19 --> Form Validation Class Initialized
INFO - 2023-10-29 01:04:19 --> Upload Class Initialized
INFO - 2023-10-29 01:04:19 --> Model "M_auth" initialized
ERROR - 2023-10-29 01:04:19 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 01:04:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:04:19 --> Config Class Initialized
INFO - 2023-10-29 01:04:19 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:04:19 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:04:19 --> Utf8 Class Initialized
INFO - 2023-10-29 01:04:19 --> URI Class Initialized
INFO - 2023-10-29 01:04:19 --> Router Class Initialized
INFO - 2023-10-29 01:04:19 --> Output Class Initialized
INFO - 2023-10-29 01:04:19 --> Security Class Initialized
DEBUG - 2023-10-29 01:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:04:19 --> Input Class Initialized
INFO - 2023-10-29 01:04:19 --> Language Class Initialized
INFO - 2023-10-29 01:04:19 --> Loader Class Initialized
INFO - 2023-10-29 01:04:19 --> Helper loaded: url_helper
INFO - 2023-10-29 01:04:19 --> Helper loaded: form_helper
INFO - 2023-10-29 01:04:19 --> Helper loaded: file_helper
INFO - 2023-10-29 01:04:19 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:04:19 --> Form Validation Class Initialized
INFO - 2023-10-29 01:04:19 --> Upload Class Initialized
INFO - 2023-10-29 01:04:19 --> Model "M_auth" initialized
ERROR - 2023-10-29 01:04:19 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 01:04:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:04:19 --> Config Class Initialized
INFO - 2023-10-29 01:04:19 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:04:19 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:04:19 --> Utf8 Class Initialized
INFO - 2023-10-29 01:04:19 --> URI Class Initialized
INFO - 2023-10-29 01:04:19 --> Router Class Initialized
INFO - 2023-10-29 01:04:19 --> Output Class Initialized
INFO - 2023-10-29 01:04:19 --> Security Class Initialized
DEBUG - 2023-10-29 01:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:04:19 --> Input Class Initialized
INFO - 2023-10-29 01:04:19 --> Language Class Initialized
INFO - 2023-10-29 01:04:19 --> Loader Class Initialized
INFO - 2023-10-29 01:04:19 --> Helper loaded: url_helper
INFO - 2023-10-29 01:04:19 --> Helper loaded: form_helper
INFO - 2023-10-29 01:04:19 --> Helper loaded: file_helper
INFO - 2023-10-29 01:04:19 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:04:19 --> Form Validation Class Initialized
INFO - 2023-10-29 01:04:19 --> Upload Class Initialized
INFO - 2023-10-29 01:04:19 --> Model "M_auth" initialized
ERROR - 2023-10-29 01:04:19 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 01:04:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:04:19 --> Config Class Initialized
INFO - 2023-10-29 01:04:19 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:04:19 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:04:19 --> Utf8 Class Initialized
INFO - 2023-10-29 01:04:19 --> URI Class Initialized
INFO - 2023-10-29 01:04:19 --> Router Class Initialized
INFO - 2023-10-29 01:04:19 --> Output Class Initialized
INFO - 2023-10-29 01:04:19 --> Security Class Initialized
DEBUG - 2023-10-29 01:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:04:19 --> Input Class Initialized
INFO - 2023-10-29 01:04:19 --> Language Class Initialized
INFO - 2023-10-29 01:04:19 --> Loader Class Initialized
INFO - 2023-10-29 01:04:19 --> Helper loaded: url_helper
INFO - 2023-10-29 01:04:19 --> Helper loaded: form_helper
INFO - 2023-10-29 01:04:19 --> Helper loaded: file_helper
INFO - 2023-10-29 01:04:19 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:04:19 --> Form Validation Class Initialized
INFO - 2023-10-29 01:04:19 --> Upload Class Initialized
INFO - 2023-10-29 01:04:19 --> Model "M_auth" initialized
ERROR - 2023-10-29 01:04:19 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 01:04:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:04:19 --> Config Class Initialized
INFO - 2023-10-29 01:04:19 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:04:19 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:04:19 --> Utf8 Class Initialized
INFO - 2023-10-29 01:04:19 --> URI Class Initialized
INFO - 2023-10-29 01:04:19 --> Router Class Initialized
INFO - 2023-10-29 01:04:19 --> Output Class Initialized
INFO - 2023-10-29 01:04:19 --> Security Class Initialized
DEBUG - 2023-10-29 01:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:04:19 --> Input Class Initialized
INFO - 2023-10-29 01:04:19 --> Language Class Initialized
INFO - 2023-10-29 01:04:19 --> Loader Class Initialized
INFO - 2023-10-29 01:04:19 --> Helper loaded: url_helper
INFO - 2023-10-29 01:04:19 --> Helper loaded: form_helper
INFO - 2023-10-29 01:04:19 --> Helper loaded: file_helper
INFO - 2023-10-29 01:04:19 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:04:19 --> Form Validation Class Initialized
INFO - 2023-10-29 01:04:19 --> Upload Class Initialized
INFO - 2023-10-29 01:04:19 --> Model "M_auth" initialized
ERROR - 2023-10-29 01:04:19 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 01:04:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:04:19 --> Config Class Initialized
INFO - 2023-10-29 01:04:19 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:04:19 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:04:19 --> Utf8 Class Initialized
INFO - 2023-10-29 01:04:19 --> URI Class Initialized
INFO - 2023-10-29 01:04:19 --> Router Class Initialized
INFO - 2023-10-29 01:04:19 --> Output Class Initialized
INFO - 2023-10-29 01:04:19 --> Security Class Initialized
DEBUG - 2023-10-29 01:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:04:19 --> Input Class Initialized
INFO - 2023-10-29 01:04:19 --> Language Class Initialized
INFO - 2023-10-29 01:04:19 --> Loader Class Initialized
INFO - 2023-10-29 01:04:19 --> Helper loaded: url_helper
INFO - 2023-10-29 01:04:19 --> Helper loaded: form_helper
INFO - 2023-10-29 01:04:19 --> Helper loaded: file_helper
INFO - 2023-10-29 01:04:19 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:04:19 --> Form Validation Class Initialized
INFO - 2023-10-29 01:04:19 --> Upload Class Initialized
INFO - 2023-10-29 01:04:19 --> Model "M_auth" initialized
ERROR - 2023-10-29 01:04:19 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 01:04:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:04:19 --> Config Class Initialized
INFO - 2023-10-29 01:04:19 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:04:19 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:04:19 --> Utf8 Class Initialized
INFO - 2023-10-29 01:04:19 --> URI Class Initialized
INFO - 2023-10-29 01:04:19 --> Router Class Initialized
INFO - 2023-10-29 01:04:19 --> Output Class Initialized
INFO - 2023-10-29 01:04:19 --> Security Class Initialized
DEBUG - 2023-10-29 01:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:04:19 --> Input Class Initialized
INFO - 2023-10-29 01:04:19 --> Language Class Initialized
INFO - 2023-10-29 01:04:20 --> Loader Class Initialized
INFO - 2023-10-29 01:04:20 --> Helper loaded: url_helper
INFO - 2023-10-29 01:04:20 --> Helper loaded: form_helper
INFO - 2023-10-29 01:04:20 --> Helper loaded: file_helper
INFO - 2023-10-29 01:04:20 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:04:20 --> Form Validation Class Initialized
INFO - 2023-10-29 01:04:20 --> Upload Class Initialized
INFO - 2023-10-29 01:04:20 --> Model "M_auth" initialized
ERROR - 2023-10-29 01:04:20 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 01:04:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:04:54 --> Config Class Initialized
INFO - 2023-10-29 01:04:54 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:04:54 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:04:54 --> Utf8 Class Initialized
INFO - 2023-10-29 01:04:54 --> URI Class Initialized
INFO - 2023-10-29 01:04:54 --> Router Class Initialized
INFO - 2023-10-29 01:04:54 --> Output Class Initialized
INFO - 2023-10-29 01:04:54 --> Security Class Initialized
DEBUG - 2023-10-29 01:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:04:54 --> Input Class Initialized
INFO - 2023-10-29 01:04:54 --> Language Class Initialized
INFO - 2023-10-29 01:04:54 --> Loader Class Initialized
INFO - 2023-10-29 01:04:54 --> Helper loaded: url_helper
INFO - 2023-10-29 01:04:54 --> Helper loaded: form_helper
INFO - 2023-10-29 01:04:54 --> Helper loaded: file_helper
INFO - 2023-10-29 01:04:54 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:04:54 --> Form Validation Class Initialized
INFO - 2023-10-29 01:04:54 --> Upload Class Initialized
INFO - 2023-10-29 01:04:54 --> Model "M_auth" initialized
ERROR - 2023-10-29 01:04:54 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 01:10:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:10:45 --> Config Class Initialized
INFO - 2023-10-29 01:10:45 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:10:45 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:10:45 --> Utf8 Class Initialized
INFO - 2023-10-29 01:10:45 --> URI Class Initialized
INFO - 2023-10-29 01:10:45 --> Router Class Initialized
INFO - 2023-10-29 01:10:45 --> Output Class Initialized
INFO - 2023-10-29 01:10:45 --> Security Class Initialized
DEBUG - 2023-10-29 01:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:10:45 --> Input Class Initialized
INFO - 2023-10-29 01:10:45 --> Language Class Initialized
INFO - 2023-10-29 01:10:45 --> Loader Class Initialized
INFO - 2023-10-29 01:10:45 --> Helper loaded: url_helper
INFO - 2023-10-29 01:10:45 --> Helper loaded: form_helper
INFO - 2023-10-29 01:10:45 --> Helper loaded: file_helper
INFO - 2023-10-29 01:10:45 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:10:45 --> Form Validation Class Initialized
INFO - 2023-10-29 01:10:45 --> Upload Class Initialized
INFO - 2023-10-29 01:10:45 --> Model "M_auth" initialized
ERROR - 2023-10-29 01:10:45 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 01:10:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:10:47 --> Config Class Initialized
INFO - 2023-10-29 01:10:47 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:10:47 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:10:47 --> Utf8 Class Initialized
INFO - 2023-10-29 01:10:47 --> URI Class Initialized
DEBUG - 2023-10-29 01:10:47 --> No URI present. Default controller set.
INFO - 2023-10-29 01:10:47 --> Router Class Initialized
INFO - 2023-10-29 01:10:47 --> Output Class Initialized
INFO - 2023-10-29 01:10:47 --> Security Class Initialized
DEBUG - 2023-10-29 01:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:10:47 --> Input Class Initialized
INFO - 2023-10-29 01:10:47 --> Language Class Initialized
INFO - 2023-10-29 01:10:48 --> Loader Class Initialized
INFO - 2023-10-29 01:10:48 --> Helper loaded: url_helper
INFO - 2023-10-29 01:10:48 --> Helper loaded: form_helper
INFO - 2023-10-29 01:10:48 --> Helper loaded: file_helper
INFO - 2023-10-29 01:10:48 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:10:48 --> Form Validation Class Initialized
INFO - 2023-10-29 01:10:48 --> Upload Class Initialized
INFO - 2023-10-29 01:10:48 --> Model "M_auth" initialized
ERROR - 2023-10-29 01:10:48 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 01:11:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:11:12 --> Config Class Initialized
INFO - 2023-10-29 01:11:12 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:11:12 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:11:12 --> Utf8 Class Initialized
INFO - 2023-10-29 01:11:12 --> URI Class Initialized
DEBUG - 2023-10-29 01:11:12 --> No URI present. Default controller set.
INFO - 2023-10-29 01:11:12 --> Router Class Initialized
INFO - 2023-10-29 01:11:12 --> Output Class Initialized
INFO - 2023-10-29 01:11:12 --> Security Class Initialized
DEBUG - 2023-10-29 01:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:11:12 --> Input Class Initialized
INFO - 2023-10-29 01:11:12 --> Language Class Initialized
INFO - 2023-10-29 01:11:12 --> Loader Class Initialized
INFO - 2023-10-29 01:11:12 --> Helper loaded: url_helper
INFO - 2023-10-29 01:11:12 --> Helper loaded: form_helper
INFO - 2023-10-29 01:11:12 --> Helper loaded: file_helper
INFO - 2023-10-29 01:11:12 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:11:12 --> Form Validation Class Initialized
INFO - 2023-10-29 01:11:12 --> Upload Class Initialized
INFO - 2023-10-29 01:11:12 --> Model "M_auth" initialized
INFO - 2023-10-29 01:11:12 --> Model "M_user" initialized
INFO - 2023-10-29 01:11:12 --> Model "M_produk" initialized
INFO - 2023-10-29 01:11:12 --> Controller Class Initialized
INFO - 2023-10-29 01:11:12 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 01:11:12 --> Model "M_produk" initialized
DEBUG - 2023-10-29 01:11:12 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 01:11:12 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 01:11:12 --> Model "M_transaksi" initialized
INFO - 2023-10-29 01:11:12 --> Model "M_bank" initialized
INFO - 2023-10-29 01:11:12 --> Model "M_pesan" initialized
INFO - 2023-10-29 01:11:13 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-29 01:11:13 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-29 01:11:13 --> Final output sent to browser
DEBUG - 2023-10-29 01:11:13 --> Total execution time: 0.2992
ERROR - 2023-10-29 01:11:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:11:16 --> Config Class Initialized
INFO - 2023-10-29 01:11:16 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:11:16 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:11:16 --> Utf8 Class Initialized
INFO - 2023-10-29 01:11:16 --> URI Class Initialized
INFO - 2023-10-29 01:11:16 --> Router Class Initialized
INFO - 2023-10-29 01:11:16 --> Output Class Initialized
INFO - 2023-10-29 01:11:16 --> Security Class Initialized
DEBUG - 2023-10-29 01:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:11:16 --> Input Class Initialized
INFO - 2023-10-29 01:11:16 --> Language Class Initialized
INFO - 2023-10-29 01:11:16 --> Loader Class Initialized
INFO - 2023-10-29 01:11:16 --> Helper loaded: url_helper
INFO - 2023-10-29 01:11:16 --> Helper loaded: form_helper
INFO - 2023-10-29 01:11:16 --> Helper loaded: file_helper
INFO - 2023-10-29 01:11:16 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:11:16 --> Form Validation Class Initialized
INFO - 2023-10-29 01:11:16 --> Upload Class Initialized
INFO - 2023-10-29 01:11:16 --> Model "M_auth" initialized
INFO - 2023-10-29 01:11:16 --> Model "M_user" initialized
INFO - 2023-10-29 01:11:16 --> Model "M_produk" initialized
INFO - 2023-10-29 01:11:16 --> Controller Class Initialized
INFO - 2023-10-29 01:11:16 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:11:16 --> Final output sent to browser
DEBUG - 2023-10-29 01:11:16 --> Total execution time: 0.0456
ERROR - 2023-10-29 01:15:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:15:51 --> Config Class Initialized
INFO - 2023-10-29 01:15:51 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:15:51 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:15:51 --> Utf8 Class Initialized
INFO - 2023-10-29 01:15:51 --> URI Class Initialized
INFO - 2023-10-29 01:15:51 --> Router Class Initialized
INFO - 2023-10-29 01:15:51 --> Output Class Initialized
INFO - 2023-10-29 01:15:51 --> Security Class Initialized
DEBUG - 2023-10-29 01:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:15:51 --> Input Class Initialized
INFO - 2023-10-29 01:15:51 --> Language Class Initialized
INFO - 2023-10-29 01:15:51 --> Loader Class Initialized
INFO - 2023-10-29 01:15:51 --> Helper loaded: url_helper
INFO - 2023-10-29 01:15:51 --> Helper loaded: form_helper
INFO - 2023-10-29 01:15:51 --> Helper loaded: file_helper
INFO - 2023-10-29 01:15:51 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:15:51 --> Form Validation Class Initialized
INFO - 2023-10-29 01:15:51 --> Upload Class Initialized
INFO - 2023-10-29 01:15:51 --> Model "M_auth" initialized
INFO - 2023-10-29 01:15:51 --> Model "M_user" initialized
INFO - 2023-10-29 01:15:51 --> Model "M_produk" initialized
INFO - 2023-10-29 01:15:51 --> Controller Class Initialized
INFO - 2023-10-29 01:15:51 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:15:51 --> Final output sent to browser
DEBUG - 2023-10-29 01:15:51 --> Total execution time: 0.0876
ERROR - 2023-10-29 01:15:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:15:53 --> Config Class Initialized
INFO - 2023-10-29 01:15:53 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:15:53 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:15:53 --> Utf8 Class Initialized
INFO - 2023-10-29 01:15:53 --> URI Class Initialized
INFO - 2023-10-29 01:15:53 --> Router Class Initialized
INFO - 2023-10-29 01:15:53 --> Output Class Initialized
INFO - 2023-10-29 01:15:53 --> Security Class Initialized
DEBUG - 2023-10-29 01:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:15:53 --> Input Class Initialized
INFO - 2023-10-29 01:15:53 --> Language Class Initialized
INFO - 2023-10-29 01:15:53 --> Loader Class Initialized
INFO - 2023-10-29 01:15:53 --> Helper loaded: url_helper
INFO - 2023-10-29 01:15:53 --> Helper loaded: form_helper
INFO - 2023-10-29 01:15:53 --> Helper loaded: file_helper
INFO - 2023-10-29 01:15:53 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:15:53 --> Form Validation Class Initialized
INFO - 2023-10-29 01:15:53 --> Upload Class Initialized
INFO - 2023-10-29 01:15:53 --> Model "M_auth" initialized
INFO - 2023-10-29 01:15:53 --> Model "M_user" initialized
INFO - 2023-10-29 01:15:53 --> Model "M_produk" initialized
INFO - 2023-10-29 01:15:53 --> Controller Class Initialized
ERROR - 2023-10-29 01:15:53 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 01:16:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:16:41 --> Config Class Initialized
INFO - 2023-10-29 01:16:41 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:16:41 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:16:41 --> Utf8 Class Initialized
INFO - 2023-10-29 01:16:41 --> URI Class Initialized
INFO - 2023-10-29 01:16:41 --> Router Class Initialized
INFO - 2023-10-29 01:16:41 --> Output Class Initialized
INFO - 2023-10-29 01:16:41 --> Security Class Initialized
DEBUG - 2023-10-29 01:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:16:41 --> Input Class Initialized
INFO - 2023-10-29 01:16:41 --> Language Class Initialized
INFO - 2023-10-29 01:16:41 --> Loader Class Initialized
INFO - 2023-10-29 01:16:41 --> Helper loaded: url_helper
INFO - 2023-10-29 01:16:41 --> Helper loaded: form_helper
INFO - 2023-10-29 01:16:41 --> Helper loaded: file_helper
INFO - 2023-10-29 01:16:41 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:16:41 --> Form Validation Class Initialized
INFO - 2023-10-29 01:16:41 --> Upload Class Initialized
INFO - 2023-10-29 01:16:41 --> Model "M_auth" initialized
INFO - 2023-10-29 01:16:41 --> Model "M_user" initialized
INFO - 2023-10-29 01:16:41 --> Model "M_produk" initialized
INFO - 2023-10-29 01:16:41 --> Controller Class Initialized
ERROR - 2023-10-29 01:16:41 --> Severity: error --> Exception: Class "Midtrans\Snap" not found C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Payment.php 22
ERROR - 2023-10-29 01:16:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:16:43 --> Config Class Initialized
INFO - 2023-10-29 01:16:43 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:16:43 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:16:43 --> Utf8 Class Initialized
INFO - 2023-10-29 01:16:43 --> URI Class Initialized
INFO - 2023-10-29 01:16:43 --> Router Class Initialized
INFO - 2023-10-29 01:16:43 --> Output Class Initialized
INFO - 2023-10-29 01:16:43 --> Security Class Initialized
DEBUG - 2023-10-29 01:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:16:43 --> Input Class Initialized
INFO - 2023-10-29 01:16:43 --> Language Class Initialized
INFO - 2023-10-29 01:16:43 --> Loader Class Initialized
INFO - 2023-10-29 01:16:43 --> Helper loaded: url_helper
INFO - 2023-10-29 01:16:43 --> Helper loaded: form_helper
INFO - 2023-10-29 01:16:43 --> Helper loaded: file_helper
INFO - 2023-10-29 01:16:44 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:16:44 --> Form Validation Class Initialized
INFO - 2023-10-29 01:16:44 --> Upload Class Initialized
INFO - 2023-10-29 01:16:44 --> Model "M_auth" initialized
INFO - 2023-10-29 01:16:44 --> Model "M_user" initialized
INFO - 2023-10-29 01:16:44 --> Model "M_produk" initialized
INFO - 2023-10-29 01:16:44 --> Controller Class Initialized
INFO - 2023-10-29 01:16:44 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:16:44 --> Final output sent to browser
DEBUG - 2023-10-29 01:16:44 --> Total execution time: 0.0672
ERROR - 2023-10-29 01:16:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:16:45 --> Config Class Initialized
INFO - 2023-10-29 01:16:45 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:16:45 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:16:45 --> Utf8 Class Initialized
INFO - 2023-10-29 01:16:45 --> URI Class Initialized
INFO - 2023-10-29 01:16:45 --> Router Class Initialized
INFO - 2023-10-29 01:16:45 --> Output Class Initialized
INFO - 2023-10-29 01:16:45 --> Security Class Initialized
DEBUG - 2023-10-29 01:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:16:45 --> Input Class Initialized
INFO - 2023-10-29 01:16:45 --> Language Class Initialized
INFO - 2023-10-29 01:16:45 --> Loader Class Initialized
INFO - 2023-10-29 01:16:45 --> Helper loaded: url_helper
INFO - 2023-10-29 01:16:45 --> Helper loaded: form_helper
INFO - 2023-10-29 01:16:45 --> Helper loaded: file_helper
INFO - 2023-10-29 01:16:45 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:16:45 --> Form Validation Class Initialized
INFO - 2023-10-29 01:16:45 --> Upload Class Initialized
INFO - 2023-10-29 01:16:45 --> Model "M_auth" initialized
INFO - 2023-10-29 01:16:45 --> Model "M_user" initialized
INFO - 2023-10-29 01:16:45 --> Model "M_produk" initialized
INFO - 2023-10-29 01:16:45 --> Controller Class Initialized
ERROR - 2023-10-29 01:16:45 --> Severity: error --> Exception: Class "Midtrans\Snap" not found C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Payment.php 22
ERROR - 2023-10-29 01:22:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:22:09 --> Config Class Initialized
INFO - 2023-10-29 01:22:09 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:22:09 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:22:09 --> Utf8 Class Initialized
INFO - 2023-10-29 01:22:09 --> URI Class Initialized
INFO - 2023-10-29 01:22:09 --> Router Class Initialized
INFO - 2023-10-29 01:22:09 --> Output Class Initialized
INFO - 2023-10-29 01:22:09 --> Security Class Initialized
DEBUG - 2023-10-29 01:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:22:09 --> Input Class Initialized
INFO - 2023-10-29 01:22:09 --> Language Class Initialized
INFO - 2023-10-29 01:22:09 --> Loader Class Initialized
INFO - 2023-10-29 01:22:09 --> Helper loaded: url_helper
INFO - 2023-10-29 01:22:09 --> Helper loaded: form_helper
INFO - 2023-10-29 01:22:09 --> Helper loaded: file_helper
INFO - 2023-10-29 01:22:09 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:22:09 --> Form Validation Class Initialized
INFO - 2023-10-29 01:22:09 --> Upload Class Initialized
INFO - 2023-10-29 01:22:09 --> Model "M_auth" initialized
INFO - 2023-10-29 01:22:09 --> Model "M_user" initialized
INFO - 2023-10-29 01:22:09 --> Model "M_produk" initialized
INFO - 2023-10-29 01:22:09 --> Controller Class Initialized
ERROR - 2023-10-29 01:22:09 --> Severity: error --> Exception: Class "Midtrans\Snap" not found C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Payment.php 27
ERROR - 2023-10-29 01:22:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:22:11 --> Config Class Initialized
INFO - 2023-10-29 01:22:11 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:22:11 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:22:11 --> Utf8 Class Initialized
INFO - 2023-10-29 01:22:11 --> URI Class Initialized
INFO - 2023-10-29 01:22:11 --> Router Class Initialized
INFO - 2023-10-29 01:22:11 --> Output Class Initialized
INFO - 2023-10-29 01:22:11 --> Security Class Initialized
DEBUG - 2023-10-29 01:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:22:11 --> Input Class Initialized
INFO - 2023-10-29 01:22:11 --> Language Class Initialized
INFO - 2023-10-29 01:22:11 --> Loader Class Initialized
INFO - 2023-10-29 01:22:11 --> Helper loaded: url_helper
INFO - 2023-10-29 01:22:11 --> Helper loaded: form_helper
INFO - 2023-10-29 01:22:11 --> Helper loaded: file_helper
INFO - 2023-10-29 01:22:11 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:22:11 --> Form Validation Class Initialized
INFO - 2023-10-29 01:22:11 --> Upload Class Initialized
INFO - 2023-10-29 01:22:11 --> Model "M_auth" initialized
INFO - 2023-10-29 01:22:11 --> Model "M_user" initialized
INFO - 2023-10-29 01:22:11 --> Model "M_produk" initialized
INFO - 2023-10-29 01:22:11 --> Controller Class Initialized
INFO - 2023-10-29 01:22:11 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:22:11 --> Final output sent to browser
DEBUG - 2023-10-29 01:22:11 --> Total execution time: 0.0656
ERROR - 2023-10-29 01:22:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:22:12 --> Config Class Initialized
INFO - 2023-10-29 01:22:12 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:22:12 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:22:12 --> Utf8 Class Initialized
INFO - 2023-10-29 01:22:12 --> URI Class Initialized
INFO - 2023-10-29 01:22:12 --> Router Class Initialized
INFO - 2023-10-29 01:22:12 --> Output Class Initialized
INFO - 2023-10-29 01:22:12 --> Security Class Initialized
DEBUG - 2023-10-29 01:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:22:12 --> Input Class Initialized
INFO - 2023-10-29 01:22:12 --> Language Class Initialized
INFO - 2023-10-29 01:22:12 --> Loader Class Initialized
INFO - 2023-10-29 01:22:12 --> Helper loaded: url_helper
INFO - 2023-10-29 01:22:12 --> Helper loaded: form_helper
INFO - 2023-10-29 01:22:12 --> Helper loaded: file_helper
INFO - 2023-10-29 01:22:12 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:22:12 --> Form Validation Class Initialized
INFO - 2023-10-29 01:22:12 --> Upload Class Initialized
INFO - 2023-10-29 01:22:12 --> Model "M_auth" initialized
INFO - 2023-10-29 01:22:12 --> Model "M_user" initialized
INFO - 2023-10-29 01:22:12 --> Model "M_produk" initialized
INFO - 2023-10-29 01:22:12 --> Controller Class Initialized
INFO - 2023-10-29 01:22:12 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:22:12 --> Final output sent to browser
DEBUG - 2023-10-29 01:22:12 --> Total execution time: 0.0928
ERROR - 2023-10-29 01:22:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:22:15 --> Config Class Initialized
INFO - 2023-10-29 01:22:15 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:22:15 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:22:15 --> Utf8 Class Initialized
INFO - 2023-10-29 01:22:15 --> URI Class Initialized
INFO - 2023-10-29 01:22:15 --> Router Class Initialized
INFO - 2023-10-29 01:22:15 --> Output Class Initialized
INFO - 2023-10-29 01:22:15 --> Security Class Initialized
DEBUG - 2023-10-29 01:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:22:15 --> Input Class Initialized
INFO - 2023-10-29 01:22:15 --> Language Class Initialized
INFO - 2023-10-29 01:22:15 --> Loader Class Initialized
INFO - 2023-10-29 01:22:15 --> Helper loaded: url_helper
INFO - 2023-10-29 01:22:15 --> Helper loaded: form_helper
INFO - 2023-10-29 01:22:15 --> Helper loaded: file_helper
INFO - 2023-10-29 01:22:15 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:22:15 --> Form Validation Class Initialized
INFO - 2023-10-29 01:22:15 --> Upload Class Initialized
INFO - 2023-10-29 01:22:15 --> Model "M_auth" initialized
INFO - 2023-10-29 01:22:15 --> Model "M_user" initialized
INFO - 2023-10-29 01:22:15 --> Model "M_produk" initialized
INFO - 2023-10-29 01:22:15 --> Controller Class Initialized
ERROR - 2023-10-29 01:22:15 --> Severity: error --> Exception: Class "Midtrans\Snap" not found C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Payment.php 27
ERROR - 2023-10-29 01:23:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:23:23 --> Config Class Initialized
INFO - 2023-10-29 01:23:23 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:23:23 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:23:23 --> Utf8 Class Initialized
INFO - 2023-10-29 01:23:23 --> URI Class Initialized
INFO - 2023-10-29 01:23:23 --> Router Class Initialized
INFO - 2023-10-29 01:23:23 --> Output Class Initialized
INFO - 2023-10-29 01:23:23 --> Security Class Initialized
DEBUG - 2023-10-29 01:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:23:23 --> Input Class Initialized
INFO - 2023-10-29 01:23:23 --> Language Class Initialized
INFO - 2023-10-29 01:23:23 --> Loader Class Initialized
INFO - 2023-10-29 01:23:23 --> Helper loaded: url_helper
INFO - 2023-10-29 01:23:23 --> Helper loaded: form_helper
INFO - 2023-10-29 01:23:23 --> Helper loaded: file_helper
INFO - 2023-10-29 01:23:23 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:23:23 --> Form Validation Class Initialized
INFO - 2023-10-29 01:23:23 --> Upload Class Initialized
INFO - 2023-10-29 01:23:23 --> Model "M_auth" initialized
INFO - 2023-10-29 01:23:23 --> Model "M_user" initialized
INFO - 2023-10-29 01:23:23 --> Model "M_produk" initialized
INFO - 2023-10-29 01:23:23 --> Controller Class Initialized
ERROR - 2023-10-29 01:23:23 --> Severity: error --> Exception: Class "Midtrans\Snap" not found C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Payment.php 27
ERROR - 2023-10-29 01:23:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:23:25 --> Config Class Initialized
INFO - 2023-10-29 01:23:25 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:23:25 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:23:25 --> Utf8 Class Initialized
INFO - 2023-10-29 01:23:25 --> URI Class Initialized
INFO - 2023-10-29 01:23:25 --> Router Class Initialized
INFO - 2023-10-29 01:23:25 --> Output Class Initialized
INFO - 2023-10-29 01:23:25 --> Security Class Initialized
DEBUG - 2023-10-29 01:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:23:25 --> Input Class Initialized
INFO - 2023-10-29 01:23:25 --> Language Class Initialized
INFO - 2023-10-29 01:23:25 --> Loader Class Initialized
INFO - 2023-10-29 01:23:25 --> Helper loaded: url_helper
INFO - 2023-10-29 01:23:25 --> Helper loaded: form_helper
INFO - 2023-10-29 01:23:25 --> Helper loaded: file_helper
INFO - 2023-10-29 01:23:25 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:23:25 --> Form Validation Class Initialized
INFO - 2023-10-29 01:23:25 --> Upload Class Initialized
INFO - 2023-10-29 01:23:25 --> Model "M_auth" initialized
INFO - 2023-10-29 01:23:25 --> Model "M_user" initialized
INFO - 2023-10-29 01:23:25 --> Model "M_produk" initialized
INFO - 2023-10-29 01:23:25 --> Controller Class Initialized
INFO - 2023-10-29 01:23:25 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:23:25 --> Final output sent to browser
DEBUG - 2023-10-29 01:23:25 --> Total execution time: 0.0821
ERROR - 2023-10-29 01:23:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:23:26 --> Config Class Initialized
INFO - 2023-10-29 01:23:26 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:23:26 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:23:26 --> Utf8 Class Initialized
INFO - 2023-10-29 01:23:26 --> URI Class Initialized
INFO - 2023-10-29 01:23:26 --> Router Class Initialized
INFO - 2023-10-29 01:23:26 --> Output Class Initialized
INFO - 2023-10-29 01:23:26 --> Security Class Initialized
DEBUG - 2023-10-29 01:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:23:26 --> Input Class Initialized
INFO - 2023-10-29 01:23:26 --> Language Class Initialized
INFO - 2023-10-29 01:23:26 --> Loader Class Initialized
INFO - 2023-10-29 01:23:26 --> Helper loaded: url_helper
INFO - 2023-10-29 01:23:26 --> Helper loaded: form_helper
INFO - 2023-10-29 01:23:26 --> Helper loaded: file_helper
INFO - 2023-10-29 01:23:26 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:23:26 --> Form Validation Class Initialized
INFO - 2023-10-29 01:23:26 --> Upload Class Initialized
INFO - 2023-10-29 01:23:26 --> Model "M_auth" initialized
INFO - 2023-10-29 01:23:26 --> Model "M_user" initialized
INFO - 2023-10-29 01:23:26 --> Model "M_produk" initialized
INFO - 2023-10-29 01:23:26 --> Controller Class Initialized
ERROR - 2023-10-29 01:23:26 --> Severity: error --> Exception: Class "Midtrans\Snap" not found C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Payment.php 27
ERROR - 2023-10-29 01:23:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:23:43 --> Config Class Initialized
INFO - 2023-10-29 01:23:43 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:23:43 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:23:43 --> Utf8 Class Initialized
INFO - 2023-10-29 01:23:43 --> URI Class Initialized
INFO - 2023-10-29 01:23:43 --> Router Class Initialized
INFO - 2023-10-29 01:23:43 --> Output Class Initialized
INFO - 2023-10-29 01:23:43 --> Security Class Initialized
DEBUG - 2023-10-29 01:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:23:43 --> Input Class Initialized
INFO - 2023-10-29 01:23:43 --> Language Class Initialized
INFO - 2023-10-29 01:23:43 --> Loader Class Initialized
INFO - 2023-10-29 01:23:43 --> Helper loaded: url_helper
INFO - 2023-10-29 01:23:43 --> Helper loaded: form_helper
INFO - 2023-10-29 01:23:43 --> Helper loaded: file_helper
INFO - 2023-10-29 01:23:43 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:23:43 --> Form Validation Class Initialized
INFO - 2023-10-29 01:23:43 --> Upload Class Initialized
INFO - 2023-10-29 01:23:43 --> Model "M_auth" initialized
INFO - 2023-10-29 01:23:43 --> Model "M_user" initialized
INFO - 2023-10-29 01:23:43 --> Model "M_produk" initialized
INFO - 2023-10-29 01:23:43 --> Controller Class Initialized
ERROR - 2023-10-29 01:23:43 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 01:26:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:26:30 --> Config Class Initialized
INFO - 2023-10-29 01:26:30 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:26:30 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:26:30 --> Utf8 Class Initialized
INFO - 2023-10-29 01:26:30 --> URI Class Initialized
INFO - 2023-10-29 01:26:30 --> Router Class Initialized
INFO - 2023-10-29 01:26:30 --> Output Class Initialized
INFO - 2023-10-29 01:26:30 --> Security Class Initialized
DEBUG - 2023-10-29 01:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:26:30 --> Input Class Initialized
INFO - 2023-10-29 01:26:30 --> Language Class Initialized
INFO - 2023-10-29 01:26:30 --> Loader Class Initialized
INFO - 2023-10-29 01:26:30 --> Helper loaded: url_helper
INFO - 2023-10-29 01:26:30 --> Helper loaded: form_helper
INFO - 2023-10-29 01:26:30 --> Helper loaded: file_helper
INFO - 2023-10-29 01:26:30 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:26:30 --> Form Validation Class Initialized
INFO - 2023-10-29 01:26:30 --> Upload Class Initialized
INFO - 2023-10-29 01:26:30 --> Model "M_auth" initialized
ERROR - 2023-10-29 01:26:30 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 01:26:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:26:32 --> Config Class Initialized
INFO - 2023-10-29 01:26:32 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:26:32 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:26:32 --> Utf8 Class Initialized
INFO - 2023-10-29 01:26:32 --> URI Class Initialized
INFO - 2023-10-29 01:26:32 --> Router Class Initialized
INFO - 2023-10-29 01:26:32 --> Output Class Initialized
INFO - 2023-10-29 01:26:32 --> Security Class Initialized
DEBUG - 2023-10-29 01:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:26:32 --> Input Class Initialized
INFO - 2023-10-29 01:26:32 --> Language Class Initialized
INFO - 2023-10-29 01:26:32 --> Loader Class Initialized
INFO - 2023-10-29 01:26:32 --> Helper loaded: url_helper
INFO - 2023-10-29 01:26:32 --> Helper loaded: form_helper
INFO - 2023-10-29 01:26:32 --> Helper loaded: file_helper
INFO - 2023-10-29 01:26:32 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:26:32 --> Form Validation Class Initialized
INFO - 2023-10-29 01:26:32 --> Upload Class Initialized
INFO - 2023-10-29 01:26:32 --> Model "M_auth" initialized
ERROR - 2023-10-29 01:26:32 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 01:37:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:37:06 --> Config Class Initialized
INFO - 2023-10-29 01:37:06 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:37:06 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:37:06 --> Utf8 Class Initialized
INFO - 2023-10-29 01:37:06 --> URI Class Initialized
INFO - 2023-10-29 01:37:06 --> Router Class Initialized
INFO - 2023-10-29 01:37:06 --> Output Class Initialized
INFO - 2023-10-29 01:37:06 --> Security Class Initialized
DEBUG - 2023-10-29 01:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:37:06 --> Input Class Initialized
INFO - 2023-10-29 01:37:06 --> Language Class Initialized
INFO - 2023-10-29 01:37:06 --> Loader Class Initialized
INFO - 2023-10-29 01:37:06 --> Helper loaded: url_helper
INFO - 2023-10-29 01:37:06 --> Helper loaded: form_helper
INFO - 2023-10-29 01:37:06 --> Helper loaded: file_helper
INFO - 2023-10-29 01:37:06 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:37:06 --> Form Validation Class Initialized
INFO - 2023-10-29 01:37:06 --> Upload Class Initialized
INFO - 2023-10-29 01:37:06 --> Model "M_auth" initialized
ERROR - 2023-10-29 01:37:06 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 01:37:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:37:07 --> Config Class Initialized
INFO - 2023-10-29 01:37:07 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:37:07 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:37:07 --> Utf8 Class Initialized
INFO - 2023-10-29 01:37:07 --> URI Class Initialized
INFO - 2023-10-29 01:37:07 --> Router Class Initialized
INFO - 2023-10-29 01:37:07 --> Output Class Initialized
INFO - 2023-10-29 01:37:07 --> Security Class Initialized
DEBUG - 2023-10-29 01:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:37:07 --> Input Class Initialized
INFO - 2023-10-29 01:37:07 --> Language Class Initialized
INFO - 2023-10-29 01:37:07 --> Loader Class Initialized
INFO - 2023-10-29 01:37:07 --> Helper loaded: url_helper
INFO - 2023-10-29 01:37:07 --> Helper loaded: form_helper
INFO - 2023-10-29 01:37:07 --> Helper loaded: file_helper
INFO - 2023-10-29 01:37:07 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:37:07 --> Form Validation Class Initialized
INFO - 2023-10-29 01:37:07 --> Upload Class Initialized
INFO - 2023-10-29 01:37:07 --> Model "M_auth" initialized
ERROR - 2023-10-29 01:37:07 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 01:37:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:37:07 --> Config Class Initialized
INFO - 2023-10-29 01:37:07 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:37:07 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:37:07 --> Utf8 Class Initialized
INFO - 2023-10-29 01:37:07 --> URI Class Initialized
INFO - 2023-10-29 01:37:07 --> Router Class Initialized
INFO - 2023-10-29 01:37:07 --> Output Class Initialized
INFO - 2023-10-29 01:37:07 --> Security Class Initialized
DEBUG - 2023-10-29 01:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:37:07 --> Input Class Initialized
INFO - 2023-10-29 01:37:07 --> Language Class Initialized
INFO - 2023-10-29 01:37:07 --> Loader Class Initialized
INFO - 2023-10-29 01:37:07 --> Helper loaded: url_helper
INFO - 2023-10-29 01:37:07 --> Helper loaded: form_helper
INFO - 2023-10-29 01:37:07 --> Helper loaded: file_helper
INFO - 2023-10-29 01:37:07 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:37:07 --> Form Validation Class Initialized
INFO - 2023-10-29 01:37:07 --> Upload Class Initialized
INFO - 2023-10-29 01:37:07 --> Model "M_auth" initialized
ERROR - 2023-10-29 01:37:07 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 01:37:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:37:07 --> Config Class Initialized
INFO - 2023-10-29 01:37:07 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:37:07 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:37:07 --> Utf8 Class Initialized
INFO - 2023-10-29 01:37:07 --> URI Class Initialized
INFO - 2023-10-29 01:37:07 --> Router Class Initialized
INFO - 2023-10-29 01:37:07 --> Output Class Initialized
INFO - 2023-10-29 01:37:07 --> Security Class Initialized
DEBUG - 2023-10-29 01:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:37:07 --> Input Class Initialized
INFO - 2023-10-29 01:37:07 --> Language Class Initialized
INFO - 2023-10-29 01:37:07 --> Loader Class Initialized
INFO - 2023-10-29 01:37:07 --> Helper loaded: url_helper
INFO - 2023-10-29 01:37:07 --> Helper loaded: form_helper
INFO - 2023-10-29 01:37:07 --> Helper loaded: file_helper
INFO - 2023-10-29 01:37:07 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:37:07 --> Form Validation Class Initialized
INFO - 2023-10-29 01:37:07 --> Upload Class Initialized
INFO - 2023-10-29 01:37:07 --> Model "M_auth" initialized
ERROR - 2023-10-29 01:37:07 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 01:37:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:37:08 --> Config Class Initialized
INFO - 2023-10-29 01:37:08 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:37:08 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:37:08 --> Utf8 Class Initialized
INFO - 2023-10-29 01:37:08 --> URI Class Initialized
INFO - 2023-10-29 01:37:08 --> Router Class Initialized
INFO - 2023-10-29 01:37:08 --> Output Class Initialized
INFO - 2023-10-29 01:37:08 --> Security Class Initialized
DEBUG - 2023-10-29 01:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:37:08 --> Input Class Initialized
INFO - 2023-10-29 01:37:08 --> Language Class Initialized
INFO - 2023-10-29 01:37:08 --> Loader Class Initialized
INFO - 2023-10-29 01:37:08 --> Helper loaded: url_helper
INFO - 2023-10-29 01:37:08 --> Helper loaded: form_helper
INFO - 2023-10-29 01:37:08 --> Helper loaded: file_helper
INFO - 2023-10-29 01:37:08 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:37:08 --> Form Validation Class Initialized
INFO - 2023-10-29 01:37:08 --> Upload Class Initialized
INFO - 2023-10-29 01:37:08 --> Model "M_auth" initialized
ERROR - 2023-10-29 01:37:08 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 01:38:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:38:06 --> Config Class Initialized
INFO - 2023-10-29 01:38:06 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:38:06 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:38:06 --> Utf8 Class Initialized
INFO - 2023-10-29 01:38:06 --> URI Class Initialized
INFO - 2023-10-29 01:38:06 --> Router Class Initialized
INFO - 2023-10-29 01:38:06 --> Output Class Initialized
INFO - 2023-10-29 01:38:06 --> Security Class Initialized
DEBUG - 2023-10-29 01:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:38:06 --> Input Class Initialized
INFO - 2023-10-29 01:38:06 --> Language Class Initialized
INFO - 2023-10-29 01:38:06 --> Loader Class Initialized
INFO - 2023-10-29 01:38:06 --> Helper loaded: url_helper
INFO - 2023-10-29 01:38:06 --> Helper loaded: form_helper
INFO - 2023-10-29 01:38:06 --> Helper loaded: file_helper
INFO - 2023-10-29 01:38:06 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:38:06 --> Form Validation Class Initialized
INFO - 2023-10-29 01:38:06 --> Upload Class Initialized
INFO - 2023-10-29 01:38:06 --> Model "M_auth" initialized
INFO - 2023-10-29 01:38:06 --> Model "M_user" initialized
INFO - 2023-10-29 01:38:06 --> Model "M_produk" initialized
INFO - 2023-10-29 01:38:06 --> Controller Class Initialized
INFO - 2023-10-29 01:38:06 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:38:06 --> Final output sent to browser
DEBUG - 2023-10-29 01:38:06 --> Total execution time: 0.0631
ERROR - 2023-10-29 01:38:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:38:08 --> Config Class Initialized
INFO - 2023-10-29 01:38:08 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:38:08 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:38:08 --> Utf8 Class Initialized
INFO - 2023-10-29 01:38:08 --> URI Class Initialized
INFO - 2023-10-29 01:38:08 --> Router Class Initialized
INFO - 2023-10-29 01:38:08 --> Output Class Initialized
INFO - 2023-10-29 01:38:08 --> Security Class Initialized
DEBUG - 2023-10-29 01:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:38:08 --> Input Class Initialized
INFO - 2023-10-29 01:38:08 --> Language Class Initialized
INFO - 2023-10-29 01:38:08 --> Loader Class Initialized
INFO - 2023-10-29 01:38:08 --> Helper loaded: url_helper
INFO - 2023-10-29 01:38:08 --> Helper loaded: form_helper
INFO - 2023-10-29 01:38:08 --> Helper loaded: file_helper
INFO - 2023-10-29 01:38:08 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:38:08 --> Form Validation Class Initialized
INFO - 2023-10-29 01:38:08 --> Upload Class Initialized
INFO - 2023-10-29 01:38:08 --> Model "M_auth" initialized
INFO - 2023-10-29 01:38:08 --> Model "M_user" initialized
INFO - 2023-10-29 01:38:08 --> Model "M_produk" initialized
INFO - 2023-10-29 01:38:08 --> Controller Class Initialized
ERROR - 2023-10-29 01:38:08 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 01:38:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:38:09 --> Config Class Initialized
INFO - 2023-10-29 01:38:09 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:38:09 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:38:09 --> Utf8 Class Initialized
INFO - 2023-10-29 01:38:09 --> URI Class Initialized
INFO - 2023-10-29 01:38:09 --> Router Class Initialized
INFO - 2023-10-29 01:38:09 --> Output Class Initialized
INFO - 2023-10-29 01:38:09 --> Security Class Initialized
DEBUG - 2023-10-29 01:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:38:09 --> Input Class Initialized
INFO - 2023-10-29 01:38:09 --> Language Class Initialized
INFO - 2023-10-29 01:38:09 --> Loader Class Initialized
INFO - 2023-10-29 01:38:09 --> Helper loaded: url_helper
INFO - 2023-10-29 01:38:09 --> Helper loaded: form_helper
INFO - 2023-10-29 01:38:09 --> Helper loaded: file_helper
INFO - 2023-10-29 01:38:09 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:38:09 --> Form Validation Class Initialized
INFO - 2023-10-29 01:38:09 --> Upload Class Initialized
INFO - 2023-10-29 01:38:09 --> Model "M_auth" initialized
INFO - 2023-10-29 01:38:09 --> Model "M_user" initialized
INFO - 2023-10-29 01:38:09 --> Model "M_produk" initialized
INFO - 2023-10-29 01:38:09 --> Controller Class Initialized
INFO - 2023-10-29 01:38:09 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:38:09 --> Final output sent to browser
DEBUG - 2023-10-29 01:38:09 --> Total execution time: 0.0562
ERROR - 2023-10-29 01:38:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:38:22 --> Config Class Initialized
INFO - 2023-10-29 01:38:22 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:38:23 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:38:23 --> Utf8 Class Initialized
INFO - 2023-10-29 01:38:23 --> URI Class Initialized
INFO - 2023-10-29 01:38:23 --> Router Class Initialized
INFO - 2023-10-29 01:38:23 --> Output Class Initialized
INFO - 2023-10-29 01:38:23 --> Security Class Initialized
DEBUG - 2023-10-29 01:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:38:23 --> Input Class Initialized
INFO - 2023-10-29 01:38:23 --> Language Class Initialized
INFO - 2023-10-29 01:38:23 --> Loader Class Initialized
INFO - 2023-10-29 01:38:23 --> Helper loaded: url_helper
INFO - 2023-10-29 01:38:23 --> Helper loaded: form_helper
INFO - 2023-10-29 01:38:23 --> Helper loaded: file_helper
INFO - 2023-10-29 01:38:23 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:38:23 --> Form Validation Class Initialized
INFO - 2023-10-29 01:38:23 --> Upload Class Initialized
INFO - 2023-10-29 01:38:23 --> Model "M_auth" initialized
INFO - 2023-10-29 01:38:23 --> Model "M_user" initialized
INFO - 2023-10-29 01:38:23 --> Model "M_produk" initialized
INFO - 2023-10-29 01:38:23 --> Controller Class Initialized
INFO - 2023-10-29 01:38:23 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:38:23 --> Final output sent to browser
DEBUG - 2023-10-29 01:38:23 --> Total execution time: 0.0882
ERROR - 2023-10-29 01:38:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:38:23 --> Config Class Initialized
INFO - 2023-10-29 01:38:23 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:38:23 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:38:23 --> Utf8 Class Initialized
INFO - 2023-10-29 01:38:23 --> URI Class Initialized
INFO - 2023-10-29 01:38:23 --> Router Class Initialized
INFO - 2023-10-29 01:38:23 --> Output Class Initialized
INFO - 2023-10-29 01:38:23 --> Security Class Initialized
DEBUG - 2023-10-29 01:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:38:23 --> Input Class Initialized
INFO - 2023-10-29 01:38:23 --> Language Class Initialized
INFO - 2023-10-29 01:38:23 --> Loader Class Initialized
INFO - 2023-10-29 01:38:23 --> Helper loaded: url_helper
INFO - 2023-10-29 01:38:23 --> Helper loaded: form_helper
INFO - 2023-10-29 01:38:23 --> Helper loaded: file_helper
INFO - 2023-10-29 01:38:23 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:38:23 --> Form Validation Class Initialized
INFO - 2023-10-29 01:38:23 --> Upload Class Initialized
INFO - 2023-10-29 01:38:23 --> Model "M_auth" initialized
INFO - 2023-10-29 01:38:23 --> Model "M_user" initialized
INFO - 2023-10-29 01:38:23 --> Model "M_produk" initialized
INFO - 2023-10-29 01:38:23 --> Controller Class Initialized
ERROR - 2023-10-29 01:38:23 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 01:38:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:38:25 --> Config Class Initialized
INFO - 2023-10-29 01:38:25 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:38:25 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:38:25 --> Utf8 Class Initialized
INFO - 2023-10-29 01:38:25 --> URI Class Initialized
INFO - 2023-10-29 01:38:25 --> Router Class Initialized
INFO - 2023-10-29 01:38:25 --> Output Class Initialized
INFO - 2023-10-29 01:38:25 --> Security Class Initialized
DEBUG - 2023-10-29 01:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:38:25 --> Input Class Initialized
INFO - 2023-10-29 01:38:25 --> Language Class Initialized
INFO - 2023-10-29 01:38:25 --> Loader Class Initialized
INFO - 2023-10-29 01:38:25 --> Helper loaded: url_helper
INFO - 2023-10-29 01:38:25 --> Helper loaded: form_helper
INFO - 2023-10-29 01:38:25 --> Helper loaded: file_helper
INFO - 2023-10-29 01:38:25 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:38:25 --> Form Validation Class Initialized
INFO - 2023-10-29 01:38:25 --> Upload Class Initialized
INFO - 2023-10-29 01:38:25 --> Model "M_auth" initialized
INFO - 2023-10-29 01:38:25 --> Model "M_user" initialized
INFO - 2023-10-29 01:38:25 --> Model "M_produk" initialized
INFO - 2023-10-29 01:38:25 --> Controller Class Initialized
INFO - 2023-10-29 01:38:25 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:38:25 --> Final output sent to browser
DEBUG - 2023-10-29 01:38:25 --> Total execution time: 0.0554
ERROR - 2023-10-29 01:38:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:38:54 --> Config Class Initialized
INFO - 2023-10-29 01:38:54 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:38:54 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:38:54 --> Utf8 Class Initialized
INFO - 2023-10-29 01:38:54 --> URI Class Initialized
INFO - 2023-10-29 01:38:54 --> Router Class Initialized
INFO - 2023-10-29 01:38:54 --> Output Class Initialized
INFO - 2023-10-29 01:38:54 --> Security Class Initialized
DEBUG - 2023-10-29 01:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:38:54 --> Input Class Initialized
INFO - 2023-10-29 01:38:54 --> Language Class Initialized
INFO - 2023-10-29 01:38:54 --> Loader Class Initialized
INFO - 2023-10-29 01:38:54 --> Helper loaded: url_helper
INFO - 2023-10-29 01:38:54 --> Helper loaded: form_helper
INFO - 2023-10-29 01:38:54 --> Helper loaded: file_helper
INFO - 2023-10-29 01:38:54 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:38:54 --> Form Validation Class Initialized
INFO - 2023-10-29 01:38:54 --> Upload Class Initialized
INFO - 2023-10-29 01:38:54 --> Model "M_auth" initialized
INFO - 2023-10-29 01:38:54 --> Model "M_user" initialized
INFO - 2023-10-29 01:38:54 --> Model "M_produk" initialized
INFO - 2023-10-29 01:38:54 --> Controller Class Initialized
INFO - 2023-10-29 01:38:54 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:38:54 --> Final output sent to browser
DEBUG - 2023-10-29 01:38:54 --> Total execution time: 0.0711
ERROR - 2023-10-29 01:38:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:38:55 --> Config Class Initialized
INFO - 2023-10-29 01:38:55 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:38:55 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:38:55 --> Utf8 Class Initialized
INFO - 2023-10-29 01:38:55 --> URI Class Initialized
INFO - 2023-10-29 01:38:55 --> Router Class Initialized
INFO - 2023-10-29 01:38:55 --> Output Class Initialized
INFO - 2023-10-29 01:38:55 --> Security Class Initialized
DEBUG - 2023-10-29 01:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:38:55 --> Input Class Initialized
INFO - 2023-10-29 01:38:55 --> Language Class Initialized
INFO - 2023-10-29 01:38:55 --> Loader Class Initialized
INFO - 2023-10-29 01:38:55 --> Helper loaded: url_helper
INFO - 2023-10-29 01:38:55 --> Helper loaded: form_helper
INFO - 2023-10-29 01:38:55 --> Helper loaded: file_helper
INFO - 2023-10-29 01:38:55 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:38:55 --> Form Validation Class Initialized
INFO - 2023-10-29 01:38:55 --> Upload Class Initialized
INFO - 2023-10-29 01:38:55 --> Model "M_auth" initialized
INFO - 2023-10-29 01:38:55 --> Model "M_user" initialized
INFO - 2023-10-29 01:38:55 --> Model "M_produk" initialized
INFO - 2023-10-29 01:38:55 --> Controller Class Initialized
ERROR - 2023-10-29 01:38:55 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 01:39:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:39:44 --> Config Class Initialized
INFO - 2023-10-29 01:39:44 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:39:44 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:39:44 --> Utf8 Class Initialized
INFO - 2023-10-29 01:39:44 --> URI Class Initialized
INFO - 2023-10-29 01:39:44 --> Router Class Initialized
INFO - 2023-10-29 01:39:44 --> Output Class Initialized
INFO - 2023-10-29 01:39:44 --> Security Class Initialized
DEBUG - 2023-10-29 01:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:39:44 --> Input Class Initialized
INFO - 2023-10-29 01:39:44 --> Language Class Initialized
INFO - 2023-10-29 01:39:44 --> Loader Class Initialized
INFO - 2023-10-29 01:39:44 --> Helper loaded: url_helper
INFO - 2023-10-29 01:39:44 --> Helper loaded: form_helper
INFO - 2023-10-29 01:39:44 --> Helper loaded: file_helper
INFO - 2023-10-29 01:39:44 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:39:44 --> Form Validation Class Initialized
INFO - 2023-10-29 01:39:44 --> Upload Class Initialized
INFO - 2023-10-29 01:39:44 --> Model "M_auth" initialized
INFO - 2023-10-29 01:39:44 --> Model "M_user" initialized
INFO - 2023-10-29 01:39:44 --> Model "M_produk" initialized
INFO - 2023-10-29 01:39:44 --> Controller Class Initialized
INFO - 2023-10-29 01:39:44 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:39:44 --> Final output sent to browser
DEBUG - 2023-10-29 01:39:44 --> Total execution time: 0.0653
ERROR - 2023-10-29 01:39:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:39:45 --> Config Class Initialized
INFO - 2023-10-29 01:39:45 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:39:45 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:39:45 --> Utf8 Class Initialized
INFO - 2023-10-29 01:39:45 --> URI Class Initialized
INFO - 2023-10-29 01:39:45 --> Router Class Initialized
INFO - 2023-10-29 01:39:45 --> Output Class Initialized
INFO - 2023-10-29 01:39:45 --> Security Class Initialized
DEBUG - 2023-10-29 01:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:39:45 --> Input Class Initialized
INFO - 2023-10-29 01:39:45 --> Language Class Initialized
INFO - 2023-10-29 01:39:45 --> Loader Class Initialized
INFO - 2023-10-29 01:39:45 --> Helper loaded: url_helper
INFO - 2023-10-29 01:39:45 --> Helper loaded: form_helper
INFO - 2023-10-29 01:39:45 --> Helper loaded: file_helper
INFO - 2023-10-29 01:39:45 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:39:45 --> Form Validation Class Initialized
INFO - 2023-10-29 01:39:45 --> Upload Class Initialized
INFO - 2023-10-29 01:39:45 --> Model "M_auth" initialized
INFO - 2023-10-29 01:39:45 --> Model "M_user" initialized
INFO - 2023-10-29 01:39:45 --> Model "M_produk" initialized
INFO - 2023-10-29 01:39:45 --> Controller Class Initialized
ERROR - 2023-10-29 01:39:45 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 01:39:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:39:46 --> Config Class Initialized
INFO - 2023-10-29 01:39:46 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:39:46 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:39:46 --> Utf8 Class Initialized
INFO - 2023-10-29 01:39:46 --> URI Class Initialized
INFO - 2023-10-29 01:39:46 --> Router Class Initialized
INFO - 2023-10-29 01:39:46 --> Output Class Initialized
INFO - 2023-10-29 01:39:46 --> Security Class Initialized
DEBUG - 2023-10-29 01:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:39:46 --> Input Class Initialized
INFO - 2023-10-29 01:39:46 --> Language Class Initialized
INFO - 2023-10-29 01:39:46 --> Loader Class Initialized
INFO - 2023-10-29 01:39:46 --> Helper loaded: url_helper
INFO - 2023-10-29 01:39:46 --> Helper loaded: form_helper
INFO - 2023-10-29 01:39:46 --> Helper loaded: file_helper
INFO - 2023-10-29 01:39:46 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:39:46 --> Form Validation Class Initialized
INFO - 2023-10-29 01:39:46 --> Upload Class Initialized
INFO - 2023-10-29 01:39:46 --> Model "M_auth" initialized
INFO - 2023-10-29 01:39:46 --> Model "M_user" initialized
INFO - 2023-10-29 01:39:46 --> Model "M_produk" initialized
INFO - 2023-10-29 01:39:46 --> Controller Class Initialized
INFO - 2023-10-29 01:39:46 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:39:46 --> Final output sent to browser
DEBUG - 2023-10-29 01:39:46 --> Total execution time: 0.0543
ERROR - 2023-10-29 01:39:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:39:47 --> Config Class Initialized
INFO - 2023-10-29 01:39:47 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:39:47 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:39:47 --> Utf8 Class Initialized
INFO - 2023-10-29 01:39:47 --> URI Class Initialized
INFO - 2023-10-29 01:39:47 --> Router Class Initialized
INFO - 2023-10-29 01:39:47 --> Output Class Initialized
INFO - 2023-10-29 01:39:47 --> Security Class Initialized
DEBUG - 2023-10-29 01:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:39:47 --> Input Class Initialized
INFO - 2023-10-29 01:39:47 --> Language Class Initialized
INFO - 2023-10-29 01:39:47 --> Loader Class Initialized
INFO - 2023-10-29 01:39:47 --> Helper loaded: url_helper
INFO - 2023-10-29 01:39:47 --> Helper loaded: form_helper
INFO - 2023-10-29 01:39:47 --> Helper loaded: file_helper
INFO - 2023-10-29 01:39:47 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:39:47 --> Form Validation Class Initialized
INFO - 2023-10-29 01:39:47 --> Upload Class Initialized
INFO - 2023-10-29 01:39:47 --> Model "M_auth" initialized
INFO - 2023-10-29 01:39:47 --> Model "M_user" initialized
INFO - 2023-10-29 01:39:47 --> Model "M_produk" initialized
INFO - 2023-10-29 01:39:47 --> Controller Class Initialized
INFO - 2023-10-29 01:39:47 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:39:47 --> Final output sent to browser
DEBUG - 2023-10-29 01:39:47 --> Total execution time: 0.0540
ERROR - 2023-10-29 01:39:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:39:48 --> Config Class Initialized
INFO - 2023-10-29 01:39:48 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:39:48 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:39:48 --> Utf8 Class Initialized
INFO - 2023-10-29 01:39:48 --> URI Class Initialized
INFO - 2023-10-29 01:39:48 --> Router Class Initialized
INFO - 2023-10-29 01:39:48 --> Output Class Initialized
INFO - 2023-10-29 01:39:48 --> Security Class Initialized
DEBUG - 2023-10-29 01:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:39:48 --> Input Class Initialized
INFO - 2023-10-29 01:39:48 --> Language Class Initialized
INFO - 2023-10-29 01:39:48 --> Loader Class Initialized
INFO - 2023-10-29 01:39:48 --> Helper loaded: url_helper
INFO - 2023-10-29 01:39:48 --> Helper loaded: form_helper
INFO - 2023-10-29 01:39:48 --> Helper loaded: file_helper
INFO - 2023-10-29 01:39:48 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:39:48 --> Form Validation Class Initialized
INFO - 2023-10-29 01:39:48 --> Upload Class Initialized
INFO - 2023-10-29 01:39:48 --> Model "M_auth" initialized
INFO - 2023-10-29 01:39:48 --> Model "M_user" initialized
INFO - 2023-10-29 01:39:48 --> Model "M_produk" initialized
INFO - 2023-10-29 01:39:48 --> Controller Class Initialized
INFO - 2023-10-29 01:39:48 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:39:48 --> Final output sent to browser
DEBUG - 2023-10-29 01:39:48 --> Total execution time: 0.0960
ERROR - 2023-10-29 01:39:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:39:48 --> Config Class Initialized
INFO - 2023-10-29 01:39:48 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:39:48 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:39:48 --> Utf8 Class Initialized
INFO - 2023-10-29 01:39:48 --> URI Class Initialized
INFO - 2023-10-29 01:39:48 --> Router Class Initialized
INFO - 2023-10-29 01:39:48 --> Output Class Initialized
INFO - 2023-10-29 01:39:48 --> Security Class Initialized
DEBUG - 2023-10-29 01:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:39:48 --> Input Class Initialized
INFO - 2023-10-29 01:39:48 --> Language Class Initialized
INFO - 2023-10-29 01:39:48 --> Loader Class Initialized
INFO - 2023-10-29 01:39:48 --> Helper loaded: url_helper
INFO - 2023-10-29 01:39:48 --> Helper loaded: form_helper
INFO - 2023-10-29 01:39:48 --> Helper loaded: file_helper
INFO - 2023-10-29 01:39:48 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:39:48 --> Form Validation Class Initialized
INFO - 2023-10-29 01:39:48 --> Upload Class Initialized
INFO - 2023-10-29 01:39:48 --> Model "M_auth" initialized
INFO - 2023-10-29 01:39:48 --> Model "M_user" initialized
INFO - 2023-10-29 01:39:48 --> Model "M_produk" initialized
INFO - 2023-10-29 01:39:48 --> Controller Class Initialized
INFO - 2023-10-29 01:39:48 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:39:48 --> Final output sent to browser
DEBUG - 2023-10-29 01:39:48 --> Total execution time: 0.0752
ERROR - 2023-10-29 01:39:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:39:48 --> Config Class Initialized
INFO - 2023-10-29 01:39:48 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:39:48 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:39:48 --> Utf8 Class Initialized
INFO - 2023-10-29 01:39:48 --> URI Class Initialized
INFO - 2023-10-29 01:39:48 --> Router Class Initialized
INFO - 2023-10-29 01:39:48 --> Output Class Initialized
INFO - 2023-10-29 01:39:48 --> Security Class Initialized
DEBUG - 2023-10-29 01:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:39:48 --> Input Class Initialized
INFO - 2023-10-29 01:39:48 --> Language Class Initialized
INFO - 2023-10-29 01:39:48 --> Loader Class Initialized
INFO - 2023-10-29 01:39:48 --> Helper loaded: url_helper
INFO - 2023-10-29 01:39:48 --> Helper loaded: form_helper
INFO - 2023-10-29 01:39:48 --> Helper loaded: file_helper
INFO - 2023-10-29 01:39:48 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:39:48 --> Form Validation Class Initialized
INFO - 2023-10-29 01:39:48 --> Upload Class Initialized
INFO - 2023-10-29 01:39:48 --> Model "M_auth" initialized
INFO - 2023-10-29 01:39:48 --> Model "M_user" initialized
INFO - 2023-10-29 01:39:48 --> Model "M_produk" initialized
INFO - 2023-10-29 01:39:48 --> Controller Class Initialized
INFO - 2023-10-29 01:39:48 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:39:48 --> Final output sent to browser
DEBUG - 2023-10-29 01:39:48 --> Total execution time: 0.0239
ERROR - 2023-10-29 01:39:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:39:48 --> Config Class Initialized
INFO - 2023-10-29 01:39:48 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:39:48 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:39:48 --> Utf8 Class Initialized
INFO - 2023-10-29 01:39:48 --> URI Class Initialized
INFO - 2023-10-29 01:39:48 --> Router Class Initialized
INFO - 2023-10-29 01:39:48 --> Output Class Initialized
INFO - 2023-10-29 01:39:48 --> Security Class Initialized
DEBUG - 2023-10-29 01:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:39:48 --> Input Class Initialized
INFO - 2023-10-29 01:39:48 --> Language Class Initialized
INFO - 2023-10-29 01:39:48 --> Loader Class Initialized
INFO - 2023-10-29 01:39:48 --> Helper loaded: url_helper
INFO - 2023-10-29 01:39:48 --> Helper loaded: form_helper
INFO - 2023-10-29 01:39:48 --> Helper loaded: file_helper
INFO - 2023-10-29 01:39:48 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:39:48 --> Form Validation Class Initialized
INFO - 2023-10-29 01:39:48 --> Upload Class Initialized
INFO - 2023-10-29 01:39:48 --> Model "M_auth" initialized
INFO - 2023-10-29 01:39:48 --> Model "M_user" initialized
INFO - 2023-10-29 01:39:48 --> Model "M_produk" initialized
INFO - 2023-10-29 01:39:48 --> Controller Class Initialized
INFO - 2023-10-29 01:39:48 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:39:48 --> Final output sent to browser
DEBUG - 2023-10-29 01:39:48 --> Total execution time: 0.0494
ERROR - 2023-10-29 01:39:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:39:49 --> Config Class Initialized
INFO - 2023-10-29 01:39:49 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:39:49 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:39:49 --> Utf8 Class Initialized
INFO - 2023-10-29 01:39:49 --> URI Class Initialized
INFO - 2023-10-29 01:39:49 --> Router Class Initialized
INFO - 2023-10-29 01:39:49 --> Output Class Initialized
INFO - 2023-10-29 01:39:49 --> Security Class Initialized
DEBUG - 2023-10-29 01:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:39:49 --> Input Class Initialized
INFO - 2023-10-29 01:39:49 --> Language Class Initialized
INFO - 2023-10-29 01:39:49 --> Loader Class Initialized
INFO - 2023-10-29 01:39:49 --> Helper loaded: url_helper
INFO - 2023-10-29 01:39:49 --> Helper loaded: form_helper
INFO - 2023-10-29 01:39:49 --> Helper loaded: file_helper
INFO - 2023-10-29 01:39:49 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:39:49 --> Form Validation Class Initialized
INFO - 2023-10-29 01:39:49 --> Upload Class Initialized
INFO - 2023-10-29 01:39:49 --> Model "M_auth" initialized
INFO - 2023-10-29 01:39:49 --> Model "M_user" initialized
INFO - 2023-10-29 01:39:49 --> Model "M_produk" initialized
INFO - 2023-10-29 01:39:49 --> Controller Class Initialized
INFO - 2023-10-29 01:39:49 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:39:49 --> Final output sent to browser
DEBUG - 2023-10-29 01:39:49 --> Total execution time: 0.0236
ERROR - 2023-10-29 01:39:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:39:49 --> Config Class Initialized
INFO - 2023-10-29 01:39:49 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:39:49 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:39:49 --> Utf8 Class Initialized
INFO - 2023-10-29 01:39:49 --> URI Class Initialized
INFO - 2023-10-29 01:39:49 --> Router Class Initialized
INFO - 2023-10-29 01:39:49 --> Output Class Initialized
INFO - 2023-10-29 01:39:49 --> Security Class Initialized
DEBUG - 2023-10-29 01:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:39:49 --> Input Class Initialized
INFO - 2023-10-29 01:39:49 --> Language Class Initialized
INFO - 2023-10-29 01:39:49 --> Loader Class Initialized
INFO - 2023-10-29 01:39:49 --> Helper loaded: url_helper
INFO - 2023-10-29 01:39:49 --> Helper loaded: form_helper
INFO - 2023-10-29 01:39:49 --> Helper loaded: file_helper
INFO - 2023-10-29 01:39:49 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:39:49 --> Form Validation Class Initialized
INFO - 2023-10-29 01:39:49 --> Upload Class Initialized
INFO - 2023-10-29 01:39:49 --> Model "M_auth" initialized
INFO - 2023-10-29 01:39:49 --> Model "M_user" initialized
INFO - 2023-10-29 01:39:49 --> Model "M_produk" initialized
INFO - 2023-10-29 01:39:49 --> Controller Class Initialized
INFO - 2023-10-29 01:39:49 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:39:49 --> Final output sent to browser
DEBUG - 2023-10-29 01:39:49 --> Total execution time: 0.0202
ERROR - 2023-10-29 01:39:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:39:49 --> Config Class Initialized
INFO - 2023-10-29 01:39:49 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:39:49 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:39:49 --> Utf8 Class Initialized
INFO - 2023-10-29 01:39:49 --> URI Class Initialized
INFO - 2023-10-29 01:39:49 --> Router Class Initialized
INFO - 2023-10-29 01:39:49 --> Output Class Initialized
INFO - 2023-10-29 01:39:49 --> Security Class Initialized
DEBUG - 2023-10-29 01:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:39:49 --> Input Class Initialized
INFO - 2023-10-29 01:39:49 --> Language Class Initialized
INFO - 2023-10-29 01:39:49 --> Loader Class Initialized
INFO - 2023-10-29 01:39:49 --> Helper loaded: url_helper
INFO - 2023-10-29 01:39:49 --> Helper loaded: form_helper
INFO - 2023-10-29 01:39:49 --> Helper loaded: file_helper
INFO - 2023-10-29 01:39:49 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:39:49 --> Form Validation Class Initialized
INFO - 2023-10-29 01:39:49 --> Upload Class Initialized
INFO - 2023-10-29 01:39:49 --> Model "M_auth" initialized
INFO - 2023-10-29 01:39:49 --> Model "M_user" initialized
INFO - 2023-10-29 01:39:49 --> Model "M_produk" initialized
INFO - 2023-10-29 01:39:49 --> Controller Class Initialized
INFO - 2023-10-29 01:39:49 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:39:49 --> Final output sent to browser
DEBUG - 2023-10-29 01:39:49 --> Total execution time: 0.0529
ERROR - 2023-10-29 01:39:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:39:49 --> Config Class Initialized
INFO - 2023-10-29 01:39:49 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:39:49 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:39:49 --> Utf8 Class Initialized
INFO - 2023-10-29 01:39:49 --> URI Class Initialized
INFO - 2023-10-29 01:39:49 --> Router Class Initialized
INFO - 2023-10-29 01:39:49 --> Output Class Initialized
INFO - 2023-10-29 01:39:49 --> Security Class Initialized
DEBUG - 2023-10-29 01:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:39:49 --> Input Class Initialized
INFO - 2023-10-29 01:39:49 --> Language Class Initialized
INFO - 2023-10-29 01:39:49 --> Loader Class Initialized
INFO - 2023-10-29 01:39:49 --> Helper loaded: url_helper
INFO - 2023-10-29 01:39:49 --> Helper loaded: form_helper
INFO - 2023-10-29 01:39:49 --> Helper loaded: file_helper
INFO - 2023-10-29 01:39:49 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:39:49 --> Form Validation Class Initialized
INFO - 2023-10-29 01:39:49 --> Upload Class Initialized
INFO - 2023-10-29 01:39:49 --> Model "M_auth" initialized
INFO - 2023-10-29 01:39:49 --> Model "M_user" initialized
INFO - 2023-10-29 01:39:49 --> Model "M_produk" initialized
INFO - 2023-10-29 01:39:49 --> Controller Class Initialized
INFO - 2023-10-29 01:39:49 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:39:49 --> Final output sent to browser
DEBUG - 2023-10-29 01:39:49 --> Total execution time: 0.0228
ERROR - 2023-10-29 01:39:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:39:49 --> Config Class Initialized
INFO - 2023-10-29 01:39:49 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:39:49 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:39:49 --> Utf8 Class Initialized
INFO - 2023-10-29 01:39:49 --> URI Class Initialized
INFO - 2023-10-29 01:39:49 --> Router Class Initialized
INFO - 2023-10-29 01:39:49 --> Output Class Initialized
INFO - 2023-10-29 01:39:49 --> Security Class Initialized
DEBUG - 2023-10-29 01:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:39:49 --> Input Class Initialized
INFO - 2023-10-29 01:39:49 --> Language Class Initialized
INFO - 2023-10-29 01:39:49 --> Loader Class Initialized
INFO - 2023-10-29 01:39:49 --> Helper loaded: url_helper
INFO - 2023-10-29 01:39:49 --> Helper loaded: form_helper
INFO - 2023-10-29 01:39:49 --> Helper loaded: file_helper
INFO - 2023-10-29 01:39:49 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:39:49 --> Form Validation Class Initialized
INFO - 2023-10-29 01:39:49 --> Upload Class Initialized
INFO - 2023-10-29 01:39:49 --> Model "M_auth" initialized
INFO - 2023-10-29 01:39:49 --> Model "M_user" initialized
INFO - 2023-10-29 01:39:49 --> Model "M_produk" initialized
INFO - 2023-10-29 01:39:49 --> Controller Class Initialized
INFO - 2023-10-29 01:39:49 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:39:49 --> Final output sent to browser
DEBUG - 2023-10-29 01:39:49 --> Total execution time: 0.0814
ERROR - 2023-10-29 01:39:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:39:50 --> Config Class Initialized
INFO - 2023-10-29 01:39:50 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:39:50 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:39:50 --> Utf8 Class Initialized
INFO - 2023-10-29 01:39:50 --> URI Class Initialized
INFO - 2023-10-29 01:39:50 --> Router Class Initialized
INFO - 2023-10-29 01:39:50 --> Output Class Initialized
INFO - 2023-10-29 01:39:50 --> Security Class Initialized
DEBUG - 2023-10-29 01:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:39:50 --> Input Class Initialized
INFO - 2023-10-29 01:39:50 --> Language Class Initialized
INFO - 2023-10-29 01:39:50 --> Loader Class Initialized
INFO - 2023-10-29 01:39:50 --> Helper loaded: url_helper
INFO - 2023-10-29 01:39:50 --> Helper loaded: form_helper
INFO - 2023-10-29 01:39:50 --> Helper loaded: file_helper
INFO - 2023-10-29 01:39:50 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:39:50 --> Form Validation Class Initialized
INFO - 2023-10-29 01:39:50 --> Upload Class Initialized
INFO - 2023-10-29 01:39:50 --> Model "M_auth" initialized
INFO - 2023-10-29 01:39:50 --> Model "M_user" initialized
INFO - 2023-10-29 01:39:50 --> Model "M_produk" initialized
INFO - 2023-10-29 01:39:50 --> Controller Class Initialized
ERROR - 2023-10-29 01:39:50 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 01:39:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:39:52 --> Config Class Initialized
INFO - 2023-10-29 01:39:52 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:39:52 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:39:52 --> Utf8 Class Initialized
INFO - 2023-10-29 01:39:52 --> URI Class Initialized
INFO - 2023-10-29 01:39:52 --> Router Class Initialized
INFO - 2023-10-29 01:39:52 --> Output Class Initialized
INFO - 2023-10-29 01:39:52 --> Security Class Initialized
DEBUG - 2023-10-29 01:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:39:52 --> Input Class Initialized
INFO - 2023-10-29 01:39:52 --> Language Class Initialized
INFO - 2023-10-29 01:39:52 --> Loader Class Initialized
INFO - 2023-10-29 01:39:52 --> Helper loaded: url_helper
INFO - 2023-10-29 01:39:52 --> Helper loaded: form_helper
INFO - 2023-10-29 01:39:52 --> Helper loaded: file_helper
INFO - 2023-10-29 01:39:52 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:39:52 --> Form Validation Class Initialized
INFO - 2023-10-29 01:39:52 --> Upload Class Initialized
INFO - 2023-10-29 01:39:52 --> Model "M_auth" initialized
INFO - 2023-10-29 01:39:52 --> Model "M_user" initialized
INFO - 2023-10-29 01:39:52 --> Model "M_produk" initialized
INFO - 2023-10-29 01:39:52 --> Controller Class Initialized
INFO - 2023-10-29 01:39:52 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:39:52 --> Final output sent to browser
DEBUG - 2023-10-29 01:39:52 --> Total execution time: 0.0982
ERROR - 2023-10-29 01:40:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:40:05 --> Config Class Initialized
INFO - 2023-10-29 01:40:05 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:40:05 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:40:05 --> Utf8 Class Initialized
INFO - 2023-10-29 01:40:05 --> URI Class Initialized
INFO - 2023-10-29 01:40:05 --> Router Class Initialized
INFO - 2023-10-29 01:40:05 --> Output Class Initialized
INFO - 2023-10-29 01:40:05 --> Security Class Initialized
DEBUG - 2023-10-29 01:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:40:05 --> Input Class Initialized
INFO - 2023-10-29 01:40:05 --> Language Class Initialized
INFO - 2023-10-29 01:40:05 --> Loader Class Initialized
INFO - 2023-10-29 01:40:05 --> Helper loaded: url_helper
INFO - 2023-10-29 01:40:05 --> Helper loaded: form_helper
INFO - 2023-10-29 01:40:05 --> Helper loaded: file_helper
INFO - 2023-10-29 01:40:05 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:40:05 --> Form Validation Class Initialized
INFO - 2023-10-29 01:40:05 --> Upload Class Initialized
INFO - 2023-10-29 01:40:05 --> Model "M_auth" initialized
INFO - 2023-10-29 01:40:05 --> Model "M_user" initialized
INFO - 2023-10-29 01:40:05 --> Model "M_produk" initialized
INFO - 2023-10-29 01:40:05 --> Controller Class Initialized
INFO - 2023-10-29 01:40:05 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:40:05 --> Final output sent to browser
DEBUG - 2023-10-29 01:40:05 --> Total execution time: 0.0701
ERROR - 2023-10-29 01:40:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:40:06 --> Config Class Initialized
INFO - 2023-10-29 01:40:06 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:40:06 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:40:06 --> Utf8 Class Initialized
INFO - 2023-10-29 01:40:06 --> URI Class Initialized
INFO - 2023-10-29 01:40:06 --> Router Class Initialized
INFO - 2023-10-29 01:40:06 --> Output Class Initialized
INFO - 2023-10-29 01:40:06 --> Security Class Initialized
DEBUG - 2023-10-29 01:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:40:06 --> Input Class Initialized
INFO - 2023-10-29 01:40:06 --> Language Class Initialized
INFO - 2023-10-29 01:40:06 --> Loader Class Initialized
INFO - 2023-10-29 01:40:06 --> Helper loaded: url_helper
INFO - 2023-10-29 01:40:06 --> Helper loaded: form_helper
INFO - 2023-10-29 01:40:06 --> Helper loaded: file_helper
INFO - 2023-10-29 01:40:06 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:40:06 --> Form Validation Class Initialized
INFO - 2023-10-29 01:40:06 --> Upload Class Initialized
INFO - 2023-10-29 01:40:06 --> Model "M_auth" initialized
INFO - 2023-10-29 01:40:06 --> Model "M_user" initialized
INFO - 2023-10-29 01:40:06 --> Model "M_produk" initialized
INFO - 2023-10-29 01:40:06 --> Controller Class Initialized
ERROR - 2023-10-29 01:40:06 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 01:40:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:40:07 --> Config Class Initialized
INFO - 2023-10-29 01:40:07 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:40:07 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:40:07 --> Utf8 Class Initialized
INFO - 2023-10-29 01:40:07 --> URI Class Initialized
INFO - 2023-10-29 01:40:07 --> Router Class Initialized
INFO - 2023-10-29 01:40:07 --> Output Class Initialized
INFO - 2023-10-29 01:40:07 --> Security Class Initialized
DEBUG - 2023-10-29 01:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:40:07 --> Input Class Initialized
INFO - 2023-10-29 01:40:07 --> Language Class Initialized
INFO - 2023-10-29 01:40:07 --> Loader Class Initialized
INFO - 2023-10-29 01:40:07 --> Helper loaded: url_helper
INFO - 2023-10-29 01:40:07 --> Helper loaded: form_helper
INFO - 2023-10-29 01:40:07 --> Helper loaded: file_helper
INFO - 2023-10-29 01:40:07 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:40:07 --> Form Validation Class Initialized
INFO - 2023-10-29 01:40:07 --> Upload Class Initialized
INFO - 2023-10-29 01:40:07 --> Model "M_auth" initialized
INFO - 2023-10-29 01:40:07 --> Model "M_user" initialized
INFO - 2023-10-29 01:40:07 --> Model "M_produk" initialized
INFO - 2023-10-29 01:40:07 --> Controller Class Initialized
INFO - 2023-10-29 01:40:07 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:40:07 --> Final output sent to browser
DEBUG - 2023-10-29 01:40:07 --> Total execution time: 0.0836
ERROR - 2023-10-29 01:40:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:40:15 --> Config Class Initialized
INFO - 2023-10-29 01:40:15 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:40:15 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:40:15 --> Utf8 Class Initialized
INFO - 2023-10-29 01:40:15 --> URI Class Initialized
INFO - 2023-10-29 01:40:15 --> Router Class Initialized
INFO - 2023-10-29 01:40:15 --> Output Class Initialized
INFO - 2023-10-29 01:40:15 --> Security Class Initialized
DEBUG - 2023-10-29 01:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:40:15 --> Input Class Initialized
INFO - 2023-10-29 01:40:15 --> Language Class Initialized
INFO - 2023-10-29 01:40:15 --> Loader Class Initialized
INFO - 2023-10-29 01:40:15 --> Helper loaded: url_helper
INFO - 2023-10-29 01:40:15 --> Helper loaded: form_helper
INFO - 2023-10-29 01:40:15 --> Helper loaded: file_helper
INFO - 2023-10-29 01:40:15 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:40:15 --> Form Validation Class Initialized
INFO - 2023-10-29 01:40:15 --> Upload Class Initialized
INFO - 2023-10-29 01:40:15 --> Model "M_auth" initialized
INFO - 2023-10-29 01:40:15 --> Model "M_user" initialized
INFO - 2023-10-29 01:40:15 --> Model "M_produk" initialized
INFO - 2023-10-29 01:40:15 --> Controller Class Initialized
INFO - 2023-10-29 01:40:15 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:40:15 --> Final output sent to browser
DEBUG - 2023-10-29 01:40:15 --> Total execution time: 0.0604
ERROR - 2023-10-29 01:40:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:40:16 --> Config Class Initialized
INFO - 2023-10-29 01:40:16 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:40:16 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:40:16 --> Utf8 Class Initialized
INFO - 2023-10-29 01:40:16 --> URI Class Initialized
INFO - 2023-10-29 01:40:16 --> Router Class Initialized
INFO - 2023-10-29 01:40:16 --> Output Class Initialized
INFO - 2023-10-29 01:40:16 --> Security Class Initialized
DEBUG - 2023-10-29 01:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:40:16 --> Input Class Initialized
INFO - 2023-10-29 01:40:16 --> Language Class Initialized
INFO - 2023-10-29 01:40:16 --> Loader Class Initialized
INFO - 2023-10-29 01:40:16 --> Helper loaded: url_helper
INFO - 2023-10-29 01:40:16 --> Helper loaded: form_helper
INFO - 2023-10-29 01:40:16 --> Helper loaded: file_helper
INFO - 2023-10-29 01:40:16 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:40:16 --> Form Validation Class Initialized
INFO - 2023-10-29 01:40:16 --> Upload Class Initialized
INFO - 2023-10-29 01:40:16 --> Model "M_auth" initialized
INFO - 2023-10-29 01:40:16 --> Model "M_user" initialized
INFO - 2023-10-29 01:40:16 --> Model "M_produk" initialized
INFO - 2023-10-29 01:40:16 --> Controller Class Initialized
INFO - 2023-10-29 01:40:16 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:40:16 --> Final output sent to browser
DEBUG - 2023-10-29 01:40:16 --> Total execution time: 0.0447
ERROR - 2023-10-29 01:40:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:40:16 --> Config Class Initialized
INFO - 2023-10-29 01:40:16 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:40:16 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:40:16 --> Utf8 Class Initialized
INFO - 2023-10-29 01:40:16 --> URI Class Initialized
INFO - 2023-10-29 01:40:16 --> Router Class Initialized
INFO - 2023-10-29 01:40:16 --> Output Class Initialized
INFO - 2023-10-29 01:40:16 --> Security Class Initialized
DEBUG - 2023-10-29 01:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:40:16 --> Input Class Initialized
INFO - 2023-10-29 01:40:16 --> Language Class Initialized
INFO - 2023-10-29 01:40:16 --> Loader Class Initialized
INFO - 2023-10-29 01:40:16 --> Helper loaded: url_helper
INFO - 2023-10-29 01:40:16 --> Helper loaded: form_helper
INFO - 2023-10-29 01:40:16 --> Helper loaded: file_helper
INFO - 2023-10-29 01:40:16 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:40:16 --> Form Validation Class Initialized
INFO - 2023-10-29 01:40:16 --> Upload Class Initialized
INFO - 2023-10-29 01:40:16 --> Model "M_auth" initialized
INFO - 2023-10-29 01:40:16 --> Model "M_user" initialized
INFO - 2023-10-29 01:40:16 --> Model "M_produk" initialized
INFO - 2023-10-29 01:40:16 --> Controller Class Initialized
INFO - 2023-10-29 01:40:16 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:40:16 --> Final output sent to browser
DEBUG - 2023-10-29 01:40:16 --> Total execution time: 0.0856
ERROR - 2023-10-29 01:40:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:40:16 --> Config Class Initialized
INFO - 2023-10-29 01:40:16 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:40:16 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:40:16 --> Utf8 Class Initialized
INFO - 2023-10-29 01:40:16 --> URI Class Initialized
INFO - 2023-10-29 01:40:16 --> Router Class Initialized
INFO - 2023-10-29 01:40:16 --> Output Class Initialized
INFO - 2023-10-29 01:40:16 --> Security Class Initialized
DEBUG - 2023-10-29 01:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:40:16 --> Input Class Initialized
INFO - 2023-10-29 01:40:16 --> Language Class Initialized
INFO - 2023-10-29 01:40:16 --> Loader Class Initialized
INFO - 2023-10-29 01:40:16 --> Helper loaded: url_helper
INFO - 2023-10-29 01:40:16 --> Helper loaded: form_helper
INFO - 2023-10-29 01:40:16 --> Helper loaded: file_helper
INFO - 2023-10-29 01:40:16 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:40:16 --> Form Validation Class Initialized
INFO - 2023-10-29 01:40:16 --> Upload Class Initialized
INFO - 2023-10-29 01:40:16 --> Model "M_auth" initialized
INFO - 2023-10-29 01:40:16 --> Model "M_user" initialized
INFO - 2023-10-29 01:40:16 --> Model "M_produk" initialized
INFO - 2023-10-29 01:40:16 --> Controller Class Initialized
INFO - 2023-10-29 01:40:16 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:40:16 --> Final output sent to browser
DEBUG - 2023-10-29 01:40:16 --> Total execution time: 0.0214
ERROR - 2023-10-29 01:40:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:40:17 --> Config Class Initialized
INFO - 2023-10-29 01:40:17 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:40:17 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:40:17 --> Utf8 Class Initialized
INFO - 2023-10-29 01:40:17 --> URI Class Initialized
INFO - 2023-10-29 01:40:17 --> Router Class Initialized
INFO - 2023-10-29 01:40:17 --> Output Class Initialized
INFO - 2023-10-29 01:40:17 --> Security Class Initialized
DEBUG - 2023-10-29 01:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:40:17 --> Input Class Initialized
INFO - 2023-10-29 01:40:17 --> Language Class Initialized
INFO - 2023-10-29 01:40:17 --> Loader Class Initialized
INFO - 2023-10-29 01:40:17 --> Helper loaded: url_helper
INFO - 2023-10-29 01:40:17 --> Helper loaded: form_helper
INFO - 2023-10-29 01:40:17 --> Helper loaded: file_helper
INFO - 2023-10-29 01:40:17 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:40:17 --> Form Validation Class Initialized
INFO - 2023-10-29 01:40:17 --> Upload Class Initialized
INFO - 2023-10-29 01:40:17 --> Model "M_auth" initialized
INFO - 2023-10-29 01:40:17 --> Model "M_user" initialized
INFO - 2023-10-29 01:40:17 --> Model "M_produk" initialized
INFO - 2023-10-29 01:40:17 --> Controller Class Initialized
INFO - 2023-10-29 01:40:17 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:40:17 --> Final output sent to browser
DEBUG - 2023-10-29 01:40:17 --> Total execution time: 0.0571
ERROR - 2023-10-29 01:40:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:40:17 --> Config Class Initialized
INFO - 2023-10-29 01:40:17 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:40:17 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:40:17 --> Utf8 Class Initialized
INFO - 2023-10-29 01:40:17 --> URI Class Initialized
INFO - 2023-10-29 01:40:17 --> Router Class Initialized
INFO - 2023-10-29 01:40:17 --> Output Class Initialized
INFO - 2023-10-29 01:40:17 --> Security Class Initialized
DEBUG - 2023-10-29 01:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:40:17 --> Input Class Initialized
INFO - 2023-10-29 01:40:17 --> Language Class Initialized
INFO - 2023-10-29 01:40:17 --> Loader Class Initialized
INFO - 2023-10-29 01:40:17 --> Helper loaded: url_helper
INFO - 2023-10-29 01:40:17 --> Helper loaded: form_helper
INFO - 2023-10-29 01:40:17 --> Helper loaded: file_helper
INFO - 2023-10-29 01:40:17 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:40:17 --> Form Validation Class Initialized
INFO - 2023-10-29 01:40:17 --> Upload Class Initialized
INFO - 2023-10-29 01:40:17 --> Model "M_auth" initialized
INFO - 2023-10-29 01:40:17 --> Model "M_user" initialized
INFO - 2023-10-29 01:40:17 --> Model "M_produk" initialized
INFO - 2023-10-29 01:40:17 --> Controller Class Initialized
ERROR - 2023-10-29 01:40:17 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 01:41:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:41:15 --> Config Class Initialized
INFO - 2023-10-29 01:41:15 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:41:15 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:41:15 --> Utf8 Class Initialized
INFO - 2023-10-29 01:41:15 --> URI Class Initialized
INFO - 2023-10-29 01:41:15 --> Router Class Initialized
INFO - 2023-10-29 01:41:15 --> Output Class Initialized
INFO - 2023-10-29 01:41:15 --> Security Class Initialized
DEBUG - 2023-10-29 01:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:41:15 --> Input Class Initialized
INFO - 2023-10-29 01:41:15 --> Language Class Initialized
INFO - 2023-10-29 01:41:15 --> Loader Class Initialized
INFO - 2023-10-29 01:41:15 --> Helper loaded: url_helper
INFO - 2023-10-29 01:41:15 --> Helper loaded: form_helper
INFO - 2023-10-29 01:41:15 --> Helper loaded: file_helper
INFO - 2023-10-29 01:41:15 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:41:15 --> Form Validation Class Initialized
INFO - 2023-10-29 01:41:15 --> Upload Class Initialized
INFO - 2023-10-29 01:41:15 --> Model "M_auth" initialized
INFO - 2023-10-29 01:41:15 --> Model "M_user" initialized
INFO - 2023-10-29 01:41:15 --> Model "M_produk" initialized
INFO - 2023-10-29 01:41:15 --> Controller Class Initialized
INFO - 2023-10-29 01:41:15 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-10-29 01:41:15 --> Final output sent to browser
DEBUG - 2023-10-29 01:41:15 --> Total execution time: 0.0591
ERROR - 2023-10-29 01:41:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:41:19 --> Config Class Initialized
INFO - 2023-10-29 01:41:19 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:41:19 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:41:19 --> Utf8 Class Initialized
INFO - 2023-10-29 01:41:19 --> URI Class Initialized
DEBUG - 2023-10-29 01:41:19 --> No URI present. Default controller set.
INFO - 2023-10-29 01:41:19 --> Router Class Initialized
INFO - 2023-10-29 01:41:19 --> Output Class Initialized
INFO - 2023-10-29 01:41:19 --> Security Class Initialized
DEBUG - 2023-10-29 01:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:41:19 --> Input Class Initialized
INFO - 2023-10-29 01:41:19 --> Language Class Initialized
INFO - 2023-10-29 01:41:19 --> Loader Class Initialized
INFO - 2023-10-29 01:41:19 --> Helper loaded: url_helper
INFO - 2023-10-29 01:41:19 --> Helper loaded: form_helper
INFO - 2023-10-29 01:41:19 --> Helper loaded: file_helper
INFO - 2023-10-29 01:41:19 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:41:19 --> Form Validation Class Initialized
INFO - 2023-10-29 01:41:19 --> Upload Class Initialized
INFO - 2023-10-29 01:41:19 --> Model "M_auth" initialized
INFO - 2023-10-29 01:41:19 --> Model "M_user" initialized
INFO - 2023-10-29 01:41:19 --> Model "M_produk" initialized
INFO - 2023-10-29 01:41:19 --> Controller Class Initialized
INFO - 2023-10-29 01:41:19 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 01:41:19 --> Model "M_produk" initialized
DEBUG - 2023-10-29 01:41:19 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 01:41:19 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 01:41:19 --> Model "M_transaksi" initialized
INFO - 2023-10-29 01:41:19 --> Model "M_bank" initialized
INFO - 2023-10-29 01:41:19 --> Model "M_pesan" initialized
INFO - 2023-10-29 01:41:19 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-29 01:41:19 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-29 01:41:19 --> Final output sent to browser
DEBUG - 2023-10-29 01:41:19 --> Total execution time: 0.0648
ERROR - 2023-10-29 01:41:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:41:25 --> Config Class Initialized
INFO - 2023-10-29 01:41:25 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:41:25 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:41:25 --> Utf8 Class Initialized
INFO - 2023-10-29 01:41:25 --> URI Class Initialized
INFO - 2023-10-29 01:41:25 --> Router Class Initialized
INFO - 2023-10-29 01:41:25 --> Output Class Initialized
INFO - 2023-10-29 01:41:25 --> Security Class Initialized
DEBUG - 2023-10-29 01:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:41:25 --> Input Class Initialized
INFO - 2023-10-29 01:41:25 --> Language Class Initialized
INFO - 2023-10-29 01:41:25 --> Loader Class Initialized
INFO - 2023-10-29 01:41:25 --> Helper loaded: url_helper
INFO - 2023-10-29 01:41:25 --> Helper loaded: form_helper
INFO - 2023-10-29 01:41:25 --> Helper loaded: file_helper
INFO - 2023-10-29 01:41:25 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:41:25 --> Form Validation Class Initialized
INFO - 2023-10-29 01:41:25 --> Upload Class Initialized
INFO - 2023-10-29 01:41:25 --> Model "M_auth" initialized
INFO - 2023-10-29 01:41:25 --> Model "M_user" initialized
INFO - 2023-10-29 01:41:25 --> Model "M_produk" initialized
INFO - 2023-10-29 01:41:25 --> Controller Class Initialized
INFO - 2023-10-29 01:41:25 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 01:41:25 --> Model "M_produk" initialized
DEBUG - 2023-10-29 01:41:25 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 01:41:25 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 01:41:25 --> Model "M_transaksi" initialized
INFO - 2023-10-29 01:41:25 --> Model "M_bank" initialized
INFO - 2023-10-29 01:41:25 --> Model "M_pesan" initialized
ERROR - 2023-10-29 01:41:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:41:25 --> Config Class Initialized
INFO - 2023-10-29 01:41:25 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:41:25 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:41:25 --> Utf8 Class Initialized
INFO - 2023-10-29 01:41:25 --> URI Class Initialized
DEBUG - 2023-10-29 01:41:25 --> No URI present. Default controller set.
INFO - 2023-10-29 01:41:25 --> Router Class Initialized
INFO - 2023-10-29 01:41:25 --> Output Class Initialized
INFO - 2023-10-29 01:41:25 --> Security Class Initialized
DEBUG - 2023-10-29 01:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:41:25 --> Input Class Initialized
INFO - 2023-10-29 01:41:25 --> Language Class Initialized
INFO - 2023-10-29 01:41:25 --> Loader Class Initialized
INFO - 2023-10-29 01:41:25 --> Helper loaded: url_helper
INFO - 2023-10-29 01:41:25 --> Helper loaded: form_helper
INFO - 2023-10-29 01:41:25 --> Helper loaded: file_helper
INFO - 2023-10-29 01:41:25 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:41:25 --> Form Validation Class Initialized
INFO - 2023-10-29 01:41:25 --> Upload Class Initialized
INFO - 2023-10-29 01:41:25 --> Model "M_auth" initialized
INFO - 2023-10-29 01:41:25 --> Model "M_user" initialized
INFO - 2023-10-29 01:41:25 --> Model "M_produk" initialized
INFO - 2023-10-29 01:41:25 --> Controller Class Initialized
INFO - 2023-10-29 01:41:25 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 01:41:25 --> Model "M_produk" initialized
DEBUG - 2023-10-29 01:41:25 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 01:41:25 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 01:41:25 --> Model "M_transaksi" initialized
INFO - 2023-10-29 01:41:25 --> Model "M_bank" initialized
INFO - 2023-10-29 01:41:25 --> Model "M_pesan" initialized
INFO - 2023-10-29 01:41:25 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-29 01:41:25 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-29 01:41:25 --> Final output sent to browser
DEBUG - 2023-10-29 01:41:25 --> Total execution time: 0.0275
ERROR - 2023-10-29 01:41:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:41:29 --> Config Class Initialized
INFO - 2023-10-29 01:41:29 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:41:29 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:41:29 --> Utf8 Class Initialized
INFO - 2023-10-29 01:41:29 --> URI Class Initialized
INFO - 2023-10-29 01:41:29 --> Router Class Initialized
INFO - 2023-10-29 01:41:29 --> Output Class Initialized
INFO - 2023-10-29 01:41:29 --> Security Class Initialized
DEBUG - 2023-10-29 01:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:41:29 --> Input Class Initialized
INFO - 2023-10-29 01:41:29 --> Language Class Initialized
INFO - 2023-10-29 01:41:29 --> Loader Class Initialized
INFO - 2023-10-29 01:41:29 --> Helper loaded: url_helper
INFO - 2023-10-29 01:41:29 --> Helper loaded: form_helper
INFO - 2023-10-29 01:41:29 --> Helper loaded: file_helper
INFO - 2023-10-29 01:41:29 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:41:29 --> Form Validation Class Initialized
INFO - 2023-10-29 01:41:29 --> Upload Class Initialized
INFO - 2023-10-29 01:41:29 --> Model "M_auth" initialized
INFO - 2023-10-29 01:41:29 --> Model "M_user" initialized
INFO - 2023-10-29 01:41:29 --> Model "M_produk" initialized
INFO - 2023-10-29 01:41:29 --> Controller Class Initialized
INFO - 2023-10-29 01:41:29 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:41:29 --> Final output sent to browser
DEBUG - 2023-10-29 01:41:29 --> Total execution time: 0.0455
ERROR - 2023-10-29 01:41:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:41:30 --> Config Class Initialized
INFO - 2023-10-29 01:41:30 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:41:30 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:41:30 --> Utf8 Class Initialized
INFO - 2023-10-29 01:41:30 --> URI Class Initialized
INFO - 2023-10-29 01:41:30 --> Router Class Initialized
INFO - 2023-10-29 01:41:30 --> Output Class Initialized
INFO - 2023-10-29 01:41:30 --> Security Class Initialized
DEBUG - 2023-10-29 01:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:41:30 --> Input Class Initialized
INFO - 2023-10-29 01:41:30 --> Language Class Initialized
INFO - 2023-10-29 01:41:30 --> Loader Class Initialized
INFO - 2023-10-29 01:41:30 --> Helper loaded: url_helper
INFO - 2023-10-29 01:41:30 --> Helper loaded: form_helper
INFO - 2023-10-29 01:41:30 --> Helper loaded: file_helper
INFO - 2023-10-29 01:41:30 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:41:30 --> Form Validation Class Initialized
INFO - 2023-10-29 01:41:30 --> Upload Class Initialized
INFO - 2023-10-29 01:41:30 --> Model "M_auth" initialized
INFO - 2023-10-29 01:41:30 --> Model "M_user" initialized
INFO - 2023-10-29 01:41:30 --> Model "M_produk" initialized
INFO - 2023-10-29 01:41:30 --> Controller Class Initialized
ERROR - 2023-10-29 01:41:30 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 01:41:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 01:41:31 --> Config Class Initialized
INFO - 2023-10-29 01:41:31 --> Hooks Class Initialized
DEBUG - 2023-10-29 01:41:31 --> UTF-8 Support Enabled
INFO - 2023-10-29 01:41:31 --> Utf8 Class Initialized
INFO - 2023-10-29 01:41:31 --> URI Class Initialized
INFO - 2023-10-29 01:41:31 --> Router Class Initialized
INFO - 2023-10-29 01:41:31 --> Output Class Initialized
INFO - 2023-10-29 01:41:31 --> Security Class Initialized
DEBUG - 2023-10-29 01:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 01:41:31 --> Input Class Initialized
INFO - 2023-10-29 01:41:31 --> Language Class Initialized
INFO - 2023-10-29 01:41:31 --> Loader Class Initialized
INFO - 2023-10-29 01:41:31 --> Helper loaded: url_helper
INFO - 2023-10-29 01:41:31 --> Helper loaded: form_helper
INFO - 2023-10-29 01:41:31 --> Helper loaded: file_helper
INFO - 2023-10-29 01:41:31 --> Database Driver Class Initialized
DEBUG - 2023-10-29 01:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 01:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 01:41:31 --> Form Validation Class Initialized
INFO - 2023-10-29 01:41:31 --> Upload Class Initialized
INFO - 2023-10-29 01:41:31 --> Model "M_auth" initialized
INFO - 2023-10-29 01:41:31 --> Model "M_user" initialized
INFO - 2023-10-29 01:41:31 --> Model "M_produk" initialized
INFO - 2023-10-29 01:41:31 --> Controller Class Initialized
INFO - 2023-10-29 01:41:31 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 01:41:31 --> Final output sent to browser
DEBUG - 2023-10-29 01:41:31 --> Total execution time: 0.0643
ERROR - 2023-10-29 02:44:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 02:44:45 --> Config Class Initialized
INFO - 2023-10-29 02:44:45 --> Hooks Class Initialized
DEBUG - 2023-10-29 02:44:45 --> UTF-8 Support Enabled
INFO - 2023-10-29 02:44:45 --> Utf8 Class Initialized
INFO - 2023-10-29 02:44:45 --> URI Class Initialized
DEBUG - 2023-10-29 02:44:45 --> No URI present. Default controller set.
INFO - 2023-10-29 02:44:45 --> Router Class Initialized
INFO - 2023-10-29 02:44:45 --> Output Class Initialized
INFO - 2023-10-29 02:44:45 --> Security Class Initialized
DEBUG - 2023-10-29 02:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 02:44:45 --> Input Class Initialized
INFO - 2023-10-29 02:44:45 --> Language Class Initialized
INFO - 2023-10-29 02:44:45 --> Loader Class Initialized
INFO - 2023-10-29 02:44:45 --> Helper loaded: url_helper
INFO - 2023-10-29 02:44:45 --> Helper loaded: form_helper
INFO - 2023-10-29 02:44:45 --> Helper loaded: file_helper
INFO - 2023-10-29 02:44:45 --> Database Driver Class Initialized
DEBUG - 2023-10-29 02:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 02:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 02:44:45 --> Form Validation Class Initialized
INFO - 2023-10-29 02:44:45 --> Upload Class Initialized
INFO - 2023-10-29 02:44:45 --> Model "M_auth" initialized
INFO - 2023-10-29 02:44:45 --> Model "M_user" initialized
INFO - 2023-10-29 02:44:45 --> Model "M_produk" initialized
INFO - 2023-10-29 02:44:45 --> Controller Class Initialized
INFO - 2023-10-29 02:44:45 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 02:44:45 --> Model "M_produk" initialized
DEBUG - 2023-10-29 02:44:45 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 02:44:45 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 02:44:45 --> Model "M_transaksi" initialized
INFO - 2023-10-29 02:44:45 --> Model "M_bank" initialized
INFO - 2023-10-29 02:44:45 --> Model "M_pesan" initialized
INFO - 2023-10-29 02:44:45 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-29 02:44:45 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-29 02:44:45 --> Final output sent to browser
DEBUG - 2023-10-29 02:44:45 --> Total execution time: 0.1575
ERROR - 2023-10-29 09:43:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 09:43:04 --> Config Class Initialized
INFO - 2023-10-29 09:43:04 --> Hooks Class Initialized
DEBUG - 2023-10-29 09:43:04 --> UTF-8 Support Enabled
INFO - 2023-10-29 09:43:04 --> Utf8 Class Initialized
INFO - 2023-10-29 09:43:04 --> URI Class Initialized
DEBUG - 2023-10-29 09:43:04 --> No URI present. Default controller set.
INFO - 2023-10-29 09:43:04 --> Router Class Initialized
INFO - 2023-10-29 09:43:04 --> Output Class Initialized
INFO - 2023-10-29 09:43:04 --> Security Class Initialized
DEBUG - 2023-10-29 09:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 09:43:04 --> Input Class Initialized
INFO - 2023-10-29 09:43:04 --> Language Class Initialized
INFO - 2023-10-29 09:43:04 --> Loader Class Initialized
INFO - 2023-10-29 09:43:04 --> Helper loaded: url_helper
INFO - 2023-10-29 09:43:04 --> Helper loaded: form_helper
INFO - 2023-10-29 09:43:04 --> Helper loaded: file_helper
INFO - 2023-10-29 09:43:04 --> Database Driver Class Initialized
DEBUG - 2023-10-29 09:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 09:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 09:43:04 --> Form Validation Class Initialized
INFO - 2023-10-29 09:43:04 --> Upload Class Initialized
INFO - 2023-10-29 09:43:04 --> Model "M_auth" initialized
INFO - 2023-10-29 09:43:04 --> Model "M_user" initialized
INFO - 2023-10-29 09:43:04 --> Model "M_produk" initialized
INFO - 2023-10-29 09:43:04 --> Controller Class Initialized
INFO - 2023-10-29 09:43:04 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 09:43:04 --> Model "M_produk" initialized
DEBUG - 2023-10-29 09:43:04 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 09:43:04 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 09:43:04 --> Model "M_transaksi" initialized
INFO - 2023-10-29 09:43:04 --> Model "M_bank" initialized
INFO - 2023-10-29 09:43:04 --> Model "M_pesan" initialized
INFO - 2023-10-29 09:43:04 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-29 09:43:04 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-29 09:43:04 --> Final output sent to browser
DEBUG - 2023-10-29 09:43:04 --> Total execution time: 0.0862
ERROR - 2023-10-29 09:43:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 09:43:08 --> Config Class Initialized
INFO - 2023-10-29 09:43:08 --> Hooks Class Initialized
DEBUG - 2023-10-29 09:43:08 --> UTF-8 Support Enabled
INFO - 2023-10-29 09:43:08 --> Utf8 Class Initialized
INFO - 2023-10-29 09:43:08 --> URI Class Initialized
INFO - 2023-10-29 09:43:08 --> Router Class Initialized
INFO - 2023-10-29 09:43:08 --> Output Class Initialized
INFO - 2023-10-29 09:43:08 --> Security Class Initialized
DEBUG - 2023-10-29 09:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 09:43:08 --> Input Class Initialized
INFO - 2023-10-29 09:43:08 --> Language Class Initialized
INFO - 2023-10-29 09:43:08 --> Loader Class Initialized
INFO - 2023-10-29 09:43:08 --> Helper loaded: url_helper
INFO - 2023-10-29 09:43:08 --> Helper loaded: form_helper
INFO - 2023-10-29 09:43:08 --> Helper loaded: file_helper
INFO - 2023-10-29 09:43:08 --> Database Driver Class Initialized
DEBUG - 2023-10-29 09:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 09:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 09:43:08 --> Form Validation Class Initialized
INFO - 2023-10-29 09:43:08 --> Upload Class Initialized
INFO - 2023-10-29 09:43:08 --> Model "M_auth" initialized
INFO - 2023-10-29 09:43:08 --> Model "M_user" initialized
INFO - 2023-10-29 09:43:08 --> Model "M_produk" initialized
INFO - 2023-10-29 09:43:08 --> Controller Class Initialized
INFO - 2023-10-29 09:43:08 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 09:43:08 --> Final output sent to browser
DEBUG - 2023-10-29 09:43:08 --> Total execution time: 0.0839
ERROR - 2023-10-29 09:43:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 09:43:09 --> Config Class Initialized
INFO - 2023-10-29 09:43:09 --> Hooks Class Initialized
DEBUG - 2023-10-29 09:43:09 --> UTF-8 Support Enabled
INFO - 2023-10-29 09:43:09 --> Utf8 Class Initialized
INFO - 2023-10-29 09:43:09 --> URI Class Initialized
INFO - 2023-10-29 09:43:09 --> Router Class Initialized
INFO - 2023-10-29 09:43:09 --> Output Class Initialized
INFO - 2023-10-29 09:43:09 --> Security Class Initialized
DEBUG - 2023-10-29 09:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 09:43:09 --> Input Class Initialized
INFO - 2023-10-29 09:43:09 --> Language Class Initialized
INFO - 2023-10-29 09:43:09 --> Loader Class Initialized
INFO - 2023-10-29 09:43:09 --> Helper loaded: url_helper
INFO - 2023-10-29 09:43:09 --> Helper loaded: form_helper
INFO - 2023-10-29 09:43:09 --> Helper loaded: file_helper
INFO - 2023-10-29 09:43:09 --> Database Driver Class Initialized
DEBUG - 2023-10-29 09:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 09:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 09:43:09 --> Form Validation Class Initialized
INFO - 2023-10-29 09:43:09 --> Upload Class Initialized
INFO - 2023-10-29 09:43:09 --> Model "M_auth" initialized
INFO - 2023-10-29 09:43:10 --> Model "M_user" initialized
INFO - 2023-10-29 09:43:10 --> Model "M_produk" initialized
INFO - 2023-10-29 09:43:10 --> Controller Class Initialized
ERROR - 2023-10-29 09:43:10 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 09:43:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 09:43:19 --> Config Class Initialized
INFO - 2023-10-29 09:43:19 --> Hooks Class Initialized
DEBUG - 2023-10-29 09:43:19 --> UTF-8 Support Enabled
INFO - 2023-10-29 09:43:19 --> Utf8 Class Initialized
INFO - 2023-10-29 09:43:19 --> URI Class Initialized
INFO - 2023-10-29 09:43:19 --> Router Class Initialized
INFO - 2023-10-29 09:43:19 --> Output Class Initialized
INFO - 2023-10-29 09:43:19 --> Security Class Initialized
DEBUG - 2023-10-29 09:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 09:43:19 --> Input Class Initialized
INFO - 2023-10-29 09:43:19 --> Language Class Initialized
INFO - 2023-10-29 09:43:19 --> Loader Class Initialized
INFO - 2023-10-29 09:43:19 --> Helper loaded: url_helper
INFO - 2023-10-29 09:43:19 --> Helper loaded: form_helper
INFO - 2023-10-29 09:43:19 --> Helper loaded: file_helper
INFO - 2023-10-29 09:43:19 --> Database Driver Class Initialized
DEBUG - 2023-10-29 09:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 09:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 09:43:19 --> Form Validation Class Initialized
INFO - 2023-10-29 09:43:19 --> Upload Class Initialized
INFO - 2023-10-29 09:43:19 --> Model "M_auth" initialized
INFO - 2023-10-29 09:43:19 --> Model "M_user" initialized
INFO - 2023-10-29 09:43:19 --> Model "M_produk" initialized
INFO - 2023-10-29 09:43:19 --> Controller Class Initialized
INFO - 2023-10-29 09:43:19 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 09:43:19 --> Final output sent to browser
DEBUG - 2023-10-29 09:43:19 --> Total execution time: 0.0797
ERROR - 2023-10-29 10:01:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:01:25 --> Config Class Initialized
INFO - 2023-10-29 10:01:25 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:01:25 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:01:25 --> Utf8 Class Initialized
INFO - 2023-10-29 10:01:25 --> URI Class Initialized
INFO - 2023-10-29 10:01:25 --> Router Class Initialized
INFO - 2023-10-29 10:01:25 --> Output Class Initialized
INFO - 2023-10-29 10:01:25 --> Security Class Initialized
DEBUG - 2023-10-29 10:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:01:25 --> Input Class Initialized
INFO - 2023-10-29 10:01:25 --> Language Class Initialized
INFO - 2023-10-29 10:01:25 --> Loader Class Initialized
INFO - 2023-10-29 10:01:25 --> Helper loaded: url_helper
INFO - 2023-10-29 10:01:25 --> Helper loaded: form_helper
INFO - 2023-10-29 10:01:25 --> Helper loaded: file_helper
INFO - 2023-10-29 10:01:25 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:01:25 --> Form Validation Class Initialized
INFO - 2023-10-29 10:01:25 --> Upload Class Initialized
INFO - 2023-10-29 10:01:25 --> Model "M_auth" initialized
INFO - 2023-10-29 10:01:25 --> Model "M_user" initialized
INFO - 2023-10-29 10:01:25 --> Model "M_produk" initialized
INFO - 2023-10-29 10:01:25 --> Controller Class Initialized
ERROR - 2023-10-29 10:01:25 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:42:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:42:00 --> Config Class Initialized
INFO - 2023-10-29 10:42:00 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:42:00 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:42:00 --> Utf8 Class Initialized
INFO - 2023-10-29 10:42:00 --> URI Class Initialized
INFO - 2023-10-29 10:42:00 --> Router Class Initialized
INFO - 2023-10-29 10:42:00 --> Output Class Initialized
INFO - 2023-10-29 10:42:00 --> Security Class Initialized
DEBUG - 2023-10-29 10:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:42:00 --> Input Class Initialized
INFO - 2023-10-29 10:42:00 --> Language Class Initialized
INFO - 2023-10-29 10:42:00 --> Loader Class Initialized
INFO - 2023-10-29 10:42:00 --> Helper loaded: url_helper
INFO - 2023-10-29 10:42:00 --> Helper loaded: form_helper
INFO - 2023-10-29 10:42:00 --> Helper loaded: file_helper
INFO - 2023-10-29 10:42:00 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:42:00 --> Form Validation Class Initialized
INFO - 2023-10-29 10:42:00 --> Upload Class Initialized
INFO - 2023-10-29 10:42:00 --> Model "M_auth" initialized
INFO - 2023-10-29 10:42:00 --> Model "M_user" initialized
INFO - 2023-10-29 10:42:00 --> Model "M_produk" initialized
INFO - 2023-10-29 10:42:00 --> Controller Class Initialized
ERROR - 2023-10-29 10:42:00 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:45:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:45:15 --> Config Class Initialized
INFO - 2023-10-29 10:45:15 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:45:15 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:45:15 --> Utf8 Class Initialized
INFO - 2023-10-29 10:45:15 --> URI Class Initialized
INFO - 2023-10-29 10:45:15 --> Router Class Initialized
INFO - 2023-10-29 10:45:15 --> Output Class Initialized
INFO - 2023-10-29 10:45:15 --> Security Class Initialized
DEBUG - 2023-10-29 10:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:45:15 --> Input Class Initialized
INFO - 2023-10-29 10:45:15 --> Language Class Initialized
INFO - 2023-10-29 10:45:15 --> Loader Class Initialized
INFO - 2023-10-29 10:45:15 --> Helper loaded: url_helper
INFO - 2023-10-29 10:45:15 --> Helper loaded: form_helper
INFO - 2023-10-29 10:45:15 --> Helper loaded: file_helper
INFO - 2023-10-29 10:45:15 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:45:15 --> Form Validation Class Initialized
INFO - 2023-10-29 10:45:15 --> Upload Class Initialized
INFO - 2023-10-29 10:45:15 --> Model "M_auth" initialized
INFO - 2023-10-29 10:45:15 --> Model "M_user" initialized
INFO - 2023-10-29 10:45:15 --> Model "M_produk" initialized
INFO - 2023-10-29 10:45:15 --> Controller Class Initialized
INFO - 2023-10-29 10:45:15 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 10:45:15 --> Final output sent to browser
DEBUG - 2023-10-29 10:45:15 --> Total execution time: 0.0494
ERROR - 2023-10-29 10:46:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:46:10 --> Config Class Initialized
INFO - 2023-10-29 10:46:10 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:46:10 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:46:10 --> Utf8 Class Initialized
INFO - 2023-10-29 10:46:10 --> URI Class Initialized
INFO - 2023-10-29 10:46:10 --> Router Class Initialized
INFO - 2023-10-29 10:46:10 --> Output Class Initialized
INFO - 2023-10-29 10:46:10 --> Security Class Initialized
DEBUG - 2023-10-29 10:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:46:10 --> Input Class Initialized
INFO - 2023-10-29 10:46:10 --> Language Class Initialized
INFO - 2023-10-29 10:46:10 --> Loader Class Initialized
INFO - 2023-10-29 10:46:10 --> Helper loaded: url_helper
INFO - 2023-10-29 10:46:10 --> Helper loaded: form_helper
INFO - 2023-10-29 10:46:10 --> Helper loaded: file_helper
INFO - 2023-10-29 10:46:11 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:46:11 --> Form Validation Class Initialized
INFO - 2023-10-29 10:46:11 --> Upload Class Initialized
INFO - 2023-10-29 10:46:11 --> Model "M_auth" initialized
INFO - 2023-10-29 10:46:11 --> Model "M_user" initialized
INFO - 2023-10-29 10:46:11 --> Model "M_produk" initialized
INFO - 2023-10-29 10:46:11 --> Controller Class Initialized
INFO - 2023-10-29 10:46:11 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 10:46:11 --> Final output sent to browser
DEBUG - 2023-10-29 10:46:11 --> Total execution time: 0.0854
ERROR - 2023-10-29 10:46:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:46:11 --> Config Class Initialized
INFO - 2023-10-29 10:46:11 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:46:11 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:46:11 --> Utf8 Class Initialized
INFO - 2023-10-29 10:46:11 --> URI Class Initialized
INFO - 2023-10-29 10:46:11 --> Router Class Initialized
INFO - 2023-10-29 10:46:11 --> Output Class Initialized
INFO - 2023-10-29 10:46:11 --> Security Class Initialized
DEBUG - 2023-10-29 10:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:46:11 --> Input Class Initialized
INFO - 2023-10-29 10:46:11 --> Language Class Initialized
INFO - 2023-10-29 10:46:11 --> Loader Class Initialized
INFO - 2023-10-29 10:46:11 --> Helper loaded: url_helper
INFO - 2023-10-29 10:46:11 --> Helper loaded: form_helper
INFO - 2023-10-29 10:46:11 --> Helper loaded: file_helper
INFO - 2023-10-29 10:46:11 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:46:11 --> Form Validation Class Initialized
INFO - 2023-10-29 10:46:11 --> Upload Class Initialized
INFO - 2023-10-29 10:46:11 --> Model "M_auth" initialized
INFO - 2023-10-29 10:46:11 --> Model "M_user" initialized
INFO - 2023-10-29 10:46:11 --> Model "M_produk" initialized
INFO - 2023-10-29 10:46:11 --> Controller Class Initialized
INFO - 2023-10-29 10:46:11 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 10:46:11 --> Final output sent to browser
DEBUG - 2023-10-29 10:46:11 --> Total execution time: 0.0780
ERROR - 2023-10-29 10:46:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:46:13 --> Config Class Initialized
INFO - 2023-10-29 10:46:13 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:46:13 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:46:13 --> Utf8 Class Initialized
INFO - 2023-10-29 10:46:13 --> URI Class Initialized
INFO - 2023-10-29 10:46:13 --> Router Class Initialized
INFO - 2023-10-29 10:46:13 --> Output Class Initialized
INFO - 2023-10-29 10:46:13 --> Security Class Initialized
DEBUG - 2023-10-29 10:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:46:13 --> Input Class Initialized
INFO - 2023-10-29 10:46:13 --> Language Class Initialized
INFO - 2023-10-29 10:46:13 --> Loader Class Initialized
INFO - 2023-10-29 10:46:13 --> Helper loaded: url_helper
INFO - 2023-10-29 10:46:13 --> Helper loaded: form_helper
INFO - 2023-10-29 10:46:13 --> Helper loaded: file_helper
INFO - 2023-10-29 10:46:13 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:46:13 --> Form Validation Class Initialized
INFO - 2023-10-29 10:46:13 --> Upload Class Initialized
INFO - 2023-10-29 10:46:13 --> Model "M_auth" initialized
INFO - 2023-10-29 10:46:13 --> Model "M_user" initialized
INFO - 2023-10-29 10:46:13 --> Model "M_produk" initialized
INFO - 2023-10-29 10:46:13 --> Controller Class Initialized
ERROR - 2023-10-29 10:46:13 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:52:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:52:22 --> Config Class Initialized
INFO - 2023-10-29 10:52:22 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:52:22 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:52:22 --> Utf8 Class Initialized
INFO - 2023-10-29 10:52:22 --> URI Class Initialized
INFO - 2023-10-29 10:52:22 --> Router Class Initialized
INFO - 2023-10-29 10:52:22 --> Output Class Initialized
INFO - 2023-10-29 10:52:22 --> Security Class Initialized
DEBUG - 2023-10-29 10:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:52:22 --> Input Class Initialized
INFO - 2023-10-29 10:52:22 --> Language Class Initialized
INFO - 2023-10-29 10:52:22 --> Loader Class Initialized
INFO - 2023-10-29 10:52:22 --> Helper loaded: url_helper
INFO - 2023-10-29 10:52:22 --> Helper loaded: form_helper
INFO - 2023-10-29 10:52:22 --> Helper loaded: file_helper
INFO - 2023-10-29 10:52:22 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:52:22 --> Form Validation Class Initialized
INFO - 2023-10-29 10:52:22 --> Upload Class Initialized
INFO - 2023-10-29 10:52:22 --> Model "M_auth" initialized
INFO - 2023-10-29 10:52:22 --> Model "M_user" initialized
INFO - 2023-10-29 10:52:22 --> Model "M_produk" initialized
INFO - 2023-10-29 10:52:22 --> Controller Class Initialized
ERROR - 2023-10-29 10:52:22 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:52:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:52:23 --> Config Class Initialized
INFO - 2023-10-29 10:52:23 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:52:23 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:52:23 --> Utf8 Class Initialized
INFO - 2023-10-29 10:52:23 --> URI Class Initialized
INFO - 2023-10-29 10:52:23 --> Router Class Initialized
INFO - 2023-10-29 10:52:23 --> Output Class Initialized
INFO - 2023-10-29 10:52:23 --> Security Class Initialized
DEBUG - 2023-10-29 10:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:52:23 --> Input Class Initialized
INFO - 2023-10-29 10:52:23 --> Language Class Initialized
INFO - 2023-10-29 10:52:23 --> Loader Class Initialized
INFO - 2023-10-29 10:52:23 --> Helper loaded: url_helper
INFO - 2023-10-29 10:52:24 --> Helper loaded: form_helper
INFO - 2023-10-29 10:52:24 --> Helper loaded: file_helper
INFO - 2023-10-29 10:52:24 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:52:24 --> Form Validation Class Initialized
INFO - 2023-10-29 10:52:24 --> Upload Class Initialized
INFO - 2023-10-29 10:52:24 --> Model "M_auth" initialized
INFO - 2023-10-29 10:52:24 --> Model "M_user" initialized
INFO - 2023-10-29 10:52:24 --> Model "M_produk" initialized
INFO - 2023-10-29 10:52:24 --> Controller Class Initialized
ERROR - 2023-10-29 10:52:24 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:52:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:52:27 --> Config Class Initialized
INFO - 2023-10-29 10:52:27 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:52:27 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:52:27 --> Utf8 Class Initialized
INFO - 2023-10-29 10:52:27 --> URI Class Initialized
DEBUG - 2023-10-29 10:52:27 --> No URI present. Default controller set.
INFO - 2023-10-29 10:52:27 --> Router Class Initialized
INFO - 2023-10-29 10:52:27 --> Output Class Initialized
INFO - 2023-10-29 10:52:27 --> Security Class Initialized
DEBUG - 2023-10-29 10:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:52:27 --> Input Class Initialized
INFO - 2023-10-29 10:52:27 --> Language Class Initialized
INFO - 2023-10-29 10:52:27 --> Loader Class Initialized
INFO - 2023-10-29 10:52:27 --> Helper loaded: url_helper
INFO - 2023-10-29 10:52:27 --> Helper loaded: form_helper
INFO - 2023-10-29 10:52:27 --> Helper loaded: file_helper
INFO - 2023-10-29 10:52:27 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:52:27 --> Form Validation Class Initialized
INFO - 2023-10-29 10:52:27 --> Upload Class Initialized
INFO - 2023-10-29 10:52:27 --> Model "M_auth" initialized
INFO - 2023-10-29 10:52:27 --> Model "M_user" initialized
INFO - 2023-10-29 10:52:27 --> Model "M_produk" initialized
INFO - 2023-10-29 10:52:27 --> Controller Class Initialized
INFO - 2023-10-29 10:52:27 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 10:52:27 --> Model "M_produk" initialized
DEBUG - 2023-10-29 10:52:27 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 10:52:27 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 10:52:27 --> Model "M_transaksi" initialized
INFO - 2023-10-29 10:52:27 --> Model "M_bank" initialized
INFO - 2023-10-29 10:52:27 --> Model "M_pesan" initialized
INFO - 2023-10-29 10:52:27 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-29 10:52:27 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-29 10:52:27 --> Final output sent to browser
DEBUG - 2023-10-29 10:52:27 --> Total execution time: 0.1010
ERROR - 2023-10-29 10:52:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:52:31 --> Config Class Initialized
INFO - 2023-10-29 10:52:31 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:52:31 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:52:31 --> Utf8 Class Initialized
INFO - 2023-10-29 10:52:31 --> URI Class Initialized
INFO - 2023-10-29 10:52:31 --> Router Class Initialized
INFO - 2023-10-29 10:52:31 --> Output Class Initialized
INFO - 2023-10-29 10:52:31 --> Security Class Initialized
DEBUG - 2023-10-29 10:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:52:31 --> Input Class Initialized
INFO - 2023-10-29 10:52:31 --> Language Class Initialized
INFO - 2023-10-29 10:52:31 --> Loader Class Initialized
INFO - 2023-10-29 10:52:31 --> Helper loaded: url_helper
INFO - 2023-10-29 10:52:31 --> Helper loaded: form_helper
INFO - 2023-10-29 10:52:31 --> Helper loaded: file_helper
INFO - 2023-10-29 10:52:31 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:52:31 --> Form Validation Class Initialized
INFO - 2023-10-29 10:52:31 --> Upload Class Initialized
INFO - 2023-10-29 10:52:31 --> Model "M_auth" initialized
INFO - 2023-10-29 10:52:31 --> Model "M_user" initialized
INFO - 2023-10-29 10:52:31 --> Model "M_produk" initialized
INFO - 2023-10-29 10:52:31 --> Controller Class Initialized
ERROR - 2023-10-29 10:52:31 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:26 --> Config Class Initialized
INFO - 2023-10-29 10:56:26 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:26 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:26 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:26 --> URI Class Initialized
INFO - 2023-10-29 10:56:26 --> Router Class Initialized
INFO - 2023-10-29 10:56:26 --> Output Class Initialized
INFO - 2023-10-29 10:56:26 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:26 --> Input Class Initialized
INFO - 2023-10-29 10:56:26 --> Language Class Initialized
INFO - 2023-10-29 10:56:26 --> Loader Class Initialized
INFO - 2023-10-29 10:56:26 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:26 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:26 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:26 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:26 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:26 --> Upload Class Initialized
INFO - 2023-10-29 10:56:26 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:26 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:26 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:26 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:26 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:27 --> Config Class Initialized
INFO - 2023-10-29 10:56:27 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:27 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:27 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:27 --> URI Class Initialized
INFO - 2023-10-29 10:56:27 --> Router Class Initialized
INFO - 2023-10-29 10:56:27 --> Output Class Initialized
INFO - 2023-10-29 10:56:27 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:27 --> Input Class Initialized
INFO - 2023-10-29 10:56:27 --> Language Class Initialized
INFO - 2023-10-29 10:56:27 --> Loader Class Initialized
INFO - 2023-10-29 10:56:27 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:27 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:27 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:27 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:27 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:27 --> Upload Class Initialized
INFO - 2023-10-29 10:56:27 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:27 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:27 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:27 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:27 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:28 --> Config Class Initialized
INFO - 2023-10-29 10:56:28 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:28 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:28 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:28 --> URI Class Initialized
INFO - 2023-10-29 10:56:28 --> Router Class Initialized
INFO - 2023-10-29 10:56:28 --> Output Class Initialized
INFO - 2023-10-29 10:56:28 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:28 --> Input Class Initialized
INFO - 2023-10-29 10:56:28 --> Language Class Initialized
INFO - 2023-10-29 10:56:28 --> Loader Class Initialized
INFO - 2023-10-29 10:56:28 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:28 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:28 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:28 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:28 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:28 --> Upload Class Initialized
INFO - 2023-10-29 10:56:28 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:28 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:28 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:28 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:28 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:28 --> Config Class Initialized
INFO - 2023-10-29 10:56:28 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:28 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:28 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:28 --> URI Class Initialized
INFO - 2023-10-29 10:56:28 --> Router Class Initialized
INFO - 2023-10-29 10:56:28 --> Output Class Initialized
INFO - 2023-10-29 10:56:28 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:28 --> Input Class Initialized
INFO - 2023-10-29 10:56:28 --> Language Class Initialized
INFO - 2023-10-29 10:56:28 --> Loader Class Initialized
INFO - 2023-10-29 10:56:28 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:28 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:28 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:28 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:28 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:28 --> Upload Class Initialized
INFO - 2023-10-29 10:56:28 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:28 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:28 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:28 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:28 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:28 --> Config Class Initialized
INFO - 2023-10-29 10:56:28 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:28 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:28 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:28 --> URI Class Initialized
DEBUG - 2023-10-29 10:56:28 --> No URI present. Default controller set.
INFO - 2023-10-29 10:56:28 --> Router Class Initialized
INFO - 2023-10-29 10:56:28 --> Output Class Initialized
INFO - 2023-10-29 10:56:28 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:28 --> Input Class Initialized
INFO - 2023-10-29 10:56:28 --> Language Class Initialized
INFO - 2023-10-29 10:56:29 --> Loader Class Initialized
INFO - 2023-10-29 10:56:29 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:29 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:29 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:29 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:29 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:29 --> Upload Class Initialized
INFO - 2023-10-29 10:56:29 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:29 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:29 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:29 --> Controller Class Initialized
INFO - 2023-10-29 10:56:29 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 10:56:29 --> Model "M_produk" initialized
DEBUG - 2023-10-29 10:56:29 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 10:56:29 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 10:56:29 --> Model "M_transaksi" initialized
INFO - 2023-10-29 10:56:29 --> Model "M_bank" initialized
INFO - 2023-10-29 10:56:29 --> Model "M_pesan" initialized
INFO - 2023-10-29 10:56:29 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-29 10:56:29 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-29 10:56:29 --> Final output sent to browser
DEBUG - 2023-10-29 10:56:29 --> Total execution time: 0.0902
ERROR - 2023-10-29 10:56:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:30 --> Config Class Initialized
INFO - 2023-10-29 10:56:30 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:30 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:30 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:30 --> URI Class Initialized
INFO - 2023-10-29 10:56:30 --> Router Class Initialized
INFO - 2023-10-29 10:56:30 --> Output Class Initialized
INFO - 2023-10-29 10:56:30 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:30 --> Input Class Initialized
INFO - 2023-10-29 10:56:30 --> Language Class Initialized
INFO - 2023-10-29 10:56:30 --> Loader Class Initialized
INFO - 2023-10-29 10:56:30 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:30 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:30 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:30 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:30 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:30 --> Upload Class Initialized
INFO - 2023-10-29 10:56:30 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:30 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:30 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:30 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:30 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:31 --> Config Class Initialized
INFO - 2023-10-29 10:56:31 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:31 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:31 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:31 --> URI Class Initialized
INFO - 2023-10-29 10:56:31 --> Router Class Initialized
INFO - 2023-10-29 10:56:31 --> Output Class Initialized
INFO - 2023-10-29 10:56:31 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:31 --> Input Class Initialized
INFO - 2023-10-29 10:56:31 --> Language Class Initialized
INFO - 2023-10-29 10:56:31 --> Loader Class Initialized
INFO - 2023-10-29 10:56:31 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:31 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:31 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:31 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:31 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:31 --> Upload Class Initialized
INFO - 2023-10-29 10:56:31 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:31 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:31 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:31 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:31 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:32 --> Config Class Initialized
INFO - 2023-10-29 10:56:32 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:32 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:32 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:32 --> URI Class Initialized
INFO - 2023-10-29 10:56:32 --> Router Class Initialized
INFO - 2023-10-29 10:56:32 --> Output Class Initialized
INFO - 2023-10-29 10:56:32 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:32 --> Input Class Initialized
INFO - 2023-10-29 10:56:32 --> Language Class Initialized
INFO - 2023-10-29 10:56:32 --> Loader Class Initialized
INFO - 2023-10-29 10:56:32 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:32 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:32 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:32 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:32 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:32 --> Upload Class Initialized
INFO - 2023-10-29 10:56:32 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:32 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:32 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:32 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:32 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:32 --> Config Class Initialized
INFO - 2023-10-29 10:56:32 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:32 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:32 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:32 --> URI Class Initialized
INFO - 2023-10-29 10:56:32 --> Router Class Initialized
INFO - 2023-10-29 10:56:32 --> Output Class Initialized
INFO - 2023-10-29 10:56:32 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:32 --> Input Class Initialized
INFO - 2023-10-29 10:56:32 --> Language Class Initialized
INFO - 2023-10-29 10:56:32 --> Loader Class Initialized
INFO - 2023-10-29 10:56:32 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:32 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:32 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:32 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:32 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:32 --> Upload Class Initialized
INFO - 2023-10-29 10:56:32 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:32 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:32 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:32 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:32 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:32 --> Config Class Initialized
INFO - 2023-10-29 10:56:32 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:32 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:32 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:32 --> URI Class Initialized
INFO - 2023-10-29 10:56:32 --> Router Class Initialized
INFO - 2023-10-29 10:56:32 --> Output Class Initialized
INFO - 2023-10-29 10:56:32 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:32 --> Input Class Initialized
INFO - 2023-10-29 10:56:32 --> Language Class Initialized
INFO - 2023-10-29 10:56:32 --> Loader Class Initialized
INFO - 2023-10-29 10:56:32 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:32 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:32 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:32 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:32 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:32 --> Upload Class Initialized
INFO - 2023-10-29 10:56:32 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:32 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:32 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:32 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:32 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:32 --> Config Class Initialized
INFO - 2023-10-29 10:56:32 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:32 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:32 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:32 --> URI Class Initialized
INFO - 2023-10-29 10:56:32 --> Router Class Initialized
INFO - 2023-10-29 10:56:32 --> Output Class Initialized
INFO - 2023-10-29 10:56:32 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:32 --> Input Class Initialized
INFO - 2023-10-29 10:56:32 --> Language Class Initialized
INFO - 2023-10-29 10:56:32 --> Loader Class Initialized
INFO - 2023-10-29 10:56:32 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:32 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:32 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:32 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:32 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:32 --> Upload Class Initialized
INFO - 2023-10-29 10:56:32 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:32 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:32 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:32 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:32 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:32 --> Config Class Initialized
INFO - 2023-10-29 10:56:32 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:32 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:32 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:32 --> URI Class Initialized
INFO - 2023-10-29 10:56:32 --> Router Class Initialized
INFO - 2023-10-29 10:56:32 --> Output Class Initialized
INFO - 2023-10-29 10:56:32 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:32 --> Input Class Initialized
INFO - 2023-10-29 10:56:32 --> Language Class Initialized
INFO - 2023-10-29 10:56:32 --> Loader Class Initialized
INFO - 2023-10-29 10:56:32 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:32 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:32 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:32 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:32 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:32 --> Upload Class Initialized
INFO - 2023-10-29 10:56:32 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:32 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:32 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:32 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:32 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:32 --> Config Class Initialized
INFO - 2023-10-29 10:56:32 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:32 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:32 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:32 --> URI Class Initialized
INFO - 2023-10-29 10:56:32 --> Router Class Initialized
INFO - 2023-10-29 10:56:32 --> Output Class Initialized
INFO - 2023-10-29 10:56:32 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:32 --> Input Class Initialized
INFO - 2023-10-29 10:56:32 --> Language Class Initialized
INFO - 2023-10-29 10:56:32 --> Loader Class Initialized
INFO - 2023-10-29 10:56:32 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:32 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:32 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:32 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:32 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:32 --> Upload Class Initialized
INFO - 2023-10-29 10:56:32 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:32 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:32 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:32 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:32 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:33 --> Config Class Initialized
INFO - 2023-10-29 10:56:33 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:33 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:33 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:33 --> URI Class Initialized
INFO - 2023-10-29 10:56:33 --> Router Class Initialized
INFO - 2023-10-29 10:56:33 --> Output Class Initialized
INFO - 2023-10-29 10:56:33 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:33 --> Input Class Initialized
INFO - 2023-10-29 10:56:33 --> Language Class Initialized
INFO - 2023-10-29 10:56:33 --> Loader Class Initialized
INFO - 2023-10-29 10:56:33 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:33 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:33 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:33 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:33 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:33 --> Upload Class Initialized
INFO - 2023-10-29 10:56:33 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:33 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:33 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:33 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:33 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:33 --> Config Class Initialized
INFO - 2023-10-29 10:56:33 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:33 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:33 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:33 --> URI Class Initialized
INFO - 2023-10-29 10:56:33 --> Router Class Initialized
INFO - 2023-10-29 10:56:33 --> Output Class Initialized
INFO - 2023-10-29 10:56:33 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:33 --> Input Class Initialized
INFO - 2023-10-29 10:56:33 --> Language Class Initialized
INFO - 2023-10-29 10:56:33 --> Loader Class Initialized
INFO - 2023-10-29 10:56:33 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:33 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:33 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:33 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:33 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:33 --> Upload Class Initialized
INFO - 2023-10-29 10:56:33 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:33 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:33 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:33 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:33 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:33 --> Config Class Initialized
INFO - 2023-10-29 10:56:33 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:33 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:33 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:33 --> URI Class Initialized
INFO - 2023-10-29 10:56:33 --> Router Class Initialized
INFO - 2023-10-29 10:56:33 --> Output Class Initialized
INFO - 2023-10-29 10:56:33 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:33 --> Input Class Initialized
INFO - 2023-10-29 10:56:33 --> Language Class Initialized
INFO - 2023-10-29 10:56:33 --> Loader Class Initialized
INFO - 2023-10-29 10:56:33 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:33 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:33 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:33 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:33 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:33 --> Upload Class Initialized
INFO - 2023-10-29 10:56:33 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:33 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:33 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:33 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:33 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:38 --> Config Class Initialized
INFO - 2023-10-29 10:56:38 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:38 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:38 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:38 --> URI Class Initialized
INFO - 2023-10-29 10:56:38 --> Router Class Initialized
INFO - 2023-10-29 10:56:38 --> Output Class Initialized
INFO - 2023-10-29 10:56:38 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:38 --> Input Class Initialized
INFO - 2023-10-29 10:56:38 --> Language Class Initialized
INFO - 2023-10-29 10:56:38 --> Loader Class Initialized
INFO - 2023-10-29 10:56:38 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:38 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:38 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:38 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:38 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:38 --> Upload Class Initialized
INFO - 2023-10-29 10:56:38 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:38 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:38 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:38 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:38 --> Severity: error --> Exception: Undefined constant "Midtrans" C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Payment.php 9
ERROR - 2023-10-29 10:56:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:39 --> Config Class Initialized
INFO - 2023-10-29 10:56:39 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:39 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:39 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:39 --> URI Class Initialized
INFO - 2023-10-29 10:56:39 --> Router Class Initialized
INFO - 2023-10-29 10:56:39 --> Output Class Initialized
INFO - 2023-10-29 10:56:39 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:39 --> Input Class Initialized
INFO - 2023-10-29 10:56:39 --> Language Class Initialized
INFO - 2023-10-29 10:56:39 --> Loader Class Initialized
INFO - 2023-10-29 10:56:39 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:39 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:39 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:39 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:39 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:39 --> Upload Class Initialized
INFO - 2023-10-29 10:56:39 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:39 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:39 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:39 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:39 --> Severity: error --> Exception: Undefined constant "Midtrans" C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Payment.php 9
ERROR - 2023-10-29 10:56:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:39 --> Config Class Initialized
INFO - 2023-10-29 10:56:39 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:39 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:39 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:39 --> URI Class Initialized
INFO - 2023-10-29 10:56:39 --> Router Class Initialized
INFO - 2023-10-29 10:56:39 --> Output Class Initialized
INFO - 2023-10-29 10:56:39 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:39 --> Input Class Initialized
INFO - 2023-10-29 10:56:39 --> Language Class Initialized
INFO - 2023-10-29 10:56:39 --> Loader Class Initialized
INFO - 2023-10-29 10:56:39 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:39 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:39 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:39 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:39 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:39 --> Upload Class Initialized
INFO - 2023-10-29 10:56:39 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:40 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:40 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:40 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:40 --> Severity: error --> Exception: Undefined constant "Midtrans" C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Payment.php 9
ERROR - 2023-10-29 10:56:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:40 --> Config Class Initialized
INFO - 2023-10-29 10:56:40 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:40 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:40 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:40 --> URI Class Initialized
INFO - 2023-10-29 10:56:40 --> Router Class Initialized
INFO - 2023-10-29 10:56:40 --> Output Class Initialized
INFO - 2023-10-29 10:56:40 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:40 --> Input Class Initialized
INFO - 2023-10-29 10:56:40 --> Language Class Initialized
INFO - 2023-10-29 10:56:40 --> Loader Class Initialized
INFO - 2023-10-29 10:56:40 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:40 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:40 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:40 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:40 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:40 --> Upload Class Initialized
INFO - 2023-10-29 10:56:40 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:40 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:40 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:40 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:40 --> Severity: error --> Exception: Undefined constant "Midtrans" C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Payment.php 9
ERROR - 2023-10-29 10:56:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:40 --> Config Class Initialized
INFO - 2023-10-29 10:56:40 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:40 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:40 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:40 --> URI Class Initialized
INFO - 2023-10-29 10:56:40 --> Router Class Initialized
INFO - 2023-10-29 10:56:40 --> Output Class Initialized
INFO - 2023-10-29 10:56:40 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:40 --> Input Class Initialized
INFO - 2023-10-29 10:56:40 --> Language Class Initialized
INFO - 2023-10-29 10:56:40 --> Loader Class Initialized
INFO - 2023-10-29 10:56:40 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:40 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:40 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:40 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:40 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:40 --> Upload Class Initialized
INFO - 2023-10-29 10:56:40 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:40 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:40 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:40 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:40 --> Severity: error --> Exception: Undefined constant "Midtrans" C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Payment.php 9
ERROR - 2023-10-29 10:56:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:47 --> Config Class Initialized
INFO - 2023-10-29 10:56:47 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:47 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:47 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:47 --> URI Class Initialized
INFO - 2023-10-29 10:56:47 --> Router Class Initialized
INFO - 2023-10-29 10:56:48 --> Output Class Initialized
INFO - 2023-10-29 10:56:48 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:48 --> Input Class Initialized
INFO - 2023-10-29 10:56:48 --> Language Class Initialized
INFO - 2023-10-29 10:56:48 --> Loader Class Initialized
INFO - 2023-10-29 10:56:48 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:48 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:48 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:48 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:48 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:48 --> Upload Class Initialized
INFO - 2023-10-29 10:56:48 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:48 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:48 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:48 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:48 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:48 --> Config Class Initialized
INFO - 2023-10-29 10:56:48 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:48 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:48 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:48 --> URI Class Initialized
INFO - 2023-10-29 10:56:48 --> Router Class Initialized
INFO - 2023-10-29 10:56:48 --> Output Class Initialized
INFO - 2023-10-29 10:56:48 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:48 --> Input Class Initialized
INFO - 2023-10-29 10:56:48 --> Language Class Initialized
INFO - 2023-10-29 10:56:48 --> Loader Class Initialized
INFO - 2023-10-29 10:56:48 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:48 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:48 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:48 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:48 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:48 --> Upload Class Initialized
INFO - 2023-10-29 10:56:48 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:48 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:48 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:48 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:48 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:48 --> Config Class Initialized
INFO - 2023-10-29 10:56:48 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:48 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:48 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:48 --> URI Class Initialized
INFO - 2023-10-29 10:56:48 --> Router Class Initialized
INFO - 2023-10-29 10:56:48 --> Output Class Initialized
INFO - 2023-10-29 10:56:48 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:48 --> Input Class Initialized
INFO - 2023-10-29 10:56:48 --> Language Class Initialized
INFO - 2023-10-29 10:56:48 --> Loader Class Initialized
INFO - 2023-10-29 10:56:48 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:48 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:48 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:48 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:48 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:48 --> Upload Class Initialized
INFO - 2023-10-29 10:56:48 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:48 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:48 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:48 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:48 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:48 --> Config Class Initialized
INFO - 2023-10-29 10:56:48 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:48 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:48 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:48 --> URI Class Initialized
INFO - 2023-10-29 10:56:48 --> Router Class Initialized
INFO - 2023-10-29 10:56:48 --> Output Class Initialized
INFO - 2023-10-29 10:56:48 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:48 --> Input Class Initialized
INFO - 2023-10-29 10:56:48 --> Language Class Initialized
INFO - 2023-10-29 10:56:48 --> Loader Class Initialized
INFO - 2023-10-29 10:56:48 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:48 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:48 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:48 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:48 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:48 --> Upload Class Initialized
INFO - 2023-10-29 10:56:48 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:48 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:48 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:48 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:48 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:48 --> Config Class Initialized
INFO - 2023-10-29 10:56:48 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:48 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:48 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:48 --> URI Class Initialized
INFO - 2023-10-29 10:56:48 --> Router Class Initialized
INFO - 2023-10-29 10:56:48 --> Output Class Initialized
INFO - 2023-10-29 10:56:48 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:48 --> Input Class Initialized
INFO - 2023-10-29 10:56:48 --> Language Class Initialized
INFO - 2023-10-29 10:56:48 --> Loader Class Initialized
INFO - 2023-10-29 10:56:48 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:48 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:48 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:48 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:48 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:48 --> Upload Class Initialized
INFO - 2023-10-29 10:56:48 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:48 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:48 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:48 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:48 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:49 --> Config Class Initialized
INFO - 2023-10-29 10:56:49 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:49 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:49 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:49 --> URI Class Initialized
INFO - 2023-10-29 10:56:49 --> Router Class Initialized
INFO - 2023-10-29 10:56:49 --> Output Class Initialized
INFO - 2023-10-29 10:56:49 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:49 --> Input Class Initialized
INFO - 2023-10-29 10:56:49 --> Language Class Initialized
INFO - 2023-10-29 10:56:49 --> Loader Class Initialized
INFO - 2023-10-29 10:56:49 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:49 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:49 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:49 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:49 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:49 --> Upload Class Initialized
INFO - 2023-10-29 10:56:49 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:49 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:49 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:49 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:49 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:49 --> Config Class Initialized
INFO - 2023-10-29 10:56:49 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:49 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:49 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:49 --> URI Class Initialized
INFO - 2023-10-29 10:56:49 --> Router Class Initialized
INFO - 2023-10-29 10:56:49 --> Output Class Initialized
INFO - 2023-10-29 10:56:49 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:49 --> Input Class Initialized
INFO - 2023-10-29 10:56:49 --> Language Class Initialized
INFO - 2023-10-29 10:56:49 --> Loader Class Initialized
INFO - 2023-10-29 10:56:49 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:49 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:49 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:49 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:49 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:49 --> Upload Class Initialized
INFO - 2023-10-29 10:56:49 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:49 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:49 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:49 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:49 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:52 --> Config Class Initialized
INFO - 2023-10-29 10:56:52 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:52 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:52 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:52 --> URI Class Initialized
INFO - 2023-10-29 10:56:52 --> Router Class Initialized
INFO - 2023-10-29 10:56:52 --> Output Class Initialized
INFO - 2023-10-29 10:56:52 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:52 --> Input Class Initialized
INFO - 2023-10-29 10:56:52 --> Language Class Initialized
INFO - 2023-10-29 10:56:52 --> Loader Class Initialized
INFO - 2023-10-29 10:56:52 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:52 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:52 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:52 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:52 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:52 --> Upload Class Initialized
INFO - 2023-10-29 10:56:52 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:52 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:52 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:52 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:52 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:52 --> Config Class Initialized
INFO - 2023-10-29 10:56:52 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:52 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:52 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:52 --> URI Class Initialized
INFO - 2023-10-29 10:56:52 --> Router Class Initialized
INFO - 2023-10-29 10:56:52 --> Output Class Initialized
INFO - 2023-10-29 10:56:52 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:52 --> Input Class Initialized
INFO - 2023-10-29 10:56:52 --> Language Class Initialized
INFO - 2023-10-29 10:56:52 --> Loader Class Initialized
INFO - 2023-10-29 10:56:52 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:52 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:52 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:52 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:52 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:52 --> Upload Class Initialized
INFO - 2023-10-29 10:56:52 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:52 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:52 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:52 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:52 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:53 --> Config Class Initialized
INFO - 2023-10-29 10:56:53 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:53 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:53 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:53 --> URI Class Initialized
INFO - 2023-10-29 10:56:53 --> Router Class Initialized
INFO - 2023-10-29 10:56:53 --> Output Class Initialized
INFO - 2023-10-29 10:56:53 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:53 --> Input Class Initialized
INFO - 2023-10-29 10:56:53 --> Language Class Initialized
INFO - 2023-10-29 10:56:53 --> Loader Class Initialized
INFO - 2023-10-29 10:56:53 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:53 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:53 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:53 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:53 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:53 --> Upload Class Initialized
INFO - 2023-10-29 10:56:53 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:53 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:53 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:53 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:53 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:53 --> Config Class Initialized
INFO - 2023-10-29 10:56:53 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:53 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:53 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:53 --> URI Class Initialized
INFO - 2023-10-29 10:56:53 --> Router Class Initialized
INFO - 2023-10-29 10:56:53 --> Output Class Initialized
INFO - 2023-10-29 10:56:53 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:53 --> Input Class Initialized
INFO - 2023-10-29 10:56:53 --> Language Class Initialized
INFO - 2023-10-29 10:56:53 --> Loader Class Initialized
INFO - 2023-10-29 10:56:53 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:53 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:53 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:53 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:53 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:53 --> Upload Class Initialized
INFO - 2023-10-29 10:56:53 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:53 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:53 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:53 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:53 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:53 --> Config Class Initialized
INFO - 2023-10-29 10:56:53 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:53 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:53 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:53 --> URI Class Initialized
INFO - 2023-10-29 10:56:53 --> Router Class Initialized
INFO - 2023-10-29 10:56:53 --> Output Class Initialized
INFO - 2023-10-29 10:56:53 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:53 --> Input Class Initialized
INFO - 2023-10-29 10:56:53 --> Language Class Initialized
INFO - 2023-10-29 10:56:53 --> Loader Class Initialized
INFO - 2023-10-29 10:56:53 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:53 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:53 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:53 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:53 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:53 --> Upload Class Initialized
INFO - 2023-10-29 10:56:53 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:53 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:53 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:53 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:53 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:53 --> Config Class Initialized
INFO - 2023-10-29 10:56:53 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:53 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:53 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:53 --> URI Class Initialized
INFO - 2023-10-29 10:56:53 --> Router Class Initialized
INFO - 2023-10-29 10:56:53 --> Output Class Initialized
INFO - 2023-10-29 10:56:53 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:53 --> Input Class Initialized
INFO - 2023-10-29 10:56:53 --> Language Class Initialized
INFO - 2023-10-29 10:56:53 --> Loader Class Initialized
INFO - 2023-10-29 10:56:53 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:53 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:53 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:53 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:53 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:53 --> Upload Class Initialized
INFO - 2023-10-29 10:56:53 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:53 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:53 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:53 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:53 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:56 --> Config Class Initialized
INFO - 2023-10-29 10:56:56 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:56 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:56 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:56 --> URI Class Initialized
INFO - 2023-10-29 10:56:56 --> Router Class Initialized
INFO - 2023-10-29 10:56:56 --> Output Class Initialized
INFO - 2023-10-29 10:56:56 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:56 --> Input Class Initialized
INFO - 2023-10-29 10:56:56 --> Language Class Initialized
INFO - 2023-10-29 10:56:56 --> Loader Class Initialized
INFO - 2023-10-29 10:56:56 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:56 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:56 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:56 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:56 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:56 --> Upload Class Initialized
INFO - 2023-10-29 10:56:56 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:56 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:56 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:56 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:56 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:56 --> Config Class Initialized
INFO - 2023-10-29 10:56:56 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:56 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:56 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:56 --> URI Class Initialized
INFO - 2023-10-29 10:56:56 --> Router Class Initialized
INFO - 2023-10-29 10:56:56 --> Output Class Initialized
INFO - 2023-10-29 10:56:56 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:56 --> Input Class Initialized
INFO - 2023-10-29 10:56:56 --> Language Class Initialized
INFO - 2023-10-29 10:56:56 --> Loader Class Initialized
INFO - 2023-10-29 10:56:56 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:56 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:56 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:56 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:56 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:56 --> Upload Class Initialized
INFO - 2023-10-29 10:56:56 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:56 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:56 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:56 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:56 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:56 --> Config Class Initialized
INFO - 2023-10-29 10:56:56 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:56 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:56 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:56 --> URI Class Initialized
INFO - 2023-10-29 10:56:56 --> Router Class Initialized
INFO - 2023-10-29 10:56:56 --> Output Class Initialized
INFO - 2023-10-29 10:56:56 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:56 --> Input Class Initialized
INFO - 2023-10-29 10:56:56 --> Language Class Initialized
INFO - 2023-10-29 10:56:56 --> Loader Class Initialized
INFO - 2023-10-29 10:56:56 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:56 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:56 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:56 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:56 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:56 --> Upload Class Initialized
INFO - 2023-10-29 10:56:56 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:56 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:56 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:56 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:56 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:56 --> Config Class Initialized
INFO - 2023-10-29 10:56:56 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:56 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:56 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:56 --> URI Class Initialized
INFO - 2023-10-29 10:56:56 --> Router Class Initialized
INFO - 2023-10-29 10:56:56 --> Output Class Initialized
INFO - 2023-10-29 10:56:56 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:56 --> Input Class Initialized
INFO - 2023-10-29 10:56:56 --> Language Class Initialized
INFO - 2023-10-29 10:56:56 --> Loader Class Initialized
INFO - 2023-10-29 10:56:56 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:56 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:56 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:56 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:56 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:56 --> Upload Class Initialized
INFO - 2023-10-29 10:56:56 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:56 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:56 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:56 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:56 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:56 --> Config Class Initialized
INFO - 2023-10-29 10:56:56 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:56 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:56 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:56 --> URI Class Initialized
INFO - 2023-10-29 10:56:56 --> Router Class Initialized
INFO - 2023-10-29 10:56:56 --> Output Class Initialized
INFO - 2023-10-29 10:56:56 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:56 --> Input Class Initialized
INFO - 2023-10-29 10:56:56 --> Language Class Initialized
INFO - 2023-10-29 10:56:56 --> Loader Class Initialized
INFO - 2023-10-29 10:56:56 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:56 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:56 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:56 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:56 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:56 --> Upload Class Initialized
INFO - 2023-10-29 10:56:56 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:56 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:56 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:56 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:56 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:56 --> Config Class Initialized
INFO - 2023-10-29 10:56:56 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:56 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:56 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:56 --> URI Class Initialized
INFO - 2023-10-29 10:56:56 --> Router Class Initialized
INFO - 2023-10-29 10:56:56 --> Output Class Initialized
INFO - 2023-10-29 10:56:56 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:56 --> Input Class Initialized
INFO - 2023-10-29 10:56:56 --> Language Class Initialized
INFO - 2023-10-29 10:56:56 --> Loader Class Initialized
INFO - 2023-10-29 10:56:56 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:56 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:56 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:56 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:56 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:56 --> Upload Class Initialized
INFO - 2023-10-29 10:56:56 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:56 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:56 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:56 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:56 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:57 --> Config Class Initialized
INFO - 2023-10-29 10:56:57 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:57 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:57 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:57 --> URI Class Initialized
INFO - 2023-10-29 10:56:57 --> Router Class Initialized
INFO - 2023-10-29 10:56:57 --> Output Class Initialized
INFO - 2023-10-29 10:56:57 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:57 --> Input Class Initialized
INFO - 2023-10-29 10:56:57 --> Language Class Initialized
INFO - 2023-10-29 10:56:57 --> Loader Class Initialized
INFO - 2023-10-29 10:56:57 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:57 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:57 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:57 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:57 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:57 --> Upload Class Initialized
INFO - 2023-10-29 10:56:57 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:57 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:57 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:57 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:57 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:57 --> Config Class Initialized
INFO - 2023-10-29 10:56:57 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:57 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:57 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:57 --> URI Class Initialized
INFO - 2023-10-29 10:56:57 --> Router Class Initialized
INFO - 2023-10-29 10:56:57 --> Output Class Initialized
INFO - 2023-10-29 10:56:57 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:57 --> Input Class Initialized
INFO - 2023-10-29 10:56:57 --> Language Class Initialized
INFO - 2023-10-29 10:56:57 --> Loader Class Initialized
INFO - 2023-10-29 10:56:57 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:57 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:57 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:57 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:57 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:57 --> Upload Class Initialized
INFO - 2023-10-29 10:56:57 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:57 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:57 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:57 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:57 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:57 --> Config Class Initialized
INFO - 2023-10-29 10:56:57 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:57 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:57 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:57 --> URI Class Initialized
INFO - 2023-10-29 10:56:57 --> Router Class Initialized
INFO - 2023-10-29 10:56:57 --> Output Class Initialized
INFO - 2023-10-29 10:56:57 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:57 --> Input Class Initialized
INFO - 2023-10-29 10:56:57 --> Language Class Initialized
INFO - 2023-10-29 10:56:57 --> Loader Class Initialized
INFO - 2023-10-29 10:56:57 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:57 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:57 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:57 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:57 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:57 --> Upload Class Initialized
INFO - 2023-10-29 10:56:57 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:57 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:57 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:57 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:57 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:57 --> Config Class Initialized
INFO - 2023-10-29 10:56:57 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:57 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:57 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:57 --> URI Class Initialized
INFO - 2023-10-29 10:56:57 --> Router Class Initialized
INFO - 2023-10-29 10:56:57 --> Output Class Initialized
INFO - 2023-10-29 10:56:57 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:57 --> Input Class Initialized
INFO - 2023-10-29 10:56:57 --> Language Class Initialized
INFO - 2023-10-29 10:56:57 --> Loader Class Initialized
INFO - 2023-10-29 10:56:57 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:57 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:57 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:57 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:57 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:57 --> Upload Class Initialized
INFO - 2023-10-29 10:56:57 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:57 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:57 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:57 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:57 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:57 --> Config Class Initialized
INFO - 2023-10-29 10:56:57 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:57 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:57 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:57 --> URI Class Initialized
INFO - 2023-10-29 10:56:57 --> Router Class Initialized
INFO - 2023-10-29 10:56:57 --> Output Class Initialized
INFO - 2023-10-29 10:56:57 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:57 --> Input Class Initialized
INFO - 2023-10-29 10:56:57 --> Language Class Initialized
INFO - 2023-10-29 10:56:57 --> Loader Class Initialized
INFO - 2023-10-29 10:56:57 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:57 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:57 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:57 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:57 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:57 --> Upload Class Initialized
INFO - 2023-10-29 10:56:57 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:57 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:57 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:57 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:57 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:57 --> Config Class Initialized
INFO - 2023-10-29 10:56:57 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:57 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:57 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:57 --> URI Class Initialized
INFO - 2023-10-29 10:56:57 --> Router Class Initialized
INFO - 2023-10-29 10:56:57 --> Output Class Initialized
INFO - 2023-10-29 10:56:57 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:57 --> Input Class Initialized
INFO - 2023-10-29 10:56:57 --> Language Class Initialized
INFO - 2023-10-29 10:56:57 --> Loader Class Initialized
INFO - 2023-10-29 10:56:57 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:57 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:57 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:57 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:57 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:57 --> Upload Class Initialized
INFO - 2023-10-29 10:56:57 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:57 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:57 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:57 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:57 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:57 --> Config Class Initialized
INFO - 2023-10-29 10:56:57 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:57 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:57 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:57 --> URI Class Initialized
INFO - 2023-10-29 10:56:57 --> Router Class Initialized
INFO - 2023-10-29 10:56:57 --> Output Class Initialized
INFO - 2023-10-29 10:56:57 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:57 --> Input Class Initialized
INFO - 2023-10-29 10:56:57 --> Language Class Initialized
INFO - 2023-10-29 10:56:57 --> Loader Class Initialized
INFO - 2023-10-29 10:56:57 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:57 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:57 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:58 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:58 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:58 --> Upload Class Initialized
INFO - 2023-10-29 10:56:58 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:58 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:58 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:58 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:58 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:58 --> Config Class Initialized
INFO - 2023-10-29 10:56:58 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:58 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:58 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:58 --> URI Class Initialized
INFO - 2023-10-29 10:56:58 --> Router Class Initialized
INFO - 2023-10-29 10:56:58 --> Output Class Initialized
INFO - 2023-10-29 10:56:58 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:58 --> Input Class Initialized
INFO - 2023-10-29 10:56:58 --> Language Class Initialized
INFO - 2023-10-29 10:56:58 --> Loader Class Initialized
INFO - 2023-10-29 10:56:58 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:58 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:58 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:58 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:58 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:58 --> Upload Class Initialized
INFO - 2023-10-29 10:56:58 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:58 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:58 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:58 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:58 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:58 --> Config Class Initialized
INFO - 2023-10-29 10:56:58 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:58 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:58 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:58 --> URI Class Initialized
INFO - 2023-10-29 10:56:58 --> Router Class Initialized
INFO - 2023-10-29 10:56:58 --> Output Class Initialized
INFO - 2023-10-29 10:56:58 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:58 --> Input Class Initialized
INFO - 2023-10-29 10:56:58 --> Language Class Initialized
INFO - 2023-10-29 10:56:58 --> Loader Class Initialized
INFO - 2023-10-29 10:56:58 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:58 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:58 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:58 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:58 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:58 --> Upload Class Initialized
INFO - 2023-10-29 10:56:58 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:58 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:58 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:58 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:58 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:56:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:56:58 --> Config Class Initialized
INFO - 2023-10-29 10:56:58 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:56:58 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:56:58 --> Utf8 Class Initialized
INFO - 2023-10-29 10:56:58 --> URI Class Initialized
INFO - 2023-10-29 10:56:58 --> Router Class Initialized
INFO - 2023-10-29 10:56:58 --> Output Class Initialized
INFO - 2023-10-29 10:56:58 --> Security Class Initialized
DEBUG - 2023-10-29 10:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:56:58 --> Input Class Initialized
INFO - 2023-10-29 10:56:58 --> Language Class Initialized
INFO - 2023-10-29 10:56:58 --> Loader Class Initialized
INFO - 2023-10-29 10:56:58 --> Helper loaded: url_helper
INFO - 2023-10-29 10:56:58 --> Helper loaded: form_helper
INFO - 2023-10-29 10:56:58 --> Helper loaded: file_helper
INFO - 2023-10-29 10:56:58 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:56:58 --> Form Validation Class Initialized
INFO - 2023-10-29 10:56:58 --> Upload Class Initialized
INFO - 2023-10-29 10:56:58 --> Model "M_auth" initialized
INFO - 2023-10-29 10:56:58 --> Model "M_user" initialized
INFO - 2023-10-29 10:56:58 --> Model "M_produk" initialized
INFO - 2023-10-29 10:56:58 --> Controller Class Initialized
ERROR - 2023-10-29 10:56:58 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:57:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:57:01 --> Config Class Initialized
INFO - 2023-10-29 10:57:01 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:57:01 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:57:01 --> Utf8 Class Initialized
INFO - 2023-10-29 10:57:01 --> URI Class Initialized
INFO - 2023-10-29 10:57:01 --> Router Class Initialized
INFO - 2023-10-29 10:57:01 --> Output Class Initialized
INFO - 2023-10-29 10:57:01 --> Security Class Initialized
DEBUG - 2023-10-29 10:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:57:01 --> Input Class Initialized
INFO - 2023-10-29 10:57:01 --> Language Class Initialized
INFO - 2023-10-29 10:57:01 --> Loader Class Initialized
INFO - 2023-10-29 10:57:01 --> Helper loaded: url_helper
INFO - 2023-10-29 10:57:01 --> Helper loaded: form_helper
INFO - 2023-10-29 10:57:01 --> Helper loaded: file_helper
INFO - 2023-10-29 10:57:01 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:57:01 --> Form Validation Class Initialized
INFO - 2023-10-29 10:57:01 --> Upload Class Initialized
INFO - 2023-10-29 10:57:01 --> Model "M_auth" initialized
INFO - 2023-10-29 10:57:01 --> Model "M_user" initialized
INFO - 2023-10-29 10:57:01 --> Model "M_produk" initialized
INFO - 2023-10-29 10:57:01 --> Controller Class Initialized
ERROR - 2023-10-29 10:57:01 --> Unable to load the requested class: Midtranss
ERROR - 2023-10-29 10:57:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:57:02 --> Config Class Initialized
INFO - 2023-10-29 10:57:02 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:57:02 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:57:02 --> Utf8 Class Initialized
INFO - 2023-10-29 10:57:02 --> URI Class Initialized
INFO - 2023-10-29 10:57:02 --> Router Class Initialized
INFO - 2023-10-29 10:57:02 --> Output Class Initialized
INFO - 2023-10-29 10:57:02 --> Security Class Initialized
DEBUG - 2023-10-29 10:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:57:02 --> Input Class Initialized
INFO - 2023-10-29 10:57:02 --> Language Class Initialized
INFO - 2023-10-29 10:57:02 --> Loader Class Initialized
INFO - 2023-10-29 10:57:02 --> Helper loaded: url_helper
INFO - 2023-10-29 10:57:02 --> Helper loaded: form_helper
INFO - 2023-10-29 10:57:02 --> Helper loaded: file_helper
INFO - 2023-10-29 10:57:02 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:57:02 --> Form Validation Class Initialized
INFO - 2023-10-29 10:57:02 --> Upload Class Initialized
INFO - 2023-10-29 10:57:02 --> Model "M_auth" initialized
INFO - 2023-10-29 10:57:02 --> Model "M_user" initialized
INFO - 2023-10-29 10:57:02 --> Model "M_produk" initialized
INFO - 2023-10-29 10:57:02 --> Controller Class Initialized
ERROR - 2023-10-29 10:57:02 --> Unable to load the requested class: Midtranss
ERROR - 2023-10-29 10:57:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:57:02 --> Config Class Initialized
INFO - 2023-10-29 10:57:02 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:57:02 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:57:02 --> Utf8 Class Initialized
INFO - 2023-10-29 10:57:02 --> URI Class Initialized
INFO - 2023-10-29 10:57:02 --> Router Class Initialized
INFO - 2023-10-29 10:57:02 --> Output Class Initialized
INFO - 2023-10-29 10:57:02 --> Security Class Initialized
DEBUG - 2023-10-29 10:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:57:02 --> Input Class Initialized
INFO - 2023-10-29 10:57:02 --> Language Class Initialized
INFO - 2023-10-29 10:57:02 --> Loader Class Initialized
INFO - 2023-10-29 10:57:02 --> Helper loaded: url_helper
INFO - 2023-10-29 10:57:02 --> Helper loaded: form_helper
INFO - 2023-10-29 10:57:02 --> Helper loaded: file_helper
INFO - 2023-10-29 10:57:02 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:57:02 --> Form Validation Class Initialized
INFO - 2023-10-29 10:57:02 --> Upload Class Initialized
INFO - 2023-10-29 10:57:02 --> Model "M_auth" initialized
INFO - 2023-10-29 10:57:02 --> Model "M_user" initialized
INFO - 2023-10-29 10:57:02 --> Model "M_produk" initialized
INFO - 2023-10-29 10:57:02 --> Controller Class Initialized
ERROR - 2023-10-29 10:57:02 --> Unable to load the requested class: Midtranss
ERROR - 2023-10-29 10:57:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:57:02 --> Config Class Initialized
INFO - 2023-10-29 10:57:02 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:57:02 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:57:02 --> Utf8 Class Initialized
INFO - 2023-10-29 10:57:02 --> URI Class Initialized
INFO - 2023-10-29 10:57:02 --> Router Class Initialized
INFO - 2023-10-29 10:57:02 --> Output Class Initialized
INFO - 2023-10-29 10:57:02 --> Security Class Initialized
DEBUG - 2023-10-29 10:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:57:02 --> Input Class Initialized
INFO - 2023-10-29 10:57:02 --> Language Class Initialized
INFO - 2023-10-29 10:57:02 --> Loader Class Initialized
INFO - 2023-10-29 10:57:02 --> Helper loaded: url_helper
INFO - 2023-10-29 10:57:02 --> Helper loaded: form_helper
INFO - 2023-10-29 10:57:02 --> Helper loaded: file_helper
INFO - 2023-10-29 10:57:02 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:57:02 --> Form Validation Class Initialized
INFO - 2023-10-29 10:57:02 --> Upload Class Initialized
INFO - 2023-10-29 10:57:02 --> Model "M_auth" initialized
INFO - 2023-10-29 10:57:02 --> Model "M_user" initialized
INFO - 2023-10-29 10:57:02 --> Model "M_produk" initialized
INFO - 2023-10-29 10:57:02 --> Controller Class Initialized
ERROR - 2023-10-29 10:57:02 --> Unable to load the requested class: Midtranss
ERROR - 2023-10-29 10:57:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:57:02 --> Config Class Initialized
INFO - 2023-10-29 10:57:02 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:57:02 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:57:02 --> Utf8 Class Initialized
INFO - 2023-10-29 10:57:02 --> URI Class Initialized
INFO - 2023-10-29 10:57:02 --> Router Class Initialized
INFO - 2023-10-29 10:57:02 --> Output Class Initialized
INFO - 2023-10-29 10:57:02 --> Security Class Initialized
DEBUG - 2023-10-29 10:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:57:02 --> Input Class Initialized
INFO - 2023-10-29 10:57:02 --> Language Class Initialized
INFO - 2023-10-29 10:57:02 --> Loader Class Initialized
INFO - 2023-10-29 10:57:02 --> Helper loaded: url_helper
INFO - 2023-10-29 10:57:02 --> Helper loaded: form_helper
INFO - 2023-10-29 10:57:02 --> Helper loaded: file_helper
INFO - 2023-10-29 10:57:02 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:57:02 --> Form Validation Class Initialized
INFO - 2023-10-29 10:57:02 --> Upload Class Initialized
INFO - 2023-10-29 10:57:02 --> Model "M_auth" initialized
INFO - 2023-10-29 10:57:02 --> Model "M_user" initialized
INFO - 2023-10-29 10:57:02 --> Model "M_produk" initialized
INFO - 2023-10-29 10:57:02 --> Controller Class Initialized
ERROR - 2023-10-29 10:57:02 --> Unable to load the requested class: Midtranss
ERROR - 2023-10-29 10:57:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:57:02 --> Config Class Initialized
INFO - 2023-10-29 10:57:02 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:57:02 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:57:02 --> Utf8 Class Initialized
INFO - 2023-10-29 10:57:02 --> URI Class Initialized
INFO - 2023-10-29 10:57:02 --> Router Class Initialized
INFO - 2023-10-29 10:57:02 --> Output Class Initialized
INFO - 2023-10-29 10:57:02 --> Security Class Initialized
DEBUG - 2023-10-29 10:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:57:02 --> Input Class Initialized
INFO - 2023-10-29 10:57:02 --> Language Class Initialized
INFO - 2023-10-29 10:57:02 --> Loader Class Initialized
INFO - 2023-10-29 10:57:02 --> Helper loaded: url_helper
INFO - 2023-10-29 10:57:02 --> Helper loaded: form_helper
INFO - 2023-10-29 10:57:02 --> Helper loaded: file_helper
INFO - 2023-10-29 10:57:02 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:57:02 --> Form Validation Class Initialized
INFO - 2023-10-29 10:57:02 --> Upload Class Initialized
INFO - 2023-10-29 10:57:02 --> Model "M_auth" initialized
INFO - 2023-10-29 10:57:02 --> Model "M_user" initialized
INFO - 2023-10-29 10:57:02 --> Model "M_produk" initialized
INFO - 2023-10-29 10:57:02 --> Controller Class Initialized
ERROR - 2023-10-29 10:57:02 --> Unable to load the requested class: Midtranss
ERROR - 2023-10-29 10:57:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:57:07 --> Config Class Initialized
INFO - 2023-10-29 10:57:07 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:57:07 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:57:07 --> Utf8 Class Initialized
INFO - 2023-10-29 10:57:07 --> URI Class Initialized
INFO - 2023-10-29 10:57:07 --> Router Class Initialized
INFO - 2023-10-29 10:57:07 --> Output Class Initialized
INFO - 2023-10-29 10:57:07 --> Security Class Initialized
DEBUG - 2023-10-29 10:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:57:07 --> Input Class Initialized
INFO - 2023-10-29 10:57:07 --> Language Class Initialized
INFO - 2023-10-29 10:57:07 --> Loader Class Initialized
INFO - 2023-10-29 10:57:07 --> Helper loaded: url_helper
INFO - 2023-10-29 10:57:07 --> Helper loaded: form_helper
INFO - 2023-10-29 10:57:07 --> Helper loaded: file_helper
INFO - 2023-10-29 10:57:07 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:57:07 --> Form Validation Class Initialized
INFO - 2023-10-29 10:57:07 --> Upload Class Initialized
INFO - 2023-10-29 10:57:07 --> Model "M_auth" initialized
INFO - 2023-10-29 10:57:07 --> Model "M_user" initialized
INFO - 2023-10-29 10:57:07 --> Model "M_produk" initialized
INFO - 2023-10-29 10:57:07 --> Controller Class Initialized
ERROR - 2023-10-29 10:57:07 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:57:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:57:07 --> Config Class Initialized
INFO - 2023-10-29 10:57:07 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:57:07 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:57:07 --> Utf8 Class Initialized
INFO - 2023-10-29 10:57:07 --> URI Class Initialized
INFO - 2023-10-29 10:57:07 --> Router Class Initialized
INFO - 2023-10-29 10:57:07 --> Output Class Initialized
INFO - 2023-10-29 10:57:07 --> Security Class Initialized
DEBUG - 2023-10-29 10:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:57:07 --> Input Class Initialized
INFO - 2023-10-29 10:57:07 --> Language Class Initialized
INFO - 2023-10-29 10:57:07 --> Loader Class Initialized
INFO - 2023-10-29 10:57:07 --> Helper loaded: url_helper
INFO - 2023-10-29 10:57:07 --> Helper loaded: form_helper
INFO - 2023-10-29 10:57:07 --> Helper loaded: file_helper
INFO - 2023-10-29 10:57:07 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:57:07 --> Form Validation Class Initialized
INFO - 2023-10-29 10:57:07 --> Upload Class Initialized
INFO - 2023-10-29 10:57:07 --> Model "M_auth" initialized
INFO - 2023-10-29 10:57:07 --> Model "M_user" initialized
INFO - 2023-10-29 10:57:07 --> Model "M_produk" initialized
INFO - 2023-10-29 10:57:07 --> Controller Class Initialized
ERROR - 2023-10-29 10:57:07 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:57:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:57:07 --> Config Class Initialized
INFO - 2023-10-29 10:57:07 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:57:07 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:57:07 --> Utf8 Class Initialized
INFO - 2023-10-29 10:57:07 --> URI Class Initialized
INFO - 2023-10-29 10:57:07 --> Router Class Initialized
INFO - 2023-10-29 10:57:08 --> Output Class Initialized
INFO - 2023-10-29 10:57:08 --> Security Class Initialized
DEBUG - 2023-10-29 10:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:57:08 --> Input Class Initialized
INFO - 2023-10-29 10:57:08 --> Language Class Initialized
INFO - 2023-10-29 10:57:08 --> Loader Class Initialized
INFO - 2023-10-29 10:57:08 --> Helper loaded: url_helper
INFO - 2023-10-29 10:57:08 --> Helper loaded: form_helper
INFO - 2023-10-29 10:57:08 --> Helper loaded: file_helper
INFO - 2023-10-29 10:57:08 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:57:08 --> Form Validation Class Initialized
INFO - 2023-10-29 10:57:08 --> Upload Class Initialized
INFO - 2023-10-29 10:57:08 --> Model "M_auth" initialized
INFO - 2023-10-29 10:57:08 --> Model "M_user" initialized
INFO - 2023-10-29 10:57:08 --> Model "M_produk" initialized
INFO - 2023-10-29 10:57:08 --> Controller Class Initialized
ERROR - 2023-10-29 10:57:08 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:57:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:57:08 --> Config Class Initialized
INFO - 2023-10-29 10:57:08 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:57:08 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:57:08 --> Utf8 Class Initialized
INFO - 2023-10-29 10:57:08 --> URI Class Initialized
INFO - 2023-10-29 10:57:08 --> Router Class Initialized
INFO - 2023-10-29 10:57:08 --> Output Class Initialized
INFO - 2023-10-29 10:57:08 --> Security Class Initialized
DEBUG - 2023-10-29 10:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:57:08 --> Input Class Initialized
INFO - 2023-10-29 10:57:08 --> Language Class Initialized
INFO - 2023-10-29 10:57:08 --> Loader Class Initialized
INFO - 2023-10-29 10:57:08 --> Helper loaded: url_helper
INFO - 2023-10-29 10:57:08 --> Helper loaded: form_helper
INFO - 2023-10-29 10:57:08 --> Helper loaded: file_helper
INFO - 2023-10-29 10:57:08 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:57:08 --> Form Validation Class Initialized
INFO - 2023-10-29 10:57:08 --> Upload Class Initialized
INFO - 2023-10-29 10:57:08 --> Model "M_auth" initialized
INFO - 2023-10-29 10:57:08 --> Model "M_user" initialized
INFO - 2023-10-29 10:57:08 --> Model "M_produk" initialized
INFO - 2023-10-29 10:57:08 --> Controller Class Initialized
ERROR - 2023-10-29 10:57:08 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 10:57:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 10:57:08 --> Config Class Initialized
INFO - 2023-10-29 10:57:08 --> Hooks Class Initialized
DEBUG - 2023-10-29 10:57:08 --> UTF-8 Support Enabled
INFO - 2023-10-29 10:57:08 --> Utf8 Class Initialized
INFO - 2023-10-29 10:57:08 --> URI Class Initialized
INFO - 2023-10-29 10:57:08 --> Router Class Initialized
INFO - 2023-10-29 10:57:08 --> Output Class Initialized
INFO - 2023-10-29 10:57:08 --> Security Class Initialized
DEBUG - 2023-10-29 10:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 10:57:08 --> Input Class Initialized
INFO - 2023-10-29 10:57:08 --> Language Class Initialized
INFO - 2023-10-29 10:57:08 --> Loader Class Initialized
INFO - 2023-10-29 10:57:08 --> Helper loaded: url_helper
INFO - 2023-10-29 10:57:08 --> Helper loaded: form_helper
INFO - 2023-10-29 10:57:08 --> Helper loaded: file_helper
INFO - 2023-10-29 10:57:08 --> Database Driver Class Initialized
DEBUG - 2023-10-29 10:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 10:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 10:57:08 --> Form Validation Class Initialized
INFO - 2023-10-29 10:57:08 --> Upload Class Initialized
INFO - 2023-10-29 10:57:08 --> Model "M_auth" initialized
INFO - 2023-10-29 10:57:08 --> Model "M_user" initialized
INFO - 2023-10-29 10:57:08 --> Model "M_produk" initialized
INFO - 2023-10-29 10:57:08 --> Controller Class Initialized
ERROR - 2023-10-29 10:57:08 --> Unable to load the requested class: Midtrans
ERROR - 2023-10-29 11:05:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:05:39 --> Config Class Initialized
INFO - 2023-10-29 11:05:39 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:05:39 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:05:39 --> Utf8 Class Initialized
INFO - 2023-10-29 11:05:39 --> URI Class Initialized
INFO - 2023-10-29 11:05:39 --> Router Class Initialized
INFO - 2023-10-29 11:05:39 --> Output Class Initialized
INFO - 2023-10-29 11:05:39 --> Security Class Initialized
DEBUG - 2023-10-29 11:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:05:39 --> Input Class Initialized
INFO - 2023-10-29 11:05:39 --> Language Class Initialized
INFO - 2023-10-29 11:05:39 --> Loader Class Initialized
INFO - 2023-10-29 11:05:39 --> Helper loaded: url_helper
INFO - 2023-10-29 11:05:39 --> Helper loaded: form_helper
INFO - 2023-10-29 11:05:39 --> Helper loaded: file_helper
INFO - 2023-10-29 11:05:39 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:05:39 --> Form Validation Class Initialized
INFO - 2023-10-29 11:05:39 --> Upload Class Initialized
INFO - 2023-10-29 11:05:39 --> Model "M_auth" initialized
INFO - 2023-10-29 11:05:39 --> Model "M_user" initialized
INFO - 2023-10-29 11:05:39 --> Model "M_produk" initialized
INFO - 2023-10-29 11:05:39 --> Controller Class Initialized
INFO - 2023-10-29 11:05:39 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:05:39 --> Final output sent to browser
DEBUG - 2023-10-29 11:05:39 --> Total execution time: 0.0969
ERROR - 2023-10-29 11:05:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:05:41 --> Config Class Initialized
INFO - 2023-10-29 11:05:41 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:05:41 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:05:41 --> Utf8 Class Initialized
INFO - 2023-10-29 11:05:41 --> URI Class Initialized
INFO - 2023-10-29 11:05:41 --> Router Class Initialized
INFO - 2023-10-29 11:05:41 --> Output Class Initialized
INFO - 2023-10-29 11:05:41 --> Security Class Initialized
DEBUG - 2023-10-29 11:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:05:41 --> Input Class Initialized
INFO - 2023-10-29 11:05:41 --> Language Class Initialized
INFO - 2023-10-29 11:05:41 --> Loader Class Initialized
INFO - 2023-10-29 11:05:41 --> Helper loaded: url_helper
INFO - 2023-10-29 11:05:41 --> Helper loaded: form_helper
INFO - 2023-10-29 11:05:41 --> Helper loaded: file_helper
INFO - 2023-10-29 11:05:41 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:05:41 --> Form Validation Class Initialized
INFO - 2023-10-29 11:05:41 --> Upload Class Initialized
INFO - 2023-10-29 11:05:41 --> Model "M_auth" initialized
INFO - 2023-10-29 11:05:41 --> Model "M_user" initialized
INFO - 2023-10-29 11:05:41 --> Model "M_produk" initialized
INFO - 2023-10-29 11:05:41 --> Controller Class Initialized
ERROR - 2023-10-29 11:05:41 --> Severity: error --> Exception: The ServerKey/ClientKey is null, You need to set the server-key from Config. Please double-check Config and ServerKey key. You can check from the Midtrans Dashboard. See https://docs.midtrans.com/en/midtrans-account/overview?id=retrieving-api-access-keys for the details or contact support at support@midtrans.com if you have any questions. C:\xampp\htdocs\4_aan\semakar_adventure\application\libraries\Mid\Midtrans\ApiRequestor.php 71
ERROR - 2023-10-29 11:07:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:07:13 --> Config Class Initialized
INFO - 2023-10-29 11:07:13 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:07:13 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:07:13 --> Utf8 Class Initialized
INFO - 2023-10-29 11:07:13 --> URI Class Initialized
INFO - 2023-10-29 11:07:13 --> Router Class Initialized
INFO - 2023-10-29 11:07:13 --> Output Class Initialized
INFO - 2023-10-29 11:07:13 --> Security Class Initialized
DEBUG - 2023-10-29 11:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:07:13 --> Input Class Initialized
INFO - 2023-10-29 11:07:13 --> Language Class Initialized
INFO - 2023-10-29 11:07:13 --> Loader Class Initialized
INFO - 2023-10-29 11:07:13 --> Helper loaded: url_helper
INFO - 2023-10-29 11:07:13 --> Helper loaded: form_helper
INFO - 2023-10-29 11:07:13 --> Helper loaded: file_helper
INFO - 2023-10-29 11:07:13 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:07:13 --> Form Validation Class Initialized
INFO - 2023-10-29 11:07:13 --> Upload Class Initialized
INFO - 2023-10-29 11:07:13 --> Model "M_auth" initialized
INFO - 2023-10-29 11:07:13 --> Model "M_user" initialized
INFO - 2023-10-29 11:07:13 --> Model "M_produk" initialized
INFO - 2023-10-29 11:07:13 --> Controller Class Initialized
ERROR - 2023-10-29 11:07:13 --> Severity: error --> Exception: The ServerKey/ClientKey is null, You need to set the server-key from Config. Please double-check Config and ServerKey key. You can check from the Midtrans Dashboard. See https://docs.midtrans.com/en/midtrans-account/overview?id=retrieving-api-access-keys for the details or contact support at support@midtrans.com if you have any questions. C:\xampp\htdocs\4_aan\semakar_adventure\application\libraries\Mid\Midtrans\ApiRequestor.php 71
ERROR - 2023-10-29 11:07:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:07:14 --> Config Class Initialized
INFO - 2023-10-29 11:07:14 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:07:14 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:07:14 --> Utf8 Class Initialized
INFO - 2023-10-29 11:07:14 --> URI Class Initialized
INFO - 2023-10-29 11:07:14 --> Router Class Initialized
INFO - 2023-10-29 11:07:14 --> Output Class Initialized
INFO - 2023-10-29 11:07:14 --> Security Class Initialized
DEBUG - 2023-10-29 11:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:07:14 --> Input Class Initialized
INFO - 2023-10-29 11:07:14 --> Language Class Initialized
INFO - 2023-10-29 11:07:14 --> Loader Class Initialized
INFO - 2023-10-29 11:07:14 --> Helper loaded: url_helper
INFO - 2023-10-29 11:07:14 --> Helper loaded: form_helper
INFO - 2023-10-29 11:07:14 --> Helper loaded: file_helper
INFO - 2023-10-29 11:07:14 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:07:14 --> Form Validation Class Initialized
INFO - 2023-10-29 11:07:14 --> Upload Class Initialized
INFO - 2023-10-29 11:07:14 --> Model "M_auth" initialized
INFO - 2023-10-29 11:07:14 --> Model "M_user" initialized
INFO - 2023-10-29 11:07:14 --> Model "M_produk" initialized
INFO - 2023-10-29 11:07:14 --> Controller Class Initialized
INFO - 2023-10-29 11:07:14 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:07:14 --> Final output sent to browser
DEBUG - 2023-10-29 11:07:14 --> Total execution time: 0.0766
ERROR - 2023-10-29 11:07:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:07:15 --> Config Class Initialized
INFO - 2023-10-29 11:07:15 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:07:15 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:07:15 --> Utf8 Class Initialized
INFO - 2023-10-29 11:07:15 --> URI Class Initialized
INFO - 2023-10-29 11:07:15 --> Router Class Initialized
INFO - 2023-10-29 11:07:15 --> Output Class Initialized
INFO - 2023-10-29 11:07:15 --> Security Class Initialized
DEBUG - 2023-10-29 11:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:07:15 --> Input Class Initialized
INFO - 2023-10-29 11:07:15 --> Language Class Initialized
INFO - 2023-10-29 11:07:15 --> Loader Class Initialized
INFO - 2023-10-29 11:07:15 --> Helper loaded: url_helper
INFO - 2023-10-29 11:07:15 --> Helper loaded: form_helper
INFO - 2023-10-29 11:07:15 --> Helper loaded: file_helper
INFO - 2023-10-29 11:07:15 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:07:15 --> Form Validation Class Initialized
INFO - 2023-10-29 11:07:15 --> Upload Class Initialized
INFO - 2023-10-29 11:07:15 --> Model "M_auth" initialized
INFO - 2023-10-29 11:07:15 --> Model "M_user" initialized
INFO - 2023-10-29 11:07:15 --> Model "M_produk" initialized
INFO - 2023-10-29 11:07:15 --> Controller Class Initialized
INFO - 2023-10-29 11:07:15 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:07:15 --> Final output sent to browser
DEBUG - 2023-10-29 11:07:15 --> Total execution time: 0.0687
ERROR - 2023-10-29 11:07:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:07:15 --> Config Class Initialized
INFO - 2023-10-29 11:07:15 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:07:15 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:07:15 --> Utf8 Class Initialized
INFO - 2023-10-29 11:07:15 --> URI Class Initialized
INFO - 2023-10-29 11:07:15 --> Router Class Initialized
INFO - 2023-10-29 11:07:15 --> Output Class Initialized
INFO - 2023-10-29 11:07:15 --> Security Class Initialized
DEBUG - 2023-10-29 11:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:07:15 --> Input Class Initialized
INFO - 2023-10-29 11:07:15 --> Language Class Initialized
INFO - 2023-10-29 11:07:15 --> Loader Class Initialized
INFO - 2023-10-29 11:07:15 --> Helper loaded: url_helper
INFO - 2023-10-29 11:07:15 --> Helper loaded: form_helper
INFO - 2023-10-29 11:07:15 --> Helper loaded: file_helper
INFO - 2023-10-29 11:07:15 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:07:15 --> Form Validation Class Initialized
INFO - 2023-10-29 11:07:15 --> Upload Class Initialized
INFO - 2023-10-29 11:07:15 --> Model "M_auth" initialized
INFO - 2023-10-29 11:07:15 --> Model "M_user" initialized
INFO - 2023-10-29 11:07:15 --> Model "M_produk" initialized
INFO - 2023-10-29 11:07:15 --> Controller Class Initialized
INFO - 2023-10-29 11:07:15 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:07:15 --> Final output sent to browser
DEBUG - 2023-10-29 11:07:15 --> Total execution time: 0.0925
ERROR - 2023-10-29 11:07:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:07:15 --> Config Class Initialized
INFO - 2023-10-29 11:07:15 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:07:15 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:07:15 --> Utf8 Class Initialized
INFO - 2023-10-29 11:07:15 --> URI Class Initialized
INFO - 2023-10-29 11:07:15 --> Router Class Initialized
INFO - 2023-10-29 11:07:15 --> Output Class Initialized
INFO - 2023-10-29 11:07:15 --> Security Class Initialized
DEBUG - 2023-10-29 11:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:07:15 --> Input Class Initialized
INFO - 2023-10-29 11:07:15 --> Language Class Initialized
INFO - 2023-10-29 11:07:15 --> Loader Class Initialized
INFO - 2023-10-29 11:07:15 --> Helper loaded: url_helper
INFO - 2023-10-29 11:07:15 --> Helper loaded: form_helper
INFO - 2023-10-29 11:07:15 --> Helper loaded: file_helper
INFO - 2023-10-29 11:07:15 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:07:15 --> Form Validation Class Initialized
INFO - 2023-10-29 11:07:15 --> Upload Class Initialized
INFO - 2023-10-29 11:07:15 --> Model "M_auth" initialized
INFO - 2023-10-29 11:07:15 --> Model "M_user" initialized
INFO - 2023-10-29 11:07:15 --> Model "M_produk" initialized
INFO - 2023-10-29 11:07:15 --> Controller Class Initialized
INFO - 2023-10-29 11:07:15 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:07:15 --> Final output sent to browser
DEBUG - 2023-10-29 11:07:15 --> Total execution time: 0.0498
ERROR - 2023-10-29 11:07:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:07:15 --> Config Class Initialized
INFO - 2023-10-29 11:07:15 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:07:15 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:07:15 --> Utf8 Class Initialized
INFO - 2023-10-29 11:07:15 --> URI Class Initialized
INFO - 2023-10-29 11:07:15 --> Router Class Initialized
INFO - 2023-10-29 11:07:15 --> Output Class Initialized
INFO - 2023-10-29 11:07:15 --> Security Class Initialized
DEBUG - 2023-10-29 11:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:07:15 --> Input Class Initialized
INFO - 2023-10-29 11:07:15 --> Language Class Initialized
INFO - 2023-10-29 11:07:15 --> Loader Class Initialized
INFO - 2023-10-29 11:07:15 --> Helper loaded: url_helper
INFO - 2023-10-29 11:07:15 --> Helper loaded: form_helper
INFO - 2023-10-29 11:07:15 --> Helper loaded: file_helper
INFO - 2023-10-29 11:07:15 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:07:16 --> Form Validation Class Initialized
INFO - 2023-10-29 11:07:16 --> Upload Class Initialized
INFO - 2023-10-29 11:07:16 --> Model "M_auth" initialized
INFO - 2023-10-29 11:07:16 --> Model "M_user" initialized
INFO - 2023-10-29 11:07:16 --> Model "M_produk" initialized
INFO - 2023-10-29 11:07:16 --> Controller Class Initialized
INFO - 2023-10-29 11:07:16 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:07:16 --> Final output sent to browser
DEBUG - 2023-10-29 11:07:16 --> Total execution time: 0.0567
ERROR - 2023-10-29 11:07:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:07:16 --> Config Class Initialized
INFO - 2023-10-29 11:07:16 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:07:16 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:07:16 --> Utf8 Class Initialized
INFO - 2023-10-29 11:07:16 --> URI Class Initialized
INFO - 2023-10-29 11:07:16 --> Router Class Initialized
INFO - 2023-10-29 11:07:16 --> Output Class Initialized
INFO - 2023-10-29 11:07:16 --> Security Class Initialized
DEBUG - 2023-10-29 11:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:07:16 --> Input Class Initialized
INFO - 2023-10-29 11:07:16 --> Language Class Initialized
INFO - 2023-10-29 11:07:16 --> Loader Class Initialized
INFO - 2023-10-29 11:07:16 --> Helper loaded: url_helper
INFO - 2023-10-29 11:07:16 --> Helper loaded: form_helper
INFO - 2023-10-29 11:07:16 --> Helper loaded: file_helper
INFO - 2023-10-29 11:07:16 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:07:16 --> Form Validation Class Initialized
INFO - 2023-10-29 11:07:16 --> Upload Class Initialized
INFO - 2023-10-29 11:07:16 --> Model "M_auth" initialized
INFO - 2023-10-29 11:07:16 --> Model "M_user" initialized
INFO - 2023-10-29 11:07:16 --> Model "M_produk" initialized
INFO - 2023-10-29 11:07:16 --> Controller Class Initialized
ERROR - 2023-10-29 11:07:16 --> Severity: error --> Exception: The ServerKey/ClientKey is null, You need to set the server-key from Config. Please double-check Config and ServerKey key. You can check from the Midtrans Dashboard. See https://docs.midtrans.com/en/midtrans-account/overview?id=retrieving-api-access-keys for the details or contact support at support@midtrans.com if you have any questions. C:\xampp\htdocs\4_aan\semakar_adventure\application\libraries\Mid\Midtrans\ApiRequestor.php 71
ERROR - 2023-10-29 11:08:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:08:10 --> Config Class Initialized
INFO - 2023-10-29 11:08:10 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:08:10 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:08:10 --> Utf8 Class Initialized
INFO - 2023-10-29 11:08:10 --> URI Class Initialized
INFO - 2023-10-29 11:08:10 --> Router Class Initialized
INFO - 2023-10-29 11:08:10 --> Output Class Initialized
INFO - 2023-10-29 11:08:10 --> Security Class Initialized
DEBUG - 2023-10-29 11:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:08:10 --> Input Class Initialized
INFO - 2023-10-29 11:08:10 --> Language Class Initialized
INFO - 2023-10-29 11:08:10 --> Loader Class Initialized
INFO - 2023-10-29 11:08:10 --> Helper loaded: url_helper
INFO - 2023-10-29 11:08:10 --> Helper loaded: form_helper
INFO - 2023-10-29 11:08:10 --> Helper loaded: file_helper
INFO - 2023-10-29 11:08:10 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:08:10 --> Form Validation Class Initialized
INFO - 2023-10-29 11:08:10 --> Upload Class Initialized
INFO - 2023-10-29 11:08:10 --> Model "M_auth" initialized
INFO - 2023-10-29 11:08:10 --> Model "M_user" initialized
INFO - 2023-10-29 11:08:10 --> Model "M_produk" initialized
INFO - 2023-10-29 11:08:10 --> Controller Class Initialized
DEBUG - 2023-10-29 11:08:10 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-29 11:08:10 --> Severity: error --> Exception: The ServerKey/ClientKey is null, You need to set the server-key from Config. Please double-check Config and ServerKey key. You can check from the Midtrans Dashboard. See https://docs.midtrans.com/en/midtrans-account/overview?id=retrieving-api-access-keys for the details or contact support at support@midtrans.com if you have any questions. C:\xampp\htdocs\4_aan\semakar_adventure\application\libraries\Mid\Midtrans\ApiRequestor.php 71
ERROR - 2023-10-29 11:08:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:08:11 --> Config Class Initialized
INFO - 2023-10-29 11:08:11 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:08:11 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:08:11 --> Utf8 Class Initialized
INFO - 2023-10-29 11:08:11 --> URI Class Initialized
INFO - 2023-10-29 11:08:11 --> Router Class Initialized
INFO - 2023-10-29 11:08:11 --> Output Class Initialized
INFO - 2023-10-29 11:08:11 --> Security Class Initialized
DEBUG - 2023-10-29 11:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:08:11 --> Input Class Initialized
INFO - 2023-10-29 11:08:11 --> Language Class Initialized
INFO - 2023-10-29 11:08:11 --> Loader Class Initialized
INFO - 2023-10-29 11:08:11 --> Helper loaded: url_helper
INFO - 2023-10-29 11:08:11 --> Helper loaded: form_helper
INFO - 2023-10-29 11:08:11 --> Helper loaded: file_helper
INFO - 2023-10-29 11:08:11 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:08:11 --> Form Validation Class Initialized
INFO - 2023-10-29 11:08:11 --> Upload Class Initialized
INFO - 2023-10-29 11:08:11 --> Model "M_auth" initialized
INFO - 2023-10-29 11:08:11 --> Model "M_user" initialized
INFO - 2023-10-29 11:08:11 --> Model "M_produk" initialized
INFO - 2023-10-29 11:08:11 --> Controller Class Initialized
DEBUG - 2023-10-29 11:08:11 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:08:11 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:08:11 --> Final output sent to browser
DEBUG - 2023-10-29 11:08:11 --> Total execution time: 0.0611
ERROR - 2023-10-29 11:08:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:08:12 --> Config Class Initialized
INFO - 2023-10-29 11:08:12 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:08:12 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:08:12 --> Utf8 Class Initialized
INFO - 2023-10-29 11:08:12 --> URI Class Initialized
INFO - 2023-10-29 11:08:12 --> Router Class Initialized
INFO - 2023-10-29 11:08:12 --> Output Class Initialized
INFO - 2023-10-29 11:08:12 --> Security Class Initialized
DEBUG - 2023-10-29 11:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:08:12 --> Input Class Initialized
INFO - 2023-10-29 11:08:12 --> Language Class Initialized
INFO - 2023-10-29 11:08:12 --> Loader Class Initialized
INFO - 2023-10-29 11:08:12 --> Helper loaded: url_helper
INFO - 2023-10-29 11:08:12 --> Helper loaded: form_helper
INFO - 2023-10-29 11:08:12 --> Helper loaded: file_helper
INFO - 2023-10-29 11:08:12 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:08:12 --> Form Validation Class Initialized
INFO - 2023-10-29 11:08:12 --> Upload Class Initialized
INFO - 2023-10-29 11:08:12 --> Model "M_auth" initialized
INFO - 2023-10-29 11:08:12 --> Model "M_user" initialized
INFO - 2023-10-29 11:08:12 --> Model "M_produk" initialized
INFO - 2023-10-29 11:08:12 --> Controller Class Initialized
DEBUG - 2023-10-29 11:08:12 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:08:12 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:08:12 --> Final output sent to browser
DEBUG - 2023-10-29 11:08:12 --> Total execution time: 0.0764
ERROR - 2023-10-29 11:08:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:08:12 --> Config Class Initialized
INFO - 2023-10-29 11:08:12 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:08:12 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:08:12 --> Utf8 Class Initialized
INFO - 2023-10-29 11:08:12 --> URI Class Initialized
INFO - 2023-10-29 11:08:12 --> Router Class Initialized
INFO - 2023-10-29 11:08:12 --> Output Class Initialized
INFO - 2023-10-29 11:08:12 --> Security Class Initialized
DEBUG - 2023-10-29 11:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:08:12 --> Input Class Initialized
INFO - 2023-10-29 11:08:12 --> Language Class Initialized
INFO - 2023-10-29 11:08:12 --> Loader Class Initialized
INFO - 2023-10-29 11:08:12 --> Helper loaded: url_helper
INFO - 2023-10-29 11:08:12 --> Helper loaded: form_helper
INFO - 2023-10-29 11:08:12 --> Helper loaded: file_helper
INFO - 2023-10-29 11:08:12 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:08:12 --> Form Validation Class Initialized
INFO - 2023-10-29 11:08:12 --> Upload Class Initialized
INFO - 2023-10-29 11:08:12 --> Model "M_auth" initialized
INFO - 2023-10-29 11:08:12 --> Model "M_user" initialized
INFO - 2023-10-29 11:08:12 --> Model "M_produk" initialized
INFO - 2023-10-29 11:08:12 --> Controller Class Initialized
DEBUG - 2023-10-29 11:08:12 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:08:12 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:08:12 --> Final output sent to browser
DEBUG - 2023-10-29 11:08:12 --> Total execution time: 0.0221
ERROR - 2023-10-29 11:08:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:08:12 --> Config Class Initialized
INFO - 2023-10-29 11:08:12 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:08:12 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:08:12 --> Utf8 Class Initialized
INFO - 2023-10-29 11:08:12 --> URI Class Initialized
INFO - 2023-10-29 11:08:12 --> Router Class Initialized
INFO - 2023-10-29 11:08:12 --> Output Class Initialized
INFO - 2023-10-29 11:08:12 --> Security Class Initialized
DEBUG - 2023-10-29 11:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:08:12 --> Input Class Initialized
INFO - 2023-10-29 11:08:12 --> Language Class Initialized
INFO - 2023-10-29 11:08:12 --> Loader Class Initialized
INFO - 2023-10-29 11:08:12 --> Helper loaded: url_helper
INFO - 2023-10-29 11:08:12 --> Helper loaded: form_helper
INFO - 2023-10-29 11:08:12 --> Helper loaded: file_helper
INFO - 2023-10-29 11:08:12 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:08:12 --> Form Validation Class Initialized
INFO - 2023-10-29 11:08:12 --> Upload Class Initialized
INFO - 2023-10-29 11:08:12 --> Model "M_auth" initialized
INFO - 2023-10-29 11:08:12 --> Model "M_user" initialized
INFO - 2023-10-29 11:08:12 --> Model "M_produk" initialized
INFO - 2023-10-29 11:08:12 --> Controller Class Initialized
DEBUG - 2023-10-29 11:08:12 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:08:12 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:08:12 --> Final output sent to browser
DEBUG - 2023-10-29 11:08:12 --> Total execution time: 0.0713
ERROR - 2023-10-29 11:08:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:08:12 --> Config Class Initialized
INFO - 2023-10-29 11:08:12 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:08:12 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:08:12 --> Utf8 Class Initialized
INFO - 2023-10-29 11:08:12 --> URI Class Initialized
INFO - 2023-10-29 11:08:12 --> Router Class Initialized
INFO - 2023-10-29 11:08:12 --> Output Class Initialized
INFO - 2023-10-29 11:08:12 --> Security Class Initialized
DEBUG - 2023-10-29 11:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:08:12 --> Input Class Initialized
INFO - 2023-10-29 11:08:12 --> Language Class Initialized
INFO - 2023-10-29 11:08:12 --> Loader Class Initialized
INFO - 2023-10-29 11:08:12 --> Helper loaded: url_helper
INFO - 2023-10-29 11:08:12 --> Helper loaded: form_helper
INFO - 2023-10-29 11:08:12 --> Helper loaded: file_helper
INFO - 2023-10-29 11:08:12 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:08:12 --> Form Validation Class Initialized
INFO - 2023-10-29 11:08:12 --> Upload Class Initialized
INFO - 2023-10-29 11:08:12 --> Model "M_auth" initialized
INFO - 2023-10-29 11:08:12 --> Model "M_user" initialized
INFO - 2023-10-29 11:08:12 --> Model "M_produk" initialized
INFO - 2023-10-29 11:08:12 --> Controller Class Initialized
DEBUG - 2023-10-29 11:08:12 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:08:12 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:08:12 --> Final output sent to browser
DEBUG - 2023-10-29 11:08:12 --> Total execution time: 0.0448
ERROR - 2023-10-29 11:08:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:08:12 --> Config Class Initialized
INFO - 2023-10-29 11:08:12 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:08:12 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:08:12 --> Utf8 Class Initialized
INFO - 2023-10-29 11:08:12 --> URI Class Initialized
INFO - 2023-10-29 11:08:12 --> Router Class Initialized
INFO - 2023-10-29 11:08:12 --> Output Class Initialized
INFO - 2023-10-29 11:08:12 --> Security Class Initialized
DEBUG - 2023-10-29 11:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:08:12 --> Input Class Initialized
INFO - 2023-10-29 11:08:12 --> Language Class Initialized
INFO - 2023-10-29 11:08:12 --> Loader Class Initialized
INFO - 2023-10-29 11:08:12 --> Helper loaded: url_helper
INFO - 2023-10-29 11:08:12 --> Helper loaded: form_helper
INFO - 2023-10-29 11:08:12 --> Helper loaded: file_helper
INFO - 2023-10-29 11:08:12 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:08:12 --> Form Validation Class Initialized
INFO - 2023-10-29 11:08:12 --> Upload Class Initialized
INFO - 2023-10-29 11:08:12 --> Model "M_auth" initialized
INFO - 2023-10-29 11:08:12 --> Model "M_user" initialized
INFO - 2023-10-29 11:08:12 --> Model "M_produk" initialized
INFO - 2023-10-29 11:08:12 --> Controller Class Initialized
DEBUG - 2023-10-29 11:08:12 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:08:12 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:08:12 --> Final output sent to browser
DEBUG - 2023-10-29 11:08:12 --> Total execution time: 0.0228
ERROR - 2023-10-29 11:08:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:08:13 --> Config Class Initialized
INFO - 2023-10-29 11:08:13 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:08:13 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:08:13 --> Utf8 Class Initialized
INFO - 2023-10-29 11:08:13 --> URI Class Initialized
INFO - 2023-10-29 11:08:13 --> Router Class Initialized
INFO - 2023-10-29 11:08:13 --> Output Class Initialized
INFO - 2023-10-29 11:08:13 --> Security Class Initialized
DEBUG - 2023-10-29 11:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:08:13 --> Input Class Initialized
INFO - 2023-10-29 11:08:13 --> Language Class Initialized
INFO - 2023-10-29 11:08:13 --> Loader Class Initialized
INFO - 2023-10-29 11:08:13 --> Helper loaded: url_helper
INFO - 2023-10-29 11:08:13 --> Helper loaded: form_helper
INFO - 2023-10-29 11:08:13 --> Helper loaded: file_helper
INFO - 2023-10-29 11:08:13 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:08:13 --> Form Validation Class Initialized
INFO - 2023-10-29 11:08:13 --> Upload Class Initialized
INFO - 2023-10-29 11:08:13 --> Model "M_auth" initialized
INFO - 2023-10-29 11:08:13 --> Model "M_user" initialized
INFO - 2023-10-29 11:08:13 --> Model "M_produk" initialized
INFO - 2023-10-29 11:08:13 --> Controller Class Initialized
DEBUG - 2023-10-29 11:08:13 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-29 11:08:13 --> Severity: error --> Exception: The ServerKey/ClientKey is null, You need to set the server-key from Config. Please double-check Config and ServerKey key. You can check from the Midtrans Dashboard. See https://docs.midtrans.com/en/midtrans-account/overview?id=retrieving-api-access-keys for the details or contact support at support@midtrans.com if you have any questions. C:\xampp\htdocs\4_aan\semakar_adventure\application\libraries\Mid\Midtrans\ApiRequestor.php 71
ERROR - 2023-10-29 11:08:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:08:52 --> Config Class Initialized
INFO - 2023-10-29 11:08:52 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:08:52 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:08:52 --> Utf8 Class Initialized
INFO - 2023-10-29 11:08:52 --> URI Class Initialized
INFO - 2023-10-29 11:08:52 --> Router Class Initialized
INFO - 2023-10-29 11:08:52 --> Output Class Initialized
INFO - 2023-10-29 11:08:52 --> Security Class Initialized
DEBUG - 2023-10-29 11:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:08:52 --> Input Class Initialized
INFO - 2023-10-29 11:08:52 --> Language Class Initialized
INFO - 2023-10-29 11:08:52 --> Loader Class Initialized
INFO - 2023-10-29 11:08:52 --> Helper loaded: url_helper
INFO - 2023-10-29 11:08:52 --> Helper loaded: form_helper
INFO - 2023-10-29 11:08:52 --> Helper loaded: file_helper
INFO - 2023-10-29 11:08:52 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:08:52 --> Form Validation Class Initialized
INFO - 2023-10-29 11:08:52 --> Upload Class Initialized
INFO - 2023-10-29 11:08:52 --> Model "M_auth" initialized
INFO - 2023-10-29 11:08:52 --> Model "M_user" initialized
INFO - 2023-10-29 11:08:52 --> Model "M_produk" initialized
INFO - 2023-10-29 11:08:52 --> Controller Class Initialized
DEBUG - 2023-10-29 11:08:52 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:08:52 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:08:52 --> Final output sent to browser
DEBUG - 2023-10-29 11:08:52 --> Total execution time: 0.0637
ERROR - 2023-10-29 11:08:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:08:52 --> Config Class Initialized
INFO - 2023-10-29 11:08:52 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:08:52 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:08:52 --> Utf8 Class Initialized
INFO - 2023-10-29 11:08:52 --> URI Class Initialized
INFO - 2023-10-29 11:08:52 --> Router Class Initialized
INFO - 2023-10-29 11:08:52 --> Output Class Initialized
INFO - 2023-10-29 11:08:52 --> Security Class Initialized
DEBUG - 2023-10-29 11:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:08:52 --> Input Class Initialized
INFO - 2023-10-29 11:08:52 --> Language Class Initialized
INFO - 2023-10-29 11:08:52 --> Loader Class Initialized
INFO - 2023-10-29 11:08:52 --> Helper loaded: url_helper
INFO - 2023-10-29 11:08:52 --> Helper loaded: form_helper
INFO - 2023-10-29 11:08:52 --> Helper loaded: file_helper
INFO - 2023-10-29 11:08:52 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:08:52 --> Form Validation Class Initialized
INFO - 2023-10-29 11:08:52 --> Upload Class Initialized
INFO - 2023-10-29 11:08:52 --> Model "M_auth" initialized
INFO - 2023-10-29 11:08:52 --> Model "M_user" initialized
INFO - 2023-10-29 11:08:52 --> Model "M_produk" initialized
INFO - 2023-10-29 11:08:52 --> Controller Class Initialized
DEBUG - 2023-10-29 11:08:52 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:08:52 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:08:52 --> Final output sent to browser
DEBUG - 2023-10-29 11:08:52 --> Total execution time: 0.0614
ERROR - 2023-10-29 11:08:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:08:52 --> Config Class Initialized
INFO - 2023-10-29 11:08:52 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:08:52 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:08:52 --> Utf8 Class Initialized
INFO - 2023-10-29 11:08:52 --> URI Class Initialized
INFO - 2023-10-29 11:08:52 --> Router Class Initialized
INFO - 2023-10-29 11:08:52 --> Output Class Initialized
INFO - 2023-10-29 11:08:52 --> Security Class Initialized
DEBUG - 2023-10-29 11:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:08:52 --> Input Class Initialized
INFO - 2023-10-29 11:08:52 --> Language Class Initialized
INFO - 2023-10-29 11:08:52 --> Loader Class Initialized
INFO - 2023-10-29 11:08:52 --> Helper loaded: url_helper
INFO - 2023-10-29 11:08:52 --> Helper loaded: form_helper
INFO - 2023-10-29 11:08:52 --> Helper loaded: file_helper
INFO - 2023-10-29 11:08:52 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:08:52 --> Form Validation Class Initialized
INFO - 2023-10-29 11:08:52 --> Upload Class Initialized
INFO - 2023-10-29 11:08:52 --> Model "M_auth" initialized
INFO - 2023-10-29 11:08:52 --> Model "M_user" initialized
INFO - 2023-10-29 11:08:52 --> Model "M_produk" initialized
INFO - 2023-10-29 11:08:52 --> Controller Class Initialized
DEBUG - 2023-10-29 11:08:52 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:08:52 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:08:52 --> Final output sent to browser
DEBUG - 2023-10-29 11:08:52 --> Total execution time: 0.0289
ERROR - 2023-10-29 11:08:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:08:53 --> Config Class Initialized
INFO - 2023-10-29 11:08:53 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:08:53 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:08:53 --> Utf8 Class Initialized
INFO - 2023-10-29 11:08:53 --> URI Class Initialized
INFO - 2023-10-29 11:08:53 --> Router Class Initialized
INFO - 2023-10-29 11:08:53 --> Output Class Initialized
INFO - 2023-10-29 11:08:53 --> Security Class Initialized
DEBUG - 2023-10-29 11:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:08:53 --> Input Class Initialized
INFO - 2023-10-29 11:08:53 --> Language Class Initialized
INFO - 2023-10-29 11:08:53 --> Loader Class Initialized
INFO - 2023-10-29 11:08:53 --> Helper loaded: url_helper
INFO - 2023-10-29 11:08:53 --> Helper loaded: form_helper
INFO - 2023-10-29 11:08:53 --> Helper loaded: file_helper
INFO - 2023-10-29 11:08:53 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:08:53 --> Form Validation Class Initialized
INFO - 2023-10-29 11:08:53 --> Upload Class Initialized
INFO - 2023-10-29 11:08:53 --> Model "M_auth" initialized
INFO - 2023-10-29 11:08:53 --> Model "M_user" initialized
INFO - 2023-10-29 11:08:53 --> Model "M_produk" initialized
INFO - 2023-10-29 11:08:53 --> Controller Class Initialized
DEBUG - 2023-10-29 11:08:53 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:08:53 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:08:53 --> Final output sent to browser
DEBUG - 2023-10-29 11:08:53 --> Total execution time: 0.0701
ERROR - 2023-10-29 11:08:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:08:53 --> Config Class Initialized
INFO - 2023-10-29 11:08:53 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:08:53 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:08:53 --> Utf8 Class Initialized
INFO - 2023-10-29 11:08:53 --> URI Class Initialized
INFO - 2023-10-29 11:08:53 --> Router Class Initialized
INFO - 2023-10-29 11:08:53 --> Output Class Initialized
INFO - 2023-10-29 11:08:53 --> Security Class Initialized
DEBUG - 2023-10-29 11:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:08:53 --> Input Class Initialized
INFO - 2023-10-29 11:08:53 --> Language Class Initialized
INFO - 2023-10-29 11:08:53 --> Loader Class Initialized
INFO - 2023-10-29 11:08:53 --> Helper loaded: url_helper
INFO - 2023-10-29 11:08:53 --> Helper loaded: form_helper
INFO - 2023-10-29 11:08:53 --> Helper loaded: file_helper
INFO - 2023-10-29 11:08:53 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:08:53 --> Form Validation Class Initialized
INFO - 2023-10-29 11:08:53 --> Upload Class Initialized
INFO - 2023-10-29 11:08:53 --> Model "M_auth" initialized
INFO - 2023-10-29 11:08:53 --> Model "M_user" initialized
INFO - 2023-10-29 11:08:53 --> Model "M_produk" initialized
INFO - 2023-10-29 11:08:53 --> Controller Class Initialized
DEBUG - 2023-10-29 11:08:53 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:08:53 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:08:53 --> Final output sent to browser
DEBUG - 2023-10-29 11:08:53 --> Total execution time: 0.0423
ERROR - 2023-10-29 11:08:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:08:53 --> Config Class Initialized
INFO - 2023-10-29 11:08:53 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:08:53 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:08:53 --> Utf8 Class Initialized
INFO - 2023-10-29 11:08:53 --> URI Class Initialized
INFO - 2023-10-29 11:08:53 --> Router Class Initialized
INFO - 2023-10-29 11:08:53 --> Output Class Initialized
INFO - 2023-10-29 11:08:53 --> Security Class Initialized
DEBUG - 2023-10-29 11:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:08:53 --> Input Class Initialized
INFO - 2023-10-29 11:08:53 --> Language Class Initialized
INFO - 2023-10-29 11:08:53 --> Loader Class Initialized
INFO - 2023-10-29 11:08:53 --> Helper loaded: url_helper
INFO - 2023-10-29 11:08:53 --> Helper loaded: form_helper
INFO - 2023-10-29 11:08:53 --> Helper loaded: file_helper
INFO - 2023-10-29 11:08:53 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:08:53 --> Form Validation Class Initialized
INFO - 2023-10-29 11:08:53 --> Upload Class Initialized
INFO - 2023-10-29 11:08:53 --> Model "M_auth" initialized
INFO - 2023-10-29 11:08:53 --> Model "M_user" initialized
INFO - 2023-10-29 11:08:53 --> Model "M_produk" initialized
INFO - 2023-10-29 11:08:53 --> Controller Class Initialized
DEBUG - 2023-10-29 11:08:53 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:08:53 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:08:53 --> Final output sent to browser
DEBUG - 2023-10-29 11:08:53 --> Total execution time: 0.0396
ERROR - 2023-10-29 11:08:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:08:53 --> Config Class Initialized
INFO - 2023-10-29 11:08:53 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:08:53 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:08:53 --> Utf8 Class Initialized
INFO - 2023-10-29 11:08:53 --> URI Class Initialized
INFO - 2023-10-29 11:08:53 --> Router Class Initialized
INFO - 2023-10-29 11:08:53 --> Output Class Initialized
INFO - 2023-10-29 11:08:53 --> Security Class Initialized
DEBUG - 2023-10-29 11:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:08:53 --> Input Class Initialized
INFO - 2023-10-29 11:08:53 --> Language Class Initialized
INFO - 2023-10-29 11:08:53 --> Loader Class Initialized
INFO - 2023-10-29 11:08:54 --> Helper loaded: url_helper
INFO - 2023-10-29 11:08:54 --> Helper loaded: form_helper
INFO - 2023-10-29 11:08:54 --> Helper loaded: file_helper
INFO - 2023-10-29 11:08:54 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:08:54 --> Form Validation Class Initialized
INFO - 2023-10-29 11:08:54 --> Upload Class Initialized
INFO - 2023-10-29 11:08:54 --> Model "M_auth" initialized
INFO - 2023-10-29 11:08:54 --> Model "M_user" initialized
INFO - 2023-10-29 11:08:54 --> Model "M_produk" initialized
INFO - 2023-10-29 11:08:54 --> Controller Class Initialized
DEBUG - 2023-10-29 11:08:54 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:08:55 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 11:08:55 --> Final output sent to browser
DEBUG - 2023-10-29 11:08:55 --> Total execution time: 1.1642
ERROR - 2023-10-29 11:09:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:09:03 --> Config Class Initialized
INFO - 2023-10-29 11:09:03 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:09:03 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:09:03 --> Utf8 Class Initialized
INFO - 2023-10-29 11:09:03 --> URI Class Initialized
INFO - 2023-10-29 11:09:03 --> Router Class Initialized
INFO - 2023-10-29 11:09:03 --> Output Class Initialized
INFO - 2023-10-29 11:09:03 --> Security Class Initialized
DEBUG - 2023-10-29 11:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:09:03 --> Input Class Initialized
INFO - 2023-10-29 11:09:03 --> Language Class Initialized
INFO - 2023-10-29 11:09:03 --> Loader Class Initialized
INFO - 2023-10-29 11:09:03 --> Helper loaded: url_helper
INFO - 2023-10-29 11:09:03 --> Helper loaded: form_helper
INFO - 2023-10-29 11:09:03 --> Helper loaded: file_helper
INFO - 2023-10-29 11:09:03 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:09:03 --> Form Validation Class Initialized
INFO - 2023-10-29 11:09:03 --> Upload Class Initialized
INFO - 2023-10-29 11:09:03 --> Model "M_auth" initialized
INFO - 2023-10-29 11:09:03 --> Model "M_user" initialized
INFO - 2023-10-29 11:09:03 --> Model "M_produk" initialized
INFO - 2023-10-29 11:09:03 --> Controller Class Initialized
DEBUG - 2023-10-29 11:09:03 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:09:04 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 11:09:04 --> Final output sent to browser
DEBUG - 2023-10-29 11:09:04 --> Total execution time: 0.9849
ERROR - 2023-10-29 11:09:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:09:39 --> Config Class Initialized
INFO - 2023-10-29 11:09:39 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:09:39 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:09:39 --> Utf8 Class Initialized
INFO - 2023-10-29 11:09:39 --> URI Class Initialized
INFO - 2023-10-29 11:09:39 --> Router Class Initialized
INFO - 2023-10-29 11:09:39 --> Output Class Initialized
INFO - 2023-10-29 11:09:39 --> Security Class Initialized
DEBUG - 2023-10-29 11:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:09:39 --> Input Class Initialized
INFO - 2023-10-29 11:09:39 --> Language Class Initialized
INFO - 2023-10-29 11:09:39 --> Loader Class Initialized
INFO - 2023-10-29 11:09:39 --> Helper loaded: url_helper
INFO - 2023-10-29 11:09:39 --> Helper loaded: form_helper
INFO - 2023-10-29 11:09:39 --> Helper loaded: file_helper
INFO - 2023-10-29 11:09:39 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:09:39 --> Form Validation Class Initialized
INFO - 2023-10-29 11:09:39 --> Upload Class Initialized
INFO - 2023-10-29 11:09:39 --> Model "M_auth" initialized
INFO - 2023-10-29 11:09:39 --> Model "M_user" initialized
INFO - 2023-10-29 11:09:39 --> Model "M_produk" initialized
INFO - 2023-10-29 11:09:39 --> Controller Class Initialized
DEBUG - 2023-10-29 11:09:39 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:09:39 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:09:39 --> Final output sent to browser
DEBUG - 2023-10-29 11:09:39 --> Total execution time: 0.0551
ERROR - 2023-10-29 11:10:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:10:59 --> Config Class Initialized
INFO - 2023-10-29 11:10:59 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:10:59 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:10:59 --> Utf8 Class Initialized
INFO - 2023-10-29 11:10:59 --> URI Class Initialized
INFO - 2023-10-29 11:10:59 --> Router Class Initialized
INFO - 2023-10-29 11:10:59 --> Output Class Initialized
INFO - 2023-10-29 11:10:59 --> Security Class Initialized
DEBUG - 2023-10-29 11:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:10:59 --> Input Class Initialized
INFO - 2023-10-29 11:10:59 --> Language Class Initialized
INFO - 2023-10-29 11:10:59 --> Loader Class Initialized
INFO - 2023-10-29 11:10:59 --> Helper loaded: url_helper
INFO - 2023-10-29 11:10:59 --> Helper loaded: form_helper
INFO - 2023-10-29 11:10:59 --> Helper loaded: file_helper
INFO - 2023-10-29 11:10:59 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:10:59 --> Form Validation Class Initialized
INFO - 2023-10-29 11:10:59 --> Upload Class Initialized
INFO - 2023-10-29 11:10:59 --> Model "M_auth" initialized
INFO - 2023-10-29 11:10:59 --> Model "M_user" initialized
INFO - 2023-10-29 11:10:59 --> Model "M_produk" initialized
INFO - 2023-10-29 11:10:59 --> Controller Class Initialized
DEBUG - 2023-10-29 11:10:59 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-29 11:10:59 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php 11
INFO - 2023-10-29 11:10:59 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:10:59 --> Final output sent to browser
DEBUG - 2023-10-29 11:10:59 --> Total execution time: 0.0663
ERROR - 2023-10-29 11:11:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:11:09 --> Config Class Initialized
INFO - 2023-10-29 11:11:09 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:11:09 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:11:09 --> Utf8 Class Initialized
INFO - 2023-10-29 11:11:09 --> URI Class Initialized
INFO - 2023-10-29 11:11:09 --> Router Class Initialized
INFO - 2023-10-29 11:11:09 --> Output Class Initialized
INFO - 2023-10-29 11:11:09 --> Security Class Initialized
DEBUG - 2023-10-29 11:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:11:09 --> Input Class Initialized
INFO - 2023-10-29 11:11:09 --> Language Class Initialized
INFO - 2023-10-29 11:11:09 --> Loader Class Initialized
INFO - 2023-10-29 11:11:09 --> Helper loaded: url_helper
INFO - 2023-10-29 11:11:09 --> Helper loaded: form_helper
INFO - 2023-10-29 11:11:09 --> Helper loaded: file_helper
INFO - 2023-10-29 11:11:09 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:11:09 --> Form Validation Class Initialized
INFO - 2023-10-29 11:11:09 --> Upload Class Initialized
INFO - 2023-10-29 11:11:09 --> Model "M_auth" initialized
INFO - 2023-10-29 11:11:09 --> Model "M_user" initialized
INFO - 2023-10-29 11:11:09 --> Model "M_produk" initialized
INFO - 2023-10-29 11:11:09 --> Controller Class Initialized
DEBUG - 2023-10-29 11:11:09 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:11:09 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:11:09 --> Final output sent to browser
DEBUG - 2023-10-29 11:11:09 --> Total execution time: 0.0733
ERROR - 2023-10-29 11:11:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:11:10 --> Config Class Initialized
INFO - 2023-10-29 11:11:10 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:11:10 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:11:10 --> Utf8 Class Initialized
INFO - 2023-10-29 11:11:10 --> URI Class Initialized
INFO - 2023-10-29 11:11:10 --> Router Class Initialized
INFO - 2023-10-29 11:11:10 --> Output Class Initialized
INFO - 2023-10-29 11:11:10 --> Security Class Initialized
DEBUG - 2023-10-29 11:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:11:10 --> Input Class Initialized
INFO - 2023-10-29 11:11:10 --> Language Class Initialized
INFO - 2023-10-29 11:11:10 --> Loader Class Initialized
INFO - 2023-10-29 11:11:10 --> Helper loaded: url_helper
INFO - 2023-10-29 11:11:10 --> Helper loaded: form_helper
INFO - 2023-10-29 11:11:10 --> Helper loaded: file_helper
INFO - 2023-10-29 11:11:10 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:11:10 --> Form Validation Class Initialized
INFO - 2023-10-29 11:11:10 --> Upload Class Initialized
INFO - 2023-10-29 11:11:10 --> Model "M_auth" initialized
INFO - 2023-10-29 11:11:10 --> Model "M_user" initialized
INFO - 2023-10-29 11:11:10 --> Model "M_produk" initialized
INFO - 2023-10-29 11:11:10 --> Controller Class Initialized
DEBUG - 2023-10-29 11:11:10 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:11:10 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 11:11:10 --> Final output sent to browser
DEBUG - 2023-10-29 11:11:10 --> Total execution time: 0.4196
ERROR - 2023-10-29 11:11:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:11:18 --> Config Class Initialized
INFO - 2023-10-29 11:11:18 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:11:18 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:11:18 --> Utf8 Class Initialized
INFO - 2023-10-29 11:11:18 --> URI Class Initialized
INFO - 2023-10-29 11:11:18 --> Router Class Initialized
INFO - 2023-10-29 11:11:18 --> Output Class Initialized
INFO - 2023-10-29 11:11:18 --> Security Class Initialized
DEBUG - 2023-10-29 11:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:11:18 --> Input Class Initialized
INFO - 2023-10-29 11:11:18 --> Language Class Initialized
INFO - 2023-10-29 11:11:18 --> Loader Class Initialized
INFO - 2023-10-29 11:11:18 --> Helper loaded: url_helper
INFO - 2023-10-29 11:11:18 --> Helper loaded: form_helper
INFO - 2023-10-29 11:11:18 --> Helper loaded: file_helper
INFO - 2023-10-29 11:11:18 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:11:18 --> Form Validation Class Initialized
INFO - 2023-10-29 11:11:18 --> Upload Class Initialized
INFO - 2023-10-29 11:11:18 --> Model "M_auth" initialized
INFO - 2023-10-29 11:11:18 --> Model "M_user" initialized
INFO - 2023-10-29 11:11:18 --> Model "M_produk" initialized
INFO - 2023-10-29 11:11:18 --> Controller Class Initialized
DEBUG - 2023-10-29 11:11:18 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:11:18 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:11:18 --> Final output sent to browser
DEBUG - 2023-10-29 11:11:18 --> Total execution time: 0.0843
ERROR - 2023-10-29 11:11:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:11:20 --> Config Class Initialized
INFO - 2023-10-29 11:11:20 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:11:20 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:11:20 --> Utf8 Class Initialized
INFO - 2023-10-29 11:11:20 --> URI Class Initialized
INFO - 2023-10-29 11:11:20 --> Router Class Initialized
INFO - 2023-10-29 11:11:20 --> Output Class Initialized
INFO - 2023-10-29 11:11:20 --> Security Class Initialized
DEBUG - 2023-10-29 11:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:11:20 --> Input Class Initialized
INFO - 2023-10-29 11:11:20 --> Language Class Initialized
INFO - 2023-10-29 11:11:20 --> Loader Class Initialized
INFO - 2023-10-29 11:11:20 --> Helper loaded: url_helper
INFO - 2023-10-29 11:11:20 --> Helper loaded: form_helper
INFO - 2023-10-29 11:11:20 --> Helper loaded: file_helper
INFO - 2023-10-29 11:11:20 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:11:20 --> Form Validation Class Initialized
INFO - 2023-10-29 11:11:20 --> Upload Class Initialized
INFO - 2023-10-29 11:11:20 --> Model "M_auth" initialized
INFO - 2023-10-29 11:11:20 --> Model "M_user" initialized
INFO - 2023-10-29 11:11:20 --> Model "M_produk" initialized
INFO - 2023-10-29 11:11:20 --> Controller Class Initialized
DEBUG - 2023-10-29 11:11:20 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:11:20 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:11:20 --> Final output sent to browser
DEBUG - 2023-10-29 11:11:20 --> Total execution time: 0.0270
ERROR - 2023-10-29 11:11:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:11:23 --> Config Class Initialized
INFO - 2023-10-29 11:11:23 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:11:23 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:11:23 --> Utf8 Class Initialized
INFO - 2023-10-29 11:11:23 --> URI Class Initialized
INFO - 2023-10-29 11:11:23 --> Router Class Initialized
INFO - 2023-10-29 11:11:23 --> Output Class Initialized
INFO - 2023-10-29 11:11:23 --> Security Class Initialized
DEBUG - 2023-10-29 11:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:11:23 --> Input Class Initialized
INFO - 2023-10-29 11:11:23 --> Language Class Initialized
INFO - 2023-10-29 11:11:23 --> Loader Class Initialized
INFO - 2023-10-29 11:11:23 --> Helper loaded: url_helper
INFO - 2023-10-29 11:11:23 --> Helper loaded: form_helper
INFO - 2023-10-29 11:11:23 --> Helper loaded: file_helper
INFO - 2023-10-29 11:11:23 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:11:24 --> Form Validation Class Initialized
INFO - 2023-10-29 11:11:24 --> Upload Class Initialized
INFO - 2023-10-29 11:11:24 --> Model "M_auth" initialized
INFO - 2023-10-29 11:11:24 --> Model "M_user" initialized
INFO - 2023-10-29 11:11:24 --> Model "M_produk" initialized
INFO - 2023-10-29 11:11:24 --> Controller Class Initialized
DEBUG - 2023-10-29 11:11:24 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:11:24 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 11:11:24 --> Final output sent to browser
DEBUG - 2023-10-29 11:11:24 --> Total execution time: 0.4663
ERROR - 2023-10-29 11:11:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:11:46 --> Config Class Initialized
INFO - 2023-10-29 11:11:46 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:11:46 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:11:46 --> Utf8 Class Initialized
INFO - 2023-10-29 11:11:46 --> URI Class Initialized
INFO - 2023-10-29 11:11:46 --> Router Class Initialized
INFO - 2023-10-29 11:11:46 --> Output Class Initialized
INFO - 2023-10-29 11:11:46 --> Security Class Initialized
DEBUG - 2023-10-29 11:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:11:46 --> Input Class Initialized
INFO - 2023-10-29 11:11:46 --> Language Class Initialized
INFO - 2023-10-29 11:11:46 --> Loader Class Initialized
INFO - 2023-10-29 11:11:46 --> Helper loaded: url_helper
INFO - 2023-10-29 11:11:46 --> Helper loaded: form_helper
INFO - 2023-10-29 11:11:46 --> Helper loaded: file_helper
INFO - 2023-10-29 11:11:46 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:11:46 --> Form Validation Class Initialized
INFO - 2023-10-29 11:11:46 --> Upload Class Initialized
INFO - 2023-10-29 11:11:46 --> Model "M_auth" initialized
INFO - 2023-10-29 11:11:46 --> Model "M_user" initialized
INFO - 2023-10-29 11:11:46 --> Model "M_produk" initialized
INFO - 2023-10-29 11:11:46 --> Controller Class Initialized
DEBUG - 2023-10-29 11:11:46 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:11:46 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:11:46 --> Final output sent to browser
DEBUG - 2023-10-29 11:11:46 --> Total execution time: 0.0686
ERROR - 2023-10-29 11:13:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:13:58 --> Config Class Initialized
INFO - 2023-10-29 11:13:58 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:13:58 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:13:58 --> Utf8 Class Initialized
INFO - 2023-10-29 11:13:58 --> URI Class Initialized
INFO - 2023-10-29 11:13:58 --> Router Class Initialized
INFO - 2023-10-29 11:13:58 --> Output Class Initialized
INFO - 2023-10-29 11:13:58 --> Security Class Initialized
DEBUG - 2023-10-29 11:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:13:58 --> Input Class Initialized
INFO - 2023-10-29 11:13:58 --> Language Class Initialized
INFO - 2023-10-29 11:13:58 --> Loader Class Initialized
INFO - 2023-10-29 11:13:58 --> Helper loaded: url_helper
INFO - 2023-10-29 11:13:58 --> Helper loaded: form_helper
INFO - 2023-10-29 11:13:58 --> Helper loaded: file_helper
INFO - 2023-10-29 11:13:58 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:13:58 --> Form Validation Class Initialized
INFO - 2023-10-29 11:13:58 --> Upload Class Initialized
INFO - 2023-10-29 11:13:58 --> Model "M_auth" initialized
INFO - 2023-10-29 11:13:58 --> Model "M_user" initialized
INFO - 2023-10-29 11:13:58 --> Model "M_produk" initialized
INFO - 2023-10-29 11:13:58 --> Controller Class Initialized
DEBUG - 2023-10-29 11:13:58 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:13:58 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:13:58 --> Final output sent to browser
DEBUG - 2023-10-29 11:13:58 --> Total execution time: 0.0969
ERROR - 2023-10-29 11:14:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:14:04 --> Config Class Initialized
INFO - 2023-10-29 11:14:04 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:14:04 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:14:04 --> Utf8 Class Initialized
INFO - 2023-10-29 11:14:04 --> URI Class Initialized
INFO - 2023-10-29 11:14:04 --> Router Class Initialized
INFO - 2023-10-29 11:14:04 --> Output Class Initialized
INFO - 2023-10-29 11:14:04 --> Security Class Initialized
DEBUG - 2023-10-29 11:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:14:04 --> Input Class Initialized
INFO - 2023-10-29 11:14:04 --> Language Class Initialized
INFO - 2023-10-29 11:14:04 --> Loader Class Initialized
INFO - 2023-10-29 11:14:04 --> Helper loaded: url_helper
INFO - 2023-10-29 11:14:04 --> Helper loaded: form_helper
INFO - 2023-10-29 11:14:04 --> Helper loaded: file_helper
INFO - 2023-10-29 11:14:04 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:14:04 --> Form Validation Class Initialized
INFO - 2023-10-29 11:14:04 --> Upload Class Initialized
INFO - 2023-10-29 11:14:04 --> Model "M_auth" initialized
INFO - 2023-10-29 11:14:04 --> Model "M_user" initialized
INFO - 2023-10-29 11:14:04 --> Model "M_produk" initialized
INFO - 2023-10-29 11:14:04 --> Controller Class Initialized
DEBUG - 2023-10-29 11:14:04 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:14:04 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 11:14:04 --> Final output sent to browser
DEBUG - 2023-10-29 11:14:04 --> Total execution time: 0.4550
ERROR - 2023-10-29 11:14:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:14:29 --> Config Class Initialized
INFO - 2023-10-29 11:14:29 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:14:29 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:14:29 --> Utf8 Class Initialized
INFO - 2023-10-29 11:14:29 --> URI Class Initialized
INFO - 2023-10-29 11:14:29 --> Router Class Initialized
INFO - 2023-10-29 11:14:29 --> Output Class Initialized
INFO - 2023-10-29 11:14:29 --> Security Class Initialized
DEBUG - 2023-10-29 11:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:14:29 --> Input Class Initialized
INFO - 2023-10-29 11:14:29 --> Language Class Initialized
INFO - 2023-10-29 11:14:29 --> Loader Class Initialized
INFO - 2023-10-29 11:14:29 --> Helper loaded: url_helper
INFO - 2023-10-29 11:14:29 --> Helper loaded: form_helper
INFO - 2023-10-29 11:14:29 --> Helper loaded: file_helper
INFO - 2023-10-29 11:14:29 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:14:29 --> Form Validation Class Initialized
INFO - 2023-10-29 11:14:29 --> Upload Class Initialized
INFO - 2023-10-29 11:14:29 --> Model "M_auth" initialized
INFO - 2023-10-29 11:14:29 --> Model "M_user" initialized
INFO - 2023-10-29 11:14:29 --> Model "M_produk" initialized
INFO - 2023-10-29 11:14:29 --> Controller Class Initialized
DEBUG - 2023-10-29 11:14:29 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:14:29 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:14:29 --> Final output sent to browser
DEBUG - 2023-10-29 11:14:29 --> Total execution time: 0.1244
ERROR - 2023-10-29 11:14:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:14:53 --> Config Class Initialized
INFO - 2023-10-29 11:14:53 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:14:53 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:14:53 --> Utf8 Class Initialized
INFO - 2023-10-29 11:14:53 --> URI Class Initialized
INFO - 2023-10-29 11:14:53 --> Router Class Initialized
INFO - 2023-10-29 11:14:53 --> Output Class Initialized
INFO - 2023-10-29 11:14:53 --> Security Class Initialized
DEBUG - 2023-10-29 11:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:14:53 --> Input Class Initialized
INFO - 2023-10-29 11:14:53 --> Language Class Initialized
INFO - 2023-10-29 11:14:53 --> Loader Class Initialized
INFO - 2023-10-29 11:14:53 --> Helper loaded: url_helper
INFO - 2023-10-29 11:14:53 --> Helper loaded: form_helper
INFO - 2023-10-29 11:14:53 --> Helper loaded: file_helper
INFO - 2023-10-29 11:14:53 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:14:54 --> Form Validation Class Initialized
INFO - 2023-10-29 11:14:54 --> Upload Class Initialized
INFO - 2023-10-29 11:14:54 --> Model "M_auth" initialized
INFO - 2023-10-29 11:14:54 --> Model "M_user" initialized
INFO - 2023-10-29 11:14:54 --> Model "M_produk" initialized
INFO - 2023-10-29 11:14:54 --> Controller Class Initialized
DEBUG - 2023-10-29 11:14:54 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:14:54 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:14:54 --> Final output sent to browser
DEBUG - 2023-10-29 11:14:54 --> Total execution time: 0.1010
ERROR - 2023-10-29 11:14:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:14:55 --> Config Class Initialized
INFO - 2023-10-29 11:14:55 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:14:55 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:14:55 --> Utf8 Class Initialized
INFO - 2023-10-29 11:14:55 --> URI Class Initialized
INFO - 2023-10-29 11:14:55 --> Router Class Initialized
INFO - 2023-10-29 11:14:55 --> Output Class Initialized
INFO - 2023-10-29 11:14:55 --> Security Class Initialized
DEBUG - 2023-10-29 11:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:14:55 --> Input Class Initialized
INFO - 2023-10-29 11:14:55 --> Language Class Initialized
INFO - 2023-10-29 11:14:55 --> Loader Class Initialized
INFO - 2023-10-29 11:14:55 --> Helper loaded: url_helper
INFO - 2023-10-29 11:14:55 --> Helper loaded: form_helper
INFO - 2023-10-29 11:14:55 --> Helper loaded: file_helper
INFO - 2023-10-29 11:14:55 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:14:55 --> Form Validation Class Initialized
INFO - 2023-10-29 11:14:55 --> Upload Class Initialized
INFO - 2023-10-29 11:14:55 --> Model "M_auth" initialized
INFO - 2023-10-29 11:14:55 --> Model "M_user" initialized
INFO - 2023-10-29 11:14:55 --> Model "M_produk" initialized
INFO - 2023-10-29 11:14:55 --> Controller Class Initialized
DEBUG - 2023-10-29 11:14:55 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:14:55 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 11:14:55 --> Final output sent to browser
DEBUG - 2023-10-29 11:14:55 --> Total execution time: 0.4068
ERROR - 2023-10-29 11:15:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:15:16 --> Config Class Initialized
INFO - 2023-10-29 11:15:16 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:15:16 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:15:16 --> Utf8 Class Initialized
INFO - 2023-10-29 11:15:16 --> URI Class Initialized
INFO - 2023-10-29 11:15:16 --> Router Class Initialized
INFO - 2023-10-29 11:15:16 --> Output Class Initialized
INFO - 2023-10-29 11:15:16 --> Security Class Initialized
DEBUG - 2023-10-29 11:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:15:16 --> Input Class Initialized
INFO - 2023-10-29 11:15:16 --> Language Class Initialized
INFO - 2023-10-29 11:15:16 --> Loader Class Initialized
INFO - 2023-10-29 11:15:16 --> Helper loaded: url_helper
INFO - 2023-10-29 11:15:16 --> Helper loaded: form_helper
INFO - 2023-10-29 11:15:16 --> Helper loaded: file_helper
INFO - 2023-10-29 11:15:16 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:15:16 --> Form Validation Class Initialized
INFO - 2023-10-29 11:15:16 --> Upload Class Initialized
INFO - 2023-10-29 11:15:16 --> Model "M_auth" initialized
INFO - 2023-10-29 11:15:16 --> Model "M_user" initialized
INFO - 2023-10-29 11:15:16 --> Model "M_produk" initialized
INFO - 2023-10-29 11:15:16 --> Controller Class Initialized
DEBUG - 2023-10-29 11:15:16 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:15:16 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 11:15:16 --> Final output sent to browser
DEBUG - 2023-10-29 11:15:16 --> Total execution time: 0.4592
ERROR - 2023-10-29 11:15:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:15:26 --> Config Class Initialized
INFO - 2023-10-29 11:15:26 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:15:26 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:15:26 --> Utf8 Class Initialized
INFO - 2023-10-29 11:15:26 --> URI Class Initialized
INFO - 2023-10-29 11:15:26 --> Router Class Initialized
INFO - 2023-10-29 11:15:26 --> Output Class Initialized
INFO - 2023-10-29 11:15:26 --> Security Class Initialized
DEBUG - 2023-10-29 11:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:15:26 --> Input Class Initialized
INFO - 2023-10-29 11:15:26 --> Language Class Initialized
INFO - 2023-10-29 11:15:26 --> Loader Class Initialized
INFO - 2023-10-29 11:15:26 --> Helper loaded: url_helper
INFO - 2023-10-29 11:15:26 --> Helper loaded: form_helper
INFO - 2023-10-29 11:15:26 --> Helper loaded: file_helper
INFO - 2023-10-29 11:15:26 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:15:26 --> Form Validation Class Initialized
INFO - 2023-10-29 11:15:26 --> Upload Class Initialized
INFO - 2023-10-29 11:15:26 --> Model "M_auth" initialized
INFO - 2023-10-29 11:15:26 --> Model "M_user" initialized
INFO - 2023-10-29 11:15:26 --> Model "M_produk" initialized
INFO - 2023-10-29 11:15:26 --> Controller Class Initialized
DEBUG - 2023-10-29 11:15:26 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:15:26 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:15:26 --> Final output sent to browser
DEBUG - 2023-10-29 11:15:26 --> Total execution time: 0.1001
ERROR - 2023-10-29 11:15:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:15:27 --> Config Class Initialized
INFO - 2023-10-29 11:15:27 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:15:27 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:15:27 --> Utf8 Class Initialized
INFO - 2023-10-29 11:15:27 --> URI Class Initialized
INFO - 2023-10-29 11:15:27 --> Router Class Initialized
INFO - 2023-10-29 11:15:27 --> Output Class Initialized
INFO - 2023-10-29 11:15:27 --> Security Class Initialized
DEBUG - 2023-10-29 11:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:15:27 --> Input Class Initialized
INFO - 2023-10-29 11:15:27 --> Language Class Initialized
INFO - 2023-10-29 11:15:27 --> Loader Class Initialized
INFO - 2023-10-29 11:15:27 --> Helper loaded: url_helper
INFO - 2023-10-29 11:15:27 --> Helper loaded: form_helper
INFO - 2023-10-29 11:15:27 --> Helper loaded: file_helper
INFO - 2023-10-29 11:15:27 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:15:27 --> Form Validation Class Initialized
INFO - 2023-10-29 11:15:27 --> Upload Class Initialized
INFO - 2023-10-29 11:15:27 --> Model "M_auth" initialized
INFO - 2023-10-29 11:15:27 --> Model "M_user" initialized
INFO - 2023-10-29 11:15:27 --> Model "M_produk" initialized
INFO - 2023-10-29 11:15:27 --> Controller Class Initialized
DEBUG - 2023-10-29 11:15:27 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:15:27 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:15:27 --> Final output sent to browser
DEBUG - 2023-10-29 11:15:27 --> Total execution time: 0.0916
ERROR - 2023-10-29 11:15:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:15:28 --> Config Class Initialized
INFO - 2023-10-29 11:15:28 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:15:28 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:15:28 --> Utf8 Class Initialized
INFO - 2023-10-29 11:15:28 --> URI Class Initialized
INFO - 2023-10-29 11:15:28 --> Router Class Initialized
INFO - 2023-10-29 11:15:28 --> Output Class Initialized
INFO - 2023-10-29 11:15:28 --> Security Class Initialized
DEBUG - 2023-10-29 11:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:15:28 --> Input Class Initialized
INFO - 2023-10-29 11:15:28 --> Language Class Initialized
INFO - 2023-10-29 11:15:28 --> Loader Class Initialized
INFO - 2023-10-29 11:15:28 --> Helper loaded: url_helper
INFO - 2023-10-29 11:15:28 --> Helper loaded: form_helper
INFO - 2023-10-29 11:15:28 --> Helper loaded: file_helper
INFO - 2023-10-29 11:15:28 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:15:28 --> Form Validation Class Initialized
INFO - 2023-10-29 11:15:28 --> Upload Class Initialized
INFO - 2023-10-29 11:15:28 --> Model "M_auth" initialized
INFO - 2023-10-29 11:15:28 --> Model "M_user" initialized
INFO - 2023-10-29 11:15:28 --> Model "M_produk" initialized
INFO - 2023-10-29 11:15:28 --> Controller Class Initialized
DEBUG - 2023-10-29 11:15:28 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:15:29 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 11:15:29 --> Final output sent to browser
DEBUG - 2023-10-29 11:15:29 --> Total execution time: 0.4547
ERROR - 2023-10-29 11:15:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:15:55 --> Config Class Initialized
INFO - 2023-10-29 11:15:55 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:15:55 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:15:55 --> Utf8 Class Initialized
INFO - 2023-10-29 11:15:55 --> URI Class Initialized
INFO - 2023-10-29 11:15:55 --> Router Class Initialized
INFO - 2023-10-29 11:15:55 --> Output Class Initialized
INFO - 2023-10-29 11:15:55 --> Security Class Initialized
DEBUG - 2023-10-29 11:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:15:55 --> Input Class Initialized
INFO - 2023-10-29 11:15:55 --> Language Class Initialized
INFO - 2023-10-29 11:15:55 --> Loader Class Initialized
INFO - 2023-10-29 11:15:55 --> Helper loaded: url_helper
INFO - 2023-10-29 11:15:55 --> Helper loaded: form_helper
INFO - 2023-10-29 11:15:55 --> Helper loaded: file_helper
INFO - 2023-10-29 11:15:55 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:15:55 --> Form Validation Class Initialized
INFO - 2023-10-29 11:15:55 --> Upload Class Initialized
INFO - 2023-10-29 11:15:55 --> Model "M_auth" initialized
INFO - 2023-10-29 11:15:55 --> Model "M_user" initialized
INFO - 2023-10-29 11:15:55 --> Model "M_produk" initialized
INFO - 2023-10-29 11:15:55 --> Controller Class Initialized
DEBUG - 2023-10-29 11:15:55 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:15:55 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:15:55 --> Final output sent to browser
DEBUG - 2023-10-29 11:15:55 --> Total execution time: 0.0775
ERROR - 2023-10-29 11:15:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:15:57 --> Config Class Initialized
INFO - 2023-10-29 11:15:57 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:15:57 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:15:57 --> Utf8 Class Initialized
INFO - 2023-10-29 11:15:57 --> URI Class Initialized
INFO - 2023-10-29 11:15:57 --> Router Class Initialized
INFO - 2023-10-29 11:15:57 --> Output Class Initialized
INFO - 2023-10-29 11:15:57 --> Security Class Initialized
DEBUG - 2023-10-29 11:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:15:57 --> Input Class Initialized
INFO - 2023-10-29 11:15:57 --> Language Class Initialized
INFO - 2023-10-29 11:15:57 --> Loader Class Initialized
INFO - 2023-10-29 11:15:57 --> Helper loaded: url_helper
INFO - 2023-10-29 11:15:57 --> Helper loaded: form_helper
INFO - 2023-10-29 11:15:57 --> Helper loaded: file_helper
INFO - 2023-10-29 11:15:57 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:15:57 --> Form Validation Class Initialized
INFO - 2023-10-29 11:15:57 --> Upload Class Initialized
INFO - 2023-10-29 11:15:57 --> Model "M_auth" initialized
INFO - 2023-10-29 11:15:57 --> Model "M_user" initialized
INFO - 2023-10-29 11:15:57 --> Model "M_produk" initialized
INFO - 2023-10-29 11:15:57 --> Controller Class Initialized
DEBUG - 2023-10-29 11:15:57 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:15:57 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 11:15:57 --> Final output sent to browser
DEBUG - 2023-10-29 11:15:57 --> Total execution time: 0.4019
ERROR - 2023-10-29 11:16:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:16:22 --> Config Class Initialized
INFO - 2023-10-29 11:16:22 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:16:22 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:16:22 --> Utf8 Class Initialized
INFO - 2023-10-29 11:16:22 --> URI Class Initialized
INFO - 2023-10-29 11:16:22 --> Router Class Initialized
INFO - 2023-10-29 11:16:22 --> Output Class Initialized
INFO - 2023-10-29 11:16:22 --> Security Class Initialized
DEBUG - 2023-10-29 11:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:16:22 --> Input Class Initialized
INFO - 2023-10-29 11:16:22 --> Language Class Initialized
INFO - 2023-10-29 11:16:22 --> Loader Class Initialized
INFO - 2023-10-29 11:16:22 --> Helper loaded: url_helper
INFO - 2023-10-29 11:16:22 --> Helper loaded: form_helper
INFO - 2023-10-29 11:16:22 --> Helper loaded: file_helper
INFO - 2023-10-29 11:16:22 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:16:22 --> Form Validation Class Initialized
INFO - 2023-10-29 11:16:22 --> Upload Class Initialized
INFO - 2023-10-29 11:16:22 --> Model "M_auth" initialized
INFO - 2023-10-29 11:16:22 --> Model "M_user" initialized
INFO - 2023-10-29 11:16:22 --> Model "M_produk" initialized
INFO - 2023-10-29 11:16:22 --> Controller Class Initialized
DEBUG - 2023-10-29 11:16:22 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:16:22 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:16:22 --> Final output sent to browser
DEBUG - 2023-10-29 11:16:22 --> Total execution time: 0.0912
ERROR - 2023-10-29 11:18:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:18:34 --> Config Class Initialized
INFO - 2023-10-29 11:18:34 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:18:34 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:18:34 --> Utf8 Class Initialized
INFO - 2023-10-29 11:18:34 --> URI Class Initialized
INFO - 2023-10-29 11:18:34 --> Router Class Initialized
INFO - 2023-10-29 11:18:34 --> Output Class Initialized
INFO - 2023-10-29 11:18:34 --> Security Class Initialized
DEBUG - 2023-10-29 11:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:18:34 --> Input Class Initialized
INFO - 2023-10-29 11:18:34 --> Language Class Initialized
INFO - 2023-10-29 11:18:34 --> Loader Class Initialized
INFO - 2023-10-29 11:18:34 --> Helper loaded: url_helper
INFO - 2023-10-29 11:18:34 --> Helper loaded: form_helper
INFO - 2023-10-29 11:18:34 --> Helper loaded: file_helper
INFO - 2023-10-29 11:18:34 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:18:34 --> Form Validation Class Initialized
INFO - 2023-10-29 11:18:34 --> Upload Class Initialized
INFO - 2023-10-29 11:18:34 --> Model "M_auth" initialized
INFO - 2023-10-29 11:18:34 --> Model "M_user" initialized
INFO - 2023-10-29 11:18:34 --> Model "M_produk" initialized
INFO - 2023-10-29 11:18:34 --> Controller Class Initialized
DEBUG - 2023-10-29 11:18:34 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:18:34 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:18:34 --> Final output sent to browser
DEBUG - 2023-10-29 11:18:34 --> Total execution time: 0.0889
ERROR - 2023-10-29 11:18:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:18:35 --> Config Class Initialized
INFO - 2023-10-29 11:18:35 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:18:35 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:18:35 --> Utf8 Class Initialized
INFO - 2023-10-29 11:18:35 --> URI Class Initialized
INFO - 2023-10-29 11:18:35 --> Router Class Initialized
INFO - 2023-10-29 11:18:35 --> Output Class Initialized
INFO - 2023-10-29 11:18:35 --> Security Class Initialized
DEBUG - 2023-10-29 11:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:18:35 --> Input Class Initialized
INFO - 2023-10-29 11:18:35 --> Language Class Initialized
INFO - 2023-10-29 11:18:35 --> Loader Class Initialized
INFO - 2023-10-29 11:18:35 --> Helper loaded: url_helper
INFO - 2023-10-29 11:18:35 --> Helper loaded: form_helper
INFO - 2023-10-29 11:18:35 --> Helper loaded: file_helper
INFO - 2023-10-29 11:18:35 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:18:35 --> Form Validation Class Initialized
INFO - 2023-10-29 11:18:35 --> Upload Class Initialized
INFO - 2023-10-29 11:18:35 --> Model "M_auth" initialized
INFO - 2023-10-29 11:18:35 --> Model "M_user" initialized
INFO - 2023-10-29 11:18:35 --> Model "M_produk" initialized
INFO - 2023-10-29 11:18:35 --> Controller Class Initialized
DEBUG - 2023-10-29 11:18:35 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:18:35 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:18:35 --> Final output sent to browser
DEBUG - 2023-10-29 11:18:35 --> Total execution time: 0.0824
ERROR - 2023-10-29 11:18:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:18:35 --> Config Class Initialized
INFO - 2023-10-29 11:18:35 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:18:35 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:18:35 --> Utf8 Class Initialized
INFO - 2023-10-29 11:18:35 --> URI Class Initialized
INFO - 2023-10-29 11:18:35 --> Router Class Initialized
INFO - 2023-10-29 11:18:35 --> Output Class Initialized
INFO - 2023-10-29 11:18:35 --> Security Class Initialized
DEBUG - 2023-10-29 11:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:18:35 --> Input Class Initialized
INFO - 2023-10-29 11:18:35 --> Language Class Initialized
INFO - 2023-10-29 11:18:35 --> Loader Class Initialized
INFO - 2023-10-29 11:18:35 --> Helper loaded: url_helper
INFO - 2023-10-29 11:18:35 --> Helper loaded: form_helper
INFO - 2023-10-29 11:18:35 --> Helper loaded: file_helper
INFO - 2023-10-29 11:18:35 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:18:35 --> Form Validation Class Initialized
INFO - 2023-10-29 11:18:35 --> Upload Class Initialized
INFO - 2023-10-29 11:18:35 --> Model "M_auth" initialized
INFO - 2023-10-29 11:18:35 --> Model "M_user" initialized
INFO - 2023-10-29 11:18:35 --> Model "M_produk" initialized
INFO - 2023-10-29 11:18:35 --> Controller Class Initialized
DEBUG - 2023-10-29 11:18:35 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:18:36 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 11:18:36 --> Final output sent to browser
DEBUG - 2023-10-29 11:18:36 --> Total execution time: 0.4185
ERROR - 2023-10-29 11:18:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:18:40 --> Config Class Initialized
INFO - 2023-10-29 11:18:40 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:18:40 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:18:40 --> Utf8 Class Initialized
INFO - 2023-10-29 11:18:40 --> URI Class Initialized
INFO - 2023-10-29 11:18:40 --> Router Class Initialized
INFO - 2023-10-29 11:18:40 --> Output Class Initialized
INFO - 2023-10-29 11:18:40 --> Security Class Initialized
DEBUG - 2023-10-29 11:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:18:40 --> Input Class Initialized
INFO - 2023-10-29 11:18:40 --> Language Class Initialized
INFO - 2023-10-29 11:18:40 --> Loader Class Initialized
INFO - 2023-10-29 11:18:40 --> Helper loaded: url_helper
INFO - 2023-10-29 11:18:40 --> Helper loaded: form_helper
INFO - 2023-10-29 11:18:40 --> Helper loaded: file_helper
INFO - 2023-10-29 11:18:40 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:18:40 --> Form Validation Class Initialized
INFO - 2023-10-29 11:18:40 --> Upload Class Initialized
INFO - 2023-10-29 11:18:40 --> Model "M_auth" initialized
INFO - 2023-10-29 11:18:40 --> Model "M_user" initialized
INFO - 2023-10-29 11:18:40 --> Model "M_produk" initialized
INFO - 2023-10-29 11:18:40 --> Controller Class Initialized
DEBUG - 2023-10-29 11:18:40 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:18:40 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:18:40 --> Final output sent to browser
DEBUG - 2023-10-29 11:18:40 --> Total execution time: 0.0979
ERROR - 2023-10-29 11:23:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:23:13 --> Config Class Initialized
INFO - 2023-10-29 11:23:13 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:23:13 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:23:13 --> Utf8 Class Initialized
INFO - 2023-10-29 11:23:13 --> URI Class Initialized
INFO - 2023-10-29 11:23:13 --> Router Class Initialized
INFO - 2023-10-29 11:23:13 --> Output Class Initialized
INFO - 2023-10-29 11:23:13 --> Security Class Initialized
DEBUG - 2023-10-29 11:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:23:13 --> Input Class Initialized
INFO - 2023-10-29 11:23:13 --> Language Class Initialized
INFO - 2023-10-29 11:23:13 --> Loader Class Initialized
INFO - 2023-10-29 11:23:13 --> Helper loaded: url_helper
INFO - 2023-10-29 11:23:13 --> Helper loaded: form_helper
INFO - 2023-10-29 11:23:13 --> Helper loaded: file_helper
INFO - 2023-10-29 11:23:13 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:23:13 --> Form Validation Class Initialized
INFO - 2023-10-29 11:23:13 --> Upload Class Initialized
INFO - 2023-10-29 11:23:13 --> Model "M_auth" initialized
INFO - 2023-10-29 11:23:13 --> Model "M_user" initialized
INFO - 2023-10-29 11:23:13 --> Model "M_produk" initialized
INFO - 2023-10-29 11:23:13 --> Controller Class Initialized
DEBUG - 2023-10-29 11:23:13 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:23:13 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:23:13 --> Final output sent to browser
DEBUG - 2023-10-29 11:23:13 --> Total execution time: 0.0988
ERROR - 2023-10-29 11:23:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:23:14 --> Config Class Initialized
INFO - 2023-10-29 11:23:14 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:23:14 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:23:14 --> Utf8 Class Initialized
INFO - 2023-10-29 11:23:14 --> URI Class Initialized
INFO - 2023-10-29 11:23:14 --> Router Class Initialized
INFO - 2023-10-29 11:23:14 --> Output Class Initialized
INFO - 2023-10-29 11:23:14 --> Security Class Initialized
DEBUG - 2023-10-29 11:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:23:14 --> Input Class Initialized
INFO - 2023-10-29 11:23:14 --> Language Class Initialized
INFO - 2023-10-29 11:23:14 --> Loader Class Initialized
INFO - 2023-10-29 11:23:14 --> Helper loaded: url_helper
INFO - 2023-10-29 11:23:14 --> Helper loaded: form_helper
INFO - 2023-10-29 11:23:14 --> Helper loaded: file_helper
INFO - 2023-10-29 11:23:14 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:23:14 --> Form Validation Class Initialized
INFO - 2023-10-29 11:23:14 --> Upload Class Initialized
INFO - 2023-10-29 11:23:14 --> Model "M_auth" initialized
INFO - 2023-10-29 11:23:14 --> Model "M_user" initialized
INFO - 2023-10-29 11:23:14 --> Model "M_produk" initialized
INFO - 2023-10-29 11:23:14 --> Controller Class Initialized
DEBUG - 2023-10-29 11:23:14 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:23:15 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 11:23:15 --> Final output sent to browser
DEBUG - 2023-10-29 11:23:15 --> Total execution time: 0.4727
ERROR - 2023-10-29 11:23:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:23:26 --> Config Class Initialized
INFO - 2023-10-29 11:23:26 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:23:26 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:23:26 --> Utf8 Class Initialized
INFO - 2023-10-29 11:23:26 --> URI Class Initialized
INFO - 2023-10-29 11:23:26 --> Router Class Initialized
INFO - 2023-10-29 11:23:26 --> Output Class Initialized
INFO - 2023-10-29 11:23:26 --> Security Class Initialized
DEBUG - 2023-10-29 11:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:23:26 --> Input Class Initialized
INFO - 2023-10-29 11:23:26 --> Language Class Initialized
INFO - 2023-10-29 11:23:26 --> Loader Class Initialized
INFO - 2023-10-29 11:23:26 --> Helper loaded: url_helper
INFO - 2023-10-29 11:23:26 --> Helper loaded: form_helper
INFO - 2023-10-29 11:23:26 --> Helper loaded: file_helper
INFO - 2023-10-29 11:23:26 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:23:26 --> Form Validation Class Initialized
INFO - 2023-10-29 11:23:26 --> Upload Class Initialized
INFO - 2023-10-29 11:23:26 --> Model "M_auth" initialized
INFO - 2023-10-29 11:23:26 --> Model "M_user" initialized
INFO - 2023-10-29 11:23:26 --> Model "M_produk" initialized
INFO - 2023-10-29 11:23:26 --> Controller Class Initialized
DEBUG - 2023-10-29 11:23:26 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:23:26 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:23:26 --> Final output sent to browser
DEBUG - 2023-10-29 11:23:26 --> Total execution time: 0.0911
ERROR - 2023-10-29 11:23:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:23:26 --> Config Class Initialized
INFO - 2023-10-29 11:23:26 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:23:26 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:23:26 --> Utf8 Class Initialized
INFO - 2023-10-29 11:23:26 --> URI Class Initialized
INFO - 2023-10-29 11:23:26 --> Router Class Initialized
INFO - 2023-10-29 11:23:26 --> Output Class Initialized
INFO - 2023-10-29 11:23:26 --> Security Class Initialized
DEBUG - 2023-10-29 11:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:23:26 --> Input Class Initialized
INFO - 2023-10-29 11:23:26 --> Language Class Initialized
INFO - 2023-10-29 11:23:26 --> Loader Class Initialized
INFO - 2023-10-29 11:23:26 --> Helper loaded: url_helper
INFO - 2023-10-29 11:23:26 --> Helper loaded: form_helper
INFO - 2023-10-29 11:23:26 --> Helper loaded: file_helper
INFO - 2023-10-29 11:23:26 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:23:26 --> Form Validation Class Initialized
INFO - 2023-10-29 11:23:26 --> Upload Class Initialized
INFO - 2023-10-29 11:23:26 --> Model "M_auth" initialized
INFO - 2023-10-29 11:23:26 --> Model "M_user" initialized
INFO - 2023-10-29 11:23:26 --> Model "M_produk" initialized
INFO - 2023-10-29 11:23:26 --> Controller Class Initialized
DEBUG - 2023-10-29 11:23:26 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:23:26 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:23:26 --> Final output sent to browser
DEBUG - 2023-10-29 11:23:26 --> Total execution time: 0.0242
ERROR - 2023-10-29 11:23:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:23:27 --> Config Class Initialized
INFO - 2023-10-29 11:23:27 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:23:27 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:23:27 --> Utf8 Class Initialized
INFO - 2023-10-29 11:23:27 --> URI Class Initialized
INFO - 2023-10-29 11:23:27 --> Router Class Initialized
INFO - 2023-10-29 11:23:27 --> Output Class Initialized
INFO - 2023-10-29 11:23:27 --> Security Class Initialized
DEBUG - 2023-10-29 11:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:23:27 --> Input Class Initialized
INFO - 2023-10-29 11:23:27 --> Language Class Initialized
INFO - 2023-10-29 11:23:27 --> Loader Class Initialized
INFO - 2023-10-29 11:23:27 --> Helper loaded: url_helper
INFO - 2023-10-29 11:23:27 --> Helper loaded: form_helper
INFO - 2023-10-29 11:23:27 --> Helper loaded: file_helper
INFO - 2023-10-29 11:23:27 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:23:27 --> Form Validation Class Initialized
INFO - 2023-10-29 11:23:27 --> Upload Class Initialized
INFO - 2023-10-29 11:23:27 --> Model "M_auth" initialized
INFO - 2023-10-29 11:23:27 --> Model "M_user" initialized
INFO - 2023-10-29 11:23:27 --> Model "M_produk" initialized
INFO - 2023-10-29 11:23:27 --> Controller Class Initialized
DEBUG - 2023-10-29 11:23:27 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:23:28 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 11:23:28 --> Final output sent to browser
DEBUG - 2023-10-29 11:23:28 --> Total execution time: 0.4246
ERROR - 2023-10-29 11:23:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:23:30 --> Config Class Initialized
INFO - 2023-10-29 11:23:30 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:23:30 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:23:30 --> Utf8 Class Initialized
INFO - 2023-10-29 11:23:30 --> URI Class Initialized
INFO - 2023-10-29 11:23:30 --> Router Class Initialized
INFO - 2023-10-29 11:23:30 --> Output Class Initialized
INFO - 2023-10-29 11:23:30 --> Security Class Initialized
DEBUG - 2023-10-29 11:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:23:30 --> Input Class Initialized
INFO - 2023-10-29 11:23:30 --> Language Class Initialized
INFO - 2023-10-29 11:23:30 --> Loader Class Initialized
INFO - 2023-10-29 11:23:30 --> Helper loaded: url_helper
INFO - 2023-10-29 11:23:30 --> Helper loaded: form_helper
INFO - 2023-10-29 11:23:30 --> Helper loaded: file_helper
INFO - 2023-10-29 11:23:30 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:23:30 --> Form Validation Class Initialized
INFO - 2023-10-29 11:23:30 --> Upload Class Initialized
INFO - 2023-10-29 11:23:30 --> Model "M_auth" initialized
INFO - 2023-10-29 11:23:30 --> Model "M_user" initialized
INFO - 2023-10-29 11:23:30 --> Model "M_produk" initialized
INFO - 2023-10-29 11:23:30 --> Controller Class Initialized
DEBUG - 2023-10-29 11:23:30 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:23:30 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:23:30 --> Final output sent to browser
DEBUG - 2023-10-29 11:23:30 --> Total execution time: 0.0914
ERROR - 2023-10-29 11:23:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:23:38 --> Config Class Initialized
INFO - 2023-10-29 11:23:38 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:23:38 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:23:38 --> Utf8 Class Initialized
INFO - 2023-10-29 11:23:38 --> URI Class Initialized
INFO - 2023-10-29 11:23:38 --> Router Class Initialized
INFO - 2023-10-29 11:23:38 --> Output Class Initialized
INFO - 2023-10-29 11:23:38 --> Security Class Initialized
DEBUG - 2023-10-29 11:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:23:38 --> Input Class Initialized
INFO - 2023-10-29 11:23:38 --> Language Class Initialized
ERROR - 2023-10-29 11:23:38 --> Severity: error --> Exception: syntax error, unexpected token "}", expecting "," or ";" C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Payment.php 47
ERROR - 2023-10-29 11:23:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:23:43 --> Config Class Initialized
INFO - 2023-10-29 11:23:43 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:23:43 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:23:43 --> Utf8 Class Initialized
INFO - 2023-10-29 11:23:43 --> URI Class Initialized
INFO - 2023-10-29 11:23:43 --> Router Class Initialized
INFO - 2023-10-29 11:23:43 --> Output Class Initialized
INFO - 2023-10-29 11:23:43 --> Security Class Initialized
DEBUG - 2023-10-29 11:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:23:43 --> Input Class Initialized
INFO - 2023-10-29 11:23:43 --> Language Class Initialized
INFO - 2023-10-29 11:23:43 --> Loader Class Initialized
INFO - 2023-10-29 11:23:43 --> Helper loaded: url_helper
INFO - 2023-10-29 11:23:43 --> Helper loaded: form_helper
INFO - 2023-10-29 11:23:43 --> Helper loaded: file_helper
INFO - 2023-10-29 11:23:43 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:23:43 --> Form Validation Class Initialized
INFO - 2023-10-29 11:23:43 --> Upload Class Initialized
INFO - 2023-10-29 11:23:43 --> Model "M_auth" initialized
INFO - 2023-10-29 11:23:43 --> Model "M_user" initialized
INFO - 2023-10-29 11:23:43 --> Model "M_produk" initialized
INFO - 2023-10-29 11:23:43 --> Controller Class Initialized
DEBUG - 2023-10-29 11:23:43 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:23:43 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:23:43 --> Final output sent to browser
DEBUG - 2023-10-29 11:23:43 --> Total execution time: 0.0905
ERROR - 2023-10-29 11:23:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:23:44 --> Config Class Initialized
INFO - 2023-10-29 11:23:44 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:23:44 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:23:44 --> Utf8 Class Initialized
INFO - 2023-10-29 11:23:44 --> URI Class Initialized
INFO - 2023-10-29 11:23:44 --> Router Class Initialized
INFO - 2023-10-29 11:23:44 --> Output Class Initialized
INFO - 2023-10-29 11:23:44 --> Security Class Initialized
DEBUG - 2023-10-29 11:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:23:44 --> Input Class Initialized
INFO - 2023-10-29 11:23:44 --> Language Class Initialized
INFO - 2023-10-29 11:23:44 --> Loader Class Initialized
INFO - 2023-10-29 11:23:44 --> Helper loaded: url_helper
INFO - 2023-10-29 11:23:44 --> Helper loaded: form_helper
INFO - 2023-10-29 11:23:44 --> Helper loaded: file_helper
INFO - 2023-10-29 11:23:44 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:23:44 --> Form Validation Class Initialized
INFO - 2023-10-29 11:23:44 --> Upload Class Initialized
INFO - 2023-10-29 11:23:44 --> Model "M_auth" initialized
INFO - 2023-10-29 11:23:44 --> Model "M_user" initialized
INFO - 2023-10-29 11:23:44 --> Model "M_produk" initialized
INFO - 2023-10-29 11:23:44 --> Controller Class Initialized
DEBUG - 2023-10-29 11:23:44 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:23:44 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 11:23:44 --> Final output sent to browser
DEBUG - 2023-10-29 11:23:44 --> Total execution time: 0.3988
ERROR - 2023-10-29 11:23:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:23:47 --> Config Class Initialized
INFO - 2023-10-29 11:23:47 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:23:47 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:23:47 --> Utf8 Class Initialized
INFO - 2023-10-29 11:23:47 --> URI Class Initialized
INFO - 2023-10-29 11:23:47 --> Router Class Initialized
INFO - 2023-10-29 11:23:47 --> Output Class Initialized
INFO - 2023-10-29 11:23:47 --> Security Class Initialized
DEBUG - 2023-10-29 11:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:23:47 --> Input Class Initialized
INFO - 2023-10-29 11:23:47 --> Language Class Initialized
INFO - 2023-10-29 11:23:47 --> Loader Class Initialized
INFO - 2023-10-29 11:23:47 --> Helper loaded: url_helper
INFO - 2023-10-29 11:23:47 --> Helper loaded: form_helper
INFO - 2023-10-29 11:23:47 --> Helper loaded: file_helper
INFO - 2023-10-29 11:23:47 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:23:47 --> Form Validation Class Initialized
INFO - 2023-10-29 11:23:47 --> Upload Class Initialized
INFO - 2023-10-29 11:23:47 --> Model "M_auth" initialized
INFO - 2023-10-29 11:23:47 --> Model "M_user" initialized
INFO - 2023-10-29 11:23:47 --> Model "M_produk" initialized
INFO - 2023-10-29 11:23:47 --> Controller Class Initialized
DEBUG - 2023-10-29 11:23:47 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:23:47 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:23:47 --> Final output sent to browser
DEBUG - 2023-10-29 11:23:47 --> Total execution time: 0.0954
ERROR - 2023-10-29 11:23:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:23:51 --> Config Class Initialized
INFO - 2023-10-29 11:23:51 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:23:51 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:23:51 --> Utf8 Class Initialized
INFO - 2023-10-29 11:23:51 --> URI Class Initialized
INFO - 2023-10-29 11:23:51 --> Router Class Initialized
INFO - 2023-10-29 11:23:51 --> Output Class Initialized
INFO - 2023-10-29 11:23:51 --> Security Class Initialized
DEBUG - 2023-10-29 11:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:23:51 --> Input Class Initialized
INFO - 2023-10-29 11:23:51 --> Language Class Initialized
INFO - 2023-10-29 11:23:51 --> Loader Class Initialized
INFO - 2023-10-29 11:23:51 --> Helper loaded: url_helper
INFO - 2023-10-29 11:23:51 --> Helper loaded: form_helper
INFO - 2023-10-29 11:23:51 --> Helper loaded: file_helper
INFO - 2023-10-29 11:23:51 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:23:51 --> Form Validation Class Initialized
INFO - 2023-10-29 11:23:51 --> Upload Class Initialized
INFO - 2023-10-29 11:23:51 --> Model "M_auth" initialized
INFO - 2023-10-29 11:23:51 --> Model "M_user" initialized
INFO - 2023-10-29 11:23:51 --> Model "M_produk" initialized
INFO - 2023-10-29 11:23:51 --> Controller Class Initialized
DEBUG - 2023-10-29 11:23:51 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:23:51 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 11:23:51 --> Final output sent to browser
DEBUG - 2023-10-29 11:23:51 --> Total execution time: 0.4029
ERROR - 2023-10-29 11:31:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:31:24 --> Config Class Initialized
INFO - 2023-10-29 11:31:24 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:31:24 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:31:24 --> Utf8 Class Initialized
INFO - 2023-10-29 11:31:24 --> URI Class Initialized
INFO - 2023-10-29 11:31:24 --> Router Class Initialized
INFO - 2023-10-29 11:31:24 --> Output Class Initialized
INFO - 2023-10-29 11:31:24 --> Security Class Initialized
DEBUG - 2023-10-29 11:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:31:24 --> Input Class Initialized
INFO - 2023-10-29 11:31:24 --> Language Class Initialized
INFO - 2023-10-29 11:31:24 --> Loader Class Initialized
INFO - 2023-10-29 11:31:24 --> Helper loaded: url_helper
INFO - 2023-10-29 11:31:24 --> Helper loaded: form_helper
INFO - 2023-10-29 11:31:24 --> Helper loaded: file_helper
INFO - 2023-10-29 11:31:24 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:31:24 --> Form Validation Class Initialized
INFO - 2023-10-29 11:31:24 --> Upload Class Initialized
INFO - 2023-10-29 11:31:24 --> Model "M_auth" initialized
INFO - 2023-10-29 11:31:24 --> Model "M_user" initialized
INFO - 2023-10-29 11:31:24 --> Model "M_produk" initialized
INFO - 2023-10-29 11:31:24 --> Controller Class Initialized
DEBUG - 2023-10-29 11:31:24 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:31:24 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:31:24 --> Final output sent to browser
DEBUG - 2023-10-29 11:31:24 --> Total execution time: 0.0398
ERROR - 2023-10-29 11:31:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:31:30 --> Config Class Initialized
INFO - 2023-10-29 11:31:30 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:31:30 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:31:30 --> Utf8 Class Initialized
INFO - 2023-10-29 11:31:30 --> URI Class Initialized
INFO - 2023-10-29 11:31:30 --> Router Class Initialized
INFO - 2023-10-29 11:31:30 --> Output Class Initialized
INFO - 2023-10-29 11:31:30 --> Security Class Initialized
DEBUG - 2023-10-29 11:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:31:30 --> Input Class Initialized
INFO - 2023-10-29 11:31:30 --> Language Class Initialized
INFO - 2023-10-29 11:31:30 --> Loader Class Initialized
INFO - 2023-10-29 11:31:30 --> Helper loaded: url_helper
INFO - 2023-10-29 11:31:30 --> Helper loaded: form_helper
INFO - 2023-10-29 11:31:30 --> Helper loaded: file_helper
INFO - 2023-10-29 11:31:30 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:31:30 --> Form Validation Class Initialized
INFO - 2023-10-29 11:31:30 --> Upload Class Initialized
INFO - 2023-10-29 11:31:30 --> Model "M_auth" initialized
INFO - 2023-10-29 11:31:30 --> Model "M_user" initialized
INFO - 2023-10-29 11:31:30 --> Model "M_produk" initialized
INFO - 2023-10-29 11:31:30 --> Controller Class Initialized
DEBUG - 2023-10-29 11:31:30 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:31:30 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:31:30 --> Final output sent to browser
DEBUG - 2023-10-29 11:31:30 --> Total execution time: 0.0572
ERROR - 2023-10-29 11:31:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:31:31 --> Config Class Initialized
INFO - 2023-10-29 11:31:31 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:31:31 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:31:31 --> Utf8 Class Initialized
INFO - 2023-10-29 11:31:31 --> URI Class Initialized
INFO - 2023-10-29 11:31:31 --> Router Class Initialized
INFO - 2023-10-29 11:31:31 --> Output Class Initialized
INFO - 2023-10-29 11:31:31 --> Security Class Initialized
DEBUG - 2023-10-29 11:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:31:31 --> Input Class Initialized
INFO - 2023-10-29 11:31:31 --> Language Class Initialized
INFO - 2023-10-29 11:31:31 --> Loader Class Initialized
INFO - 2023-10-29 11:31:31 --> Helper loaded: url_helper
INFO - 2023-10-29 11:31:31 --> Helper loaded: form_helper
INFO - 2023-10-29 11:31:31 --> Helper loaded: file_helper
INFO - 2023-10-29 11:31:31 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:31:31 --> Form Validation Class Initialized
INFO - 2023-10-29 11:31:31 --> Upload Class Initialized
INFO - 2023-10-29 11:31:31 --> Model "M_auth" initialized
INFO - 2023-10-29 11:31:31 --> Model "M_user" initialized
INFO - 2023-10-29 11:31:31 --> Model "M_produk" initialized
INFO - 2023-10-29 11:31:31 --> Controller Class Initialized
DEBUG - 2023-10-29 11:31:31 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:31:32 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 11:31:32 --> Final output sent to browser
DEBUG - 2023-10-29 11:31:32 --> Total execution time: 0.6766
ERROR - 2023-10-29 11:31:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:31:38 --> Config Class Initialized
INFO - 2023-10-29 11:31:38 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:31:38 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:31:38 --> Utf8 Class Initialized
INFO - 2023-10-29 11:31:38 --> URI Class Initialized
INFO - 2023-10-29 11:31:38 --> Router Class Initialized
INFO - 2023-10-29 11:31:38 --> Output Class Initialized
INFO - 2023-10-29 11:31:38 --> Security Class Initialized
DEBUG - 2023-10-29 11:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:31:38 --> Input Class Initialized
INFO - 2023-10-29 11:31:38 --> Language Class Initialized
INFO - 2023-10-29 11:31:38 --> Loader Class Initialized
INFO - 2023-10-29 11:31:38 --> Helper loaded: url_helper
INFO - 2023-10-29 11:31:38 --> Helper loaded: form_helper
INFO - 2023-10-29 11:31:38 --> Helper loaded: file_helper
INFO - 2023-10-29 11:31:38 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:31:38 --> Form Validation Class Initialized
INFO - 2023-10-29 11:31:38 --> Upload Class Initialized
INFO - 2023-10-29 11:31:38 --> Model "M_auth" initialized
INFO - 2023-10-29 11:31:38 --> Model "M_user" initialized
INFO - 2023-10-29 11:31:38 --> Model "M_produk" initialized
INFO - 2023-10-29 11:31:38 --> Controller Class Initialized
DEBUG - 2023-10-29 11:31:38 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:31:38 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:31:38 --> Final output sent to browser
DEBUG - 2023-10-29 11:31:38 --> Total execution time: 0.0749
ERROR - 2023-10-29 11:31:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:31:40 --> Config Class Initialized
INFO - 2023-10-29 11:31:40 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:31:40 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:31:40 --> Utf8 Class Initialized
INFO - 2023-10-29 11:31:40 --> URI Class Initialized
INFO - 2023-10-29 11:31:40 --> Router Class Initialized
INFO - 2023-10-29 11:31:40 --> Output Class Initialized
INFO - 2023-10-29 11:31:40 --> Security Class Initialized
DEBUG - 2023-10-29 11:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:31:40 --> Input Class Initialized
INFO - 2023-10-29 11:31:40 --> Language Class Initialized
INFO - 2023-10-29 11:31:40 --> Loader Class Initialized
INFO - 2023-10-29 11:31:40 --> Helper loaded: url_helper
INFO - 2023-10-29 11:31:40 --> Helper loaded: form_helper
INFO - 2023-10-29 11:31:40 --> Helper loaded: file_helper
INFO - 2023-10-29 11:31:40 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:31:40 --> Form Validation Class Initialized
INFO - 2023-10-29 11:31:40 --> Upload Class Initialized
INFO - 2023-10-29 11:31:40 --> Model "M_auth" initialized
INFO - 2023-10-29 11:31:40 --> Model "M_user" initialized
INFO - 2023-10-29 11:31:40 --> Model "M_produk" initialized
INFO - 2023-10-29 11:31:40 --> Controller Class Initialized
DEBUG - 2023-10-29 11:31:40 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:31:40 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 11:31:40 --> Final output sent to browser
DEBUG - 2023-10-29 11:31:40 --> Total execution time: 0.4294
ERROR - 2023-10-29 11:32:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:32:29 --> Config Class Initialized
INFO - 2023-10-29 11:32:29 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:32:29 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:32:29 --> Utf8 Class Initialized
INFO - 2023-10-29 11:32:29 --> URI Class Initialized
INFO - 2023-10-29 11:32:29 --> Router Class Initialized
INFO - 2023-10-29 11:32:29 --> Output Class Initialized
INFO - 2023-10-29 11:32:29 --> Security Class Initialized
DEBUG - 2023-10-29 11:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:32:29 --> Input Class Initialized
INFO - 2023-10-29 11:32:29 --> Language Class Initialized
INFO - 2023-10-29 11:32:29 --> Loader Class Initialized
INFO - 2023-10-29 11:32:29 --> Helper loaded: url_helper
INFO - 2023-10-29 11:32:29 --> Helper loaded: form_helper
INFO - 2023-10-29 11:32:29 --> Helper loaded: file_helper
INFO - 2023-10-29 11:32:29 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:32:29 --> Form Validation Class Initialized
INFO - 2023-10-29 11:32:29 --> Upload Class Initialized
INFO - 2023-10-29 11:32:29 --> Model "M_auth" initialized
INFO - 2023-10-29 11:32:29 --> Model "M_user" initialized
INFO - 2023-10-29 11:32:29 --> Model "M_produk" initialized
INFO - 2023-10-29 11:32:29 --> Controller Class Initialized
DEBUG - 2023-10-29 11:32:29 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:32:29 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:32:29 --> Final output sent to browser
DEBUG - 2023-10-29 11:32:29 --> Total execution time: 0.0569
ERROR - 2023-10-29 11:34:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:34:47 --> Config Class Initialized
INFO - 2023-10-29 11:34:47 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:34:47 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:34:47 --> Utf8 Class Initialized
INFO - 2023-10-29 11:34:47 --> URI Class Initialized
INFO - 2023-10-29 11:34:47 --> Router Class Initialized
INFO - 2023-10-29 11:34:47 --> Output Class Initialized
INFO - 2023-10-29 11:34:47 --> Security Class Initialized
DEBUG - 2023-10-29 11:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:34:47 --> Input Class Initialized
INFO - 2023-10-29 11:34:47 --> Language Class Initialized
INFO - 2023-10-29 11:34:47 --> Loader Class Initialized
INFO - 2023-10-29 11:34:47 --> Helper loaded: url_helper
INFO - 2023-10-29 11:34:47 --> Helper loaded: form_helper
INFO - 2023-10-29 11:34:47 --> Helper loaded: file_helper
INFO - 2023-10-29 11:34:47 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:34:47 --> Form Validation Class Initialized
INFO - 2023-10-29 11:34:47 --> Upload Class Initialized
INFO - 2023-10-29 11:34:47 --> Model "M_auth" initialized
INFO - 2023-10-29 11:34:47 --> Model "M_user" initialized
INFO - 2023-10-29 11:34:47 --> Model "M_produk" initialized
INFO - 2023-10-29 11:34:47 --> Controller Class Initialized
DEBUG - 2023-10-29 11:34:47 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:34:47 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:34:47 --> Final output sent to browser
DEBUG - 2023-10-29 11:34:47 --> Total execution time: 0.0299
ERROR - 2023-10-29 11:34:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:34:47 --> Config Class Initialized
INFO - 2023-10-29 11:34:47 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:34:47 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:34:47 --> Utf8 Class Initialized
INFO - 2023-10-29 11:34:47 --> URI Class Initialized
INFO - 2023-10-29 11:34:47 --> Router Class Initialized
INFO - 2023-10-29 11:34:47 --> Output Class Initialized
INFO - 2023-10-29 11:34:47 --> Security Class Initialized
DEBUG - 2023-10-29 11:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:34:47 --> Input Class Initialized
INFO - 2023-10-29 11:34:47 --> Language Class Initialized
INFO - 2023-10-29 11:34:47 --> Loader Class Initialized
INFO - 2023-10-29 11:34:47 --> Helper loaded: url_helper
INFO - 2023-10-29 11:34:47 --> Helper loaded: form_helper
INFO - 2023-10-29 11:34:47 --> Helper loaded: file_helper
INFO - 2023-10-29 11:34:47 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:34:47 --> Form Validation Class Initialized
INFO - 2023-10-29 11:34:47 --> Upload Class Initialized
INFO - 2023-10-29 11:34:47 --> Model "M_auth" initialized
INFO - 2023-10-29 11:34:47 --> Model "M_user" initialized
INFO - 2023-10-29 11:34:47 --> Model "M_produk" initialized
INFO - 2023-10-29 11:34:47 --> Controller Class Initialized
DEBUG - 2023-10-29 11:34:47 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:34:48 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 11:34:48 --> Final output sent to browser
DEBUG - 2023-10-29 11:34:48 --> Total execution time: 0.4373
ERROR - 2023-10-29 11:34:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:34:50 --> Config Class Initialized
INFO - 2023-10-29 11:34:50 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:34:50 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:34:50 --> Utf8 Class Initialized
INFO - 2023-10-29 11:34:50 --> URI Class Initialized
INFO - 2023-10-29 11:34:50 --> Router Class Initialized
INFO - 2023-10-29 11:34:50 --> Output Class Initialized
INFO - 2023-10-29 11:34:50 --> Security Class Initialized
DEBUG - 2023-10-29 11:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:34:50 --> Input Class Initialized
INFO - 2023-10-29 11:34:50 --> Language Class Initialized
INFO - 2023-10-29 11:34:50 --> Loader Class Initialized
INFO - 2023-10-29 11:34:50 --> Helper loaded: url_helper
INFO - 2023-10-29 11:34:50 --> Helper loaded: form_helper
INFO - 2023-10-29 11:34:50 --> Helper loaded: file_helper
INFO - 2023-10-29 11:34:50 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:34:50 --> Form Validation Class Initialized
INFO - 2023-10-29 11:34:50 --> Upload Class Initialized
INFO - 2023-10-29 11:34:50 --> Model "M_auth" initialized
INFO - 2023-10-29 11:34:50 --> Model "M_user" initialized
INFO - 2023-10-29 11:34:50 --> Model "M_produk" initialized
INFO - 2023-10-29 11:34:50 --> Controller Class Initialized
DEBUG - 2023-10-29 11:34:50 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:34:50 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:34:50 --> Final output sent to browser
DEBUG - 2023-10-29 11:34:50 --> Total execution time: 0.0997
ERROR - 2023-10-29 11:34:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:34:51 --> Config Class Initialized
INFO - 2023-10-29 11:34:51 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:34:51 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:34:51 --> Utf8 Class Initialized
INFO - 2023-10-29 11:34:51 --> URI Class Initialized
INFO - 2023-10-29 11:34:51 --> Router Class Initialized
INFO - 2023-10-29 11:34:51 --> Output Class Initialized
INFO - 2023-10-29 11:34:51 --> Security Class Initialized
DEBUG - 2023-10-29 11:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:34:51 --> Input Class Initialized
INFO - 2023-10-29 11:34:51 --> Language Class Initialized
INFO - 2023-10-29 11:34:51 --> Loader Class Initialized
INFO - 2023-10-29 11:34:51 --> Helper loaded: url_helper
INFO - 2023-10-29 11:34:51 --> Helper loaded: form_helper
INFO - 2023-10-29 11:34:51 --> Helper loaded: file_helper
INFO - 2023-10-29 11:34:51 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:34:51 --> Form Validation Class Initialized
INFO - 2023-10-29 11:34:51 --> Upload Class Initialized
INFO - 2023-10-29 11:34:51 --> Model "M_auth" initialized
INFO - 2023-10-29 11:34:51 --> Model "M_user" initialized
INFO - 2023-10-29 11:34:51 --> Model "M_produk" initialized
INFO - 2023-10-29 11:34:51 --> Controller Class Initialized
DEBUG - 2023-10-29 11:34:51 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:34:51 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 11:34:51 --> Final output sent to browser
DEBUG - 2023-10-29 11:34:51 --> Total execution time: 0.3891
ERROR - 2023-10-29 11:34:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:34:53 --> Config Class Initialized
INFO - 2023-10-29 11:34:53 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:34:53 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:34:53 --> Utf8 Class Initialized
INFO - 2023-10-29 11:34:53 --> URI Class Initialized
INFO - 2023-10-29 11:34:53 --> Router Class Initialized
INFO - 2023-10-29 11:34:53 --> Output Class Initialized
INFO - 2023-10-29 11:34:53 --> Security Class Initialized
DEBUG - 2023-10-29 11:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:34:53 --> Input Class Initialized
INFO - 2023-10-29 11:34:53 --> Language Class Initialized
INFO - 2023-10-29 11:34:53 --> Loader Class Initialized
INFO - 2023-10-29 11:34:53 --> Helper loaded: url_helper
INFO - 2023-10-29 11:34:53 --> Helper loaded: form_helper
INFO - 2023-10-29 11:34:53 --> Helper loaded: file_helper
INFO - 2023-10-29 11:34:53 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:34:53 --> Form Validation Class Initialized
INFO - 2023-10-29 11:34:53 --> Upload Class Initialized
INFO - 2023-10-29 11:34:53 --> Model "M_auth" initialized
INFO - 2023-10-29 11:34:53 --> Model "M_user" initialized
INFO - 2023-10-29 11:34:53 --> Model "M_produk" initialized
INFO - 2023-10-29 11:34:53 --> Controller Class Initialized
DEBUG - 2023-10-29 11:34:53 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:34:53 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:34:53 --> Final output sent to browser
DEBUG - 2023-10-29 11:34:53 --> Total execution time: 0.0584
ERROR - 2023-10-29 11:35:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:35:42 --> Config Class Initialized
INFO - 2023-10-29 11:35:42 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:35:42 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:35:42 --> Utf8 Class Initialized
INFO - 2023-10-29 11:35:42 --> URI Class Initialized
INFO - 2023-10-29 11:35:42 --> Router Class Initialized
INFO - 2023-10-29 11:35:42 --> Output Class Initialized
INFO - 2023-10-29 11:35:42 --> Security Class Initialized
DEBUG - 2023-10-29 11:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:35:42 --> Input Class Initialized
INFO - 2023-10-29 11:35:42 --> Language Class Initialized
INFO - 2023-10-29 11:35:42 --> Loader Class Initialized
INFO - 2023-10-29 11:35:42 --> Helper loaded: url_helper
INFO - 2023-10-29 11:35:42 --> Helper loaded: form_helper
INFO - 2023-10-29 11:35:42 --> Helper loaded: file_helper
INFO - 2023-10-29 11:35:42 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:35:42 --> Form Validation Class Initialized
INFO - 2023-10-29 11:35:42 --> Upload Class Initialized
INFO - 2023-10-29 11:35:42 --> Model "M_auth" initialized
INFO - 2023-10-29 11:35:42 --> Model "M_user" initialized
INFO - 2023-10-29 11:35:42 --> Model "M_produk" initialized
INFO - 2023-10-29 11:35:42 --> Controller Class Initialized
DEBUG - 2023-10-29 11:35:42 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:35:42 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:35:42 --> Final output sent to browser
DEBUG - 2023-10-29 11:35:42 --> Total execution time: 0.0837
ERROR - 2023-10-29 11:35:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:35:43 --> Config Class Initialized
INFO - 2023-10-29 11:35:43 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:35:43 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:35:43 --> Utf8 Class Initialized
INFO - 2023-10-29 11:35:43 --> URI Class Initialized
INFO - 2023-10-29 11:35:43 --> Router Class Initialized
INFO - 2023-10-29 11:35:43 --> Output Class Initialized
INFO - 2023-10-29 11:35:43 --> Security Class Initialized
DEBUG - 2023-10-29 11:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:35:43 --> Input Class Initialized
INFO - 2023-10-29 11:35:43 --> Language Class Initialized
INFO - 2023-10-29 11:35:43 --> Loader Class Initialized
INFO - 2023-10-29 11:35:43 --> Helper loaded: url_helper
INFO - 2023-10-29 11:35:43 --> Helper loaded: form_helper
INFO - 2023-10-29 11:35:43 --> Helper loaded: file_helper
INFO - 2023-10-29 11:35:43 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:35:43 --> Form Validation Class Initialized
INFO - 2023-10-29 11:35:43 --> Upload Class Initialized
INFO - 2023-10-29 11:35:43 --> Model "M_auth" initialized
INFO - 2023-10-29 11:35:43 --> Model "M_user" initialized
INFO - 2023-10-29 11:35:43 --> Model "M_produk" initialized
INFO - 2023-10-29 11:35:43 --> Controller Class Initialized
DEBUG - 2023-10-29 11:35:43 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:35:43 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 11:35:43 --> Final output sent to browser
DEBUG - 2023-10-29 11:35:43 --> Total execution time: 0.3888
ERROR - 2023-10-29 11:35:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:35:45 --> Config Class Initialized
INFO - 2023-10-29 11:35:45 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:35:45 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:35:45 --> Utf8 Class Initialized
INFO - 2023-10-29 11:35:45 --> URI Class Initialized
INFO - 2023-10-29 11:35:45 --> Router Class Initialized
INFO - 2023-10-29 11:35:45 --> Output Class Initialized
INFO - 2023-10-29 11:35:45 --> Security Class Initialized
DEBUG - 2023-10-29 11:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:35:45 --> Input Class Initialized
INFO - 2023-10-29 11:35:45 --> Language Class Initialized
INFO - 2023-10-29 11:35:45 --> Loader Class Initialized
INFO - 2023-10-29 11:35:45 --> Helper loaded: url_helper
INFO - 2023-10-29 11:35:45 --> Helper loaded: form_helper
INFO - 2023-10-29 11:35:45 --> Helper loaded: file_helper
INFO - 2023-10-29 11:35:45 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:35:45 --> Form Validation Class Initialized
INFO - 2023-10-29 11:35:45 --> Upload Class Initialized
INFO - 2023-10-29 11:35:45 --> Model "M_auth" initialized
INFO - 2023-10-29 11:35:45 --> Model "M_user" initialized
INFO - 2023-10-29 11:35:45 --> Model "M_produk" initialized
INFO - 2023-10-29 11:35:45 --> Controller Class Initialized
DEBUG - 2023-10-29 11:35:45 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:35:45 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:35:45 --> Final output sent to browser
DEBUG - 2023-10-29 11:35:45 --> Total execution time: 0.0738
ERROR - 2023-10-29 11:36:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:36:18 --> Config Class Initialized
INFO - 2023-10-29 11:36:18 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:36:18 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:36:18 --> Utf8 Class Initialized
INFO - 2023-10-29 11:36:18 --> URI Class Initialized
INFO - 2023-10-29 11:36:18 --> Router Class Initialized
INFO - 2023-10-29 11:36:18 --> Output Class Initialized
INFO - 2023-10-29 11:36:18 --> Security Class Initialized
DEBUG - 2023-10-29 11:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:36:18 --> Input Class Initialized
INFO - 2023-10-29 11:36:18 --> Language Class Initialized
INFO - 2023-10-29 11:36:18 --> Loader Class Initialized
INFO - 2023-10-29 11:36:18 --> Helper loaded: url_helper
INFO - 2023-10-29 11:36:18 --> Helper loaded: form_helper
INFO - 2023-10-29 11:36:18 --> Helper loaded: file_helper
INFO - 2023-10-29 11:36:18 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:36:18 --> Form Validation Class Initialized
INFO - 2023-10-29 11:36:18 --> Upload Class Initialized
INFO - 2023-10-29 11:36:18 --> Model "M_auth" initialized
INFO - 2023-10-29 11:36:18 --> Model "M_user" initialized
INFO - 2023-10-29 11:36:18 --> Model "M_produk" initialized
INFO - 2023-10-29 11:36:18 --> Controller Class Initialized
DEBUG - 2023-10-29 11:36:18 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:36:19 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 11:36:19 --> Final output sent to browser
DEBUG - 2023-10-29 11:36:19 --> Total execution time: 0.8590
ERROR - 2023-10-29 11:36:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:36:47 --> Config Class Initialized
INFO - 2023-10-29 11:36:47 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:36:47 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:36:47 --> Utf8 Class Initialized
INFO - 2023-10-29 11:36:47 --> URI Class Initialized
INFO - 2023-10-29 11:36:47 --> Router Class Initialized
INFO - 2023-10-29 11:36:47 --> Output Class Initialized
INFO - 2023-10-29 11:36:47 --> Security Class Initialized
DEBUG - 2023-10-29 11:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:36:47 --> Input Class Initialized
INFO - 2023-10-29 11:36:47 --> Language Class Initialized
INFO - 2023-10-29 11:36:47 --> Loader Class Initialized
INFO - 2023-10-29 11:36:47 --> Helper loaded: url_helper
INFO - 2023-10-29 11:36:47 --> Helper loaded: form_helper
INFO - 2023-10-29 11:36:47 --> Helper loaded: file_helper
INFO - 2023-10-29 11:36:47 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:36:47 --> Form Validation Class Initialized
INFO - 2023-10-29 11:36:47 --> Upload Class Initialized
INFO - 2023-10-29 11:36:47 --> Model "M_auth" initialized
INFO - 2023-10-29 11:36:47 --> Model "M_user" initialized
INFO - 2023-10-29 11:36:47 --> Model "M_produk" initialized
INFO - 2023-10-29 11:36:47 --> Controller Class Initialized
DEBUG - 2023-10-29 11:36:47 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:36:47 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:36:47 --> Final output sent to browser
DEBUG - 2023-10-29 11:36:47 --> Total execution time: 0.0706
ERROR - 2023-10-29 11:37:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:37:03 --> Config Class Initialized
INFO - 2023-10-29 11:37:03 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:37:03 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:37:03 --> Utf8 Class Initialized
INFO - 2023-10-29 11:37:03 --> URI Class Initialized
INFO - 2023-10-29 11:37:03 --> Router Class Initialized
INFO - 2023-10-29 11:37:03 --> Output Class Initialized
INFO - 2023-10-29 11:37:03 --> Security Class Initialized
DEBUG - 2023-10-29 11:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:37:03 --> Input Class Initialized
INFO - 2023-10-29 11:37:03 --> Language Class Initialized
INFO - 2023-10-29 11:37:03 --> Loader Class Initialized
INFO - 2023-10-29 11:37:03 --> Helper loaded: url_helper
INFO - 2023-10-29 11:37:03 --> Helper loaded: form_helper
INFO - 2023-10-29 11:37:03 --> Helper loaded: file_helper
INFO - 2023-10-29 11:37:03 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:37:03 --> Form Validation Class Initialized
INFO - 2023-10-29 11:37:03 --> Upload Class Initialized
INFO - 2023-10-29 11:37:03 --> Model "M_auth" initialized
INFO - 2023-10-29 11:37:03 --> Model "M_user" initialized
INFO - 2023-10-29 11:37:03 --> Model "M_produk" initialized
INFO - 2023-10-29 11:37:03 --> Controller Class Initialized
DEBUG - 2023-10-29 11:37:03 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:37:04 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 11:37:04 --> Final output sent to browser
DEBUG - 2023-10-29 11:37:04 --> Total execution time: 0.4010
ERROR - 2023-10-29 11:37:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:37:07 --> Config Class Initialized
INFO - 2023-10-29 11:37:07 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:37:07 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:37:07 --> Utf8 Class Initialized
INFO - 2023-10-29 11:37:07 --> URI Class Initialized
INFO - 2023-10-29 11:37:07 --> Router Class Initialized
INFO - 2023-10-29 11:37:07 --> Output Class Initialized
INFO - 2023-10-29 11:37:07 --> Security Class Initialized
DEBUG - 2023-10-29 11:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:37:07 --> Input Class Initialized
INFO - 2023-10-29 11:37:07 --> Language Class Initialized
INFO - 2023-10-29 11:37:07 --> Loader Class Initialized
INFO - 2023-10-29 11:37:07 --> Helper loaded: url_helper
INFO - 2023-10-29 11:37:07 --> Helper loaded: form_helper
INFO - 2023-10-29 11:37:07 --> Helper loaded: file_helper
INFO - 2023-10-29 11:37:07 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:37:07 --> Form Validation Class Initialized
INFO - 2023-10-29 11:37:07 --> Upload Class Initialized
INFO - 2023-10-29 11:37:07 --> Model "M_auth" initialized
INFO - 2023-10-29 11:37:07 --> Model "M_user" initialized
INFO - 2023-10-29 11:37:07 --> Model "M_produk" initialized
INFO - 2023-10-29 11:37:07 --> Controller Class Initialized
DEBUG - 2023-10-29 11:37:07 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:37:07 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:37:07 --> Final output sent to browser
DEBUG - 2023-10-29 11:37:07 --> Total execution time: 0.0480
ERROR - 2023-10-29 11:37:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:37:08 --> Config Class Initialized
INFO - 2023-10-29 11:37:08 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:37:08 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:37:08 --> Utf8 Class Initialized
INFO - 2023-10-29 11:37:08 --> URI Class Initialized
INFO - 2023-10-29 11:37:08 --> Router Class Initialized
INFO - 2023-10-29 11:37:08 --> Output Class Initialized
INFO - 2023-10-29 11:37:08 --> Security Class Initialized
DEBUG - 2023-10-29 11:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:37:08 --> Input Class Initialized
INFO - 2023-10-29 11:37:08 --> Language Class Initialized
INFO - 2023-10-29 11:37:08 --> Loader Class Initialized
INFO - 2023-10-29 11:37:08 --> Helper loaded: url_helper
INFO - 2023-10-29 11:37:08 --> Helper loaded: form_helper
INFO - 2023-10-29 11:37:08 --> Helper loaded: file_helper
INFO - 2023-10-29 11:37:08 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:37:08 --> Form Validation Class Initialized
INFO - 2023-10-29 11:37:08 --> Upload Class Initialized
INFO - 2023-10-29 11:37:08 --> Model "M_auth" initialized
INFO - 2023-10-29 11:37:08 --> Model "M_user" initialized
INFO - 2023-10-29 11:37:08 --> Model "M_produk" initialized
INFO - 2023-10-29 11:37:08 --> Controller Class Initialized
DEBUG - 2023-10-29 11:37:08 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:37:08 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 11:37:08 --> Final output sent to browser
DEBUG - 2023-10-29 11:37:08 --> Total execution time: 0.3578
ERROR - 2023-10-29 11:37:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:37:14 --> Config Class Initialized
INFO - 2023-10-29 11:37:14 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:37:14 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:37:14 --> Utf8 Class Initialized
INFO - 2023-10-29 11:37:14 --> URI Class Initialized
INFO - 2023-10-29 11:37:14 --> Router Class Initialized
INFO - 2023-10-29 11:37:14 --> Output Class Initialized
INFO - 2023-10-29 11:37:14 --> Security Class Initialized
DEBUG - 2023-10-29 11:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:37:14 --> Input Class Initialized
INFO - 2023-10-29 11:37:14 --> Language Class Initialized
INFO - 2023-10-29 11:37:14 --> Loader Class Initialized
INFO - 2023-10-29 11:37:14 --> Helper loaded: url_helper
INFO - 2023-10-29 11:37:14 --> Helper loaded: form_helper
INFO - 2023-10-29 11:37:14 --> Helper loaded: file_helper
INFO - 2023-10-29 11:37:14 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:37:14 --> Form Validation Class Initialized
INFO - 2023-10-29 11:37:14 --> Upload Class Initialized
INFO - 2023-10-29 11:37:14 --> Model "M_auth" initialized
INFO - 2023-10-29 11:37:14 --> Model "M_user" initialized
INFO - 2023-10-29 11:37:14 --> Model "M_produk" initialized
INFO - 2023-10-29 11:37:14 --> Controller Class Initialized
DEBUG - 2023-10-29 11:37:14 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:37:14 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:37:14 --> Final output sent to browser
DEBUG - 2023-10-29 11:37:14 --> Total execution time: 0.0534
ERROR - 2023-10-29 11:39:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:39:25 --> Config Class Initialized
INFO - 2023-10-29 11:39:25 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:39:25 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:39:25 --> Utf8 Class Initialized
INFO - 2023-10-29 11:39:25 --> URI Class Initialized
INFO - 2023-10-29 11:39:25 --> Router Class Initialized
INFO - 2023-10-29 11:39:25 --> Output Class Initialized
INFO - 2023-10-29 11:39:25 --> Security Class Initialized
DEBUG - 2023-10-29 11:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:39:25 --> Input Class Initialized
INFO - 2023-10-29 11:39:25 --> Language Class Initialized
INFO - 2023-10-29 11:39:25 --> Loader Class Initialized
INFO - 2023-10-29 11:39:25 --> Helper loaded: url_helper
INFO - 2023-10-29 11:39:25 --> Helper loaded: form_helper
INFO - 2023-10-29 11:39:25 --> Helper loaded: file_helper
INFO - 2023-10-29 11:39:25 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:39:25 --> Form Validation Class Initialized
INFO - 2023-10-29 11:39:25 --> Upload Class Initialized
INFO - 2023-10-29 11:39:25 --> Model "M_auth" initialized
INFO - 2023-10-29 11:39:25 --> Model "M_user" initialized
INFO - 2023-10-29 11:39:25 --> Model "M_produk" initialized
INFO - 2023-10-29 11:39:25 --> Controller Class Initialized
DEBUG - 2023-10-29 11:39:25 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:39:25 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:39:25 --> Final output sent to browser
DEBUG - 2023-10-29 11:39:25 --> Total execution time: 0.0486
ERROR - 2023-10-29 11:39:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:39:26 --> Config Class Initialized
INFO - 2023-10-29 11:39:26 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:39:26 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:39:26 --> Utf8 Class Initialized
INFO - 2023-10-29 11:39:26 --> URI Class Initialized
INFO - 2023-10-29 11:39:26 --> Router Class Initialized
INFO - 2023-10-29 11:39:26 --> Output Class Initialized
INFO - 2023-10-29 11:39:26 --> Security Class Initialized
DEBUG - 2023-10-29 11:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:39:26 --> Input Class Initialized
INFO - 2023-10-29 11:39:26 --> Language Class Initialized
INFO - 2023-10-29 11:39:26 --> Loader Class Initialized
INFO - 2023-10-29 11:39:26 --> Helper loaded: url_helper
INFO - 2023-10-29 11:39:26 --> Helper loaded: form_helper
INFO - 2023-10-29 11:39:26 --> Helper loaded: file_helper
INFO - 2023-10-29 11:39:26 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:39:26 --> Form Validation Class Initialized
INFO - 2023-10-29 11:39:26 --> Upload Class Initialized
INFO - 2023-10-29 11:39:26 --> Model "M_auth" initialized
INFO - 2023-10-29 11:39:26 --> Model "M_user" initialized
INFO - 2023-10-29 11:39:26 --> Model "M_produk" initialized
INFO - 2023-10-29 11:39:26 --> Controller Class Initialized
DEBUG - 2023-10-29 11:39:26 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-29 11:39:26 --> Severity: Warning --> Undefined variable $clientKey C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php 7
INFO - 2023-10-29 11:39:26 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 11:39:26 --> Final output sent to browser
DEBUG - 2023-10-29 11:39:26 --> Total execution time: 0.4327
ERROR - 2023-10-29 11:39:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:39:29 --> Config Class Initialized
INFO - 2023-10-29 11:39:29 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:39:29 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:39:29 --> Utf8 Class Initialized
INFO - 2023-10-29 11:39:29 --> URI Class Initialized
INFO - 2023-10-29 11:39:29 --> Router Class Initialized
INFO - 2023-10-29 11:39:29 --> Output Class Initialized
INFO - 2023-10-29 11:39:29 --> Security Class Initialized
DEBUG - 2023-10-29 11:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:39:29 --> Input Class Initialized
INFO - 2023-10-29 11:39:29 --> Language Class Initialized
INFO - 2023-10-29 11:39:29 --> Loader Class Initialized
INFO - 2023-10-29 11:39:29 --> Helper loaded: url_helper
INFO - 2023-10-29 11:39:29 --> Helper loaded: form_helper
INFO - 2023-10-29 11:39:29 --> Helper loaded: file_helper
INFO - 2023-10-29 11:39:29 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:39:29 --> Form Validation Class Initialized
INFO - 2023-10-29 11:39:29 --> Upload Class Initialized
INFO - 2023-10-29 11:39:29 --> Model "M_auth" initialized
INFO - 2023-10-29 11:39:29 --> Model "M_user" initialized
INFO - 2023-10-29 11:39:29 --> Model "M_produk" initialized
INFO - 2023-10-29 11:39:29 --> Controller Class Initialized
DEBUG - 2023-10-29 11:39:29 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:39:29 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:39:29 --> Final output sent to browser
DEBUG - 2023-10-29 11:39:29 --> Total execution time: 0.1143
ERROR - 2023-10-29 11:39:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:39:35 --> Config Class Initialized
INFO - 2023-10-29 11:39:35 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:39:35 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:39:35 --> Utf8 Class Initialized
INFO - 2023-10-29 11:39:35 --> URI Class Initialized
INFO - 2023-10-29 11:39:35 --> Router Class Initialized
INFO - 2023-10-29 11:39:35 --> Output Class Initialized
INFO - 2023-10-29 11:39:35 --> Security Class Initialized
DEBUG - 2023-10-29 11:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:39:35 --> Input Class Initialized
INFO - 2023-10-29 11:39:35 --> Language Class Initialized
INFO - 2023-10-29 11:39:35 --> Loader Class Initialized
INFO - 2023-10-29 11:39:35 --> Helper loaded: url_helper
INFO - 2023-10-29 11:39:35 --> Helper loaded: form_helper
INFO - 2023-10-29 11:39:35 --> Helper loaded: file_helper
INFO - 2023-10-29 11:39:35 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:39:35 --> Form Validation Class Initialized
INFO - 2023-10-29 11:39:35 --> Upload Class Initialized
INFO - 2023-10-29 11:39:35 --> Model "M_auth" initialized
INFO - 2023-10-29 11:39:35 --> Model "M_user" initialized
INFO - 2023-10-29 11:39:35 --> Model "M_produk" initialized
INFO - 2023-10-29 11:39:35 --> Controller Class Initialized
DEBUG - 2023-10-29 11:39:35 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:39:35 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:39:35 --> Final output sent to browser
DEBUG - 2023-10-29 11:39:35 --> Total execution time: 0.0861
ERROR - 2023-10-29 11:39:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:39:36 --> Config Class Initialized
INFO - 2023-10-29 11:39:36 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:39:36 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:39:36 --> Utf8 Class Initialized
INFO - 2023-10-29 11:39:36 --> URI Class Initialized
INFO - 2023-10-29 11:39:36 --> Router Class Initialized
INFO - 2023-10-29 11:39:36 --> Output Class Initialized
INFO - 2023-10-29 11:39:36 --> Security Class Initialized
DEBUG - 2023-10-29 11:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:39:36 --> Input Class Initialized
INFO - 2023-10-29 11:39:36 --> Language Class Initialized
INFO - 2023-10-29 11:39:36 --> Loader Class Initialized
INFO - 2023-10-29 11:39:36 --> Helper loaded: url_helper
INFO - 2023-10-29 11:39:36 --> Helper loaded: form_helper
INFO - 2023-10-29 11:39:36 --> Helper loaded: file_helper
INFO - 2023-10-29 11:39:36 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:39:36 --> Form Validation Class Initialized
INFO - 2023-10-29 11:39:36 --> Upload Class Initialized
INFO - 2023-10-29 11:39:36 --> Model "M_auth" initialized
INFO - 2023-10-29 11:39:36 --> Model "M_user" initialized
INFO - 2023-10-29 11:39:36 --> Model "M_produk" initialized
INFO - 2023-10-29 11:39:36 --> Controller Class Initialized
DEBUG - 2023-10-29 11:39:36 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-29 11:39:36 --> Severity: Warning --> Undefined variable $clientKey C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php 7
INFO - 2023-10-29 11:39:36 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 11:39:36 --> Final output sent to browser
DEBUG - 2023-10-29 11:39:36 --> Total execution time: 0.4416
ERROR - 2023-10-29 11:39:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:39:50 --> Config Class Initialized
INFO - 2023-10-29 11:39:50 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:39:50 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:39:50 --> Utf8 Class Initialized
INFO - 2023-10-29 11:39:50 --> URI Class Initialized
INFO - 2023-10-29 11:39:50 --> Router Class Initialized
INFO - 2023-10-29 11:39:50 --> Output Class Initialized
INFO - 2023-10-29 11:39:50 --> Security Class Initialized
DEBUG - 2023-10-29 11:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:39:50 --> Input Class Initialized
INFO - 2023-10-29 11:39:50 --> Language Class Initialized
INFO - 2023-10-29 11:39:50 --> Loader Class Initialized
INFO - 2023-10-29 11:39:50 --> Helper loaded: url_helper
INFO - 2023-10-29 11:39:50 --> Helper loaded: form_helper
INFO - 2023-10-29 11:39:50 --> Helper loaded: file_helper
INFO - 2023-10-29 11:39:50 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:39:50 --> Form Validation Class Initialized
INFO - 2023-10-29 11:39:50 --> Upload Class Initialized
INFO - 2023-10-29 11:39:50 --> Model "M_auth" initialized
INFO - 2023-10-29 11:39:50 --> Model "M_user" initialized
INFO - 2023-10-29 11:39:50 --> Model "M_produk" initialized
INFO - 2023-10-29 11:39:50 --> Controller Class Initialized
DEBUG - 2023-10-29 11:39:50 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:39:50 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 11:39:50 --> Final output sent to browser
DEBUG - 2023-10-29 11:39:50 --> Total execution time: 0.4013
ERROR - 2023-10-29 11:39:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 11:39:51 --> Config Class Initialized
INFO - 2023-10-29 11:39:51 --> Hooks Class Initialized
DEBUG - 2023-10-29 11:39:51 --> UTF-8 Support Enabled
INFO - 2023-10-29 11:39:51 --> Utf8 Class Initialized
INFO - 2023-10-29 11:39:51 --> URI Class Initialized
INFO - 2023-10-29 11:39:51 --> Router Class Initialized
INFO - 2023-10-29 11:39:51 --> Output Class Initialized
INFO - 2023-10-29 11:39:51 --> Security Class Initialized
DEBUG - 2023-10-29 11:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 11:39:51 --> Input Class Initialized
INFO - 2023-10-29 11:39:51 --> Language Class Initialized
INFO - 2023-10-29 11:39:51 --> Loader Class Initialized
INFO - 2023-10-29 11:39:51 --> Helper loaded: url_helper
INFO - 2023-10-29 11:39:51 --> Helper loaded: form_helper
INFO - 2023-10-29 11:39:51 --> Helper loaded: file_helper
INFO - 2023-10-29 11:39:51 --> Database Driver Class Initialized
DEBUG - 2023-10-29 11:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 11:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 11:39:51 --> Form Validation Class Initialized
INFO - 2023-10-29 11:39:51 --> Upload Class Initialized
INFO - 2023-10-29 11:39:51 --> Model "M_auth" initialized
INFO - 2023-10-29 11:39:51 --> Model "M_user" initialized
INFO - 2023-10-29 11:39:51 --> Model "M_produk" initialized
INFO - 2023-10-29 11:39:51 --> Controller Class Initialized
DEBUG - 2023-10-29 11:39:51 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 11:39:51 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 11:39:51 --> Final output sent to browser
DEBUG - 2023-10-29 11:39:51 --> Total execution time: 0.0372
ERROR - 2023-10-29 14:43:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 14:43:24 --> Config Class Initialized
INFO - 2023-10-29 14:43:24 --> Hooks Class Initialized
DEBUG - 2023-10-29 14:43:24 --> UTF-8 Support Enabled
INFO - 2023-10-29 14:43:24 --> Utf8 Class Initialized
INFO - 2023-10-29 14:43:24 --> URI Class Initialized
INFO - 2023-10-29 14:43:24 --> Router Class Initialized
INFO - 2023-10-29 14:43:24 --> Output Class Initialized
INFO - 2023-10-29 14:43:24 --> Security Class Initialized
DEBUG - 2023-10-29 14:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 14:43:24 --> Input Class Initialized
INFO - 2023-10-29 14:43:24 --> Language Class Initialized
INFO - 2023-10-29 14:43:25 --> Loader Class Initialized
INFO - 2023-10-29 14:43:25 --> Helper loaded: url_helper
INFO - 2023-10-29 14:43:25 --> Helper loaded: form_helper
INFO - 2023-10-29 14:43:25 --> Helper loaded: file_helper
INFO - 2023-10-29 14:43:25 --> Database Driver Class Initialized
DEBUG - 2023-10-29 14:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 14:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 14:43:25 --> Form Validation Class Initialized
INFO - 2023-10-29 14:43:25 --> Upload Class Initialized
INFO - 2023-10-29 14:43:25 --> Model "M_auth" initialized
INFO - 2023-10-29 14:43:25 --> Model "M_user" initialized
INFO - 2023-10-29 14:43:25 --> Model "M_produk" initialized
INFO - 2023-10-29 14:43:25 --> Controller Class Initialized
DEBUG - 2023-10-29 14:43:25 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 14:43:25 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 14:43:25 --> Final output sent to browser
DEBUG - 2023-10-29 14:43:25 --> Total execution time: 0.7364
ERROR - 2023-10-29 14:43:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 14:43:26 --> Config Class Initialized
INFO - 2023-10-29 14:43:26 --> Hooks Class Initialized
DEBUG - 2023-10-29 14:43:26 --> UTF-8 Support Enabled
INFO - 2023-10-29 14:43:26 --> Utf8 Class Initialized
INFO - 2023-10-29 14:43:26 --> URI Class Initialized
INFO - 2023-10-29 14:43:26 --> Router Class Initialized
INFO - 2023-10-29 14:43:26 --> Output Class Initialized
INFO - 2023-10-29 14:43:26 --> Security Class Initialized
DEBUG - 2023-10-29 14:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 14:43:26 --> Input Class Initialized
INFO - 2023-10-29 14:43:26 --> Language Class Initialized
INFO - 2023-10-29 14:43:26 --> Loader Class Initialized
INFO - 2023-10-29 14:43:26 --> Helper loaded: url_helper
INFO - 2023-10-29 14:43:26 --> Helper loaded: form_helper
INFO - 2023-10-29 14:43:26 --> Helper loaded: file_helper
INFO - 2023-10-29 14:43:26 --> Database Driver Class Initialized
DEBUG - 2023-10-29 14:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 14:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 14:43:26 --> Form Validation Class Initialized
INFO - 2023-10-29 14:43:26 --> Upload Class Initialized
INFO - 2023-10-29 14:43:26 --> Model "M_auth" initialized
INFO - 2023-10-29 14:43:26 --> Model "M_user" initialized
INFO - 2023-10-29 14:43:26 --> Model "M_produk" initialized
INFO - 2023-10-29 14:43:26 --> Controller Class Initialized
DEBUG - 2023-10-29 14:43:26 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 14:43:29 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 14:43:29 --> Final output sent to browser
DEBUG - 2023-10-29 14:43:29 --> Total execution time: 3.1500
ERROR - 2023-10-29 14:43:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 14:43:35 --> Config Class Initialized
INFO - 2023-10-29 14:43:35 --> Hooks Class Initialized
DEBUG - 2023-10-29 14:43:35 --> UTF-8 Support Enabled
INFO - 2023-10-29 14:43:35 --> Utf8 Class Initialized
INFO - 2023-10-29 14:43:35 --> URI Class Initialized
INFO - 2023-10-29 14:43:35 --> Router Class Initialized
INFO - 2023-10-29 14:43:35 --> Output Class Initialized
INFO - 2023-10-29 14:43:35 --> Security Class Initialized
DEBUG - 2023-10-29 14:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 14:43:35 --> Input Class Initialized
INFO - 2023-10-29 14:43:35 --> Language Class Initialized
INFO - 2023-10-29 14:43:35 --> Loader Class Initialized
INFO - 2023-10-29 14:43:35 --> Helper loaded: url_helper
INFO - 2023-10-29 14:43:35 --> Helper loaded: form_helper
INFO - 2023-10-29 14:43:35 --> Helper loaded: file_helper
INFO - 2023-10-29 14:43:35 --> Database Driver Class Initialized
DEBUG - 2023-10-29 14:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 14:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 14:43:35 --> Form Validation Class Initialized
INFO - 2023-10-29 14:43:35 --> Upload Class Initialized
INFO - 2023-10-29 14:43:35 --> Model "M_auth" initialized
INFO - 2023-10-29 14:43:35 --> Model "M_user" initialized
INFO - 2023-10-29 14:43:35 --> Model "M_produk" initialized
INFO - 2023-10-29 14:43:35 --> Controller Class Initialized
DEBUG - 2023-10-29 14:43:35 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 14:43:35 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 14:43:35 --> Final output sent to browser
DEBUG - 2023-10-29 14:43:35 --> Total execution time: 0.0531
ERROR - 2023-10-29 14:43:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 14:43:36 --> Config Class Initialized
INFO - 2023-10-29 14:43:36 --> Hooks Class Initialized
DEBUG - 2023-10-29 14:43:36 --> UTF-8 Support Enabled
INFO - 2023-10-29 14:43:36 --> Utf8 Class Initialized
INFO - 2023-10-29 14:43:36 --> URI Class Initialized
INFO - 2023-10-29 14:43:36 --> Router Class Initialized
INFO - 2023-10-29 14:43:36 --> Output Class Initialized
INFO - 2023-10-29 14:43:36 --> Security Class Initialized
DEBUG - 2023-10-29 14:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 14:43:36 --> Input Class Initialized
INFO - 2023-10-29 14:43:36 --> Language Class Initialized
INFO - 2023-10-29 14:43:36 --> Loader Class Initialized
INFO - 2023-10-29 14:43:36 --> Helper loaded: url_helper
INFO - 2023-10-29 14:43:36 --> Helper loaded: form_helper
INFO - 2023-10-29 14:43:36 --> Helper loaded: file_helper
INFO - 2023-10-29 14:43:36 --> Database Driver Class Initialized
DEBUG - 2023-10-29 14:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 14:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 14:43:36 --> Form Validation Class Initialized
INFO - 2023-10-29 14:43:36 --> Upload Class Initialized
INFO - 2023-10-29 14:43:36 --> Model "M_auth" initialized
INFO - 2023-10-29 14:43:36 --> Model "M_user" initialized
INFO - 2023-10-29 14:43:36 --> Model "M_produk" initialized
INFO - 2023-10-29 14:43:36 --> Controller Class Initialized
DEBUG - 2023-10-29 14:43:36 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 14:43:36 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 14:43:36 --> Final output sent to browser
DEBUG - 2023-10-29 14:43:36 --> Total execution time: 0.0761
ERROR - 2023-10-29 14:43:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 14:43:36 --> Config Class Initialized
INFO - 2023-10-29 14:43:36 --> Hooks Class Initialized
DEBUG - 2023-10-29 14:43:37 --> UTF-8 Support Enabled
INFO - 2023-10-29 14:43:37 --> Utf8 Class Initialized
INFO - 2023-10-29 14:43:37 --> URI Class Initialized
INFO - 2023-10-29 14:43:37 --> Router Class Initialized
INFO - 2023-10-29 14:43:37 --> Output Class Initialized
INFO - 2023-10-29 14:43:37 --> Security Class Initialized
DEBUG - 2023-10-29 14:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 14:43:37 --> Input Class Initialized
INFO - 2023-10-29 14:43:37 --> Language Class Initialized
INFO - 2023-10-29 14:43:37 --> Loader Class Initialized
INFO - 2023-10-29 14:43:37 --> Helper loaded: url_helper
INFO - 2023-10-29 14:43:37 --> Helper loaded: form_helper
INFO - 2023-10-29 14:43:37 --> Helper loaded: file_helper
INFO - 2023-10-29 14:43:37 --> Database Driver Class Initialized
DEBUG - 2023-10-29 14:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 14:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 14:43:37 --> Form Validation Class Initialized
INFO - 2023-10-29 14:43:37 --> Upload Class Initialized
INFO - 2023-10-29 14:43:37 --> Model "M_auth" initialized
INFO - 2023-10-29 14:43:37 --> Model "M_user" initialized
INFO - 2023-10-29 14:43:37 --> Model "M_produk" initialized
INFO - 2023-10-29 14:43:37 --> Controller Class Initialized
DEBUG - 2023-10-29 14:43:37 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 14:43:38 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 14:43:38 --> Final output sent to browser
DEBUG - 2023-10-29 14:43:38 --> Total execution time: 1.3158
ERROR - 2023-10-29 14:43:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 14:43:40 --> Config Class Initialized
INFO - 2023-10-29 14:43:40 --> Hooks Class Initialized
DEBUG - 2023-10-29 14:43:40 --> UTF-8 Support Enabled
INFO - 2023-10-29 14:43:40 --> Utf8 Class Initialized
INFO - 2023-10-29 14:43:40 --> URI Class Initialized
INFO - 2023-10-29 14:43:40 --> Router Class Initialized
INFO - 2023-10-29 14:43:40 --> Output Class Initialized
INFO - 2023-10-29 14:43:40 --> Security Class Initialized
DEBUG - 2023-10-29 14:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 14:43:40 --> Input Class Initialized
INFO - 2023-10-29 14:43:40 --> Language Class Initialized
INFO - 2023-10-29 14:43:40 --> Loader Class Initialized
INFO - 2023-10-29 14:43:40 --> Helper loaded: url_helper
INFO - 2023-10-29 14:43:40 --> Helper loaded: form_helper
INFO - 2023-10-29 14:43:40 --> Helper loaded: file_helper
INFO - 2023-10-29 14:43:40 --> Database Driver Class Initialized
DEBUG - 2023-10-29 14:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 14:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 14:43:40 --> Form Validation Class Initialized
INFO - 2023-10-29 14:43:40 --> Upload Class Initialized
INFO - 2023-10-29 14:43:40 --> Model "M_auth" initialized
INFO - 2023-10-29 14:43:40 --> Model "M_user" initialized
INFO - 2023-10-29 14:43:40 --> Model "M_produk" initialized
INFO - 2023-10-29 14:43:40 --> Controller Class Initialized
DEBUG - 2023-10-29 14:43:40 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 14:43:40 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 14:43:40 --> Final output sent to browser
DEBUG - 2023-10-29 14:43:40 --> Total execution time: 0.0677
ERROR - 2023-10-29 14:43:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 14:43:41 --> Config Class Initialized
INFO - 2023-10-29 14:43:41 --> Hooks Class Initialized
DEBUG - 2023-10-29 14:43:41 --> UTF-8 Support Enabled
INFO - 2023-10-29 14:43:41 --> Utf8 Class Initialized
INFO - 2023-10-29 14:43:41 --> URI Class Initialized
INFO - 2023-10-29 14:43:41 --> Router Class Initialized
INFO - 2023-10-29 14:43:41 --> Output Class Initialized
INFO - 2023-10-29 14:43:41 --> Security Class Initialized
DEBUG - 2023-10-29 14:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 14:43:41 --> Input Class Initialized
INFO - 2023-10-29 14:43:41 --> Language Class Initialized
INFO - 2023-10-29 14:43:41 --> Loader Class Initialized
INFO - 2023-10-29 14:43:41 --> Helper loaded: url_helper
INFO - 2023-10-29 14:43:41 --> Helper loaded: form_helper
INFO - 2023-10-29 14:43:41 --> Helper loaded: file_helper
INFO - 2023-10-29 14:43:41 --> Database Driver Class Initialized
DEBUG - 2023-10-29 14:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 14:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 14:43:41 --> Form Validation Class Initialized
INFO - 2023-10-29 14:43:41 --> Upload Class Initialized
INFO - 2023-10-29 14:43:41 --> Model "M_auth" initialized
INFO - 2023-10-29 14:43:41 --> Model "M_user" initialized
INFO - 2023-10-29 14:43:41 --> Model "M_produk" initialized
INFO - 2023-10-29 14:43:41 --> Controller Class Initialized
DEBUG - 2023-10-29 14:43:41 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 14:43:41 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 14:43:41 --> Final output sent to browser
DEBUG - 2023-10-29 14:43:41 --> Total execution time: 0.1044
ERROR - 2023-10-29 14:55:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 14:55:19 --> Config Class Initialized
INFO - 2023-10-29 14:55:19 --> Hooks Class Initialized
DEBUG - 2023-10-29 14:55:19 --> UTF-8 Support Enabled
INFO - 2023-10-29 14:55:19 --> Utf8 Class Initialized
INFO - 2023-10-29 14:55:19 --> URI Class Initialized
INFO - 2023-10-29 14:55:19 --> Router Class Initialized
INFO - 2023-10-29 14:55:19 --> Output Class Initialized
INFO - 2023-10-29 14:55:19 --> Security Class Initialized
DEBUG - 2023-10-29 14:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 14:55:19 --> Input Class Initialized
INFO - 2023-10-29 14:55:19 --> Language Class Initialized
INFO - 2023-10-29 14:55:19 --> Loader Class Initialized
INFO - 2023-10-29 14:55:19 --> Helper loaded: url_helper
INFO - 2023-10-29 14:55:19 --> Helper loaded: form_helper
INFO - 2023-10-29 14:55:19 --> Helper loaded: file_helper
INFO - 2023-10-29 14:55:19 --> Database Driver Class Initialized
DEBUG - 2023-10-29 14:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 14:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 14:55:19 --> Form Validation Class Initialized
INFO - 2023-10-29 14:55:19 --> Upload Class Initialized
INFO - 2023-10-29 14:55:19 --> Model "M_auth" initialized
INFO - 2023-10-29 14:55:19 --> Model "M_user" initialized
INFO - 2023-10-29 14:55:19 --> Model "M_produk" initialized
INFO - 2023-10-29 14:55:19 --> Controller Class Initialized
DEBUG - 2023-10-29 14:55:19 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 14:55:19 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 14:55:19 --> Final output sent to browser
DEBUG - 2023-10-29 14:55:19 --> Total execution time: 0.6452
ERROR - 2023-10-29 14:55:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 14:55:51 --> Config Class Initialized
INFO - 2023-10-29 14:55:51 --> Hooks Class Initialized
DEBUG - 2023-10-29 14:55:51 --> UTF-8 Support Enabled
INFO - 2023-10-29 14:55:51 --> Utf8 Class Initialized
INFO - 2023-10-29 14:55:51 --> URI Class Initialized
INFO - 2023-10-29 14:55:51 --> Router Class Initialized
INFO - 2023-10-29 14:55:51 --> Output Class Initialized
INFO - 2023-10-29 14:55:51 --> Security Class Initialized
DEBUG - 2023-10-29 14:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 14:55:51 --> Input Class Initialized
INFO - 2023-10-29 14:55:51 --> Language Class Initialized
INFO - 2023-10-29 14:55:51 --> Loader Class Initialized
INFO - 2023-10-29 14:55:51 --> Helper loaded: url_helper
INFO - 2023-10-29 14:55:51 --> Helper loaded: form_helper
INFO - 2023-10-29 14:55:51 --> Helper loaded: file_helper
INFO - 2023-10-29 14:55:51 --> Database Driver Class Initialized
DEBUG - 2023-10-29 14:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 14:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 14:55:51 --> Form Validation Class Initialized
INFO - 2023-10-29 14:55:51 --> Upload Class Initialized
INFO - 2023-10-29 14:55:51 --> Model "M_auth" initialized
INFO - 2023-10-29 14:55:51 --> Model "M_user" initialized
INFO - 2023-10-29 14:55:51 --> Model "M_produk" initialized
INFO - 2023-10-29 14:55:51 --> Controller Class Initialized
DEBUG - 2023-10-29 14:55:51 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 14:55:51 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 14:55:51 --> Final output sent to browser
DEBUG - 2023-10-29 14:55:51 --> Total execution time: 0.1069
ERROR - 2023-10-29 14:55:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 14:55:55 --> Config Class Initialized
INFO - 2023-10-29 14:55:55 --> Hooks Class Initialized
DEBUG - 2023-10-29 14:55:56 --> UTF-8 Support Enabled
INFO - 2023-10-29 14:55:56 --> Utf8 Class Initialized
INFO - 2023-10-29 14:55:56 --> URI Class Initialized
DEBUG - 2023-10-29 14:55:56 --> No URI present. Default controller set.
INFO - 2023-10-29 14:55:56 --> Router Class Initialized
INFO - 2023-10-29 14:55:56 --> Output Class Initialized
INFO - 2023-10-29 14:55:56 --> Security Class Initialized
DEBUG - 2023-10-29 14:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 14:55:56 --> Input Class Initialized
INFO - 2023-10-29 14:55:56 --> Language Class Initialized
INFO - 2023-10-29 14:55:56 --> Loader Class Initialized
INFO - 2023-10-29 14:55:56 --> Helper loaded: url_helper
INFO - 2023-10-29 14:55:56 --> Helper loaded: form_helper
INFO - 2023-10-29 14:55:56 --> Helper loaded: file_helper
INFO - 2023-10-29 14:55:56 --> Database Driver Class Initialized
DEBUG - 2023-10-29 14:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 14:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 14:55:56 --> Form Validation Class Initialized
INFO - 2023-10-29 14:55:56 --> Upload Class Initialized
INFO - 2023-10-29 14:55:56 --> Model "M_auth" initialized
INFO - 2023-10-29 14:55:56 --> Model "M_user" initialized
INFO - 2023-10-29 14:55:56 --> Model "M_produk" initialized
INFO - 2023-10-29 14:55:56 --> Controller Class Initialized
INFO - 2023-10-29 14:55:56 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 14:55:56 --> Model "M_produk" initialized
DEBUG - 2023-10-29 14:55:56 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 14:55:56 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 14:55:56 --> Model "M_transaksi" initialized
INFO - 2023-10-29 14:55:56 --> Model "M_bank" initialized
INFO - 2023-10-29 14:55:56 --> Model "M_pesan" initialized
INFO - 2023-10-29 14:55:56 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-29 14:55:56 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-29 14:55:56 --> Final output sent to browser
DEBUG - 2023-10-29 14:55:56 --> Total execution time: 0.2572
ERROR - 2023-10-29 14:56:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 14:56:25 --> Config Class Initialized
INFO - 2023-10-29 14:56:25 --> Hooks Class Initialized
DEBUG - 2023-10-29 14:56:25 --> UTF-8 Support Enabled
INFO - 2023-10-29 14:56:25 --> Utf8 Class Initialized
INFO - 2023-10-29 14:56:25 --> URI Class Initialized
INFO - 2023-10-29 14:56:25 --> Router Class Initialized
INFO - 2023-10-29 14:56:25 --> Output Class Initialized
INFO - 2023-10-29 14:56:25 --> Security Class Initialized
DEBUG - 2023-10-29 14:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 14:56:25 --> Input Class Initialized
INFO - 2023-10-29 14:56:25 --> Language Class Initialized
INFO - 2023-10-29 14:56:25 --> Loader Class Initialized
INFO - 2023-10-29 14:56:25 --> Helper loaded: url_helper
INFO - 2023-10-29 14:56:25 --> Helper loaded: form_helper
INFO - 2023-10-29 14:56:25 --> Helper loaded: file_helper
INFO - 2023-10-29 14:56:25 --> Database Driver Class Initialized
DEBUG - 2023-10-29 14:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 14:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 14:56:25 --> Form Validation Class Initialized
INFO - 2023-10-29 14:56:25 --> Upload Class Initialized
INFO - 2023-10-29 14:56:25 --> Model "M_auth" initialized
INFO - 2023-10-29 14:56:25 --> Model "M_user" initialized
INFO - 2023-10-29 14:56:25 --> Model "M_produk" initialized
INFO - 2023-10-29 14:56:25 --> Controller Class Initialized
DEBUG - 2023-10-29 14:56:25 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 14:56:25 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 14:56:25 --> Final output sent to browser
DEBUG - 2023-10-29 14:56:25 --> Total execution time: 0.0298
ERROR - 2023-10-29 14:56:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 14:56:58 --> Config Class Initialized
INFO - 2023-10-29 14:56:58 --> Hooks Class Initialized
DEBUG - 2023-10-29 14:56:58 --> UTF-8 Support Enabled
INFO - 2023-10-29 14:56:58 --> Utf8 Class Initialized
INFO - 2023-10-29 14:56:58 --> URI Class Initialized
DEBUG - 2023-10-29 14:56:58 --> No URI present. Default controller set.
INFO - 2023-10-29 14:56:58 --> Router Class Initialized
INFO - 2023-10-29 14:56:58 --> Output Class Initialized
INFO - 2023-10-29 14:56:58 --> Security Class Initialized
DEBUG - 2023-10-29 14:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 14:56:58 --> Input Class Initialized
INFO - 2023-10-29 14:56:58 --> Language Class Initialized
INFO - 2023-10-29 14:56:58 --> Loader Class Initialized
INFO - 2023-10-29 14:56:58 --> Helper loaded: url_helper
INFO - 2023-10-29 14:56:58 --> Helper loaded: form_helper
INFO - 2023-10-29 14:56:58 --> Helper loaded: file_helper
INFO - 2023-10-29 14:56:58 --> Database Driver Class Initialized
DEBUG - 2023-10-29 14:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 14:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 14:56:58 --> Form Validation Class Initialized
INFO - 2023-10-29 14:56:58 --> Upload Class Initialized
INFO - 2023-10-29 14:56:58 --> Model "M_auth" initialized
INFO - 2023-10-29 14:56:58 --> Model "M_user" initialized
INFO - 2023-10-29 14:56:58 --> Model "M_produk" initialized
INFO - 2023-10-29 14:56:58 --> Controller Class Initialized
INFO - 2023-10-29 14:56:58 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 14:56:58 --> Model "M_produk" initialized
DEBUG - 2023-10-29 14:56:58 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 14:56:58 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 14:56:58 --> Model "M_transaksi" initialized
INFO - 2023-10-29 14:56:58 --> Model "M_bank" initialized
INFO - 2023-10-29 14:56:58 --> Model "M_pesan" initialized
INFO - 2023-10-29 14:56:58 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-29 14:56:58 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-29 14:56:58 --> Final output sent to browser
DEBUG - 2023-10-29 14:56:58 --> Total execution time: 0.0845
ERROR - 2023-10-29 14:57:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 14:57:06 --> Config Class Initialized
INFO - 2023-10-29 14:57:06 --> Hooks Class Initialized
DEBUG - 2023-10-29 14:57:06 --> UTF-8 Support Enabled
INFO - 2023-10-29 14:57:06 --> Utf8 Class Initialized
INFO - 2023-10-29 14:57:06 --> URI Class Initialized
INFO - 2023-10-29 14:57:06 --> Router Class Initialized
INFO - 2023-10-29 14:57:06 --> Output Class Initialized
INFO - 2023-10-29 14:57:06 --> Security Class Initialized
DEBUG - 2023-10-29 14:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 14:57:06 --> Input Class Initialized
INFO - 2023-10-29 14:57:06 --> Language Class Initialized
INFO - 2023-10-29 14:57:06 --> Loader Class Initialized
INFO - 2023-10-29 14:57:06 --> Helper loaded: url_helper
INFO - 2023-10-29 14:57:06 --> Helper loaded: form_helper
INFO - 2023-10-29 14:57:06 --> Helper loaded: file_helper
INFO - 2023-10-29 14:57:06 --> Database Driver Class Initialized
DEBUG - 2023-10-29 14:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 14:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 14:57:06 --> Form Validation Class Initialized
INFO - 2023-10-29 14:57:06 --> Upload Class Initialized
INFO - 2023-10-29 14:57:06 --> Model "M_auth" initialized
INFO - 2023-10-29 14:57:06 --> Model "M_user" initialized
INFO - 2023-10-29 14:57:06 --> Model "M_produk" initialized
INFO - 2023-10-29 14:57:06 --> Controller Class Initialized
DEBUG - 2023-10-29 14:57:06 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 14:57:06 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 14:57:06 --> Final output sent to browser
DEBUG - 2023-10-29 14:57:06 --> Total execution time: 0.0535
ERROR - 2023-10-29 14:57:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 14:57:24 --> Config Class Initialized
INFO - 2023-10-29 14:57:24 --> Hooks Class Initialized
DEBUG - 2023-10-29 14:57:24 --> UTF-8 Support Enabled
INFO - 2023-10-29 14:57:24 --> Utf8 Class Initialized
INFO - 2023-10-29 14:57:24 --> URI Class Initialized
INFO - 2023-10-29 14:57:24 --> Router Class Initialized
INFO - 2023-10-29 14:57:24 --> Output Class Initialized
INFO - 2023-10-29 14:57:24 --> Security Class Initialized
DEBUG - 2023-10-29 14:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 14:57:24 --> Input Class Initialized
INFO - 2023-10-29 14:57:24 --> Language Class Initialized
INFO - 2023-10-29 14:57:24 --> Loader Class Initialized
INFO - 2023-10-29 14:57:24 --> Helper loaded: url_helper
INFO - 2023-10-29 14:57:24 --> Helper loaded: form_helper
INFO - 2023-10-29 14:57:24 --> Helper loaded: file_helper
INFO - 2023-10-29 14:57:24 --> Database Driver Class Initialized
DEBUG - 2023-10-29 14:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 14:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 14:57:24 --> Form Validation Class Initialized
INFO - 2023-10-29 14:57:24 --> Upload Class Initialized
INFO - 2023-10-29 14:57:24 --> Model "M_auth" initialized
INFO - 2023-10-29 14:57:24 --> Model "M_user" initialized
INFO - 2023-10-29 14:57:24 --> Model "M_produk" initialized
INFO - 2023-10-29 14:57:24 --> Controller Class Initialized
DEBUG - 2023-10-29 14:57:24 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 14:57:27 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 14:57:27 --> Final output sent to browser
DEBUG - 2023-10-29 14:57:27 --> Total execution time: 2.2395
ERROR - 2023-10-29 14:58:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 14:58:01 --> Config Class Initialized
INFO - 2023-10-29 14:58:01 --> Hooks Class Initialized
DEBUG - 2023-10-29 14:58:01 --> UTF-8 Support Enabled
INFO - 2023-10-29 14:58:01 --> Utf8 Class Initialized
INFO - 2023-10-29 14:58:01 --> URI Class Initialized
INFO - 2023-10-29 14:58:01 --> Router Class Initialized
INFO - 2023-10-29 14:58:01 --> Output Class Initialized
INFO - 2023-10-29 14:58:01 --> Security Class Initialized
DEBUG - 2023-10-29 14:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 14:58:01 --> Input Class Initialized
INFO - 2023-10-29 14:58:01 --> Language Class Initialized
INFO - 2023-10-29 14:58:01 --> Loader Class Initialized
INFO - 2023-10-29 14:58:01 --> Helper loaded: url_helper
INFO - 2023-10-29 14:58:01 --> Helper loaded: form_helper
INFO - 2023-10-29 14:58:01 --> Helper loaded: file_helper
INFO - 2023-10-29 14:58:01 --> Database Driver Class Initialized
DEBUG - 2023-10-29 14:58:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 14:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 14:58:01 --> Form Validation Class Initialized
INFO - 2023-10-29 14:58:01 --> Upload Class Initialized
INFO - 2023-10-29 14:58:01 --> Model "M_auth" initialized
INFO - 2023-10-29 14:58:01 --> Model "M_user" initialized
INFO - 2023-10-29 14:58:01 --> Model "M_produk" initialized
INFO - 2023-10-29 14:58:01 --> Controller Class Initialized
DEBUG - 2023-10-29 14:58:01 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 14:58:01 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 14:58:01 --> Final output sent to browser
DEBUG - 2023-10-29 14:58:01 --> Total execution time: 0.0646
ERROR - 2023-10-29 14:58:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 14:58:02 --> Config Class Initialized
INFO - 2023-10-29 14:58:02 --> Hooks Class Initialized
DEBUG - 2023-10-29 14:58:02 --> UTF-8 Support Enabled
INFO - 2023-10-29 14:58:02 --> Utf8 Class Initialized
INFO - 2023-10-29 14:58:02 --> URI Class Initialized
INFO - 2023-10-29 14:58:02 --> Router Class Initialized
INFO - 2023-10-29 14:58:02 --> Output Class Initialized
INFO - 2023-10-29 14:58:02 --> Security Class Initialized
DEBUG - 2023-10-29 14:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 14:58:02 --> Input Class Initialized
INFO - 2023-10-29 14:58:02 --> Language Class Initialized
INFO - 2023-10-29 14:58:02 --> Loader Class Initialized
INFO - 2023-10-29 14:58:02 --> Helper loaded: url_helper
INFO - 2023-10-29 14:58:02 --> Helper loaded: form_helper
INFO - 2023-10-29 14:58:02 --> Helper loaded: file_helper
INFO - 2023-10-29 14:58:02 --> Database Driver Class Initialized
DEBUG - 2023-10-29 14:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 14:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 14:58:02 --> Form Validation Class Initialized
INFO - 2023-10-29 14:58:02 --> Upload Class Initialized
INFO - 2023-10-29 14:58:02 --> Model "M_auth" initialized
INFO - 2023-10-29 14:58:02 --> Model "M_user" initialized
INFO - 2023-10-29 14:58:02 --> Model "M_produk" initialized
INFO - 2023-10-29 14:58:02 --> Controller Class Initialized
DEBUG - 2023-10-29 14:58:02 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 14:58:02 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 14:58:02 --> Final output sent to browser
DEBUG - 2023-10-29 14:58:02 --> Total execution time: 0.0872
ERROR - 2023-10-29 14:58:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 14:58:04 --> Config Class Initialized
INFO - 2023-10-29 14:58:04 --> Hooks Class Initialized
DEBUG - 2023-10-29 14:58:04 --> UTF-8 Support Enabled
INFO - 2023-10-29 14:58:04 --> Utf8 Class Initialized
INFO - 2023-10-29 14:58:04 --> URI Class Initialized
INFO - 2023-10-29 14:58:04 --> Router Class Initialized
INFO - 2023-10-29 14:58:04 --> Output Class Initialized
INFO - 2023-10-29 14:58:04 --> Security Class Initialized
DEBUG - 2023-10-29 14:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 14:58:04 --> Input Class Initialized
INFO - 2023-10-29 14:58:04 --> Language Class Initialized
INFO - 2023-10-29 14:58:04 --> Loader Class Initialized
INFO - 2023-10-29 14:58:04 --> Helper loaded: url_helper
INFO - 2023-10-29 14:58:04 --> Helper loaded: form_helper
INFO - 2023-10-29 14:58:04 --> Helper loaded: file_helper
INFO - 2023-10-29 14:58:04 --> Database Driver Class Initialized
DEBUG - 2023-10-29 14:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 14:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 14:58:04 --> Form Validation Class Initialized
INFO - 2023-10-29 14:58:04 --> Upload Class Initialized
INFO - 2023-10-29 14:58:04 --> Model "M_auth" initialized
INFO - 2023-10-29 14:58:04 --> Model "M_user" initialized
INFO - 2023-10-29 14:58:04 --> Model "M_produk" initialized
INFO - 2023-10-29 14:58:04 --> Controller Class Initialized
DEBUG - 2023-10-29 14:58:04 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 14:58:05 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 14:58:05 --> Final output sent to browser
DEBUG - 2023-10-29 14:58:05 --> Total execution time: 1.3389
ERROR - 2023-10-29 14:58:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 14:58:15 --> Config Class Initialized
INFO - 2023-10-29 14:58:15 --> Hooks Class Initialized
DEBUG - 2023-10-29 14:58:15 --> UTF-8 Support Enabled
INFO - 2023-10-29 14:58:15 --> Utf8 Class Initialized
INFO - 2023-10-29 14:58:15 --> URI Class Initialized
INFO - 2023-10-29 14:58:15 --> Router Class Initialized
INFO - 2023-10-29 14:58:15 --> Output Class Initialized
INFO - 2023-10-29 14:58:15 --> Security Class Initialized
DEBUG - 2023-10-29 14:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 14:58:15 --> Input Class Initialized
INFO - 2023-10-29 14:58:15 --> Language Class Initialized
INFO - 2023-10-29 14:58:15 --> Loader Class Initialized
INFO - 2023-10-29 14:58:15 --> Helper loaded: url_helper
INFO - 2023-10-29 14:58:15 --> Helper loaded: form_helper
INFO - 2023-10-29 14:58:15 --> Helper loaded: file_helper
INFO - 2023-10-29 14:58:15 --> Database Driver Class Initialized
DEBUG - 2023-10-29 14:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 14:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 14:58:15 --> Form Validation Class Initialized
INFO - 2023-10-29 14:58:15 --> Upload Class Initialized
INFO - 2023-10-29 14:58:15 --> Model "M_auth" initialized
INFO - 2023-10-29 14:58:15 --> Model "M_user" initialized
INFO - 2023-10-29 14:58:15 --> Model "M_produk" initialized
INFO - 2023-10-29 14:58:15 --> Controller Class Initialized
DEBUG - 2023-10-29 14:58:15 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 14:58:15 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 14:58:15 --> Final output sent to browser
DEBUG - 2023-10-29 14:58:15 --> Total execution time: 0.0691
ERROR - 2023-10-29 14:58:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 14:58:22 --> Config Class Initialized
INFO - 2023-10-29 14:58:22 --> Hooks Class Initialized
DEBUG - 2023-10-29 14:58:22 --> UTF-8 Support Enabled
INFO - 2023-10-29 14:58:22 --> Utf8 Class Initialized
INFO - 2023-10-29 14:58:22 --> URI Class Initialized
INFO - 2023-10-29 14:58:22 --> Router Class Initialized
INFO - 2023-10-29 14:58:22 --> Output Class Initialized
INFO - 2023-10-29 14:58:22 --> Security Class Initialized
DEBUG - 2023-10-29 14:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 14:58:22 --> Input Class Initialized
INFO - 2023-10-29 14:58:22 --> Language Class Initialized
INFO - 2023-10-29 14:58:22 --> Loader Class Initialized
INFO - 2023-10-29 14:58:22 --> Helper loaded: url_helper
INFO - 2023-10-29 14:58:22 --> Helper loaded: form_helper
INFO - 2023-10-29 14:58:22 --> Helper loaded: file_helper
INFO - 2023-10-29 14:58:22 --> Database Driver Class Initialized
DEBUG - 2023-10-29 14:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 14:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 14:58:22 --> Form Validation Class Initialized
INFO - 2023-10-29 14:58:22 --> Upload Class Initialized
INFO - 2023-10-29 14:58:22 --> Model "M_auth" initialized
INFO - 2023-10-29 14:58:22 --> Model "M_user" initialized
INFO - 2023-10-29 14:58:22 --> Model "M_produk" initialized
INFO - 2023-10-29 14:58:22 --> Controller Class Initialized
DEBUG - 2023-10-29 14:58:22 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 14:58:24 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 14:58:24 --> Final output sent to browser
DEBUG - 2023-10-29 14:58:24 --> Total execution time: 1.7885
ERROR - 2023-10-29 15:00:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 15:00:55 --> Config Class Initialized
INFO - 2023-10-29 15:00:55 --> Hooks Class Initialized
DEBUG - 2023-10-29 15:00:55 --> UTF-8 Support Enabled
INFO - 2023-10-29 15:00:55 --> Utf8 Class Initialized
INFO - 2023-10-29 15:00:55 --> URI Class Initialized
INFO - 2023-10-29 15:00:55 --> Router Class Initialized
INFO - 2023-10-29 15:00:55 --> Output Class Initialized
INFO - 2023-10-29 15:00:55 --> Security Class Initialized
DEBUG - 2023-10-29 15:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 15:00:55 --> Input Class Initialized
INFO - 2023-10-29 15:00:55 --> Language Class Initialized
INFO - 2023-10-29 15:00:55 --> Loader Class Initialized
INFO - 2023-10-29 15:00:55 --> Helper loaded: url_helper
INFO - 2023-10-29 15:00:55 --> Helper loaded: form_helper
INFO - 2023-10-29 15:00:55 --> Helper loaded: file_helper
INFO - 2023-10-29 15:00:55 --> Database Driver Class Initialized
DEBUG - 2023-10-29 15:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 15:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 15:00:55 --> Form Validation Class Initialized
INFO - 2023-10-29 15:00:55 --> Upload Class Initialized
INFO - 2023-10-29 15:00:55 --> Model "M_auth" initialized
INFO - 2023-10-29 15:00:55 --> Model "M_user" initialized
INFO - 2023-10-29 15:00:55 --> Model "M_produk" initialized
INFO - 2023-10-29 15:00:55 --> Controller Class Initialized
DEBUG - 2023-10-29 15:00:55 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 15:00:55 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 15:00:55 --> Final output sent to browser
DEBUG - 2023-10-29 15:00:55 --> Total execution time: 0.0593
ERROR - 2023-10-29 15:00:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 15:00:57 --> Config Class Initialized
INFO - 2023-10-29 15:00:57 --> Hooks Class Initialized
DEBUG - 2023-10-29 15:00:57 --> UTF-8 Support Enabled
INFO - 2023-10-29 15:00:57 --> Utf8 Class Initialized
INFO - 2023-10-29 15:00:57 --> URI Class Initialized
DEBUG - 2023-10-29 15:00:57 --> No URI present. Default controller set.
INFO - 2023-10-29 15:00:57 --> Router Class Initialized
INFO - 2023-10-29 15:00:57 --> Output Class Initialized
INFO - 2023-10-29 15:00:57 --> Security Class Initialized
DEBUG - 2023-10-29 15:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 15:00:57 --> Input Class Initialized
INFO - 2023-10-29 15:00:57 --> Language Class Initialized
INFO - 2023-10-29 15:00:57 --> Loader Class Initialized
INFO - 2023-10-29 15:00:57 --> Helper loaded: url_helper
INFO - 2023-10-29 15:00:57 --> Helper loaded: form_helper
INFO - 2023-10-29 15:00:57 --> Helper loaded: file_helper
INFO - 2023-10-29 15:00:57 --> Database Driver Class Initialized
DEBUG - 2023-10-29 15:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 15:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 15:00:57 --> Form Validation Class Initialized
INFO - 2023-10-29 15:00:57 --> Upload Class Initialized
INFO - 2023-10-29 15:00:57 --> Model "M_auth" initialized
INFO - 2023-10-29 15:00:57 --> Model "M_user" initialized
INFO - 2023-10-29 15:00:57 --> Model "M_produk" initialized
INFO - 2023-10-29 15:00:57 --> Controller Class Initialized
INFO - 2023-10-29 15:00:57 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 15:00:57 --> Model "M_produk" initialized
DEBUG - 2023-10-29 15:00:57 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 15:00:57 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 15:00:57 --> Model "M_transaksi" initialized
INFO - 2023-10-29 15:00:57 --> Model "M_bank" initialized
INFO - 2023-10-29 15:00:57 --> Model "M_pesan" initialized
INFO - 2023-10-29 15:00:57 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-29 15:00:57 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-29 15:00:57 --> Final output sent to browser
DEBUG - 2023-10-29 15:00:57 --> Total execution time: 0.0912
ERROR - 2023-10-29 15:01:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 15:01:08 --> Config Class Initialized
INFO - 2023-10-29 15:01:08 --> Hooks Class Initialized
DEBUG - 2023-10-29 15:01:08 --> UTF-8 Support Enabled
INFO - 2023-10-29 15:01:08 --> Utf8 Class Initialized
INFO - 2023-10-29 15:01:08 --> URI Class Initialized
DEBUG - 2023-10-29 15:01:08 --> No URI present. Default controller set.
INFO - 2023-10-29 15:01:08 --> Router Class Initialized
INFO - 2023-10-29 15:01:08 --> Output Class Initialized
INFO - 2023-10-29 15:01:08 --> Security Class Initialized
DEBUG - 2023-10-29 15:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 15:01:08 --> Input Class Initialized
INFO - 2023-10-29 15:01:08 --> Language Class Initialized
INFO - 2023-10-29 15:01:08 --> Loader Class Initialized
INFO - 2023-10-29 15:01:08 --> Helper loaded: url_helper
INFO - 2023-10-29 15:01:08 --> Helper loaded: form_helper
INFO - 2023-10-29 15:01:08 --> Helper loaded: file_helper
INFO - 2023-10-29 15:01:08 --> Database Driver Class Initialized
DEBUG - 2023-10-29 15:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 15:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 15:01:08 --> Form Validation Class Initialized
INFO - 2023-10-29 15:01:08 --> Upload Class Initialized
INFO - 2023-10-29 15:01:08 --> Model "M_auth" initialized
INFO - 2023-10-29 15:01:08 --> Model "M_user" initialized
INFO - 2023-10-29 15:01:08 --> Model "M_produk" initialized
INFO - 2023-10-29 15:01:08 --> Controller Class Initialized
INFO - 2023-10-29 15:01:08 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 15:01:08 --> Model "M_produk" initialized
DEBUG - 2023-10-29 15:01:08 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 15:01:08 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 15:01:08 --> Model "M_transaksi" initialized
INFO - 2023-10-29 15:01:08 --> Model "M_bank" initialized
INFO - 2023-10-29 15:01:08 --> Model "M_pesan" initialized
INFO - 2023-10-29 15:01:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-10-29 15:01:08 --> Email Class Initialized
INFO - 2023-10-29 15:01:09 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-10-29 15:01:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 15:01:25 --> Config Class Initialized
INFO - 2023-10-29 15:01:25 --> Hooks Class Initialized
DEBUG - 2023-10-29 15:01:25 --> UTF-8 Support Enabled
INFO - 2023-10-29 15:01:25 --> Utf8 Class Initialized
INFO - 2023-10-29 15:01:25 --> URI Class Initialized
DEBUG - 2023-10-29 15:01:25 --> No URI present. Default controller set.
INFO - 2023-10-29 15:01:25 --> Router Class Initialized
INFO - 2023-10-29 15:01:25 --> Output Class Initialized
INFO - 2023-10-29 15:01:25 --> Security Class Initialized
DEBUG - 2023-10-29 15:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 15:01:25 --> Input Class Initialized
INFO - 2023-10-29 15:01:25 --> Language Class Initialized
INFO - 2023-10-29 15:01:25 --> Loader Class Initialized
INFO - 2023-10-29 15:01:25 --> Helper loaded: url_helper
INFO - 2023-10-29 15:01:25 --> Helper loaded: form_helper
INFO - 2023-10-29 15:01:25 --> Helper loaded: file_helper
INFO - 2023-10-29 15:01:25 --> Database Driver Class Initialized
DEBUG - 2023-10-29 15:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 15:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 15:01:25 --> Form Validation Class Initialized
INFO - 2023-10-29 15:01:25 --> Upload Class Initialized
INFO - 2023-10-29 15:01:25 --> Model "M_auth" initialized
INFO - 2023-10-29 15:01:25 --> Model "M_user" initialized
INFO - 2023-10-29 15:01:25 --> Model "M_produk" initialized
INFO - 2023-10-29 15:01:25 --> Controller Class Initialized
INFO - 2023-10-29 15:01:25 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 15:01:25 --> Model "M_produk" initialized
DEBUG - 2023-10-29 15:01:25 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 15:01:25 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 15:01:25 --> Model "M_transaksi" initialized
INFO - 2023-10-29 15:01:25 --> Model "M_bank" initialized
INFO - 2023-10-29 15:01:25 --> Model "M_pesan" initialized
INFO - 2023-10-29 15:01:25 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-29 15:01:25 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-29 15:01:25 --> Final output sent to browser
DEBUG - 2023-10-29 15:01:25 --> Total execution time: 0.0844
ERROR - 2023-10-29 15:01:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 15:01:34 --> Config Class Initialized
INFO - 2023-10-29 15:01:34 --> Hooks Class Initialized
DEBUG - 2023-10-29 15:01:34 --> UTF-8 Support Enabled
INFO - 2023-10-29 15:01:34 --> Utf8 Class Initialized
INFO - 2023-10-29 15:01:34 --> URI Class Initialized
INFO - 2023-10-29 15:01:34 --> Router Class Initialized
INFO - 2023-10-29 15:01:34 --> Output Class Initialized
INFO - 2023-10-29 15:01:34 --> Security Class Initialized
DEBUG - 2023-10-29 15:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 15:01:34 --> Input Class Initialized
INFO - 2023-10-29 15:01:34 --> Language Class Initialized
INFO - 2023-10-29 15:01:34 --> Loader Class Initialized
INFO - 2023-10-29 15:01:34 --> Helper loaded: url_helper
INFO - 2023-10-29 15:01:34 --> Helper loaded: form_helper
INFO - 2023-10-29 15:01:34 --> Helper loaded: file_helper
INFO - 2023-10-29 15:01:34 --> Database Driver Class Initialized
DEBUG - 2023-10-29 15:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 15:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 15:01:34 --> Form Validation Class Initialized
INFO - 2023-10-29 15:01:34 --> Upload Class Initialized
INFO - 2023-10-29 15:01:34 --> Model "M_auth" initialized
INFO - 2023-10-29 15:01:34 --> Model "M_user" initialized
INFO - 2023-10-29 15:01:34 --> Model "M_produk" initialized
INFO - 2023-10-29 15:01:34 --> Controller Class Initialized
INFO - 2023-10-29 15:01:34 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 15:01:34 --> Model "M_produk" initialized
DEBUG - 2023-10-29 15:01:34 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 15:01:34 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 15:01:34 --> Model "M_transaksi" initialized
INFO - 2023-10-29 15:01:34 --> Model "M_bank" initialized
INFO - 2023-10-29 15:01:34 --> Model "M_pesan" initialized
INFO - 2023-10-29 15:01:34 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-29 15:01:34 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-29 15:01:34 --> Final output sent to browser
DEBUG - 2023-10-29 15:01:34 --> Total execution time: 0.1251
ERROR - 2023-10-29 15:01:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 15:01:45 --> Config Class Initialized
INFO - 2023-10-29 15:01:45 --> Hooks Class Initialized
DEBUG - 2023-10-29 15:01:45 --> UTF-8 Support Enabled
INFO - 2023-10-29 15:01:45 --> Utf8 Class Initialized
INFO - 2023-10-29 15:01:45 --> URI Class Initialized
INFO - 2023-10-29 15:01:45 --> Router Class Initialized
INFO - 2023-10-29 15:01:45 --> Output Class Initialized
INFO - 2023-10-29 15:01:45 --> Security Class Initialized
DEBUG - 2023-10-29 15:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 15:01:45 --> Input Class Initialized
INFO - 2023-10-29 15:01:45 --> Language Class Initialized
INFO - 2023-10-29 15:01:45 --> Loader Class Initialized
INFO - 2023-10-29 15:01:45 --> Helper loaded: url_helper
INFO - 2023-10-29 15:01:45 --> Helper loaded: form_helper
INFO - 2023-10-29 15:01:45 --> Helper loaded: file_helper
INFO - 2023-10-29 15:01:45 --> Database Driver Class Initialized
DEBUG - 2023-10-29 15:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 15:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 15:01:45 --> Form Validation Class Initialized
INFO - 2023-10-29 15:01:45 --> Upload Class Initialized
INFO - 2023-10-29 15:01:45 --> Model "M_auth" initialized
INFO - 2023-10-29 15:01:45 --> Model "M_user" initialized
INFO - 2023-10-29 15:01:45 --> Model "M_produk" initialized
INFO - 2023-10-29 15:01:45 --> Controller Class Initialized
DEBUG - 2023-10-29 15:01:45 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 15:01:45 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 15:01:45 --> Final output sent to browser
DEBUG - 2023-10-29 15:01:45 --> Total execution time: 0.0590
ERROR - 2023-10-29 15:01:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 15:01:50 --> Config Class Initialized
INFO - 2023-10-29 15:01:50 --> Hooks Class Initialized
DEBUG - 2023-10-29 15:01:50 --> UTF-8 Support Enabled
INFO - 2023-10-29 15:01:50 --> Utf8 Class Initialized
INFO - 2023-10-29 15:01:50 --> URI Class Initialized
INFO - 2023-10-29 15:01:50 --> Router Class Initialized
INFO - 2023-10-29 15:01:50 --> Output Class Initialized
INFO - 2023-10-29 15:01:50 --> Security Class Initialized
DEBUG - 2023-10-29 15:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 15:01:50 --> Input Class Initialized
INFO - 2023-10-29 15:01:50 --> Language Class Initialized
INFO - 2023-10-29 15:01:50 --> Loader Class Initialized
INFO - 2023-10-29 15:01:50 --> Helper loaded: url_helper
INFO - 2023-10-29 15:01:50 --> Helper loaded: form_helper
INFO - 2023-10-29 15:01:50 --> Helper loaded: file_helper
INFO - 2023-10-29 15:01:50 --> Database Driver Class Initialized
DEBUG - 2023-10-29 15:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 15:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 15:01:50 --> Form Validation Class Initialized
INFO - 2023-10-29 15:01:50 --> Upload Class Initialized
INFO - 2023-10-29 15:01:50 --> Model "M_auth" initialized
INFO - 2023-10-29 15:01:50 --> Model "M_user" initialized
INFO - 2023-10-29 15:01:50 --> Model "M_produk" initialized
INFO - 2023-10-29 15:01:50 --> Controller Class Initialized
INFO - 2023-10-29 15:01:50 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 15:01:50 --> Model "M_produk" initialized
DEBUG - 2023-10-29 15:01:50 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 15:01:50 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 15:01:50 --> Model "M_transaksi" initialized
INFO - 2023-10-29 15:01:50 --> Model "M_bank" initialized
INFO - 2023-10-29 15:01:50 --> Model "M_pesan" initialized
INFO - 2023-10-29 15:01:50 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-29 15:01:50 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-29 15:01:50 --> Final output sent to browser
DEBUG - 2023-10-29 15:01:50 --> Total execution time: 0.0452
ERROR - 2023-10-29 15:01:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 15:01:52 --> Config Class Initialized
INFO - 2023-10-29 15:01:52 --> Hooks Class Initialized
DEBUG - 2023-10-29 15:01:52 --> UTF-8 Support Enabled
INFO - 2023-10-29 15:01:52 --> Utf8 Class Initialized
INFO - 2023-10-29 15:01:52 --> URI Class Initialized
INFO - 2023-10-29 15:01:52 --> Router Class Initialized
INFO - 2023-10-29 15:01:52 --> Output Class Initialized
INFO - 2023-10-29 15:01:52 --> Security Class Initialized
DEBUG - 2023-10-29 15:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 15:01:52 --> Input Class Initialized
INFO - 2023-10-29 15:01:52 --> Language Class Initialized
INFO - 2023-10-29 15:01:52 --> Loader Class Initialized
INFO - 2023-10-29 15:01:52 --> Helper loaded: url_helper
INFO - 2023-10-29 15:01:52 --> Helper loaded: form_helper
INFO - 2023-10-29 15:01:52 --> Helper loaded: file_helper
INFO - 2023-10-29 15:01:52 --> Database Driver Class Initialized
DEBUG - 2023-10-29 15:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 15:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 15:01:52 --> Form Validation Class Initialized
INFO - 2023-10-29 15:01:52 --> Upload Class Initialized
INFO - 2023-10-29 15:01:52 --> Model "M_auth" initialized
INFO - 2023-10-29 15:01:52 --> Model "M_user" initialized
INFO - 2023-10-29 15:01:52 --> Model "M_produk" initialized
INFO - 2023-10-29 15:01:52 --> Controller Class Initialized
INFO - 2023-10-29 15:01:52 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 15:01:52 --> Model "M_produk" initialized
DEBUG - 2023-10-29 15:01:52 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 15:01:52 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 15:01:52 --> Model "M_transaksi" initialized
INFO - 2023-10-29 15:01:52 --> Model "M_bank" initialized
INFO - 2023-10-29 15:01:52 --> Model "M_pesan" initialized
INFO - 2023-10-29 15:01:52 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-29 15:01:52 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_bayar_sekarang.php
INFO - 2023-10-29 15:01:52 --> Final output sent to browser
DEBUG - 2023-10-29 15:01:52 --> Total execution time: 0.0881
ERROR - 2023-10-29 15:01:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 15:01:52 --> Config Class Initialized
INFO - 2023-10-29 15:01:52 --> Hooks Class Initialized
DEBUG - 2023-10-29 15:01:52 --> UTF-8 Support Enabled
INFO - 2023-10-29 15:01:52 --> Utf8 Class Initialized
INFO - 2023-10-29 15:01:52 --> URI Class Initialized
INFO - 2023-10-29 15:01:52 --> Router Class Initialized
INFO - 2023-10-29 15:01:52 --> Output Class Initialized
INFO - 2023-10-29 15:01:52 --> Security Class Initialized
DEBUG - 2023-10-29 15:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 15:01:52 --> Input Class Initialized
INFO - 2023-10-29 15:01:52 --> Language Class Initialized
INFO - 2023-10-29 15:01:52 --> Loader Class Initialized
INFO - 2023-10-29 15:01:52 --> Helper loaded: url_helper
INFO - 2023-10-29 15:01:52 --> Helper loaded: form_helper
INFO - 2023-10-29 15:01:52 --> Helper loaded: file_helper
INFO - 2023-10-29 15:01:52 --> Database Driver Class Initialized
DEBUG - 2023-10-29 15:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 15:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 15:01:52 --> Form Validation Class Initialized
INFO - 2023-10-29 15:01:52 --> Upload Class Initialized
INFO - 2023-10-29 15:01:52 --> Model "M_auth" initialized
INFO - 2023-10-29 15:01:52 --> Model "M_user" initialized
INFO - 2023-10-29 15:01:52 --> Model "M_produk" initialized
INFO - 2023-10-29 15:01:52 --> Controller Class Initialized
INFO - 2023-10-29 15:01:52 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-10-29 15:01:52 --> Final output sent to browser
DEBUG - 2023-10-29 15:01:52 --> Total execution time: 0.0343
ERROR - 2023-10-29 15:03:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 15:03:11 --> Config Class Initialized
INFO - 2023-10-29 15:03:11 --> Hooks Class Initialized
DEBUG - 2023-10-29 15:03:11 --> UTF-8 Support Enabled
INFO - 2023-10-29 15:03:11 --> Utf8 Class Initialized
INFO - 2023-10-29 15:03:11 --> URI Class Initialized
INFO - 2023-10-29 15:03:11 --> Router Class Initialized
INFO - 2023-10-29 15:03:11 --> Output Class Initialized
INFO - 2023-10-29 15:03:11 --> Security Class Initialized
DEBUG - 2023-10-29 15:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 15:03:11 --> Input Class Initialized
INFO - 2023-10-29 15:03:11 --> Language Class Initialized
INFO - 2023-10-29 15:03:11 --> Loader Class Initialized
INFO - 2023-10-29 15:03:11 --> Helper loaded: url_helper
INFO - 2023-10-29 15:03:11 --> Helper loaded: form_helper
INFO - 2023-10-29 15:03:11 --> Helper loaded: file_helper
INFO - 2023-10-29 15:03:11 --> Database Driver Class Initialized
DEBUG - 2023-10-29 15:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 15:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 15:03:11 --> Form Validation Class Initialized
INFO - 2023-10-29 15:03:11 --> Upload Class Initialized
INFO - 2023-10-29 15:03:11 --> Model "M_auth" initialized
INFO - 2023-10-29 15:03:11 --> Model "M_user" initialized
INFO - 2023-10-29 15:03:11 --> Model "M_produk" initialized
INFO - 2023-10-29 15:03:11 --> Controller Class Initialized
INFO - 2023-10-29 15:03:11 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 15:03:11 --> Model "M_produk" initialized
DEBUG - 2023-10-29 15:03:11 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 15:03:11 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 15:03:11 --> Model "M_transaksi" initialized
INFO - 2023-10-29 15:03:11 --> Model "M_bank" initialized
INFO - 2023-10-29 15:03:11 --> Model "M_pesan" initialized
INFO - 2023-10-29 15:03:11 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-29 15:03:11 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-29 15:03:11 --> Final output sent to browser
DEBUG - 2023-10-29 15:03:11 --> Total execution time: 0.1488
ERROR - 2023-10-29 15:04:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 15:04:13 --> Config Class Initialized
INFO - 2023-10-29 15:04:13 --> Hooks Class Initialized
DEBUG - 2023-10-29 15:04:13 --> UTF-8 Support Enabled
INFO - 2023-10-29 15:04:13 --> Utf8 Class Initialized
INFO - 2023-10-29 15:04:13 --> URI Class Initialized
INFO - 2023-10-29 15:04:13 --> Router Class Initialized
INFO - 2023-10-29 15:04:13 --> Output Class Initialized
INFO - 2023-10-29 15:04:13 --> Security Class Initialized
DEBUG - 2023-10-29 15:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 15:04:13 --> Input Class Initialized
INFO - 2023-10-29 15:04:13 --> Language Class Initialized
INFO - 2023-10-29 15:04:13 --> Loader Class Initialized
INFO - 2023-10-29 15:04:13 --> Helper loaded: url_helper
INFO - 2023-10-29 15:04:13 --> Helper loaded: form_helper
INFO - 2023-10-29 15:04:13 --> Helper loaded: file_helper
INFO - 2023-10-29 15:04:13 --> Database Driver Class Initialized
DEBUG - 2023-10-29 15:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 15:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 15:04:13 --> Form Validation Class Initialized
INFO - 2023-10-29 15:04:13 --> Upload Class Initialized
INFO - 2023-10-29 15:04:13 --> Model "M_auth" initialized
INFO - 2023-10-29 15:04:13 --> Model "M_user" initialized
INFO - 2023-10-29 15:04:13 --> Model "M_produk" initialized
INFO - 2023-10-29 15:04:13 --> Controller Class Initialized
INFO - 2023-10-29 15:04:13 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 15:04:13 --> Model "M_produk" initialized
DEBUG - 2023-10-29 15:04:13 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 15:04:13 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 15:04:13 --> Model "M_transaksi" initialized
INFO - 2023-10-29 15:04:13 --> Model "M_bank" initialized
INFO - 2023-10-29 15:04:13 --> Model "M_pesan" initialized
ERROR - 2023-10-29 15:04:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 15:04:13 --> Config Class Initialized
INFO - 2023-10-29 15:04:13 --> Hooks Class Initialized
DEBUG - 2023-10-29 15:04:13 --> UTF-8 Support Enabled
INFO - 2023-10-29 15:04:13 --> Utf8 Class Initialized
INFO - 2023-10-29 15:04:13 --> URI Class Initialized
DEBUG - 2023-10-29 15:04:13 --> No URI present. Default controller set.
INFO - 2023-10-29 15:04:13 --> Router Class Initialized
INFO - 2023-10-29 15:04:13 --> Output Class Initialized
INFO - 2023-10-29 15:04:13 --> Security Class Initialized
DEBUG - 2023-10-29 15:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 15:04:13 --> Input Class Initialized
INFO - 2023-10-29 15:04:13 --> Language Class Initialized
INFO - 2023-10-29 15:04:13 --> Loader Class Initialized
INFO - 2023-10-29 15:04:13 --> Helper loaded: url_helper
INFO - 2023-10-29 15:04:13 --> Helper loaded: form_helper
INFO - 2023-10-29 15:04:13 --> Helper loaded: file_helper
INFO - 2023-10-29 15:04:13 --> Database Driver Class Initialized
DEBUG - 2023-10-29 15:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 15:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 15:04:13 --> Form Validation Class Initialized
INFO - 2023-10-29 15:04:13 --> Upload Class Initialized
INFO - 2023-10-29 15:04:13 --> Model "M_auth" initialized
INFO - 2023-10-29 15:04:13 --> Model "M_user" initialized
INFO - 2023-10-29 15:04:13 --> Model "M_produk" initialized
INFO - 2023-10-29 15:04:13 --> Controller Class Initialized
INFO - 2023-10-29 15:04:13 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 15:04:13 --> Model "M_produk" initialized
DEBUG - 2023-10-29 15:04:13 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 15:04:13 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 15:04:13 --> Model "M_transaksi" initialized
INFO - 2023-10-29 15:04:13 --> Model "M_bank" initialized
INFO - 2023-10-29 15:04:13 --> Model "M_pesan" initialized
INFO - 2023-10-29 15:04:13 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-29 15:04:13 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-29 15:04:13 --> Final output sent to browser
DEBUG - 2023-10-29 15:04:13 --> Total execution time: 0.0619
ERROR - 2023-10-29 15:04:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 15:04:16 --> Config Class Initialized
INFO - 2023-10-29 15:04:16 --> Hooks Class Initialized
DEBUG - 2023-10-29 15:04:16 --> UTF-8 Support Enabled
INFO - 2023-10-29 15:04:16 --> Utf8 Class Initialized
INFO - 2023-10-29 15:04:16 --> URI Class Initialized
INFO - 2023-10-29 15:04:16 --> Router Class Initialized
INFO - 2023-10-29 15:04:16 --> Output Class Initialized
INFO - 2023-10-29 15:04:16 --> Security Class Initialized
DEBUG - 2023-10-29 15:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 15:04:16 --> Input Class Initialized
INFO - 2023-10-29 15:04:16 --> Language Class Initialized
INFO - 2023-10-29 15:04:16 --> Loader Class Initialized
INFO - 2023-10-29 15:04:16 --> Helper loaded: url_helper
INFO - 2023-10-29 15:04:16 --> Helper loaded: form_helper
INFO - 2023-10-29 15:04:16 --> Helper loaded: file_helper
INFO - 2023-10-29 15:04:16 --> Database Driver Class Initialized
DEBUG - 2023-10-29 15:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 15:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 15:04:16 --> Form Validation Class Initialized
INFO - 2023-10-29 15:04:16 --> Upload Class Initialized
INFO - 2023-10-29 15:04:16 --> Model "M_auth" initialized
INFO - 2023-10-29 15:04:16 --> Model "M_user" initialized
INFO - 2023-10-29 15:04:16 --> Model "M_produk" initialized
INFO - 2023-10-29 15:04:16 --> Controller Class Initialized
DEBUG - 2023-10-29 15:04:16 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 15:04:16 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 15:04:16 --> Final output sent to browser
DEBUG - 2023-10-29 15:04:16 --> Total execution time: 0.0806
ERROR - 2023-10-29 15:04:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 15:04:18 --> Config Class Initialized
INFO - 2023-10-29 15:04:18 --> Hooks Class Initialized
DEBUG - 2023-10-29 15:04:18 --> UTF-8 Support Enabled
INFO - 2023-10-29 15:04:18 --> Utf8 Class Initialized
INFO - 2023-10-29 15:04:18 --> URI Class Initialized
INFO - 2023-10-29 15:04:18 --> Router Class Initialized
INFO - 2023-10-29 15:04:18 --> Output Class Initialized
INFO - 2023-10-29 15:04:18 --> Security Class Initialized
DEBUG - 2023-10-29 15:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 15:04:18 --> Input Class Initialized
INFO - 2023-10-29 15:04:18 --> Language Class Initialized
INFO - 2023-10-29 15:04:18 --> Loader Class Initialized
INFO - 2023-10-29 15:04:18 --> Helper loaded: url_helper
INFO - 2023-10-29 15:04:18 --> Helper loaded: form_helper
INFO - 2023-10-29 15:04:18 --> Helper loaded: file_helper
INFO - 2023-10-29 15:04:18 --> Database Driver Class Initialized
DEBUG - 2023-10-29 15:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 15:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 15:04:18 --> Form Validation Class Initialized
INFO - 2023-10-29 15:04:18 --> Upload Class Initialized
INFO - 2023-10-29 15:04:18 --> Model "M_auth" initialized
INFO - 2023-10-29 15:04:18 --> Model "M_user" initialized
INFO - 2023-10-29 15:04:18 --> Model "M_produk" initialized
INFO - 2023-10-29 15:04:18 --> Controller Class Initialized
DEBUG - 2023-10-29 15:04:18 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-29 15:04:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 15:04:25 --> Config Class Initialized
INFO - 2023-10-29 15:04:25 --> Hooks Class Initialized
DEBUG - 2023-10-29 15:04:25 --> UTF-8 Support Enabled
INFO - 2023-10-29 15:04:25 --> Utf8 Class Initialized
INFO - 2023-10-29 15:04:25 --> URI Class Initialized
DEBUG - 2023-10-29 15:04:25 --> No URI present. Default controller set.
INFO - 2023-10-29 15:04:25 --> Router Class Initialized
INFO - 2023-10-29 15:04:25 --> Output Class Initialized
INFO - 2023-10-29 15:04:25 --> Security Class Initialized
DEBUG - 2023-10-29 15:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 15:04:25 --> Input Class Initialized
INFO - 2023-10-29 15:04:25 --> Language Class Initialized
INFO - 2023-10-29 15:04:25 --> Loader Class Initialized
INFO - 2023-10-29 15:04:25 --> Helper loaded: url_helper
INFO - 2023-10-29 15:04:25 --> Helper loaded: form_helper
INFO - 2023-10-29 15:04:25 --> Helper loaded: file_helper
INFO - 2023-10-29 15:04:25 --> Database Driver Class Initialized
DEBUG - 2023-10-29 15:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 15:04:28 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 15:04:28 --> Final output sent to browser
DEBUG - 2023-10-29 15:04:28 --> Total execution time: 9.4611
INFO - 2023-10-29 15:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 15:04:28 --> Form Validation Class Initialized
INFO - 2023-10-29 15:04:28 --> Upload Class Initialized
INFO - 2023-10-29 15:04:28 --> Model "M_auth" initialized
INFO - 2023-10-29 15:04:28 --> Model "M_user" initialized
INFO - 2023-10-29 15:04:28 --> Model "M_produk" initialized
INFO - 2023-10-29 15:04:28 --> Controller Class Initialized
INFO - 2023-10-29 15:04:28 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 15:04:28 --> Model "M_produk" initialized
DEBUG - 2023-10-29 15:04:28 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 15:04:28 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 15:04:28 --> Model "M_transaksi" initialized
INFO - 2023-10-29 15:04:28 --> Model "M_bank" initialized
INFO - 2023-10-29 15:04:28 --> Model "M_pesan" initialized
INFO - 2023-10-29 15:04:28 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-29 15:04:28 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-29 15:04:28 --> Final output sent to browser
DEBUG - 2023-10-29 15:04:28 --> Total execution time: 2.9224
ERROR - 2023-10-29 15:09:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 15:09:30 --> Config Class Initialized
INFO - 2023-10-29 15:09:30 --> Hooks Class Initialized
DEBUG - 2023-10-29 15:09:30 --> UTF-8 Support Enabled
INFO - 2023-10-29 15:09:30 --> Utf8 Class Initialized
INFO - 2023-10-29 15:09:30 --> URI Class Initialized
DEBUG - 2023-10-29 15:09:30 --> No URI present. Default controller set.
INFO - 2023-10-29 15:09:30 --> Router Class Initialized
INFO - 2023-10-29 15:09:30 --> Output Class Initialized
INFO - 2023-10-29 15:09:30 --> Security Class Initialized
DEBUG - 2023-10-29 15:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 15:09:30 --> Input Class Initialized
INFO - 2023-10-29 15:09:30 --> Language Class Initialized
INFO - 2023-10-29 15:09:30 --> Loader Class Initialized
INFO - 2023-10-29 15:09:30 --> Helper loaded: url_helper
INFO - 2023-10-29 15:09:30 --> Helper loaded: form_helper
INFO - 2023-10-29 15:09:30 --> Helper loaded: file_helper
INFO - 2023-10-29 15:09:30 --> Database Driver Class Initialized
DEBUG - 2023-10-29 15:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 15:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 15:09:30 --> Form Validation Class Initialized
INFO - 2023-10-29 15:09:30 --> Upload Class Initialized
INFO - 2023-10-29 15:09:30 --> Model "M_auth" initialized
INFO - 2023-10-29 15:09:30 --> Model "M_user" initialized
INFO - 2023-10-29 15:09:30 --> Model "M_produk" initialized
INFO - 2023-10-29 15:09:30 --> Controller Class Initialized
INFO - 2023-10-29 15:09:30 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 15:09:30 --> Model "M_produk" initialized
DEBUG - 2023-10-29 15:09:30 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 15:09:30 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 15:09:30 --> Model "M_transaksi" initialized
INFO - 2023-10-29 15:09:30 --> Model "M_bank" initialized
INFO - 2023-10-29 15:09:30 --> Model "M_pesan" initialized
INFO - 2023-10-29 15:09:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-10-29 15:09:30 --> Email Class Initialized
INFO - 2023-10-29 15:09:32 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-10-29 15:09:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 15:09:37 --> Config Class Initialized
INFO - 2023-10-29 15:09:37 --> Hooks Class Initialized
DEBUG - 2023-10-29 15:09:37 --> UTF-8 Support Enabled
INFO - 2023-10-29 15:09:37 --> Utf8 Class Initialized
INFO - 2023-10-29 15:09:37 --> URI Class Initialized
DEBUG - 2023-10-29 15:09:37 --> No URI present. Default controller set.
INFO - 2023-10-29 15:09:37 --> Router Class Initialized
INFO - 2023-10-29 15:09:37 --> Output Class Initialized
INFO - 2023-10-29 15:09:37 --> Security Class Initialized
DEBUG - 2023-10-29 15:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 15:09:37 --> Input Class Initialized
INFO - 2023-10-29 15:09:37 --> Language Class Initialized
INFO - 2023-10-29 15:09:37 --> Loader Class Initialized
INFO - 2023-10-29 15:09:37 --> Helper loaded: url_helper
INFO - 2023-10-29 15:09:37 --> Helper loaded: form_helper
INFO - 2023-10-29 15:09:37 --> Helper loaded: file_helper
INFO - 2023-10-29 15:09:37 --> Database Driver Class Initialized
DEBUG - 2023-10-29 15:09:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 15:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 15:09:37 --> Form Validation Class Initialized
INFO - 2023-10-29 15:09:37 --> Upload Class Initialized
INFO - 2023-10-29 15:09:37 --> Model "M_auth" initialized
INFO - 2023-10-29 15:09:37 --> Model "M_user" initialized
INFO - 2023-10-29 15:09:37 --> Model "M_produk" initialized
INFO - 2023-10-29 15:09:37 --> Controller Class Initialized
INFO - 2023-10-29 15:09:37 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 15:09:37 --> Model "M_produk" initialized
DEBUG - 2023-10-29 15:09:37 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 15:09:37 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 15:09:37 --> Model "M_transaksi" initialized
INFO - 2023-10-29 15:09:38 --> Model "M_bank" initialized
INFO - 2023-10-29 15:09:38 --> Model "M_pesan" initialized
INFO - 2023-10-29 15:09:38 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-29 15:09:38 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-29 15:09:38 --> Final output sent to browser
DEBUG - 2023-10-29 15:09:38 --> Total execution time: 0.0986
ERROR - 2023-10-29 15:09:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 15:09:40 --> Config Class Initialized
INFO - 2023-10-29 15:09:40 --> Hooks Class Initialized
DEBUG - 2023-10-29 15:09:40 --> UTF-8 Support Enabled
INFO - 2023-10-29 15:09:40 --> Utf8 Class Initialized
INFO - 2023-10-29 15:09:40 --> URI Class Initialized
INFO - 2023-10-29 15:09:40 --> Router Class Initialized
INFO - 2023-10-29 15:09:40 --> Output Class Initialized
INFO - 2023-10-29 15:09:40 --> Security Class Initialized
DEBUG - 2023-10-29 15:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 15:09:40 --> Input Class Initialized
INFO - 2023-10-29 15:09:40 --> Language Class Initialized
INFO - 2023-10-29 15:09:40 --> Loader Class Initialized
INFO - 2023-10-29 15:09:40 --> Helper loaded: url_helper
INFO - 2023-10-29 15:09:40 --> Helper loaded: form_helper
INFO - 2023-10-29 15:09:40 --> Helper loaded: file_helper
INFO - 2023-10-29 15:09:40 --> Database Driver Class Initialized
DEBUG - 2023-10-29 15:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 15:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 15:09:40 --> Form Validation Class Initialized
INFO - 2023-10-29 15:09:40 --> Upload Class Initialized
INFO - 2023-10-29 15:09:40 --> Model "M_auth" initialized
INFO - 2023-10-29 15:09:40 --> Model "M_user" initialized
INFO - 2023-10-29 15:09:40 --> Model "M_produk" initialized
INFO - 2023-10-29 15:09:40 --> Controller Class Initialized
INFO - 2023-10-29 15:09:40 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 15:09:40 --> Model "M_produk" initialized
DEBUG - 2023-10-29 15:09:40 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 15:09:40 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 15:09:40 --> Model "M_transaksi" initialized
INFO - 2023-10-29 15:09:40 --> Model "M_bank" initialized
INFO - 2023-10-29 15:09:40 --> Model "M_pesan" initialized
INFO - 2023-10-29 15:09:40 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-29 15:09:40 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-29 15:09:40 --> Final output sent to browser
DEBUG - 2023-10-29 15:09:40 --> Total execution time: 0.0780
ERROR - 2023-10-29 16:16:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 16:16:10 --> Config Class Initialized
INFO - 2023-10-29 16:16:10 --> Hooks Class Initialized
DEBUG - 2023-10-29 16:16:10 --> UTF-8 Support Enabled
INFO - 2023-10-29 16:16:10 --> Utf8 Class Initialized
INFO - 2023-10-29 16:16:10 --> URI Class Initialized
DEBUG - 2023-10-29 16:16:10 --> No URI present. Default controller set.
INFO - 2023-10-29 16:16:10 --> Router Class Initialized
INFO - 2023-10-29 16:16:10 --> Output Class Initialized
INFO - 2023-10-29 16:16:10 --> Security Class Initialized
DEBUG - 2023-10-29 16:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 16:16:10 --> Input Class Initialized
INFO - 2023-10-29 16:16:10 --> Language Class Initialized
INFO - 2023-10-29 16:16:10 --> Loader Class Initialized
INFO - 2023-10-29 16:16:10 --> Helper loaded: url_helper
INFO - 2023-10-29 16:16:10 --> Helper loaded: form_helper
INFO - 2023-10-29 16:16:10 --> Helper loaded: file_helper
INFO - 2023-10-29 16:16:10 --> Database Driver Class Initialized
DEBUG - 2023-10-29 16:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 16:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 16:16:10 --> Form Validation Class Initialized
INFO - 2023-10-29 16:16:10 --> Upload Class Initialized
INFO - 2023-10-29 16:16:10 --> Model "M_auth" initialized
INFO - 2023-10-29 16:16:10 --> Model "M_user" initialized
INFO - 2023-10-29 16:16:10 --> Model "M_produk" initialized
INFO - 2023-10-29 16:16:10 --> Controller Class Initialized
INFO - 2023-10-29 16:16:10 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 16:16:10 --> Model "M_produk" initialized
DEBUG - 2023-10-29 16:16:10 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 16:16:10 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 16:16:10 --> Model "M_transaksi" initialized
INFO - 2023-10-29 16:16:10 --> Model "M_bank" initialized
INFO - 2023-10-29 16:16:10 --> Model "M_pesan" initialized
INFO - 2023-10-29 16:16:10 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-29 16:16:10 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-29 16:16:10 --> Final output sent to browser
DEBUG - 2023-10-29 16:16:10 --> Total execution time: 0.0519
ERROR - 2023-10-29 16:16:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 16:16:11 --> Config Class Initialized
INFO - 2023-10-29 16:16:11 --> Hooks Class Initialized
DEBUG - 2023-10-29 16:16:11 --> UTF-8 Support Enabled
INFO - 2023-10-29 16:16:11 --> Utf8 Class Initialized
INFO - 2023-10-29 16:16:11 --> URI Class Initialized
INFO - 2023-10-29 16:16:11 --> Router Class Initialized
INFO - 2023-10-29 16:16:11 --> Output Class Initialized
INFO - 2023-10-29 16:16:11 --> Security Class Initialized
DEBUG - 2023-10-29 16:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 16:16:11 --> Input Class Initialized
INFO - 2023-10-29 16:16:11 --> Language Class Initialized
INFO - 2023-10-29 16:16:11 --> Loader Class Initialized
INFO - 2023-10-29 16:16:11 --> Helper loaded: url_helper
INFO - 2023-10-29 16:16:11 --> Helper loaded: form_helper
INFO - 2023-10-29 16:16:11 --> Helper loaded: file_helper
INFO - 2023-10-29 16:16:11 --> Database Driver Class Initialized
DEBUG - 2023-10-29 16:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 16:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 16:16:11 --> Form Validation Class Initialized
INFO - 2023-10-29 16:16:11 --> Upload Class Initialized
INFO - 2023-10-29 16:16:11 --> Model "M_auth" initialized
INFO - 2023-10-29 16:16:11 --> Model "M_user" initialized
INFO - 2023-10-29 16:16:11 --> Model "M_produk" initialized
INFO - 2023-10-29 16:16:11 --> Controller Class Initialized
DEBUG - 2023-10-29 16:16:11 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 16:16:11 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 16:16:11 --> Final output sent to browser
DEBUG - 2023-10-29 16:16:11 --> Total execution time: 0.0789
ERROR - 2023-10-29 16:16:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 16:16:12 --> Config Class Initialized
INFO - 2023-10-29 16:16:12 --> Hooks Class Initialized
DEBUG - 2023-10-29 16:16:12 --> UTF-8 Support Enabled
INFO - 2023-10-29 16:16:12 --> Utf8 Class Initialized
INFO - 2023-10-29 16:16:12 --> URI Class Initialized
INFO - 2023-10-29 16:16:12 --> Router Class Initialized
INFO - 2023-10-29 16:16:12 --> Output Class Initialized
INFO - 2023-10-29 16:16:12 --> Security Class Initialized
DEBUG - 2023-10-29 16:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 16:16:12 --> Input Class Initialized
INFO - 2023-10-29 16:16:12 --> Language Class Initialized
INFO - 2023-10-29 16:16:12 --> Loader Class Initialized
INFO - 2023-10-29 16:16:12 --> Helper loaded: url_helper
INFO - 2023-10-29 16:16:12 --> Helper loaded: form_helper
INFO - 2023-10-29 16:16:12 --> Helper loaded: file_helper
INFO - 2023-10-29 16:16:12 --> Database Driver Class Initialized
DEBUG - 2023-10-29 16:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 16:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 16:16:12 --> Form Validation Class Initialized
INFO - 2023-10-29 16:16:12 --> Upload Class Initialized
INFO - 2023-10-29 16:16:12 --> Model "M_auth" initialized
INFO - 2023-10-29 16:16:12 --> Model "M_user" initialized
INFO - 2023-10-29 16:16:12 --> Model "M_produk" initialized
INFO - 2023-10-29 16:16:12 --> Controller Class Initialized
DEBUG - 2023-10-29 16:16:12 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 16:16:13 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 16:16:13 --> Final output sent to browser
DEBUG - 2023-10-29 16:16:13 --> Total execution time: 0.5268
ERROR - 2023-10-29 17:19:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 17:19:58 --> Config Class Initialized
INFO - 2023-10-29 17:19:58 --> Hooks Class Initialized
DEBUG - 2023-10-29 17:19:58 --> UTF-8 Support Enabled
INFO - 2023-10-29 17:19:58 --> Utf8 Class Initialized
INFO - 2023-10-29 17:19:58 --> URI Class Initialized
DEBUG - 2023-10-29 17:19:58 --> No URI present. Default controller set.
INFO - 2023-10-29 17:19:58 --> Router Class Initialized
INFO - 2023-10-29 17:19:58 --> Output Class Initialized
INFO - 2023-10-29 17:19:58 --> Security Class Initialized
DEBUG - 2023-10-29 17:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 17:19:58 --> Input Class Initialized
INFO - 2023-10-29 17:19:58 --> Language Class Initialized
INFO - 2023-10-29 17:19:58 --> Loader Class Initialized
INFO - 2023-10-29 17:19:58 --> Helper loaded: url_helper
INFO - 2023-10-29 17:19:58 --> Helper loaded: form_helper
INFO - 2023-10-29 17:19:58 --> Helper loaded: file_helper
INFO - 2023-10-29 17:19:58 --> Database Driver Class Initialized
DEBUG - 2023-10-29 17:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 17:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 17:19:58 --> Form Validation Class Initialized
INFO - 2023-10-29 17:19:58 --> Upload Class Initialized
INFO - 2023-10-29 17:19:58 --> Model "M_auth" initialized
INFO - 2023-10-29 17:19:58 --> Model "M_user" initialized
INFO - 2023-10-29 17:19:58 --> Model "M_produk" initialized
INFO - 2023-10-29 17:19:58 --> Controller Class Initialized
INFO - 2023-10-29 17:19:58 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 17:19:58 --> Model "M_produk" initialized
DEBUG - 2023-10-29 17:19:58 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 17:19:58 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 17:19:58 --> Model "M_transaksi" initialized
INFO - 2023-10-29 17:19:58 --> Model "M_bank" initialized
INFO - 2023-10-29 17:19:58 --> Model "M_pesan" initialized
INFO - 2023-10-29 17:19:58 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-29 17:19:58 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-29 17:19:58 --> Final output sent to browser
DEBUG - 2023-10-29 17:19:58 --> Total execution time: 0.0729
ERROR - 2023-10-29 17:22:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 17:22:39 --> Config Class Initialized
INFO - 2023-10-29 17:22:39 --> Hooks Class Initialized
DEBUG - 2023-10-29 17:22:39 --> UTF-8 Support Enabled
INFO - 2023-10-29 17:22:39 --> Utf8 Class Initialized
INFO - 2023-10-29 17:22:39 --> URI Class Initialized
INFO - 2023-10-29 17:22:39 --> Router Class Initialized
INFO - 2023-10-29 17:22:39 --> Output Class Initialized
INFO - 2023-10-29 17:22:39 --> Security Class Initialized
DEBUG - 2023-10-29 17:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 17:22:39 --> Input Class Initialized
INFO - 2023-10-29 17:22:39 --> Language Class Initialized
INFO - 2023-10-29 17:22:39 --> Loader Class Initialized
INFO - 2023-10-29 17:22:39 --> Helper loaded: url_helper
INFO - 2023-10-29 17:22:39 --> Helper loaded: form_helper
INFO - 2023-10-29 17:22:39 --> Helper loaded: file_helper
INFO - 2023-10-29 17:22:39 --> Database Driver Class Initialized
DEBUG - 2023-10-29 17:22:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 17:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 17:22:39 --> Form Validation Class Initialized
INFO - 2023-10-29 17:22:39 --> Upload Class Initialized
INFO - 2023-10-29 17:22:39 --> Model "M_auth" initialized
INFO - 2023-10-29 17:22:39 --> Model "M_user" initialized
INFO - 2023-10-29 17:22:39 --> Model "M_produk" initialized
INFO - 2023-10-29 17:22:39 --> Controller Class Initialized
INFO - 2023-10-29 17:22:39 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 17:22:39 --> Model "M_produk" initialized
DEBUG - 2023-10-29 17:22:39 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 17:22:39 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 17:22:39 --> Model "M_transaksi" initialized
INFO - 2023-10-29 17:22:39 --> Model "M_bank" initialized
INFO - 2023-10-29 17:22:39 --> Model "M_pesan" initialized
INFO - 2023-10-29 17:22:39 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-29 17:22:39 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_produk_detail.php
INFO - 2023-10-29 17:22:39 --> Final output sent to browser
DEBUG - 2023-10-29 17:22:39 --> Total execution time: 0.1764
ERROR - 2023-10-29 17:22:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 17:22:39 --> Config Class Initialized
INFO - 2023-10-29 17:22:39 --> Hooks Class Initialized
DEBUG - 2023-10-29 17:22:39 --> UTF-8 Support Enabled
INFO - 2023-10-29 17:22:39 --> Utf8 Class Initialized
INFO - 2023-10-29 17:22:39 --> URI Class Initialized
INFO - 2023-10-29 17:22:39 --> Router Class Initialized
INFO - 2023-10-29 17:22:39 --> Output Class Initialized
INFO - 2023-10-29 17:22:39 --> Security Class Initialized
DEBUG - 2023-10-29 17:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 17:22:39 --> Input Class Initialized
INFO - 2023-10-29 17:22:39 --> Language Class Initialized
INFO - 2023-10-29 17:22:39 --> Loader Class Initialized
INFO - 2023-10-29 17:22:39 --> Helper loaded: url_helper
INFO - 2023-10-29 17:22:39 --> Helper loaded: form_helper
INFO - 2023-10-29 17:22:39 --> Helper loaded: file_helper
INFO - 2023-10-29 17:22:39 --> Database Driver Class Initialized
DEBUG - 2023-10-29 17:22:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 17:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 17:22:39 --> Form Validation Class Initialized
INFO - 2023-10-29 17:22:39 --> Upload Class Initialized
INFO - 2023-10-29 17:22:39 --> Model "M_auth" initialized
INFO - 2023-10-29 17:22:39 --> Model "M_user" initialized
INFO - 2023-10-29 17:22:39 --> Model "M_produk" initialized
INFO - 2023-10-29 17:22:39 --> Controller Class Initialized
INFO - 2023-10-29 17:22:39 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-10-29 17:22:39 --> Final output sent to browser
DEBUG - 2023-10-29 17:22:39 --> Total execution time: 0.0277
ERROR - 2023-10-29 17:22:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 17:22:51 --> Config Class Initialized
INFO - 2023-10-29 17:22:51 --> Hooks Class Initialized
DEBUG - 2023-10-29 17:22:51 --> UTF-8 Support Enabled
INFO - 2023-10-29 17:22:51 --> Utf8 Class Initialized
INFO - 2023-10-29 17:22:51 --> URI Class Initialized
DEBUG - 2023-10-29 17:22:51 --> No URI present. Default controller set.
INFO - 2023-10-29 17:22:51 --> Router Class Initialized
INFO - 2023-10-29 17:22:51 --> Output Class Initialized
INFO - 2023-10-29 17:22:51 --> Security Class Initialized
DEBUG - 2023-10-29 17:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 17:22:51 --> Input Class Initialized
INFO - 2023-10-29 17:22:51 --> Language Class Initialized
INFO - 2023-10-29 17:22:51 --> Loader Class Initialized
INFO - 2023-10-29 17:22:51 --> Helper loaded: url_helper
INFO - 2023-10-29 17:22:51 --> Helper loaded: form_helper
INFO - 2023-10-29 17:22:51 --> Helper loaded: file_helper
INFO - 2023-10-29 17:22:51 --> Database Driver Class Initialized
DEBUG - 2023-10-29 17:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 17:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 17:22:51 --> Form Validation Class Initialized
INFO - 2023-10-29 17:22:51 --> Upload Class Initialized
INFO - 2023-10-29 17:22:51 --> Model "M_auth" initialized
INFO - 2023-10-29 17:22:51 --> Model "M_user" initialized
INFO - 2023-10-29 17:22:51 --> Model "M_produk" initialized
INFO - 2023-10-29 17:22:51 --> Controller Class Initialized
INFO - 2023-10-29 17:22:51 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 17:22:51 --> Model "M_produk" initialized
DEBUG - 2023-10-29 17:22:51 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 17:22:51 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 17:22:51 --> Model "M_transaksi" initialized
INFO - 2023-10-29 17:22:51 --> Model "M_bank" initialized
INFO - 2023-10-29 17:22:51 --> Model "M_pesan" initialized
INFO - 2023-10-29 17:22:51 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-29 17:22:51 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-29 17:22:51 --> Final output sent to browser
DEBUG - 2023-10-29 17:22:51 --> Total execution time: 0.1094
ERROR - 2023-10-29 17:24:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 17:24:24 --> Config Class Initialized
INFO - 2023-10-29 17:24:24 --> Hooks Class Initialized
DEBUG - 2023-10-29 17:24:24 --> UTF-8 Support Enabled
INFO - 2023-10-29 17:24:24 --> Utf8 Class Initialized
INFO - 2023-10-29 17:24:24 --> URI Class Initialized
INFO - 2023-10-29 17:24:24 --> Router Class Initialized
INFO - 2023-10-29 17:24:24 --> Output Class Initialized
INFO - 2023-10-29 17:24:24 --> Security Class Initialized
DEBUG - 2023-10-29 17:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 17:24:24 --> Input Class Initialized
INFO - 2023-10-29 17:24:24 --> Language Class Initialized
INFO - 2023-10-29 17:24:24 --> Loader Class Initialized
INFO - 2023-10-29 17:24:24 --> Helper loaded: url_helper
INFO - 2023-10-29 17:24:24 --> Helper loaded: form_helper
INFO - 2023-10-29 17:24:24 --> Helper loaded: file_helper
INFO - 2023-10-29 17:24:24 --> Database Driver Class Initialized
DEBUG - 2023-10-29 17:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 17:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 17:24:24 --> Form Validation Class Initialized
INFO - 2023-10-29 17:24:24 --> Upload Class Initialized
INFO - 2023-10-29 17:24:24 --> Model "M_auth" initialized
INFO - 2023-10-29 17:24:24 --> Model "M_user" initialized
INFO - 2023-10-29 17:24:24 --> Model "M_produk" initialized
INFO - 2023-10-29 17:24:24 --> Controller Class Initialized
INFO - 2023-10-29 17:24:24 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 17:24:24 --> Model "M_produk" initialized
DEBUG - 2023-10-29 17:24:24 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 17:24:24 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 17:24:24 --> Model "M_transaksi" initialized
INFO - 2023-10-29 17:24:24 --> Model "M_bank" initialized
INFO - 2023-10-29 17:24:24 --> Model "M_pesan" initialized
INFO - 2023-10-29 17:24:24 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-29 17:24:24 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_produk_detail.php
INFO - 2023-10-29 17:24:24 --> Final output sent to browser
DEBUG - 2023-10-29 17:24:24 --> Total execution time: 0.0739
ERROR - 2023-10-29 17:24:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 17:24:24 --> Config Class Initialized
INFO - 2023-10-29 17:24:24 --> Hooks Class Initialized
DEBUG - 2023-10-29 17:24:24 --> UTF-8 Support Enabled
INFO - 2023-10-29 17:24:24 --> Utf8 Class Initialized
INFO - 2023-10-29 17:24:24 --> URI Class Initialized
INFO - 2023-10-29 17:24:24 --> Router Class Initialized
INFO - 2023-10-29 17:24:24 --> Output Class Initialized
INFO - 2023-10-29 17:24:24 --> Security Class Initialized
DEBUG - 2023-10-29 17:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 17:24:24 --> Input Class Initialized
INFO - 2023-10-29 17:24:24 --> Language Class Initialized
INFO - 2023-10-29 17:24:24 --> Loader Class Initialized
INFO - 2023-10-29 17:24:24 --> Helper loaded: url_helper
INFO - 2023-10-29 17:24:24 --> Helper loaded: form_helper
INFO - 2023-10-29 17:24:24 --> Helper loaded: file_helper
INFO - 2023-10-29 17:24:24 --> Database Driver Class Initialized
DEBUG - 2023-10-29 17:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 17:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 17:24:24 --> Form Validation Class Initialized
INFO - 2023-10-29 17:24:24 --> Upload Class Initialized
INFO - 2023-10-29 17:24:24 --> Model "M_auth" initialized
INFO - 2023-10-29 17:24:24 --> Model "M_user" initialized
INFO - 2023-10-29 17:24:24 --> Model "M_produk" initialized
INFO - 2023-10-29 17:24:24 --> Controller Class Initialized
INFO - 2023-10-29 17:24:24 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-10-29 17:24:24 --> Final output sent to browser
DEBUG - 2023-10-29 17:24:24 --> Total execution time: 0.0421
ERROR - 2023-10-29 17:24:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 17:24:44 --> Config Class Initialized
INFO - 2023-10-29 17:24:44 --> Hooks Class Initialized
DEBUG - 2023-10-29 17:24:44 --> UTF-8 Support Enabled
INFO - 2023-10-29 17:24:44 --> Utf8 Class Initialized
INFO - 2023-10-29 17:24:44 --> URI Class Initialized
DEBUG - 2023-10-29 17:24:44 --> No URI present. Default controller set.
INFO - 2023-10-29 17:24:44 --> Router Class Initialized
INFO - 2023-10-29 17:24:44 --> Output Class Initialized
INFO - 2023-10-29 17:24:44 --> Security Class Initialized
DEBUG - 2023-10-29 17:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 17:24:44 --> Input Class Initialized
INFO - 2023-10-29 17:24:44 --> Language Class Initialized
INFO - 2023-10-29 17:24:44 --> Loader Class Initialized
INFO - 2023-10-29 17:24:44 --> Helper loaded: url_helper
INFO - 2023-10-29 17:24:44 --> Helper loaded: form_helper
INFO - 2023-10-29 17:24:44 --> Helper loaded: file_helper
INFO - 2023-10-29 17:24:44 --> Database Driver Class Initialized
DEBUG - 2023-10-29 17:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 17:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 17:24:44 --> Form Validation Class Initialized
INFO - 2023-10-29 17:24:44 --> Upload Class Initialized
INFO - 2023-10-29 17:24:44 --> Model "M_auth" initialized
INFO - 2023-10-29 17:24:44 --> Model "M_user" initialized
INFO - 2023-10-29 17:24:44 --> Model "M_produk" initialized
INFO - 2023-10-29 17:24:44 --> Controller Class Initialized
INFO - 2023-10-29 17:24:44 --> Model "M_pelanggan" initialized
INFO - 2023-10-29 17:24:44 --> Model "M_produk" initialized
DEBUG - 2023-10-29 17:24:44 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-29 17:24:44 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-29 17:24:44 --> Model "M_transaksi" initialized
INFO - 2023-10-29 17:24:44 --> Model "M_bank" initialized
INFO - 2023-10-29 17:24:44 --> Model "M_pesan" initialized
INFO - 2023-10-29 17:24:44 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-29 17:24:44 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-29 17:24:44 --> Final output sent to browser
DEBUG - 2023-10-29 17:24:44 --> Total execution time: 0.0939
ERROR - 2023-10-29 17:57:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 17:57:30 --> Config Class Initialized
INFO - 2023-10-29 17:57:30 --> Hooks Class Initialized
DEBUG - 2023-10-29 17:57:30 --> UTF-8 Support Enabled
INFO - 2023-10-29 17:57:30 --> Utf8 Class Initialized
INFO - 2023-10-29 17:57:30 --> URI Class Initialized
INFO - 2023-10-29 17:57:30 --> Router Class Initialized
INFO - 2023-10-29 17:57:30 --> Output Class Initialized
INFO - 2023-10-29 17:57:30 --> Security Class Initialized
DEBUG - 2023-10-29 17:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 17:57:30 --> Input Class Initialized
INFO - 2023-10-29 17:57:30 --> Language Class Initialized
INFO - 2023-10-29 17:57:30 --> Loader Class Initialized
INFO - 2023-10-29 17:57:30 --> Helper loaded: url_helper
INFO - 2023-10-29 17:57:30 --> Helper loaded: form_helper
INFO - 2023-10-29 17:57:30 --> Helper loaded: file_helper
INFO - 2023-10-29 17:57:30 --> Database Driver Class Initialized
DEBUG - 2023-10-29 17:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 17:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 17:57:30 --> Form Validation Class Initialized
INFO - 2023-10-29 17:57:30 --> Upload Class Initialized
INFO - 2023-10-29 17:57:30 --> Model "M_auth" initialized
INFO - 2023-10-29 17:57:30 --> Model "M_user" initialized
INFO - 2023-10-29 17:57:30 --> Model "M_produk" initialized
INFO - 2023-10-29 17:57:30 --> Controller Class Initialized
DEBUG - 2023-10-29 17:57:30 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 17:57:30 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 17:57:30 --> Final output sent to browser
DEBUG - 2023-10-29 17:57:30 --> Total execution time: 0.0465
ERROR - 2023-10-29 18:05:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:05:48 --> Config Class Initialized
INFO - 2023-10-29 18:05:48 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:05:48 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:05:48 --> Utf8 Class Initialized
INFO - 2023-10-29 18:05:48 --> URI Class Initialized
INFO - 2023-10-29 18:05:48 --> Router Class Initialized
INFO - 2023-10-29 18:05:48 --> Output Class Initialized
INFO - 2023-10-29 18:05:48 --> Security Class Initialized
DEBUG - 2023-10-29 18:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:05:48 --> Input Class Initialized
INFO - 2023-10-29 18:05:48 --> Language Class Initialized
INFO - 2023-10-29 18:05:48 --> Loader Class Initialized
INFO - 2023-10-29 18:05:48 --> Helper loaded: url_helper
INFO - 2023-10-29 18:05:48 --> Helper loaded: form_helper
INFO - 2023-10-29 18:05:48 --> Helper loaded: file_helper
INFO - 2023-10-29 18:05:48 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:05:48 --> Form Validation Class Initialized
INFO - 2023-10-29 18:05:48 --> Upload Class Initialized
INFO - 2023-10-29 18:05:48 --> Model "M_auth" initialized
INFO - 2023-10-29 18:05:48 --> Model "M_user" initialized
INFO - 2023-10-29 18:05:48 --> Model "M_produk" initialized
INFO - 2023-10-29 18:05:48 --> Controller Class Initialized
DEBUG - 2023-10-29 18:05:48 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:05:48 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:05:48 --> Final output sent to browser
DEBUG - 2023-10-29 18:05:48 --> Total execution time: 0.0667
ERROR - 2023-10-29 18:05:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:05:50 --> Config Class Initialized
INFO - 2023-10-29 18:05:50 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:05:50 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:05:50 --> Utf8 Class Initialized
INFO - 2023-10-29 18:05:50 --> URI Class Initialized
INFO - 2023-10-29 18:05:50 --> Router Class Initialized
INFO - 2023-10-29 18:05:50 --> Output Class Initialized
INFO - 2023-10-29 18:05:50 --> Security Class Initialized
DEBUG - 2023-10-29 18:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:05:50 --> Input Class Initialized
INFO - 2023-10-29 18:05:50 --> Language Class Initialized
INFO - 2023-10-29 18:05:50 --> Loader Class Initialized
INFO - 2023-10-29 18:05:50 --> Helper loaded: url_helper
INFO - 2023-10-29 18:05:50 --> Helper loaded: form_helper
INFO - 2023-10-29 18:05:50 --> Helper loaded: file_helper
INFO - 2023-10-29 18:05:50 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:05:50 --> Form Validation Class Initialized
INFO - 2023-10-29 18:05:50 --> Upload Class Initialized
INFO - 2023-10-29 18:05:50 --> Model "M_auth" initialized
INFO - 2023-10-29 18:05:50 --> Model "M_user" initialized
INFO - 2023-10-29 18:05:50 --> Model "M_produk" initialized
INFO - 2023-10-29 18:05:50 --> Controller Class Initialized
DEBUG - 2023-10-29 18:05:50 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:05:51 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 18:05:51 --> Final output sent to browser
DEBUG - 2023-10-29 18:05:51 --> Total execution time: 1.0393
ERROR - 2023-10-29 18:05:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:05:55 --> Config Class Initialized
INFO - 2023-10-29 18:05:55 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:05:55 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:05:55 --> Utf8 Class Initialized
INFO - 2023-10-29 18:05:55 --> URI Class Initialized
INFO - 2023-10-29 18:05:55 --> Router Class Initialized
INFO - 2023-10-29 18:05:55 --> Output Class Initialized
INFO - 2023-10-29 18:05:55 --> Security Class Initialized
DEBUG - 2023-10-29 18:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:05:55 --> Input Class Initialized
INFO - 2023-10-29 18:05:55 --> Language Class Initialized
INFO - 2023-10-29 18:05:55 --> Loader Class Initialized
INFO - 2023-10-29 18:05:55 --> Helper loaded: url_helper
INFO - 2023-10-29 18:05:55 --> Helper loaded: form_helper
INFO - 2023-10-29 18:05:55 --> Helper loaded: file_helper
INFO - 2023-10-29 18:05:55 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:05:55 --> Form Validation Class Initialized
INFO - 2023-10-29 18:05:55 --> Upload Class Initialized
INFO - 2023-10-29 18:05:55 --> Model "M_auth" initialized
INFO - 2023-10-29 18:05:55 --> Model "M_user" initialized
INFO - 2023-10-29 18:05:55 --> Model "M_produk" initialized
INFO - 2023-10-29 18:05:55 --> Controller Class Initialized
DEBUG - 2023-10-29 18:05:55 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:05:55 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:05:55 --> Final output sent to browser
DEBUG - 2023-10-29 18:05:55 --> Total execution time: 0.0648
ERROR - 2023-10-29 18:05:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:05:56 --> Config Class Initialized
INFO - 2023-10-29 18:05:56 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:05:56 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:05:56 --> Utf8 Class Initialized
INFO - 2023-10-29 18:05:56 --> URI Class Initialized
INFO - 2023-10-29 18:05:56 --> Router Class Initialized
INFO - 2023-10-29 18:05:56 --> Output Class Initialized
INFO - 2023-10-29 18:05:56 --> Security Class Initialized
DEBUG - 2023-10-29 18:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:05:56 --> Input Class Initialized
INFO - 2023-10-29 18:05:56 --> Language Class Initialized
INFO - 2023-10-29 18:05:56 --> Loader Class Initialized
INFO - 2023-10-29 18:05:56 --> Helper loaded: url_helper
INFO - 2023-10-29 18:05:56 --> Helper loaded: form_helper
INFO - 2023-10-29 18:05:56 --> Helper loaded: file_helper
INFO - 2023-10-29 18:05:56 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:05:56 --> Form Validation Class Initialized
INFO - 2023-10-29 18:05:56 --> Upload Class Initialized
INFO - 2023-10-29 18:05:56 --> Model "M_auth" initialized
INFO - 2023-10-29 18:05:56 --> Model "M_user" initialized
INFO - 2023-10-29 18:05:56 --> Model "M_produk" initialized
INFO - 2023-10-29 18:05:56 --> Controller Class Initialized
DEBUG - 2023-10-29 18:05:56 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:05:57 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 18:05:57 --> Final output sent to browser
DEBUG - 2023-10-29 18:05:57 --> Total execution time: 1.2171
ERROR - 2023-10-29 18:07:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:07:40 --> Config Class Initialized
INFO - 2023-10-29 18:07:40 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:07:40 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:07:40 --> Utf8 Class Initialized
INFO - 2023-10-29 18:07:40 --> URI Class Initialized
INFO - 2023-10-29 18:07:40 --> Router Class Initialized
INFO - 2023-10-29 18:07:40 --> Output Class Initialized
INFO - 2023-10-29 18:07:40 --> Security Class Initialized
DEBUG - 2023-10-29 18:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:07:40 --> Input Class Initialized
INFO - 2023-10-29 18:07:40 --> Language Class Initialized
ERROR - 2023-10-29 18:07:40 --> Severity: error --> Exception: Class "Config" not found C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Payment.php 68
ERROR - 2023-10-29 18:07:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:07:41 --> Config Class Initialized
INFO - 2023-10-29 18:07:41 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:07:41 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:07:41 --> Utf8 Class Initialized
INFO - 2023-10-29 18:07:41 --> URI Class Initialized
INFO - 2023-10-29 18:07:41 --> Router Class Initialized
INFO - 2023-10-29 18:07:41 --> Output Class Initialized
INFO - 2023-10-29 18:07:41 --> Security Class Initialized
DEBUG - 2023-10-29 18:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:07:41 --> Input Class Initialized
INFO - 2023-10-29 18:07:41 --> Language Class Initialized
ERROR - 2023-10-29 18:07:41 --> Severity: error --> Exception: Class "Config" not found C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Payment.php 68
ERROR - 2023-10-29 18:07:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:07:46 --> Config Class Initialized
INFO - 2023-10-29 18:07:46 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:07:46 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:07:46 --> Utf8 Class Initialized
INFO - 2023-10-29 18:07:46 --> URI Class Initialized
INFO - 2023-10-29 18:07:46 --> Router Class Initialized
INFO - 2023-10-29 18:07:46 --> Output Class Initialized
INFO - 2023-10-29 18:07:46 --> Security Class Initialized
DEBUG - 2023-10-29 18:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:07:46 --> Input Class Initialized
INFO - 2023-10-29 18:07:46 --> Language Class Initialized
ERROR - 2023-10-29 18:07:46 --> Severity: error --> Exception: Class "Config" not found C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Payment.php 68
ERROR - 2023-10-29 18:09:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:09:50 --> Config Class Initialized
INFO - 2023-10-29 18:09:50 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:09:50 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:09:50 --> Utf8 Class Initialized
INFO - 2023-10-29 18:09:50 --> URI Class Initialized
INFO - 2023-10-29 18:09:50 --> Router Class Initialized
INFO - 2023-10-29 18:09:50 --> Output Class Initialized
INFO - 2023-10-29 18:09:50 --> Security Class Initialized
DEBUG - 2023-10-29 18:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:09:50 --> Input Class Initialized
INFO - 2023-10-29 18:09:50 --> Language Class Initialized
ERROR - 2023-10-29 18:09:50 --> Severity: error --> Exception: Class "Config" not found C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Payment.php 68
ERROR - 2023-10-29 18:13:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:13:51 --> Config Class Initialized
INFO - 2023-10-29 18:13:51 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:13:51 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:13:51 --> Utf8 Class Initialized
INFO - 2023-10-29 18:13:51 --> URI Class Initialized
INFO - 2023-10-29 18:13:51 --> Router Class Initialized
INFO - 2023-10-29 18:13:51 --> Output Class Initialized
INFO - 2023-10-29 18:13:51 --> Security Class Initialized
DEBUG - 2023-10-29 18:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:13:51 --> Input Class Initialized
INFO - 2023-10-29 18:13:51 --> Language Class Initialized
INFO - 2023-10-29 18:13:51 --> Loader Class Initialized
INFO - 2023-10-29 18:13:51 --> Helper loaded: url_helper
INFO - 2023-10-29 18:13:51 --> Helper loaded: form_helper
INFO - 2023-10-29 18:13:51 --> Helper loaded: file_helper
INFO - 2023-10-29 18:13:51 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:13:51 --> Form Validation Class Initialized
INFO - 2023-10-29 18:13:51 --> Upload Class Initialized
INFO - 2023-10-29 18:13:51 --> Model "M_auth" initialized
INFO - 2023-10-29 18:13:51 --> Model "M_user" initialized
INFO - 2023-10-29 18:13:51 --> Model "M_produk" initialized
INFO - 2023-10-29 18:13:51 --> Controller Class Initialized
DEBUG - 2023-10-29 18:13:51 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:13:51 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:13:51 --> Final output sent to browser
DEBUG - 2023-10-29 18:13:51 --> Total execution time: 0.0773
ERROR - 2023-10-29 18:13:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:13:52 --> Config Class Initialized
INFO - 2023-10-29 18:13:52 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:13:52 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:13:52 --> Utf8 Class Initialized
INFO - 2023-10-29 18:13:52 --> URI Class Initialized
INFO - 2023-10-29 18:13:52 --> Router Class Initialized
INFO - 2023-10-29 18:13:52 --> Output Class Initialized
INFO - 2023-10-29 18:13:52 --> Security Class Initialized
DEBUG - 2023-10-29 18:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:13:52 --> Input Class Initialized
INFO - 2023-10-29 18:13:52 --> Language Class Initialized
INFO - 2023-10-29 18:13:52 --> Loader Class Initialized
INFO - 2023-10-29 18:13:52 --> Helper loaded: url_helper
INFO - 2023-10-29 18:13:52 --> Helper loaded: form_helper
INFO - 2023-10-29 18:13:52 --> Helper loaded: file_helper
INFO - 2023-10-29 18:13:52 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:13:52 --> Form Validation Class Initialized
INFO - 2023-10-29 18:13:52 --> Upload Class Initialized
INFO - 2023-10-29 18:13:52 --> Model "M_auth" initialized
INFO - 2023-10-29 18:13:52 --> Model "M_user" initialized
INFO - 2023-10-29 18:13:52 --> Model "M_produk" initialized
INFO - 2023-10-29 18:13:52 --> Controller Class Initialized
DEBUG - 2023-10-29 18:13:52 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:13:53 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 18:13:53 --> Final output sent to browser
DEBUG - 2023-10-29 18:13:53 --> Total execution time: 1.0401
ERROR - 2023-10-29 18:14:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:14:03 --> Config Class Initialized
INFO - 2023-10-29 18:14:03 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:14:03 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:14:03 --> Utf8 Class Initialized
INFO - 2023-10-29 18:14:03 --> URI Class Initialized
INFO - 2023-10-29 18:14:03 --> Router Class Initialized
INFO - 2023-10-29 18:14:03 --> Output Class Initialized
INFO - 2023-10-29 18:14:03 --> Security Class Initialized
DEBUG - 2023-10-29 18:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:14:03 --> Input Class Initialized
INFO - 2023-10-29 18:14:03 --> Language Class Initialized
INFO - 2023-10-29 18:14:03 --> Loader Class Initialized
INFO - 2023-10-29 18:14:03 --> Helper loaded: url_helper
INFO - 2023-10-29 18:14:03 --> Helper loaded: form_helper
INFO - 2023-10-29 18:14:03 --> Helper loaded: file_helper
INFO - 2023-10-29 18:14:03 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:14:03 --> Form Validation Class Initialized
INFO - 2023-10-29 18:14:03 --> Upload Class Initialized
INFO - 2023-10-29 18:14:03 --> Model "M_auth" initialized
INFO - 2023-10-29 18:14:03 --> Model "M_user" initialized
INFO - 2023-10-29 18:14:03 --> Model "M_produk" initialized
INFO - 2023-10-29 18:14:03 --> Controller Class Initialized
DEBUG - 2023-10-29 18:14:03 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:14:04 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 18:14:04 --> Final output sent to browser
DEBUG - 2023-10-29 18:14:04 --> Total execution time: 0.5664
ERROR - 2023-10-29 18:19:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:19:34 --> Config Class Initialized
INFO - 2023-10-29 18:19:34 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:19:34 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:19:34 --> Utf8 Class Initialized
INFO - 2023-10-29 18:19:34 --> URI Class Initialized
INFO - 2023-10-29 18:19:34 --> Router Class Initialized
INFO - 2023-10-29 18:19:34 --> Output Class Initialized
INFO - 2023-10-29 18:19:34 --> Security Class Initialized
DEBUG - 2023-10-29 18:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:19:34 --> Input Class Initialized
INFO - 2023-10-29 18:19:34 --> Language Class Initialized
INFO - 2023-10-29 18:19:34 --> Loader Class Initialized
INFO - 2023-10-29 18:19:34 --> Helper loaded: url_helper
INFO - 2023-10-29 18:19:34 --> Helper loaded: form_helper
INFO - 2023-10-29 18:19:34 --> Helper loaded: file_helper
INFO - 2023-10-29 18:19:34 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:19:34 --> Form Validation Class Initialized
INFO - 2023-10-29 18:19:34 --> Upload Class Initialized
INFO - 2023-10-29 18:19:34 --> Model "M_auth" initialized
INFO - 2023-10-29 18:19:34 --> Model "M_user" initialized
INFO - 2023-10-29 18:19:34 --> Model "M_produk" initialized
INFO - 2023-10-29 18:19:34 --> Controller Class Initialized
DEBUG - 2023-10-29 18:19:34 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:19:34 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:19:34 --> Final output sent to browser
DEBUG - 2023-10-29 18:19:34 --> Total execution time: 0.0528
ERROR - 2023-10-29 18:19:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:19:35 --> Config Class Initialized
INFO - 2023-10-29 18:19:35 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:19:35 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:19:35 --> Utf8 Class Initialized
INFO - 2023-10-29 18:19:35 --> URI Class Initialized
INFO - 2023-10-29 18:19:35 --> Router Class Initialized
INFO - 2023-10-29 18:19:35 --> Output Class Initialized
INFO - 2023-10-29 18:19:35 --> Security Class Initialized
DEBUG - 2023-10-29 18:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:19:35 --> Input Class Initialized
INFO - 2023-10-29 18:19:35 --> Language Class Initialized
INFO - 2023-10-29 18:19:35 --> Loader Class Initialized
INFO - 2023-10-29 18:19:35 --> Helper loaded: url_helper
INFO - 2023-10-29 18:19:35 --> Helper loaded: form_helper
INFO - 2023-10-29 18:19:35 --> Helper loaded: file_helper
INFO - 2023-10-29 18:19:35 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:19:35 --> Form Validation Class Initialized
INFO - 2023-10-29 18:19:35 --> Upload Class Initialized
INFO - 2023-10-29 18:19:35 --> Model "M_auth" initialized
INFO - 2023-10-29 18:19:35 --> Model "M_user" initialized
INFO - 2023-10-29 18:19:35 --> Model "M_produk" initialized
INFO - 2023-10-29 18:19:35 --> Controller Class Initialized
DEBUG - 2023-10-29 18:19:35 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-29 18:19:36 --> Severity: error --> Exception: Undefined constant "snapToken" C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Payment.php 49
ERROR - 2023-10-29 18:19:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:19:42 --> Config Class Initialized
INFO - 2023-10-29 18:19:42 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:19:42 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:19:42 --> Utf8 Class Initialized
INFO - 2023-10-29 18:19:42 --> URI Class Initialized
INFO - 2023-10-29 18:19:42 --> Router Class Initialized
INFO - 2023-10-29 18:19:42 --> Output Class Initialized
INFO - 2023-10-29 18:19:42 --> Security Class Initialized
DEBUG - 2023-10-29 18:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:19:42 --> Input Class Initialized
INFO - 2023-10-29 18:19:42 --> Language Class Initialized
INFO - 2023-10-29 18:19:42 --> Loader Class Initialized
INFO - 2023-10-29 18:19:42 --> Helper loaded: url_helper
INFO - 2023-10-29 18:19:42 --> Helper loaded: form_helper
INFO - 2023-10-29 18:19:42 --> Helper loaded: file_helper
INFO - 2023-10-29 18:19:42 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:19:42 --> Form Validation Class Initialized
INFO - 2023-10-29 18:19:42 --> Upload Class Initialized
INFO - 2023-10-29 18:19:42 --> Model "M_auth" initialized
INFO - 2023-10-29 18:19:42 --> Model "M_user" initialized
INFO - 2023-10-29 18:19:42 --> Model "M_produk" initialized
INFO - 2023-10-29 18:19:42 --> Controller Class Initialized
DEBUG - 2023-10-29 18:19:42 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-29 18:19:43 --> Severity: error --> Exception: Call to undefined function snapToken() C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Payment.php 49
ERROR - 2023-10-29 18:19:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:19:45 --> Config Class Initialized
INFO - 2023-10-29 18:19:45 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:19:45 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:19:45 --> Utf8 Class Initialized
INFO - 2023-10-29 18:19:45 --> URI Class Initialized
INFO - 2023-10-29 18:19:45 --> Router Class Initialized
INFO - 2023-10-29 18:19:45 --> Output Class Initialized
INFO - 2023-10-29 18:19:45 --> Security Class Initialized
DEBUG - 2023-10-29 18:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:19:45 --> Input Class Initialized
INFO - 2023-10-29 18:19:45 --> Language Class Initialized
INFO - 2023-10-29 18:19:45 --> Loader Class Initialized
INFO - 2023-10-29 18:19:45 --> Helper loaded: url_helper
INFO - 2023-10-29 18:19:45 --> Helper loaded: form_helper
INFO - 2023-10-29 18:19:45 --> Helper loaded: file_helper
INFO - 2023-10-29 18:19:45 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:19:45 --> Form Validation Class Initialized
INFO - 2023-10-29 18:19:45 --> Upload Class Initialized
INFO - 2023-10-29 18:19:45 --> Model "M_auth" initialized
INFO - 2023-10-29 18:19:45 --> Model "M_user" initialized
INFO - 2023-10-29 18:19:45 --> Model "M_produk" initialized
INFO - 2023-10-29 18:19:45 --> Controller Class Initialized
DEBUG - 2023-10-29 18:19:45 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:19:45 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:19:45 --> Final output sent to browser
DEBUG - 2023-10-29 18:19:45 --> Total execution time: 0.0532
ERROR - 2023-10-29 18:19:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:19:46 --> Config Class Initialized
INFO - 2023-10-29 18:19:46 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:19:46 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:19:46 --> Utf8 Class Initialized
INFO - 2023-10-29 18:19:46 --> URI Class Initialized
INFO - 2023-10-29 18:19:46 --> Router Class Initialized
INFO - 2023-10-29 18:19:46 --> Output Class Initialized
INFO - 2023-10-29 18:19:46 --> Security Class Initialized
DEBUG - 2023-10-29 18:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:19:46 --> Input Class Initialized
INFO - 2023-10-29 18:19:46 --> Language Class Initialized
INFO - 2023-10-29 18:19:46 --> Loader Class Initialized
INFO - 2023-10-29 18:19:46 --> Helper loaded: url_helper
INFO - 2023-10-29 18:19:46 --> Helper loaded: form_helper
INFO - 2023-10-29 18:19:46 --> Helper loaded: file_helper
INFO - 2023-10-29 18:19:46 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:19:46 --> Form Validation Class Initialized
INFO - 2023-10-29 18:19:46 --> Upload Class Initialized
INFO - 2023-10-29 18:19:46 --> Model "M_auth" initialized
INFO - 2023-10-29 18:19:46 --> Model "M_user" initialized
INFO - 2023-10-29 18:19:46 --> Model "M_produk" initialized
INFO - 2023-10-29 18:19:46 --> Controller Class Initialized
DEBUG - 2023-10-29 18:19:46 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:19:46 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:19:46 --> Final output sent to browser
DEBUG - 2023-10-29 18:19:46 --> Total execution time: 0.0214
ERROR - 2023-10-29 18:19:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:19:46 --> Config Class Initialized
INFO - 2023-10-29 18:19:46 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:19:46 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:19:46 --> Utf8 Class Initialized
INFO - 2023-10-29 18:19:46 --> URI Class Initialized
INFO - 2023-10-29 18:19:46 --> Router Class Initialized
INFO - 2023-10-29 18:19:46 --> Output Class Initialized
INFO - 2023-10-29 18:19:46 --> Security Class Initialized
DEBUG - 2023-10-29 18:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:19:46 --> Input Class Initialized
INFO - 2023-10-29 18:19:46 --> Language Class Initialized
INFO - 2023-10-29 18:19:46 --> Loader Class Initialized
INFO - 2023-10-29 18:19:46 --> Helper loaded: url_helper
INFO - 2023-10-29 18:19:46 --> Helper loaded: form_helper
INFO - 2023-10-29 18:19:46 --> Helper loaded: file_helper
INFO - 2023-10-29 18:19:46 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:19:46 --> Form Validation Class Initialized
INFO - 2023-10-29 18:19:46 --> Upload Class Initialized
INFO - 2023-10-29 18:19:46 --> Model "M_auth" initialized
INFO - 2023-10-29 18:19:46 --> Model "M_user" initialized
INFO - 2023-10-29 18:19:46 --> Model "M_produk" initialized
INFO - 2023-10-29 18:19:46 --> Controller Class Initialized
DEBUG - 2023-10-29 18:19:46 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-29 18:19:47 --> Severity: error --> Exception: Call to undefined function snapToken() C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Payment.php 49
ERROR - 2023-10-29 18:19:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:19:48 --> Config Class Initialized
INFO - 2023-10-29 18:19:48 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:19:48 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:19:48 --> Utf8 Class Initialized
INFO - 2023-10-29 18:19:48 --> URI Class Initialized
INFO - 2023-10-29 18:19:49 --> Router Class Initialized
INFO - 2023-10-29 18:19:49 --> Output Class Initialized
INFO - 2023-10-29 18:19:49 --> Security Class Initialized
DEBUG - 2023-10-29 18:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:19:49 --> Input Class Initialized
INFO - 2023-10-29 18:19:49 --> Language Class Initialized
INFO - 2023-10-29 18:19:49 --> Loader Class Initialized
INFO - 2023-10-29 18:19:49 --> Helper loaded: url_helper
INFO - 2023-10-29 18:19:49 --> Helper loaded: form_helper
INFO - 2023-10-29 18:19:49 --> Helper loaded: file_helper
INFO - 2023-10-29 18:19:49 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:19:49 --> Form Validation Class Initialized
INFO - 2023-10-29 18:19:49 --> Upload Class Initialized
INFO - 2023-10-29 18:19:49 --> Model "M_auth" initialized
INFO - 2023-10-29 18:19:49 --> Model "M_user" initialized
INFO - 2023-10-29 18:19:49 --> Model "M_produk" initialized
INFO - 2023-10-29 18:19:49 --> Controller Class Initialized
DEBUG - 2023-10-29 18:19:49 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:19:49 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:19:49 --> Final output sent to browser
DEBUG - 2023-10-29 18:19:49 --> Total execution time: 0.6166
ERROR - 2023-10-29 18:19:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:19:56 --> Config Class Initialized
INFO - 2023-10-29 18:19:56 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:19:56 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:19:56 --> Utf8 Class Initialized
INFO - 2023-10-29 18:19:56 --> URI Class Initialized
INFO - 2023-10-29 18:19:56 --> Router Class Initialized
INFO - 2023-10-29 18:19:56 --> Output Class Initialized
INFO - 2023-10-29 18:19:56 --> Security Class Initialized
DEBUG - 2023-10-29 18:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:19:56 --> Input Class Initialized
INFO - 2023-10-29 18:19:56 --> Language Class Initialized
INFO - 2023-10-29 18:19:56 --> Loader Class Initialized
INFO - 2023-10-29 18:19:56 --> Helper loaded: url_helper
INFO - 2023-10-29 18:19:56 --> Helper loaded: form_helper
INFO - 2023-10-29 18:19:56 --> Helper loaded: file_helper
INFO - 2023-10-29 18:19:56 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:19:56 --> Form Validation Class Initialized
INFO - 2023-10-29 18:19:56 --> Upload Class Initialized
INFO - 2023-10-29 18:19:56 --> Model "M_auth" initialized
INFO - 2023-10-29 18:19:56 --> Model "M_user" initialized
INFO - 2023-10-29 18:19:56 --> Model "M_produk" initialized
INFO - 2023-10-29 18:19:56 --> Controller Class Initialized
DEBUG - 2023-10-29 18:19:56 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:19:56 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:19:56 --> Final output sent to browser
DEBUG - 2023-10-29 18:19:56 --> Total execution time: 0.0781
ERROR - 2023-10-29 18:19:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:19:57 --> Config Class Initialized
INFO - 2023-10-29 18:19:57 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:19:57 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:19:57 --> Utf8 Class Initialized
INFO - 2023-10-29 18:19:57 --> URI Class Initialized
INFO - 2023-10-29 18:19:57 --> Router Class Initialized
INFO - 2023-10-29 18:19:57 --> Output Class Initialized
INFO - 2023-10-29 18:19:57 --> Security Class Initialized
DEBUG - 2023-10-29 18:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:19:57 --> Input Class Initialized
INFO - 2023-10-29 18:19:57 --> Language Class Initialized
INFO - 2023-10-29 18:19:57 --> Loader Class Initialized
INFO - 2023-10-29 18:19:57 --> Helper loaded: url_helper
INFO - 2023-10-29 18:19:57 --> Helper loaded: form_helper
INFO - 2023-10-29 18:19:57 --> Helper loaded: file_helper
INFO - 2023-10-29 18:19:57 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:19:57 --> Form Validation Class Initialized
INFO - 2023-10-29 18:19:57 --> Upload Class Initialized
INFO - 2023-10-29 18:19:57 --> Model "M_auth" initialized
INFO - 2023-10-29 18:19:57 --> Model "M_user" initialized
INFO - 2023-10-29 18:19:57 --> Model "M_produk" initialized
INFO - 2023-10-29 18:19:57 --> Controller Class Initialized
DEBUG - 2023-10-29 18:19:57 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:19:59 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 18:19:59 --> Final output sent to browser
DEBUG - 2023-10-29 18:19:59 --> Total execution time: 1.6725
ERROR - 2023-10-29 18:21:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:21:08 --> Config Class Initialized
INFO - 2023-10-29 18:21:08 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:21:08 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:21:08 --> Utf8 Class Initialized
INFO - 2023-10-29 18:21:08 --> URI Class Initialized
INFO - 2023-10-29 18:21:08 --> Router Class Initialized
INFO - 2023-10-29 18:21:08 --> Output Class Initialized
INFO - 2023-10-29 18:21:08 --> Security Class Initialized
DEBUG - 2023-10-29 18:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:21:08 --> Input Class Initialized
INFO - 2023-10-29 18:21:08 --> Language Class Initialized
INFO - 2023-10-29 18:21:08 --> Loader Class Initialized
INFO - 2023-10-29 18:21:08 --> Helper loaded: url_helper
INFO - 2023-10-29 18:21:08 --> Helper loaded: form_helper
INFO - 2023-10-29 18:21:08 --> Helper loaded: file_helper
INFO - 2023-10-29 18:21:08 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:21:08 --> Form Validation Class Initialized
INFO - 2023-10-29 18:21:08 --> Upload Class Initialized
INFO - 2023-10-29 18:21:08 --> Model "M_auth" initialized
INFO - 2023-10-29 18:21:08 --> Model "M_user" initialized
INFO - 2023-10-29 18:21:08 --> Model "M_produk" initialized
INFO - 2023-10-29 18:21:08 --> Controller Class Initialized
DEBUG - 2023-10-29 18:21:08 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:21:08 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:21:08 --> Final output sent to browser
DEBUG - 2023-10-29 18:21:08 --> Total execution time: 0.0841
ERROR - 2023-10-29 18:21:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:21:08 --> Config Class Initialized
INFO - 2023-10-29 18:21:08 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:21:08 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:21:08 --> Utf8 Class Initialized
INFO - 2023-10-29 18:21:08 --> URI Class Initialized
INFO - 2023-10-29 18:21:08 --> Router Class Initialized
INFO - 2023-10-29 18:21:08 --> Output Class Initialized
INFO - 2023-10-29 18:21:08 --> Security Class Initialized
DEBUG - 2023-10-29 18:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:21:08 --> Input Class Initialized
INFO - 2023-10-29 18:21:08 --> Language Class Initialized
INFO - 2023-10-29 18:21:08 --> Loader Class Initialized
INFO - 2023-10-29 18:21:08 --> Helper loaded: url_helper
INFO - 2023-10-29 18:21:08 --> Helper loaded: form_helper
INFO - 2023-10-29 18:21:08 --> Helper loaded: file_helper
INFO - 2023-10-29 18:21:08 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:21:08 --> Form Validation Class Initialized
INFO - 2023-10-29 18:21:08 --> Upload Class Initialized
INFO - 2023-10-29 18:21:08 --> Model "M_auth" initialized
INFO - 2023-10-29 18:21:08 --> Model "M_user" initialized
INFO - 2023-10-29 18:21:08 --> Model "M_produk" initialized
INFO - 2023-10-29 18:21:08 --> Controller Class Initialized
DEBUG - 2023-10-29 18:21:08 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:21:08 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:21:08 --> Final output sent to browser
DEBUG - 2023-10-29 18:21:08 --> Total execution time: 0.0880
ERROR - 2023-10-29 18:21:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:21:08 --> Config Class Initialized
INFO - 2023-10-29 18:21:08 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:21:08 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:21:08 --> Utf8 Class Initialized
INFO - 2023-10-29 18:21:08 --> URI Class Initialized
INFO - 2023-10-29 18:21:08 --> Router Class Initialized
INFO - 2023-10-29 18:21:08 --> Output Class Initialized
INFO - 2023-10-29 18:21:08 --> Security Class Initialized
DEBUG - 2023-10-29 18:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:21:08 --> Input Class Initialized
INFO - 2023-10-29 18:21:08 --> Language Class Initialized
INFO - 2023-10-29 18:21:08 --> Loader Class Initialized
INFO - 2023-10-29 18:21:08 --> Helper loaded: url_helper
INFO - 2023-10-29 18:21:08 --> Helper loaded: form_helper
INFO - 2023-10-29 18:21:08 --> Helper loaded: file_helper
INFO - 2023-10-29 18:21:08 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:21:08 --> Form Validation Class Initialized
INFO - 2023-10-29 18:21:08 --> Upload Class Initialized
INFO - 2023-10-29 18:21:08 --> Model "M_auth" initialized
INFO - 2023-10-29 18:21:08 --> Model "M_user" initialized
INFO - 2023-10-29 18:21:08 --> Model "M_produk" initialized
INFO - 2023-10-29 18:21:08 --> Controller Class Initialized
DEBUG - 2023-10-29 18:21:08 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:21:08 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:21:08 --> Final output sent to browser
DEBUG - 2023-10-29 18:21:08 --> Total execution time: 0.0357
ERROR - 2023-10-29 18:21:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:21:09 --> Config Class Initialized
INFO - 2023-10-29 18:21:09 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:21:09 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:21:09 --> Utf8 Class Initialized
INFO - 2023-10-29 18:21:09 --> URI Class Initialized
INFO - 2023-10-29 18:21:09 --> Router Class Initialized
INFO - 2023-10-29 18:21:09 --> Output Class Initialized
INFO - 2023-10-29 18:21:09 --> Security Class Initialized
DEBUG - 2023-10-29 18:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:21:09 --> Input Class Initialized
INFO - 2023-10-29 18:21:09 --> Language Class Initialized
INFO - 2023-10-29 18:21:09 --> Loader Class Initialized
INFO - 2023-10-29 18:21:09 --> Helper loaded: url_helper
INFO - 2023-10-29 18:21:09 --> Helper loaded: form_helper
INFO - 2023-10-29 18:21:09 --> Helper loaded: file_helper
INFO - 2023-10-29 18:21:09 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:21:09 --> Form Validation Class Initialized
INFO - 2023-10-29 18:21:09 --> Upload Class Initialized
INFO - 2023-10-29 18:21:09 --> Model "M_auth" initialized
INFO - 2023-10-29 18:21:09 --> Model "M_user" initialized
INFO - 2023-10-29 18:21:09 --> Model "M_produk" initialized
INFO - 2023-10-29 18:21:09 --> Controller Class Initialized
DEBUG - 2023-10-29 18:21:09 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:21:09 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:21:09 --> Final output sent to browser
DEBUG - 2023-10-29 18:21:09 --> Total execution time: 0.0938
ERROR - 2023-10-29 18:21:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:21:09 --> Config Class Initialized
INFO - 2023-10-29 18:21:09 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:21:09 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:21:09 --> Utf8 Class Initialized
INFO - 2023-10-29 18:21:09 --> URI Class Initialized
INFO - 2023-10-29 18:21:09 --> Router Class Initialized
INFO - 2023-10-29 18:21:09 --> Output Class Initialized
INFO - 2023-10-29 18:21:09 --> Security Class Initialized
DEBUG - 2023-10-29 18:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:21:09 --> Input Class Initialized
INFO - 2023-10-29 18:21:09 --> Language Class Initialized
INFO - 2023-10-29 18:21:09 --> Loader Class Initialized
INFO - 2023-10-29 18:21:09 --> Helper loaded: url_helper
INFO - 2023-10-29 18:21:09 --> Helper loaded: form_helper
INFO - 2023-10-29 18:21:09 --> Helper loaded: file_helper
INFO - 2023-10-29 18:21:09 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:21:09 --> Form Validation Class Initialized
INFO - 2023-10-29 18:21:09 --> Upload Class Initialized
INFO - 2023-10-29 18:21:09 --> Model "M_auth" initialized
INFO - 2023-10-29 18:21:09 --> Model "M_user" initialized
INFO - 2023-10-29 18:21:09 --> Model "M_produk" initialized
INFO - 2023-10-29 18:21:09 --> Controller Class Initialized
DEBUG - 2023-10-29 18:21:09 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:21:09 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:21:09 --> Final output sent to browser
DEBUG - 2023-10-29 18:21:09 --> Total execution time: 0.0244
ERROR - 2023-10-29 18:21:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:21:15 --> Config Class Initialized
INFO - 2023-10-29 18:21:15 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:21:15 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:21:15 --> Utf8 Class Initialized
INFO - 2023-10-29 18:21:15 --> URI Class Initialized
INFO - 2023-10-29 18:21:15 --> Router Class Initialized
INFO - 2023-10-29 18:21:15 --> Output Class Initialized
INFO - 2023-10-29 18:21:15 --> Security Class Initialized
DEBUG - 2023-10-29 18:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:21:15 --> Input Class Initialized
INFO - 2023-10-29 18:21:15 --> Language Class Initialized
INFO - 2023-10-29 18:21:15 --> Loader Class Initialized
INFO - 2023-10-29 18:21:15 --> Helper loaded: url_helper
INFO - 2023-10-29 18:21:15 --> Helper loaded: form_helper
INFO - 2023-10-29 18:21:15 --> Helper loaded: file_helper
INFO - 2023-10-29 18:21:15 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:21:15 --> Form Validation Class Initialized
INFO - 2023-10-29 18:21:15 --> Upload Class Initialized
INFO - 2023-10-29 18:21:15 --> Model "M_auth" initialized
INFO - 2023-10-29 18:21:15 --> Model "M_user" initialized
INFO - 2023-10-29 18:21:15 --> Model "M_produk" initialized
INFO - 2023-10-29 18:21:15 --> Controller Class Initialized
DEBUG - 2023-10-29 18:21:15 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:21:16 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 18:21:16 --> Final output sent to browser
DEBUG - 2023-10-29 18:21:16 --> Total execution time: 1.1493
ERROR - 2023-10-29 18:22:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:22:24 --> Config Class Initialized
INFO - 2023-10-29 18:22:24 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:22:24 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:22:24 --> Utf8 Class Initialized
INFO - 2023-10-29 18:22:24 --> URI Class Initialized
INFO - 2023-10-29 18:22:24 --> Router Class Initialized
INFO - 2023-10-29 18:22:24 --> Output Class Initialized
INFO - 2023-10-29 18:22:24 --> Security Class Initialized
DEBUG - 2023-10-29 18:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:22:24 --> Input Class Initialized
INFO - 2023-10-29 18:22:24 --> Language Class Initialized
INFO - 2023-10-29 18:22:24 --> Loader Class Initialized
INFO - 2023-10-29 18:22:24 --> Helper loaded: url_helper
INFO - 2023-10-29 18:22:24 --> Helper loaded: form_helper
INFO - 2023-10-29 18:22:24 --> Helper loaded: file_helper
INFO - 2023-10-29 18:22:24 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:22:24 --> Form Validation Class Initialized
INFO - 2023-10-29 18:22:24 --> Upload Class Initialized
INFO - 2023-10-29 18:22:24 --> Model "M_auth" initialized
INFO - 2023-10-29 18:22:24 --> Model "M_user" initialized
INFO - 2023-10-29 18:22:24 --> Model "M_produk" initialized
INFO - 2023-10-29 18:22:24 --> Controller Class Initialized
DEBUG - 2023-10-29 18:22:24 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:22:24 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:22:24 --> Final output sent to browser
DEBUG - 2023-10-29 18:22:24 --> Total execution time: 0.0373
ERROR - 2023-10-29 18:22:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:22:25 --> Config Class Initialized
INFO - 2023-10-29 18:22:25 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:22:25 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:22:25 --> Utf8 Class Initialized
INFO - 2023-10-29 18:22:25 --> URI Class Initialized
INFO - 2023-10-29 18:22:25 --> Router Class Initialized
INFO - 2023-10-29 18:22:25 --> Output Class Initialized
INFO - 2023-10-29 18:22:25 --> Security Class Initialized
DEBUG - 2023-10-29 18:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:22:25 --> Input Class Initialized
INFO - 2023-10-29 18:22:25 --> Language Class Initialized
INFO - 2023-10-29 18:22:25 --> Loader Class Initialized
INFO - 2023-10-29 18:22:25 --> Helper loaded: url_helper
INFO - 2023-10-29 18:22:25 --> Helper loaded: form_helper
INFO - 2023-10-29 18:22:25 --> Helper loaded: file_helper
INFO - 2023-10-29 18:22:25 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:22:25 --> Form Validation Class Initialized
INFO - 2023-10-29 18:22:25 --> Upload Class Initialized
INFO - 2023-10-29 18:22:25 --> Model "M_auth" initialized
INFO - 2023-10-29 18:22:25 --> Model "M_user" initialized
INFO - 2023-10-29 18:22:25 --> Model "M_produk" initialized
INFO - 2023-10-29 18:22:25 --> Controller Class Initialized
DEBUG - 2023-10-29 18:22:25 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:22:25 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:22:25 --> Final output sent to browser
DEBUG - 2023-10-29 18:22:25 --> Total execution time: 0.0640
ERROR - 2023-10-29 18:22:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:22:27 --> Config Class Initialized
INFO - 2023-10-29 18:22:27 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:22:27 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:22:27 --> Utf8 Class Initialized
INFO - 2023-10-29 18:22:27 --> URI Class Initialized
INFO - 2023-10-29 18:22:27 --> Router Class Initialized
INFO - 2023-10-29 18:22:27 --> Output Class Initialized
INFO - 2023-10-29 18:22:27 --> Security Class Initialized
DEBUG - 2023-10-29 18:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:22:27 --> Input Class Initialized
INFO - 2023-10-29 18:22:27 --> Language Class Initialized
INFO - 2023-10-29 18:22:27 --> Loader Class Initialized
INFO - 2023-10-29 18:22:27 --> Helper loaded: url_helper
INFO - 2023-10-29 18:22:27 --> Helper loaded: form_helper
INFO - 2023-10-29 18:22:27 --> Helper loaded: file_helper
INFO - 2023-10-29 18:22:27 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:22:27 --> Form Validation Class Initialized
INFO - 2023-10-29 18:22:27 --> Upload Class Initialized
INFO - 2023-10-29 18:22:27 --> Model "M_auth" initialized
INFO - 2023-10-29 18:22:27 --> Model "M_user" initialized
INFO - 2023-10-29 18:22:27 --> Model "M_produk" initialized
INFO - 2023-10-29 18:22:27 --> Controller Class Initialized
DEBUG - 2023-10-29 18:22:27 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:22:27 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 18:22:27 --> Final output sent to browser
DEBUG - 2023-10-29 18:22:27 --> Total execution time: 0.4260
ERROR - 2023-10-29 18:23:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:23:28 --> Config Class Initialized
INFO - 2023-10-29 18:23:28 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:23:28 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:23:28 --> Utf8 Class Initialized
INFO - 2023-10-29 18:23:28 --> URI Class Initialized
INFO - 2023-10-29 18:23:28 --> Router Class Initialized
INFO - 2023-10-29 18:23:28 --> Output Class Initialized
INFO - 2023-10-29 18:23:28 --> Security Class Initialized
DEBUG - 2023-10-29 18:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:23:28 --> Input Class Initialized
INFO - 2023-10-29 18:23:28 --> Language Class Initialized
INFO - 2023-10-29 18:23:28 --> Loader Class Initialized
INFO - 2023-10-29 18:23:28 --> Helper loaded: url_helper
INFO - 2023-10-29 18:23:28 --> Helper loaded: form_helper
INFO - 2023-10-29 18:23:28 --> Helper loaded: file_helper
INFO - 2023-10-29 18:23:28 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:23:28 --> Form Validation Class Initialized
INFO - 2023-10-29 18:23:28 --> Upload Class Initialized
INFO - 2023-10-29 18:23:28 --> Model "M_auth" initialized
INFO - 2023-10-29 18:23:28 --> Model "M_user" initialized
INFO - 2023-10-29 18:23:28 --> Model "M_produk" initialized
INFO - 2023-10-29 18:23:28 --> Controller Class Initialized
DEBUG - 2023-10-29 18:23:28 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:23:28 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:23:28 --> Final output sent to browser
DEBUG - 2023-10-29 18:23:28 --> Total execution time: 0.0567
ERROR - 2023-10-29 18:23:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:23:30 --> Config Class Initialized
INFO - 2023-10-29 18:23:30 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:23:30 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:23:30 --> Utf8 Class Initialized
INFO - 2023-10-29 18:23:30 --> URI Class Initialized
INFO - 2023-10-29 18:23:30 --> Router Class Initialized
INFO - 2023-10-29 18:23:30 --> Output Class Initialized
INFO - 2023-10-29 18:23:30 --> Security Class Initialized
DEBUG - 2023-10-29 18:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:23:30 --> Input Class Initialized
INFO - 2023-10-29 18:23:30 --> Language Class Initialized
INFO - 2023-10-29 18:23:30 --> Loader Class Initialized
INFO - 2023-10-29 18:23:30 --> Helper loaded: url_helper
INFO - 2023-10-29 18:23:30 --> Helper loaded: form_helper
INFO - 2023-10-29 18:23:30 --> Helper loaded: file_helper
INFO - 2023-10-29 18:23:30 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:23:30 --> Form Validation Class Initialized
INFO - 2023-10-29 18:23:30 --> Upload Class Initialized
INFO - 2023-10-29 18:23:30 --> Model "M_auth" initialized
INFO - 2023-10-29 18:23:30 --> Model "M_user" initialized
INFO - 2023-10-29 18:23:30 --> Model "M_produk" initialized
INFO - 2023-10-29 18:23:30 --> Controller Class Initialized
DEBUG - 2023-10-29 18:23:30 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:23:30 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:23:30 --> Final output sent to browser
DEBUG - 2023-10-29 18:23:30 --> Total execution time: 0.0585
ERROR - 2023-10-29 18:23:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:23:31 --> Config Class Initialized
INFO - 2023-10-29 18:23:31 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:23:31 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:23:31 --> Utf8 Class Initialized
INFO - 2023-10-29 18:23:31 --> URI Class Initialized
INFO - 2023-10-29 18:23:31 --> Router Class Initialized
INFO - 2023-10-29 18:23:31 --> Output Class Initialized
INFO - 2023-10-29 18:23:31 --> Security Class Initialized
DEBUG - 2023-10-29 18:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:23:31 --> Input Class Initialized
INFO - 2023-10-29 18:23:31 --> Language Class Initialized
INFO - 2023-10-29 18:23:31 --> Loader Class Initialized
INFO - 2023-10-29 18:23:31 --> Helper loaded: url_helper
INFO - 2023-10-29 18:23:31 --> Helper loaded: form_helper
INFO - 2023-10-29 18:23:31 --> Helper loaded: file_helper
INFO - 2023-10-29 18:23:31 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:23:31 --> Form Validation Class Initialized
INFO - 2023-10-29 18:23:31 --> Upload Class Initialized
INFO - 2023-10-29 18:23:31 --> Model "M_auth" initialized
INFO - 2023-10-29 18:23:31 --> Model "M_user" initialized
INFO - 2023-10-29 18:23:31 --> Model "M_produk" initialized
INFO - 2023-10-29 18:23:31 --> Controller Class Initialized
DEBUG - 2023-10-29 18:23:31 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:23:32 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 18:23:32 --> Final output sent to browser
DEBUG - 2023-10-29 18:23:32 --> Total execution time: 1.1212
ERROR - 2023-10-29 18:24:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:24:02 --> Config Class Initialized
INFO - 2023-10-29 18:24:02 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:24:02 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:24:02 --> Utf8 Class Initialized
INFO - 2023-10-29 18:24:02 --> URI Class Initialized
INFO - 2023-10-29 18:24:02 --> Router Class Initialized
INFO - 2023-10-29 18:24:02 --> Output Class Initialized
INFO - 2023-10-29 18:24:02 --> Security Class Initialized
DEBUG - 2023-10-29 18:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:24:02 --> Input Class Initialized
INFO - 2023-10-29 18:24:02 --> Language Class Initialized
INFO - 2023-10-29 18:24:02 --> Loader Class Initialized
INFO - 2023-10-29 18:24:02 --> Helper loaded: url_helper
INFO - 2023-10-29 18:24:02 --> Helper loaded: form_helper
INFO - 2023-10-29 18:24:02 --> Helper loaded: file_helper
INFO - 2023-10-29 18:24:02 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:24:02 --> Form Validation Class Initialized
INFO - 2023-10-29 18:24:02 --> Upload Class Initialized
INFO - 2023-10-29 18:24:02 --> Model "M_auth" initialized
INFO - 2023-10-29 18:24:02 --> Model "M_user" initialized
INFO - 2023-10-29 18:24:02 --> Model "M_produk" initialized
INFO - 2023-10-29 18:24:02 --> Controller Class Initialized
DEBUG - 2023-10-29 18:24:02 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:24:02 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:24:02 --> Final output sent to browser
DEBUG - 2023-10-29 18:24:02 --> Total execution time: 0.0693
ERROR - 2023-10-29 18:24:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:24:03 --> Config Class Initialized
INFO - 2023-10-29 18:24:03 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:24:03 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:24:03 --> Utf8 Class Initialized
INFO - 2023-10-29 18:24:03 --> URI Class Initialized
INFO - 2023-10-29 18:24:03 --> Router Class Initialized
INFO - 2023-10-29 18:24:03 --> Output Class Initialized
INFO - 2023-10-29 18:24:03 --> Security Class Initialized
DEBUG - 2023-10-29 18:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:24:03 --> Input Class Initialized
INFO - 2023-10-29 18:24:03 --> Language Class Initialized
INFO - 2023-10-29 18:24:03 --> Loader Class Initialized
INFO - 2023-10-29 18:24:03 --> Helper loaded: url_helper
INFO - 2023-10-29 18:24:03 --> Helper loaded: form_helper
INFO - 2023-10-29 18:24:03 --> Helper loaded: file_helper
INFO - 2023-10-29 18:24:03 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:24:03 --> Form Validation Class Initialized
INFO - 2023-10-29 18:24:03 --> Upload Class Initialized
INFO - 2023-10-29 18:24:03 --> Model "M_auth" initialized
INFO - 2023-10-29 18:24:03 --> Model "M_user" initialized
INFO - 2023-10-29 18:24:03 --> Model "M_produk" initialized
INFO - 2023-10-29 18:24:03 --> Controller Class Initialized
DEBUG - 2023-10-29 18:24:03 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:24:03 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:24:03 --> Final output sent to browser
DEBUG - 2023-10-29 18:24:03 --> Total execution time: 0.0618
ERROR - 2023-10-29 18:24:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:24:05 --> Config Class Initialized
INFO - 2023-10-29 18:24:05 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:24:05 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:24:05 --> Utf8 Class Initialized
INFO - 2023-10-29 18:24:05 --> URI Class Initialized
INFO - 2023-10-29 18:24:05 --> Router Class Initialized
INFO - 2023-10-29 18:24:05 --> Output Class Initialized
INFO - 2023-10-29 18:24:05 --> Security Class Initialized
DEBUG - 2023-10-29 18:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:24:05 --> Input Class Initialized
INFO - 2023-10-29 18:24:05 --> Language Class Initialized
INFO - 2023-10-29 18:24:05 --> Loader Class Initialized
INFO - 2023-10-29 18:24:05 --> Helper loaded: url_helper
INFO - 2023-10-29 18:24:05 --> Helper loaded: form_helper
INFO - 2023-10-29 18:24:05 --> Helper loaded: file_helper
INFO - 2023-10-29 18:24:05 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:24:05 --> Form Validation Class Initialized
INFO - 2023-10-29 18:24:05 --> Upload Class Initialized
INFO - 2023-10-29 18:24:05 --> Model "M_auth" initialized
INFO - 2023-10-29 18:24:05 --> Model "M_user" initialized
INFO - 2023-10-29 18:24:05 --> Model "M_produk" initialized
INFO - 2023-10-29 18:24:05 --> Controller Class Initialized
DEBUG - 2023-10-29 18:24:05 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:24:06 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 18:24:06 --> Final output sent to browser
DEBUG - 2023-10-29 18:24:06 --> Total execution time: 1.5938
ERROR - 2023-10-29 18:24:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:24:12 --> Config Class Initialized
INFO - 2023-10-29 18:24:12 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:24:12 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:24:12 --> Utf8 Class Initialized
INFO - 2023-10-29 18:24:12 --> URI Class Initialized
INFO - 2023-10-29 18:24:12 --> Router Class Initialized
INFO - 2023-10-29 18:24:12 --> Output Class Initialized
INFO - 2023-10-29 18:24:12 --> Security Class Initialized
DEBUG - 2023-10-29 18:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:24:12 --> Input Class Initialized
INFO - 2023-10-29 18:24:12 --> Language Class Initialized
INFO - 2023-10-29 18:24:12 --> Loader Class Initialized
INFO - 2023-10-29 18:24:12 --> Helper loaded: url_helper
INFO - 2023-10-29 18:24:12 --> Helper loaded: form_helper
INFO - 2023-10-29 18:24:12 --> Helper loaded: file_helper
INFO - 2023-10-29 18:24:12 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:24:12 --> Form Validation Class Initialized
INFO - 2023-10-29 18:24:12 --> Upload Class Initialized
INFO - 2023-10-29 18:24:12 --> Model "M_auth" initialized
INFO - 2023-10-29 18:24:12 --> Model "M_user" initialized
INFO - 2023-10-29 18:24:12 --> Model "M_produk" initialized
INFO - 2023-10-29 18:24:12 --> Controller Class Initialized
DEBUG - 2023-10-29 18:24:12 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:24:12 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:24:12 --> Final output sent to browser
DEBUG - 2023-10-29 18:24:12 --> Total execution time: 0.0865
ERROR - 2023-10-29 18:24:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:24:13 --> Config Class Initialized
INFO - 2023-10-29 18:24:13 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:24:13 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:24:13 --> Utf8 Class Initialized
INFO - 2023-10-29 18:24:13 --> URI Class Initialized
INFO - 2023-10-29 18:24:13 --> Router Class Initialized
INFO - 2023-10-29 18:24:13 --> Output Class Initialized
INFO - 2023-10-29 18:24:13 --> Security Class Initialized
DEBUG - 2023-10-29 18:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:24:13 --> Input Class Initialized
INFO - 2023-10-29 18:24:13 --> Language Class Initialized
INFO - 2023-10-29 18:24:13 --> Loader Class Initialized
INFO - 2023-10-29 18:24:13 --> Helper loaded: url_helper
INFO - 2023-10-29 18:24:13 --> Helper loaded: form_helper
INFO - 2023-10-29 18:24:13 --> Helper loaded: file_helper
INFO - 2023-10-29 18:24:13 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:24:13 --> Form Validation Class Initialized
INFO - 2023-10-29 18:24:13 --> Upload Class Initialized
INFO - 2023-10-29 18:24:13 --> Model "M_auth" initialized
INFO - 2023-10-29 18:24:13 --> Model "M_user" initialized
INFO - 2023-10-29 18:24:13 --> Model "M_produk" initialized
INFO - 2023-10-29 18:24:13 --> Controller Class Initialized
DEBUG - 2023-10-29 18:24:13 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:24:13 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:24:13 --> Final output sent to browser
DEBUG - 2023-10-29 18:24:13 --> Total execution time: 0.0785
ERROR - 2023-10-29 18:24:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:24:15 --> Config Class Initialized
INFO - 2023-10-29 18:24:15 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:24:15 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:24:15 --> Utf8 Class Initialized
INFO - 2023-10-29 18:24:15 --> URI Class Initialized
INFO - 2023-10-29 18:24:15 --> Router Class Initialized
INFO - 2023-10-29 18:24:15 --> Output Class Initialized
INFO - 2023-10-29 18:24:15 --> Security Class Initialized
DEBUG - 2023-10-29 18:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:24:15 --> Input Class Initialized
INFO - 2023-10-29 18:24:15 --> Language Class Initialized
INFO - 2023-10-29 18:24:15 --> Loader Class Initialized
INFO - 2023-10-29 18:24:15 --> Helper loaded: url_helper
INFO - 2023-10-29 18:24:15 --> Helper loaded: form_helper
INFO - 2023-10-29 18:24:15 --> Helper loaded: file_helper
INFO - 2023-10-29 18:24:15 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:24:15 --> Form Validation Class Initialized
INFO - 2023-10-29 18:24:15 --> Upload Class Initialized
INFO - 2023-10-29 18:24:15 --> Model "M_auth" initialized
INFO - 2023-10-29 18:24:15 --> Model "M_user" initialized
INFO - 2023-10-29 18:24:15 --> Model "M_produk" initialized
INFO - 2023-10-29 18:24:15 --> Controller Class Initialized
DEBUG - 2023-10-29 18:24:15 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:24:15 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 18:24:15 --> Final output sent to browser
DEBUG - 2023-10-29 18:24:15 --> Total execution time: 0.4452
ERROR - 2023-10-29 18:24:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:24:56 --> Config Class Initialized
INFO - 2023-10-29 18:24:56 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:24:56 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:24:56 --> Utf8 Class Initialized
INFO - 2023-10-29 18:24:56 --> URI Class Initialized
INFO - 2023-10-29 18:24:56 --> Router Class Initialized
INFO - 2023-10-29 18:24:56 --> Output Class Initialized
INFO - 2023-10-29 18:24:56 --> Security Class Initialized
DEBUG - 2023-10-29 18:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:24:56 --> Input Class Initialized
INFO - 2023-10-29 18:24:56 --> Language Class Initialized
INFO - 2023-10-29 18:24:56 --> Loader Class Initialized
INFO - 2023-10-29 18:24:56 --> Helper loaded: url_helper
INFO - 2023-10-29 18:24:57 --> Helper loaded: form_helper
INFO - 2023-10-29 18:24:57 --> Helper loaded: file_helper
INFO - 2023-10-29 18:24:57 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:24:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:24:57 --> Form Validation Class Initialized
INFO - 2023-10-29 18:24:57 --> Upload Class Initialized
INFO - 2023-10-29 18:24:57 --> Model "M_auth" initialized
INFO - 2023-10-29 18:24:57 --> Model "M_user" initialized
INFO - 2023-10-29 18:24:57 --> Model "M_produk" initialized
INFO - 2023-10-29 18:24:57 --> Controller Class Initialized
DEBUG - 2023-10-29 18:24:57 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:24:57 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:24:57 --> Final output sent to browser
DEBUG - 2023-10-29 18:24:57 --> Total execution time: 0.0957
ERROR - 2023-10-29 18:24:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:24:57 --> Config Class Initialized
INFO - 2023-10-29 18:24:57 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:24:57 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:24:57 --> Utf8 Class Initialized
INFO - 2023-10-29 18:24:57 --> URI Class Initialized
INFO - 2023-10-29 18:24:57 --> Router Class Initialized
INFO - 2023-10-29 18:24:57 --> Output Class Initialized
INFO - 2023-10-29 18:24:57 --> Security Class Initialized
DEBUG - 2023-10-29 18:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:24:57 --> Input Class Initialized
INFO - 2023-10-29 18:24:57 --> Language Class Initialized
INFO - 2023-10-29 18:24:57 --> Loader Class Initialized
INFO - 2023-10-29 18:24:57 --> Helper loaded: url_helper
INFO - 2023-10-29 18:24:57 --> Helper loaded: form_helper
INFO - 2023-10-29 18:24:57 --> Helper loaded: file_helper
INFO - 2023-10-29 18:24:57 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:24:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:24:57 --> Form Validation Class Initialized
INFO - 2023-10-29 18:24:57 --> Upload Class Initialized
INFO - 2023-10-29 18:24:57 --> Model "M_auth" initialized
INFO - 2023-10-29 18:24:57 --> Model "M_user" initialized
INFO - 2023-10-29 18:24:57 --> Model "M_produk" initialized
INFO - 2023-10-29 18:24:57 --> Controller Class Initialized
DEBUG - 2023-10-29 18:24:57 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:24:57 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:24:57 --> Final output sent to browser
DEBUG - 2023-10-29 18:24:57 --> Total execution time: 0.0613
ERROR - 2023-10-29 18:24:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:24:58 --> Config Class Initialized
INFO - 2023-10-29 18:24:58 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:24:58 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:24:58 --> Utf8 Class Initialized
INFO - 2023-10-29 18:24:58 --> URI Class Initialized
INFO - 2023-10-29 18:24:58 --> Router Class Initialized
INFO - 2023-10-29 18:24:58 --> Output Class Initialized
INFO - 2023-10-29 18:24:58 --> Security Class Initialized
DEBUG - 2023-10-29 18:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:24:58 --> Input Class Initialized
INFO - 2023-10-29 18:24:58 --> Language Class Initialized
INFO - 2023-10-29 18:24:58 --> Loader Class Initialized
INFO - 2023-10-29 18:24:58 --> Helper loaded: url_helper
INFO - 2023-10-29 18:24:58 --> Helper loaded: form_helper
INFO - 2023-10-29 18:24:58 --> Helper loaded: file_helper
INFO - 2023-10-29 18:24:58 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:24:58 --> Form Validation Class Initialized
INFO - 2023-10-29 18:24:58 --> Upload Class Initialized
INFO - 2023-10-29 18:24:58 --> Model "M_auth" initialized
INFO - 2023-10-29 18:24:58 --> Model "M_user" initialized
INFO - 2023-10-29 18:24:58 --> Model "M_produk" initialized
INFO - 2023-10-29 18:24:58 --> Controller Class Initialized
DEBUG - 2023-10-29 18:24:58 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:24:58 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:24:58 --> Final output sent to browser
DEBUG - 2023-10-29 18:24:58 --> Total execution time: 0.0727
ERROR - 2023-10-29 18:24:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:24:58 --> Config Class Initialized
INFO - 2023-10-29 18:24:58 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:24:58 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:24:58 --> Utf8 Class Initialized
INFO - 2023-10-29 18:24:58 --> URI Class Initialized
INFO - 2023-10-29 18:24:58 --> Router Class Initialized
INFO - 2023-10-29 18:24:58 --> Output Class Initialized
INFO - 2023-10-29 18:24:58 --> Security Class Initialized
DEBUG - 2023-10-29 18:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:24:58 --> Input Class Initialized
INFO - 2023-10-29 18:24:58 --> Language Class Initialized
INFO - 2023-10-29 18:24:58 --> Loader Class Initialized
INFO - 2023-10-29 18:24:58 --> Helper loaded: url_helper
INFO - 2023-10-29 18:24:58 --> Helper loaded: form_helper
INFO - 2023-10-29 18:24:58 --> Helper loaded: file_helper
INFO - 2023-10-29 18:24:58 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:24:58 --> Form Validation Class Initialized
INFO - 2023-10-29 18:24:58 --> Upload Class Initialized
INFO - 2023-10-29 18:24:58 --> Model "M_auth" initialized
INFO - 2023-10-29 18:24:58 --> Model "M_user" initialized
INFO - 2023-10-29 18:24:58 --> Model "M_produk" initialized
INFO - 2023-10-29 18:24:58 --> Controller Class Initialized
DEBUG - 2023-10-29 18:24:58 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:24:58 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:24:58 --> Final output sent to browser
DEBUG - 2023-10-29 18:24:58 --> Total execution time: 0.0616
ERROR - 2023-10-29 18:24:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:24:59 --> Config Class Initialized
INFO - 2023-10-29 18:24:59 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:24:59 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:24:59 --> Utf8 Class Initialized
INFO - 2023-10-29 18:24:59 --> URI Class Initialized
INFO - 2023-10-29 18:24:59 --> Router Class Initialized
INFO - 2023-10-29 18:24:59 --> Output Class Initialized
INFO - 2023-10-29 18:24:59 --> Security Class Initialized
DEBUG - 2023-10-29 18:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:24:59 --> Input Class Initialized
INFO - 2023-10-29 18:24:59 --> Language Class Initialized
INFO - 2023-10-29 18:24:59 --> Loader Class Initialized
INFO - 2023-10-29 18:24:59 --> Helper loaded: url_helper
INFO - 2023-10-29 18:24:59 --> Helper loaded: form_helper
INFO - 2023-10-29 18:24:59 --> Helper loaded: file_helper
INFO - 2023-10-29 18:24:59 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:24:59 --> Form Validation Class Initialized
INFO - 2023-10-29 18:24:59 --> Upload Class Initialized
INFO - 2023-10-29 18:24:59 --> Model "M_auth" initialized
INFO - 2023-10-29 18:24:59 --> Model "M_user" initialized
INFO - 2023-10-29 18:24:59 --> Model "M_produk" initialized
INFO - 2023-10-29 18:24:59 --> Controller Class Initialized
DEBUG - 2023-10-29 18:24:59 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-29 18:25:01 --> Severity: error --> Exception: Undefined constant "console" C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Payment.php 49
ERROR - 2023-10-29 18:25:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:25:55 --> Config Class Initialized
INFO - 2023-10-29 18:25:55 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:25:55 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:25:55 --> Utf8 Class Initialized
INFO - 2023-10-29 18:25:55 --> URI Class Initialized
INFO - 2023-10-29 18:25:55 --> Router Class Initialized
INFO - 2023-10-29 18:25:55 --> Output Class Initialized
INFO - 2023-10-29 18:25:55 --> Security Class Initialized
DEBUG - 2023-10-29 18:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:25:55 --> Input Class Initialized
INFO - 2023-10-29 18:25:55 --> Language Class Initialized
INFO - 2023-10-29 18:25:55 --> Loader Class Initialized
INFO - 2023-10-29 18:25:55 --> Helper loaded: url_helper
INFO - 2023-10-29 18:25:55 --> Helper loaded: form_helper
INFO - 2023-10-29 18:25:55 --> Helper loaded: file_helper
INFO - 2023-10-29 18:25:55 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:25:55 --> Form Validation Class Initialized
INFO - 2023-10-29 18:25:55 --> Upload Class Initialized
INFO - 2023-10-29 18:25:55 --> Model "M_auth" initialized
INFO - 2023-10-29 18:25:55 --> Model "M_user" initialized
INFO - 2023-10-29 18:25:55 --> Model "M_produk" initialized
INFO - 2023-10-29 18:25:55 --> Controller Class Initialized
DEBUG - 2023-10-29 18:25:55 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:25:55 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:25:55 --> Final output sent to browser
DEBUG - 2023-10-29 18:25:55 --> Total execution time: 0.0928
ERROR - 2023-10-29 18:25:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:25:56 --> Config Class Initialized
INFO - 2023-10-29 18:25:56 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:25:56 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:25:56 --> Utf8 Class Initialized
INFO - 2023-10-29 18:25:56 --> URI Class Initialized
INFO - 2023-10-29 18:25:56 --> Router Class Initialized
INFO - 2023-10-29 18:25:56 --> Output Class Initialized
INFO - 2023-10-29 18:25:56 --> Security Class Initialized
DEBUG - 2023-10-29 18:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:25:56 --> Input Class Initialized
INFO - 2023-10-29 18:25:56 --> Language Class Initialized
INFO - 2023-10-29 18:25:56 --> Loader Class Initialized
INFO - 2023-10-29 18:25:56 --> Helper loaded: url_helper
INFO - 2023-10-29 18:25:56 --> Helper loaded: form_helper
INFO - 2023-10-29 18:25:56 --> Helper loaded: file_helper
INFO - 2023-10-29 18:25:56 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:25:56 --> Form Validation Class Initialized
INFO - 2023-10-29 18:25:56 --> Upload Class Initialized
INFO - 2023-10-29 18:25:56 --> Model "M_auth" initialized
INFO - 2023-10-29 18:25:56 --> Model "M_user" initialized
INFO - 2023-10-29 18:25:56 --> Model "M_produk" initialized
INFO - 2023-10-29 18:25:56 --> Controller Class Initialized
DEBUG - 2023-10-29 18:25:56 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:25:56 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:25:56 --> Final output sent to browser
DEBUG - 2023-10-29 18:25:56 --> Total execution time: 0.0275
ERROR - 2023-10-29 18:25:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:25:57 --> Config Class Initialized
INFO - 2023-10-29 18:25:57 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:25:57 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:25:57 --> Utf8 Class Initialized
INFO - 2023-10-29 18:25:57 --> URI Class Initialized
INFO - 2023-10-29 18:25:57 --> Router Class Initialized
INFO - 2023-10-29 18:25:57 --> Output Class Initialized
INFO - 2023-10-29 18:25:57 --> Security Class Initialized
DEBUG - 2023-10-29 18:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:25:57 --> Input Class Initialized
INFO - 2023-10-29 18:25:57 --> Language Class Initialized
INFO - 2023-10-29 18:25:57 --> Loader Class Initialized
INFO - 2023-10-29 18:25:57 --> Helper loaded: url_helper
INFO - 2023-10-29 18:25:57 --> Helper loaded: form_helper
INFO - 2023-10-29 18:25:57 --> Helper loaded: file_helper
INFO - 2023-10-29 18:25:57 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:25:57 --> Form Validation Class Initialized
INFO - 2023-10-29 18:25:57 --> Upload Class Initialized
INFO - 2023-10-29 18:25:57 --> Model "M_auth" initialized
INFO - 2023-10-29 18:25:57 --> Model "M_user" initialized
INFO - 2023-10-29 18:25:57 --> Model "M_produk" initialized
INFO - 2023-10-29 18:25:57 --> Controller Class Initialized
DEBUG - 2023-10-29 18:25:57 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:25:58 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 18:25:58 --> Final output sent to browser
DEBUG - 2023-10-29 18:25:58 --> Total execution time: 0.6522
ERROR - 2023-10-29 18:26:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:26:01 --> Config Class Initialized
INFO - 2023-10-29 18:26:01 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:26:01 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:26:01 --> Utf8 Class Initialized
INFO - 2023-10-29 18:26:01 --> URI Class Initialized
INFO - 2023-10-29 18:26:01 --> Router Class Initialized
INFO - 2023-10-29 18:26:01 --> Output Class Initialized
INFO - 2023-10-29 18:26:01 --> Security Class Initialized
DEBUG - 2023-10-29 18:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:26:01 --> Input Class Initialized
INFO - 2023-10-29 18:26:01 --> Language Class Initialized
INFO - 2023-10-29 18:26:01 --> Loader Class Initialized
INFO - 2023-10-29 18:26:01 --> Helper loaded: url_helper
INFO - 2023-10-29 18:26:01 --> Helper loaded: form_helper
INFO - 2023-10-29 18:26:01 --> Helper loaded: file_helper
INFO - 2023-10-29 18:26:01 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:26:01 --> Form Validation Class Initialized
INFO - 2023-10-29 18:26:01 --> Upload Class Initialized
INFO - 2023-10-29 18:26:01 --> Model "M_auth" initialized
INFO - 2023-10-29 18:26:01 --> Model "M_user" initialized
INFO - 2023-10-29 18:26:01 --> Model "M_produk" initialized
INFO - 2023-10-29 18:26:01 --> Controller Class Initialized
DEBUG - 2023-10-29 18:26:01 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:26:01 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:26:01 --> Final output sent to browser
DEBUG - 2023-10-29 18:26:01 --> Total execution time: 0.0486
ERROR - 2023-10-29 18:26:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:26:25 --> Config Class Initialized
INFO - 2023-10-29 18:26:25 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:26:25 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:26:25 --> Utf8 Class Initialized
INFO - 2023-10-29 18:26:25 --> URI Class Initialized
INFO - 2023-10-29 18:26:25 --> Router Class Initialized
INFO - 2023-10-29 18:26:25 --> Output Class Initialized
INFO - 2023-10-29 18:26:25 --> Security Class Initialized
DEBUG - 2023-10-29 18:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:26:25 --> Input Class Initialized
INFO - 2023-10-29 18:26:25 --> Language Class Initialized
INFO - 2023-10-29 18:26:25 --> Loader Class Initialized
INFO - 2023-10-29 18:26:25 --> Helper loaded: url_helper
INFO - 2023-10-29 18:26:25 --> Helper loaded: form_helper
INFO - 2023-10-29 18:26:25 --> Helper loaded: file_helper
INFO - 2023-10-29 18:26:25 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:26:25 --> Form Validation Class Initialized
INFO - 2023-10-29 18:26:25 --> Upload Class Initialized
INFO - 2023-10-29 18:26:25 --> Model "M_auth" initialized
INFO - 2023-10-29 18:26:25 --> Model "M_user" initialized
INFO - 2023-10-29 18:26:25 --> Model "M_produk" initialized
INFO - 2023-10-29 18:26:25 --> Controller Class Initialized
DEBUG - 2023-10-29 18:26:25 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:26:25 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:26:25 --> Final output sent to browser
DEBUG - 2023-10-29 18:26:25 --> Total execution time: 0.0826
ERROR - 2023-10-29 18:26:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:26:26 --> Config Class Initialized
INFO - 2023-10-29 18:26:26 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:26:26 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:26:26 --> Utf8 Class Initialized
INFO - 2023-10-29 18:26:26 --> URI Class Initialized
INFO - 2023-10-29 18:26:26 --> Router Class Initialized
INFO - 2023-10-29 18:26:26 --> Output Class Initialized
INFO - 2023-10-29 18:26:26 --> Security Class Initialized
DEBUG - 2023-10-29 18:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:26:26 --> Input Class Initialized
INFO - 2023-10-29 18:26:26 --> Language Class Initialized
INFO - 2023-10-29 18:26:26 --> Loader Class Initialized
INFO - 2023-10-29 18:26:26 --> Helper loaded: url_helper
INFO - 2023-10-29 18:26:26 --> Helper loaded: form_helper
INFO - 2023-10-29 18:26:26 --> Helper loaded: file_helper
INFO - 2023-10-29 18:26:26 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:26:26 --> Form Validation Class Initialized
INFO - 2023-10-29 18:26:26 --> Upload Class Initialized
INFO - 2023-10-29 18:26:26 --> Model "M_auth" initialized
INFO - 2023-10-29 18:26:26 --> Model "M_user" initialized
INFO - 2023-10-29 18:26:26 --> Model "M_produk" initialized
INFO - 2023-10-29 18:26:26 --> Controller Class Initialized
DEBUG - 2023-10-29 18:26:26 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:26:26 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 18:26:26 --> Final output sent to browser
DEBUG - 2023-10-29 18:26:26 --> Total execution time: 0.4019
ERROR - 2023-10-29 18:27:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:27:11 --> Config Class Initialized
INFO - 2023-10-29 18:27:11 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:27:11 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:27:11 --> Utf8 Class Initialized
INFO - 2023-10-29 18:27:11 --> URI Class Initialized
INFO - 2023-10-29 18:27:11 --> Router Class Initialized
INFO - 2023-10-29 18:27:11 --> Output Class Initialized
INFO - 2023-10-29 18:27:11 --> Security Class Initialized
DEBUG - 2023-10-29 18:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:27:11 --> Input Class Initialized
INFO - 2023-10-29 18:27:11 --> Language Class Initialized
INFO - 2023-10-29 18:27:11 --> Loader Class Initialized
INFO - 2023-10-29 18:27:11 --> Helper loaded: url_helper
INFO - 2023-10-29 18:27:11 --> Helper loaded: form_helper
INFO - 2023-10-29 18:27:11 --> Helper loaded: file_helper
INFO - 2023-10-29 18:27:11 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:27:11 --> Form Validation Class Initialized
INFO - 2023-10-29 18:27:11 --> Upload Class Initialized
INFO - 2023-10-29 18:27:11 --> Model "M_auth" initialized
INFO - 2023-10-29 18:27:11 --> Model "M_user" initialized
INFO - 2023-10-29 18:27:11 --> Model "M_produk" initialized
INFO - 2023-10-29 18:27:11 --> Controller Class Initialized
DEBUG - 2023-10-29 18:27:11 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:27:11 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 18:27:11 --> Final output sent to browser
DEBUG - 2023-10-29 18:27:11 --> Total execution time: 0.5022
ERROR - 2023-10-29 18:27:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:27:13 --> Config Class Initialized
INFO - 2023-10-29 18:27:13 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:27:13 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:27:13 --> Utf8 Class Initialized
INFO - 2023-10-29 18:27:13 --> URI Class Initialized
INFO - 2023-10-29 18:27:13 --> Router Class Initialized
INFO - 2023-10-29 18:27:13 --> Output Class Initialized
INFO - 2023-10-29 18:27:13 --> Security Class Initialized
DEBUG - 2023-10-29 18:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:27:13 --> Input Class Initialized
INFO - 2023-10-29 18:27:13 --> Language Class Initialized
INFO - 2023-10-29 18:27:13 --> Loader Class Initialized
INFO - 2023-10-29 18:27:13 --> Helper loaded: url_helper
INFO - 2023-10-29 18:27:13 --> Helper loaded: form_helper
INFO - 2023-10-29 18:27:13 --> Helper loaded: file_helper
INFO - 2023-10-29 18:27:13 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:27:13 --> Form Validation Class Initialized
INFO - 2023-10-29 18:27:13 --> Upload Class Initialized
INFO - 2023-10-29 18:27:13 --> Model "M_auth" initialized
INFO - 2023-10-29 18:27:13 --> Model "M_user" initialized
INFO - 2023-10-29 18:27:13 --> Model "M_produk" initialized
INFO - 2023-10-29 18:27:13 --> Controller Class Initialized
DEBUG - 2023-10-29 18:27:13 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:27:13 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:27:13 --> Final output sent to browser
DEBUG - 2023-10-29 18:27:13 --> Total execution time: 0.0285
ERROR - 2023-10-29 18:27:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:27:14 --> Config Class Initialized
INFO - 2023-10-29 18:27:14 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:27:14 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:27:14 --> Utf8 Class Initialized
INFO - 2023-10-29 18:27:14 --> URI Class Initialized
INFO - 2023-10-29 18:27:14 --> Router Class Initialized
INFO - 2023-10-29 18:27:14 --> Output Class Initialized
INFO - 2023-10-29 18:27:14 --> Security Class Initialized
DEBUG - 2023-10-29 18:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:27:14 --> Input Class Initialized
INFO - 2023-10-29 18:27:14 --> Language Class Initialized
INFO - 2023-10-29 18:27:14 --> Loader Class Initialized
INFO - 2023-10-29 18:27:14 --> Helper loaded: url_helper
INFO - 2023-10-29 18:27:15 --> Helper loaded: form_helper
INFO - 2023-10-29 18:27:15 --> Helper loaded: file_helper
INFO - 2023-10-29 18:27:15 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:27:15 --> Form Validation Class Initialized
INFO - 2023-10-29 18:27:15 --> Upload Class Initialized
INFO - 2023-10-29 18:27:15 --> Model "M_auth" initialized
INFO - 2023-10-29 18:27:15 --> Model "M_user" initialized
INFO - 2023-10-29 18:27:15 --> Model "M_produk" initialized
INFO - 2023-10-29 18:27:15 --> Controller Class Initialized
DEBUG - 2023-10-29 18:27:15 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:27:15 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:27:15 --> Final output sent to browser
DEBUG - 2023-10-29 18:27:15 --> Total execution time: 0.1077
ERROR - 2023-10-29 18:27:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:27:16 --> Config Class Initialized
INFO - 2023-10-29 18:27:16 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:27:16 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:27:16 --> Utf8 Class Initialized
INFO - 2023-10-29 18:27:16 --> URI Class Initialized
INFO - 2023-10-29 18:27:16 --> Router Class Initialized
INFO - 2023-10-29 18:27:16 --> Output Class Initialized
INFO - 2023-10-29 18:27:16 --> Security Class Initialized
DEBUG - 2023-10-29 18:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:27:16 --> Input Class Initialized
INFO - 2023-10-29 18:27:16 --> Language Class Initialized
INFO - 2023-10-29 18:27:16 --> Loader Class Initialized
INFO - 2023-10-29 18:27:16 --> Helper loaded: url_helper
INFO - 2023-10-29 18:27:16 --> Helper loaded: form_helper
INFO - 2023-10-29 18:27:16 --> Helper loaded: file_helper
INFO - 2023-10-29 18:27:16 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:27:16 --> Form Validation Class Initialized
INFO - 2023-10-29 18:27:16 --> Upload Class Initialized
INFO - 2023-10-29 18:27:16 --> Model "M_auth" initialized
INFO - 2023-10-29 18:27:16 --> Model "M_user" initialized
INFO - 2023-10-29 18:27:16 --> Model "M_produk" initialized
INFO - 2023-10-29 18:27:16 --> Controller Class Initialized
DEBUG - 2023-10-29 18:27:16 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:27:16 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:27:16 --> Final output sent to browser
DEBUG - 2023-10-29 18:27:16 --> Total execution time: 0.0805
ERROR - 2023-10-29 18:27:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:27:18 --> Config Class Initialized
INFO - 2023-10-29 18:27:18 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:27:18 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:27:18 --> Utf8 Class Initialized
INFO - 2023-10-29 18:27:18 --> URI Class Initialized
INFO - 2023-10-29 18:27:18 --> Router Class Initialized
INFO - 2023-10-29 18:27:18 --> Output Class Initialized
INFO - 2023-10-29 18:27:18 --> Security Class Initialized
DEBUG - 2023-10-29 18:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:27:18 --> Input Class Initialized
INFO - 2023-10-29 18:27:18 --> Language Class Initialized
INFO - 2023-10-29 18:27:18 --> Loader Class Initialized
INFO - 2023-10-29 18:27:18 --> Helper loaded: url_helper
INFO - 2023-10-29 18:27:18 --> Helper loaded: form_helper
INFO - 2023-10-29 18:27:18 --> Helper loaded: file_helper
INFO - 2023-10-29 18:27:18 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:27:18 --> Form Validation Class Initialized
INFO - 2023-10-29 18:27:18 --> Upload Class Initialized
INFO - 2023-10-29 18:27:18 --> Model "M_auth" initialized
INFO - 2023-10-29 18:27:18 --> Model "M_user" initialized
INFO - 2023-10-29 18:27:18 --> Model "M_produk" initialized
INFO - 2023-10-29 18:27:18 --> Controller Class Initialized
DEBUG - 2023-10-29 18:27:18 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:27:18 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 18:27:18 --> Final output sent to browser
DEBUG - 2023-10-29 18:27:18 --> Total execution time: 0.4579
ERROR - 2023-10-29 18:28:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:28:38 --> Config Class Initialized
INFO - 2023-10-29 18:28:38 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:28:38 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:28:38 --> Utf8 Class Initialized
INFO - 2023-10-29 18:28:38 --> URI Class Initialized
INFO - 2023-10-29 18:28:38 --> Router Class Initialized
INFO - 2023-10-29 18:28:38 --> Output Class Initialized
INFO - 2023-10-29 18:28:38 --> Security Class Initialized
DEBUG - 2023-10-29 18:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:28:38 --> Input Class Initialized
INFO - 2023-10-29 18:28:38 --> Language Class Initialized
INFO - 2023-10-29 18:28:38 --> Loader Class Initialized
INFO - 2023-10-29 18:28:38 --> Helper loaded: url_helper
INFO - 2023-10-29 18:28:38 --> Helper loaded: form_helper
INFO - 2023-10-29 18:28:38 --> Helper loaded: file_helper
INFO - 2023-10-29 18:28:38 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:28:38 --> Form Validation Class Initialized
INFO - 2023-10-29 18:28:38 --> Upload Class Initialized
INFO - 2023-10-29 18:28:38 --> Model "M_auth" initialized
INFO - 2023-10-29 18:28:38 --> Model "M_user" initialized
INFO - 2023-10-29 18:28:38 --> Model "M_produk" initialized
INFO - 2023-10-29 18:28:38 --> Controller Class Initialized
DEBUG - 2023-10-29 18:28:38 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:28:38 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 18:28:38 --> Final output sent to browser
DEBUG - 2023-10-29 18:28:38 --> Total execution time: 0.3930
ERROR - 2023-10-29 18:28:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:28:40 --> Config Class Initialized
INFO - 2023-10-29 18:28:40 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:28:40 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:28:40 --> Utf8 Class Initialized
INFO - 2023-10-29 18:28:40 --> URI Class Initialized
INFO - 2023-10-29 18:28:40 --> Router Class Initialized
INFO - 2023-10-29 18:28:40 --> Output Class Initialized
INFO - 2023-10-29 18:28:40 --> Security Class Initialized
DEBUG - 2023-10-29 18:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:28:40 --> Input Class Initialized
INFO - 2023-10-29 18:28:40 --> Language Class Initialized
INFO - 2023-10-29 18:28:40 --> Loader Class Initialized
INFO - 2023-10-29 18:28:40 --> Helper loaded: url_helper
INFO - 2023-10-29 18:28:40 --> Helper loaded: form_helper
INFO - 2023-10-29 18:28:40 --> Helper loaded: file_helper
INFO - 2023-10-29 18:28:40 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:28:40 --> Form Validation Class Initialized
INFO - 2023-10-29 18:28:40 --> Upload Class Initialized
INFO - 2023-10-29 18:28:40 --> Model "M_auth" initialized
INFO - 2023-10-29 18:28:40 --> Model "M_user" initialized
INFO - 2023-10-29 18:28:40 --> Model "M_produk" initialized
INFO - 2023-10-29 18:28:40 --> Controller Class Initialized
DEBUG - 2023-10-29 18:28:40 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:28:40 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:28:40 --> Final output sent to browser
DEBUG - 2023-10-29 18:28:40 --> Total execution time: 0.0708
ERROR - 2023-10-29 18:28:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:28:42 --> Config Class Initialized
INFO - 2023-10-29 18:28:42 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:28:42 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:28:42 --> Utf8 Class Initialized
INFO - 2023-10-29 18:28:42 --> URI Class Initialized
INFO - 2023-10-29 18:28:42 --> Router Class Initialized
INFO - 2023-10-29 18:28:42 --> Output Class Initialized
INFO - 2023-10-29 18:28:42 --> Security Class Initialized
DEBUG - 2023-10-29 18:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:28:42 --> Input Class Initialized
INFO - 2023-10-29 18:28:42 --> Language Class Initialized
INFO - 2023-10-29 18:28:42 --> Loader Class Initialized
INFO - 2023-10-29 18:28:42 --> Helper loaded: url_helper
INFO - 2023-10-29 18:28:42 --> Helper loaded: form_helper
INFO - 2023-10-29 18:28:42 --> Helper loaded: file_helper
INFO - 2023-10-29 18:28:42 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:28:42 --> Form Validation Class Initialized
INFO - 2023-10-29 18:28:42 --> Upload Class Initialized
INFO - 2023-10-29 18:28:42 --> Model "M_auth" initialized
INFO - 2023-10-29 18:28:42 --> Model "M_user" initialized
INFO - 2023-10-29 18:28:42 --> Model "M_produk" initialized
INFO - 2023-10-29 18:28:42 --> Controller Class Initialized
DEBUG - 2023-10-29 18:28:42 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:28:42 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:28:42 --> Final output sent to browser
DEBUG - 2023-10-29 18:28:42 --> Total execution time: 0.0778
ERROR - 2023-10-29 18:28:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:28:44 --> Config Class Initialized
INFO - 2023-10-29 18:28:44 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:28:44 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:28:44 --> Utf8 Class Initialized
INFO - 2023-10-29 18:28:44 --> URI Class Initialized
INFO - 2023-10-29 18:28:44 --> Router Class Initialized
INFO - 2023-10-29 18:28:44 --> Output Class Initialized
INFO - 2023-10-29 18:28:44 --> Security Class Initialized
DEBUG - 2023-10-29 18:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:28:44 --> Input Class Initialized
INFO - 2023-10-29 18:28:44 --> Language Class Initialized
INFO - 2023-10-29 18:28:44 --> Loader Class Initialized
INFO - 2023-10-29 18:28:44 --> Helper loaded: url_helper
INFO - 2023-10-29 18:28:44 --> Helper loaded: form_helper
INFO - 2023-10-29 18:28:44 --> Helper loaded: file_helper
INFO - 2023-10-29 18:28:44 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:28:44 --> Form Validation Class Initialized
INFO - 2023-10-29 18:28:44 --> Upload Class Initialized
INFO - 2023-10-29 18:28:44 --> Model "M_auth" initialized
INFO - 2023-10-29 18:28:44 --> Model "M_user" initialized
INFO - 2023-10-29 18:28:44 --> Model "M_produk" initialized
INFO - 2023-10-29 18:28:44 --> Controller Class Initialized
DEBUG - 2023-10-29 18:28:44 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 18:28:44 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 18:28:44 --> Final output sent to browser
DEBUG - 2023-10-29 18:28:44 --> Total execution time: 0.3853
ERROR - 2023-10-29 18:52:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:52:51 --> Config Class Initialized
INFO - 2023-10-29 18:52:51 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:52:51 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:52:51 --> Utf8 Class Initialized
INFO - 2023-10-29 18:52:51 --> URI Class Initialized
INFO - 2023-10-29 18:52:51 --> Router Class Initialized
INFO - 2023-10-29 18:52:51 --> Output Class Initialized
INFO - 2023-10-29 18:52:51 --> Security Class Initialized
DEBUG - 2023-10-29 18:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:52:51 --> Input Class Initialized
INFO - 2023-10-29 18:52:51 --> Language Class Initialized
INFO - 2023-10-29 18:52:51 --> Loader Class Initialized
INFO - 2023-10-29 18:52:51 --> Helper loaded: url_helper
INFO - 2023-10-29 18:52:51 --> Helper loaded: form_helper
INFO - 2023-10-29 18:52:51 --> Helper loaded: file_helper
INFO - 2023-10-29 18:52:51 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:52:51 --> Form Validation Class Initialized
INFO - 2023-10-29 18:52:51 --> Upload Class Initialized
INFO - 2023-10-29 18:52:51 --> Model "M_auth" initialized
INFO - 2023-10-29 18:52:51 --> Model "M_user" initialized
INFO - 2023-10-29 18:52:51 --> Model "M_produk" initialized
INFO - 2023-10-29 18:52:51 --> Controller Class Initialized
DEBUG - 2023-10-29 18:52:51 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-29 18:52:51 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php 24
INFO - 2023-10-29 18:52:51 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:52:51 --> Final output sent to browser
DEBUG - 2023-10-29 18:52:51 --> Total execution time: 0.1243
ERROR - 2023-10-29 18:52:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:52:54 --> Config Class Initialized
INFO - 2023-10-29 18:52:54 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:52:54 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:52:54 --> Utf8 Class Initialized
INFO - 2023-10-29 18:52:54 --> URI Class Initialized
INFO - 2023-10-29 18:52:54 --> Router Class Initialized
INFO - 2023-10-29 18:52:54 --> Output Class Initialized
INFO - 2023-10-29 18:52:54 --> Security Class Initialized
DEBUG - 2023-10-29 18:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:52:54 --> Input Class Initialized
INFO - 2023-10-29 18:52:54 --> Language Class Initialized
INFO - 2023-10-29 18:52:54 --> Loader Class Initialized
INFO - 2023-10-29 18:52:54 --> Helper loaded: url_helper
INFO - 2023-10-29 18:52:54 --> Helper loaded: form_helper
INFO - 2023-10-29 18:52:54 --> Helper loaded: file_helper
INFO - 2023-10-29 18:52:54 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:52:54 --> Form Validation Class Initialized
INFO - 2023-10-29 18:52:54 --> Upload Class Initialized
INFO - 2023-10-29 18:52:54 --> Model "M_auth" initialized
INFO - 2023-10-29 18:52:54 --> Model "M_user" initialized
INFO - 2023-10-29 18:52:54 --> Model "M_produk" initialized
INFO - 2023-10-29 18:52:54 --> Controller Class Initialized
DEBUG - 2023-10-29 18:52:54 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-29 18:52:54 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php 24
INFO - 2023-10-29 18:52:54 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:52:54 --> Final output sent to browser
DEBUG - 2023-10-29 18:52:54 --> Total execution time: 0.0549
ERROR - 2023-10-29 18:53:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 18:53:38 --> Config Class Initialized
INFO - 2023-10-29 18:53:38 --> Hooks Class Initialized
DEBUG - 2023-10-29 18:53:38 --> UTF-8 Support Enabled
INFO - 2023-10-29 18:53:38 --> Utf8 Class Initialized
INFO - 2023-10-29 18:53:38 --> URI Class Initialized
INFO - 2023-10-29 18:53:38 --> Router Class Initialized
INFO - 2023-10-29 18:53:38 --> Output Class Initialized
INFO - 2023-10-29 18:53:38 --> Security Class Initialized
DEBUG - 2023-10-29 18:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 18:53:38 --> Input Class Initialized
INFO - 2023-10-29 18:53:38 --> Language Class Initialized
INFO - 2023-10-29 18:53:38 --> Loader Class Initialized
INFO - 2023-10-29 18:53:38 --> Helper loaded: url_helper
INFO - 2023-10-29 18:53:38 --> Helper loaded: form_helper
INFO - 2023-10-29 18:53:38 --> Helper loaded: file_helper
INFO - 2023-10-29 18:53:38 --> Database Driver Class Initialized
DEBUG - 2023-10-29 18:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 18:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 18:53:38 --> Form Validation Class Initialized
INFO - 2023-10-29 18:53:38 --> Upload Class Initialized
INFO - 2023-10-29 18:53:38 --> Model "M_auth" initialized
INFO - 2023-10-29 18:53:38 --> Model "M_user" initialized
INFO - 2023-10-29 18:53:38 --> Model "M_produk" initialized
INFO - 2023-10-29 18:53:38 --> Controller Class Initialized
DEBUG - 2023-10-29 18:53:38 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-29 18:53:38 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php 24
INFO - 2023-10-29 18:53:38 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 18:53:38 --> Final output sent to browser
DEBUG - 2023-10-29 18:53:38 --> Total execution time: 0.0602
ERROR - 2023-10-29 19:13:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 19:13:35 --> Config Class Initialized
INFO - 2023-10-29 19:13:35 --> Hooks Class Initialized
DEBUG - 2023-10-29 19:13:35 --> UTF-8 Support Enabled
INFO - 2023-10-29 19:13:35 --> Utf8 Class Initialized
INFO - 2023-10-29 19:13:35 --> URI Class Initialized
INFO - 2023-10-29 19:13:35 --> Router Class Initialized
INFO - 2023-10-29 19:13:35 --> Output Class Initialized
INFO - 2023-10-29 19:13:35 --> Security Class Initialized
DEBUG - 2023-10-29 19:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 19:13:35 --> Input Class Initialized
INFO - 2023-10-29 19:13:35 --> Language Class Initialized
INFO - 2023-10-29 19:13:35 --> Loader Class Initialized
INFO - 2023-10-29 19:13:35 --> Helper loaded: url_helper
INFO - 2023-10-29 19:13:35 --> Helper loaded: form_helper
INFO - 2023-10-29 19:13:35 --> Helper loaded: file_helper
INFO - 2023-10-29 19:13:35 --> Database Driver Class Initialized
DEBUG - 2023-10-29 19:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 19:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 19:13:35 --> Form Validation Class Initialized
INFO - 2023-10-29 19:13:35 --> Upload Class Initialized
INFO - 2023-10-29 19:13:35 --> Model "M_auth" initialized
INFO - 2023-10-29 19:13:35 --> Model "M_user" initialized
INFO - 2023-10-29 19:13:35 --> Model "M_produk" initialized
INFO - 2023-10-29 19:13:35 --> Controller Class Initialized
DEBUG - 2023-10-29 19:13:35 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-29 19:13:35 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php 27
INFO - 2023-10-29 19:13:35 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 19:13:35 --> Final output sent to browser
DEBUG - 2023-10-29 19:13:35 --> Total execution time: 0.1018
ERROR - 2023-10-29 19:14:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 19:14:34 --> Config Class Initialized
INFO - 2023-10-29 19:14:34 --> Hooks Class Initialized
DEBUG - 2023-10-29 19:14:34 --> UTF-8 Support Enabled
INFO - 2023-10-29 19:14:34 --> Utf8 Class Initialized
INFO - 2023-10-29 19:14:34 --> URI Class Initialized
INFO - 2023-10-29 19:14:34 --> Router Class Initialized
INFO - 2023-10-29 19:14:34 --> Output Class Initialized
INFO - 2023-10-29 19:14:34 --> Security Class Initialized
DEBUG - 2023-10-29 19:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 19:14:34 --> Input Class Initialized
INFO - 2023-10-29 19:14:34 --> Language Class Initialized
INFO - 2023-10-29 19:14:34 --> Loader Class Initialized
INFO - 2023-10-29 19:14:34 --> Helper loaded: url_helper
INFO - 2023-10-29 19:14:34 --> Helper loaded: form_helper
INFO - 2023-10-29 19:14:34 --> Helper loaded: file_helper
INFO - 2023-10-29 19:14:34 --> Database Driver Class Initialized
DEBUG - 2023-10-29 19:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 19:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 19:14:34 --> Form Validation Class Initialized
INFO - 2023-10-29 19:14:34 --> Upload Class Initialized
INFO - 2023-10-29 19:14:34 --> Model "M_auth" initialized
INFO - 2023-10-29 19:14:34 --> Model "M_user" initialized
INFO - 2023-10-29 19:14:34 --> Model "M_produk" initialized
INFO - 2023-10-29 19:14:34 --> Controller Class Initialized
DEBUG - 2023-10-29 19:14:34 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-29 19:14:34 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php 27
INFO - 2023-10-29 19:14:34 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 19:14:34 --> Final output sent to browser
DEBUG - 2023-10-29 19:14:34 --> Total execution time: 0.0638
ERROR - 2023-10-29 19:14:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 19:14:42 --> Config Class Initialized
INFO - 2023-10-29 19:14:42 --> Hooks Class Initialized
DEBUG - 2023-10-29 19:14:42 --> UTF-8 Support Enabled
INFO - 2023-10-29 19:14:42 --> Utf8 Class Initialized
INFO - 2023-10-29 19:14:42 --> URI Class Initialized
INFO - 2023-10-29 19:14:42 --> Router Class Initialized
INFO - 2023-10-29 19:14:42 --> Output Class Initialized
INFO - 2023-10-29 19:14:42 --> Security Class Initialized
DEBUG - 2023-10-29 19:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 19:14:42 --> Input Class Initialized
INFO - 2023-10-29 19:14:42 --> Language Class Initialized
INFO - 2023-10-29 19:14:42 --> Loader Class Initialized
INFO - 2023-10-29 19:14:42 --> Helper loaded: url_helper
INFO - 2023-10-29 19:14:42 --> Helper loaded: form_helper
INFO - 2023-10-29 19:14:42 --> Helper loaded: file_helper
INFO - 2023-10-29 19:14:42 --> Database Driver Class Initialized
DEBUG - 2023-10-29 19:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 19:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 19:14:42 --> Form Validation Class Initialized
INFO - 2023-10-29 19:14:42 --> Upload Class Initialized
INFO - 2023-10-29 19:14:42 --> Model "M_auth" initialized
INFO - 2023-10-29 19:14:42 --> Model "M_user" initialized
INFO - 2023-10-29 19:14:42 --> Model "M_produk" initialized
INFO - 2023-10-29 19:14:42 --> Controller Class Initialized
DEBUG - 2023-10-29 19:14:42 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 19:14:42 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 19:14:42 --> Final output sent to browser
DEBUG - 2023-10-29 19:14:42 --> Total execution time: 0.0806
ERROR - 2023-10-29 19:14:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 19:14:44 --> Config Class Initialized
INFO - 2023-10-29 19:14:44 --> Hooks Class Initialized
DEBUG - 2023-10-29 19:14:44 --> UTF-8 Support Enabled
INFO - 2023-10-29 19:14:44 --> Utf8 Class Initialized
INFO - 2023-10-29 19:14:44 --> URI Class Initialized
INFO - 2023-10-29 19:14:44 --> Router Class Initialized
INFO - 2023-10-29 19:14:44 --> Output Class Initialized
INFO - 2023-10-29 19:14:44 --> Security Class Initialized
DEBUG - 2023-10-29 19:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 19:14:44 --> Input Class Initialized
INFO - 2023-10-29 19:14:44 --> Language Class Initialized
INFO - 2023-10-29 19:14:44 --> Loader Class Initialized
INFO - 2023-10-29 19:14:44 --> Helper loaded: url_helper
INFO - 2023-10-29 19:14:44 --> Helper loaded: form_helper
INFO - 2023-10-29 19:14:44 --> Helper loaded: file_helper
INFO - 2023-10-29 19:14:44 --> Database Driver Class Initialized
DEBUG - 2023-10-29 19:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 19:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 19:14:44 --> Form Validation Class Initialized
INFO - 2023-10-29 19:14:44 --> Upload Class Initialized
INFO - 2023-10-29 19:14:44 --> Model "M_auth" initialized
INFO - 2023-10-29 19:14:44 --> Model "M_user" initialized
INFO - 2023-10-29 19:14:44 --> Model "M_produk" initialized
INFO - 2023-10-29 19:14:44 --> Controller Class Initialized
DEBUG - 2023-10-29 19:14:44 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 19:14:45 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 19:14:45 --> Final output sent to browser
DEBUG - 2023-10-29 19:14:45 --> Total execution time: 0.4393
ERROR - 2023-10-29 19:14:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 19:14:54 --> Config Class Initialized
INFO - 2023-10-29 19:14:54 --> Hooks Class Initialized
DEBUG - 2023-10-29 19:14:54 --> UTF-8 Support Enabled
INFO - 2023-10-29 19:14:54 --> Utf8 Class Initialized
INFO - 2023-10-29 19:14:54 --> URI Class Initialized
INFO - 2023-10-29 19:14:54 --> Router Class Initialized
INFO - 2023-10-29 19:14:54 --> Output Class Initialized
INFO - 2023-10-29 19:14:54 --> Security Class Initialized
DEBUG - 2023-10-29 19:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 19:14:54 --> Input Class Initialized
INFO - 2023-10-29 19:14:54 --> Language Class Initialized
INFO - 2023-10-29 19:14:54 --> Loader Class Initialized
INFO - 2023-10-29 19:14:54 --> Helper loaded: url_helper
INFO - 2023-10-29 19:14:54 --> Helper loaded: form_helper
INFO - 2023-10-29 19:14:54 --> Helper loaded: file_helper
INFO - 2023-10-29 19:14:54 --> Database Driver Class Initialized
DEBUG - 2023-10-29 19:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 19:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 19:14:54 --> Form Validation Class Initialized
INFO - 2023-10-29 19:14:54 --> Upload Class Initialized
INFO - 2023-10-29 19:14:54 --> Model "M_auth" initialized
INFO - 2023-10-29 19:14:54 --> Model "M_user" initialized
INFO - 2023-10-29 19:14:54 --> Model "M_produk" initialized
INFO - 2023-10-29 19:14:54 --> Controller Class Initialized
DEBUG - 2023-10-29 19:14:54 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 19:14:54 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 19:14:54 --> Final output sent to browser
DEBUG - 2023-10-29 19:14:54 --> Total execution time: 0.0830
ERROR - 2023-10-29 19:15:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 19:15:45 --> Config Class Initialized
INFO - 2023-10-29 19:15:45 --> Hooks Class Initialized
DEBUG - 2023-10-29 19:15:45 --> UTF-8 Support Enabled
INFO - 2023-10-29 19:15:45 --> Utf8 Class Initialized
INFO - 2023-10-29 19:15:45 --> URI Class Initialized
INFO - 2023-10-29 19:15:45 --> Router Class Initialized
INFO - 2023-10-29 19:15:45 --> Output Class Initialized
INFO - 2023-10-29 19:15:45 --> Security Class Initialized
DEBUG - 2023-10-29 19:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 19:15:45 --> Input Class Initialized
INFO - 2023-10-29 19:15:45 --> Language Class Initialized
INFO - 2023-10-29 19:15:45 --> Loader Class Initialized
INFO - 2023-10-29 19:15:45 --> Helper loaded: url_helper
INFO - 2023-10-29 19:15:45 --> Helper loaded: form_helper
INFO - 2023-10-29 19:15:45 --> Helper loaded: file_helper
INFO - 2023-10-29 19:15:45 --> Database Driver Class Initialized
DEBUG - 2023-10-29 19:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 19:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 19:15:45 --> Form Validation Class Initialized
INFO - 2023-10-29 19:15:45 --> Upload Class Initialized
INFO - 2023-10-29 19:15:45 --> Model "M_auth" initialized
INFO - 2023-10-29 19:15:45 --> Model "M_user" initialized
INFO - 2023-10-29 19:15:45 --> Model "M_produk" initialized
INFO - 2023-10-29 19:15:45 --> Controller Class Initialized
DEBUG - 2023-10-29 19:15:45 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 19:15:45 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_popup.php
INFO - 2023-10-29 19:15:45 --> Final output sent to browser
DEBUG - 2023-10-29 19:15:45 --> Total execution time: 0.3861
ERROR - 2023-10-29 19:15:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 19:15:54 --> Config Class Initialized
INFO - 2023-10-29 19:15:54 --> Hooks Class Initialized
DEBUG - 2023-10-29 19:15:54 --> UTF-8 Support Enabled
INFO - 2023-10-29 19:15:54 --> Utf8 Class Initialized
INFO - 2023-10-29 19:15:54 --> URI Class Initialized
INFO - 2023-10-29 19:15:54 --> Router Class Initialized
INFO - 2023-10-29 19:15:54 --> Output Class Initialized
INFO - 2023-10-29 19:15:54 --> Security Class Initialized
DEBUG - 2023-10-29 19:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 19:15:54 --> Input Class Initialized
INFO - 2023-10-29 19:15:54 --> Language Class Initialized
INFO - 2023-10-29 19:15:54 --> Loader Class Initialized
INFO - 2023-10-29 19:15:54 --> Helper loaded: url_helper
INFO - 2023-10-29 19:15:54 --> Helper loaded: form_helper
INFO - 2023-10-29 19:15:54 --> Helper loaded: file_helper
INFO - 2023-10-29 19:15:54 --> Database Driver Class Initialized
DEBUG - 2023-10-29 19:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 19:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 19:15:54 --> Form Validation Class Initialized
INFO - 2023-10-29 19:15:54 --> Upload Class Initialized
INFO - 2023-10-29 19:15:54 --> Model "M_auth" initialized
INFO - 2023-10-29 19:15:54 --> Model "M_user" initialized
INFO - 2023-10-29 19:15:54 --> Model "M_produk" initialized
INFO - 2023-10-29 19:15:54 --> Controller Class Initialized
DEBUG - 2023-10-29 19:15:54 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 19:15:54 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 19:15:54 --> Final output sent to browser
DEBUG - 2023-10-29 19:15:54 --> Total execution time: 0.0483
ERROR - 2023-10-29 19:28:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 19:28:54 --> Config Class Initialized
INFO - 2023-10-29 19:28:54 --> Hooks Class Initialized
DEBUG - 2023-10-29 19:28:54 --> UTF-8 Support Enabled
INFO - 2023-10-29 19:28:54 --> Utf8 Class Initialized
INFO - 2023-10-29 19:28:54 --> URI Class Initialized
INFO - 2023-10-29 19:28:54 --> Router Class Initialized
INFO - 2023-10-29 19:28:54 --> Output Class Initialized
INFO - 2023-10-29 19:28:54 --> Security Class Initialized
DEBUG - 2023-10-29 19:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 19:28:54 --> Input Class Initialized
INFO - 2023-10-29 19:28:54 --> Language Class Initialized
INFO - 2023-10-29 19:28:54 --> Loader Class Initialized
INFO - 2023-10-29 19:28:54 --> Helper loaded: url_helper
INFO - 2023-10-29 19:28:54 --> Helper loaded: form_helper
INFO - 2023-10-29 19:28:54 --> Helper loaded: file_helper
INFO - 2023-10-29 19:28:54 --> Database Driver Class Initialized
DEBUG - 2023-10-29 19:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 19:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 19:28:54 --> Form Validation Class Initialized
INFO - 2023-10-29 19:28:54 --> Upload Class Initialized
INFO - 2023-10-29 19:28:54 --> Model "M_auth" initialized
INFO - 2023-10-29 19:28:54 --> Model "M_user" initialized
INFO - 2023-10-29 19:28:54 --> Model "M_produk" initialized
INFO - 2023-10-29 19:28:54 --> Controller Class Initialized
DEBUG - 2023-10-29 19:28:54 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 19:28:54 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 19:28:54 --> Final output sent to browser
DEBUG - 2023-10-29 19:28:54 --> Total execution time: 0.4103
ERROR - 2023-10-29 19:31:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 19:31:01 --> Config Class Initialized
INFO - 2023-10-29 19:31:01 --> Hooks Class Initialized
DEBUG - 2023-10-29 19:31:01 --> UTF-8 Support Enabled
INFO - 2023-10-29 19:31:01 --> Utf8 Class Initialized
INFO - 2023-10-29 19:31:01 --> URI Class Initialized
INFO - 2023-10-29 19:31:01 --> Router Class Initialized
INFO - 2023-10-29 19:31:01 --> Output Class Initialized
INFO - 2023-10-29 19:31:01 --> Security Class Initialized
DEBUG - 2023-10-29 19:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 19:31:01 --> Input Class Initialized
INFO - 2023-10-29 19:31:01 --> Language Class Initialized
INFO - 2023-10-29 19:31:01 --> Loader Class Initialized
INFO - 2023-10-29 19:31:01 --> Helper loaded: url_helper
INFO - 2023-10-29 19:31:01 --> Helper loaded: form_helper
INFO - 2023-10-29 19:31:01 --> Helper loaded: file_helper
INFO - 2023-10-29 19:31:01 --> Database Driver Class Initialized
DEBUG - 2023-10-29 19:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 19:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 19:31:01 --> Form Validation Class Initialized
INFO - 2023-10-29 19:31:01 --> Upload Class Initialized
INFO - 2023-10-29 19:31:01 --> Model "M_auth" initialized
INFO - 2023-10-29 19:31:01 --> Model "M_user" initialized
INFO - 2023-10-29 19:31:01 --> Model "M_produk" initialized
INFO - 2023-10-29 19:31:01 --> Controller Class Initialized
DEBUG - 2023-10-29 19:31:01 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 19:31:01 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 19:31:01 --> Final output sent to browser
DEBUG - 2023-10-29 19:31:01 --> Total execution time: 0.4964
ERROR - 2023-10-29 19:39:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 19:39:14 --> Config Class Initialized
INFO - 2023-10-29 19:39:14 --> Hooks Class Initialized
DEBUG - 2023-10-29 19:39:15 --> UTF-8 Support Enabled
INFO - 2023-10-29 19:39:15 --> Utf8 Class Initialized
INFO - 2023-10-29 19:39:15 --> URI Class Initialized
INFO - 2023-10-29 19:39:15 --> Router Class Initialized
INFO - 2023-10-29 19:39:15 --> Output Class Initialized
INFO - 2023-10-29 19:39:15 --> Security Class Initialized
DEBUG - 2023-10-29 19:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 19:39:15 --> Input Class Initialized
INFO - 2023-10-29 19:39:15 --> Language Class Initialized
INFO - 2023-10-29 19:39:15 --> Loader Class Initialized
INFO - 2023-10-29 19:39:15 --> Helper loaded: url_helper
INFO - 2023-10-29 19:39:15 --> Helper loaded: form_helper
INFO - 2023-10-29 19:39:15 --> Helper loaded: file_helper
INFO - 2023-10-29 19:39:15 --> Database Driver Class Initialized
DEBUG - 2023-10-29 19:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 19:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 19:39:15 --> Form Validation Class Initialized
INFO - 2023-10-29 19:39:15 --> Upload Class Initialized
INFO - 2023-10-29 19:39:15 --> Model "M_auth" initialized
INFO - 2023-10-29 19:39:15 --> Model "M_user" initialized
INFO - 2023-10-29 19:39:15 --> Model "M_produk" initialized
INFO - 2023-10-29 19:39:15 --> Controller Class Initialized
DEBUG - 2023-10-29 19:39:15 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 19:39:15 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 19:39:15 --> Final output sent to browser
DEBUG - 2023-10-29 19:39:15 --> Total execution time: 0.4825
ERROR - 2023-10-29 19:39:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 19:39:17 --> Config Class Initialized
INFO - 2023-10-29 19:39:17 --> Hooks Class Initialized
DEBUG - 2023-10-29 19:39:17 --> UTF-8 Support Enabled
INFO - 2023-10-29 19:39:17 --> Utf8 Class Initialized
INFO - 2023-10-29 19:39:17 --> URI Class Initialized
INFO - 2023-10-29 19:39:17 --> Router Class Initialized
INFO - 2023-10-29 19:39:17 --> Output Class Initialized
INFO - 2023-10-29 19:39:17 --> Security Class Initialized
DEBUG - 2023-10-29 19:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 19:39:17 --> Input Class Initialized
INFO - 2023-10-29 19:39:17 --> Language Class Initialized
INFO - 2023-10-29 19:39:17 --> Loader Class Initialized
INFO - 2023-10-29 19:39:17 --> Helper loaded: url_helper
INFO - 2023-10-29 19:39:17 --> Helper loaded: form_helper
INFO - 2023-10-29 19:39:17 --> Helper loaded: file_helper
INFO - 2023-10-29 19:39:17 --> Database Driver Class Initialized
DEBUG - 2023-10-29 19:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 19:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 19:39:17 --> Form Validation Class Initialized
INFO - 2023-10-29 19:39:17 --> Upload Class Initialized
INFO - 2023-10-29 19:39:17 --> Model "M_auth" initialized
INFO - 2023-10-29 19:39:17 --> Model "M_user" initialized
INFO - 2023-10-29 19:39:17 --> Model "M_produk" initialized
INFO - 2023-10-29 19:39:17 --> Controller Class Initialized
DEBUG - 2023-10-29 19:39:17 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 19:39:17 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 19:39:17 --> Final output sent to browser
DEBUG - 2023-10-29 19:39:17 --> Total execution time: 0.3599
ERROR - 2023-10-29 19:39:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 19:39:29 --> Config Class Initialized
INFO - 2023-10-29 19:39:29 --> Hooks Class Initialized
DEBUG - 2023-10-29 19:39:29 --> UTF-8 Support Enabled
INFO - 2023-10-29 19:39:29 --> Utf8 Class Initialized
INFO - 2023-10-29 19:39:29 --> URI Class Initialized
INFO - 2023-10-29 19:39:29 --> Router Class Initialized
INFO - 2023-10-29 19:39:29 --> Output Class Initialized
INFO - 2023-10-29 19:39:29 --> Security Class Initialized
DEBUG - 2023-10-29 19:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 19:39:29 --> Input Class Initialized
INFO - 2023-10-29 19:39:29 --> Language Class Initialized
INFO - 2023-10-29 19:39:29 --> Loader Class Initialized
INFO - 2023-10-29 19:39:29 --> Helper loaded: url_helper
INFO - 2023-10-29 19:39:29 --> Helper loaded: form_helper
INFO - 2023-10-29 19:39:29 --> Helper loaded: file_helper
INFO - 2023-10-29 19:39:29 --> Database Driver Class Initialized
DEBUG - 2023-10-29 19:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 19:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 19:39:29 --> Form Validation Class Initialized
INFO - 2023-10-29 19:39:29 --> Upload Class Initialized
INFO - 2023-10-29 19:39:29 --> Model "M_auth" initialized
INFO - 2023-10-29 19:39:29 --> Model "M_user" initialized
INFO - 2023-10-29 19:39:29 --> Model "M_produk" initialized
INFO - 2023-10-29 19:39:29 --> Controller Class Initialized
DEBUG - 2023-10-29 19:39:29 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 19:39:29 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 19:39:30 --> Final output sent to browser
DEBUG - 2023-10-29 19:39:30 --> Total execution time: 0.3604
ERROR - 2023-10-29 19:39:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 19:39:50 --> Config Class Initialized
INFO - 2023-10-29 19:39:50 --> Hooks Class Initialized
DEBUG - 2023-10-29 19:39:50 --> UTF-8 Support Enabled
INFO - 2023-10-29 19:39:50 --> Utf8 Class Initialized
INFO - 2023-10-29 19:39:50 --> URI Class Initialized
INFO - 2023-10-29 19:39:50 --> Router Class Initialized
INFO - 2023-10-29 19:39:50 --> Output Class Initialized
INFO - 2023-10-29 19:39:50 --> Security Class Initialized
DEBUG - 2023-10-29 19:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 19:39:50 --> Input Class Initialized
INFO - 2023-10-29 19:39:50 --> Language Class Initialized
INFO - 2023-10-29 19:39:50 --> Loader Class Initialized
INFO - 2023-10-29 19:39:50 --> Helper loaded: url_helper
INFO - 2023-10-29 19:39:50 --> Helper loaded: form_helper
INFO - 2023-10-29 19:39:50 --> Helper loaded: file_helper
INFO - 2023-10-29 19:39:50 --> Database Driver Class Initialized
DEBUG - 2023-10-29 19:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 19:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 19:39:50 --> Form Validation Class Initialized
INFO - 2023-10-29 19:39:50 --> Upload Class Initialized
INFO - 2023-10-29 19:39:50 --> Model "M_auth" initialized
INFO - 2023-10-29 19:39:50 --> Model "M_user" initialized
INFO - 2023-10-29 19:39:50 --> Model "M_produk" initialized
INFO - 2023-10-29 19:39:50 --> Controller Class Initialized
DEBUG - 2023-10-29 19:39:50 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 19:39:51 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 19:39:51 --> Final output sent to browser
DEBUG - 2023-10-29 19:39:51 --> Total execution time: 0.3675
ERROR - 2023-10-29 19:40:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 19:40:01 --> Config Class Initialized
INFO - 2023-10-29 19:40:01 --> Hooks Class Initialized
DEBUG - 2023-10-29 19:40:01 --> UTF-8 Support Enabled
INFO - 2023-10-29 19:40:01 --> Utf8 Class Initialized
INFO - 2023-10-29 19:40:01 --> URI Class Initialized
INFO - 2023-10-29 19:40:01 --> Router Class Initialized
INFO - 2023-10-29 19:40:01 --> Output Class Initialized
INFO - 2023-10-29 19:40:01 --> Security Class Initialized
DEBUG - 2023-10-29 19:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 19:40:01 --> Input Class Initialized
INFO - 2023-10-29 19:40:01 --> Language Class Initialized
INFO - 2023-10-29 19:40:01 --> Loader Class Initialized
INFO - 2023-10-29 19:40:01 --> Helper loaded: url_helper
INFO - 2023-10-29 19:40:01 --> Helper loaded: form_helper
INFO - 2023-10-29 19:40:01 --> Helper loaded: file_helper
INFO - 2023-10-29 19:40:02 --> Database Driver Class Initialized
DEBUG - 2023-10-29 19:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 19:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 19:40:02 --> Form Validation Class Initialized
INFO - 2023-10-29 19:40:02 --> Upload Class Initialized
INFO - 2023-10-29 19:40:02 --> Model "M_auth" initialized
INFO - 2023-10-29 19:40:02 --> Model "M_user" initialized
INFO - 2023-10-29 19:40:02 --> Model "M_produk" initialized
INFO - 2023-10-29 19:40:02 --> Controller Class Initialized
DEBUG - 2023-10-29 19:40:02 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 19:40:02 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 19:40:02 --> Final output sent to browser
DEBUG - 2023-10-29 19:40:02 --> Total execution time: 0.3989
ERROR - 2023-10-29 19:40:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 19:40:19 --> Config Class Initialized
INFO - 2023-10-29 19:40:19 --> Hooks Class Initialized
DEBUG - 2023-10-29 19:40:19 --> UTF-8 Support Enabled
INFO - 2023-10-29 19:40:19 --> Utf8 Class Initialized
INFO - 2023-10-29 19:40:19 --> URI Class Initialized
INFO - 2023-10-29 19:40:19 --> Router Class Initialized
INFO - 2023-10-29 19:40:19 --> Output Class Initialized
INFO - 2023-10-29 19:40:19 --> Security Class Initialized
DEBUG - 2023-10-29 19:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 19:40:19 --> Input Class Initialized
INFO - 2023-10-29 19:40:19 --> Language Class Initialized
INFO - 2023-10-29 19:40:19 --> Loader Class Initialized
INFO - 2023-10-29 19:40:19 --> Helper loaded: url_helper
INFO - 2023-10-29 19:40:19 --> Helper loaded: form_helper
INFO - 2023-10-29 19:40:19 --> Helper loaded: file_helper
INFO - 2023-10-29 19:40:19 --> Database Driver Class Initialized
DEBUG - 2023-10-29 19:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 19:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 19:40:19 --> Form Validation Class Initialized
INFO - 2023-10-29 19:40:19 --> Upload Class Initialized
INFO - 2023-10-29 19:40:19 --> Model "M_auth" initialized
INFO - 2023-10-29 19:40:19 --> Model "M_user" initialized
INFO - 2023-10-29 19:40:19 --> Model "M_produk" initialized
INFO - 2023-10-29 19:40:19 --> Controller Class Initialized
DEBUG - 2023-10-29 19:40:19 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 19:40:19 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 19:40:19 --> Final output sent to browser
DEBUG - 2023-10-29 19:40:19 --> Total execution time: 0.3465
ERROR - 2023-10-29 19:42:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 19:42:24 --> Config Class Initialized
INFO - 2023-10-29 19:42:24 --> Hooks Class Initialized
DEBUG - 2023-10-29 19:42:24 --> UTF-8 Support Enabled
INFO - 2023-10-29 19:42:24 --> Utf8 Class Initialized
INFO - 2023-10-29 19:42:24 --> URI Class Initialized
INFO - 2023-10-29 19:42:24 --> Router Class Initialized
INFO - 2023-10-29 19:42:24 --> Output Class Initialized
INFO - 2023-10-29 19:42:24 --> Security Class Initialized
DEBUG - 2023-10-29 19:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 19:42:24 --> Input Class Initialized
INFO - 2023-10-29 19:42:24 --> Language Class Initialized
INFO - 2023-10-29 19:42:24 --> Loader Class Initialized
INFO - 2023-10-29 19:42:24 --> Helper loaded: url_helper
INFO - 2023-10-29 19:42:24 --> Helper loaded: form_helper
INFO - 2023-10-29 19:42:24 --> Helper loaded: file_helper
INFO - 2023-10-29 19:42:24 --> Database Driver Class Initialized
DEBUG - 2023-10-29 19:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 19:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 19:42:24 --> Form Validation Class Initialized
INFO - 2023-10-29 19:42:24 --> Upload Class Initialized
INFO - 2023-10-29 19:42:24 --> Model "M_auth" initialized
INFO - 2023-10-29 19:42:24 --> Model "M_user" initialized
INFO - 2023-10-29 19:42:24 --> Model "M_produk" initialized
INFO - 2023-10-29 19:42:24 --> Controller Class Initialized
DEBUG - 2023-10-29 19:42:24 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 19:42:25 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 19:42:25 --> Final output sent to browser
DEBUG - 2023-10-29 19:42:25 --> Total execution time: 0.4248
ERROR - 2023-10-29 19:42:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 19:42:29 --> Config Class Initialized
INFO - 2023-10-29 19:42:29 --> Hooks Class Initialized
DEBUG - 2023-10-29 19:42:29 --> UTF-8 Support Enabled
INFO - 2023-10-29 19:42:29 --> Utf8 Class Initialized
INFO - 2023-10-29 19:42:29 --> URI Class Initialized
INFO - 2023-10-29 19:42:29 --> Router Class Initialized
INFO - 2023-10-29 19:42:29 --> Output Class Initialized
INFO - 2023-10-29 19:42:29 --> Security Class Initialized
DEBUG - 2023-10-29 19:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 19:42:29 --> Input Class Initialized
INFO - 2023-10-29 19:42:29 --> Language Class Initialized
INFO - 2023-10-29 19:42:29 --> Loader Class Initialized
INFO - 2023-10-29 19:42:29 --> Helper loaded: url_helper
INFO - 2023-10-29 19:42:29 --> Helper loaded: form_helper
INFO - 2023-10-29 19:42:29 --> Helper loaded: file_helper
INFO - 2023-10-29 19:42:29 --> Database Driver Class Initialized
DEBUG - 2023-10-29 19:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 19:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 19:42:29 --> Form Validation Class Initialized
INFO - 2023-10-29 19:42:29 --> Upload Class Initialized
INFO - 2023-10-29 19:42:29 --> Model "M_auth" initialized
INFO - 2023-10-29 19:42:29 --> Model "M_user" initialized
INFO - 2023-10-29 19:42:29 --> Model "M_produk" initialized
INFO - 2023-10-29 19:42:29 --> Controller Class Initialized
DEBUG - 2023-10-29 19:42:29 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 19:42:30 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 19:42:30 --> Final output sent to browser
DEBUG - 2023-10-29 19:42:30 --> Total execution time: 0.4626
ERROR - 2023-10-29 19:43:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-29 19:43:31 --> Config Class Initialized
INFO - 2023-10-29 19:43:31 --> Hooks Class Initialized
DEBUG - 2023-10-29 19:43:31 --> UTF-8 Support Enabled
INFO - 2023-10-29 19:43:31 --> Utf8 Class Initialized
INFO - 2023-10-29 19:43:31 --> URI Class Initialized
INFO - 2023-10-29 19:43:31 --> Router Class Initialized
INFO - 2023-10-29 19:43:31 --> Output Class Initialized
INFO - 2023-10-29 19:43:31 --> Security Class Initialized
DEBUG - 2023-10-29 19:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-29 19:43:31 --> Input Class Initialized
INFO - 2023-10-29 19:43:31 --> Language Class Initialized
INFO - 2023-10-29 19:43:31 --> Loader Class Initialized
INFO - 2023-10-29 19:43:31 --> Helper loaded: url_helper
INFO - 2023-10-29 19:43:31 --> Helper loaded: form_helper
INFO - 2023-10-29 19:43:31 --> Helper loaded: file_helper
INFO - 2023-10-29 19:43:31 --> Database Driver Class Initialized
DEBUG - 2023-10-29 19:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-29 19:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-29 19:43:31 --> Form Validation Class Initialized
INFO - 2023-10-29 19:43:31 --> Upload Class Initialized
INFO - 2023-10-29 19:43:31 --> Model "M_auth" initialized
INFO - 2023-10-29 19:43:31 --> Model "M_user" initialized
INFO - 2023-10-29 19:43:31 --> Model "M_produk" initialized
INFO - 2023-10-29 19:43:31 --> Controller Class Initialized
DEBUG - 2023-10-29 19:43:31 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-29 19:43:32 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-29 19:43:32 --> Final output sent to browser
DEBUG - 2023-10-29 19:43:32 --> Total execution time: 0.3685
