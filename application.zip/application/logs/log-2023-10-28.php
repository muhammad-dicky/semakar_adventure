<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-10-28 22:47:58 --> Config Class Initialized
INFO - 2023-10-28 22:47:58 --> Hooks Class Initialized
DEBUG - 2023-10-28 22:47:58 --> UTF-8 Support Enabled
INFO - 2023-10-28 22:47:58 --> Utf8 Class Initialized
INFO - 2023-10-28 22:47:58 --> URI Class Initialized
DEBUG - 2023-10-28 22:47:58 --> No URI present. Default controller set.
INFO - 2023-10-28 22:47:58 --> Router Class Initialized
INFO - 2023-10-28 22:47:58 --> Output Class Initialized
INFO - 2023-10-28 22:47:58 --> Security Class Initialized
DEBUG - 2023-10-28 22:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 22:47:58 --> Input Class Initialized
INFO - 2023-10-28 22:47:58 --> Language Class Initialized
INFO - 2023-10-28 22:47:58 --> Loader Class Initialized
INFO - 2023-10-28 22:47:58 --> Helper loaded: url_helper
INFO - 2023-10-28 22:47:58 --> Helper loaded: form_helper
INFO - 2023-10-28 22:47:58 --> Helper loaded: file_helper
INFO - 2023-10-28 22:47:58 --> Database Driver Class Initialized
DEBUG - 2023-10-28 22:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-28 22:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 22:47:59 --> Form Validation Class Initialized
INFO - 2023-10-28 22:47:59 --> Upload Class Initialized
INFO - 2023-10-28 22:47:59 --> Model "M_auth" initialized
INFO - 2023-10-28 22:47:59 --> Model "M_user" initialized
INFO - 2023-10-28 22:47:59 --> Model "M_produk" initialized
INFO - 2023-10-28 22:47:59 --> Controller Class Initialized
INFO - 2023-10-28 22:47:59 --> Model "M_pelanggan" initialized
INFO - 2023-10-28 22:47:59 --> Model "M_produk" initialized
DEBUG - 2023-10-28 22:47:59 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 22:47:59 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-28 22:47:59 --> Model "M_transaksi" initialized
INFO - 2023-10-28 22:47:59 --> Model "M_bank" initialized
INFO - 2023-10-28 22:47:59 --> Model "M_pesan" initialized
INFO - 2023-10-28 22:47:59 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-28 22:47:59 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-28 22:47:59 --> Final output sent to browser
DEBUG - 2023-10-28 22:47:59 --> Total execution time: 0.5836
INFO - 2023-10-28 22:54:16 --> Config Class Initialized
INFO - 2023-10-28 22:54:16 --> Hooks Class Initialized
DEBUG - 2023-10-28 22:54:16 --> UTF-8 Support Enabled
INFO - 2023-10-28 22:54:16 --> Utf8 Class Initialized
INFO - 2023-10-28 22:54:16 --> URI Class Initialized
DEBUG - 2023-10-28 22:54:16 --> No URI present. Default controller set.
INFO - 2023-10-28 22:54:16 --> Router Class Initialized
INFO - 2023-10-28 22:54:16 --> Output Class Initialized
INFO - 2023-10-28 22:54:16 --> Security Class Initialized
DEBUG - 2023-10-28 22:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 22:54:16 --> Input Class Initialized
INFO - 2023-10-28 22:54:16 --> Language Class Initialized
INFO - 2023-10-28 22:54:16 --> Loader Class Initialized
INFO - 2023-10-28 22:54:16 --> Helper loaded: url_helper
INFO - 2023-10-28 22:54:16 --> Helper loaded: form_helper
INFO - 2023-10-28 22:54:16 --> Helper loaded: file_helper
INFO - 2023-10-28 22:54:16 --> Database Driver Class Initialized
DEBUG - 2023-10-28 22:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-28 22:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 22:54:16 --> Form Validation Class Initialized
INFO - 2023-10-28 22:54:16 --> Upload Class Initialized
INFO - 2023-10-28 22:54:16 --> Model "M_auth" initialized
INFO - 2023-10-28 22:54:16 --> Model "M_user" initialized
INFO - 2023-10-28 22:54:16 --> Model "M_produk" initialized
INFO - 2023-10-28 22:54:16 --> Controller Class Initialized
INFO - 2023-10-28 22:54:16 --> Model "M_pelanggan" initialized
INFO - 2023-10-28 22:54:16 --> Model "M_produk" initialized
DEBUG - 2023-10-28 22:54:16 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 22:54:16 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-28 22:54:16 --> Model "M_transaksi" initialized
INFO - 2023-10-28 22:54:16 --> Model "M_bank" initialized
INFO - 2023-10-28 22:54:16 --> Model "M_pesan" initialized
INFO - 2023-10-28 22:54:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-10-28 22:54:16 --> Email Class Initialized
INFO - 2023-10-28 22:54:17 --> Language file loaded: language/english/email_lang.php
INFO - 2023-10-28 22:54:21 --> Config Class Initialized
INFO - 2023-10-28 22:54:21 --> Hooks Class Initialized
DEBUG - 2023-10-28 22:54:21 --> UTF-8 Support Enabled
INFO - 2023-10-28 22:54:21 --> Utf8 Class Initialized
INFO - 2023-10-28 22:54:21 --> URI Class Initialized
DEBUG - 2023-10-28 22:54:21 --> No URI present. Default controller set.
INFO - 2023-10-28 22:54:21 --> Router Class Initialized
INFO - 2023-10-28 22:54:21 --> Output Class Initialized
INFO - 2023-10-28 22:54:21 --> Security Class Initialized
DEBUG - 2023-10-28 22:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 22:54:21 --> Input Class Initialized
INFO - 2023-10-28 22:54:21 --> Language Class Initialized
INFO - 2023-10-28 22:54:21 --> Loader Class Initialized
INFO - 2023-10-28 22:54:21 --> Helper loaded: url_helper
INFO - 2023-10-28 22:54:21 --> Helper loaded: form_helper
INFO - 2023-10-28 22:54:21 --> Helper loaded: file_helper
INFO - 2023-10-28 22:54:21 --> Database Driver Class Initialized
DEBUG - 2023-10-28 22:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-28 22:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 22:54:21 --> Form Validation Class Initialized
INFO - 2023-10-28 22:54:21 --> Upload Class Initialized
INFO - 2023-10-28 22:54:21 --> Model "M_auth" initialized
INFO - 2023-10-28 22:54:21 --> Model "M_user" initialized
INFO - 2023-10-28 22:54:21 --> Model "M_produk" initialized
INFO - 2023-10-28 22:54:21 --> Controller Class Initialized
INFO - 2023-10-28 22:54:21 --> Model "M_pelanggan" initialized
INFO - 2023-10-28 22:54:21 --> Model "M_produk" initialized
DEBUG - 2023-10-28 22:54:21 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 22:54:21 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-28 22:54:21 --> Model "M_transaksi" initialized
INFO - 2023-10-28 22:54:21 --> Model "M_bank" initialized
INFO - 2023-10-28 22:54:21 --> Model "M_pesan" initialized
INFO - 2023-10-28 22:54:21 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-28 22:54:21 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-28 22:54:21 --> Final output sent to browser
DEBUG - 2023-10-28 22:54:21 --> Total execution time: 0.0958
INFO - 2023-10-28 22:54:38 --> Config Class Initialized
INFO - 2023-10-28 22:54:38 --> Hooks Class Initialized
DEBUG - 2023-10-28 22:54:38 --> UTF-8 Support Enabled
INFO - 2023-10-28 22:54:38 --> Utf8 Class Initialized
INFO - 2023-10-28 22:54:38 --> URI Class Initialized
INFO - 2023-10-28 22:54:38 --> Router Class Initialized
INFO - 2023-10-28 22:54:38 --> Output Class Initialized
INFO - 2023-10-28 22:54:38 --> Security Class Initialized
DEBUG - 2023-10-28 22:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 22:54:38 --> Input Class Initialized
INFO - 2023-10-28 22:54:38 --> Language Class Initialized
INFO - 2023-10-28 22:54:38 --> Loader Class Initialized
INFO - 2023-10-28 22:54:38 --> Helper loaded: url_helper
INFO - 2023-10-28 22:54:38 --> Helper loaded: form_helper
INFO - 2023-10-28 22:54:38 --> Helper loaded: file_helper
INFO - 2023-10-28 22:54:38 --> Database Driver Class Initialized
DEBUG - 2023-10-28 22:54:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-28 22:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 22:54:38 --> Form Validation Class Initialized
INFO - 2023-10-28 22:54:38 --> Upload Class Initialized
INFO - 2023-10-28 22:54:38 --> Model "M_auth" initialized
INFO - 2023-10-28 22:54:38 --> Model "M_user" initialized
INFO - 2023-10-28 22:54:38 --> Model "M_produk" initialized
INFO - 2023-10-28 22:54:38 --> Controller Class Initialized
INFO - 2023-10-28 22:54:38 --> Model "M_pelanggan" initialized
INFO - 2023-10-28 22:54:38 --> Model "M_produk" initialized
DEBUG - 2023-10-28 22:54:38 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 22:54:38 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-28 22:54:38 --> Model "M_transaksi" initialized
INFO - 2023-10-28 22:54:38 --> Model "M_bank" initialized
INFO - 2023-10-28 22:54:38 --> Model "M_pesan" initialized
INFO - 2023-10-28 22:54:39 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-28 22:54:39 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_edit_profile_pelanggan.php
INFO - 2023-10-28 22:54:39 --> Final output sent to browser
DEBUG - 2023-10-28 22:54:39 --> Total execution time: 0.1354
INFO - 2023-10-28 22:54:46 --> Config Class Initialized
INFO - 2023-10-28 22:54:46 --> Hooks Class Initialized
DEBUG - 2023-10-28 22:54:46 --> UTF-8 Support Enabled
INFO - 2023-10-28 22:54:46 --> Utf8 Class Initialized
INFO - 2023-10-28 22:54:46 --> URI Class Initialized
INFO - 2023-10-28 22:54:46 --> Router Class Initialized
INFO - 2023-10-28 22:54:46 --> Output Class Initialized
INFO - 2023-10-28 22:54:46 --> Security Class Initialized
DEBUG - 2023-10-28 22:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 22:54:46 --> Input Class Initialized
INFO - 2023-10-28 22:54:46 --> Language Class Initialized
INFO - 2023-10-28 22:54:46 --> Loader Class Initialized
INFO - 2023-10-28 22:54:46 --> Helper loaded: url_helper
INFO - 2023-10-28 22:54:46 --> Helper loaded: form_helper
INFO - 2023-10-28 22:54:46 --> Helper loaded: file_helper
INFO - 2023-10-28 22:54:46 --> Database Driver Class Initialized
DEBUG - 2023-10-28 22:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-28 22:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 22:54:46 --> Form Validation Class Initialized
INFO - 2023-10-28 22:54:46 --> Upload Class Initialized
INFO - 2023-10-28 22:54:46 --> Model "M_auth" initialized
INFO - 2023-10-28 22:54:46 --> Model "M_user" initialized
INFO - 2023-10-28 22:54:46 --> Model "M_produk" initialized
INFO - 2023-10-28 22:54:46 --> Controller Class Initialized
INFO - 2023-10-28 22:54:46 --> Model "M_pelanggan" initialized
INFO - 2023-10-28 22:54:46 --> Model "M_produk" initialized
DEBUG - 2023-10-28 22:54:46 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 22:54:46 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-28 22:54:46 --> Model "M_transaksi" initialized
INFO - 2023-10-28 22:54:46 --> Model "M_bank" initialized
INFO - 2023-10-28 22:54:46 --> Model "M_pesan" initialized
INFO - 2023-10-28 22:54:46 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-28 22:54:46 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-28 22:54:46 --> Final output sent to browser
DEBUG - 2023-10-28 22:54:46 --> Total execution time: 0.1771
INFO - 2023-10-28 22:54:51 --> Config Class Initialized
INFO - 2023-10-28 22:54:51 --> Hooks Class Initialized
DEBUG - 2023-10-28 22:54:51 --> UTF-8 Support Enabled
INFO - 2023-10-28 22:54:51 --> Utf8 Class Initialized
INFO - 2023-10-28 22:54:51 --> URI Class Initialized
DEBUG - 2023-10-28 22:54:51 --> No URI present. Default controller set.
INFO - 2023-10-28 22:54:51 --> Router Class Initialized
INFO - 2023-10-28 22:54:51 --> Output Class Initialized
INFO - 2023-10-28 22:54:51 --> Security Class Initialized
DEBUG - 2023-10-28 22:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 22:54:51 --> Input Class Initialized
INFO - 2023-10-28 22:54:51 --> Language Class Initialized
INFO - 2023-10-28 22:54:51 --> Loader Class Initialized
INFO - 2023-10-28 22:54:51 --> Helper loaded: url_helper
INFO - 2023-10-28 22:54:51 --> Helper loaded: form_helper
INFO - 2023-10-28 22:54:51 --> Helper loaded: file_helper
INFO - 2023-10-28 22:54:51 --> Database Driver Class Initialized
DEBUG - 2023-10-28 22:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-28 22:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 22:54:51 --> Form Validation Class Initialized
INFO - 2023-10-28 22:54:51 --> Upload Class Initialized
INFO - 2023-10-28 22:54:51 --> Model "M_auth" initialized
INFO - 2023-10-28 22:54:51 --> Model "M_user" initialized
INFO - 2023-10-28 22:54:51 --> Model "M_produk" initialized
INFO - 2023-10-28 22:54:51 --> Controller Class Initialized
INFO - 2023-10-28 22:54:51 --> Model "M_pelanggan" initialized
INFO - 2023-10-28 22:54:51 --> Model "M_produk" initialized
DEBUG - 2023-10-28 22:54:51 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 22:54:51 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-28 22:54:51 --> Model "M_transaksi" initialized
INFO - 2023-10-28 22:54:51 --> Model "M_bank" initialized
INFO - 2023-10-28 22:54:51 --> Model "M_pesan" initialized
INFO - 2023-10-28 22:54:51 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-28 22:54:51 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-28 22:54:51 --> Final output sent to browser
DEBUG - 2023-10-28 22:54:51 --> Total execution time: 0.1045
INFO - 2023-10-28 22:54:58 --> Config Class Initialized
INFO - 2023-10-28 22:54:58 --> Hooks Class Initialized
DEBUG - 2023-10-28 22:54:58 --> UTF-8 Support Enabled
INFO - 2023-10-28 22:54:58 --> Utf8 Class Initialized
INFO - 2023-10-28 22:54:58 --> URI Class Initialized
INFO - 2023-10-28 22:54:58 --> Router Class Initialized
INFO - 2023-10-28 22:54:58 --> Output Class Initialized
INFO - 2023-10-28 22:54:58 --> Security Class Initialized
DEBUG - 2023-10-28 22:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 22:54:58 --> Input Class Initialized
INFO - 2023-10-28 22:54:58 --> Language Class Initialized
INFO - 2023-10-28 22:54:58 --> Loader Class Initialized
INFO - 2023-10-28 22:54:58 --> Helper loaded: url_helper
INFO - 2023-10-28 22:54:58 --> Helper loaded: form_helper
INFO - 2023-10-28 22:54:58 --> Helper loaded: file_helper
INFO - 2023-10-28 22:54:58 --> Database Driver Class Initialized
DEBUG - 2023-10-28 22:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-28 22:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 22:54:58 --> Form Validation Class Initialized
INFO - 2023-10-28 22:54:58 --> Upload Class Initialized
INFO - 2023-10-28 22:54:58 --> Model "M_auth" initialized
INFO - 2023-10-28 22:54:58 --> Model "M_user" initialized
INFO - 2023-10-28 22:54:58 --> Model "M_produk" initialized
INFO - 2023-10-28 22:54:58 --> Controller Class Initialized
INFO - 2023-10-28 22:54:58 --> Model "M_pelanggan" initialized
INFO - 2023-10-28 22:54:58 --> Model "M_produk" initialized
DEBUG - 2023-10-28 22:54:58 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 22:54:58 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-28 22:54:58 --> Model "M_transaksi" initialized
INFO - 2023-10-28 22:54:58 --> Model "M_bank" initialized
INFO - 2023-10-28 22:54:58 --> Model "M_pesan" initialized
INFO - 2023-10-28 22:54:58 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-28 22:54:58 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_produk_detail.php
INFO - 2023-10-28 22:54:58 --> Final output sent to browser
DEBUG - 2023-10-28 22:54:58 --> Total execution time: 0.2353
INFO - 2023-10-28 22:54:58 --> Config Class Initialized
INFO - 2023-10-28 22:54:58 --> Hooks Class Initialized
DEBUG - 2023-10-28 22:54:58 --> UTF-8 Support Enabled
INFO - 2023-10-28 22:54:58 --> Utf8 Class Initialized
INFO - 2023-10-28 22:54:58 --> URI Class Initialized
INFO - 2023-10-28 22:54:58 --> Router Class Initialized
INFO - 2023-10-28 22:54:58 --> Output Class Initialized
INFO - 2023-10-28 22:54:58 --> Security Class Initialized
DEBUG - 2023-10-28 22:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 22:54:58 --> Input Class Initialized
INFO - 2023-10-28 22:54:58 --> Language Class Initialized
INFO - 2023-10-28 22:54:58 --> Loader Class Initialized
INFO - 2023-10-28 22:54:58 --> Helper loaded: url_helper
INFO - 2023-10-28 22:54:58 --> Helper loaded: form_helper
INFO - 2023-10-28 22:54:58 --> Helper loaded: file_helper
INFO - 2023-10-28 22:54:58 --> Database Driver Class Initialized
DEBUG - 2023-10-28 22:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-28 22:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 22:54:58 --> Form Validation Class Initialized
INFO - 2023-10-28 22:54:58 --> Upload Class Initialized
INFO - 2023-10-28 22:54:58 --> Model "M_auth" initialized
INFO - 2023-10-28 22:54:58 --> Model "M_user" initialized
INFO - 2023-10-28 22:54:58 --> Model "M_produk" initialized
INFO - 2023-10-28 22:54:58 --> Controller Class Initialized
INFO - 2023-10-28 22:54:58 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-10-28 22:54:58 --> Final output sent to browser
DEBUG - 2023-10-28 22:54:58 --> Total execution time: 0.1451
INFO - 2023-10-28 22:55:04 --> Config Class Initialized
INFO - 2023-10-28 22:55:04 --> Hooks Class Initialized
DEBUG - 2023-10-28 22:55:04 --> UTF-8 Support Enabled
INFO - 2023-10-28 22:55:04 --> Utf8 Class Initialized
INFO - 2023-10-28 22:55:04 --> URI Class Initialized
DEBUG - 2023-10-28 22:55:04 --> No URI present. Default controller set.
INFO - 2023-10-28 22:55:04 --> Router Class Initialized
INFO - 2023-10-28 22:55:04 --> Output Class Initialized
INFO - 2023-10-28 22:55:04 --> Security Class Initialized
DEBUG - 2023-10-28 22:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 22:55:04 --> Input Class Initialized
INFO - 2023-10-28 22:55:04 --> Language Class Initialized
INFO - 2023-10-28 22:55:04 --> Loader Class Initialized
INFO - 2023-10-28 22:55:04 --> Helper loaded: url_helper
INFO - 2023-10-28 22:55:04 --> Helper loaded: form_helper
INFO - 2023-10-28 22:55:04 --> Helper loaded: file_helper
INFO - 2023-10-28 22:55:04 --> Database Driver Class Initialized
DEBUG - 2023-10-28 22:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-28 22:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 22:55:04 --> Form Validation Class Initialized
INFO - 2023-10-28 22:55:04 --> Upload Class Initialized
INFO - 2023-10-28 22:55:04 --> Model "M_auth" initialized
INFO - 2023-10-28 22:55:04 --> Model "M_user" initialized
INFO - 2023-10-28 22:55:04 --> Model "M_produk" initialized
INFO - 2023-10-28 22:55:04 --> Controller Class Initialized
INFO - 2023-10-28 22:55:04 --> Model "M_pelanggan" initialized
INFO - 2023-10-28 22:55:04 --> Model "M_produk" initialized
DEBUG - 2023-10-28 22:55:04 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 22:55:04 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-28 22:55:04 --> Model "M_transaksi" initialized
INFO - 2023-10-28 22:55:04 --> Model "M_bank" initialized
INFO - 2023-10-28 22:55:04 --> Model "M_pesan" initialized
INFO - 2023-10-28 22:55:04 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-28 22:55:04 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-28 22:55:04 --> Final output sent to browser
DEBUG - 2023-10-28 22:55:04 --> Total execution time: 0.0831
INFO - 2023-10-28 22:55:10 --> Config Class Initialized
INFO - 2023-10-28 22:55:10 --> Hooks Class Initialized
DEBUG - 2023-10-28 22:55:10 --> UTF-8 Support Enabled
INFO - 2023-10-28 22:55:10 --> Utf8 Class Initialized
INFO - 2023-10-28 22:55:10 --> URI Class Initialized
INFO - 2023-10-28 22:55:10 --> Router Class Initialized
INFO - 2023-10-28 22:55:10 --> Output Class Initialized
INFO - 2023-10-28 22:55:10 --> Security Class Initialized
DEBUG - 2023-10-28 22:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 22:55:10 --> Input Class Initialized
INFO - 2023-10-28 22:55:10 --> Language Class Initialized
INFO - 2023-10-28 22:55:10 --> Loader Class Initialized
INFO - 2023-10-28 22:55:10 --> Helper loaded: url_helper
INFO - 2023-10-28 22:55:10 --> Helper loaded: form_helper
INFO - 2023-10-28 22:55:10 --> Helper loaded: file_helper
INFO - 2023-10-28 22:55:10 --> Database Driver Class Initialized
DEBUG - 2023-10-28 22:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-28 22:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 22:55:10 --> Form Validation Class Initialized
INFO - 2023-10-28 22:55:10 --> Upload Class Initialized
INFO - 2023-10-28 22:55:10 --> Model "M_auth" initialized
INFO - 2023-10-28 22:55:10 --> Model "M_user" initialized
INFO - 2023-10-28 22:55:10 --> Model "M_produk" initialized
INFO - 2023-10-28 22:55:10 --> Controller Class Initialized
INFO - 2023-10-28 22:55:10 --> Model "M_pelanggan" initialized
INFO - 2023-10-28 22:55:10 --> Model "M_produk" initialized
DEBUG - 2023-10-28 22:55:10 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 22:55:10 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-28 22:55:10 --> Model "M_transaksi" initialized
INFO - 2023-10-28 22:55:10 --> Model "M_bank" initialized
INFO - 2023-10-28 22:55:10 --> Model "M_pesan" initialized
INFO - 2023-10-28 22:55:10 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-28 22:55:10 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_produk_detail.php
INFO - 2023-10-28 22:55:10 --> Final output sent to browser
DEBUG - 2023-10-28 22:55:10 --> Total execution time: 0.1160
INFO - 2023-10-28 22:55:10 --> Config Class Initialized
INFO - 2023-10-28 22:55:10 --> Hooks Class Initialized
DEBUG - 2023-10-28 22:55:10 --> UTF-8 Support Enabled
INFO - 2023-10-28 22:55:10 --> Utf8 Class Initialized
INFO - 2023-10-28 22:55:10 --> URI Class Initialized
INFO - 2023-10-28 22:55:10 --> Router Class Initialized
INFO - 2023-10-28 22:55:10 --> Output Class Initialized
INFO - 2023-10-28 22:55:10 --> Security Class Initialized
DEBUG - 2023-10-28 22:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 22:55:10 --> Input Class Initialized
INFO - 2023-10-28 22:55:10 --> Language Class Initialized
INFO - 2023-10-28 22:55:10 --> Loader Class Initialized
INFO - 2023-10-28 22:55:10 --> Helper loaded: url_helper
INFO - 2023-10-28 22:55:10 --> Helper loaded: form_helper
INFO - 2023-10-28 22:55:10 --> Helper loaded: file_helper
INFO - 2023-10-28 22:55:10 --> Database Driver Class Initialized
DEBUG - 2023-10-28 22:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-28 22:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 22:55:10 --> Form Validation Class Initialized
INFO - 2023-10-28 22:55:10 --> Upload Class Initialized
INFO - 2023-10-28 22:55:10 --> Model "M_auth" initialized
INFO - 2023-10-28 22:55:10 --> Model "M_user" initialized
INFO - 2023-10-28 22:55:10 --> Model "M_produk" initialized
INFO - 2023-10-28 22:55:10 --> Controller Class Initialized
INFO - 2023-10-28 22:55:10 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-10-28 22:55:10 --> Final output sent to browser
DEBUG - 2023-10-28 22:55:10 --> Total execution time: 0.0566
INFO - 2023-10-28 22:55:23 --> Config Class Initialized
INFO - 2023-10-28 22:55:23 --> Hooks Class Initialized
DEBUG - 2023-10-28 22:55:23 --> UTF-8 Support Enabled
INFO - 2023-10-28 22:55:23 --> Utf8 Class Initialized
INFO - 2023-10-28 22:55:23 --> URI Class Initialized
INFO - 2023-10-28 22:55:23 --> Router Class Initialized
INFO - 2023-10-28 22:55:23 --> Output Class Initialized
INFO - 2023-10-28 22:55:23 --> Security Class Initialized
DEBUG - 2023-10-28 22:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 22:55:23 --> Input Class Initialized
INFO - 2023-10-28 22:55:23 --> Language Class Initialized
INFO - 2023-10-28 22:55:23 --> Loader Class Initialized
INFO - 2023-10-28 22:55:23 --> Helper loaded: url_helper
INFO - 2023-10-28 22:55:23 --> Helper loaded: form_helper
INFO - 2023-10-28 22:55:23 --> Helper loaded: file_helper
INFO - 2023-10-28 22:55:23 --> Database Driver Class Initialized
DEBUG - 2023-10-28 22:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-28 22:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 22:55:23 --> Form Validation Class Initialized
INFO - 2023-10-28 22:55:23 --> Upload Class Initialized
INFO - 2023-10-28 22:55:23 --> Model "M_auth" initialized
INFO - 2023-10-28 22:55:23 --> Model "M_user" initialized
INFO - 2023-10-28 22:55:23 --> Model "M_produk" initialized
INFO - 2023-10-28 22:55:23 --> Controller Class Initialized
INFO - 2023-10-28 22:55:23 --> Model "M_pelanggan" initialized
INFO - 2023-10-28 22:55:23 --> Model "M_produk" initialized
DEBUG - 2023-10-28 22:55:23 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 22:55:23 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-28 22:55:23 --> Model "M_transaksi" initialized
INFO - 2023-10-28 22:55:23 --> Model "M_bank" initialized
INFO - 2023-10-28 22:55:23 --> Model "M_pesan" initialized
INFO - 2023-10-28 22:55:23 --> Email Class Initialized
INFO - 2023-10-28 22:55:24 --> Language file loaded: language/english/email_lang.php
INFO - 2023-10-28 22:55:27 --> Config Class Initialized
INFO - 2023-10-28 22:55:27 --> Hooks Class Initialized
DEBUG - 2023-10-28 22:55:27 --> UTF-8 Support Enabled
INFO - 2023-10-28 22:55:27 --> Utf8 Class Initialized
INFO - 2023-10-28 22:55:27 --> URI Class Initialized
INFO - 2023-10-28 22:55:27 --> Router Class Initialized
INFO - 2023-10-28 22:55:27 --> Output Class Initialized
INFO - 2023-10-28 22:55:27 --> Security Class Initialized
DEBUG - 2023-10-28 22:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 22:55:27 --> Input Class Initialized
INFO - 2023-10-28 22:55:27 --> Language Class Initialized
INFO - 2023-10-28 22:55:27 --> Loader Class Initialized
INFO - 2023-10-28 22:55:27 --> Helper loaded: url_helper
INFO - 2023-10-28 22:55:27 --> Helper loaded: form_helper
INFO - 2023-10-28 22:55:27 --> Helper loaded: file_helper
INFO - 2023-10-28 22:55:27 --> Database Driver Class Initialized
DEBUG - 2023-10-28 22:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-28 22:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 22:55:27 --> Form Validation Class Initialized
INFO - 2023-10-28 22:55:27 --> Upload Class Initialized
INFO - 2023-10-28 22:55:27 --> Model "M_auth" initialized
INFO - 2023-10-28 22:55:27 --> Model "M_user" initialized
INFO - 2023-10-28 22:55:27 --> Model "M_produk" initialized
INFO - 2023-10-28 22:55:27 --> Controller Class Initialized
INFO - 2023-10-28 22:55:27 --> Model "M_pelanggan" initialized
INFO - 2023-10-28 22:55:27 --> Model "M_produk" initialized
DEBUG - 2023-10-28 22:55:27 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 22:55:27 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-28 22:55:27 --> Model "M_transaksi" initialized
INFO - 2023-10-28 22:55:27 --> Model "M_bank" initialized
INFO - 2023-10-28 22:55:27 --> Model "M_pesan" initialized
INFO - 2023-10-28 22:55:27 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-28 22:55:27 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-28 22:55:27 --> Final output sent to browser
DEBUG - 2023-10-28 22:55:27 --> Total execution time: 0.0883
INFO - 2023-10-28 22:55:34 --> Config Class Initialized
INFO - 2023-10-28 22:55:34 --> Hooks Class Initialized
DEBUG - 2023-10-28 22:55:34 --> UTF-8 Support Enabled
INFO - 2023-10-28 22:55:34 --> Utf8 Class Initialized
INFO - 2023-10-28 22:55:34 --> URI Class Initialized
INFO - 2023-10-28 22:55:34 --> Router Class Initialized
INFO - 2023-10-28 22:55:34 --> Output Class Initialized
INFO - 2023-10-28 22:55:34 --> Security Class Initialized
DEBUG - 2023-10-28 22:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 22:55:34 --> Input Class Initialized
INFO - 2023-10-28 22:55:34 --> Language Class Initialized
INFO - 2023-10-28 22:55:34 --> Loader Class Initialized
INFO - 2023-10-28 22:55:34 --> Helper loaded: url_helper
INFO - 2023-10-28 22:55:34 --> Helper loaded: form_helper
INFO - 2023-10-28 22:55:34 --> Helper loaded: file_helper
INFO - 2023-10-28 22:55:34 --> Database Driver Class Initialized
DEBUG - 2023-10-28 22:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-28 22:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 22:55:34 --> Form Validation Class Initialized
INFO - 2023-10-28 22:55:34 --> Upload Class Initialized
INFO - 2023-10-28 22:55:34 --> Model "M_auth" initialized
INFO - 2023-10-28 22:55:34 --> Model "M_user" initialized
INFO - 2023-10-28 22:55:34 --> Model "M_produk" initialized
INFO - 2023-10-28 22:55:34 --> Controller Class Initialized
INFO - 2023-10-28 22:55:34 --> Model "M_pelanggan" initialized
INFO - 2023-10-28 22:55:34 --> Model "M_produk" initialized
DEBUG - 2023-10-28 22:55:34 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 22:55:34 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-28 22:55:34 --> Model "M_transaksi" initialized
INFO - 2023-10-28 22:55:34 --> Model "M_bank" initialized
INFO - 2023-10-28 22:55:34 --> Model "M_pesan" initialized
INFO - 2023-10-28 22:55:34 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-28 22:55:34 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_bayar_sekarang.php
INFO - 2023-10-28 22:55:34 --> Final output sent to browser
DEBUG - 2023-10-28 22:55:34 --> Total execution time: 0.2263
INFO - 2023-10-28 22:55:34 --> Config Class Initialized
INFO - 2023-10-28 22:55:34 --> Hooks Class Initialized
DEBUG - 2023-10-28 22:55:34 --> UTF-8 Support Enabled
INFO - 2023-10-28 22:55:34 --> Utf8 Class Initialized
INFO - 2023-10-28 22:55:34 --> URI Class Initialized
INFO - 2023-10-28 22:55:34 --> Router Class Initialized
INFO - 2023-10-28 22:55:34 --> Output Class Initialized
INFO - 2023-10-28 22:55:34 --> Security Class Initialized
DEBUG - 2023-10-28 22:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 22:55:34 --> Input Class Initialized
INFO - 2023-10-28 22:55:34 --> Language Class Initialized
INFO - 2023-10-28 22:55:34 --> Loader Class Initialized
INFO - 2023-10-28 22:55:34 --> Helper loaded: url_helper
INFO - 2023-10-28 22:55:34 --> Helper loaded: form_helper
INFO - 2023-10-28 22:55:34 --> Helper loaded: file_helper
INFO - 2023-10-28 22:55:34 --> Database Driver Class Initialized
DEBUG - 2023-10-28 22:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-28 22:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 22:55:34 --> Form Validation Class Initialized
INFO - 2023-10-28 22:55:34 --> Upload Class Initialized
INFO - 2023-10-28 22:55:34 --> Model "M_auth" initialized
INFO - 2023-10-28 22:55:34 --> Model "M_user" initialized
INFO - 2023-10-28 22:55:34 --> Model "M_produk" initialized
INFO - 2023-10-28 22:55:34 --> Controller Class Initialized
INFO - 2023-10-28 22:55:34 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-10-28 22:55:34 --> Final output sent to browser
DEBUG - 2023-10-28 22:55:34 --> Total execution time: 0.0252
INFO - 2023-10-28 23:31:22 --> Config Class Initialized
INFO - 2023-10-28 23:31:22 --> Hooks Class Initialized
DEBUG - 2023-10-28 23:31:23 --> UTF-8 Support Enabled
INFO - 2023-10-28 23:31:23 --> Utf8 Class Initialized
INFO - 2023-10-28 23:31:23 --> URI Class Initialized
INFO - 2023-10-28 23:31:23 --> Router Class Initialized
INFO - 2023-10-28 23:31:23 --> Output Class Initialized
INFO - 2023-10-28 23:31:23 --> Security Class Initialized
DEBUG - 2023-10-28 23:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 23:31:23 --> Input Class Initialized
INFO - 2023-10-28 23:31:23 --> Language Class Initialized
INFO - 2023-10-28 23:31:23 --> Loader Class Initialized
INFO - 2023-10-28 23:31:23 --> Helper loaded: url_helper
INFO - 2023-10-28 23:31:23 --> Helper loaded: form_helper
INFO - 2023-10-28 23:31:23 --> Helper loaded: file_helper
INFO - 2023-10-28 23:31:23 --> Database Driver Class Initialized
DEBUG - 2023-10-28 23:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-28 23:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 23:31:23 --> Form Validation Class Initialized
INFO - 2023-10-28 23:31:23 --> Upload Class Initialized
INFO - 2023-10-28 23:31:23 --> Model "M_auth" initialized
INFO - 2023-10-28 23:31:23 --> Model "M_user" initialized
INFO - 2023-10-28 23:31:23 --> Model "M_produk" initialized
INFO - 2023-10-28 23:31:23 --> Controller Class Initialized
INFO - 2023-10-28 23:31:23 --> Model "M_pelanggan" initialized
INFO - 2023-10-28 23:31:23 --> Model "M_produk" initialized
DEBUG - 2023-10-28 23:31:23 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 23:31:23 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-28 23:31:23 --> Model "M_transaksi" initialized
INFO - 2023-10-28 23:31:23 --> Model "M_bank" initialized
INFO - 2023-10-28 23:31:23 --> Model "M_pesan" initialized
INFO - 2023-10-28 23:31:23 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-28 23:31:23 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-28 23:31:23 --> Final output sent to browser
DEBUG - 2023-10-28 23:31:23 --> Total execution time: 0.1052
INFO - 2023-10-28 23:51:19 --> Config Class Initialized
INFO - 2023-10-28 23:51:19 --> Hooks Class Initialized
DEBUG - 2023-10-28 23:51:19 --> UTF-8 Support Enabled
INFO - 2023-10-28 23:51:19 --> Utf8 Class Initialized
INFO - 2023-10-28 23:51:19 --> URI Class Initialized
INFO - 2023-10-28 23:51:19 --> Router Class Initialized
INFO - 2023-10-28 23:51:19 --> Output Class Initialized
INFO - 2023-10-28 23:51:19 --> Security Class Initialized
DEBUG - 2023-10-28 23:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 23:51:19 --> Input Class Initialized
INFO - 2023-10-28 23:51:19 --> Language Class Initialized
INFO - 2023-10-28 23:51:19 --> Loader Class Initialized
INFO - 2023-10-28 23:51:19 --> Helper loaded: url_helper
INFO - 2023-10-28 23:51:19 --> Helper loaded: form_helper
INFO - 2023-10-28 23:51:19 --> Helper loaded: file_helper
INFO - 2023-10-28 23:51:19 --> Database Driver Class Initialized
DEBUG - 2023-10-28 23:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-28 23:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 23:51:19 --> Form Validation Class Initialized
INFO - 2023-10-28 23:51:19 --> Upload Class Initialized
INFO - 2023-10-28 23:51:19 --> Model "M_auth" initialized
INFO - 2023-10-28 23:51:19 --> Model "M_user" initialized
INFO - 2023-10-28 23:51:19 --> Model "M_produk" initialized
INFO - 2023-10-28 23:51:19 --> Controller Class Initialized
INFO - 2023-10-28 23:51:19 --> Model "M_pelanggan" initialized
INFO - 2023-10-28 23:51:19 --> Model "M_produk" initialized
DEBUG - 2023-10-28 23:51:19 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 23:51:19 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-28 23:51:19 --> Model "M_transaksi" initialized
INFO - 2023-10-28 23:51:19 --> Model "M_bank" initialized
INFO - 2023-10-28 23:51:19 --> Model "M_pesan" initialized
INFO - 2023-10-28 23:51:19 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-28 23:51:19 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-28 23:51:19 --> Final output sent to browser
DEBUG - 2023-10-28 23:51:19 --> Total execution time: 0.1079
INFO - 2023-10-28 23:58:20 --> Config Class Initialized
INFO - 2023-10-28 23:58:20 --> Hooks Class Initialized
DEBUG - 2023-10-28 23:58:20 --> UTF-8 Support Enabled
INFO - 2023-10-28 23:58:20 --> Utf8 Class Initialized
INFO - 2023-10-28 23:58:20 --> URI Class Initialized
INFO - 2023-10-28 23:58:20 --> Router Class Initialized
INFO - 2023-10-28 23:58:20 --> Output Class Initialized
INFO - 2023-10-28 23:58:20 --> Security Class Initialized
DEBUG - 2023-10-28 23:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 23:58:20 --> Input Class Initialized
INFO - 2023-10-28 23:58:20 --> Language Class Initialized
INFO - 2023-10-28 23:58:20 --> Loader Class Initialized
INFO - 2023-10-28 23:58:20 --> Helper loaded: url_helper
INFO - 2023-10-28 23:58:20 --> Helper loaded: form_helper
INFO - 2023-10-28 23:58:20 --> Helper loaded: file_helper
INFO - 2023-10-28 23:58:20 --> Database Driver Class Initialized
DEBUG - 2023-10-28 23:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-28 23:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 23:58:20 --> Form Validation Class Initialized
INFO - 2023-10-28 23:58:20 --> Upload Class Initialized
INFO - 2023-10-28 23:58:20 --> Model "M_auth" initialized
INFO - 2023-10-28 23:58:20 --> Model "M_user" initialized
INFO - 2023-10-28 23:58:20 --> Model "M_produk" initialized
INFO - 2023-10-28 23:58:20 --> Controller Class Initialized
INFO - 2023-10-28 23:58:20 --> Model "M_pelanggan" initialized
INFO - 2023-10-28 23:58:20 --> Model "M_produk" initialized
DEBUG - 2023-10-28 23:58:20 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 23:58:20 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-28 23:58:20 --> Model "M_transaksi" initialized
INFO - 2023-10-28 23:58:20 --> Model "M_bank" initialized
INFO - 2023-10-28 23:58:20 --> Model "M_pesan" initialized
INFO - 2023-10-28 23:58:20 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-28 23:58:20 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-28 23:58:20 --> Final output sent to browser
DEBUG - 2023-10-28 23:58:20 --> Total execution time: 0.0898
INFO - 2023-10-28 23:58:23 --> Config Class Initialized
INFO - 2023-10-28 23:58:23 --> Hooks Class Initialized
DEBUG - 2023-10-28 23:58:24 --> UTF-8 Support Enabled
INFO - 2023-10-28 23:58:24 --> Utf8 Class Initialized
INFO - 2023-10-28 23:58:24 --> URI Class Initialized
INFO - 2023-10-28 23:58:24 --> Router Class Initialized
INFO - 2023-10-28 23:58:24 --> Output Class Initialized
INFO - 2023-10-28 23:58:24 --> Security Class Initialized
DEBUG - 2023-10-28 23:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 23:58:24 --> Input Class Initialized
INFO - 2023-10-28 23:58:24 --> Language Class Initialized
INFO - 2023-10-28 23:58:24 --> Loader Class Initialized
INFO - 2023-10-28 23:58:24 --> Helper loaded: url_helper
INFO - 2023-10-28 23:58:24 --> Helper loaded: form_helper
INFO - 2023-10-28 23:58:24 --> Helper loaded: file_helper
INFO - 2023-10-28 23:58:24 --> Database Driver Class Initialized
DEBUG - 2023-10-28 23:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-28 23:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 23:58:24 --> Form Validation Class Initialized
INFO - 2023-10-28 23:58:24 --> Upload Class Initialized
INFO - 2023-10-28 23:58:24 --> Model "M_auth" initialized
INFO - 2023-10-28 23:58:24 --> Model "M_user" initialized
INFO - 2023-10-28 23:58:24 --> Model "M_produk" initialized
INFO - 2023-10-28 23:58:24 --> Controller Class Initialized
INFO - 2023-10-28 23:58:24 --> Model "M_pelanggan" initialized
INFO - 2023-10-28 23:58:24 --> Model "M_produk" initialized
DEBUG - 2023-10-28 23:58:24 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 23:58:24 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-28 23:58:24 --> Model "M_transaksi" initialized
INFO - 2023-10-28 23:58:24 --> Model "M_bank" initialized
INFO - 2023-10-28 23:58:24 --> Model "M_pesan" initialized
INFO - 2023-10-28 23:58:24 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-28 23:58:24 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_bayar_sekarang.php
INFO - 2023-10-28 23:58:24 --> Final output sent to browser
DEBUG - 2023-10-28 23:58:24 --> Total execution time: 0.1046
INFO - 2023-10-28 23:58:24 --> Config Class Initialized
INFO - 2023-10-28 23:58:24 --> Hooks Class Initialized
DEBUG - 2023-10-28 23:58:24 --> UTF-8 Support Enabled
INFO - 2023-10-28 23:58:24 --> Utf8 Class Initialized
INFO - 2023-10-28 23:58:24 --> URI Class Initialized
INFO - 2023-10-28 23:58:24 --> Router Class Initialized
INFO - 2023-10-28 23:58:24 --> Output Class Initialized
INFO - 2023-10-28 23:58:24 --> Security Class Initialized
DEBUG - 2023-10-28 23:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 23:58:24 --> Input Class Initialized
INFO - 2023-10-28 23:58:24 --> Language Class Initialized
INFO - 2023-10-28 23:58:24 --> Loader Class Initialized
INFO - 2023-10-28 23:58:24 --> Helper loaded: url_helper
INFO - 2023-10-28 23:58:24 --> Helper loaded: form_helper
INFO - 2023-10-28 23:58:24 --> Helper loaded: file_helper
INFO - 2023-10-28 23:58:24 --> Database Driver Class Initialized
DEBUG - 2023-10-28 23:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-28 23:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 23:58:24 --> Form Validation Class Initialized
INFO - 2023-10-28 23:58:24 --> Upload Class Initialized
INFO - 2023-10-28 23:58:24 --> Model "M_auth" initialized
INFO - 2023-10-28 23:58:24 --> Model "M_user" initialized
INFO - 2023-10-28 23:58:24 --> Model "M_produk" initialized
INFO - 2023-10-28 23:58:24 --> Controller Class Initialized
INFO - 2023-10-28 23:58:24 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-10-28 23:58:24 --> Final output sent to browser
DEBUG - 2023-10-28 23:58:24 --> Total execution time: 0.0239
INFO - 2023-10-28 23:58:27 --> Config Class Initialized
INFO - 2023-10-28 23:58:27 --> Hooks Class Initialized
DEBUG - 2023-10-28 23:58:27 --> UTF-8 Support Enabled
INFO - 2023-10-28 23:58:27 --> Utf8 Class Initialized
INFO - 2023-10-28 23:58:27 --> URI Class Initialized
INFO - 2023-10-28 23:58:27 --> Router Class Initialized
INFO - 2023-10-28 23:58:27 --> Output Class Initialized
INFO - 2023-10-28 23:58:27 --> Security Class Initialized
DEBUG - 2023-10-28 23:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-28 23:58:27 --> Input Class Initialized
INFO - 2023-10-28 23:58:27 --> Language Class Initialized
INFO - 2023-10-28 23:58:27 --> Loader Class Initialized
INFO - 2023-10-28 23:58:27 --> Helper loaded: url_helper
INFO - 2023-10-28 23:58:27 --> Helper loaded: form_helper
INFO - 2023-10-28 23:58:27 --> Helper loaded: file_helper
INFO - 2023-10-28 23:58:27 --> Database Driver Class Initialized
DEBUG - 2023-10-28 23:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-28 23:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-28 23:58:27 --> Form Validation Class Initialized
INFO - 2023-10-28 23:58:27 --> Upload Class Initialized
INFO - 2023-10-28 23:58:27 --> Model "M_auth" initialized
INFO - 2023-10-28 23:58:27 --> Model "M_user" initialized
INFO - 2023-10-28 23:58:27 --> Model "M_produk" initialized
INFO - 2023-10-28 23:58:27 --> Controller Class Initialized
INFO - 2023-10-28 23:58:27 --> Model "M_pelanggan" initialized
INFO - 2023-10-28 23:58:27 --> Model "M_produk" initialized
DEBUG - 2023-10-28 23:58:27 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-28 23:58:27 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-28 23:58:27 --> Model "M_transaksi" initialized
INFO - 2023-10-28 23:58:27 --> Model "M_bank" initialized
INFO - 2023-10-28 23:58:27 --> Model "M_pesan" initialized
INFO - 2023-10-28 23:58:27 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-28 23:58:27 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-28 23:58:27 --> Final output sent to browser
DEBUG - 2023-10-28 23:58:27 --> Total execution time: 0.1065
