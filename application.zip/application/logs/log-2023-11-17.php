<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-17 01:25:25 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-17 01:25:25 --> Config Class Initialized
INFO - 2023-11-17 01:25:25 --> Hooks Class Initialized
DEBUG - 2023-11-17 01:25:25 --> UTF-8 Support Enabled
INFO - 2023-11-17 01:25:25 --> Utf8 Class Initialized
INFO - 2023-11-17 01:25:25 --> URI Class Initialized
DEBUG - 2023-11-17 01:25:25 --> No URI present. Default controller set.
INFO - 2023-11-17 01:25:25 --> Router Class Initialized
INFO - 2023-11-17 01:25:25 --> Output Class Initialized
INFO - 2023-11-17 01:25:25 --> Security Class Initialized
DEBUG - 2023-11-17 01:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 01:25:25 --> Input Class Initialized
INFO - 2023-11-17 01:25:25 --> Language Class Initialized
INFO - 2023-11-17 01:25:25 --> Loader Class Initialized
INFO - 2023-11-17 01:25:25 --> Helper loaded: url_helper
INFO - 2023-11-17 01:25:25 --> Helper loaded: form_helper
INFO - 2023-11-17 01:25:25 --> Helper loaded: file_helper
INFO - 2023-11-17 01:25:25 --> Database Driver Class Initialized
DEBUG - 2023-11-17 01:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-17 01:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 01:25:25 --> Form Validation Class Initialized
INFO - 2023-11-17 01:25:25 --> Upload Class Initialized
INFO - 2023-11-17 01:25:25 --> Model "M_auth" initialized
INFO - 2023-11-17 01:25:25 --> Model "M_user" initialized
INFO - 2023-11-17 01:25:25 --> Model "M_produk" initialized
INFO - 2023-11-17 01:25:25 --> Controller Class Initialized
INFO - 2023-11-17 01:25:25 --> Model "M_pelanggan" initialized
INFO - 2023-11-17 01:25:25 --> Model "M_produk" initialized
DEBUG - 2023-11-17 01:25:25 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 01:25:25 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-17 01:25:25 --> Model "M_transaksi" initialized
INFO - 2023-11-17 01:25:25 --> Model "M_bank" initialized
INFO - 2023-11-17 01:25:25 --> Model "M_pesan" initialized
DEBUG - 2023-11-17 01:25:25 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-17 01:25:25 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-17 01:25:25 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-17 01:25:25 --> Final output sent to browser
DEBUG - 2023-11-17 01:25:25 --> Total execution time: 0.0342
ERROR - 2023-11-17 01:44:57 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-17 01:44:57 --> Config Class Initialized
INFO - 2023-11-17 01:44:57 --> Hooks Class Initialized
DEBUG - 2023-11-17 01:44:57 --> UTF-8 Support Enabled
INFO - 2023-11-17 01:44:57 --> Utf8 Class Initialized
INFO - 2023-11-17 01:44:57 --> URI Class Initialized
INFO - 2023-11-17 01:44:57 --> Router Class Initialized
INFO - 2023-11-17 01:44:57 --> Output Class Initialized
INFO - 2023-11-17 01:44:57 --> Security Class Initialized
DEBUG - 2023-11-17 01:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 01:44:57 --> Input Class Initialized
INFO - 2023-11-17 01:44:57 --> Language Class Initialized
INFO - 2023-11-17 01:44:57 --> Loader Class Initialized
INFO - 2023-11-17 01:44:57 --> Helper loaded: url_helper
INFO - 2023-11-17 01:44:57 --> Helper loaded: form_helper
INFO - 2023-11-17 01:44:57 --> Helper loaded: file_helper
INFO - 2023-11-17 01:44:57 --> Database Driver Class Initialized
DEBUG - 2023-11-17 01:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-17 01:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 01:44:57 --> Form Validation Class Initialized
INFO - 2023-11-17 01:44:57 --> Upload Class Initialized
INFO - 2023-11-17 01:44:57 --> Model "M_auth" initialized
INFO - 2023-11-17 01:44:57 --> Model "M_user" initialized
INFO - 2023-11-17 01:44:57 --> Model "M_produk" initialized
INFO - 2023-11-17 01:44:57 --> Controller Class Initialized
INFO - 2023-11-17 01:44:57 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-17 01:44:57 --> Final output sent to browser
DEBUG - 2023-11-17 01:44:57 --> Total execution time: 0.0268
ERROR - 2023-11-17 03:23:18 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-17 03:23:18 --> Config Class Initialized
INFO - 2023-11-17 03:23:18 --> Hooks Class Initialized
DEBUG - 2023-11-17 03:23:18 --> UTF-8 Support Enabled
INFO - 2023-11-17 03:23:18 --> Utf8 Class Initialized
INFO - 2023-11-17 03:23:18 --> URI Class Initialized
DEBUG - 2023-11-17 03:23:18 --> No URI present. Default controller set.
INFO - 2023-11-17 03:23:18 --> Router Class Initialized
INFO - 2023-11-17 03:23:18 --> Output Class Initialized
INFO - 2023-11-17 03:23:18 --> Security Class Initialized
DEBUG - 2023-11-17 03:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 03:23:18 --> Input Class Initialized
INFO - 2023-11-17 03:23:18 --> Language Class Initialized
INFO - 2023-11-17 03:23:18 --> Loader Class Initialized
INFO - 2023-11-17 03:23:18 --> Helper loaded: url_helper
INFO - 2023-11-17 03:23:18 --> Helper loaded: form_helper
INFO - 2023-11-17 03:23:18 --> Helper loaded: file_helper
INFO - 2023-11-17 03:23:18 --> Database Driver Class Initialized
DEBUG - 2023-11-17 03:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-17 03:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 03:23:18 --> Form Validation Class Initialized
INFO - 2023-11-17 03:23:18 --> Upload Class Initialized
INFO - 2023-11-17 03:23:18 --> Model "M_auth" initialized
INFO - 2023-11-17 03:23:18 --> Model "M_user" initialized
INFO - 2023-11-17 03:23:18 --> Model "M_produk" initialized
INFO - 2023-11-17 03:23:18 --> Controller Class Initialized
INFO - 2023-11-17 03:23:18 --> Model "M_pelanggan" initialized
INFO - 2023-11-17 03:23:18 --> Model "M_produk" initialized
DEBUG - 2023-11-17 03:23:18 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 03:23:18 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-17 03:23:18 --> Model "M_transaksi" initialized
INFO - 2023-11-17 03:23:18 --> Model "M_bank" initialized
INFO - 2023-11-17 03:23:18 --> Model "M_pesan" initialized
DEBUG - 2023-11-17 03:23:18 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-17 03:23:18 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-17 03:23:18 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-17 03:23:18 --> Final output sent to browser
DEBUG - 2023-11-17 03:23:18 --> Total execution time: 0.0358
ERROR - 2023-11-17 04:27:07 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-17 04:27:07 --> Config Class Initialized
INFO - 2023-11-17 04:27:07 --> Hooks Class Initialized
DEBUG - 2023-11-17 04:27:07 --> UTF-8 Support Enabled
INFO - 2023-11-17 04:27:07 --> Utf8 Class Initialized
INFO - 2023-11-17 04:27:07 --> URI Class Initialized
INFO - 2023-11-17 04:27:07 --> Router Class Initialized
INFO - 2023-11-17 04:27:07 --> Output Class Initialized
INFO - 2023-11-17 04:27:07 --> Security Class Initialized
DEBUG - 2023-11-17 04:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 04:27:07 --> Input Class Initialized
INFO - 2023-11-17 04:27:07 --> Language Class Initialized
INFO - 2023-11-17 04:27:07 --> Loader Class Initialized
INFO - 2023-11-17 04:27:07 --> Helper loaded: url_helper
INFO - 2023-11-17 04:27:07 --> Helper loaded: form_helper
INFO - 2023-11-17 04:27:07 --> Helper loaded: file_helper
INFO - 2023-11-17 04:27:07 --> Database Driver Class Initialized
DEBUG - 2023-11-17 04:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-17 04:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 04:27:07 --> Form Validation Class Initialized
INFO - 2023-11-17 04:27:07 --> Upload Class Initialized
INFO - 2023-11-17 04:27:07 --> Model "M_auth" initialized
INFO - 2023-11-17 04:27:07 --> Model "M_user" initialized
INFO - 2023-11-17 04:27:07 --> Model "M_produk" initialized
INFO - 2023-11-17 04:27:07 --> Controller Class Initialized
INFO - 2023-11-17 04:27:07 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-17 04:27:07 --> Final output sent to browser
DEBUG - 2023-11-17 04:27:07 --> Total execution time: 0.0263
ERROR - 2023-11-17 04:27:08 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-17 04:27:08 --> Config Class Initialized
INFO - 2023-11-17 04:27:08 --> Hooks Class Initialized
DEBUG - 2023-11-17 04:27:08 --> UTF-8 Support Enabled
INFO - 2023-11-17 04:27:08 --> Utf8 Class Initialized
INFO - 2023-11-17 04:27:08 --> URI Class Initialized
DEBUG - 2023-11-17 04:27:08 --> No URI present. Default controller set.
INFO - 2023-11-17 04:27:08 --> Router Class Initialized
INFO - 2023-11-17 04:27:08 --> Output Class Initialized
INFO - 2023-11-17 04:27:08 --> Security Class Initialized
DEBUG - 2023-11-17 04:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 04:27:08 --> Input Class Initialized
INFO - 2023-11-17 04:27:08 --> Language Class Initialized
INFO - 2023-11-17 04:27:08 --> Loader Class Initialized
INFO - 2023-11-17 04:27:08 --> Helper loaded: url_helper
INFO - 2023-11-17 04:27:08 --> Helper loaded: form_helper
INFO - 2023-11-17 04:27:08 --> Helper loaded: file_helper
INFO - 2023-11-17 04:27:08 --> Database Driver Class Initialized
DEBUG - 2023-11-17 04:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-17 04:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 04:27:08 --> Form Validation Class Initialized
INFO - 2023-11-17 04:27:08 --> Upload Class Initialized
INFO - 2023-11-17 04:27:08 --> Model "M_auth" initialized
INFO - 2023-11-17 04:27:08 --> Model "M_user" initialized
INFO - 2023-11-17 04:27:08 --> Model "M_produk" initialized
INFO - 2023-11-17 04:27:08 --> Controller Class Initialized
INFO - 2023-11-17 04:27:08 --> Model "M_pelanggan" initialized
INFO - 2023-11-17 04:27:08 --> Model "M_produk" initialized
DEBUG - 2023-11-17 04:27:08 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 04:27:08 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-17 04:27:08 --> Model "M_transaksi" initialized
INFO - 2023-11-17 04:27:08 --> Model "M_bank" initialized
INFO - 2023-11-17 04:27:08 --> Model "M_pesan" initialized
DEBUG - 2023-11-17 04:27:08 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-17 04:27:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-17 04:27:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-17 04:27:08 --> Final output sent to browser
DEBUG - 2023-11-17 04:27:08 --> Total execution time: 0.0085
ERROR - 2023-11-17 11:11:41 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-17 11:11:41 --> Config Class Initialized
INFO - 2023-11-17 11:11:41 --> Hooks Class Initialized
DEBUG - 2023-11-17 11:11:41 --> UTF-8 Support Enabled
INFO - 2023-11-17 11:11:41 --> Utf8 Class Initialized
INFO - 2023-11-17 11:11:41 --> URI Class Initialized
INFO - 2023-11-17 11:11:41 --> Router Class Initialized
INFO - 2023-11-17 11:11:41 --> Output Class Initialized
INFO - 2023-11-17 11:11:41 --> Security Class Initialized
DEBUG - 2023-11-17 11:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 11:11:41 --> Input Class Initialized
INFO - 2023-11-17 11:11:41 --> Language Class Initialized
INFO - 2023-11-17 11:11:41 --> Loader Class Initialized
INFO - 2023-11-17 11:11:41 --> Helper loaded: url_helper
INFO - 2023-11-17 11:11:41 --> Helper loaded: form_helper
INFO - 2023-11-17 11:11:41 --> Helper loaded: file_helper
INFO - 2023-11-17 11:11:41 --> Database Driver Class Initialized
DEBUG - 2023-11-17 11:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-17 11:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 11:11:41 --> Form Validation Class Initialized
INFO - 2023-11-17 11:11:41 --> Upload Class Initialized
INFO - 2023-11-17 11:11:41 --> Model "M_auth" initialized
INFO - 2023-11-17 11:11:41 --> Model "M_user" initialized
INFO - 2023-11-17 11:11:41 --> Model "M_produk" initialized
INFO - 2023-11-17 11:11:41 --> Controller Class Initialized
INFO - 2023-11-17 11:11:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-17 11:11:41 --> Final output sent to browser
DEBUG - 2023-11-17 11:11:41 --> Total execution time: 0.0267
ERROR - 2023-11-17 11:11:43 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-17 11:11:43 --> Config Class Initialized
INFO - 2023-11-17 11:11:43 --> Hooks Class Initialized
DEBUG - 2023-11-17 11:11:43 --> UTF-8 Support Enabled
INFO - 2023-11-17 11:11:43 --> Utf8 Class Initialized
INFO - 2023-11-17 11:11:43 --> URI Class Initialized
DEBUG - 2023-11-17 11:11:43 --> No URI present. Default controller set.
INFO - 2023-11-17 11:11:43 --> Router Class Initialized
INFO - 2023-11-17 11:11:43 --> Output Class Initialized
INFO - 2023-11-17 11:11:43 --> Security Class Initialized
DEBUG - 2023-11-17 11:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 11:11:43 --> Input Class Initialized
INFO - 2023-11-17 11:11:43 --> Language Class Initialized
INFO - 2023-11-17 11:11:43 --> Loader Class Initialized
INFO - 2023-11-17 11:11:43 --> Helper loaded: url_helper
INFO - 2023-11-17 11:11:43 --> Helper loaded: form_helper
INFO - 2023-11-17 11:11:43 --> Helper loaded: file_helper
INFO - 2023-11-17 11:11:43 --> Database Driver Class Initialized
DEBUG - 2023-11-17 11:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-17 11:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 11:11:43 --> Form Validation Class Initialized
INFO - 2023-11-17 11:11:43 --> Upload Class Initialized
INFO - 2023-11-17 11:11:43 --> Model "M_auth" initialized
INFO - 2023-11-17 11:11:43 --> Model "M_user" initialized
INFO - 2023-11-17 11:11:43 --> Model "M_produk" initialized
INFO - 2023-11-17 11:11:43 --> Controller Class Initialized
INFO - 2023-11-17 11:11:43 --> Model "M_pelanggan" initialized
INFO - 2023-11-17 11:11:43 --> Model "M_produk" initialized
DEBUG - 2023-11-17 11:11:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 11:11:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-17 11:11:43 --> Model "M_transaksi" initialized
INFO - 2023-11-17 11:11:43 --> Model "M_bank" initialized
INFO - 2023-11-17 11:11:43 --> Model "M_pesan" initialized
DEBUG - 2023-11-17 11:11:43 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-17 11:11:43 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-17 11:11:43 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-17 11:11:43 --> Final output sent to browser
DEBUG - 2023-11-17 11:11:43 --> Total execution time: 0.0103
ERROR - 2023-11-17 11:37:05 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-17 11:37:05 --> Config Class Initialized
INFO - 2023-11-17 11:37:05 --> Hooks Class Initialized
DEBUG - 2023-11-17 11:37:05 --> UTF-8 Support Enabled
INFO - 2023-11-17 11:37:05 --> Utf8 Class Initialized
INFO - 2023-11-17 11:37:05 --> URI Class Initialized
DEBUG - 2023-11-17 11:37:05 --> No URI present. Default controller set.
INFO - 2023-11-17 11:37:05 --> Router Class Initialized
INFO - 2023-11-17 11:37:05 --> Output Class Initialized
INFO - 2023-11-17 11:37:05 --> Security Class Initialized
DEBUG - 2023-11-17 11:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 11:37:05 --> Input Class Initialized
INFO - 2023-11-17 11:37:05 --> Language Class Initialized
INFO - 2023-11-17 11:37:05 --> Loader Class Initialized
INFO - 2023-11-17 11:37:05 --> Helper loaded: url_helper
INFO - 2023-11-17 11:37:05 --> Helper loaded: form_helper
INFO - 2023-11-17 11:37:05 --> Helper loaded: file_helper
INFO - 2023-11-17 11:37:05 --> Database Driver Class Initialized
DEBUG - 2023-11-17 11:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-17 11:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 11:37:05 --> Form Validation Class Initialized
INFO - 2023-11-17 11:37:05 --> Upload Class Initialized
INFO - 2023-11-17 11:37:05 --> Model "M_auth" initialized
INFO - 2023-11-17 11:37:05 --> Model "M_user" initialized
INFO - 2023-11-17 11:37:05 --> Model "M_produk" initialized
INFO - 2023-11-17 11:37:05 --> Controller Class Initialized
INFO - 2023-11-17 11:37:05 --> Model "M_pelanggan" initialized
INFO - 2023-11-17 11:37:05 --> Model "M_produk" initialized
DEBUG - 2023-11-17 11:37:05 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 11:37:05 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-17 11:37:05 --> Model "M_transaksi" initialized
INFO - 2023-11-17 11:37:05 --> Model "M_bank" initialized
INFO - 2023-11-17 11:37:05 --> Model "M_pesan" initialized
DEBUG - 2023-11-17 11:37:05 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-17 11:37:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-17 11:37:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-17 11:37:05 --> Final output sent to browser
DEBUG - 2023-11-17 11:37:05 --> Total execution time: 0.0359
ERROR - 2023-11-17 16:20:41 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-17 16:20:41 --> Config Class Initialized
INFO - 2023-11-17 16:20:41 --> Hooks Class Initialized
DEBUG - 2023-11-17 16:20:41 --> UTF-8 Support Enabled
INFO - 2023-11-17 16:20:41 --> Utf8 Class Initialized
INFO - 2023-11-17 16:20:41 --> URI Class Initialized
DEBUG - 2023-11-17 16:20:41 --> No URI present. Default controller set.
INFO - 2023-11-17 16:20:41 --> Router Class Initialized
INFO - 2023-11-17 16:20:41 --> Output Class Initialized
INFO - 2023-11-17 16:20:41 --> Security Class Initialized
DEBUG - 2023-11-17 16:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 16:20:41 --> Input Class Initialized
INFO - 2023-11-17 16:20:41 --> Language Class Initialized
INFO - 2023-11-17 16:20:41 --> Loader Class Initialized
INFO - 2023-11-17 16:20:41 --> Helper loaded: url_helper
INFO - 2023-11-17 16:20:41 --> Helper loaded: form_helper
INFO - 2023-11-17 16:20:41 --> Helper loaded: file_helper
INFO - 2023-11-17 16:20:41 --> Database Driver Class Initialized
DEBUG - 2023-11-17 16:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-17 16:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 16:20:41 --> Form Validation Class Initialized
INFO - 2023-11-17 16:20:41 --> Upload Class Initialized
INFO - 2023-11-17 16:20:41 --> Model "M_auth" initialized
INFO - 2023-11-17 16:20:41 --> Model "M_user" initialized
INFO - 2023-11-17 16:20:41 --> Model "M_produk" initialized
INFO - 2023-11-17 16:20:41 --> Controller Class Initialized
INFO - 2023-11-17 16:20:41 --> Model "M_pelanggan" initialized
INFO - 2023-11-17 16:20:41 --> Model "M_produk" initialized
DEBUG - 2023-11-17 16:20:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 16:20:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-17 16:20:41 --> Model "M_transaksi" initialized
INFO - 2023-11-17 16:20:41 --> Model "M_bank" initialized
INFO - 2023-11-17 16:20:41 --> Model "M_pesan" initialized
DEBUG - 2023-11-17 16:20:41 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-17 16:20:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-17 16:20:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-17 16:20:41 --> Final output sent to browser
DEBUG - 2023-11-17 16:20:41 --> Total execution time: 0.0302
ERROR - 2023-11-17 17:53:41 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-17 17:53:41 --> Config Class Initialized
INFO - 2023-11-17 17:53:41 --> Hooks Class Initialized
DEBUG - 2023-11-17 17:53:41 --> UTF-8 Support Enabled
INFO - 2023-11-17 17:53:41 --> Utf8 Class Initialized
INFO - 2023-11-17 17:53:41 --> URI Class Initialized
DEBUG - 2023-11-17 17:53:41 --> No URI present. Default controller set.
INFO - 2023-11-17 17:53:41 --> Router Class Initialized
INFO - 2023-11-17 17:53:41 --> Output Class Initialized
INFO - 2023-11-17 17:53:41 --> Security Class Initialized
DEBUG - 2023-11-17 17:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 17:53:41 --> Input Class Initialized
INFO - 2023-11-17 17:53:41 --> Language Class Initialized
INFO - 2023-11-17 17:53:41 --> Loader Class Initialized
INFO - 2023-11-17 17:53:41 --> Helper loaded: url_helper
INFO - 2023-11-17 17:53:41 --> Helper loaded: form_helper
INFO - 2023-11-17 17:53:41 --> Helper loaded: file_helper
INFO - 2023-11-17 17:53:41 --> Database Driver Class Initialized
DEBUG - 2023-11-17 17:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-17 17:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 17:53:41 --> Form Validation Class Initialized
INFO - 2023-11-17 17:53:41 --> Upload Class Initialized
INFO - 2023-11-17 17:53:41 --> Model "M_auth" initialized
INFO - 2023-11-17 17:53:41 --> Model "M_user" initialized
INFO - 2023-11-17 17:53:41 --> Model "M_produk" initialized
INFO - 2023-11-17 17:53:41 --> Controller Class Initialized
INFO - 2023-11-17 17:53:41 --> Model "M_pelanggan" initialized
INFO - 2023-11-17 17:53:41 --> Model "M_produk" initialized
DEBUG - 2023-11-17 17:53:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 17:53:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-17 17:53:41 --> Model "M_transaksi" initialized
INFO - 2023-11-17 17:53:41 --> Model "M_bank" initialized
INFO - 2023-11-17 17:53:41 --> Model "M_pesan" initialized
DEBUG - 2023-11-17 17:53:41 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-17 17:53:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-17 17:53:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-17 17:53:41 --> Final output sent to browser
DEBUG - 2023-11-17 17:53:41 --> Total execution time: 0.0337
ERROR - 2023-11-17 19:03:35 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-17 19:03:35 --> Config Class Initialized
INFO - 2023-11-17 19:03:35 --> Hooks Class Initialized
DEBUG - 2023-11-17 19:03:35 --> UTF-8 Support Enabled
INFO - 2023-11-17 19:03:35 --> Utf8 Class Initialized
INFO - 2023-11-17 19:03:35 --> URI Class Initialized
DEBUG - 2023-11-17 19:03:35 --> No URI present. Default controller set.
INFO - 2023-11-17 19:03:35 --> Router Class Initialized
INFO - 2023-11-17 19:03:35 --> Output Class Initialized
INFO - 2023-11-17 19:03:35 --> Security Class Initialized
DEBUG - 2023-11-17 19:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 19:03:35 --> Input Class Initialized
INFO - 2023-11-17 19:03:35 --> Language Class Initialized
INFO - 2023-11-17 19:03:35 --> Loader Class Initialized
INFO - 2023-11-17 19:03:35 --> Helper loaded: url_helper
INFO - 2023-11-17 19:03:35 --> Helper loaded: form_helper
INFO - 2023-11-17 19:03:35 --> Helper loaded: file_helper
INFO - 2023-11-17 19:03:35 --> Database Driver Class Initialized
DEBUG - 2023-11-17 19:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-17 19:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 19:03:35 --> Form Validation Class Initialized
INFO - 2023-11-17 19:03:35 --> Upload Class Initialized
INFO - 2023-11-17 19:03:35 --> Model "M_auth" initialized
INFO - 2023-11-17 19:03:35 --> Model "M_user" initialized
INFO - 2023-11-17 19:03:35 --> Model "M_produk" initialized
INFO - 2023-11-17 19:03:35 --> Controller Class Initialized
INFO - 2023-11-17 19:03:35 --> Model "M_pelanggan" initialized
INFO - 2023-11-17 19:03:35 --> Model "M_produk" initialized
DEBUG - 2023-11-17 19:03:35 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 19:03:35 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-17 19:03:35 --> Model "M_transaksi" initialized
INFO - 2023-11-17 19:03:35 --> Model "M_bank" initialized
INFO - 2023-11-17 19:03:35 --> Model "M_pesan" initialized
DEBUG - 2023-11-17 19:03:35 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-17 19:03:35 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-17 19:03:35 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-17 19:03:35 --> Final output sent to browser
DEBUG - 2023-11-17 19:03:35 --> Total execution time: 0.0305
ERROR - 2023-11-17 19:14:23 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-17 19:14:23 --> Config Class Initialized
INFO - 2023-11-17 19:14:23 --> Hooks Class Initialized
DEBUG - 2023-11-17 19:14:23 --> UTF-8 Support Enabled
INFO - 2023-11-17 19:14:23 --> Utf8 Class Initialized
INFO - 2023-11-17 19:14:23 --> URI Class Initialized
DEBUG - 2023-11-17 19:14:23 --> No URI present. Default controller set.
INFO - 2023-11-17 19:14:23 --> Router Class Initialized
INFO - 2023-11-17 19:14:23 --> Output Class Initialized
INFO - 2023-11-17 19:14:23 --> Security Class Initialized
DEBUG - 2023-11-17 19:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 19:14:23 --> Input Class Initialized
INFO - 2023-11-17 19:14:23 --> Language Class Initialized
INFO - 2023-11-17 19:14:23 --> Loader Class Initialized
INFO - 2023-11-17 19:14:23 --> Helper loaded: url_helper
INFO - 2023-11-17 19:14:23 --> Helper loaded: form_helper
INFO - 2023-11-17 19:14:23 --> Helper loaded: file_helper
INFO - 2023-11-17 19:14:23 --> Database Driver Class Initialized
DEBUG - 2023-11-17 19:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-17 19:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 19:14:23 --> Form Validation Class Initialized
INFO - 2023-11-17 19:14:23 --> Upload Class Initialized
INFO - 2023-11-17 19:14:23 --> Model "M_auth" initialized
INFO - 2023-11-17 19:14:23 --> Model "M_user" initialized
INFO - 2023-11-17 19:14:23 --> Model "M_produk" initialized
INFO - 2023-11-17 19:14:23 --> Controller Class Initialized
INFO - 2023-11-17 19:14:23 --> Model "M_pelanggan" initialized
INFO - 2023-11-17 19:14:23 --> Model "M_produk" initialized
DEBUG - 2023-11-17 19:14:23 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 19:14:23 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-17 19:14:23 --> Model "M_transaksi" initialized
INFO - 2023-11-17 19:14:23 --> Model "M_bank" initialized
INFO - 2023-11-17 19:14:23 --> Model "M_pesan" initialized
DEBUG - 2023-11-17 19:14:23 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-17 19:14:23 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-17 19:14:23 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-17 19:14:23 --> Final output sent to browser
DEBUG - 2023-11-17 19:14:23 --> Total execution time: 0.0381
ERROR - 2023-11-17 19:32:25 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-17 19:32:25 --> Config Class Initialized
INFO - 2023-11-17 19:32:25 --> Hooks Class Initialized
DEBUG - 2023-11-17 19:32:25 --> UTF-8 Support Enabled
INFO - 2023-11-17 19:32:25 --> Utf8 Class Initialized
INFO - 2023-11-17 19:32:25 --> URI Class Initialized
INFO - 2023-11-17 19:32:25 --> Router Class Initialized
INFO - 2023-11-17 19:32:25 --> Output Class Initialized
INFO - 2023-11-17 19:32:25 --> Security Class Initialized
DEBUG - 2023-11-17 19:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-17 19:32:25 --> Input Class Initialized
INFO - 2023-11-17 19:32:25 --> Language Class Initialized
INFO - 2023-11-17 19:32:25 --> Loader Class Initialized
INFO - 2023-11-17 19:32:25 --> Helper loaded: url_helper
INFO - 2023-11-17 19:32:25 --> Helper loaded: form_helper
INFO - 2023-11-17 19:32:25 --> Helper loaded: file_helper
INFO - 2023-11-17 19:32:25 --> Database Driver Class Initialized
DEBUG - 2023-11-17 19:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-17 19:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-17 19:32:25 --> Form Validation Class Initialized
INFO - 2023-11-17 19:32:25 --> Upload Class Initialized
INFO - 2023-11-17 19:32:25 --> Model "M_auth" initialized
INFO - 2023-11-17 19:32:25 --> Model "M_user" initialized
INFO - 2023-11-17 19:32:25 --> Model "M_produk" initialized
INFO - 2023-11-17 19:32:25 --> Controller Class Initialized
INFO - 2023-11-17 19:32:25 --> Model "M_pelanggan" initialized
INFO - 2023-11-17 19:32:25 --> Model "M_produk" initialized
DEBUG - 2023-11-17 19:32:25 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-17 19:32:25 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-17 19:32:25 --> Model "M_transaksi" initialized
INFO - 2023-11-17 19:32:25 --> Model "M_bank" initialized
INFO - 2023-11-17 19:32:25 --> Model "M_pesan" initialized
DEBUG - 2023-11-17 19:32:25 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-17 19:32:25 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-17 19:32:25 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-17 19:32:25 --> Final output sent to browser
DEBUG - 2023-11-17 19:32:25 --> Total execution time: 0.0364
