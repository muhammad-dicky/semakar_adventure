<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-13 00:48:05 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-13 00:48:05 --> Config Class Initialized
INFO - 2023-11-13 00:48:05 --> Hooks Class Initialized
DEBUG - 2023-11-13 00:48:05 --> UTF-8 Support Enabled
INFO - 2023-11-13 00:48:05 --> Utf8 Class Initialized
INFO - 2023-11-13 00:48:05 --> URI Class Initialized
DEBUG - 2023-11-13 00:48:05 --> No URI present. Default controller set.
INFO - 2023-11-13 00:48:05 --> Router Class Initialized
INFO - 2023-11-13 00:48:05 --> Output Class Initialized
INFO - 2023-11-13 00:48:05 --> Security Class Initialized
DEBUG - 2023-11-13 00:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 00:48:05 --> Input Class Initialized
INFO - 2023-11-13 00:48:05 --> Language Class Initialized
INFO - 2023-11-13 00:48:05 --> Loader Class Initialized
INFO - 2023-11-13 00:48:05 --> Helper loaded: url_helper
INFO - 2023-11-13 00:48:05 --> Helper loaded: form_helper
INFO - 2023-11-13 00:48:05 --> Helper loaded: file_helper
INFO - 2023-11-13 00:48:05 --> Database Driver Class Initialized
DEBUG - 2023-11-13 00:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-13 00:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-13 00:48:05 --> Form Validation Class Initialized
INFO - 2023-11-13 00:48:05 --> Upload Class Initialized
INFO - 2023-11-13 00:48:05 --> Model "M_auth" initialized
INFO - 2023-11-13 00:48:05 --> Model "M_user" initialized
INFO - 2023-11-13 00:48:05 --> Model "M_produk" initialized
INFO - 2023-11-13 00:48:05 --> Controller Class Initialized
INFO - 2023-11-13 00:48:05 --> Model "M_pelanggan" initialized
INFO - 2023-11-13 00:48:05 --> Model "M_produk" initialized
DEBUG - 2023-11-13 00:48:05 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-13 00:48:05 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-13 00:48:05 --> Model "M_transaksi" initialized
INFO - 2023-11-13 00:48:05 --> Model "M_bank" initialized
INFO - 2023-11-13 00:48:05 --> Model "M_pesan" initialized
DEBUG - 2023-11-13 00:48:05 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-13 00:48:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-13 00:48:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-13 00:48:05 --> Final output sent to browser
DEBUG - 2023-11-13 00:48:05 --> Total execution time: 0.0485
ERROR - 2023-11-13 01:14:53 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-13 01:14:53 --> Config Class Initialized
INFO - 2023-11-13 01:14:53 --> Hooks Class Initialized
DEBUG - 2023-11-13 01:14:53 --> UTF-8 Support Enabled
INFO - 2023-11-13 01:14:53 --> Utf8 Class Initialized
INFO - 2023-11-13 01:14:53 --> URI Class Initialized
INFO - 2023-11-13 01:14:53 --> Router Class Initialized
INFO - 2023-11-13 01:14:53 --> Output Class Initialized
INFO - 2023-11-13 01:14:53 --> Security Class Initialized
DEBUG - 2023-11-13 01:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 01:14:53 --> Input Class Initialized
INFO - 2023-11-13 01:14:53 --> Language Class Initialized
INFO - 2023-11-13 01:14:53 --> Loader Class Initialized
INFO - 2023-11-13 01:14:53 --> Helper loaded: url_helper
INFO - 2023-11-13 01:14:53 --> Helper loaded: form_helper
INFO - 2023-11-13 01:14:53 --> Helper loaded: file_helper
INFO - 2023-11-13 01:14:53 --> Database Driver Class Initialized
DEBUG - 2023-11-13 01:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-13 01:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-13 01:14:53 --> Form Validation Class Initialized
INFO - 2023-11-13 01:14:53 --> Upload Class Initialized
INFO - 2023-11-13 01:14:53 --> Model "M_auth" initialized
INFO - 2023-11-13 01:14:53 --> Model "M_user" initialized
INFO - 2023-11-13 01:14:53 --> Model "M_produk" initialized
INFO - 2023-11-13 01:14:53 --> Controller Class Initialized
INFO - 2023-11-13 01:14:53 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-13 01:14:53 --> Final output sent to browser
DEBUG - 2023-11-13 01:14:53 --> Total execution time: 0.0362
ERROR - 2023-11-13 01:21:48 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-13 01:21:48 --> Config Class Initialized
INFO - 2023-11-13 01:21:48 --> Hooks Class Initialized
DEBUG - 2023-11-13 01:21:48 --> UTF-8 Support Enabled
INFO - 2023-11-13 01:21:48 --> Utf8 Class Initialized
INFO - 2023-11-13 01:21:48 --> URI Class Initialized
DEBUG - 2023-11-13 01:21:48 --> No URI present. Default controller set.
INFO - 2023-11-13 01:21:48 --> Router Class Initialized
INFO - 2023-11-13 01:21:48 --> Output Class Initialized
INFO - 2023-11-13 01:21:48 --> Security Class Initialized
DEBUG - 2023-11-13 01:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 01:21:48 --> Input Class Initialized
INFO - 2023-11-13 01:21:48 --> Language Class Initialized
INFO - 2023-11-13 01:21:48 --> Loader Class Initialized
INFO - 2023-11-13 01:21:48 --> Helper loaded: url_helper
INFO - 2023-11-13 01:21:48 --> Helper loaded: form_helper
INFO - 2023-11-13 01:21:48 --> Helper loaded: file_helper
INFO - 2023-11-13 01:21:48 --> Database Driver Class Initialized
DEBUG - 2023-11-13 01:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-13 01:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-13 01:21:48 --> Form Validation Class Initialized
INFO - 2023-11-13 01:21:48 --> Upload Class Initialized
INFO - 2023-11-13 01:21:48 --> Model "M_auth" initialized
INFO - 2023-11-13 01:21:48 --> Model "M_user" initialized
INFO - 2023-11-13 01:21:48 --> Model "M_produk" initialized
INFO - 2023-11-13 01:21:48 --> Controller Class Initialized
INFO - 2023-11-13 01:21:48 --> Model "M_pelanggan" initialized
INFO - 2023-11-13 01:21:48 --> Model "M_produk" initialized
DEBUG - 2023-11-13 01:21:48 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-13 01:21:48 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-13 01:21:48 --> Model "M_transaksi" initialized
INFO - 2023-11-13 01:21:48 --> Model "M_bank" initialized
INFO - 2023-11-13 01:21:48 --> Model "M_pesan" initialized
DEBUG - 2023-11-13 01:21:48 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-13 01:21:48 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-13 01:21:48 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-13 01:21:48 --> Final output sent to browser
DEBUG - 2023-11-13 01:21:48 --> Total execution time: 0.0336
ERROR - 2023-11-13 02:20:11 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-13 02:20:11 --> Config Class Initialized
INFO - 2023-11-13 02:20:11 --> Hooks Class Initialized
DEBUG - 2023-11-13 02:20:11 --> UTF-8 Support Enabled
INFO - 2023-11-13 02:20:11 --> Utf8 Class Initialized
INFO - 2023-11-13 02:20:11 --> URI Class Initialized
INFO - 2023-11-13 02:20:11 --> Router Class Initialized
INFO - 2023-11-13 02:20:11 --> Output Class Initialized
INFO - 2023-11-13 02:20:11 --> Security Class Initialized
DEBUG - 2023-11-13 02:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 02:20:11 --> Input Class Initialized
INFO - 2023-11-13 02:20:11 --> Language Class Initialized
INFO - 2023-11-13 02:20:11 --> Loader Class Initialized
INFO - 2023-11-13 02:20:11 --> Helper loaded: url_helper
INFO - 2023-11-13 02:20:11 --> Helper loaded: form_helper
INFO - 2023-11-13 02:20:11 --> Helper loaded: file_helper
INFO - 2023-11-13 02:20:11 --> Database Driver Class Initialized
DEBUG - 2023-11-13 02:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-13 02:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-13 02:20:11 --> Form Validation Class Initialized
INFO - 2023-11-13 02:20:11 --> Upload Class Initialized
INFO - 2023-11-13 02:20:11 --> Model "M_auth" initialized
INFO - 2023-11-13 02:20:11 --> Model "M_user" initialized
INFO - 2023-11-13 02:20:11 --> Model "M_produk" initialized
INFO - 2023-11-13 02:20:11 --> Controller Class Initialized
INFO - 2023-11-13 02:20:11 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-13 02:20:11 --> Final output sent to browser
DEBUG - 2023-11-13 02:20:11 --> Total execution time: 0.0351
ERROR - 2023-11-13 02:45:06 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-13 02:45:06 --> Config Class Initialized
INFO - 2023-11-13 02:45:06 --> Hooks Class Initialized
DEBUG - 2023-11-13 02:45:06 --> UTF-8 Support Enabled
INFO - 2023-11-13 02:45:06 --> Utf8 Class Initialized
INFO - 2023-11-13 02:45:06 --> URI Class Initialized
DEBUG - 2023-11-13 02:45:06 --> No URI present. Default controller set.
INFO - 2023-11-13 02:45:06 --> Router Class Initialized
INFO - 2023-11-13 02:45:06 --> Output Class Initialized
INFO - 2023-11-13 02:45:06 --> Security Class Initialized
DEBUG - 2023-11-13 02:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 02:45:06 --> Input Class Initialized
INFO - 2023-11-13 02:45:06 --> Language Class Initialized
INFO - 2023-11-13 02:45:06 --> Loader Class Initialized
INFO - 2023-11-13 02:45:06 --> Helper loaded: url_helper
INFO - 2023-11-13 02:45:06 --> Helper loaded: form_helper
INFO - 2023-11-13 02:45:06 --> Helper loaded: file_helper
INFO - 2023-11-13 02:45:06 --> Database Driver Class Initialized
DEBUG - 2023-11-13 02:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-13 02:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-13 02:45:06 --> Form Validation Class Initialized
INFO - 2023-11-13 02:45:06 --> Upload Class Initialized
INFO - 2023-11-13 02:45:06 --> Model "M_auth" initialized
INFO - 2023-11-13 02:45:06 --> Model "M_user" initialized
INFO - 2023-11-13 02:45:06 --> Model "M_produk" initialized
INFO - 2023-11-13 02:45:06 --> Controller Class Initialized
INFO - 2023-11-13 02:45:06 --> Model "M_pelanggan" initialized
INFO - 2023-11-13 02:45:06 --> Model "M_produk" initialized
DEBUG - 2023-11-13 02:45:06 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-13 02:45:06 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-13 02:45:06 --> Model "M_transaksi" initialized
INFO - 2023-11-13 02:45:06 --> Model "M_bank" initialized
INFO - 2023-11-13 02:45:06 --> Model "M_pesan" initialized
DEBUG - 2023-11-13 02:45:06 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-13 02:45:06 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-13 02:45:06 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-13 02:45:06 --> Final output sent to browser
DEBUG - 2023-11-13 02:45:06 --> Total execution time: 0.0478
ERROR - 2023-11-13 03:43:43 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-13 03:43:43 --> Config Class Initialized
INFO - 2023-11-13 03:43:43 --> Hooks Class Initialized
DEBUG - 2023-11-13 03:43:43 --> UTF-8 Support Enabled
INFO - 2023-11-13 03:43:43 --> Utf8 Class Initialized
INFO - 2023-11-13 03:43:43 --> URI Class Initialized
DEBUG - 2023-11-13 03:43:43 --> No URI present. Default controller set.
INFO - 2023-11-13 03:43:43 --> Router Class Initialized
INFO - 2023-11-13 03:43:43 --> Output Class Initialized
INFO - 2023-11-13 03:43:43 --> Security Class Initialized
DEBUG - 2023-11-13 03:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 03:43:43 --> Input Class Initialized
INFO - 2023-11-13 03:43:43 --> Language Class Initialized
INFO - 2023-11-13 03:43:43 --> Loader Class Initialized
INFO - 2023-11-13 03:43:43 --> Helper loaded: url_helper
INFO - 2023-11-13 03:43:43 --> Helper loaded: form_helper
INFO - 2023-11-13 03:43:43 --> Helper loaded: file_helper
INFO - 2023-11-13 03:43:43 --> Database Driver Class Initialized
DEBUG - 2023-11-13 03:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-13 03:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-13 03:43:43 --> Form Validation Class Initialized
INFO - 2023-11-13 03:43:43 --> Upload Class Initialized
INFO - 2023-11-13 03:43:43 --> Model "M_auth" initialized
INFO - 2023-11-13 03:43:43 --> Model "M_user" initialized
INFO - 2023-11-13 03:43:43 --> Model "M_produk" initialized
INFO - 2023-11-13 03:43:43 --> Controller Class Initialized
INFO - 2023-11-13 03:43:43 --> Model "M_pelanggan" initialized
INFO - 2023-11-13 03:43:43 --> Model "M_produk" initialized
DEBUG - 2023-11-13 03:43:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-13 03:43:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-13 03:43:43 --> Model "M_transaksi" initialized
INFO - 2023-11-13 03:43:43 --> Model "M_bank" initialized
INFO - 2023-11-13 03:43:43 --> Model "M_pesan" initialized
DEBUG - 2023-11-13 03:43:43 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-13 03:43:43 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-13 03:43:43 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-13 03:43:43 --> Final output sent to browser
DEBUG - 2023-11-13 03:43:43 --> Total execution time: 0.0517
ERROR - 2023-11-13 06:50:07 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-13 06:50:07 --> Config Class Initialized
INFO - 2023-11-13 06:50:07 --> Hooks Class Initialized
DEBUG - 2023-11-13 06:50:07 --> UTF-8 Support Enabled
INFO - 2023-11-13 06:50:07 --> Utf8 Class Initialized
INFO - 2023-11-13 06:50:07 --> URI Class Initialized
INFO - 2023-11-13 06:50:07 --> Router Class Initialized
INFO - 2023-11-13 06:50:07 --> Output Class Initialized
INFO - 2023-11-13 06:50:07 --> Security Class Initialized
DEBUG - 2023-11-13 06:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 06:50:07 --> Input Class Initialized
INFO - 2023-11-13 06:50:07 --> Language Class Initialized
INFO - 2023-11-13 06:50:07 --> Loader Class Initialized
INFO - 2023-11-13 06:50:07 --> Helper loaded: url_helper
INFO - 2023-11-13 06:50:07 --> Helper loaded: form_helper
INFO - 2023-11-13 06:50:07 --> Helper loaded: file_helper
INFO - 2023-11-13 06:50:07 --> Database Driver Class Initialized
DEBUG - 2023-11-13 06:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-13 06:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-13 06:50:07 --> Form Validation Class Initialized
INFO - 2023-11-13 06:50:07 --> Upload Class Initialized
INFO - 2023-11-13 06:50:07 --> Model "M_auth" initialized
INFO - 2023-11-13 06:50:07 --> Model "M_user" initialized
INFO - 2023-11-13 06:50:07 --> Model "M_produk" initialized
INFO - 2023-11-13 06:50:07 --> Controller Class Initialized
INFO - 2023-11-13 06:50:07 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-13 06:50:07 --> Final output sent to browser
DEBUG - 2023-11-13 06:50:07 --> Total execution time: 0.0387
ERROR - 2023-11-13 06:50:08 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-13 06:50:08 --> Config Class Initialized
INFO - 2023-11-13 06:50:08 --> Hooks Class Initialized
DEBUG - 2023-11-13 06:50:08 --> UTF-8 Support Enabled
INFO - 2023-11-13 06:50:08 --> Utf8 Class Initialized
INFO - 2023-11-13 06:50:08 --> URI Class Initialized
DEBUG - 2023-11-13 06:50:08 --> No URI present. Default controller set.
INFO - 2023-11-13 06:50:08 --> Router Class Initialized
INFO - 2023-11-13 06:50:08 --> Output Class Initialized
INFO - 2023-11-13 06:50:08 --> Security Class Initialized
DEBUG - 2023-11-13 06:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 06:50:08 --> Input Class Initialized
INFO - 2023-11-13 06:50:08 --> Language Class Initialized
INFO - 2023-11-13 06:50:08 --> Loader Class Initialized
INFO - 2023-11-13 06:50:08 --> Helper loaded: url_helper
INFO - 2023-11-13 06:50:08 --> Helper loaded: form_helper
INFO - 2023-11-13 06:50:08 --> Helper loaded: file_helper
INFO - 2023-11-13 06:50:08 --> Database Driver Class Initialized
DEBUG - 2023-11-13 06:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-13 06:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-13 06:50:08 --> Form Validation Class Initialized
INFO - 2023-11-13 06:50:08 --> Upload Class Initialized
INFO - 2023-11-13 06:50:08 --> Model "M_auth" initialized
INFO - 2023-11-13 06:50:08 --> Model "M_user" initialized
INFO - 2023-11-13 06:50:08 --> Model "M_produk" initialized
INFO - 2023-11-13 06:50:08 --> Controller Class Initialized
INFO - 2023-11-13 06:50:08 --> Model "M_pelanggan" initialized
INFO - 2023-11-13 06:50:08 --> Model "M_produk" initialized
DEBUG - 2023-11-13 06:50:08 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-13 06:50:08 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-13 06:50:08 --> Model "M_transaksi" initialized
INFO - 2023-11-13 06:50:08 --> Model "M_bank" initialized
INFO - 2023-11-13 06:50:08 --> Model "M_pesan" initialized
DEBUG - 2023-11-13 06:50:08 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-13 06:50:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-13 06:50:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-13 06:50:08 --> Final output sent to browser
DEBUG - 2023-11-13 06:50:08 --> Total execution time: 0.0131
ERROR - 2023-11-13 08:01:40 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-13 08:01:40 --> Config Class Initialized
INFO - 2023-11-13 08:01:40 --> Hooks Class Initialized
DEBUG - 2023-11-13 08:01:40 --> UTF-8 Support Enabled
INFO - 2023-11-13 08:01:40 --> Utf8 Class Initialized
INFO - 2023-11-13 08:01:40 --> URI Class Initialized
INFO - 2023-11-13 08:01:40 --> Router Class Initialized
INFO - 2023-11-13 08:01:40 --> Output Class Initialized
INFO - 2023-11-13 08:01:40 --> Security Class Initialized
DEBUG - 2023-11-13 08:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 08:01:40 --> Input Class Initialized
INFO - 2023-11-13 08:01:40 --> Language Class Initialized
INFO - 2023-11-13 08:01:40 --> Loader Class Initialized
INFO - 2023-11-13 08:01:40 --> Helper loaded: url_helper
INFO - 2023-11-13 08:01:40 --> Helper loaded: form_helper
INFO - 2023-11-13 08:01:40 --> Helper loaded: file_helper
INFO - 2023-11-13 08:01:40 --> Database Driver Class Initialized
DEBUG - 2023-11-13 08:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-13 08:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-13 08:01:40 --> Form Validation Class Initialized
INFO - 2023-11-13 08:01:40 --> Upload Class Initialized
INFO - 2023-11-13 08:01:40 --> Model "M_auth" initialized
INFO - 2023-11-13 08:01:40 --> Model "M_user" initialized
INFO - 2023-11-13 08:01:40 --> Model "M_produk" initialized
INFO - 2023-11-13 08:01:40 --> Controller Class Initialized
INFO - 2023-11-13 08:01:40 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-13 08:01:40 --> Final output sent to browser
DEBUG - 2023-11-13 08:01:40 --> Total execution time: 0.0364
ERROR - 2023-11-13 08:01:42 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-13 08:01:42 --> Config Class Initialized
INFO - 2023-11-13 08:01:42 --> Hooks Class Initialized
DEBUG - 2023-11-13 08:01:42 --> UTF-8 Support Enabled
INFO - 2023-11-13 08:01:42 --> Utf8 Class Initialized
INFO - 2023-11-13 08:01:42 --> URI Class Initialized
DEBUG - 2023-11-13 08:01:42 --> No URI present. Default controller set.
INFO - 2023-11-13 08:01:42 --> Router Class Initialized
INFO - 2023-11-13 08:01:42 --> Output Class Initialized
INFO - 2023-11-13 08:01:42 --> Security Class Initialized
DEBUG - 2023-11-13 08:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 08:01:42 --> Input Class Initialized
INFO - 2023-11-13 08:01:42 --> Language Class Initialized
INFO - 2023-11-13 08:01:42 --> Loader Class Initialized
INFO - 2023-11-13 08:01:42 --> Helper loaded: url_helper
INFO - 2023-11-13 08:01:42 --> Helper loaded: form_helper
INFO - 2023-11-13 08:01:42 --> Helper loaded: file_helper
INFO - 2023-11-13 08:01:42 --> Database Driver Class Initialized
DEBUG - 2023-11-13 08:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-13 08:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-13 08:01:42 --> Form Validation Class Initialized
INFO - 2023-11-13 08:01:42 --> Upload Class Initialized
INFO - 2023-11-13 08:01:42 --> Model "M_auth" initialized
INFO - 2023-11-13 08:01:42 --> Model "M_user" initialized
INFO - 2023-11-13 08:01:42 --> Model "M_produk" initialized
INFO - 2023-11-13 08:01:42 --> Controller Class Initialized
INFO - 2023-11-13 08:01:42 --> Model "M_pelanggan" initialized
INFO - 2023-11-13 08:01:42 --> Model "M_produk" initialized
DEBUG - 2023-11-13 08:01:42 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-13 08:01:42 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-13 08:01:42 --> Model "M_transaksi" initialized
INFO - 2023-11-13 08:01:42 --> Model "M_bank" initialized
INFO - 2023-11-13 08:01:42 --> Model "M_pesan" initialized
DEBUG - 2023-11-13 08:01:42 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-13 08:01:42 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-13 08:01:42 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-13 08:01:42 --> Final output sent to browser
DEBUG - 2023-11-13 08:01:42 --> Total execution time: 0.0124
ERROR - 2023-11-13 08:23:44 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-13 08:23:44 --> Config Class Initialized
INFO - 2023-11-13 08:23:44 --> Hooks Class Initialized
DEBUG - 2023-11-13 08:23:44 --> UTF-8 Support Enabled
INFO - 2023-11-13 08:23:44 --> Utf8 Class Initialized
INFO - 2023-11-13 08:23:44 --> URI Class Initialized
INFO - 2023-11-13 08:23:44 --> Router Class Initialized
INFO - 2023-11-13 08:23:44 --> Output Class Initialized
INFO - 2023-11-13 08:23:44 --> Security Class Initialized
DEBUG - 2023-11-13 08:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 08:23:44 --> Input Class Initialized
INFO - 2023-11-13 08:23:44 --> Language Class Initialized
INFO - 2023-11-13 08:23:44 --> Loader Class Initialized
INFO - 2023-11-13 08:23:44 --> Helper loaded: url_helper
INFO - 2023-11-13 08:23:44 --> Helper loaded: form_helper
INFO - 2023-11-13 08:23:44 --> Helper loaded: file_helper
INFO - 2023-11-13 08:23:44 --> Database Driver Class Initialized
DEBUG - 2023-11-13 08:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-13 08:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-13 08:23:44 --> Form Validation Class Initialized
INFO - 2023-11-13 08:23:44 --> Upload Class Initialized
INFO - 2023-11-13 08:23:44 --> Model "M_auth" initialized
INFO - 2023-11-13 08:23:44 --> Model "M_user" initialized
INFO - 2023-11-13 08:23:44 --> Model "M_produk" initialized
INFO - 2023-11-13 08:23:44 --> Controller Class Initialized
INFO - 2023-11-13 08:23:44 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-13 08:23:44 --> Final output sent to browser
DEBUG - 2023-11-13 08:23:44 --> Total execution time: 0.0400
ERROR - 2023-11-13 11:17:06 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-13 11:17:06 --> Config Class Initialized
INFO - 2023-11-13 11:17:06 --> Hooks Class Initialized
DEBUG - 2023-11-13 11:17:06 --> UTF-8 Support Enabled
INFO - 2023-11-13 11:17:06 --> Utf8 Class Initialized
INFO - 2023-11-13 11:17:06 --> URI Class Initialized
DEBUG - 2023-11-13 11:17:06 --> No URI present. Default controller set.
INFO - 2023-11-13 11:17:06 --> Router Class Initialized
INFO - 2023-11-13 11:17:06 --> Output Class Initialized
INFO - 2023-11-13 11:17:06 --> Security Class Initialized
DEBUG - 2023-11-13 11:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 11:17:06 --> Input Class Initialized
INFO - 2023-11-13 11:17:06 --> Language Class Initialized
INFO - 2023-11-13 11:17:06 --> Loader Class Initialized
INFO - 2023-11-13 11:17:06 --> Helper loaded: url_helper
INFO - 2023-11-13 11:17:06 --> Helper loaded: form_helper
INFO - 2023-11-13 11:17:06 --> Helper loaded: file_helper
INFO - 2023-11-13 11:17:06 --> Database Driver Class Initialized
DEBUG - 2023-11-13 11:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-13 11:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-13 11:17:06 --> Form Validation Class Initialized
INFO - 2023-11-13 11:17:06 --> Upload Class Initialized
INFO - 2023-11-13 11:17:06 --> Model "M_auth" initialized
INFO - 2023-11-13 11:17:06 --> Model "M_user" initialized
INFO - 2023-11-13 11:17:06 --> Model "M_produk" initialized
INFO - 2023-11-13 11:17:06 --> Controller Class Initialized
INFO - 2023-11-13 11:17:06 --> Model "M_pelanggan" initialized
INFO - 2023-11-13 11:17:06 --> Model "M_produk" initialized
DEBUG - 2023-11-13 11:17:06 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-13 11:17:06 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-13 11:17:06 --> Model "M_transaksi" initialized
INFO - 2023-11-13 11:17:06 --> Model "M_bank" initialized
INFO - 2023-11-13 11:17:06 --> Model "M_pesan" initialized
DEBUG - 2023-11-13 11:17:06 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-13 11:17:06 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-13 11:17:06 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-13 11:17:06 --> Final output sent to browser
DEBUG - 2023-11-13 11:17:06 --> Total execution time: 0.0529
ERROR - 2023-11-13 11:37:05 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-13 11:37:05 --> Config Class Initialized
INFO - 2023-11-13 11:37:05 --> Hooks Class Initialized
DEBUG - 2023-11-13 11:37:05 --> UTF-8 Support Enabled
INFO - 2023-11-13 11:37:05 --> Utf8 Class Initialized
INFO - 2023-11-13 11:37:05 --> URI Class Initialized
DEBUG - 2023-11-13 11:37:05 --> No URI present. Default controller set.
INFO - 2023-11-13 11:37:05 --> Router Class Initialized
INFO - 2023-11-13 11:37:05 --> Output Class Initialized
INFO - 2023-11-13 11:37:05 --> Security Class Initialized
DEBUG - 2023-11-13 11:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 11:37:05 --> Input Class Initialized
INFO - 2023-11-13 11:37:05 --> Language Class Initialized
INFO - 2023-11-13 11:37:05 --> Loader Class Initialized
INFO - 2023-11-13 11:37:05 --> Helper loaded: url_helper
INFO - 2023-11-13 11:37:05 --> Helper loaded: form_helper
INFO - 2023-11-13 11:37:05 --> Helper loaded: file_helper
INFO - 2023-11-13 11:37:05 --> Database Driver Class Initialized
DEBUG - 2023-11-13 11:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-13 11:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-13 11:37:05 --> Form Validation Class Initialized
INFO - 2023-11-13 11:37:05 --> Upload Class Initialized
INFO - 2023-11-13 11:37:05 --> Model "M_auth" initialized
INFO - 2023-11-13 11:37:05 --> Model "M_user" initialized
INFO - 2023-11-13 11:37:05 --> Model "M_produk" initialized
INFO - 2023-11-13 11:37:05 --> Controller Class Initialized
INFO - 2023-11-13 11:37:05 --> Model "M_pelanggan" initialized
INFO - 2023-11-13 11:37:05 --> Model "M_produk" initialized
DEBUG - 2023-11-13 11:37:05 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-13 11:37:05 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-13 11:37:05 --> Model "M_transaksi" initialized
INFO - 2023-11-13 11:37:05 --> Model "M_bank" initialized
INFO - 2023-11-13 11:37:05 --> Model "M_pesan" initialized
DEBUG - 2023-11-13 11:37:05 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-13 11:37:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-13 11:37:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-13 11:37:05 --> Final output sent to browser
DEBUG - 2023-11-13 11:37:05 --> Total execution time: 0.0396
ERROR - 2023-11-13 12:22:43 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-13 12:22:43 --> Config Class Initialized
INFO - 2023-11-13 12:22:43 --> Hooks Class Initialized
DEBUG - 2023-11-13 12:22:43 --> UTF-8 Support Enabled
INFO - 2023-11-13 12:22:43 --> Utf8 Class Initialized
INFO - 2023-11-13 12:22:43 --> URI Class Initialized
DEBUG - 2023-11-13 12:22:43 --> No URI present. Default controller set.
INFO - 2023-11-13 12:22:43 --> Router Class Initialized
INFO - 2023-11-13 12:22:43 --> Output Class Initialized
INFO - 2023-11-13 12:22:43 --> Security Class Initialized
DEBUG - 2023-11-13 12:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 12:22:43 --> Input Class Initialized
INFO - 2023-11-13 12:22:43 --> Language Class Initialized
INFO - 2023-11-13 12:22:43 --> Loader Class Initialized
INFO - 2023-11-13 12:22:43 --> Helper loaded: url_helper
INFO - 2023-11-13 12:22:43 --> Helper loaded: form_helper
INFO - 2023-11-13 12:22:43 --> Helper loaded: file_helper
INFO - 2023-11-13 12:22:43 --> Database Driver Class Initialized
DEBUG - 2023-11-13 12:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-13 12:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-13 12:22:43 --> Form Validation Class Initialized
INFO - 2023-11-13 12:22:43 --> Upload Class Initialized
INFO - 2023-11-13 12:22:43 --> Model "M_auth" initialized
INFO - 2023-11-13 12:22:43 --> Model "M_user" initialized
INFO - 2023-11-13 12:22:43 --> Model "M_produk" initialized
INFO - 2023-11-13 12:22:43 --> Controller Class Initialized
INFO - 2023-11-13 12:22:43 --> Model "M_pelanggan" initialized
INFO - 2023-11-13 12:22:43 --> Model "M_produk" initialized
DEBUG - 2023-11-13 12:22:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-13 12:22:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-13 12:22:43 --> Model "M_transaksi" initialized
INFO - 2023-11-13 12:22:43 --> Model "M_bank" initialized
INFO - 2023-11-13 12:22:43 --> Model "M_pesan" initialized
DEBUG - 2023-11-13 12:22:43 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-13 12:22:43 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-13 12:22:43 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-13 12:22:43 --> Final output sent to browser
DEBUG - 2023-11-13 12:22:43 --> Total execution time: 0.0467
ERROR - 2023-11-13 12:27:29 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-13 12:27:29 --> Config Class Initialized
INFO - 2023-11-13 12:27:29 --> Hooks Class Initialized
DEBUG - 2023-11-13 12:27:29 --> UTF-8 Support Enabled
INFO - 2023-11-13 12:27:29 --> Utf8 Class Initialized
INFO - 2023-11-13 12:27:29 --> URI Class Initialized
INFO - 2023-11-13 12:27:29 --> Router Class Initialized
INFO - 2023-11-13 12:27:29 --> Output Class Initialized
INFO - 2023-11-13 12:27:29 --> Security Class Initialized
DEBUG - 2023-11-13 12:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 12:27:29 --> Input Class Initialized
INFO - 2023-11-13 12:27:29 --> Language Class Initialized
INFO - 2023-11-13 12:27:29 --> Loader Class Initialized
INFO - 2023-11-13 12:27:29 --> Helper loaded: url_helper
INFO - 2023-11-13 12:27:29 --> Helper loaded: form_helper
INFO - 2023-11-13 12:27:29 --> Helper loaded: file_helper
INFO - 2023-11-13 12:27:29 --> Database Driver Class Initialized
DEBUG - 2023-11-13 12:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-13 12:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-13 12:27:29 --> Form Validation Class Initialized
INFO - 2023-11-13 12:27:29 --> Upload Class Initialized
INFO - 2023-11-13 12:27:29 --> Model "M_auth" initialized
INFO - 2023-11-13 12:27:29 --> Model "M_user" initialized
INFO - 2023-11-13 12:27:29 --> Model "M_produk" initialized
INFO - 2023-11-13 12:27:29 --> Controller Class Initialized
INFO - 2023-11-13 12:27:29 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-13 12:27:29 --> Final output sent to browser
DEBUG - 2023-11-13 12:27:29 --> Total execution time: 0.0046
ERROR - 2023-11-13 12:27:37 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-13 12:27:37 --> Config Class Initialized
INFO - 2023-11-13 12:27:37 --> Hooks Class Initialized
DEBUG - 2023-11-13 12:27:37 --> UTF-8 Support Enabled
INFO - 2023-11-13 12:27:37 --> Utf8 Class Initialized
INFO - 2023-11-13 12:27:37 --> URI Class Initialized
INFO - 2023-11-13 12:27:37 --> Router Class Initialized
INFO - 2023-11-13 12:27:37 --> Output Class Initialized
INFO - 2023-11-13 12:27:37 --> Security Class Initialized
DEBUG - 2023-11-13 12:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 12:27:37 --> Input Class Initialized
INFO - 2023-11-13 12:27:37 --> Language Class Initialized
INFO - 2023-11-13 12:27:37 --> Loader Class Initialized
INFO - 2023-11-13 12:27:37 --> Helper loaded: url_helper
INFO - 2023-11-13 12:27:37 --> Helper loaded: form_helper
INFO - 2023-11-13 12:27:37 --> Helper loaded: file_helper
INFO - 2023-11-13 12:27:37 --> Database Driver Class Initialized
DEBUG - 2023-11-13 12:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-13 12:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-13 12:27:37 --> Form Validation Class Initialized
INFO - 2023-11-13 12:27:37 --> Upload Class Initialized
INFO - 2023-11-13 12:27:37 --> Model "M_auth" initialized
INFO - 2023-11-13 12:27:37 --> Model "M_user" initialized
INFO - 2023-11-13 12:27:37 --> Model "M_produk" initialized
INFO - 2023-11-13 12:27:37 --> Controller Class Initialized
INFO - 2023-11-13 12:27:37 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-13 12:27:37 --> Final output sent to browser
DEBUG - 2023-11-13 12:27:37 --> Total execution time: 0.0025
ERROR - 2023-11-13 15:16:58 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-13 15:16:58 --> Config Class Initialized
INFO - 2023-11-13 15:16:58 --> Hooks Class Initialized
DEBUG - 2023-11-13 15:16:58 --> UTF-8 Support Enabled
INFO - 2023-11-13 15:16:58 --> Utf8 Class Initialized
INFO - 2023-11-13 15:16:58 --> URI Class Initialized
INFO - 2023-11-13 15:16:58 --> Router Class Initialized
INFO - 2023-11-13 15:16:58 --> Output Class Initialized
INFO - 2023-11-13 15:16:58 --> Security Class Initialized
DEBUG - 2023-11-13 15:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 15:16:58 --> Input Class Initialized
INFO - 2023-11-13 15:16:58 --> Language Class Initialized
INFO - 2023-11-13 15:16:58 --> Loader Class Initialized
INFO - 2023-11-13 15:16:58 --> Helper loaded: url_helper
INFO - 2023-11-13 15:16:58 --> Helper loaded: form_helper
INFO - 2023-11-13 15:16:58 --> Helper loaded: file_helper
INFO - 2023-11-13 15:16:58 --> Database Driver Class Initialized
DEBUG - 2023-11-13 15:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-13 15:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-13 15:16:58 --> Form Validation Class Initialized
INFO - 2023-11-13 15:16:58 --> Upload Class Initialized
INFO - 2023-11-13 15:16:58 --> Model "M_auth" initialized
INFO - 2023-11-13 15:16:58 --> Model "M_user" initialized
INFO - 2023-11-13 15:16:58 --> Model "M_produk" initialized
INFO - 2023-11-13 15:16:58 --> Controller Class Initialized
INFO - 2023-11-13 15:16:58 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-13 15:16:58 --> Final output sent to browser
DEBUG - 2023-11-13 15:16:58 --> Total execution time: 0.0342
ERROR - 2023-11-13 15:28:04 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-13 15:28:04 --> Config Class Initialized
INFO - 2023-11-13 15:28:04 --> Hooks Class Initialized
DEBUG - 2023-11-13 15:28:04 --> UTF-8 Support Enabled
INFO - 2023-11-13 15:28:04 --> Utf8 Class Initialized
INFO - 2023-11-13 15:28:04 --> URI Class Initialized
INFO - 2023-11-13 15:28:04 --> Router Class Initialized
INFO - 2023-11-13 15:28:04 --> Output Class Initialized
INFO - 2023-11-13 15:28:04 --> Security Class Initialized
DEBUG - 2023-11-13 15:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 15:28:04 --> Input Class Initialized
INFO - 2023-11-13 15:28:04 --> Language Class Initialized
INFO - 2023-11-13 15:28:04 --> Loader Class Initialized
INFO - 2023-11-13 15:28:04 --> Helper loaded: url_helper
INFO - 2023-11-13 15:28:04 --> Helper loaded: form_helper
INFO - 2023-11-13 15:28:04 --> Helper loaded: file_helper
INFO - 2023-11-13 15:28:04 --> Database Driver Class Initialized
DEBUG - 2023-11-13 15:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-13 15:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-13 15:28:04 --> Form Validation Class Initialized
INFO - 2023-11-13 15:28:04 --> Upload Class Initialized
INFO - 2023-11-13 15:28:04 --> Model "M_auth" initialized
INFO - 2023-11-13 15:28:04 --> Model "M_user" initialized
INFO - 2023-11-13 15:28:04 --> Model "M_produk" initialized
INFO - 2023-11-13 15:28:04 --> Controller Class Initialized
INFO - 2023-11-13 15:28:04 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-13 15:28:04 --> Final output sent to browser
DEBUG - 2023-11-13 15:28:04 --> Total execution time: 0.0285
ERROR - 2023-11-13 15:28:04 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-13 15:28:04 --> Config Class Initialized
INFO - 2023-11-13 15:28:04 --> Hooks Class Initialized
DEBUG - 2023-11-13 15:28:04 --> UTF-8 Support Enabled
INFO - 2023-11-13 15:28:04 --> Utf8 Class Initialized
INFO - 2023-11-13 15:28:04 --> URI Class Initialized
DEBUG - 2023-11-13 15:28:04 --> No URI present. Default controller set.
INFO - 2023-11-13 15:28:04 --> Router Class Initialized
INFO - 2023-11-13 15:28:04 --> Output Class Initialized
INFO - 2023-11-13 15:28:04 --> Security Class Initialized
DEBUG - 2023-11-13 15:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 15:28:04 --> Input Class Initialized
INFO - 2023-11-13 15:28:04 --> Language Class Initialized
INFO - 2023-11-13 15:28:04 --> Loader Class Initialized
INFO - 2023-11-13 15:28:04 --> Helper loaded: url_helper
INFO - 2023-11-13 15:28:04 --> Helper loaded: form_helper
INFO - 2023-11-13 15:28:04 --> Helper loaded: file_helper
INFO - 2023-11-13 15:28:04 --> Database Driver Class Initialized
DEBUG - 2023-11-13 15:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-13 15:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-13 15:28:04 --> Form Validation Class Initialized
INFO - 2023-11-13 15:28:04 --> Upload Class Initialized
INFO - 2023-11-13 15:28:04 --> Model "M_auth" initialized
INFO - 2023-11-13 15:28:04 --> Model "M_user" initialized
INFO - 2023-11-13 15:28:04 --> Model "M_produk" initialized
INFO - 2023-11-13 15:28:04 --> Controller Class Initialized
INFO - 2023-11-13 15:28:04 --> Model "M_pelanggan" initialized
INFO - 2023-11-13 15:28:04 --> Model "M_produk" initialized
DEBUG - 2023-11-13 15:28:04 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-13 15:28:04 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-13 15:28:04 --> Model "M_transaksi" initialized
INFO - 2023-11-13 15:28:04 --> Model "M_bank" initialized
INFO - 2023-11-13 15:28:04 --> Model "M_pesan" initialized
DEBUG - 2023-11-13 15:28:04 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-13 15:28:04 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-13 15:28:04 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-13 15:28:04 --> Final output sent to browser
DEBUG - 2023-11-13 15:28:04 --> Total execution time: 0.0138
ERROR - 2023-11-13 16:10:38 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-13 16:10:38 --> Config Class Initialized
INFO - 2023-11-13 16:10:38 --> Hooks Class Initialized
DEBUG - 2023-11-13 16:10:38 --> UTF-8 Support Enabled
INFO - 2023-11-13 16:10:38 --> Utf8 Class Initialized
INFO - 2023-11-13 16:10:38 --> URI Class Initialized
DEBUG - 2023-11-13 16:10:38 --> No URI present. Default controller set.
INFO - 2023-11-13 16:10:38 --> Router Class Initialized
INFO - 2023-11-13 16:10:38 --> Output Class Initialized
INFO - 2023-11-13 16:10:38 --> Security Class Initialized
DEBUG - 2023-11-13 16:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 16:10:38 --> Input Class Initialized
INFO - 2023-11-13 16:10:38 --> Language Class Initialized
INFO - 2023-11-13 16:10:38 --> Loader Class Initialized
INFO - 2023-11-13 16:10:38 --> Helper loaded: url_helper
INFO - 2023-11-13 16:10:38 --> Helper loaded: form_helper
INFO - 2023-11-13 16:10:38 --> Helper loaded: file_helper
INFO - 2023-11-13 16:10:38 --> Database Driver Class Initialized
DEBUG - 2023-11-13 16:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-13 16:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-13 16:10:38 --> Form Validation Class Initialized
INFO - 2023-11-13 16:10:38 --> Upload Class Initialized
INFO - 2023-11-13 16:10:38 --> Model "M_auth" initialized
INFO - 2023-11-13 16:10:38 --> Model "M_user" initialized
INFO - 2023-11-13 16:10:38 --> Model "M_produk" initialized
INFO - 2023-11-13 16:10:38 --> Controller Class Initialized
INFO - 2023-11-13 16:10:38 --> Model "M_pelanggan" initialized
INFO - 2023-11-13 16:10:38 --> Model "M_produk" initialized
DEBUG - 2023-11-13 16:10:38 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-13 16:10:38 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-13 16:10:38 --> Model "M_transaksi" initialized
INFO - 2023-11-13 16:10:38 --> Model "M_bank" initialized
INFO - 2023-11-13 16:10:38 --> Model "M_pesan" initialized
DEBUG - 2023-11-13 16:10:38 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-13 16:10:38 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-13 16:10:38 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-13 16:10:38 --> Final output sent to browser
DEBUG - 2023-11-13 16:10:38 --> Total execution time: 0.0406
ERROR - 2023-11-13 18:34:16 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-13 18:34:16 --> Config Class Initialized
INFO - 2023-11-13 18:34:16 --> Hooks Class Initialized
DEBUG - 2023-11-13 18:34:16 --> UTF-8 Support Enabled
INFO - 2023-11-13 18:34:16 --> Utf8 Class Initialized
INFO - 2023-11-13 18:34:16 --> URI Class Initialized
DEBUG - 2023-11-13 18:34:16 --> No URI present. Default controller set.
INFO - 2023-11-13 18:34:16 --> Router Class Initialized
INFO - 2023-11-13 18:34:16 --> Output Class Initialized
INFO - 2023-11-13 18:34:16 --> Security Class Initialized
DEBUG - 2023-11-13 18:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 18:34:16 --> Input Class Initialized
INFO - 2023-11-13 18:34:16 --> Language Class Initialized
INFO - 2023-11-13 18:34:16 --> Loader Class Initialized
INFO - 2023-11-13 18:34:16 --> Helper loaded: url_helper
INFO - 2023-11-13 18:34:16 --> Helper loaded: form_helper
INFO - 2023-11-13 18:34:16 --> Helper loaded: file_helper
INFO - 2023-11-13 18:34:17 --> Database Driver Class Initialized
DEBUG - 2023-11-13 18:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-13 18:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-13 18:34:17 --> Form Validation Class Initialized
INFO - 2023-11-13 18:34:17 --> Upload Class Initialized
INFO - 2023-11-13 18:34:17 --> Model "M_auth" initialized
INFO - 2023-11-13 18:34:17 --> Model "M_user" initialized
INFO - 2023-11-13 18:34:17 --> Model "M_produk" initialized
INFO - 2023-11-13 18:34:17 --> Controller Class Initialized
INFO - 2023-11-13 18:34:17 --> Model "M_pelanggan" initialized
INFO - 2023-11-13 18:34:17 --> Model "M_produk" initialized
DEBUG - 2023-11-13 18:34:17 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-13 18:34:17 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-13 18:34:17 --> Model "M_transaksi" initialized
INFO - 2023-11-13 18:34:17 --> Model "M_bank" initialized
INFO - 2023-11-13 18:34:17 --> Model "M_pesan" initialized
DEBUG - 2023-11-13 18:34:17 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-13 18:34:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-13 18:34:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-13 18:34:17 --> Final output sent to browser
DEBUG - 2023-11-13 18:34:17 --> Total execution time: 0.0461
ERROR - 2023-11-13 19:04:33 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-13 19:04:33 --> Config Class Initialized
INFO - 2023-11-13 19:04:33 --> Hooks Class Initialized
DEBUG - 2023-11-13 19:04:33 --> UTF-8 Support Enabled
INFO - 2023-11-13 19:04:33 --> Utf8 Class Initialized
INFO - 2023-11-13 19:04:33 --> URI Class Initialized
DEBUG - 2023-11-13 19:04:33 --> No URI present. Default controller set.
INFO - 2023-11-13 19:04:33 --> Router Class Initialized
INFO - 2023-11-13 19:04:33 --> Output Class Initialized
INFO - 2023-11-13 19:04:33 --> Security Class Initialized
DEBUG - 2023-11-13 19:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 19:04:33 --> Input Class Initialized
INFO - 2023-11-13 19:04:33 --> Language Class Initialized
INFO - 2023-11-13 19:04:33 --> Loader Class Initialized
INFO - 2023-11-13 19:04:33 --> Helper loaded: url_helper
INFO - 2023-11-13 19:04:33 --> Helper loaded: form_helper
INFO - 2023-11-13 19:04:33 --> Helper loaded: file_helper
INFO - 2023-11-13 19:04:34 --> Database Driver Class Initialized
DEBUG - 2023-11-13 19:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-13 19:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-13 19:04:34 --> Form Validation Class Initialized
INFO - 2023-11-13 19:04:34 --> Upload Class Initialized
INFO - 2023-11-13 19:04:34 --> Model "M_auth" initialized
INFO - 2023-11-13 19:04:34 --> Model "M_user" initialized
INFO - 2023-11-13 19:04:34 --> Model "M_produk" initialized
INFO - 2023-11-13 19:04:34 --> Controller Class Initialized
INFO - 2023-11-13 19:04:34 --> Model "M_pelanggan" initialized
INFO - 2023-11-13 19:04:34 --> Model "M_produk" initialized
DEBUG - 2023-11-13 19:04:34 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-13 19:04:34 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-13 19:04:34 --> Model "M_transaksi" initialized
INFO - 2023-11-13 19:04:34 --> Model "M_bank" initialized
INFO - 2023-11-13 19:04:34 --> Model "M_pesan" initialized
DEBUG - 2023-11-13 19:04:34 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-13 19:04:34 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-13 19:04:34 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-13 19:04:34 --> Final output sent to browser
DEBUG - 2023-11-13 19:04:34 --> Total execution time: 0.0319
ERROR - 2023-11-13 19:20:09 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-13 19:20:09 --> Config Class Initialized
INFO - 2023-11-13 19:20:09 --> Hooks Class Initialized
DEBUG - 2023-11-13 19:20:09 --> UTF-8 Support Enabled
INFO - 2023-11-13 19:20:09 --> Utf8 Class Initialized
INFO - 2023-11-13 19:20:09 --> URI Class Initialized
DEBUG - 2023-11-13 19:20:09 --> No URI present. Default controller set.
INFO - 2023-11-13 19:20:09 --> Router Class Initialized
INFO - 2023-11-13 19:20:09 --> Output Class Initialized
INFO - 2023-11-13 19:20:09 --> Security Class Initialized
DEBUG - 2023-11-13 19:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 19:20:09 --> Input Class Initialized
INFO - 2023-11-13 19:20:09 --> Language Class Initialized
INFO - 2023-11-13 19:20:09 --> Loader Class Initialized
INFO - 2023-11-13 19:20:09 --> Helper loaded: url_helper
INFO - 2023-11-13 19:20:09 --> Helper loaded: form_helper
INFO - 2023-11-13 19:20:09 --> Helper loaded: file_helper
INFO - 2023-11-13 19:20:09 --> Database Driver Class Initialized
DEBUG - 2023-11-13 19:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-13 19:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-13 19:20:09 --> Form Validation Class Initialized
INFO - 2023-11-13 19:20:09 --> Upload Class Initialized
INFO - 2023-11-13 19:20:09 --> Model "M_auth" initialized
INFO - 2023-11-13 19:20:09 --> Model "M_user" initialized
INFO - 2023-11-13 19:20:09 --> Model "M_produk" initialized
INFO - 2023-11-13 19:20:09 --> Controller Class Initialized
INFO - 2023-11-13 19:20:09 --> Model "M_pelanggan" initialized
INFO - 2023-11-13 19:20:09 --> Model "M_produk" initialized
DEBUG - 2023-11-13 19:20:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-13 19:20:09 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-13 19:20:09 --> Model "M_transaksi" initialized
INFO - 2023-11-13 19:20:09 --> Model "M_bank" initialized
INFO - 2023-11-13 19:20:09 --> Model "M_pesan" initialized
DEBUG - 2023-11-13 19:20:09 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-13 19:20:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-13 19:20:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-13 19:20:09 --> Final output sent to browser
DEBUG - 2023-11-13 19:20:09 --> Total execution time: 0.0363
ERROR - 2023-11-13 19:26:25 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-13 19:26:25 --> Config Class Initialized
INFO - 2023-11-13 19:26:25 --> Hooks Class Initialized
DEBUG - 2023-11-13 19:26:25 --> UTF-8 Support Enabled
INFO - 2023-11-13 19:26:25 --> Utf8 Class Initialized
INFO - 2023-11-13 19:26:25 --> URI Class Initialized
INFO - 2023-11-13 19:26:25 --> Router Class Initialized
INFO - 2023-11-13 19:26:25 --> Output Class Initialized
INFO - 2023-11-13 19:26:25 --> Security Class Initialized
DEBUG - 2023-11-13 19:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 19:26:25 --> Input Class Initialized
INFO - 2023-11-13 19:26:25 --> Language Class Initialized
INFO - 2023-11-13 19:26:25 --> Loader Class Initialized
INFO - 2023-11-13 19:26:25 --> Helper loaded: url_helper
INFO - 2023-11-13 19:26:25 --> Helper loaded: form_helper
INFO - 2023-11-13 19:26:25 --> Helper loaded: file_helper
INFO - 2023-11-13 19:26:25 --> Database Driver Class Initialized
DEBUG - 2023-11-13 19:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-13 19:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-13 19:26:25 --> Form Validation Class Initialized
INFO - 2023-11-13 19:26:25 --> Upload Class Initialized
INFO - 2023-11-13 19:26:25 --> Model "M_auth" initialized
INFO - 2023-11-13 19:26:25 --> Model "M_user" initialized
INFO - 2023-11-13 19:26:25 --> Model "M_produk" initialized
INFO - 2023-11-13 19:26:25 --> Controller Class Initialized
INFO - 2023-11-13 19:26:25 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-13 19:26:25 --> Final output sent to browser
DEBUG - 2023-11-13 19:26:25 --> Total execution time: 0.0264
ERROR - 2023-11-13 19:26:26 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-13 19:26:26 --> Config Class Initialized
INFO - 2023-11-13 19:26:26 --> Hooks Class Initialized
DEBUG - 2023-11-13 19:26:26 --> UTF-8 Support Enabled
INFO - 2023-11-13 19:26:26 --> Utf8 Class Initialized
INFO - 2023-11-13 19:26:26 --> URI Class Initialized
DEBUG - 2023-11-13 19:26:26 --> No URI present. Default controller set.
INFO - 2023-11-13 19:26:26 --> Router Class Initialized
INFO - 2023-11-13 19:26:26 --> Output Class Initialized
INFO - 2023-11-13 19:26:26 --> Security Class Initialized
DEBUG - 2023-11-13 19:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 19:26:26 --> Input Class Initialized
INFO - 2023-11-13 19:26:26 --> Language Class Initialized
INFO - 2023-11-13 19:26:26 --> Loader Class Initialized
INFO - 2023-11-13 19:26:26 --> Helper loaded: url_helper
INFO - 2023-11-13 19:26:26 --> Helper loaded: form_helper
INFO - 2023-11-13 19:26:26 --> Helper loaded: file_helper
INFO - 2023-11-13 19:26:26 --> Database Driver Class Initialized
DEBUG - 2023-11-13 19:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-13 19:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-13 19:26:26 --> Form Validation Class Initialized
INFO - 2023-11-13 19:26:26 --> Upload Class Initialized
INFO - 2023-11-13 19:26:26 --> Model "M_auth" initialized
INFO - 2023-11-13 19:26:26 --> Model "M_user" initialized
INFO - 2023-11-13 19:26:26 --> Model "M_produk" initialized
INFO - 2023-11-13 19:26:26 --> Controller Class Initialized
INFO - 2023-11-13 19:26:26 --> Model "M_pelanggan" initialized
INFO - 2023-11-13 19:26:26 --> Model "M_produk" initialized
DEBUG - 2023-11-13 19:26:26 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-13 19:26:26 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-13 19:26:26 --> Model "M_transaksi" initialized
INFO - 2023-11-13 19:26:26 --> Model "M_bank" initialized
INFO - 2023-11-13 19:26:26 --> Model "M_pesan" initialized
DEBUG - 2023-11-13 19:26:26 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-13 19:26:26 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-13 19:26:26 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-13 19:26:26 --> Final output sent to browser
DEBUG - 2023-11-13 19:26:26 --> Total execution time: 0.0080
ERROR - 2023-11-13 20:34:12 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-13 20:34:12 --> Config Class Initialized
INFO - 2023-11-13 20:34:12 --> Hooks Class Initialized
DEBUG - 2023-11-13 20:34:12 --> UTF-8 Support Enabled
INFO - 2023-11-13 20:34:12 --> Utf8 Class Initialized
INFO - 2023-11-13 20:34:12 --> URI Class Initialized
INFO - 2023-11-13 20:34:12 --> Router Class Initialized
INFO - 2023-11-13 20:34:12 --> Output Class Initialized
INFO - 2023-11-13 20:34:12 --> Security Class Initialized
DEBUG - 2023-11-13 20:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 20:34:12 --> Input Class Initialized
INFO - 2023-11-13 20:34:12 --> Language Class Initialized
INFO - 2023-11-13 20:34:12 --> Loader Class Initialized
INFO - 2023-11-13 20:34:12 --> Helper loaded: url_helper
INFO - 2023-11-13 20:34:12 --> Helper loaded: form_helper
INFO - 2023-11-13 20:34:12 --> Helper loaded: file_helper
INFO - 2023-11-13 20:34:12 --> Database Driver Class Initialized
DEBUG - 2023-11-13 20:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-13 20:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-13 20:34:12 --> Form Validation Class Initialized
INFO - 2023-11-13 20:34:12 --> Upload Class Initialized
INFO - 2023-11-13 20:34:12 --> Model "M_auth" initialized
INFO - 2023-11-13 20:34:12 --> Model "M_user" initialized
INFO - 2023-11-13 20:34:12 --> Model "M_produk" initialized
INFO - 2023-11-13 20:34:12 --> Controller Class Initialized
INFO - 2023-11-13 20:34:12 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-13 20:34:12 --> Final output sent to browser
DEBUG - 2023-11-13 20:34:12 --> Total execution time: 0.0289
ERROR - 2023-11-13 20:34:13 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-13 20:34:13 --> Config Class Initialized
INFO - 2023-11-13 20:34:13 --> Hooks Class Initialized
DEBUG - 2023-11-13 20:34:13 --> UTF-8 Support Enabled
INFO - 2023-11-13 20:34:13 --> Utf8 Class Initialized
INFO - 2023-11-13 20:34:13 --> URI Class Initialized
DEBUG - 2023-11-13 20:34:13 --> No URI present. Default controller set.
INFO - 2023-11-13 20:34:13 --> Router Class Initialized
INFO - 2023-11-13 20:34:13 --> Output Class Initialized
INFO - 2023-11-13 20:34:13 --> Security Class Initialized
DEBUG - 2023-11-13 20:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 20:34:13 --> Input Class Initialized
INFO - 2023-11-13 20:34:13 --> Language Class Initialized
INFO - 2023-11-13 20:34:13 --> Loader Class Initialized
INFO - 2023-11-13 20:34:13 --> Helper loaded: url_helper
INFO - 2023-11-13 20:34:13 --> Helper loaded: form_helper
INFO - 2023-11-13 20:34:13 --> Helper loaded: file_helper
INFO - 2023-11-13 20:34:13 --> Database Driver Class Initialized
DEBUG - 2023-11-13 20:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-13 20:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-13 20:34:13 --> Form Validation Class Initialized
INFO - 2023-11-13 20:34:13 --> Upload Class Initialized
INFO - 2023-11-13 20:34:13 --> Model "M_auth" initialized
INFO - 2023-11-13 20:34:13 --> Model "M_user" initialized
INFO - 2023-11-13 20:34:13 --> Model "M_produk" initialized
INFO - 2023-11-13 20:34:13 --> Controller Class Initialized
INFO - 2023-11-13 20:34:13 --> Model "M_pelanggan" initialized
INFO - 2023-11-13 20:34:13 --> Model "M_produk" initialized
DEBUG - 2023-11-13 20:34:13 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-13 20:34:13 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-13 20:34:13 --> Model "M_transaksi" initialized
INFO - 2023-11-13 20:34:13 --> Model "M_bank" initialized
INFO - 2023-11-13 20:34:13 --> Model "M_pesan" initialized
DEBUG - 2023-11-13 20:34:13 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-13 20:34:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-13 20:34:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-13 20:34:13 --> Final output sent to browser
DEBUG - 2023-11-13 20:34:13 --> Total execution time: 0.0086
ERROR - 2023-11-13 21:32:21 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-13 21:32:21 --> Config Class Initialized
INFO - 2023-11-13 21:32:21 --> Hooks Class Initialized
DEBUG - 2023-11-13 21:32:21 --> UTF-8 Support Enabled
INFO - 2023-11-13 21:32:21 --> Utf8 Class Initialized
INFO - 2023-11-13 21:32:21 --> URI Class Initialized
DEBUG - 2023-11-13 21:32:21 --> No URI present. Default controller set.
INFO - 2023-11-13 21:32:21 --> Router Class Initialized
INFO - 2023-11-13 21:32:21 --> Output Class Initialized
INFO - 2023-11-13 21:32:21 --> Security Class Initialized
DEBUG - 2023-11-13 21:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-13 21:32:21 --> Input Class Initialized
INFO - 2023-11-13 21:32:21 --> Language Class Initialized
INFO - 2023-11-13 21:32:21 --> Loader Class Initialized
INFO - 2023-11-13 21:32:21 --> Helper loaded: url_helper
INFO - 2023-11-13 21:32:21 --> Helper loaded: form_helper
INFO - 2023-11-13 21:32:21 --> Helper loaded: file_helper
INFO - 2023-11-13 21:32:21 --> Database Driver Class Initialized
DEBUG - 2023-11-13 21:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-13 21:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-13 21:32:21 --> Form Validation Class Initialized
INFO - 2023-11-13 21:32:21 --> Upload Class Initialized
INFO - 2023-11-13 21:32:21 --> Model "M_auth" initialized
INFO - 2023-11-13 21:32:21 --> Model "M_user" initialized
INFO - 2023-11-13 21:32:21 --> Model "M_produk" initialized
INFO - 2023-11-13 21:32:21 --> Controller Class Initialized
INFO - 2023-11-13 21:32:21 --> Model "M_pelanggan" initialized
INFO - 2023-11-13 21:32:21 --> Model "M_produk" initialized
DEBUG - 2023-11-13 21:32:21 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-13 21:32:21 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-13 21:32:21 --> Model "M_transaksi" initialized
INFO - 2023-11-13 21:32:21 --> Model "M_bank" initialized
INFO - 2023-11-13 21:32:21 --> Model "M_pesan" initialized
DEBUG - 2023-11-13 21:32:21 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-13 21:32:21 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-13 21:32:21 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-13 21:32:21 --> Final output sent to browser
DEBUG - 2023-11-13 21:32:21 --> Total execution time: 0.0420
