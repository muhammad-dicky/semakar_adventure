<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-01 01:19:24 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-01 01:19:24 --> Config Class Initialized
INFO - 2023-12-01 01:19:24 --> Hooks Class Initialized
DEBUG - 2023-12-01 01:19:24 --> UTF-8 Support Enabled
INFO - 2023-12-01 01:19:24 --> Utf8 Class Initialized
INFO - 2023-12-01 01:19:24 --> URI Class Initialized
DEBUG - 2023-12-01 01:19:24 --> No URI present. Default controller set.
INFO - 2023-12-01 01:19:24 --> Router Class Initialized
INFO - 2023-12-01 01:19:24 --> Output Class Initialized
INFO - 2023-12-01 01:19:24 --> Security Class Initialized
DEBUG - 2023-12-01 01:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-01 01:19:24 --> Input Class Initialized
INFO - 2023-12-01 01:19:24 --> Language Class Initialized
INFO - 2023-12-01 01:19:24 --> Loader Class Initialized
INFO - 2023-12-01 01:19:24 --> Helper loaded: url_helper
INFO - 2023-12-01 01:19:24 --> Helper loaded: form_helper
INFO - 2023-12-01 01:19:24 --> Helper loaded: file_helper
INFO - 2023-12-01 01:19:24 --> Database Driver Class Initialized
DEBUG - 2023-12-01 01:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-01 01:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-01 01:19:24 --> Form Validation Class Initialized
INFO - 2023-12-01 01:19:24 --> Upload Class Initialized
INFO - 2023-12-01 01:19:24 --> Model "M_auth" initialized
INFO - 2023-12-01 01:19:24 --> Model "M_user" initialized
INFO - 2023-12-01 01:19:24 --> Model "M_produk" initialized
INFO - 2023-12-01 01:19:24 --> Controller Class Initialized
INFO - 2023-12-01 01:19:24 --> Model "M_pelanggan" initialized
INFO - 2023-12-01 01:19:24 --> Model "M_produk" initialized
DEBUG - 2023-12-01 01:19:24 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-01 01:19:24 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-01 01:19:24 --> Model "M_transaksi" initialized
INFO - 2023-12-01 01:19:24 --> Model "M_bank" initialized
INFO - 2023-12-01 01:19:24 --> Model "M_pesan" initialized
DEBUG - 2023-12-01 01:19:24 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-01 01:19:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-01 01:19:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-01 01:19:24 --> Final output sent to browser
DEBUG - 2023-12-01 01:19:24 --> Total execution time: 0.0318
ERROR - 2023-12-01 05:39:37 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-01 05:39:37 --> Config Class Initialized
INFO - 2023-12-01 05:39:37 --> Hooks Class Initialized
DEBUG - 2023-12-01 05:39:37 --> UTF-8 Support Enabled
INFO - 2023-12-01 05:39:37 --> Utf8 Class Initialized
INFO - 2023-12-01 05:39:37 --> URI Class Initialized
DEBUG - 2023-12-01 05:39:37 --> No URI present. Default controller set.
INFO - 2023-12-01 05:39:37 --> Router Class Initialized
INFO - 2023-12-01 05:39:37 --> Output Class Initialized
INFO - 2023-12-01 05:39:37 --> Security Class Initialized
DEBUG - 2023-12-01 05:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-01 05:39:37 --> Input Class Initialized
INFO - 2023-12-01 05:39:37 --> Language Class Initialized
INFO - 2023-12-01 05:39:37 --> Loader Class Initialized
INFO - 2023-12-01 05:39:37 --> Helper loaded: url_helper
INFO - 2023-12-01 05:39:37 --> Helper loaded: form_helper
INFO - 2023-12-01 05:39:37 --> Helper loaded: file_helper
INFO - 2023-12-01 05:39:37 --> Database Driver Class Initialized
DEBUG - 2023-12-01 05:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-01 05:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-01 05:39:37 --> Form Validation Class Initialized
INFO - 2023-12-01 05:39:37 --> Upload Class Initialized
INFO - 2023-12-01 05:39:37 --> Model "M_auth" initialized
INFO - 2023-12-01 05:39:37 --> Model "M_user" initialized
INFO - 2023-12-01 05:39:37 --> Model "M_produk" initialized
INFO - 2023-12-01 05:39:37 --> Controller Class Initialized
INFO - 2023-12-01 05:39:37 --> Model "M_pelanggan" initialized
INFO - 2023-12-01 05:39:37 --> Model "M_produk" initialized
DEBUG - 2023-12-01 05:39:37 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-01 05:39:37 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-01 05:39:37 --> Model "M_transaksi" initialized
INFO - 2023-12-01 05:39:37 --> Model "M_bank" initialized
INFO - 2023-12-01 05:39:37 --> Model "M_pesan" initialized
DEBUG - 2023-12-01 05:39:37 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-01 05:39:37 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-01 05:39:37 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-01 05:39:37 --> Final output sent to browser
DEBUG - 2023-12-01 05:39:37 --> Total execution time: 0.0401
ERROR - 2023-12-01 08:15:01 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-01 08:15:01 --> Config Class Initialized
INFO - 2023-12-01 08:15:01 --> Hooks Class Initialized
DEBUG - 2023-12-01 08:15:01 --> UTF-8 Support Enabled
INFO - 2023-12-01 08:15:01 --> Utf8 Class Initialized
INFO - 2023-12-01 08:15:01 --> URI Class Initialized
INFO - 2023-12-01 08:15:01 --> Router Class Initialized
INFO - 2023-12-01 08:15:01 --> Output Class Initialized
INFO - 2023-12-01 08:15:01 --> Security Class Initialized
DEBUG - 2023-12-01 08:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-01 08:15:01 --> Input Class Initialized
INFO - 2023-12-01 08:15:01 --> Language Class Initialized
INFO - 2023-12-01 08:15:01 --> Loader Class Initialized
INFO - 2023-12-01 08:15:01 --> Helper loaded: url_helper
INFO - 2023-12-01 08:15:01 --> Helper loaded: form_helper
INFO - 2023-12-01 08:15:01 --> Helper loaded: file_helper
INFO - 2023-12-01 08:15:01 --> Database Driver Class Initialized
DEBUG - 2023-12-01 08:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-01 08:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-01 08:15:01 --> Form Validation Class Initialized
INFO - 2023-12-01 08:15:01 --> Upload Class Initialized
INFO - 2023-12-01 08:15:01 --> Model "M_auth" initialized
INFO - 2023-12-01 08:15:01 --> Model "M_user" initialized
INFO - 2023-12-01 08:15:01 --> Model "M_produk" initialized
INFO - 2023-12-01 08:15:01 --> Controller Class Initialized
INFO - 2023-12-01 08:15:01 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-01 08:15:01 --> Final output sent to browser
DEBUG - 2023-12-01 08:15:01 --> Total execution time: 0.0316
ERROR - 2023-12-01 08:15:10 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-01 08:15:10 --> Config Class Initialized
INFO - 2023-12-01 08:15:10 --> Hooks Class Initialized
DEBUG - 2023-12-01 08:15:10 --> UTF-8 Support Enabled
INFO - 2023-12-01 08:15:10 --> Utf8 Class Initialized
INFO - 2023-12-01 08:15:10 --> URI Class Initialized
INFO - 2023-12-01 08:15:10 --> Router Class Initialized
INFO - 2023-12-01 08:15:10 --> Output Class Initialized
INFO - 2023-12-01 08:15:10 --> Security Class Initialized
DEBUG - 2023-12-01 08:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-01 08:15:10 --> Input Class Initialized
INFO - 2023-12-01 08:15:10 --> Language Class Initialized
INFO - 2023-12-01 08:15:10 --> Loader Class Initialized
INFO - 2023-12-01 08:15:10 --> Helper loaded: url_helper
INFO - 2023-12-01 08:15:10 --> Helper loaded: form_helper
INFO - 2023-12-01 08:15:10 --> Helper loaded: file_helper
INFO - 2023-12-01 08:15:10 --> Database Driver Class Initialized
DEBUG - 2023-12-01 08:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-01 08:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-01 08:15:10 --> Form Validation Class Initialized
INFO - 2023-12-01 08:15:10 --> Upload Class Initialized
INFO - 2023-12-01 08:15:10 --> Model "M_auth" initialized
INFO - 2023-12-01 08:15:10 --> Model "M_user" initialized
INFO - 2023-12-01 08:15:10 --> Model "M_produk" initialized
INFO - 2023-12-01 08:15:10 --> Controller Class Initialized
INFO - 2023-12-01 08:15:10 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-01 08:15:10 --> Final output sent to browser
DEBUG - 2023-12-01 08:15:10 --> Total execution time: 0.0028
ERROR - 2023-12-01 08:15:10 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-01 08:15:10 --> Config Class Initialized
INFO - 2023-12-01 08:15:10 --> Hooks Class Initialized
DEBUG - 2023-12-01 08:15:10 --> UTF-8 Support Enabled
INFO - 2023-12-01 08:15:10 --> Utf8 Class Initialized
INFO - 2023-12-01 08:15:10 --> URI Class Initialized
INFO - 2023-12-01 08:15:10 --> Router Class Initialized
INFO - 2023-12-01 08:15:10 --> Output Class Initialized
INFO - 2023-12-01 08:15:10 --> Security Class Initialized
DEBUG - 2023-12-01 08:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-01 08:15:10 --> Input Class Initialized
INFO - 2023-12-01 08:15:10 --> Language Class Initialized
INFO - 2023-12-01 08:15:10 --> Loader Class Initialized
INFO - 2023-12-01 08:15:10 --> Helper loaded: url_helper
INFO - 2023-12-01 08:15:10 --> Helper loaded: form_helper
INFO - 2023-12-01 08:15:10 --> Helper loaded: file_helper
INFO - 2023-12-01 08:15:10 --> Database Driver Class Initialized
DEBUG - 2023-12-01 08:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-01 08:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-01 08:15:10 --> Form Validation Class Initialized
INFO - 2023-12-01 08:15:10 --> Upload Class Initialized
INFO - 2023-12-01 08:15:10 --> Model "M_auth" initialized
INFO - 2023-12-01 08:15:10 --> Model "M_user" initialized
INFO - 2023-12-01 08:15:10 --> Model "M_produk" initialized
INFO - 2023-12-01 08:15:10 --> Controller Class Initialized
INFO - 2023-12-01 08:15:10 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-01 08:15:10 --> Final output sent to browser
DEBUG - 2023-12-01 08:15:10 --> Total execution time: 0.0045
ERROR - 2023-12-01 12:35:13 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-01 12:35:13 --> Config Class Initialized
INFO - 2023-12-01 12:35:13 --> Hooks Class Initialized
DEBUG - 2023-12-01 12:35:13 --> UTF-8 Support Enabled
INFO - 2023-12-01 12:35:13 --> Utf8 Class Initialized
INFO - 2023-12-01 12:35:13 --> URI Class Initialized
INFO - 2023-12-01 12:35:13 --> Router Class Initialized
INFO - 2023-12-01 12:35:13 --> Output Class Initialized
INFO - 2023-12-01 12:35:13 --> Security Class Initialized
DEBUG - 2023-12-01 12:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-01 12:35:13 --> Input Class Initialized
INFO - 2023-12-01 12:35:13 --> Language Class Initialized
INFO - 2023-12-01 12:35:13 --> Loader Class Initialized
INFO - 2023-12-01 12:35:13 --> Helper loaded: url_helper
INFO - 2023-12-01 12:35:13 --> Helper loaded: form_helper
INFO - 2023-12-01 12:35:13 --> Helper loaded: file_helper
INFO - 2023-12-01 12:35:13 --> Database Driver Class Initialized
DEBUG - 2023-12-01 12:35:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-01 12:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-01 12:35:13 --> Form Validation Class Initialized
INFO - 2023-12-01 12:35:13 --> Upload Class Initialized
INFO - 2023-12-01 12:35:13 --> Model "M_auth" initialized
INFO - 2023-12-01 12:35:13 --> Model "M_user" initialized
INFO - 2023-12-01 12:35:13 --> Model "M_produk" initialized
INFO - 2023-12-01 12:35:13 --> Controller Class Initialized
INFO - 2023-12-01 12:35:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-01 12:35:13 --> Final output sent to browser
DEBUG - 2023-12-01 12:35:13 --> Total execution time: 0.0258
ERROR - 2023-12-01 12:35:13 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-01 12:35:13 --> Config Class Initialized
INFO - 2023-12-01 12:35:13 --> Hooks Class Initialized
DEBUG - 2023-12-01 12:35:13 --> UTF-8 Support Enabled
INFO - 2023-12-01 12:35:13 --> Utf8 Class Initialized
INFO - 2023-12-01 12:35:13 --> URI Class Initialized
INFO - 2023-12-01 12:35:13 --> Router Class Initialized
INFO - 2023-12-01 12:35:13 --> Output Class Initialized
INFO - 2023-12-01 12:35:13 --> Security Class Initialized
DEBUG - 2023-12-01 12:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-01 12:35:13 --> Input Class Initialized
INFO - 2023-12-01 12:35:13 --> Language Class Initialized
INFO - 2023-12-01 12:35:13 --> Loader Class Initialized
INFO - 2023-12-01 12:35:13 --> Helper loaded: url_helper
INFO - 2023-12-01 12:35:13 --> Helper loaded: form_helper
INFO - 2023-12-01 12:35:13 --> Helper loaded: file_helper
INFO - 2023-12-01 12:35:13 --> Database Driver Class Initialized
DEBUG - 2023-12-01 12:35:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-01 12:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-01 12:35:13 --> Form Validation Class Initialized
INFO - 2023-12-01 12:35:13 --> Upload Class Initialized
INFO - 2023-12-01 12:35:13 --> Model "M_auth" initialized
INFO - 2023-12-01 12:35:13 --> Model "M_user" initialized
INFO - 2023-12-01 12:35:13 --> Model "M_produk" initialized
INFO - 2023-12-01 12:35:13 --> Controller Class Initialized
INFO - 2023-12-01 12:35:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-01 12:35:13 --> Final output sent to browser
DEBUG - 2023-12-01 12:35:13 --> Total execution time: 0.0030
ERROR - 2023-12-01 13:13:01 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-01 13:13:01 --> Config Class Initialized
INFO - 2023-12-01 13:13:01 --> Hooks Class Initialized
DEBUG - 2023-12-01 13:13:01 --> UTF-8 Support Enabled
INFO - 2023-12-01 13:13:01 --> Utf8 Class Initialized
INFO - 2023-12-01 13:13:01 --> URI Class Initialized
DEBUG - 2023-12-01 13:13:01 --> No URI present. Default controller set.
INFO - 2023-12-01 13:13:01 --> Router Class Initialized
INFO - 2023-12-01 13:13:01 --> Output Class Initialized
INFO - 2023-12-01 13:13:01 --> Security Class Initialized
DEBUG - 2023-12-01 13:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-01 13:13:01 --> Input Class Initialized
INFO - 2023-12-01 13:13:01 --> Language Class Initialized
INFO - 2023-12-01 13:13:01 --> Loader Class Initialized
INFO - 2023-12-01 13:13:01 --> Helper loaded: url_helper
INFO - 2023-12-01 13:13:01 --> Helper loaded: form_helper
INFO - 2023-12-01 13:13:01 --> Helper loaded: file_helper
INFO - 2023-12-01 13:13:01 --> Database Driver Class Initialized
DEBUG - 2023-12-01 13:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-01 13:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-01 13:13:01 --> Form Validation Class Initialized
INFO - 2023-12-01 13:13:01 --> Upload Class Initialized
INFO - 2023-12-01 13:13:01 --> Model "M_auth" initialized
INFO - 2023-12-01 13:13:01 --> Model "M_user" initialized
INFO - 2023-12-01 13:13:01 --> Model "M_produk" initialized
INFO - 2023-12-01 13:13:01 --> Controller Class Initialized
INFO - 2023-12-01 13:13:01 --> Model "M_pelanggan" initialized
INFO - 2023-12-01 13:13:01 --> Model "M_produk" initialized
DEBUG - 2023-12-01 13:13:01 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-01 13:13:01 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-01 13:13:01 --> Model "M_transaksi" initialized
INFO - 2023-12-01 13:13:01 --> Model "M_bank" initialized
INFO - 2023-12-01 13:13:01 --> Model "M_pesan" initialized
DEBUG - 2023-12-01 13:13:01 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-01 13:13:01 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-01 13:13:01 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-01 13:13:01 --> Final output sent to browser
DEBUG - 2023-12-01 13:13:01 --> Total execution time: 0.0399
ERROR - 2023-12-01 13:55:00 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-01 13:55:00 --> Config Class Initialized
INFO - 2023-12-01 13:55:00 --> Hooks Class Initialized
DEBUG - 2023-12-01 13:55:00 --> UTF-8 Support Enabled
INFO - 2023-12-01 13:55:00 --> Utf8 Class Initialized
INFO - 2023-12-01 13:55:00 --> URI Class Initialized
DEBUG - 2023-12-01 13:55:00 --> No URI present. Default controller set.
INFO - 2023-12-01 13:55:00 --> Router Class Initialized
INFO - 2023-12-01 13:55:00 --> Output Class Initialized
INFO - 2023-12-01 13:55:00 --> Security Class Initialized
DEBUG - 2023-12-01 13:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-01 13:55:00 --> Input Class Initialized
INFO - 2023-12-01 13:55:00 --> Language Class Initialized
INFO - 2023-12-01 13:55:00 --> Loader Class Initialized
INFO - 2023-12-01 13:55:00 --> Helper loaded: url_helper
INFO - 2023-12-01 13:55:00 --> Helper loaded: form_helper
INFO - 2023-12-01 13:55:00 --> Helper loaded: file_helper
INFO - 2023-12-01 13:55:00 --> Database Driver Class Initialized
DEBUG - 2023-12-01 13:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-01 13:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-01 13:55:00 --> Form Validation Class Initialized
INFO - 2023-12-01 13:55:00 --> Upload Class Initialized
INFO - 2023-12-01 13:55:00 --> Model "M_auth" initialized
INFO - 2023-12-01 13:55:00 --> Model "M_user" initialized
INFO - 2023-12-01 13:55:00 --> Model "M_produk" initialized
INFO - 2023-12-01 13:55:00 --> Controller Class Initialized
INFO - 2023-12-01 13:55:00 --> Model "M_pelanggan" initialized
INFO - 2023-12-01 13:55:00 --> Model "M_produk" initialized
DEBUG - 2023-12-01 13:55:00 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-01 13:55:00 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-01 13:55:00 --> Model "M_transaksi" initialized
INFO - 2023-12-01 13:55:00 --> Model "M_bank" initialized
INFO - 2023-12-01 13:55:00 --> Model "M_pesan" initialized
DEBUG - 2023-12-01 13:55:00 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-01 13:55:00 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-01 13:55:00 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-01 13:55:00 --> Final output sent to browser
DEBUG - 2023-12-01 13:55:00 --> Total execution time: 0.0309
ERROR - 2023-12-01 14:26:53 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-01 14:26:53 --> Config Class Initialized
INFO - 2023-12-01 14:26:53 --> Hooks Class Initialized
DEBUG - 2023-12-01 14:26:53 --> UTF-8 Support Enabled
INFO - 2023-12-01 14:26:53 --> Utf8 Class Initialized
INFO - 2023-12-01 14:26:53 --> URI Class Initialized
DEBUG - 2023-12-01 14:26:53 --> No URI present. Default controller set.
INFO - 2023-12-01 14:26:53 --> Router Class Initialized
INFO - 2023-12-01 14:26:53 --> Output Class Initialized
INFO - 2023-12-01 14:26:53 --> Security Class Initialized
DEBUG - 2023-12-01 14:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-01 14:26:53 --> Input Class Initialized
INFO - 2023-12-01 14:26:53 --> Language Class Initialized
INFO - 2023-12-01 14:26:53 --> Loader Class Initialized
INFO - 2023-12-01 14:26:53 --> Helper loaded: url_helper
INFO - 2023-12-01 14:26:53 --> Helper loaded: form_helper
INFO - 2023-12-01 14:26:53 --> Helper loaded: file_helper
INFO - 2023-12-01 14:26:53 --> Database Driver Class Initialized
DEBUG - 2023-12-01 14:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-01 14:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-01 14:26:53 --> Form Validation Class Initialized
INFO - 2023-12-01 14:26:53 --> Upload Class Initialized
INFO - 2023-12-01 14:26:53 --> Model "M_auth" initialized
INFO - 2023-12-01 14:26:53 --> Model "M_user" initialized
INFO - 2023-12-01 14:26:53 --> Model "M_produk" initialized
INFO - 2023-12-01 14:26:53 --> Controller Class Initialized
INFO - 2023-12-01 14:26:53 --> Model "M_pelanggan" initialized
INFO - 2023-12-01 14:26:53 --> Model "M_produk" initialized
DEBUG - 2023-12-01 14:26:53 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-01 14:26:53 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-01 14:26:53 --> Model "M_transaksi" initialized
INFO - 2023-12-01 14:26:53 --> Model "M_bank" initialized
INFO - 2023-12-01 14:26:53 --> Model "M_pesan" initialized
DEBUG - 2023-12-01 14:26:53 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-01 14:26:53 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-01 14:26:53 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-01 14:26:53 --> Final output sent to browser
DEBUG - 2023-12-01 14:26:53 --> Total execution time: 0.0303
ERROR - 2023-12-01 15:16:16 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-01 15:16:16 --> Config Class Initialized
INFO - 2023-12-01 15:16:16 --> Hooks Class Initialized
DEBUG - 2023-12-01 15:16:16 --> UTF-8 Support Enabled
INFO - 2023-12-01 15:16:16 --> Utf8 Class Initialized
INFO - 2023-12-01 15:16:16 --> URI Class Initialized
DEBUG - 2023-12-01 15:16:16 --> No URI present. Default controller set.
INFO - 2023-12-01 15:16:16 --> Router Class Initialized
INFO - 2023-12-01 15:16:16 --> Output Class Initialized
INFO - 2023-12-01 15:16:16 --> Security Class Initialized
DEBUG - 2023-12-01 15:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-01 15:16:16 --> Input Class Initialized
INFO - 2023-12-01 15:16:16 --> Language Class Initialized
INFO - 2023-12-01 15:16:16 --> Loader Class Initialized
INFO - 2023-12-01 15:16:16 --> Helper loaded: url_helper
INFO - 2023-12-01 15:16:16 --> Helper loaded: form_helper
INFO - 2023-12-01 15:16:16 --> Helper loaded: file_helper
INFO - 2023-12-01 15:16:16 --> Database Driver Class Initialized
DEBUG - 2023-12-01 15:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-01 15:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-01 15:16:16 --> Form Validation Class Initialized
INFO - 2023-12-01 15:16:16 --> Upload Class Initialized
INFO - 2023-12-01 15:16:16 --> Model "M_auth" initialized
INFO - 2023-12-01 15:16:16 --> Model "M_user" initialized
INFO - 2023-12-01 15:16:16 --> Model "M_produk" initialized
INFO - 2023-12-01 15:16:16 --> Controller Class Initialized
INFO - 2023-12-01 15:16:16 --> Model "M_pelanggan" initialized
INFO - 2023-12-01 15:16:16 --> Model "M_produk" initialized
DEBUG - 2023-12-01 15:16:16 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-01 15:16:16 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-01 15:16:16 --> Model "M_transaksi" initialized
INFO - 2023-12-01 15:16:16 --> Model "M_bank" initialized
INFO - 2023-12-01 15:16:16 --> Model "M_pesan" initialized
DEBUG - 2023-12-01 15:16:16 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-01 15:16:16 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-01 15:16:16 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-01 15:16:16 --> Final output sent to browser
DEBUG - 2023-12-01 15:16:16 --> Total execution time: 0.0378
ERROR - 2023-12-01 15:18:36 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-01 15:18:36 --> Config Class Initialized
INFO - 2023-12-01 15:18:36 --> Hooks Class Initialized
DEBUG - 2023-12-01 15:18:36 --> UTF-8 Support Enabled
INFO - 2023-12-01 15:18:36 --> Utf8 Class Initialized
INFO - 2023-12-01 15:18:36 --> URI Class Initialized
INFO - 2023-12-01 15:18:36 --> Router Class Initialized
INFO - 2023-12-01 15:18:36 --> Output Class Initialized
INFO - 2023-12-01 15:18:36 --> Security Class Initialized
DEBUG - 2023-12-01 15:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-01 15:18:36 --> Input Class Initialized
INFO - 2023-12-01 15:18:36 --> Language Class Initialized
INFO - 2023-12-01 15:18:36 --> Loader Class Initialized
INFO - 2023-12-01 15:18:36 --> Helper loaded: url_helper
INFO - 2023-12-01 15:18:36 --> Helper loaded: form_helper
INFO - 2023-12-01 15:18:36 --> Helper loaded: file_helper
INFO - 2023-12-01 15:18:36 --> Database Driver Class Initialized
DEBUG - 2023-12-01 15:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-01 15:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-01 15:18:36 --> Form Validation Class Initialized
INFO - 2023-12-01 15:18:36 --> Upload Class Initialized
INFO - 2023-12-01 15:18:36 --> Model "M_auth" initialized
INFO - 2023-12-01 15:18:36 --> Model "M_user" initialized
INFO - 2023-12-01 15:18:36 --> Model "M_produk" initialized
INFO - 2023-12-01 15:18:36 --> Controller Class Initialized
INFO - 2023-12-01 15:18:36 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-01 15:18:36 --> Final output sent to browser
DEBUG - 2023-12-01 15:18:36 --> Total execution time: 0.0036
ERROR - 2023-12-01 15:18:36 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-01 15:18:36 --> Config Class Initialized
INFO - 2023-12-01 15:18:36 --> Hooks Class Initialized
DEBUG - 2023-12-01 15:18:36 --> UTF-8 Support Enabled
INFO - 2023-12-01 15:18:36 --> Utf8 Class Initialized
INFO - 2023-12-01 15:18:36 --> URI Class Initialized
INFO - 2023-12-01 15:18:36 --> Router Class Initialized
INFO - 2023-12-01 15:18:36 --> Output Class Initialized
INFO - 2023-12-01 15:18:36 --> Security Class Initialized
DEBUG - 2023-12-01 15:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-01 15:18:36 --> Input Class Initialized
INFO - 2023-12-01 15:18:36 --> Language Class Initialized
INFO - 2023-12-01 15:18:36 --> Loader Class Initialized
INFO - 2023-12-01 15:18:36 --> Helper loaded: url_helper
INFO - 2023-12-01 15:18:36 --> Helper loaded: form_helper
INFO - 2023-12-01 15:18:36 --> Helper loaded: file_helper
INFO - 2023-12-01 15:18:36 --> Database Driver Class Initialized
DEBUG - 2023-12-01 15:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-01 15:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-01 15:18:36 --> Form Validation Class Initialized
INFO - 2023-12-01 15:18:36 --> Upload Class Initialized
INFO - 2023-12-01 15:18:36 --> Model "M_auth" initialized
INFO - 2023-12-01 15:18:36 --> Model "M_user" initialized
INFO - 2023-12-01 15:18:36 --> Model "M_produk" initialized
INFO - 2023-12-01 15:18:36 --> Controller Class Initialized
INFO - 2023-12-01 15:18:36 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-01 15:18:36 --> Final output sent to browser
DEBUG - 2023-12-01 15:18:36 --> Total execution time: 0.0030
ERROR - 2023-12-01 16:25:12 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-01 16:25:12 --> Config Class Initialized
INFO - 2023-12-01 16:25:12 --> Hooks Class Initialized
DEBUG - 2023-12-01 16:25:12 --> UTF-8 Support Enabled
INFO - 2023-12-01 16:25:12 --> Utf8 Class Initialized
INFO - 2023-12-01 16:25:12 --> URI Class Initialized
INFO - 2023-12-01 16:25:12 --> Router Class Initialized
INFO - 2023-12-01 16:25:12 --> Output Class Initialized
INFO - 2023-12-01 16:25:12 --> Security Class Initialized
DEBUG - 2023-12-01 16:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-01 16:25:12 --> Input Class Initialized
INFO - 2023-12-01 16:25:12 --> Language Class Initialized
INFO - 2023-12-01 16:25:12 --> Loader Class Initialized
INFO - 2023-12-01 16:25:12 --> Helper loaded: url_helper
INFO - 2023-12-01 16:25:12 --> Helper loaded: form_helper
INFO - 2023-12-01 16:25:12 --> Helper loaded: file_helper
INFO - 2023-12-01 16:25:12 --> Database Driver Class Initialized
DEBUG - 2023-12-01 16:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-01 16:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-01 16:25:12 --> Form Validation Class Initialized
INFO - 2023-12-01 16:25:12 --> Upload Class Initialized
INFO - 2023-12-01 16:25:12 --> Model "M_auth" initialized
INFO - 2023-12-01 16:25:12 --> Model "M_user" initialized
INFO - 2023-12-01 16:25:12 --> Model "M_produk" initialized
INFO - 2023-12-01 16:25:12 --> Controller Class Initialized
INFO - 2023-12-01 16:25:12 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-01 16:25:12 --> Final output sent to browser
DEBUG - 2023-12-01 16:25:12 --> Total execution time: 0.0364
ERROR - 2023-12-01 16:25:13 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-01 16:25:13 --> Config Class Initialized
INFO - 2023-12-01 16:25:13 --> Hooks Class Initialized
DEBUG - 2023-12-01 16:25:13 --> UTF-8 Support Enabled
INFO - 2023-12-01 16:25:13 --> Utf8 Class Initialized
INFO - 2023-12-01 16:25:13 --> URI Class Initialized
INFO - 2023-12-01 16:25:13 --> Router Class Initialized
INFO - 2023-12-01 16:25:13 --> Output Class Initialized
INFO - 2023-12-01 16:25:13 --> Security Class Initialized
DEBUG - 2023-12-01 16:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-01 16:25:13 --> Input Class Initialized
INFO - 2023-12-01 16:25:13 --> Language Class Initialized
INFO - 2023-12-01 16:25:13 --> Loader Class Initialized
INFO - 2023-12-01 16:25:13 --> Helper loaded: url_helper
INFO - 2023-12-01 16:25:13 --> Helper loaded: form_helper
INFO - 2023-12-01 16:25:13 --> Helper loaded: file_helper
INFO - 2023-12-01 16:25:13 --> Database Driver Class Initialized
DEBUG - 2023-12-01 16:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-01 16:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-01 16:25:13 --> Form Validation Class Initialized
INFO - 2023-12-01 16:25:13 --> Upload Class Initialized
INFO - 2023-12-01 16:25:13 --> Model "M_auth" initialized
INFO - 2023-12-01 16:25:13 --> Model "M_user" initialized
INFO - 2023-12-01 16:25:13 --> Model "M_produk" initialized
INFO - 2023-12-01 16:25:13 --> Controller Class Initialized
INFO - 2023-12-01 16:25:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-01 16:25:13 --> Final output sent to browser
DEBUG - 2023-12-01 16:25:13 --> Total execution time: 0.0024
ERROR - 2023-12-01 17:57:48 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-01 17:57:48 --> Config Class Initialized
INFO - 2023-12-01 17:57:48 --> Hooks Class Initialized
DEBUG - 2023-12-01 17:57:48 --> UTF-8 Support Enabled
INFO - 2023-12-01 17:57:48 --> Utf8 Class Initialized
INFO - 2023-12-01 17:57:48 --> URI Class Initialized
INFO - 2023-12-01 17:57:48 --> Router Class Initialized
INFO - 2023-12-01 17:57:48 --> Output Class Initialized
INFO - 2023-12-01 17:57:48 --> Security Class Initialized
DEBUG - 2023-12-01 17:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-01 17:57:48 --> Input Class Initialized
INFO - 2023-12-01 17:57:48 --> Language Class Initialized
INFO - 2023-12-01 17:57:48 --> Loader Class Initialized
INFO - 2023-12-01 17:57:48 --> Helper loaded: url_helper
INFO - 2023-12-01 17:57:48 --> Helper loaded: form_helper
INFO - 2023-12-01 17:57:48 --> Helper loaded: file_helper
INFO - 2023-12-01 17:57:48 --> Database Driver Class Initialized
DEBUG - 2023-12-01 17:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-01 17:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-01 17:57:48 --> Form Validation Class Initialized
INFO - 2023-12-01 17:57:48 --> Upload Class Initialized
INFO - 2023-12-01 17:57:48 --> Model "M_auth" initialized
INFO - 2023-12-01 17:57:48 --> Model "M_user" initialized
INFO - 2023-12-01 17:57:48 --> Model "M_produk" initialized
INFO - 2023-12-01 17:57:48 --> Controller Class Initialized
INFO - 2023-12-01 17:57:48 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-01 17:57:48 --> Final output sent to browser
DEBUG - 2023-12-01 17:57:48 --> Total execution time: 0.0256
ERROR - 2023-12-01 19:06:16 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-01 19:06:16 --> Config Class Initialized
INFO - 2023-12-01 19:06:16 --> Hooks Class Initialized
DEBUG - 2023-12-01 19:06:16 --> UTF-8 Support Enabled
INFO - 2023-12-01 19:06:16 --> Utf8 Class Initialized
INFO - 2023-12-01 19:06:16 --> URI Class Initialized
DEBUG - 2023-12-01 19:06:16 --> No URI present. Default controller set.
INFO - 2023-12-01 19:06:16 --> Router Class Initialized
INFO - 2023-12-01 19:06:16 --> Output Class Initialized
INFO - 2023-12-01 19:06:16 --> Security Class Initialized
DEBUG - 2023-12-01 19:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-01 19:06:16 --> Input Class Initialized
INFO - 2023-12-01 19:06:16 --> Language Class Initialized
INFO - 2023-12-01 19:06:16 --> Loader Class Initialized
INFO - 2023-12-01 19:06:16 --> Helper loaded: url_helper
INFO - 2023-12-01 19:06:16 --> Helper loaded: form_helper
INFO - 2023-12-01 19:06:16 --> Helper loaded: file_helper
INFO - 2023-12-01 19:06:16 --> Database Driver Class Initialized
DEBUG - 2023-12-01 19:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-01 19:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-01 19:06:16 --> Form Validation Class Initialized
INFO - 2023-12-01 19:06:16 --> Upload Class Initialized
INFO - 2023-12-01 19:06:16 --> Model "M_auth" initialized
INFO - 2023-12-01 19:06:16 --> Model "M_user" initialized
INFO - 2023-12-01 19:06:16 --> Model "M_produk" initialized
INFO - 2023-12-01 19:06:16 --> Controller Class Initialized
INFO - 2023-12-01 19:06:16 --> Model "M_pelanggan" initialized
INFO - 2023-12-01 19:06:16 --> Model "M_produk" initialized
DEBUG - 2023-12-01 19:06:16 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-01 19:06:16 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-01 19:06:16 --> Model "M_transaksi" initialized
INFO - 2023-12-01 19:06:16 --> Model "M_bank" initialized
INFO - 2023-12-01 19:06:16 --> Model "M_pesan" initialized
DEBUG - 2023-12-01 19:06:16 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-01 19:06:16 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-01 19:06:16 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-01 19:06:16 --> Final output sent to browser
DEBUG - 2023-12-01 19:06:16 --> Total execution time: 0.0327
ERROR - 2023-12-01 23:29:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-01 23:29:45 --> Config Class Initialized
INFO - 2023-12-01 23:29:45 --> Hooks Class Initialized
DEBUG - 2023-12-01 23:29:45 --> UTF-8 Support Enabled
INFO - 2023-12-01 23:29:45 --> Utf8 Class Initialized
INFO - 2023-12-01 23:29:45 --> URI Class Initialized
INFO - 2023-12-01 23:29:45 --> Router Class Initialized
INFO - 2023-12-01 23:29:45 --> Output Class Initialized
INFO - 2023-12-01 23:29:45 --> Security Class Initialized
DEBUG - 2023-12-01 23:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-01 23:29:45 --> Input Class Initialized
INFO - 2023-12-01 23:29:45 --> Language Class Initialized
INFO - 2023-12-01 23:29:45 --> Loader Class Initialized
INFO - 2023-12-01 23:29:45 --> Helper loaded: url_helper
INFO - 2023-12-01 23:29:45 --> Helper loaded: form_helper
INFO - 2023-12-01 23:29:45 --> Helper loaded: file_helper
INFO - 2023-12-01 23:29:45 --> Database Driver Class Initialized
DEBUG - 2023-12-01 23:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-01 23:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-01 23:29:45 --> Form Validation Class Initialized
INFO - 2023-12-01 23:29:45 --> Upload Class Initialized
INFO - 2023-12-01 23:29:45 --> Model "M_auth" initialized
INFO - 2023-12-01 23:29:45 --> Model "M_user" initialized
INFO - 2023-12-01 23:29:45 --> Model "M_produk" initialized
INFO - 2023-12-01 23:29:45 --> Controller Class Initialized
INFO - 2023-12-01 23:29:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-01 23:29:45 --> Final output sent to browser
DEBUG - 2023-12-01 23:29:45 --> Total execution time: 0.0253
ERROR - 2023-12-01 23:29:47 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-01 23:29:47 --> Config Class Initialized
INFO - 2023-12-01 23:29:47 --> Hooks Class Initialized
DEBUG - 2023-12-01 23:29:47 --> UTF-8 Support Enabled
INFO - 2023-12-01 23:29:47 --> Utf8 Class Initialized
INFO - 2023-12-01 23:29:47 --> URI Class Initialized
DEBUG - 2023-12-01 23:29:47 --> No URI present. Default controller set.
INFO - 2023-12-01 23:29:47 --> Router Class Initialized
INFO - 2023-12-01 23:29:47 --> Output Class Initialized
INFO - 2023-12-01 23:29:47 --> Security Class Initialized
DEBUG - 2023-12-01 23:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-01 23:29:47 --> Input Class Initialized
INFO - 2023-12-01 23:29:47 --> Language Class Initialized
INFO - 2023-12-01 23:29:47 --> Loader Class Initialized
INFO - 2023-12-01 23:29:47 --> Helper loaded: url_helper
INFO - 2023-12-01 23:29:47 --> Helper loaded: form_helper
INFO - 2023-12-01 23:29:47 --> Helper loaded: file_helper
INFO - 2023-12-01 23:29:47 --> Database Driver Class Initialized
DEBUG - 2023-12-01 23:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-01 23:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-01 23:29:47 --> Form Validation Class Initialized
INFO - 2023-12-01 23:29:47 --> Upload Class Initialized
INFO - 2023-12-01 23:29:47 --> Model "M_auth" initialized
INFO - 2023-12-01 23:29:47 --> Model "M_user" initialized
INFO - 2023-12-01 23:29:47 --> Model "M_produk" initialized
INFO - 2023-12-01 23:29:47 --> Controller Class Initialized
INFO - 2023-12-01 23:29:47 --> Model "M_pelanggan" initialized
INFO - 2023-12-01 23:29:47 --> Model "M_produk" initialized
DEBUG - 2023-12-01 23:29:47 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-01 23:29:47 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-01 23:29:47 --> Model "M_transaksi" initialized
INFO - 2023-12-01 23:29:47 --> Model "M_bank" initialized
INFO - 2023-12-01 23:29:47 --> Model "M_pesan" initialized
DEBUG - 2023-12-01 23:29:47 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-01 23:29:47 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-01 23:29:47 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-01 23:29:47 --> Final output sent to browser
DEBUG - 2023-12-01 23:29:47 --> Total execution time: 0.0083
