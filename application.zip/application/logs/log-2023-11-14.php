<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-14 01:22:00 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-14 01:22:00 --> Config Class Initialized
INFO - 2023-11-14 01:22:00 --> Hooks Class Initialized
DEBUG - 2023-11-14 01:22:00 --> UTF-8 Support Enabled
INFO - 2023-11-14 01:22:00 --> Utf8 Class Initialized
INFO - 2023-11-14 01:22:00 --> URI Class Initialized
DEBUG - 2023-11-14 01:22:00 --> No URI present. Default controller set.
INFO - 2023-11-14 01:22:00 --> Router Class Initialized
INFO - 2023-11-14 01:22:00 --> Output Class Initialized
INFO - 2023-11-14 01:22:00 --> Security Class Initialized
DEBUG - 2023-11-14 01:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-14 01:22:00 --> Input Class Initialized
INFO - 2023-11-14 01:22:00 --> Language Class Initialized
INFO - 2023-11-14 01:22:00 --> Loader Class Initialized
INFO - 2023-11-14 01:22:00 --> Helper loaded: url_helper
INFO - 2023-11-14 01:22:00 --> Helper loaded: form_helper
INFO - 2023-11-14 01:22:00 --> Helper loaded: file_helper
INFO - 2023-11-14 01:22:00 --> Database Driver Class Initialized
DEBUG - 2023-11-14 01:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-14 01:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-14 01:22:00 --> Form Validation Class Initialized
INFO - 2023-11-14 01:22:00 --> Upload Class Initialized
INFO - 2023-11-14 01:22:00 --> Model "M_auth" initialized
INFO - 2023-11-14 01:22:00 --> Model "M_user" initialized
INFO - 2023-11-14 01:22:00 --> Model "M_produk" initialized
INFO - 2023-11-14 01:22:00 --> Controller Class Initialized
INFO - 2023-11-14 01:22:00 --> Model "M_pelanggan" initialized
INFO - 2023-11-14 01:22:00 --> Model "M_produk" initialized
DEBUG - 2023-11-14 01:22:00 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-14 01:22:00 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-14 01:22:00 --> Model "M_transaksi" initialized
INFO - 2023-11-14 01:22:00 --> Model "M_bank" initialized
INFO - 2023-11-14 01:22:00 --> Model "M_pesan" initialized
DEBUG - 2023-11-14 01:22:00 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-14 01:22:00 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-14 01:22:00 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-14 01:22:00 --> Final output sent to browser
DEBUG - 2023-11-14 01:22:00 --> Total execution time: 0.0405
ERROR - 2023-11-14 03:09:18 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-14 03:09:18 --> Config Class Initialized
INFO - 2023-11-14 03:09:18 --> Hooks Class Initialized
DEBUG - 2023-11-14 03:09:18 --> UTF-8 Support Enabled
INFO - 2023-11-14 03:09:18 --> Utf8 Class Initialized
INFO - 2023-11-14 03:09:18 --> URI Class Initialized
DEBUG - 2023-11-14 03:09:18 --> No URI present. Default controller set.
INFO - 2023-11-14 03:09:18 --> Router Class Initialized
INFO - 2023-11-14 03:09:18 --> Output Class Initialized
INFO - 2023-11-14 03:09:18 --> Security Class Initialized
DEBUG - 2023-11-14 03:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-14 03:09:18 --> Input Class Initialized
INFO - 2023-11-14 03:09:18 --> Language Class Initialized
INFO - 2023-11-14 03:09:18 --> Loader Class Initialized
INFO - 2023-11-14 03:09:18 --> Helper loaded: url_helper
INFO - 2023-11-14 03:09:18 --> Helper loaded: form_helper
INFO - 2023-11-14 03:09:18 --> Helper loaded: file_helper
INFO - 2023-11-14 03:09:18 --> Database Driver Class Initialized
DEBUG - 2023-11-14 03:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-14 03:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-14 03:09:18 --> Form Validation Class Initialized
INFO - 2023-11-14 03:09:18 --> Upload Class Initialized
INFO - 2023-11-14 03:09:18 --> Model "M_auth" initialized
INFO - 2023-11-14 03:09:18 --> Model "M_user" initialized
INFO - 2023-11-14 03:09:18 --> Model "M_produk" initialized
INFO - 2023-11-14 03:09:18 --> Controller Class Initialized
INFO - 2023-11-14 03:09:18 --> Model "M_pelanggan" initialized
INFO - 2023-11-14 03:09:18 --> Model "M_produk" initialized
DEBUG - 2023-11-14 03:09:18 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-14 03:09:18 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-14 03:09:18 --> Model "M_transaksi" initialized
INFO - 2023-11-14 03:09:18 --> Model "M_bank" initialized
INFO - 2023-11-14 03:09:18 --> Model "M_pesan" initialized
DEBUG - 2023-11-14 03:09:18 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-14 03:09:18 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-14 03:09:18 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-14 03:09:18 --> Final output sent to browser
DEBUG - 2023-11-14 03:09:18 --> Total execution time: 0.0374
ERROR - 2023-11-14 03:09:19 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-14 03:09:19 --> Config Class Initialized
INFO - 2023-11-14 03:09:19 --> Hooks Class Initialized
DEBUG - 2023-11-14 03:09:19 --> UTF-8 Support Enabled
INFO - 2023-11-14 03:09:19 --> Utf8 Class Initialized
INFO - 2023-11-14 03:09:19 --> URI Class Initialized
DEBUG - 2023-11-14 03:09:19 --> No URI present. Default controller set.
INFO - 2023-11-14 03:09:19 --> Router Class Initialized
INFO - 2023-11-14 03:09:19 --> Output Class Initialized
INFO - 2023-11-14 03:09:19 --> Security Class Initialized
DEBUG - 2023-11-14 03:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-14 03:09:19 --> Input Class Initialized
INFO - 2023-11-14 03:09:19 --> Language Class Initialized
INFO - 2023-11-14 03:09:19 --> Loader Class Initialized
INFO - 2023-11-14 03:09:19 --> Helper loaded: url_helper
INFO - 2023-11-14 03:09:19 --> Helper loaded: form_helper
INFO - 2023-11-14 03:09:19 --> Helper loaded: file_helper
INFO - 2023-11-14 03:09:19 --> Database Driver Class Initialized
DEBUG - 2023-11-14 03:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-14 03:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-14 03:09:19 --> Form Validation Class Initialized
INFO - 2023-11-14 03:09:19 --> Upload Class Initialized
INFO - 2023-11-14 03:09:19 --> Model "M_auth" initialized
INFO - 2023-11-14 03:09:19 --> Model "M_user" initialized
INFO - 2023-11-14 03:09:19 --> Model "M_produk" initialized
INFO - 2023-11-14 03:09:19 --> Controller Class Initialized
INFO - 2023-11-14 03:09:19 --> Model "M_pelanggan" initialized
INFO - 2023-11-14 03:09:19 --> Model "M_produk" initialized
DEBUG - 2023-11-14 03:09:19 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-14 03:09:19 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-14 03:09:19 --> Model "M_transaksi" initialized
INFO - 2023-11-14 03:09:19 --> Model "M_bank" initialized
INFO - 2023-11-14 03:09:19 --> Model "M_pesan" initialized
DEBUG - 2023-11-14 03:09:19 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-14 03:09:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-14 03:09:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-14 03:09:19 --> Final output sent to browser
DEBUG - 2023-11-14 03:09:19 --> Total execution time: 0.0043
ERROR - 2023-11-14 03:09:20 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-14 03:09:20 --> Config Class Initialized
INFO - 2023-11-14 03:09:20 --> Hooks Class Initialized
DEBUG - 2023-11-14 03:09:20 --> UTF-8 Support Enabled
INFO - 2023-11-14 03:09:20 --> Utf8 Class Initialized
INFO - 2023-11-14 03:09:20 --> URI Class Initialized
DEBUG - 2023-11-14 03:09:20 --> No URI present. Default controller set.
INFO - 2023-11-14 03:09:20 --> Router Class Initialized
INFO - 2023-11-14 03:09:20 --> Output Class Initialized
INFO - 2023-11-14 03:09:20 --> Security Class Initialized
DEBUG - 2023-11-14 03:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-14 03:09:20 --> Input Class Initialized
INFO - 2023-11-14 03:09:20 --> Language Class Initialized
INFO - 2023-11-14 03:09:20 --> Loader Class Initialized
INFO - 2023-11-14 03:09:20 --> Helper loaded: url_helper
INFO - 2023-11-14 03:09:20 --> Helper loaded: form_helper
INFO - 2023-11-14 03:09:20 --> Helper loaded: file_helper
INFO - 2023-11-14 03:09:20 --> Database Driver Class Initialized
DEBUG - 2023-11-14 03:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-14 03:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-14 03:09:20 --> Form Validation Class Initialized
INFO - 2023-11-14 03:09:20 --> Upload Class Initialized
INFO - 2023-11-14 03:09:20 --> Model "M_auth" initialized
INFO - 2023-11-14 03:09:20 --> Model "M_user" initialized
INFO - 2023-11-14 03:09:20 --> Model "M_produk" initialized
INFO - 2023-11-14 03:09:20 --> Controller Class Initialized
INFO - 2023-11-14 03:09:20 --> Model "M_pelanggan" initialized
INFO - 2023-11-14 03:09:20 --> Model "M_produk" initialized
DEBUG - 2023-11-14 03:09:20 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-14 03:09:20 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-14 03:09:20 --> Model "M_transaksi" initialized
INFO - 2023-11-14 03:09:20 --> Model "M_bank" initialized
INFO - 2023-11-14 03:09:20 --> Model "M_pesan" initialized
DEBUG - 2023-11-14 03:09:20 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-14 03:09:20 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-14 03:09:20 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-14 03:09:20 --> Final output sent to browser
DEBUG - 2023-11-14 03:09:20 --> Total execution time: 0.0036
ERROR - 2023-11-14 03:09:23 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-14 03:09:23 --> Config Class Initialized
INFO - 2023-11-14 03:09:23 --> Hooks Class Initialized
DEBUG - 2023-11-14 03:09:23 --> UTF-8 Support Enabled
INFO - 2023-11-14 03:09:23 --> Utf8 Class Initialized
INFO - 2023-11-14 03:09:23 --> URI Class Initialized
DEBUG - 2023-11-14 03:09:23 --> No URI present. Default controller set.
INFO - 2023-11-14 03:09:23 --> Router Class Initialized
INFO - 2023-11-14 03:09:23 --> Output Class Initialized
INFO - 2023-11-14 03:09:23 --> Security Class Initialized
DEBUG - 2023-11-14 03:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-14 03:09:23 --> Input Class Initialized
INFO - 2023-11-14 03:09:23 --> Language Class Initialized
INFO - 2023-11-14 03:09:23 --> Loader Class Initialized
INFO - 2023-11-14 03:09:23 --> Helper loaded: url_helper
INFO - 2023-11-14 03:09:23 --> Helper loaded: form_helper
INFO - 2023-11-14 03:09:23 --> Helper loaded: file_helper
INFO - 2023-11-14 03:09:23 --> Database Driver Class Initialized
DEBUG - 2023-11-14 03:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-14 03:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-14 03:09:23 --> Form Validation Class Initialized
INFO - 2023-11-14 03:09:23 --> Upload Class Initialized
INFO - 2023-11-14 03:09:23 --> Model "M_auth" initialized
INFO - 2023-11-14 03:09:23 --> Model "M_user" initialized
INFO - 2023-11-14 03:09:23 --> Model "M_produk" initialized
INFO - 2023-11-14 03:09:23 --> Controller Class Initialized
INFO - 2023-11-14 03:09:23 --> Model "M_pelanggan" initialized
INFO - 2023-11-14 03:09:23 --> Model "M_produk" initialized
DEBUG - 2023-11-14 03:09:23 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-14 03:09:23 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-14 03:09:23 --> Model "M_transaksi" initialized
INFO - 2023-11-14 03:09:23 --> Model "M_bank" initialized
INFO - 2023-11-14 03:09:23 --> Model "M_pesan" initialized
DEBUG - 2023-11-14 03:09:23 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
ERROR - 2023-11-14 03:09:23 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-14 03:09:23 --> Config Class Initialized
INFO - 2023-11-14 03:09:23 --> Hooks Class Initialized
DEBUG - 2023-11-14 03:09:23 --> UTF-8 Support Enabled
INFO - 2023-11-14 03:09:23 --> Utf8 Class Initialized
INFO - 2023-11-14 03:09:23 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-14 03:09:23 --> URI Class Initialized
INFO - 2023-11-14 03:09:23 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
DEBUG - 2023-11-14 03:09:23 --> No URI present. Default controller set.
INFO - 2023-11-14 03:09:23 --> Router Class Initialized
INFO - 2023-11-14 03:09:23 --> Final output sent to browser
DEBUG - 2023-11-14 03:09:23 --> Total execution time: 0.0039
INFO - 2023-11-14 03:09:23 --> Output Class Initialized
INFO - 2023-11-14 03:09:23 --> Security Class Initialized
DEBUG - 2023-11-14 03:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-14 03:09:23 --> Input Class Initialized
INFO - 2023-11-14 03:09:23 --> Language Class Initialized
INFO - 2023-11-14 03:09:23 --> Loader Class Initialized
INFO - 2023-11-14 03:09:23 --> Helper loaded: url_helper
INFO - 2023-11-14 03:09:23 --> Helper loaded: form_helper
INFO - 2023-11-14 03:09:23 --> Helper loaded: file_helper
INFO - 2023-11-14 03:09:23 --> Database Driver Class Initialized
DEBUG - 2023-11-14 03:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-14 03:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-14 03:09:23 --> Form Validation Class Initialized
INFO - 2023-11-14 03:09:23 --> Upload Class Initialized
INFO - 2023-11-14 03:09:23 --> Model "M_auth" initialized
INFO - 2023-11-14 03:09:23 --> Model "M_user" initialized
INFO - 2023-11-14 03:09:23 --> Model "M_produk" initialized
INFO - 2023-11-14 03:09:23 --> Controller Class Initialized
INFO - 2023-11-14 03:09:23 --> Model "M_pelanggan" initialized
INFO - 2023-11-14 03:09:23 --> Model "M_produk" initialized
DEBUG - 2023-11-14 03:09:23 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-14 03:09:23 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-14 03:09:23 --> Model "M_transaksi" initialized
INFO - 2023-11-14 03:09:23 --> Model "M_bank" initialized
INFO - 2023-11-14 03:09:23 --> Model "M_pesan" initialized
DEBUG - 2023-11-14 03:09:23 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-14 03:09:23 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-14 03:09:23 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-14 03:09:23 --> Final output sent to browser
DEBUG - 2023-11-14 03:09:23 --> Total execution time: 0.0040
ERROR - 2023-11-14 03:45:05 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-14 03:45:05 --> Config Class Initialized
INFO - 2023-11-14 03:45:05 --> Hooks Class Initialized
DEBUG - 2023-11-14 03:45:05 --> UTF-8 Support Enabled
INFO - 2023-11-14 03:45:05 --> Utf8 Class Initialized
INFO - 2023-11-14 03:45:05 --> URI Class Initialized
DEBUG - 2023-11-14 03:45:05 --> No URI present. Default controller set.
INFO - 2023-11-14 03:45:05 --> Router Class Initialized
INFO - 2023-11-14 03:45:05 --> Output Class Initialized
INFO - 2023-11-14 03:45:05 --> Security Class Initialized
DEBUG - 2023-11-14 03:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-14 03:45:05 --> Input Class Initialized
INFO - 2023-11-14 03:45:05 --> Language Class Initialized
INFO - 2023-11-14 03:45:05 --> Loader Class Initialized
INFO - 2023-11-14 03:45:05 --> Helper loaded: url_helper
INFO - 2023-11-14 03:45:05 --> Helper loaded: form_helper
INFO - 2023-11-14 03:45:05 --> Helper loaded: file_helper
INFO - 2023-11-14 03:45:05 --> Database Driver Class Initialized
DEBUG - 2023-11-14 03:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-14 03:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-14 03:45:05 --> Form Validation Class Initialized
INFO - 2023-11-14 03:45:05 --> Upload Class Initialized
INFO - 2023-11-14 03:45:05 --> Model "M_auth" initialized
INFO - 2023-11-14 03:45:05 --> Model "M_user" initialized
INFO - 2023-11-14 03:45:05 --> Model "M_produk" initialized
INFO - 2023-11-14 03:45:05 --> Controller Class Initialized
INFO - 2023-11-14 03:45:05 --> Model "M_pelanggan" initialized
INFO - 2023-11-14 03:45:05 --> Model "M_produk" initialized
DEBUG - 2023-11-14 03:45:05 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-14 03:45:05 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-14 03:45:05 --> Model "M_transaksi" initialized
INFO - 2023-11-14 03:45:05 --> Model "M_bank" initialized
INFO - 2023-11-14 03:45:05 --> Model "M_pesan" initialized
DEBUG - 2023-11-14 03:45:05 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-14 03:45:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-14 03:45:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-14 03:45:05 --> Final output sent to browser
DEBUG - 2023-11-14 03:45:05 --> Total execution time: 0.0450
ERROR - 2023-11-14 04:44:41 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-14 04:44:41 --> Config Class Initialized
INFO - 2023-11-14 04:44:41 --> Hooks Class Initialized
DEBUG - 2023-11-14 04:44:41 --> UTF-8 Support Enabled
INFO - 2023-11-14 04:44:41 --> Utf8 Class Initialized
INFO - 2023-11-14 04:44:41 --> URI Class Initialized
DEBUG - 2023-11-14 04:44:41 --> No URI present. Default controller set.
INFO - 2023-11-14 04:44:41 --> Router Class Initialized
INFO - 2023-11-14 04:44:41 --> Output Class Initialized
INFO - 2023-11-14 04:44:41 --> Security Class Initialized
DEBUG - 2023-11-14 04:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-14 04:44:41 --> Input Class Initialized
INFO - 2023-11-14 04:44:41 --> Language Class Initialized
INFO - 2023-11-14 04:44:41 --> Loader Class Initialized
INFO - 2023-11-14 04:44:41 --> Helper loaded: url_helper
INFO - 2023-11-14 04:44:41 --> Helper loaded: form_helper
INFO - 2023-11-14 04:44:41 --> Helper loaded: file_helper
INFO - 2023-11-14 04:44:41 --> Database Driver Class Initialized
DEBUG - 2023-11-14 04:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-14 04:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-14 04:44:41 --> Form Validation Class Initialized
INFO - 2023-11-14 04:44:41 --> Upload Class Initialized
INFO - 2023-11-14 04:44:41 --> Model "M_auth" initialized
INFO - 2023-11-14 04:44:41 --> Model "M_user" initialized
INFO - 2023-11-14 04:44:41 --> Model "M_produk" initialized
INFO - 2023-11-14 04:44:41 --> Controller Class Initialized
INFO - 2023-11-14 04:44:41 --> Model "M_pelanggan" initialized
INFO - 2023-11-14 04:44:41 --> Model "M_produk" initialized
DEBUG - 2023-11-14 04:44:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-14 04:44:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-14 04:44:41 --> Model "M_transaksi" initialized
INFO - 2023-11-14 04:44:41 --> Model "M_bank" initialized
INFO - 2023-11-14 04:44:41 --> Model "M_pesan" initialized
DEBUG - 2023-11-14 04:44:41 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-14 04:44:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-14 04:44:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-14 04:44:41 --> Final output sent to browser
DEBUG - 2023-11-14 04:44:41 --> Total execution time: 0.0474
ERROR - 2023-11-14 05:35:34 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-14 05:35:34 --> Config Class Initialized
INFO - 2023-11-14 05:35:34 --> Hooks Class Initialized
DEBUG - 2023-11-14 05:35:34 --> UTF-8 Support Enabled
INFO - 2023-11-14 05:35:34 --> Utf8 Class Initialized
INFO - 2023-11-14 05:35:34 --> URI Class Initialized
INFO - 2023-11-14 05:35:34 --> Router Class Initialized
INFO - 2023-11-14 05:35:34 --> Output Class Initialized
INFO - 2023-11-14 05:35:34 --> Security Class Initialized
DEBUG - 2023-11-14 05:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-14 05:35:34 --> Input Class Initialized
INFO - 2023-11-14 05:35:34 --> Language Class Initialized
INFO - 2023-11-14 05:35:34 --> Loader Class Initialized
INFO - 2023-11-14 05:35:34 --> Helper loaded: url_helper
INFO - 2023-11-14 05:35:34 --> Helper loaded: form_helper
INFO - 2023-11-14 05:35:34 --> Helper loaded: file_helper
INFO - 2023-11-14 05:35:34 --> Database Driver Class Initialized
DEBUG - 2023-11-14 05:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-14 05:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-14 05:35:34 --> Form Validation Class Initialized
INFO - 2023-11-14 05:35:34 --> Upload Class Initialized
INFO - 2023-11-14 05:35:34 --> Model "M_auth" initialized
INFO - 2023-11-14 05:35:34 --> Model "M_user" initialized
INFO - 2023-11-14 05:35:34 --> Model "M_produk" initialized
INFO - 2023-11-14 05:35:34 --> Controller Class Initialized
INFO - 2023-11-14 05:35:34 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-14 05:35:34 --> Final output sent to browser
DEBUG - 2023-11-14 05:35:34 --> Total execution time: 0.0390
ERROR - 2023-11-14 05:35:35 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-14 05:35:35 --> Config Class Initialized
INFO - 2023-11-14 05:35:35 --> Hooks Class Initialized
DEBUG - 2023-11-14 05:35:35 --> UTF-8 Support Enabled
INFO - 2023-11-14 05:35:35 --> Utf8 Class Initialized
INFO - 2023-11-14 05:35:35 --> URI Class Initialized
INFO - 2023-11-14 05:35:35 --> Router Class Initialized
INFO - 2023-11-14 05:35:35 --> Output Class Initialized
INFO - 2023-11-14 05:35:35 --> Security Class Initialized
DEBUG - 2023-11-14 05:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-14 05:35:35 --> Input Class Initialized
INFO - 2023-11-14 05:35:35 --> Language Class Initialized
INFO - 2023-11-14 05:35:35 --> Loader Class Initialized
INFO - 2023-11-14 05:35:35 --> Helper loaded: url_helper
INFO - 2023-11-14 05:35:35 --> Helper loaded: form_helper
INFO - 2023-11-14 05:35:35 --> Helper loaded: file_helper
INFO - 2023-11-14 05:35:35 --> Database Driver Class Initialized
DEBUG - 2023-11-14 05:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-14 05:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-14 05:35:35 --> Form Validation Class Initialized
INFO - 2023-11-14 05:35:35 --> Upload Class Initialized
INFO - 2023-11-14 05:35:35 --> Model "M_auth" initialized
INFO - 2023-11-14 05:35:35 --> Model "M_user" initialized
INFO - 2023-11-14 05:35:35 --> Model "M_produk" initialized
INFO - 2023-11-14 05:35:35 --> Controller Class Initialized
INFO - 2023-11-14 05:35:35 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-14 05:35:35 --> Final output sent to browser
DEBUG - 2023-11-14 05:35:35 --> Total execution time: 0.0027
ERROR - 2023-11-14 05:35:36 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-14 05:35:36 --> Config Class Initialized
INFO - 2023-11-14 05:35:36 --> Hooks Class Initialized
DEBUG - 2023-11-14 05:35:36 --> UTF-8 Support Enabled
INFO - 2023-11-14 05:35:36 --> Utf8 Class Initialized
INFO - 2023-11-14 05:35:36 --> URI Class Initialized
INFO - 2023-11-14 05:35:36 --> Router Class Initialized
INFO - 2023-11-14 05:35:36 --> Output Class Initialized
INFO - 2023-11-14 05:35:36 --> Security Class Initialized
DEBUG - 2023-11-14 05:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-14 05:35:36 --> Input Class Initialized
INFO - 2023-11-14 05:35:36 --> Language Class Initialized
INFO - 2023-11-14 05:35:36 --> Loader Class Initialized
INFO - 2023-11-14 05:35:36 --> Helper loaded: url_helper
INFO - 2023-11-14 05:35:36 --> Helper loaded: form_helper
INFO - 2023-11-14 05:35:36 --> Helper loaded: file_helper
INFO - 2023-11-14 05:35:36 --> Database Driver Class Initialized
DEBUG - 2023-11-14 05:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-14 05:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-14 05:35:36 --> Form Validation Class Initialized
INFO - 2023-11-14 05:35:36 --> Upload Class Initialized
INFO - 2023-11-14 05:35:36 --> Model "M_auth" initialized
INFO - 2023-11-14 05:35:36 --> Model "M_user" initialized
INFO - 2023-11-14 05:35:36 --> Model "M_produk" initialized
INFO - 2023-11-14 05:35:36 --> Controller Class Initialized
INFO - 2023-11-14 05:35:36 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-14 05:35:36 --> Final output sent to browser
DEBUG - 2023-11-14 05:35:36 --> Total execution time: 0.0021
ERROR - 2023-11-14 05:35:38 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-14 05:35:38 --> Config Class Initialized
INFO - 2023-11-14 05:35:38 --> Hooks Class Initialized
DEBUG - 2023-11-14 05:35:38 --> UTF-8 Support Enabled
INFO - 2023-11-14 05:35:38 --> Utf8 Class Initialized
INFO - 2023-11-14 05:35:38 --> URI Class Initialized
DEBUG - 2023-11-14 05:35:38 --> No URI present. Default controller set.
INFO - 2023-11-14 05:35:38 --> Router Class Initialized
INFO - 2023-11-14 05:35:38 --> Output Class Initialized
INFO - 2023-11-14 05:35:38 --> Security Class Initialized
DEBUG - 2023-11-14 05:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-14 05:35:38 --> Input Class Initialized
INFO - 2023-11-14 05:35:38 --> Language Class Initialized
INFO - 2023-11-14 05:35:38 --> Loader Class Initialized
INFO - 2023-11-14 05:35:38 --> Helper loaded: url_helper
INFO - 2023-11-14 05:35:38 --> Helper loaded: form_helper
INFO - 2023-11-14 05:35:38 --> Helper loaded: file_helper
INFO - 2023-11-14 05:35:38 --> Database Driver Class Initialized
DEBUG - 2023-11-14 05:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-14 05:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-14 05:35:38 --> Form Validation Class Initialized
INFO - 2023-11-14 05:35:38 --> Upload Class Initialized
INFO - 2023-11-14 05:35:38 --> Model "M_auth" initialized
INFO - 2023-11-14 05:35:38 --> Model "M_user" initialized
INFO - 2023-11-14 05:35:38 --> Model "M_produk" initialized
INFO - 2023-11-14 05:35:38 --> Controller Class Initialized
INFO - 2023-11-14 05:35:38 --> Model "M_pelanggan" initialized
INFO - 2023-11-14 05:35:38 --> Model "M_produk" initialized
DEBUG - 2023-11-14 05:35:38 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-14 05:35:38 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-14 05:35:38 --> Model "M_transaksi" initialized
INFO - 2023-11-14 05:35:38 --> Model "M_bank" initialized
INFO - 2023-11-14 05:35:38 --> Model "M_pesan" initialized
DEBUG - 2023-11-14 05:35:38 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-14 05:35:38 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-14 05:35:38 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-14 05:35:38 --> Final output sent to browser
DEBUG - 2023-11-14 05:35:38 --> Total execution time: 0.0156
ERROR - 2023-11-14 08:19:10 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-14 08:19:10 --> Config Class Initialized
INFO - 2023-11-14 08:19:10 --> Hooks Class Initialized
DEBUG - 2023-11-14 08:19:10 --> UTF-8 Support Enabled
INFO - 2023-11-14 08:19:10 --> Utf8 Class Initialized
INFO - 2023-11-14 08:19:10 --> URI Class Initialized
INFO - 2023-11-14 08:19:10 --> Router Class Initialized
INFO - 2023-11-14 08:19:10 --> Output Class Initialized
INFO - 2023-11-14 08:19:10 --> Security Class Initialized
DEBUG - 2023-11-14 08:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-14 08:19:10 --> Input Class Initialized
INFO - 2023-11-14 08:19:10 --> Language Class Initialized
INFO - 2023-11-14 08:19:10 --> Loader Class Initialized
INFO - 2023-11-14 08:19:10 --> Helper loaded: url_helper
INFO - 2023-11-14 08:19:10 --> Helper loaded: form_helper
INFO - 2023-11-14 08:19:10 --> Helper loaded: file_helper
INFO - 2023-11-14 08:19:10 --> Database Driver Class Initialized
DEBUG - 2023-11-14 08:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-14 08:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-14 08:19:10 --> Form Validation Class Initialized
INFO - 2023-11-14 08:19:10 --> Upload Class Initialized
INFO - 2023-11-14 08:19:10 --> Model "M_auth" initialized
INFO - 2023-11-14 08:19:10 --> Model "M_user" initialized
INFO - 2023-11-14 08:19:10 --> Model "M_produk" initialized
INFO - 2023-11-14 08:19:10 --> Controller Class Initialized
INFO - 2023-11-14 08:19:10 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-14 08:19:10 --> Final output sent to browser
DEBUG - 2023-11-14 08:19:10 --> Total execution time: 0.0390
ERROR - 2023-11-14 08:19:11 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-14 08:19:11 --> Config Class Initialized
INFO - 2023-11-14 08:19:11 --> Hooks Class Initialized
DEBUG - 2023-11-14 08:19:11 --> UTF-8 Support Enabled
INFO - 2023-11-14 08:19:11 --> Utf8 Class Initialized
INFO - 2023-11-14 08:19:11 --> URI Class Initialized
DEBUG - 2023-11-14 08:19:11 --> No URI present. Default controller set.
INFO - 2023-11-14 08:19:11 --> Router Class Initialized
INFO - 2023-11-14 08:19:11 --> Output Class Initialized
INFO - 2023-11-14 08:19:11 --> Security Class Initialized
DEBUG - 2023-11-14 08:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-14 08:19:11 --> Input Class Initialized
INFO - 2023-11-14 08:19:11 --> Language Class Initialized
INFO - 2023-11-14 08:19:11 --> Loader Class Initialized
INFO - 2023-11-14 08:19:11 --> Helper loaded: url_helper
INFO - 2023-11-14 08:19:11 --> Helper loaded: form_helper
INFO - 2023-11-14 08:19:11 --> Helper loaded: file_helper
INFO - 2023-11-14 08:19:11 --> Database Driver Class Initialized
DEBUG - 2023-11-14 08:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-14 08:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-14 08:19:11 --> Form Validation Class Initialized
INFO - 2023-11-14 08:19:11 --> Upload Class Initialized
INFO - 2023-11-14 08:19:11 --> Model "M_auth" initialized
INFO - 2023-11-14 08:19:11 --> Model "M_user" initialized
INFO - 2023-11-14 08:19:11 --> Model "M_produk" initialized
INFO - 2023-11-14 08:19:11 --> Controller Class Initialized
INFO - 2023-11-14 08:19:11 --> Model "M_pelanggan" initialized
INFO - 2023-11-14 08:19:11 --> Model "M_produk" initialized
DEBUG - 2023-11-14 08:19:11 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-14 08:19:11 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-14 08:19:11 --> Model "M_transaksi" initialized
INFO - 2023-11-14 08:19:11 --> Model "M_bank" initialized
INFO - 2023-11-14 08:19:11 --> Model "M_pesan" initialized
DEBUG - 2023-11-14 08:19:11 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-14 08:19:11 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-14 08:19:11 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-14 08:19:11 --> Final output sent to browser
DEBUG - 2023-11-14 08:19:11 --> Total execution time: 0.0122
ERROR - 2023-11-14 11:37:05 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-14 11:37:05 --> Config Class Initialized
INFO - 2023-11-14 11:37:05 --> Hooks Class Initialized
DEBUG - 2023-11-14 11:37:05 --> UTF-8 Support Enabled
INFO - 2023-11-14 11:37:05 --> Utf8 Class Initialized
INFO - 2023-11-14 11:37:05 --> URI Class Initialized
DEBUG - 2023-11-14 11:37:05 --> No URI present. Default controller set.
INFO - 2023-11-14 11:37:05 --> Router Class Initialized
INFO - 2023-11-14 11:37:05 --> Output Class Initialized
INFO - 2023-11-14 11:37:05 --> Security Class Initialized
DEBUG - 2023-11-14 11:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-14 11:37:05 --> Input Class Initialized
INFO - 2023-11-14 11:37:05 --> Language Class Initialized
INFO - 2023-11-14 11:37:05 --> Loader Class Initialized
INFO - 2023-11-14 11:37:05 --> Helper loaded: url_helper
INFO - 2023-11-14 11:37:05 --> Helper loaded: form_helper
INFO - 2023-11-14 11:37:05 --> Helper loaded: file_helper
INFO - 2023-11-14 11:37:05 --> Database Driver Class Initialized
DEBUG - 2023-11-14 11:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-14 11:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-14 11:37:05 --> Form Validation Class Initialized
INFO - 2023-11-14 11:37:05 --> Upload Class Initialized
INFO - 2023-11-14 11:37:05 --> Model "M_auth" initialized
INFO - 2023-11-14 11:37:05 --> Model "M_user" initialized
INFO - 2023-11-14 11:37:05 --> Model "M_produk" initialized
INFO - 2023-11-14 11:37:05 --> Controller Class Initialized
INFO - 2023-11-14 11:37:05 --> Model "M_pelanggan" initialized
INFO - 2023-11-14 11:37:05 --> Model "M_produk" initialized
DEBUG - 2023-11-14 11:37:05 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-14 11:37:05 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-14 11:37:05 --> Model "M_transaksi" initialized
INFO - 2023-11-14 11:37:05 --> Model "M_bank" initialized
INFO - 2023-11-14 11:37:05 --> Model "M_pesan" initialized
DEBUG - 2023-11-14 11:37:05 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-14 11:37:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-14 11:37:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-14 11:37:05 --> Final output sent to browser
DEBUG - 2023-11-14 11:37:05 --> Total execution time: 0.0429
ERROR - 2023-11-14 12:46:52 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-14 12:46:52 --> Config Class Initialized
INFO - 2023-11-14 12:46:52 --> Hooks Class Initialized
DEBUG - 2023-11-14 12:46:52 --> UTF-8 Support Enabled
INFO - 2023-11-14 12:46:52 --> Utf8 Class Initialized
INFO - 2023-11-14 12:46:52 --> URI Class Initialized
DEBUG - 2023-11-14 12:46:52 --> No URI present. Default controller set.
INFO - 2023-11-14 12:46:52 --> Router Class Initialized
INFO - 2023-11-14 12:46:52 --> Output Class Initialized
INFO - 2023-11-14 12:46:52 --> Security Class Initialized
DEBUG - 2023-11-14 12:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-14 12:46:52 --> Input Class Initialized
INFO - 2023-11-14 12:46:52 --> Language Class Initialized
INFO - 2023-11-14 12:46:52 --> Loader Class Initialized
INFO - 2023-11-14 12:46:52 --> Helper loaded: url_helper
INFO - 2023-11-14 12:46:52 --> Helper loaded: form_helper
INFO - 2023-11-14 12:46:52 --> Helper loaded: file_helper
INFO - 2023-11-14 12:46:52 --> Database Driver Class Initialized
DEBUG - 2023-11-14 12:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-14 12:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-14 12:46:52 --> Form Validation Class Initialized
INFO - 2023-11-14 12:46:52 --> Upload Class Initialized
INFO - 2023-11-14 12:46:52 --> Model "M_auth" initialized
INFO - 2023-11-14 12:46:52 --> Model "M_user" initialized
INFO - 2023-11-14 12:46:52 --> Model "M_produk" initialized
INFO - 2023-11-14 12:46:52 --> Controller Class Initialized
INFO - 2023-11-14 12:46:52 --> Model "M_pelanggan" initialized
INFO - 2023-11-14 12:46:52 --> Model "M_produk" initialized
DEBUG - 2023-11-14 12:46:52 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-14 12:46:52 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-14 12:46:52 --> Model "M_transaksi" initialized
INFO - 2023-11-14 12:46:52 --> Model "M_bank" initialized
INFO - 2023-11-14 12:46:52 --> Model "M_pesan" initialized
DEBUG - 2023-11-14 12:46:52 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-14 12:46:52 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-14 12:46:52 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-14 12:46:52 --> Final output sent to browser
DEBUG - 2023-11-14 12:46:52 --> Total execution time: 0.0350
ERROR - 2023-11-14 13:29:27 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-14 13:29:27 --> Config Class Initialized
INFO - 2023-11-14 13:29:27 --> Hooks Class Initialized
DEBUG - 2023-11-14 13:29:27 --> UTF-8 Support Enabled
INFO - 2023-11-14 13:29:27 --> Utf8 Class Initialized
INFO - 2023-11-14 13:29:27 --> URI Class Initialized
DEBUG - 2023-11-14 13:29:27 --> No URI present. Default controller set.
INFO - 2023-11-14 13:29:27 --> Router Class Initialized
INFO - 2023-11-14 13:29:27 --> Output Class Initialized
INFO - 2023-11-14 13:29:27 --> Security Class Initialized
DEBUG - 2023-11-14 13:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-14 13:29:27 --> Input Class Initialized
INFO - 2023-11-14 13:29:27 --> Language Class Initialized
INFO - 2023-11-14 13:29:27 --> Loader Class Initialized
INFO - 2023-11-14 13:29:27 --> Helper loaded: url_helper
INFO - 2023-11-14 13:29:27 --> Helper loaded: form_helper
INFO - 2023-11-14 13:29:27 --> Helper loaded: file_helper
INFO - 2023-11-14 13:29:27 --> Database Driver Class Initialized
DEBUG - 2023-11-14 13:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-14 13:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-14 13:29:27 --> Form Validation Class Initialized
INFO - 2023-11-14 13:29:27 --> Upload Class Initialized
INFO - 2023-11-14 13:29:27 --> Model "M_auth" initialized
INFO - 2023-11-14 13:29:27 --> Model "M_user" initialized
INFO - 2023-11-14 13:29:27 --> Model "M_produk" initialized
INFO - 2023-11-14 13:29:27 --> Controller Class Initialized
INFO - 2023-11-14 13:29:27 --> Model "M_pelanggan" initialized
INFO - 2023-11-14 13:29:27 --> Model "M_produk" initialized
DEBUG - 2023-11-14 13:29:27 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-14 13:29:27 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-14 13:29:27 --> Model "M_transaksi" initialized
INFO - 2023-11-14 13:29:27 --> Model "M_bank" initialized
INFO - 2023-11-14 13:29:27 --> Model "M_pesan" initialized
DEBUG - 2023-11-14 13:29:27 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-14 13:29:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-14 13:29:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-14 13:29:27 --> Final output sent to browser
DEBUG - 2023-11-14 13:29:27 --> Total execution time: 0.0362
ERROR - 2023-11-14 14:56:40 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-14 14:56:40 --> Config Class Initialized
INFO - 2023-11-14 14:56:40 --> Hooks Class Initialized
DEBUG - 2023-11-14 14:56:40 --> UTF-8 Support Enabled
INFO - 2023-11-14 14:56:40 --> Utf8 Class Initialized
INFO - 2023-11-14 14:56:40 --> URI Class Initialized
DEBUG - 2023-11-14 14:56:40 --> No URI present. Default controller set.
INFO - 2023-11-14 14:56:40 --> Router Class Initialized
INFO - 2023-11-14 14:56:40 --> Output Class Initialized
INFO - 2023-11-14 14:56:40 --> Security Class Initialized
DEBUG - 2023-11-14 14:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-14 14:56:40 --> Input Class Initialized
INFO - 2023-11-14 14:56:40 --> Language Class Initialized
INFO - 2023-11-14 14:56:40 --> Loader Class Initialized
INFO - 2023-11-14 14:56:40 --> Helper loaded: url_helper
INFO - 2023-11-14 14:56:40 --> Helper loaded: form_helper
INFO - 2023-11-14 14:56:40 --> Helper loaded: file_helper
INFO - 2023-11-14 14:56:40 --> Database Driver Class Initialized
DEBUG - 2023-11-14 14:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-14 14:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-14 14:56:40 --> Form Validation Class Initialized
INFO - 2023-11-14 14:56:40 --> Upload Class Initialized
INFO - 2023-11-14 14:56:40 --> Model "M_auth" initialized
INFO - 2023-11-14 14:56:40 --> Model "M_user" initialized
INFO - 2023-11-14 14:56:40 --> Model "M_produk" initialized
INFO - 2023-11-14 14:56:40 --> Controller Class Initialized
INFO - 2023-11-14 14:56:40 --> Model "M_pelanggan" initialized
INFO - 2023-11-14 14:56:40 --> Model "M_produk" initialized
DEBUG - 2023-11-14 14:56:40 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-14 14:56:40 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-14 14:56:40 --> Model "M_transaksi" initialized
INFO - 2023-11-14 14:56:40 --> Model "M_bank" initialized
INFO - 2023-11-14 14:56:40 --> Model "M_pesan" initialized
DEBUG - 2023-11-14 14:56:40 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-14 14:56:40 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-14 14:56:40 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-14 14:56:40 --> Final output sent to browser
DEBUG - 2023-11-14 14:56:40 --> Total execution time: 0.0423
ERROR - 2023-11-14 14:56:41 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-14 14:56:41 --> Config Class Initialized
INFO - 2023-11-14 14:56:41 --> Hooks Class Initialized
DEBUG - 2023-11-14 14:56:41 --> UTF-8 Support Enabled
INFO - 2023-11-14 14:56:41 --> Utf8 Class Initialized
INFO - 2023-11-14 14:56:41 --> URI Class Initialized
DEBUG - 2023-11-14 14:56:41 --> No URI present. Default controller set.
INFO - 2023-11-14 14:56:41 --> Router Class Initialized
INFO - 2023-11-14 14:56:41 --> Output Class Initialized
INFO - 2023-11-14 14:56:41 --> Security Class Initialized
DEBUG - 2023-11-14 14:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-14 14:56:41 --> Input Class Initialized
INFO - 2023-11-14 14:56:41 --> Language Class Initialized
INFO - 2023-11-14 14:56:41 --> Loader Class Initialized
INFO - 2023-11-14 14:56:41 --> Helper loaded: url_helper
INFO - 2023-11-14 14:56:41 --> Helper loaded: form_helper
INFO - 2023-11-14 14:56:41 --> Helper loaded: file_helper
INFO - 2023-11-14 14:56:41 --> Database Driver Class Initialized
DEBUG - 2023-11-14 14:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-14 14:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-14 14:56:41 --> Form Validation Class Initialized
INFO - 2023-11-14 14:56:41 --> Upload Class Initialized
INFO - 2023-11-14 14:56:41 --> Model "M_auth" initialized
INFO - 2023-11-14 14:56:41 --> Model "M_user" initialized
INFO - 2023-11-14 14:56:41 --> Model "M_produk" initialized
INFO - 2023-11-14 14:56:41 --> Controller Class Initialized
INFO - 2023-11-14 14:56:41 --> Model "M_pelanggan" initialized
INFO - 2023-11-14 14:56:41 --> Model "M_produk" initialized
DEBUG - 2023-11-14 14:56:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-14 14:56:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-14 14:56:41 --> Model "M_transaksi" initialized
INFO - 2023-11-14 14:56:41 --> Model "M_bank" initialized
INFO - 2023-11-14 14:56:41 --> Model "M_pesan" initialized
DEBUG - 2023-11-14 14:56:41 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-14 14:56:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-14 14:56:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-14 14:56:41 --> Final output sent to browser
DEBUG - 2023-11-14 14:56:41 --> Total execution time: 0.0033
ERROR - 2023-11-14 16:27:27 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-14 16:27:27 --> Config Class Initialized
INFO - 2023-11-14 16:27:27 --> Hooks Class Initialized
DEBUG - 2023-11-14 16:27:27 --> UTF-8 Support Enabled
INFO - 2023-11-14 16:27:27 --> Utf8 Class Initialized
INFO - 2023-11-14 16:27:27 --> URI Class Initialized
DEBUG - 2023-11-14 16:27:27 --> No URI present. Default controller set.
INFO - 2023-11-14 16:27:27 --> Router Class Initialized
INFO - 2023-11-14 16:27:27 --> Output Class Initialized
INFO - 2023-11-14 16:27:27 --> Security Class Initialized
DEBUG - 2023-11-14 16:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-14 16:27:27 --> Input Class Initialized
INFO - 2023-11-14 16:27:27 --> Language Class Initialized
INFO - 2023-11-14 16:27:27 --> Loader Class Initialized
INFO - 2023-11-14 16:27:27 --> Helper loaded: url_helper
INFO - 2023-11-14 16:27:27 --> Helper loaded: form_helper
INFO - 2023-11-14 16:27:27 --> Helper loaded: file_helper
INFO - 2023-11-14 16:27:27 --> Database Driver Class Initialized
DEBUG - 2023-11-14 16:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-14 16:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-14 16:27:27 --> Form Validation Class Initialized
INFO - 2023-11-14 16:27:27 --> Upload Class Initialized
INFO - 2023-11-14 16:27:27 --> Model "M_auth" initialized
INFO - 2023-11-14 16:27:27 --> Model "M_user" initialized
INFO - 2023-11-14 16:27:27 --> Model "M_produk" initialized
INFO - 2023-11-14 16:27:27 --> Controller Class Initialized
INFO - 2023-11-14 16:27:27 --> Model "M_pelanggan" initialized
INFO - 2023-11-14 16:27:27 --> Model "M_produk" initialized
DEBUG - 2023-11-14 16:27:27 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-14 16:27:27 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-14 16:27:27 --> Model "M_transaksi" initialized
INFO - 2023-11-14 16:27:27 --> Model "M_bank" initialized
INFO - 2023-11-14 16:27:27 --> Model "M_pesan" initialized
DEBUG - 2023-11-14 16:27:27 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-14 16:27:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-14 16:27:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-14 16:27:27 --> Final output sent to browser
DEBUG - 2023-11-14 16:27:27 --> Total execution time: 0.0398
ERROR - 2023-11-14 16:34:52 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-14 16:34:52 --> Config Class Initialized
INFO - 2023-11-14 16:34:52 --> Hooks Class Initialized
DEBUG - 2023-11-14 16:34:52 --> UTF-8 Support Enabled
INFO - 2023-11-14 16:34:52 --> Utf8 Class Initialized
INFO - 2023-11-14 16:34:52 --> URI Class Initialized
DEBUG - 2023-11-14 16:34:52 --> No URI present. Default controller set.
INFO - 2023-11-14 16:34:52 --> Router Class Initialized
INFO - 2023-11-14 16:34:52 --> Output Class Initialized
INFO - 2023-11-14 16:34:52 --> Security Class Initialized
DEBUG - 2023-11-14 16:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-14 16:34:52 --> Input Class Initialized
INFO - 2023-11-14 16:34:52 --> Language Class Initialized
INFO - 2023-11-14 16:34:52 --> Loader Class Initialized
INFO - 2023-11-14 16:34:52 --> Helper loaded: url_helper
INFO - 2023-11-14 16:34:52 --> Helper loaded: form_helper
INFO - 2023-11-14 16:34:52 --> Helper loaded: file_helper
INFO - 2023-11-14 16:34:52 --> Database Driver Class Initialized
DEBUG - 2023-11-14 16:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-14 16:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-14 16:34:52 --> Form Validation Class Initialized
INFO - 2023-11-14 16:34:52 --> Upload Class Initialized
INFO - 2023-11-14 16:34:52 --> Model "M_auth" initialized
INFO - 2023-11-14 16:34:52 --> Model "M_user" initialized
INFO - 2023-11-14 16:34:52 --> Model "M_produk" initialized
INFO - 2023-11-14 16:34:52 --> Controller Class Initialized
INFO - 2023-11-14 16:34:52 --> Model "M_pelanggan" initialized
INFO - 2023-11-14 16:34:52 --> Model "M_produk" initialized
DEBUG - 2023-11-14 16:34:52 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-14 16:34:52 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-14 16:34:52 --> Model "M_transaksi" initialized
INFO - 2023-11-14 16:34:52 --> Model "M_bank" initialized
INFO - 2023-11-14 16:34:52 --> Model "M_pesan" initialized
DEBUG - 2023-11-14 16:34:52 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-14 16:34:52 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-14 16:34:52 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-14 16:34:52 --> Final output sent to browser
DEBUG - 2023-11-14 16:34:52 --> Total execution time: 0.0306
ERROR - 2023-11-14 19:07:59 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-14 19:07:59 --> Config Class Initialized
INFO - 2023-11-14 19:07:59 --> Hooks Class Initialized
DEBUG - 2023-11-14 19:07:59 --> UTF-8 Support Enabled
INFO - 2023-11-14 19:07:59 --> Utf8 Class Initialized
INFO - 2023-11-14 19:07:59 --> URI Class Initialized
DEBUG - 2023-11-14 19:07:59 --> No URI present. Default controller set.
INFO - 2023-11-14 19:07:59 --> Router Class Initialized
INFO - 2023-11-14 19:07:59 --> Output Class Initialized
INFO - 2023-11-14 19:07:59 --> Security Class Initialized
DEBUG - 2023-11-14 19:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-14 19:07:59 --> Input Class Initialized
INFO - 2023-11-14 19:07:59 --> Language Class Initialized
INFO - 2023-11-14 19:07:59 --> Loader Class Initialized
INFO - 2023-11-14 19:07:59 --> Helper loaded: url_helper
INFO - 2023-11-14 19:07:59 --> Helper loaded: form_helper
INFO - 2023-11-14 19:07:59 --> Helper loaded: file_helper
INFO - 2023-11-14 19:07:59 --> Database Driver Class Initialized
DEBUG - 2023-11-14 19:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-14 19:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-14 19:07:59 --> Form Validation Class Initialized
INFO - 2023-11-14 19:07:59 --> Upload Class Initialized
INFO - 2023-11-14 19:07:59 --> Model "M_auth" initialized
INFO - 2023-11-14 19:07:59 --> Model "M_user" initialized
INFO - 2023-11-14 19:07:59 --> Model "M_produk" initialized
INFO - 2023-11-14 19:07:59 --> Controller Class Initialized
INFO - 2023-11-14 19:07:59 --> Model "M_pelanggan" initialized
INFO - 2023-11-14 19:07:59 --> Model "M_produk" initialized
DEBUG - 2023-11-14 19:07:59 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-14 19:07:59 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-14 19:07:59 --> Model "M_transaksi" initialized
INFO - 2023-11-14 19:07:59 --> Model "M_bank" initialized
INFO - 2023-11-14 19:07:59 --> Model "M_pesan" initialized
DEBUG - 2023-11-14 19:07:59 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-14 19:07:59 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-14 19:07:59 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-14 19:07:59 --> Final output sent to browser
DEBUG - 2023-11-14 19:07:59 --> Total execution time: 0.0341
ERROR - 2023-11-14 23:05:09 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-14 23:05:09 --> Config Class Initialized
INFO - 2023-11-14 23:05:09 --> Hooks Class Initialized
DEBUG - 2023-11-14 23:05:09 --> UTF-8 Support Enabled
INFO - 2023-11-14 23:05:09 --> Utf8 Class Initialized
INFO - 2023-11-14 23:05:09 --> URI Class Initialized
DEBUG - 2023-11-14 23:05:09 --> No URI present. Default controller set.
INFO - 2023-11-14 23:05:09 --> Router Class Initialized
INFO - 2023-11-14 23:05:09 --> Output Class Initialized
INFO - 2023-11-14 23:05:09 --> Security Class Initialized
DEBUG - 2023-11-14 23:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-14 23:05:09 --> Input Class Initialized
INFO - 2023-11-14 23:05:09 --> Language Class Initialized
INFO - 2023-11-14 23:05:09 --> Loader Class Initialized
INFO - 2023-11-14 23:05:09 --> Helper loaded: url_helper
INFO - 2023-11-14 23:05:09 --> Helper loaded: form_helper
INFO - 2023-11-14 23:05:09 --> Helper loaded: file_helper
INFO - 2023-11-14 23:05:09 --> Database Driver Class Initialized
DEBUG - 2023-11-14 23:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-14 23:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-14 23:05:09 --> Form Validation Class Initialized
INFO - 2023-11-14 23:05:09 --> Upload Class Initialized
INFO - 2023-11-14 23:05:09 --> Model "M_auth" initialized
INFO - 2023-11-14 23:05:09 --> Model "M_user" initialized
INFO - 2023-11-14 23:05:09 --> Model "M_produk" initialized
INFO - 2023-11-14 23:05:09 --> Controller Class Initialized
INFO - 2023-11-14 23:05:09 --> Model "M_pelanggan" initialized
INFO - 2023-11-14 23:05:09 --> Model "M_produk" initialized
DEBUG - 2023-11-14 23:05:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-14 23:05:09 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-14 23:05:09 --> Model "M_transaksi" initialized
INFO - 2023-11-14 23:05:09 --> Model "M_bank" initialized
INFO - 2023-11-14 23:05:09 --> Model "M_pesan" initialized
DEBUG - 2023-11-14 23:05:09 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-14 23:05:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-14 23:05:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-14 23:05:09 --> Final output sent to browser
DEBUG - 2023-11-14 23:05:09 --> Total execution time: 0.0470
