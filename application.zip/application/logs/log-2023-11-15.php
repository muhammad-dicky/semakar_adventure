<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-15 01:40:49 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-15 01:40:49 --> Config Class Initialized
INFO - 2023-11-15 01:40:49 --> Hooks Class Initialized
DEBUG - 2023-11-15 01:40:49 --> UTF-8 Support Enabled
INFO - 2023-11-15 01:40:49 --> Utf8 Class Initialized
INFO - 2023-11-15 01:40:49 --> URI Class Initialized
DEBUG - 2023-11-15 01:40:49 --> No URI present. Default controller set.
INFO - 2023-11-15 01:40:49 --> Router Class Initialized
INFO - 2023-11-15 01:40:49 --> Output Class Initialized
INFO - 2023-11-15 01:40:49 --> Security Class Initialized
DEBUG - 2023-11-15 01:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-15 01:40:49 --> Input Class Initialized
INFO - 2023-11-15 01:40:49 --> Language Class Initialized
INFO - 2023-11-15 01:40:49 --> Loader Class Initialized
INFO - 2023-11-15 01:40:49 --> Helper loaded: url_helper
INFO - 2023-11-15 01:40:49 --> Helper loaded: form_helper
INFO - 2023-11-15 01:40:49 --> Helper loaded: file_helper
INFO - 2023-11-15 01:40:49 --> Database Driver Class Initialized
DEBUG - 2023-11-15 01:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-15 01:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-15 01:40:49 --> Form Validation Class Initialized
INFO - 2023-11-15 01:40:49 --> Upload Class Initialized
INFO - 2023-11-15 01:40:49 --> Model "M_auth" initialized
INFO - 2023-11-15 01:40:49 --> Model "M_user" initialized
INFO - 2023-11-15 01:40:49 --> Model "M_produk" initialized
INFO - 2023-11-15 01:40:49 --> Controller Class Initialized
INFO - 2023-11-15 01:40:49 --> Model "M_pelanggan" initialized
INFO - 2023-11-15 01:40:49 --> Model "M_produk" initialized
DEBUG - 2023-11-15 01:40:49 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-15 01:40:49 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-15 01:40:49 --> Model "M_transaksi" initialized
INFO - 2023-11-15 01:40:49 --> Model "M_bank" initialized
INFO - 2023-11-15 01:40:49 --> Model "M_pesan" initialized
DEBUG - 2023-11-15 01:40:49 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-15 01:40:49 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-15 01:40:49 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-15 01:40:49 --> Final output sent to browser
DEBUG - 2023-11-15 01:40:49 --> Total execution time: 0.0449
ERROR - 2023-11-15 02:36:36 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-15 02:36:36 --> Config Class Initialized
INFO - 2023-11-15 02:36:36 --> Hooks Class Initialized
DEBUG - 2023-11-15 02:36:36 --> UTF-8 Support Enabled
INFO - 2023-11-15 02:36:36 --> Utf8 Class Initialized
INFO - 2023-11-15 02:36:36 --> URI Class Initialized
INFO - 2023-11-15 02:36:36 --> Router Class Initialized
INFO - 2023-11-15 02:36:36 --> Output Class Initialized
INFO - 2023-11-15 02:36:36 --> Security Class Initialized
DEBUG - 2023-11-15 02:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-15 02:36:36 --> Input Class Initialized
INFO - 2023-11-15 02:36:36 --> Language Class Initialized
INFO - 2023-11-15 02:36:36 --> Loader Class Initialized
INFO - 2023-11-15 02:36:36 --> Helper loaded: url_helper
INFO - 2023-11-15 02:36:36 --> Helper loaded: form_helper
INFO - 2023-11-15 02:36:36 --> Helper loaded: file_helper
INFO - 2023-11-15 02:36:36 --> Database Driver Class Initialized
DEBUG - 2023-11-15 02:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-15 02:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-15 02:36:36 --> Form Validation Class Initialized
INFO - 2023-11-15 02:36:36 --> Upload Class Initialized
INFO - 2023-11-15 02:36:36 --> Model "M_auth" initialized
INFO - 2023-11-15 02:36:36 --> Model "M_user" initialized
INFO - 2023-11-15 02:36:36 --> Model "M_produk" initialized
INFO - 2023-11-15 02:36:36 --> Controller Class Initialized
INFO - 2023-11-15 02:36:36 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-15 02:36:36 --> Final output sent to browser
DEBUG - 2023-11-15 02:36:36 --> Total execution time: 0.0269
ERROR - 2023-11-15 02:36:37 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-15 02:36:37 --> Config Class Initialized
INFO - 2023-11-15 02:36:37 --> Hooks Class Initialized
DEBUG - 2023-11-15 02:36:37 --> UTF-8 Support Enabled
INFO - 2023-11-15 02:36:37 --> Utf8 Class Initialized
INFO - 2023-11-15 02:36:37 --> URI Class Initialized
DEBUG - 2023-11-15 02:36:37 --> No URI present. Default controller set.
INFO - 2023-11-15 02:36:37 --> Router Class Initialized
INFO - 2023-11-15 02:36:37 --> Output Class Initialized
INFO - 2023-11-15 02:36:37 --> Security Class Initialized
DEBUG - 2023-11-15 02:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-15 02:36:37 --> Input Class Initialized
INFO - 2023-11-15 02:36:37 --> Language Class Initialized
INFO - 2023-11-15 02:36:37 --> Loader Class Initialized
INFO - 2023-11-15 02:36:37 --> Helper loaded: url_helper
INFO - 2023-11-15 02:36:37 --> Helper loaded: form_helper
INFO - 2023-11-15 02:36:37 --> Helper loaded: file_helper
INFO - 2023-11-15 02:36:37 --> Database Driver Class Initialized
DEBUG - 2023-11-15 02:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-15 02:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-15 02:36:37 --> Form Validation Class Initialized
INFO - 2023-11-15 02:36:37 --> Upload Class Initialized
INFO - 2023-11-15 02:36:37 --> Model "M_auth" initialized
INFO - 2023-11-15 02:36:37 --> Model "M_user" initialized
INFO - 2023-11-15 02:36:37 --> Model "M_produk" initialized
INFO - 2023-11-15 02:36:37 --> Controller Class Initialized
INFO - 2023-11-15 02:36:37 --> Model "M_pelanggan" initialized
INFO - 2023-11-15 02:36:37 --> Model "M_produk" initialized
DEBUG - 2023-11-15 02:36:37 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-15 02:36:37 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-15 02:36:37 --> Model "M_transaksi" initialized
INFO - 2023-11-15 02:36:37 --> Model "M_bank" initialized
INFO - 2023-11-15 02:36:37 --> Model "M_pesan" initialized
DEBUG - 2023-11-15 02:36:37 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-15 02:36:37 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-15 02:36:37 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-15 02:36:37 --> Final output sent to browser
DEBUG - 2023-11-15 02:36:37 --> Total execution time: 0.0093
ERROR - 2023-11-15 04:16:20 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-15 04:16:20 --> Config Class Initialized
INFO - 2023-11-15 04:16:20 --> Hooks Class Initialized
DEBUG - 2023-11-15 04:16:20 --> UTF-8 Support Enabled
INFO - 2023-11-15 04:16:20 --> Utf8 Class Initialized
INFO - 2023-11-15 04:16:20 --> URI Class Initialized
DEBUG - 2023-11-15 04:16:20 --> No URI present. Default controller set.
INFO - 2023-11-15 04:16:20 --> Router Class Initialized
INFO - 2023-11-15 04:16:20 --> Output Class Initialized
INFO - 2023-11-15 04:16:20 --> Security Class Initialized
DEBUG - 2023-11-15 04:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-15 04:16:20 --> Input Class Initialized
INFO - 2023-11-15 04:16:20 --> Language Class Initialized
INFO - 2023-11-15 04:16:20 --> Loader Class Initialized
INFO - 2023-11-15 04:16:20 --> Helper loaded: url_helper
INFO - 2023-11-15 04:16:20 --> Helper loaded: form_helper
INFO - 2023-11-15 04:16:20 --> Helper loaded: file_helper
INFO - 2023-11-15 04:16:20 --> Database Driver Class Initialized
DEBUG - 2023-11-15 04:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-15 04:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-15 04:16:20 --> Form Validation Class Initialized
INFO - 2023-11-15 04:16:20 --> Upload Class Initialized
INFO - 2023-11-15 04:16:20 --> Model "M_auth" initialized
INFO - 2023-11-15 04:16:20 --> Model "M_user" initialized
INFO - 2023-11-15 04:16:20 --> Model "M_produk" initialized
INFO - 2023-11-15 04:16:20 --> Controller Class Initialized
INFO - 2023-11-15 04:16:20 --> Model "M_pelanggan" initialized
INFO - 2023-11-15 04:16:20 --> Model "M_produk" initialized
DEBUG - 2023-11-15 04:16:20 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-15 04:16:20 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-15 04:16:20 --> Model "M_transaksi" initialized
INFO - 2023-11-15 04:16:20 --> Model "M_bank" initialized
INFO - 2023-11-15 04:16:20 --> Model "M_pesan" initialized
DEBUG - 2023-11-15 04:16:20 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-15 04:16:20 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-15 04:16:20 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-15 04:16:20 --> Final output sent to browser
DEBUG - 2023-11-15 04:16:20 --> Total execution time: 0.0495
ERROR - 2023-11-15 05:35:40 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-15 05:35:40 --> Config Class Initialized
INFO - 2023-11-15 05:35:40 --> Hooks Class Initialized
DEBUG - 2023-11-15 05:35:40 --> UTF-8 Support Enabled
INFO - 2023-11-15 05:35:40 --> Utf8 Class Initialized
INFO - 2023-11-15 05:35:40 --> URI Class Initialized
INFO - 2023-11-15 05:35:40 --> Router Class Initialized
INFO - 2023-11-15 05:35:40 --> Output Class Initialized
INFO - 2023-11-15 05:35:40 --> Security Class Initialized
DEBUG - 2023-11-15 05:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-15 05:35:40 --> Input Class Initialized
INFO - 2023-11-15 05:35:40 --> Language Class Initialized
INFO - 2023-11-15 05:35:40 --> Loader Class Initialized
INFO - 2023-11-15 05:35:40 --> Helper loaded: url_helper
INFO - 2023-11-15 05:35:40 --> Helper loaded: form_helper
INFO - 2023-11-15 05:35:40 --> Helper loaded: file_helper
INFO - 2023-11-15 05:35:40 --> Database Driver Class Initialized
DEBUG - 2023-11-15 05:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-15 05:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-15 05:35:40 --> Form Validation Class Initialized
INFO - 2023-11-15 05:35:40 --> Upload Class Initialized
INFO - 2023-11-15 05:35:40 --> Model "M_auth" initialized
INFO - 2023-11-15 05:35:40 --> Model "M_user" initialized
INFO - 2023-11-15 05:35:40 --> Model "M_produk" initialized
INFO - 2023-11-15 05:35:40 --> Controller Class Initialized
INFO - 2023-11-15 05:35:40 --> Model "M_pelanggan" initialized
INFO - 2023-11-15 05:35:40 --> Model "M_produk" initialized
DEBUG - 2023-11-15 05:35:40 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-15 05:35:40 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-15 05:35:40 --> Model "M_transaksi" initialized
INFO - 2023-11-15 05:35:40 --> Model "M_bank" initialized
INFO - 2023-11-15 05:35:40 --> Model "M_pesan" initialized
DEBUG - 2023-11-15 05:35:40 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-15 05:35:40 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-15 05:35:40 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-15 05:35:40 --> Final output sent to browser
DEBUG - 2023-11-15 05:35:40 --> Total execution time: 0.0469
ERROR - 2023-11-15 08:59:15 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-15 08:59:15 --> Config Class Initialized
INFO - 2023-11-15 08:59:15 --> Hooks Class Initialized
DEBUG - 2023-11-15 08:59:15 --> UTF-8 Support Enabled
INFO - 2023-11-15 08:59:15 --> Utf8 Class Initialized
INFO - 2023-11-15 08:59:15 --> URI Class Initialized
DEBUG - 2023-11-15 08:59:15 --> No URI present. Default controller set.
INFO - 2023-11-15 08:59:15 --> Router Class Initialized
INFO - 2023-11-15 08:59:15 --> Output Class Initialized
INFO - 2023-11-15 08:59:15 --> Security Class Initialized
DEBUG - 2023-11-15 08:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-15 08:59:15 --> Input Class Initialized
INFO - 2023-11-15 08:59:15 --> Language Class Initialized
INFO - 2023-11-15 08:59:15 --> Loader Class Initialized
INFO - 2023-11-15 08:59:15 --> Helper loaded: url_helper
INFO - 2023-11-15 08:59:15 --> Helper loaded: form_helper
INFO - 2023-11-15 08:59:15 --> Helper loaded: file_helper
INFO - 2023-11-15 08:59:15 --> Database Driver Class Initialized
DEBUG - 2023-11-15 08:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-15 08:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-15 08:59:15 --> Form Validation Class Initialized
INFO - 2023-11-15 08:59:15 --> Upload Class Initialized
INFO - 2023-11-15 08:59:15 --> Model "M_auth" initialized
INFO - 2023-11-15 08:59:15 --> Model "M_user" initialized
INFO - 2023-11-15 08:59:15 --> Model "M_produk" initialized
INFO - 2023-11-15 08:59:15 --> Controller Class Initialized
INFO - 2023-11-15 08:59:15 --> Model "M_pelanggan" initialized
INFO - 2023-11-15 08:59:15 --> Model "M_produk" initialized
DEBUG - 2023-11-15 08:59:15 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-15 08:59:15 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-15 08:59:15 --> Model "M_transaksi" initialized
INFO - 2023-11-15 08:59:15 --> Model "M_bank" initialized
INFO - 2023-11-15 08:59:15 --> Model "M_pesan" initialized
DEBUG - 2023-11-15 08:59:15 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-15 08:59:15 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-15 08:59:15 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-15 08:59:15 --> Final output sent to browser
DEBUG - 2023-11-15 08:59:15 --> Total execution time: 0.0491
ERROR - 2023-11-15 11:07:48 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-15 11:07:48 --> Config Class Initialized
INFO - 2023-11-15 11:07:48 --> Hooks Class Initialized
DEBUG - 2023-11-15 11:07:48 --> UTF-8 Support Enabled
INFO - 2023-11-15 11:07:48 --> Utf8 Class Initialized
INFO - 2023-11-15 11:07:48 --> URI Class Initialized
DEBUG - 2023-11-15 11:07:48 --> No URI present. Default controller set.
INFO - 2023-11-15 11:07:48 --> Router Class Initialized
INFO - 2023-11-15 11:07:48 --> Output Class Initialized
INFO - 2023-11-15 11:07:48 --> Security Class Initialized
DEBUG - 2023-11-15 11:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-15 11:07:48 --> Input Class Initialized
INFO - 2023-11-15 11:07:48 --> Language Class Initialized
INFO - 2023-11-15 11:07:48 --> Loader Class Initialized
INFO - 2023-11-15 11:07:48 --> Helper loaded: url_helper
INFO - 2023-11-15 11:07:48 --> Helper loaded: form_helper
INFO - 2023-11-15 11:07:48 --> Helper loaded: file_helper
INFO - 2023-11-15 11:07:48 --> Database Driver Class Initialized
DEBUG - 2023-11-15 11:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-15 11:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-15 11:07:48 --> Form Validation Class Initialized
INFO - 2023-11-15 11:07:48 --> Upload Class Initialized
INFO - 2023-11-15 11:07:48 --> Model "M_auth" initialized
INFO - 2023-11-15 11:07:48 --> Model "M_user" initialized
INFO - 2023-11-15 11:07:48 --> Model "M_produk" initialized
INFO - 2023-11-15 11:07:48 --> Controller Class Initialized
INFO - 2023-11-15 11:07:48 --> Model "M_pelanggan" initialized
INFO - 2023-11-15 11:07:48 --> Model "M_produk" initialized
DEBUG - 2023-11-15 11:07:48 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-15 11:07:48 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-15 11:07:48 --> Model "M_transaksi" initialized
INFO - 2023-11-15 11:07:48 --> Model "M_bank" initialized
INFO - 2023-11-15 11:07:48 --> Model "M_pesan" initialized
DEBUG - 2023-11-15 11:07:48 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-15 11:07:48 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-15 11:07:48 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-15 11:07:48 --> Final output sent to browser
DEBUG - 2023-11-15 11:07:48 --> Total execution time: 0.0321
ERROR - 2023-11-15 11:37:05 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-15 11:37:05 --> Config Class Initialized
INFO - 2023-11-15 11:37:05 --> Hooks Class Initialized
DEBUG - 2023-11-15 11:37:05 --> UTF-8 Support Enabled
INFO - 2023-11-15 11:37:05 --> Utf8 Class Initialized
INFO - 2023-11-15 11:37:05 --> URI Class Initialized
DEBUG - 2023-11-15 11:37:05 --> No URI present. Default controller set.
INFO - 2023-11-15 11:37:05 --> Router Class Initialized
INFO - 2023-11-15 11:37:05 --> Output Class Initialized
INFO - 2023-11-15 11:37:05 --> Security Class Initialized
DEBUG - 2023-11-15 11:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-15 11:37:05 --> Input Class Initialized
INFO - 2023-11-15 11:37:05 --> Language Class Initialized
INFO - 2023-11-15 11:37:05 --> Loader Class Initialized
INFO - 2023-11-15 11:37:05 --> Helper loaded: url_helper
INFO - 2023-11-15 11:37:05 --> Helper loaded: form_helper
INFO - 2023-11-15 11:37:05 --> Helper loaded: file_helper
INFO - 2023-11-15 11:37:05 --> Database Driver Class Initialized
DEBUG - 2023-11-15 11:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-15 11:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-15 11:37:05 --> Form Validation Class Initialized
INFO - 2023-11-15 11:37:05 --> Upload Class Initialized
INFO - 2023-11-15 11:37:05 --> Model "M_auth" initialized
INFO - 2023-11-15 11:37:05 --> Model "M_user" initialized
INFO - 2023-11-15 11:37:05 --> Model "M_produk" initialized
INFO - 2023-11-15 11:37:05 --> Controller Class Initialized
INFO - 2023-11-15 11:37:05 --> Model "M_pelanggan" initialized
INFO - 2023-11-15 11:37:05 --> Model "M_produk" initialized
DEBUG - 2023-11-15 11:37:05 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-15 11:37:05 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-15 11:37:05 --> Model "M_transaksi" initialized
INFO - 2023-11-15 11:37:05 --> Model "M_bank" initialized
INFO - 2023-11-15 11:37:05 --> Model "M_pesan" initialized
DEBUG - 2023-11-15 11:37:05 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-15 11:37:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-15 11:37:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-15 11:37:05 --> Final output sent to browser
DEBUG - 2023-11-15 11:37:05 --> Total execution time: 0.0365
ERROR - 2023-11-15 12:04:19 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-15 12:04:19 --> Config Class Initialized
INFO - 2023-11-15 12:04:19 --> Hooks Class Initialized
DEBUG - 2023-11-15 12:04:19 --> UTF-8 Support Enabled
INFO - 2023-11-15 12:04:19 --> Utf8 Class Initialized
INFO - 2023-11-15 12:04:19 --> URI Class Initialized
DEBUG - 2023-11-15 12:04:19 --> No URI present. Default controller set.
INFO - 2023-11-15 12:04:19 --> Router Class Initialized
INFO - 2023-11-15 12:04:19 --> Output Class Initialized
INFO - 2023-11-15 12:04:19 --> Security Class Initialized
DEBUG - 2023-11-15 12:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-15 12:04:19 --> Input Class Initialized
INFO - 2023-11-15 12:04:19 --> Language Class Initialized
INFO - 2023-11-15 12:04:19 --> Loader Class Initialized
INFO - 2023-11-15 12:04:19 --> Helper loaded: url_helper
INFO - 2023-11-15 12:04:19 --> Helper loaded: form_helper
INFO - 2023-11-15 12:04:19 --> Helper loaded: file_helper
INFO - 2023-11-15 12:04:19 --> Database Driver Class Initialized
DEBUG - 2023-11-15 12:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-15 12:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-15 12:04:19 --> Form Validation Class Initialized
INFO - 2023-11-15 12:04:19 --> Upload Class Initialized
INFO - 2023-11-15 12:04:19 --> Model "M_auth" initialized
INFO - 2023-11-15 12:04:19 --> Model "M_user" initialized
INFO - 2023-11-15 12:04:19 --> Model "M_produk" initialized
INFO - 2023-11-15 12:04:19 --> Controller Class Initialized
INFO - 2023-11-15 12:04:19 --> Model "M_pelanggan" initialized
INFO - 2023-11-15 12:04:19 --> Model "M_produk" initialized
DEBUG - 2023-11-15 12:04:19 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-15 12:04:19 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-15 12:04:19 --> Model "M_transaksi" initialized
INFO - 2023-11-15 12:04:19 --> Model "M_bank" initialized
INFO - 2023-11-15 12:04:19 --> Model "M_pesan" initialized
DEBUG - 2023-11-15 12:04:19 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-15 12:04:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-15 12:04:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-15 12:04:19 --> Final output sent to browser
DEBUG - 2023-11-15 12:04:19 --> Total execution time: 0.0377
ERROR - 2023-11-15 13:13:57 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-15 13:13:57 --> Config Class Initialized
INFO - 2023-11-15 13:13:57 --> Hooks Class Initialized
DEBUG - 2023-11-15 13:13:57 --> UTF-8 Support Enabled
INFO - 2023-11-15 13:13:57 --> Utf8 Class Initialized
INFO - 2023-11-15 13:13:57 --> URI Class Initialized
INFO - 2023-11-15 13:13:57 --> Router Class Initialized
INFO - 2023-11-15 13:13:57 --> Output Class Initialized
INFO - 2023-11-15 13:13:57 --> Security Class Initialized
DEBUG - 2023-11-15 13:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-15 13:13:57 --> Input Class Initialized
INFO - 2023-11-15 13:13:57 --> Language Class Initialized
INFO - 2023-11-15 13:13:57 --> Loader Class Initialized
INFO - 2023-11-15 13:13:57 --> Helper loaded: url_helper
INFO - 2023-11-15 13:13:57 --> Helper loaded: form_helper
INFO - 2023-11-15 13:13:57 --> Helper loaded: file_helper
INFO - 2023-11-15 13:13:57 --> Database Driver Class Initialized
DEBUG - 2023-11-15 13:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-15 13:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-15 13:13:57 --> Form Validation Class Initialized
INFO - 2023-11-15 13:13:57 --> Upload Class Initialized
INFO - 2023-11-15 13:13:57 --> Model "M_auth" initialized
INFO - 2023-11-15 13:13:57 --> Model "M_user" initialized
INFO - 2023-11-15 13:13:57 --> Model "M_produk" initialized
INFO - 2023-11-15 13:13:57 --> Controller Class Initialized
INFO - 2023-11-15 13:13:57 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-15 13:13:57 --> Final output sent to browser
DEBUG - 2023-11-15 13:13:57 --> Total execution time: 0.0288
ERROR - 2023-11-15 13:13:59 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-15 13:13:59 --> Config Class Initialized
INFO - 2023-11-15 13:13:59 --> Hooks Class Initialized
DEBUG - 2023-11-15 13:13:59 --> UTF-8 Support Enabled
INFO - 2023-11-15 13:13:59 --> Utf8 Class Initialized
INFO - 2023-11-15 13:13:59 --> URI Class Initialized
DEBUG - 2023-11-15 13:13:59 --> No URI present. Default controller set.
INFO - 2023-11-15 13:13:59 --> Router Class Initialized
INFO - 2023-11-15 13:13:59 --> Output Class Initialized
INFO - 2023-11-15 13:13:59 --> Security Class Initialized
DEBUG - 2023-11-15 13:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-15 13:13:59 --> Input Class Initialized
INFO - 2023-11-15 13:13:59 --> Language Class Initialized
INFO - 2023-11-15 13:13:59 --> Loader Class Initialized
INFO - 2023-11-15 13:13:59 --> Helper loaded: url_helper
INFO - 2023-11-15 13:13:59 --> Helper loaded: form_helper
INFO - 2023-11-15 13:13:59 --> Helper loaded: file_helper
INFO - 2023-11-15 13:13:59 --> Database Driver Class Initialized
DEBUG - 2023-11-15 13:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-15 13:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-15 13:13:59 --> Form Validation Class Initialized
INFO - 2023-11-15 13:13:59 --> Upload Class Initialized
INFO - 2023-11-15 13:13:59 --> Model "M_auth" initialized
INFO - 2023-11-15 13:13:59 --> Model "M_user" initialized
INFO - 2023-11-15 13:13:59 --> Model "M_produk" initialized
INFO - 2023-11-15 13:13:59 --> Controller Class Initialized
INFO - 2023-11-15 13:13:59 --> Model "M_pelanggan" initialized
INFO - 2023-11-15 13:13:59 --> Model "M_produk" initialized
DEBUG - 2023-11-15 13:13:59 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-15 13:13:59 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-15 13:13:59 --> Model "M_transaksi" initialized
INFO - 2023-11-15 13:13:59 --> Model "M_bank" initialized
INFO - 2023-11-15 13:13:59 --> Model "M_pesan" initialized
DEBUG - 2023-11-15 13:13:59 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-15 13:13:59 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-15 13:13:59 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-15 13:13:59 --> Final output sent to browser
DEBUG - 2023-11-15 13:13:59 --> Total execution time: 0.0094
ERROR - 2023-11-15 13:19:39 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-15 13:19:39 --> Config Class Initialized
INFO - 2023-11-15 13:19:39 --> Hooks Class Initialized
DEBUG - 2023-11-15 13:19:39 --> UTF-8 Support Enabled
INFO - 2023-11-15 13:19:39 --> Utf8 Class Initialized
INFO - 2023-11-15 13:19:39 --> URI Class Initialized
DEBUG - 2023-11-15 13:19:39 --> No URI present. Default controller set.
INFO - 2023-11-15 13:19:39 --> Router Class Initialized
INFO - 2023-11-15 13:19:39 --> Output Class Initialized
INFO - 2023-11-15 13:19:39 --> Security Class Initialized
DEBUG - 2023-11-15 13:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-15 13:19:39 --> Input Class Initialized
INFO - 2023-11-15 13:19:39 --> Language Class Initialized
INFO - 2023-11-15 13:19:39 --> Loader Class Initialized
INFO - 2023-11-15 13:19:39 --> Helper loaded: url_helper
INFO - 2023-11-15 13:19:39 --> Helper loaded: form_helper
INFO - 2023-11-15 13:19:39 --> Helper loaded: file_helper
INFO - 2023-11-15 13:19:39 --> Database Driver Class Initialized
DEBUG - 2023-11-15 13:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-15 13:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-15 13:19:39 --> Form Validation Class Initialized
INFO - 2023-11-15 13:19:39 --> Upload Class Initialized
INFO - 2023-11-15 13:19:39 --> Model "M_auth" initialized
INFO - 2023-11-15 13:19:39 --> Model "M_user" initialized
INFO - 2023-11-15 13:19:39 --> Model "M_produk" initialized
INFO - 2023-11-15 13:19:39 --> Controller Class Initialized
INFO - 2023-11-15 13:19:39 --> Model "M_pelanggan" initialized
INFO - 2023-11-15 13:19:39 --> Model "M_produk" initialized
DEBUG - 2023-11-15 13:19:39 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-15 13:19:39 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-15 13:19:39 --> Model "M_transaksi" initialized
INFO - 2023-11-15 13:19:39 --> Model "M_bank" initialized
INFO - 2023-11-15 13:19:39 --> Model "M_pesan" initialized
DEBUG - 2023-11-15 13:19:39 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-15 13:19:39 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-15 13:19:39 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-15 13:19:39 --> Final output sent to browser
DEBUG - 2023-11-15 13:19:39 --> Total execution time: 0.0342
ERROR - 2023-11-15 14:13:38 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-15 14:13:38 --> Config Class Initialized
INFO - 2023-11-15 14:13:38 --> Hooks Class Initialized
DEBUG - 2023-11-15 14:13:38 --> UTF-8 Support Enabled
INFO - 2023-11-15 14:13:38 --> Utf8 Class Initialized
INFO - 2023-11-15 14:13:38 --> URI Class Initialized
INFO - 2023-11-15 14:13:38 --> Router Class Initialized
INFO - 2023-11-15 14:13:38 --> Output Class Initialized
INFO - 2023-11-15 14:13:38 --> Security Class Initialized
DEBUG - 2023-11-15 14:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-15 14:13:38 --> Input Class Initialized
INFO - 2023-11-15 14:13:38 --> Language Class Initialized
INFO - 2023-11-15 14:13:38 --> Loader Class Initialized
INFO - 2023-11-15 14:13:38 --> Helper loaded: url_helper
INFO - 2023-11-15 14:13:38 --> Helper loaded: form_helper
INFO - 2023-11-15 14:13:38 --> Helper loaded: file_helper
INFO - 2023-11-15 14:13:38 --> Database Driver Class Initialized
DEBUG - 2023-11-15 14:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-15 14:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-15 14:13:38 --> Form Validation Class Initialized
INFO - 2023-11-15 14:13:38 --> Upload Class Initialized
INFO - 2023-11-15 14:13:38 --> Model "M_auth" initialized
INFO - 2023-11-15 14:13:38 --> Model "M_user" initialized
INFO - 2023-11-15 14:13:38 --> Model "M_produk" initialized
INFO - 2023-11-15 14:13:38 --> Controller Class Initialized
INFO - 2023-11-15 14:13:38 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-15 14:13:38 --> Final output sent to browser
DEBUG - 2023-11-15 14:13:38 --> Total execution time: 0.0284
ERROR - 2023-11-15 14:13:39 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-15 14:13:39 --> Config Class Initialized
INFO - 2023-11-15 14:13:39 --> Hooks Class Initialized
DEBUG - 2023-11-15 14:13:39 --> UTF-8 Support Enabled
INFO - 2023-11-15 14:13:39 --> Utf8 Class Initialized
INFO - 2023-11-15 14:13:39 --> URI Class Initialized
DEBUG - 2023-11-15 14:13:39 --> No URI present. Default controller set.
INFO - 2023-11-15 14:13:39 --> Router Class Initialized
INFO - 2023-11-15 14:13:39 --> Output Class Initialized
INFO - 2023-11-15 14:13:39 --> Security Class Initialized
DEBUG - 2023-11-15 14:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-15 14:13:39 --> Input Class Initialized
INFO - 2023-11-15 14:13:39 --> Language Class Initialized
INFO - 2023-11-15 14:13:39 --> Loader Class Initialized
INFO - 2023-11-15 14:13:39 --> Helper loaded: url_helper
INFO - 2023-11-15 14:13:39 --> Helper loaded: form_helper
INFO - 2023-11-15 14:13:39 --> Helper loaded: file_helper
INFO - 2023-11-15 14:13:39 --> Database Driver Class Initialized
DEBUG - 2023-11-15 14:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-15 14:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-15 14:13:39 --> Form Validation Class Initialized
INFO - 2023-11-15 14:13:39 --> Upload Class Initialized
INFO - 2023-11-15 14:13:39 --> Model "M_auth" initialized
INFO - 2023-11-15 14:13:39 --> Model "M_user" initialized
INFO - 2023-11-15 14:13:39 --> Model "M_produk" initialized
INFO - 2023-11-15 14:13:39 --> Controller Class Initialized
INFO - 2023-11-15 14:13:39 --> Model "M_pelanggan" initialized
INFO - 2023-11-15 14:13:39 --> Model "M_produk" initialized
DEBUG - 2023-11-15 14:13:39 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-15 14:13:39 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-15 14:13:39 --> Model "M_transaksi" initialized
INFO - 2023-11-15 14:13:39 --> Model "M_bank" initialized
INFO - 2023-11-15 14:13:39 --> Model "M_pesan" initialized
DEBUG - 2023-11-15 14:13:39 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-15 14:13:39 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-15 14:13:39 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-15 14:13:39 --> Final output sent to browser
DEBUG - 2023-11-15 14:13:39 --> Total execution time: 0.0108
ERROR - 2023-11-15 14:38:44 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-15 14:38:44 --> Config Class Initialized
INFO - 2023-11-15 14:38:44 --> Hooks Class Initialized
DEBUG - 2023-11-15 14:38:44 --> UTF-8 Support Enabled
INFO - 2023-11-15 14:38:44 --> Utf8 Class Initialized
INFO - 2023-11-15 14:38:44 --> URI Class Initialized
DEBUG - 2023-11-15 14:38:44 --> No URI present. Default controller set.
INFO - 2023-11-15 14:38:44 --> Router Class Initialized
INFO - 2023-11-15 14:38:44 --> Output Class Initialized
INFO - 2023-11-15 14:38:44 --> Security Class Initialized
DEBUG - 2023-11-15 14:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-15 14:38:44 --> Input Class Initialized
INFO - 2023-11-15 14:38:44 --> Language Class Initialized
INFO - 2023-11-15 14:38:44 --> Loader Class Initialized
INFO - 2023-11-15 14:38:44 --> Helper loaded: url_helper
INFO - 2023-11-15 14:38:44 --> Helper loaded: form_helper
INFO - 2023-11-15 14:38:44 --> Helper loaded: file_helper
INFO - 2023-11-15 14:38:44 --> Database Driver Class Initialized
DEBUG - 2023-11-15 14:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-15 14:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-15 14:38:44 --> Form Validation Class Initialized
INFO - 2023-11-15 14:38:44 --> Upload Class Initialized
INFO - 2023-11-15 14:38:44 --> Model "M_auth" initialized
INFO - 2023-11-15 14:38:44 --> Model "M_user" initialized
INFO - 2023-11-15 14:38:44 --> Model "M_produk" initialized
INFO - 2023-11-15 14:38:44 --> Controller Class Initialized
INFO - 2023-11-15 14:38:44 --> Model "M_pelanggan" initialized
INFO - 2023-11-15 14:38:44 --> Model "M_produk" initialized
DEBUG - 2023-11-15 14:38:44 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-15 14:38:44 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-15 14:38:44 --> Model "M_transaksi" initialized
INFO - 2023-11-15 14:38:44 --> Model "M_bank" initialized
INFO - 2023-11-15 14:38:44 --> Model "M_pesan" initialized
DEBUG - 2023-11-15 14:38:44 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-15 14:38:44 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-15 14:38:44 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-15 14:38:44 --> Final output sent to browser
DEBUG - 2023-11-15 14:38:44 --> Total execution time: 0.0355
ERROR - 2023-11-15 16:37:55 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-15 16:37:55 --> Config Class Initialized
INFO - 2023-11-15 16:37:55 --> Hooks Class Initialized
DEBUG - 2023-11-15 16:37:55 --> UTF-8 Support Enabled
INFO - 2023-11-15 16:37:55 --> Utf8 Class Initialized
INFO - 2023-11-15 16:37:55 --> URI Class Initialized
DEBUG - 2023-11-15 16:37:55 --> No URI present. Default controller set.
INFO - 2023-11-15 16:37:55 --> Router Class Initialized
INFO - 2023-11-15 16:37:55 --> Output Class Initialized
INFO - 2023-11-15 16:37:55 --> Security Class Initialized
DEBUG - 2023-11-15 16:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-15 16:37:55 --> Input Class Initialized
INFO - 2023-11-15 16:37:55 --> Language Class Initialized
INFO - 2023-11-15 16:37:55 --> Loader Class Initialized
INFO - 2023-11-15 16:37:55 --> Helper loaded: url_helper
INFO - 2023-11-15 16:37:55 --> Helper loaded: form_helper
INFO - 2023-11-15 16:37:55 --> Helper loaded: file_helper
INFO - 2023-11-15 16:37:55 --> Database Driver Class Initialized
DEBUG - 2023-11-15 16:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-15 16:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-15 16:37:55 --> Form Validation Class Initialized
INFO - 2023-11-15 16:37:55 --> Upload Class Initialized
INFO - 2023-11-15 16:37:55 --> Model "M_auth" initialized
INFO - 2023-11-15 16:37:55 --> Model "M_user" initialized
INFO - 2023-11-15 16:37:55 --> Model "M_produk" initialized
INFO - 2023-11-15 16:37:55 --> Controller Class Initialized
INFO - 2023-11-15 16:37:55 --> Model "M_pelanggan" initialized
INFO - 2023-11-15 16:37:55 --> Model "M_produk" initialized
DEBUG - 2023-11-15 16:37:55 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-15 16:37:55 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-15 16:37:55 --> Model "M_transaksi" initialized
INFO - 2023-11-15 16:37:55 --> Model "M_bank" initialized
INFO - 2023-11-15 16:37:55 --> Model "M_pesan" initialized
DEBUG - 2023-11-15 16:37:55 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-15 16:37:55 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-15 16:37:55 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-15 16:37:55 --> Final output sent to browser
DEBUG - 2023-11-15 16:37:55 --> Total execution time: 0.0335
ERROR - 2023-11-15 17:21:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-15 17:21:45 --> Config Class Initialized
INFO - 2023-11-15 17:21:45 --> Hooks Class Initialized
DEBUG - 2023-11-15 17:21:45 --> UTF-8 Support Enabled
INFO - 2023-11-15 17:21:45 --> Utf8 Class Initialized
INFO - 2023-11-15 17:21:45 --> URI Class Initialized
DEBUG - 2023-11-15 17:21:45 --> No URI present. Default controller set.
INFO - 2023-11-15 17:21:45 --> Router Class Initialized
INFO - 2023-11-15 17:21:45 --> Output Class Initialized
INFO - 2023-11-15 17:21:45 --> Security Class Initialized
DEBUG - 2023-11-15 17:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-15 17:21:45 --> Input Class Initialized
INFO - 2023-11-15 17:21:45 --> Language Class Initialized
INFO - 2023-11-15 17:21:45 --> Loader Class Initialized
INFO - 2023-11-15 17:21:45 --> Helper loaded: url_helper
INFO - 2023-11-15 17:21:45 --> Helper loaded: form_helper
INFO - 2023-11-15 17:21:45 --> Helper loaded: file_helper
INFO - 2023-11-15 17:21:45 --> Database Driver Class Initialized
DEBUG - 2023-11-15 17:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-15 17:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-15 17:21:45 --> Form Validation Class Initialized
INFO - 2023-11-15 17:21:45 --> Upload Class Initialized
INFO - 2023-11-15 17:21:45 --> Model "M_auth" initialized
INFO - 2023-11-15 17:21:45 --> Model "M_user" initialized
INFO - 2023-11-15 17:21:45 --> Model "M_produk" initialized
INFO - 2023-11-15 17:21:45 --> Controller Class Initialized
INFO - 2023-11-15 17:21:45 --> Model "M_pelanggan" initialized
INFO - 2023-11-15 17:21:45 --> Model "M_produk" initialized
DEBUG - 2023-11-15 17:21:45 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-15 17:21:45 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-15 17:21:45 --> Model "M_transaksi" initialized
INFO - 2023-11-15 17:21:45 --> Model "M_bank" initialized
INFO - 2023-11-15 17:21:45 --> Model "M_pesan" initialized
DEBUG - 2023-11-15 17:21:45 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-15 17:21:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-15 17:21:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-15 17:21:45 --> Final output sent to browser
DEBUG - 2023-11-15 17:21:45 --> Total execution time: 0.0365
ERROR - 2023-11-15 18:25:42 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-15 18:25:42 --> Config Class Initialized
INFO - 2023-11-15 18:25:42 --> Hooks Class Initialized
DEBUG - 2023-11-15 18:25:42 --> UTF-8 Support Enabled
INFO - 2023-11-15 18:25:42 --> Utf8 Class Initialized
INFO - 2023-11-15 18:25:42 --> URI Class Initialized
INFO - 2023-11-15 18:25:42 --> Router Class Initialized
INFO - 2023-11-15 18:25:42 --> Output Class Initialized
INFO - 2023-11-15 18:25:42 --> Security Class Initialized
DEBUG - 2023-11-15 18:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-15 18:25:42 --> Input Class Initialized
INFO - 2023-11-15 18:25:42 --> Language Class Initialized
INFO - 2023-11-15 18:25:42 --> Loader Class Initialized
INFO - 2023-11-15 18:25:42 --> Helper loaded: url_helper
INFO - 2023-11-15 18:25:42 --> Helper loaded: form_helper
INFO - 2023-11-15 18:25:42 --> Helper loaded: file_helper
INFO - 2023-11-15 18:25:42 --> Database Driver Class Initialized
DEBUG - 2023-11-15 18:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-15 18:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-15 18:25:42 --> Form Validation Class Initialized
INFO - 2023-11-15 18:25:42 --> Upload Class Initialized
INFO - 2023-11-15 18:25:42 --> Model "M_auth" initialized
INFO - 2023-11-15 18:25:42 --> Model "M_user" initialized
INFO - 2023-11-15 18:25:42 --> Model "M_produk" initialized
INFO - 2023-11-15 18:25:42 --> Controller Class Initialized
INFO - 2023-11-15 18:25:42 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-15 18:25:42 --> Final output sent to browser
DEBUG - 2023-11-15 18:25:42 --> Total execution time: 0.0292
ERROR - 2023-11-15 18:25:44 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-15 18:25:44 --> Config Class Initialized
INFO - 2023-11-15 18:25:44 --> Hooks Class Initialized
DEBUG - 2023-11-15 18:25:44 --> UTF-8 Support Enabled
INFO - 2023-11-15 18:25:44 --> Utf8 Class Initialized
INFO - 2023-11-15 18:25:44 --> URI Class Initialized
DEBUG - 2023-11-15 18:25:44 --> No URI present. Default controller set.
INFO - 2023-11-15 18:25:44 --> Router Class Initialized
INFO - 2023-11-15 18:25:44 --> Output Class Initialized
INFO - 2023-11-15 18:25:44 --> Security Class Initialized
DEBUG - 2023-11-15 18:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-15 18:25:44 --> Input Class Initialized
INFO - 2023-11-15 18:25:44 --> Language Class Initialized
INFO - 2023-11-15 18:25:44 --> Loader Class Initialized
INFO - 2023-11-15 18:25:44 --> Helper loaded: url_helper
INFO - 2023-11-15 18:25:44 --> Helper loaded: form_helper
INFO - 2023-11-15 18:25:44 --> Helper loaded: file_helper
INFO - 2023-11-15 18:25:44 --> Database Driver Class Initialized
DEBUG - 2023-11-15 18:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-15 18:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-15 18:25:44 --> Form Validation Class Initialized
INFO - 2023-11-15 18:25:44 --> Upload Class Initialized
INFO - 2023-11-15 18:25:44 --> Model "M_auth" initialized
INFO - 2023-11-15 18:25:44 --> Model "M_user" initialized
INFO - 2023-11-15 18:25:44 --> Model "M_produk" initialized
INFO - 2023-11-15 18:25:44 --> Controller Class Initialized
INFO - 2023-11-15 18:25:44 --> Model "M_pelanggan" initialized
INFO - 2023-11-15 18:25:44 --> Model "M_produk" initialized
DEBUG - 2023-11-15 18:25:44 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-15 18:25:44 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-15 18:25:44 --> Model "M_transaksi" initialized
INFO - 2023-11-15 18:25:44 --> Model "M_bank" initialized
INFO - 2023-11-15 18:25:44 --> Model "M_pesan" initialized
DEBUG - 2023-11-15 18:25:44 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-15 18:25:44 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-15 18:25:44 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-15 18:25:44 --> Final output sent to browser
DEBUG - 2023-11-15 18:25:44 --> Total execution time: 0.0091
ERROR - 2023-11-15 19:05:57 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-15 19:05:57 --> Config Class Initialized
INFO - 2023-11-15 19:05:57 --> Hooks Class Initialized
DEBUG - 2023-11-15 19:05:57 --> UTF-8 Support Enabled
INFO - 2023-11-15 19:05:57 --> Utf8 Class Initialized
INFO - 2023-11-15 19:05:57 --> URI Class Initialized
DEBUG - 2023-11-15 19:05:57 --> No URI present. Default controller set.
INFO - 2023-11-15 19:05:57 --> Router Class Initialized
INFO - 2023-11-15 19:05:57 --> Output Class Initialized
INFO - 2023-11-15 19:05:57 --> Security Class Initialized
DEBUG - 2023-11-15 19:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-15 19:05:57 --> Input Class Initialized
INFO - 2023-11-15 19:05:57 --> Language Class Initialized
INFO - 2023-11-15 19:05:57 --> Loader Class Initialized
INFO - 2023-11-15 19:05:57 --> Helper loaded: url_helper
INFO - 2023-11-15 19:05:57 --> Helper loaded: form_helper
INFO - 2023-11-15 19:05:57 --> Helper loaded: file_helper
INFO - 2023-11-15 19:05:57 --> Database Driver Class Initialized
DEBUG - 2023-11-15 19:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-15 19:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-15 19:05:57 --> Form Validation Class Initialized
INFO - 2023-11-15 19:05:57 --> Upload Class Initialized
INFO - 2023-11-15 19:05:57 --> Model "M_auth" initialized
INFO - 2023-11-15 19:05:57 --> Model "M_user" initialized
INFO - 2023-11-15 19:05:57 --> Model "M_produk" initialized
INFO - 2023-11-15 19:05:57 --> Controller Class Initialized
INFO - 2023-11-15 19:05:57 --> Model "M_pelanggan" initialized
INFO - 2023-11-15 19:05:57 --> Model "M_produk" initialized
DEBUG - 2023-11-15 19:05:57 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-15 19:05:57 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-15 19:05:57 --> Model "M_transaksi" initialized
INFO - 2023-11-15 19:05:57 --> Model "M_bank" initialized
INFO - 2023-11-15 19:05:57 --> Model "M_pesan" initialized
DEBUG - 2023-11-15 19:05:57 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-15 19:05:57 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-15 19:05:57 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-15 19:05:57 --> Final output sent to browser
DEBUG - 2023-11-15 19:05:57 --> Total execution time: 0.0356
ERROR - 2023-11-15 19:49:38 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-15 19:49:38 --> Config Class Initialized
INFO - 2023-11-15 19:49:38 --> Hooks Class Initialized
DEBUG - 2023-11-15 19:49:38 --> UTF-8 Support Enabled
INFO - 2023-11-15 19:49:38 --> Utf8 Class Initialized
INFO - 2023-11-15 19:49:38 --> URI Class Initialized
DEBUG - 2023-11-15 19:49:38 --> No URI present. Default controller set.
INFO - 2023-11-15 19:49:38 --> Router Class Initialized
INFO - 2023-11-15 19:49:38 --> Output Class Initialized
INFO - 2023-11-15 19:49:38 --> Security Class Initialized
DEBUG - 2023-11-15 19:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-15 19:49:38 --> Input Class Initialized
INFO - 2023-11-15 19:49:38 --> Language Class Initialized
INFO - 2023-11-15 19:49:38 --> Loader Class Initialized
INFO - 2023-11-15 19:49:38 --> Helper loaded: url_helper
INFO - 2023-11-15 19:49:38 --> Helper loaded: form_helper
INFO - 2023-11-15 19:49:38 --> Helper loaded: file_helper
INFO - 2023-11-15 19:49:38 --> Database Driver Class Initialized
DEBUG - 2023-11-15 19:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-15 19:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-15 19:49:38 --> Form Validation Class Initialized
INFO - 2023-11-15 19:49:38 --> Upload Class Initialized
INFO - 2023-11-15 19:49:38 --> Model "M_auth" initialized
INFO - 2023-11-15 19:49:38 --> Model "M_user" initialized
INFO - 2023-11-15 19:49:38 --> Model "M_produk" initialized
INFO - 2023-11-15 19:49:38 --> Controller Class Initialized
INFO - 2023-11-15 19:49:38 --> Model "M_pelanggan" initialized
INFO - 2023-11-15 19:49:38 --> Model "M_produk" initialized
DEBUG - 2023-11-15 19:49:38 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-15 19:49:38 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-15 19:49:38 --> Model "M_transaksi" initialized
INFO - 2023-11-15 19:49:38 --> Model "M_bank" initialized
INFO - 2023-11-15 19:49:38 --> Model "M_pesan" initialized
DEBUG - 2023-11-15 19:49:38 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-15 19:49:38 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-15 19:49:38 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-15 19:49:38 --> Final output sent to browser
DEBUG - 2023-11-15 19:49:38 --> Total execution time: 0.0309
