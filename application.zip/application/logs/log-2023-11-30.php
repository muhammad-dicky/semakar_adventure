<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-30 01:49:31 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-30 01:49:31 --> Config Class Initialized
INFO - 2023-11-30 01:49:31 --> Hooks Class Initialized
DEBUG - 2023-11-30 01:49:31 --> UTF-8 Support Enabled
INFO - 2023-11-30 01:49:31 --> Utf8 Class Initialized
INFO - 2023-11-30 01:49:31 --> URI Class Initialized
INFO - 2023-11-30 01:49:31 --> Router Class Initialized
INFO - 2023-11-30 01:49:31 --> Output Class Initialized
INFO - 2023-11-30 01:49:31 --> Security Class Initialized
DEBUG - 2023-11-30 01:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 01:49:31 --> Input Class Initialized
INFO - 2023-11-30 01:49:31 --> Language Class Initialized
INFO - 2023-11-30 01:49:31 --> Loader Class Initialized
INFO - 2023-11-30 01:49:31 --> Helper loaded: url_helper
INFO - 2023-11-30 01:49:31 --> Helper loaded: form_helper
INFO - 2023-11-30 01:49:31 --> Helper loaded: file_helper
INFO - 2023-11-30 01:49:31 --> Database Driver Class Initialized
DEBUG - 2023-11-30 01:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-30 01:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 01:49:31 --> Form Validation Class Initialized
INFO - 2023-11-30 01:49:31 --> Upload Class Initialized
INFO - 2023-11-30 01:49:31 --> Model "M_auth" initialized
INFO - 2023-11-30 01:49:31 --> Model "M_user" initialized
INFO - 2023-11-30 01:49:31 --> Model "M_produk" initialized
INFO - 2023-11-30 01:49:31 --> Controller Class Initialized
INFO - 2023-11-30 01:49:31 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-30 01:49:31 --> Final output sent to browser
DEBUG - 2023-11-30 01:49:31 --> Total execution time: 0.0288
ERROR - 2023-11-30 06:33:27 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-30 06:33:27 --> Config Class Initialized
INFO - 2023-11-30 06:33:27 --> Hooks Class Initialized
DEBUG - 2023-11-30 06:33:27 --> UTF-8 Support Enabled
INFO - 2023-11-30 06:33:27 --> Utf8 Class Initialized
INFO - 2023-11-30 06:33:27 --> URI Class Initialized
DEBUG - 2023-11-30 06:33:27 --> No URI present. Default controller set.
INFO - 2023-11-30 06:33:27 --> Router Class Initialized
INFO - 2023-11-30 06:33:27 --> Output Class Initialized
INFO - 2023-11-30 06:33:27 --> Security Class Initialized
DEBUG - 2023-11-30 06:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 06:33:27 --> Input Class Initialized
INFO - 2023-11-30 06:33:27 --> Language Class Initialized
INFO - 2023-11-30 06:33:27 --> Loader Class Initialized
INFO - 2023-11-30 06:33:27 --> Helper loaded: url_helper
INFO - 2023-11-30 06:33:27 --> Helper loaded: form_helper
INFO - 2023-11-30 06:33:27 --> Helper loaded: file_helper
INFO - 2023-11-30 06:33:27 --> Database Driver Class Initialized
DEBUG - 2023-11-30 06:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-30 06:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 06:33:27 --> Form Validation Class Initialized
INFO - 2023-11-30 06:33:27 --> Upload Class Initialized
INFO - 2023-11-30 06:33:27 --> Model "M_auth" initialized
INFO - 2023-11-30 06:33:27 --> Model "M_user" initialized
INFO - 2023-11-30 06:33:27 --> Model "M_produk" initialized
INFO - 2023-11-30 06:33:27 --> Controller Class Initialized
INFO - 2023-11-30 06:33:27 --> Model "M_pelanggan" initialized
INFO - 2023-11-30 06:33:27 --> Model "M_produk" initialized
DEBUG - 2023-11-30 06:33:27 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-30 06:33:27 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-30 06:33:27 --> Model "M_transaksi" initialized
INFO - 2023-11-30 06:33:27 --> Model "M_bank" initialized
INFO - 2023-11-30 06:33:27 --> Model "M_pesan" initialized
DEBUG - 2023-11-30 06:33:27 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-30 06:33:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-30 06:33:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-30 06:33:27 --> Final output sent to browser
DEBUG - 2023-11-30 06:33:27 --> Total execution time: 0.0348
ERROR - 2023-11-30 06:39:58 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-30 06:39:58 --> Config Class Initialized
INFO - 2023-11-30 06:39:58 --> Hooks Class Initialized
DEBUG - 2023-11-30 06:39:58 --> UTF-8 Support Enabled
INFO - 2023-11-30 06:39:58 --> Utf8 Class Initialized
INFO - 2023-11-30 06:39:58 --> URI Class Initialized
DEBUG - 2023-11-30 06:39:58 --> No URI present. Default controller set.
INFO - 2023-11-30 06:39:58 --> Router Class Initialized
INFO - 2023-11-30 06:39:58 --> Output Class Initialized
INFO - 2023-11-30 06:39:58 --> Security Class Initialized
DEBUG - 2023-11-30 06:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 06:39:58 --> Input Class Initialized
INFO - 2023-11-30 06:39:58 --> Language Class Initialized
INFO - 2023-11-30 06:39:58 --> Loader Class Initialized
INFO - 2023-11-30 06:39:58 --> Helper loaded: url_helper
INFO - 2023-11-30 06:39:58 --> Helper loaded: form_helper
INFO - 2023-11-30 06:39:58 --> Helper loaded: file_helper
INFO - 2023-11-30 06:39:58 --> Database Driver Class Initialized
DEBUG - 2023-11-30 06:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-30 06:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 06:39:58 --> Form Validation Class Initialized
INFO - 2023-11-30 06:39:59 --> Upload Class Initialized
INFO - 2023-11-30 06:39:59 --> Model "M_auth" initialized
INFO - 2023-11-30 06:39:59 --> Model "M_user" initialized
INFO - 2023-11-30 06:39:59 --> Model "M_produk" initialized
INFO - 2023-11-30 06:39:59 --> Controller Class Initialized
INFO - 2023-11-30 06:39:59 --> Model "M_pelanggan" initialized
INFO - 2023-11-30 06:39:59 --> Model "M_produk" initialized
DEBUG - 2023-11-30 06:39:59 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-30 06:39:59 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-30 06:39:59 --> Model "M_transaksi" initialized
INFO - 2023-11-30 06:39:59 --> Model "M_bank" initialized
INFO - 2023-11-30 06:39:59 --> Model "M_pesan" initialized
DEBUG - 2023-11-30 06:39:59 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-30 06:39:59 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-30 06:39:59 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-30 06:39:59 --> Final output sent to browser
DEBUG - 2023-11-30 06:39:59 --> Total execution time: 0.0359
ERROR - 2023-11-30 13:00:21 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-30 13:00:21 --> Config Class Initialized
INFO - 2023-11-30 13:00:21 --> Hooks Class Initialized
DEBUG - 2023-11-30 13:00:21 --> UTF-8 Support Enabled
INFO - 2023-11-30 13:00:21 --> Utf8 Class Initialized
INFO - 2023-11-30 13:00:21 --> URI Class Initialized
DEBUG - 2023-11-30 13:00:21 --> No URI present. Default controller set.
INFO - 2023-11-30 13:00:21 --> Router Class Initialized
INFO - 2023-11-30 13:00:21 --> Output Class Initialized
INFO - 2023-11-30 13:00:21 --> Security Class Initialized
DEBUG - 2023-11-30 13:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 13:00:21 --> Input Class Initialized
INFO - 2023-11-30 13:00:21 --> Language Class Initialized
INFO - 2023-11-30 13:00:21 --> Loader Class Initialized
INFO - 2023-11-30 13:00:21 --> Helper loaded: url_helper
INFO - 2023-11-30 13:00:21 --> Helper loaded: form_helper
INFO - 2023-11-30 13:00:21 --> Helper loaded: file_helper
INFO - 2023-11-30 13:00:21 --> Database Driver Class Initialized
DEBUG - 2023-11-30 13:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-30 13:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 13:00:22 --> Form Validation Class Initialized
INFO - 2023-11-30 13:00:22 --> Upload Class Initialized
INFO - 2023-11-30 13:00:22 --> Model "M_auth" initialized
INFO - 2023-11-30 13:00:22 --> Model "M_user" initialized
INFO - 2023-11-30 13:00:22 --> Model "M_produk" initialized
INFO - 2023-11-30 13:00:22 --> Controller Class Initialized
INFO - 2023-11-30 13:00:22 --> Model "M_pelanggan" initialized
INFO - 2023-11-30 13:00:22 --> Model "M_produk" initialized
DEBUG - 2023-11-30 13:00:22 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-30 13:00:22 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-30 13:00:22 --> Model "M_transaksi" initialized
INFO - 2023-11-30 13:00:22 --> Model "M_bank" initialized
INFO - 2023-11-30 13:00:22 --> Model "M_pesan" initialized
DEBUG - 2023-11-30 13:00:22 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-30 13:00:22 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-30 13:00:22 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-30 13:00:22 --> Final output sent to browser
DEBUG - 2023-11-30 13:00:22 --> Total execution time: 0.6867
ERROR - 2023-11-30 13:02:14 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-30 13:02:14 --> Config Class Initialized
INFO - 2023-11-30 13:02:14 --> Hooks Class Initialized
DEBUG - 2023-11-30 13:02:14 --> UTF-8 Support Enabled
INFO - 2023-11-30 13:02:14 --> Utf8 Class Initialized
INFO - 2023-11-30 13:02:14 --> URI Class Initialized
DEBUG - 2023-11-30 13:02:14 --> No URI present. Default controller set.
INFO - 2023-11-30 13:02:14 --> Router Class Initialized
INFO - 2023-11-30 13:02:14 --> Output Class Initialized
INFO - 2023-11-30 13:02:14 --> Security Class Initialized
DEBUG - 2023-11-30 13:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 13:02:14 --> Input Class Initialized
INFO - 2023-11-30 13:02:14 --> Language Class Initialized
INFO - 2023-11-30 13:02:14 --> Loader Class Initialized
INFO - 2023-11-30 13:02:14 --> Helper loaded: url_helper
INFO - 2023-11-30 13:02:14 --> Helper loaded: form_helper
INFO - 2023-11-30 13:02:14 --> Helper loaded: file_helper
INFO - 2023-11-30 13:02:14 --> Database Driver Class Initialized
DEBUG - 2023-11-30 13:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-30 13:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 13:02:14 --> Form Validation Class Initialized
INFO - 2023-11-30 13:02:14 --> Upload Class Initialized
INFO - 2023-11-30 13:02:14 --> Model "M_auth" initialized
INFO - 2023-11-30 13:02:14 --> Model "M_user" initialized
INFO - 2023-11-30 13:02:14 --> Model "M_produk" initialized
INFO - 2023-11-30 13:02:14 --> Controller Class Initialized
INFO - 2023-11-30 13:02:14 --> Model "M_pelanggan" initialized
INFO - 2023-11-30 13:02:14 --> Model "M_produk" initialized
DEBUG - 2023-11-30 13:02:14 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-30 13:02:14 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-30 13:02:14 --> Model "M_transaksi" initialized
INFO - 2023-11-30 13:02:14 --> Model "M_bank" initialized
INFO - 2023-11-30 13:02:14 --> Model "M_pesan" initialized
DEBUG - 2023-11-30 13:02:14 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-30 13:02:14 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-30 13:02:14 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-30 13:02:14 --> Final output sent to browser
DEBUG - 2023-11-30 13:02:14 --> Total execution time: 0.0046
ERROR - 2023-11-30 13:02:54 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-30 13:02:54 --> Config Class Initialized
INFO - 2023-11-30 13:02:54 --> Hooks Class Initialized
DEBUG - 2023-11-30 13:02:54 --> UTF-8 Support Enabled
INFO - 2023-11-30 13:02:54 --> Utf8 Class Initialized
INFO - 2023-11-30 13:02:54 --> URI Class Initialized
DEBUG - 2023-11-30 13:02:54 --> No URI present. Default controller set.
INFO - 2023-11-30 13:02:54 --> Router Class Initialized
INFO - 2023-11-30 13:02:54 --> Output Class Initialized
INFO - 2023-11-30 13:02:54 --> Security Class Initialized
DEBUG - 2023-11-30 13:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 13:02:54 --> Input Class Initialized
INFO - 2023-11-30 13:02:54 --> Language Class Initialized
INFO - 2023-11-30 13:02:54 --> Loader Class Initialized
INFO - 2023-11-30 13:02:54 --> Helper loaded: url_helper
INFO - 2023-11-30 13:02:54 --> Helper loaded: form_helper
INFO - 2023-11-30 13:02:54 --> Helper loaded: file_helper
INFO - 2023-11-30 13:02:54 --> Database Driver Class Initialized
DEBUG - 2023-11-30 13:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-30 13:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 13:02:54 --> Form Validation Class Initialized
INFO - 2023-11-30 13:02:54 --> Upload Class Initialized
INFO - 2023-11-30 13:02:54 --> Model "M_auth" initialized
INFO - 2023-11-30 13:02:54 --> Model "M_user" initialized
INFO - 2023-11-30 13:02:54 --> Model "M_produk" initialized
INFO - 2023-11-30 13:02:54 --> Controller Class Initialized
INFO - 2023-11-30 13:02:54 --> Model "M_pelanggan" initialized
INFO - 2023-11-30 13:02:54 --> Model "M_produk" initialized
DEBUG - 2023-11-30 13:02:54 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-30 13:02:54 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-30 13:02:54 --> Model "M_transaksi" initialized
INFO - 2023-11-30 13:02:54 --> Model "M_bank" initialized
INFO - 2023-11-30 13:02:54 --> Model "M_pesan" initialized
DEBUG - 2023-11-30 13:02:54 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-30 13:02:54 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-30 13:02:54 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-30 13:02:54 --> Final output sent to browser
DEBUG - 2023-11-30 13:02:54 --> Total execution time: 0.0036
ERROR - 2023-11-30 13:03:00 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-30 13:03:00 --> Config Class Initialized
INFO - 2023-11-30 13:03:00 --> Hooks Class Initialized
DEBUG - 2023-11-30 13:03:00 --> UTF-8 Support Enabled
INFO - 2023-11-30 13:03:00 --> Utf8 Class Initialized
INFO - 2023-11-30 13:03:00 --> URI Class Initialized
DEBUG - 2023-11-30 13:03:00 --> No URI present. Default controller set.
INFO - 2023-11-30 13:03:00 --> Router Class Initialized
INFO - 2023-11-30 13:03:00 --> Output Class Initialized
INFO - 2023-11-30 13:03:00 --> Security Class Initialized
DEBUG - 2023-11-30 13:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 13:03:00 --> Input Class Initialized
INFO - 2023-11-30 13:03:00 --> Language Class Initialized
INFO - 2023-11-30 13:03:00 --> Loader Class Initialized
INFO - 2023-11-30 13:03:00 --> Helper loaded: url_helper
INFO - 2023-11-30 13:03:00 --> Helper loaded: form_helper
INFO - 2023-11-30 13:03:00 --> Helper loaded: file_helper
INFO - 2023-11-30 13:03:00 --> Database Driver Class Initialized
DEBUG - 2023-11-30 13:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-30 13:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 13:03:00 --> Form Validation Class Initialized
INFO - 2023-11-30 13:03:00 --> Upload Class Initialized
INFO - 2023-11-30 13:03:00 --> Model "M_auth" initialized
INFO - 2023-11-30 13:03:00 --> Model "M_user" initialized
INFO - 2023-11-30 13:03:00 --> Model "M_produk" initialized
INFO - 2023-11-30 13:03:00 --> Controller Class Initialized
INFO - 2023-11-30 13:03:00 --> Model "M_pelanggan" initialized
INFO - 2023-11-30 13:03:00 --> Model "M_produk" initialized
DEBUG - 2023-11-30 13:03:00 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-30 13:03:00 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-30 13:03:00 --> Model "M_transaksi" initialized
INFO - 2023-11-30 13:03:00 --> Model "M_bank" initialized
INFO - 2023-11-30 13:03:00 --> Model "M_pesan" initialized
DEBUG - 2023-11-30 13:03:00 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-30 13:03:00 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-30 13:03:00 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-30 13:03:00 --> Final output sent to browser
DEBUG - 2023-11-30 13:03:00 --> Total execution time: 0.0043
ERROR - 2023-11-30 15:16:16 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-30 15:16:16 --> Config Class Initialized
INFO - 2023-11-30 15:16:16 --> Hooks Class Initialized
DEBUG - 2023-11-30 15:16:16 --> UTF-8 Support Enabled
INFO - 2023-11-30 15:16:16 --> Utf8 Class Initialized
INFO - 2023-11-30 15:16:16 --> URI Class Initialized
DEBUG - 2023-11-30 15:16:16 --> No URI present. Default controller set.
INFO - 2023-11-30 15:16:16 --> Router Class Initialized
INFO - 2023-11-30 15:16:16 --> Output Class Initialized
INFO - 2023-11-30 15:16:16 --> Security Class Initialized
DEBUG - 2023-11-30 15:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 15:16:16 --> Input Class Initialized
INFO - 2023-11-30 15:16:16 --> Language Class Initialized
INFO - 2023-11-30 15:16:16 --> Loader Class Initialized
INFO - 2023-11-30 15:16:16 --> Helper loaded: url_helper
INFO - 2023-11-30 15:16:16 --> Helper loaded: form_helper
INFO - 2023-11-30 15:16:16 --> Helper loaded: file_helper
INFO - 2023-11-30 15:16:16 --> Database Driver Class Initialized
DEBUG - 2023-11-30 15:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-30 15:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 15:16:16 --> Form Validation Class Initialized
INFO - 2023-11-30 15:16:16 --> Upload Class Initialized
INFO - 2023-11-30 15:16:16 --> Model "M_auth" initialized
INFO - 2023-11-30 15:16:16 --> Model "M_user" initialized
INFO - 2023-11-30 15:16:16 --> Model "M_produk" initialized
INFO - 2023-11-30 15:16:16 --> Controller Class Initialized
INFO - 2023-11-30 15:16:16 --> Model "M_pelanggan" initialized
INFO - 2023-11-30 15:16:16 --> Model "M_produk" initialized
DEBUG - 2023-11-30 15:16:16 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-30 15:16:16 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-30 15:16:16 --> Model "M_transaksi" initialized
INFO - 2023-11-30 15:16:16 --> Model "M_bank" initialized
INFO - 2023-11-30 15:16:16 --> Model "M_pesan" initialized
DEBUG - 2023-11-30 15:16:16 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-30 15:16:16 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-30 15:16:16 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-30 15:16:16 --> Final output sent to browser
DEBUG - 2023-11-30 15:16:16 --> Total execution time: 0.0420
ERROR - 2023-11-30 16:31:02 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-30 16:31:02 --> Config Class Initialized
INFO - 2023-11-30 16:31:02 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:31:02 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:31:02 --> Utf8 Class Initialized
INFO - 2023-11-30 16:31:02 --> URI Class Initialized
DEBUG - 2023-11-30 16:31:02 --> No URI present. Default controller set.
INFO - 2023-11-30 16:31:02 --> Router Class Initialized
INFO - 2023-11-30 16:31:02 --> Output Class Initialized
INFO - 2023-11-30 16:31:02 --> Security Class Initialized
DEBUG - 2023-11-30 16:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:31:02 --> Input Class Initialized
INFO - 2023-11-30 16:31:02 --> Language Class Initialized
INFO - 2023-11-30 16:31:02 --> Loader Class Initialized
INFO - 2023-11-30 16:31:02 --> Helper loaded: url_helper
INFO - 2023-11-30 16:31:02 --> Helper loaded: form_helper
INFO - 2023-11-30 16:31:02 --> Helper loaded: file_helper
INFO - 2023-11-30 16:31:02 --> Database Driver Class Initialized
DEBUG - 2023-11-30 16:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-30 16:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:31:02 --> Form Validation Class Initialized
INFO - 2023-11-30 16:31:02 --> Upload Class Initialized
INFO - 2023-11-30 16:31:02 --> Model "M_auth" initialized
INFO - 2023-11-30 16:31:02 --> Model "M_user" initialized
INFO - 2023-11-30 16:31:02 --> Model "M_produk" initialized
INFO - 2023-11-30 16:31:02 --> Controller Class Initialized
INFO - 2023-11-30 16:31:02 --> Model "M_pelanggan" initialized
INFO - 2023-11-30 16:31:02 --> Model "M_produk" initialized
DEBUG - 2023-11-30 16:31:02 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-30 16:31:02 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-30 16:31:02 --> Model "M_transaksi" initialized
INFO - 2023-11-30 16:31:02 --> Model "M_bank" initialized
INFO - 2023-11-30 16:31:02 --> Model "M_pesan" initialized
DEBUG - 2023-11-30 16:31:02 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-30 16:31:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-30 16:31:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-30 16:31:02 --> Final output sent to browser
DEBUG - 2023-11-30 16:31:02 --> Total execution time: 0.0373
ERROR - 2023-11-30 19:36:09 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-30 19:36:09 --> Config Class Initialized
INFO - 2023-11-30 19:36:09 --> Hooks Class Initialized
DEBUG - 2023-11-30 19:36:09 --> UTF-8 Support Enabled
INFO - 2023-11-30 19:36:09 --> Utf8 Class Initialized
INFO - 2023-11-30 19:36:09 --> URI Class Initialized
INFO - 2023-11-30 19:36:09 --> Router Class Initialized
INFO - 2023-11-30 19:36:09 --> Output Class Initialized
INFO - 2023-11-30 19:36:09 --> Security Class Initialized
DEBUG - 2023-11-30 19:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 19:36:09 --> Input Class Initialized
INFO - 2023-11-30 19:36:09 --> Language Class Initialized
INFO - 2023-11-30 19:36:09 --> Loader Class Initialized
INFO - 2023-11-30 19:36:09 --> Helper loaded: url_helper
INFO - 2023-11-30 19:36:09 --> Helper loaded: form_helper
INFO - 2023-11-30 19:36:09 --> Helper loaded: file_helper
INFO - 2023-11-30 19:36:09 --> Database Driver Class Initialized
DEBUG - 2023-11-30 19:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-30 19:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 19:36:09 --> Form Validation Class Initialized
INFO - 2023-11-30 19:36:09 --> Upload Class Initialized
INFO - 2023-11-30 19:36:09 --> Model "M_auth" initialized
INFO - 2023-11-30 19:36:09 --> Model "M_user" initialized
INFO - 2023-11-30 19:36:09 --> Model "M_produk" initialized
INFO - 2023-11-30 19:36:09 --> Controller Class Initialized
INFO - 2023-11-30 19:36:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-30 19:36:09 --> Final output sent to browser
DEBUG - 2023-11-30 19:36:09 --> Total execution time: 0.0284
ERROR - 2023-11-30 20:18:26 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-30 20:18:26 --> Config Class Initialized
INFO - 2023-11-30 20:18:26 --> Hooks Class Initialized
DEBUG - 2023-11-30 20:18:26 --> UTF-8 Support Enabled
INFO - 2023-11-30 20:18:26 --> Utf8 Class Initialized
INFO - 2023-11-30 20:18:26 --> URI Class Initialized
DEBUG - 2023-11-30 20:18:26 --> No URI present. Default controller set.
INFO - 2023-11-30 20:18:26 --> Router Class Initialized
INFO - 2023-11-30 20:18:26 --> Output Class Initialized
INFO - 2023-11-30 20:18:26 --> Security Class Initialized
DEBUG - 2023-11-30 20:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 20:18:26 --> Input Class Initialized
INFO - 2023-11-30 20:18:26 --> Language Class Initialized
INFO - 2023-11-30 20:18:26 --> Loader Class Initialized
INFO - 2023-11-30 20:18:26 --> Helper loaded: url_helper
INFO - 2023-11-30 20:18:26 --> Helper loaded: form_helper
INFO - 2023-11-30 20:18:26 --> Helper loaded: file_helper
INFO - 2023-11-30 20:18:26 --> Database Driver Class Initialized
DEBUG - 2023-11-30 20:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-30 20:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 20:18:26 --> Form Validation Class Initialized
INFO - 2023-11-30 20:18:26 --> Upload Class Initialized
INFO - 2023-11-30 20:18:26 --> Model "M_auth" initialized
INFO - 2023-11-30 20:18:26 --> Model "M_user" initialized
INFO - 2023-11-30 20:18:26 --> Model "M_produk" initialized
INFO - 2023-11-30 20:18:26 --> Controller Class Initialized
INFO - 2023-11-30 20:18:26 --> Model "M_pelanggan" initialized
INFO - 2023-11-30 20:18:26 --> Model "M_produk" initialized
DEBUG - 2023-11-30 20:18:26 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-30 20:18:26 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-30 20:18:26 --> Model "M_transaksi" initialized
INFO - 2023-11-30 20:18:26 --> Model "M_bank" initialized
INFO - 2023-11-30 20:18:26 --> Model "M_pesan" initialized
DEBUG - 2023-11-30 20:18:26 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-30 20:18:26 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-30 20:18:26 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-30 20:18:26 --> Final output sent to browser
DEBUG - 2023-11-30 20:18:26 --> Total execution time: 0.0305
ERROR - 2023-11-30 20:18:35 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-30 20:18:35 --> Config Class Initialized
INFO - 2023-11-30 20:18:35 --> Hooks Class Initialized
DEBUG - 2023-11-30 20:18:35 --> UTF-8 Support Enabled
INFO - 2023-11-30 20:18:35 --> Utf8 Class Initialized
INFO - 2023-11-30 20:18:35 --> URI Class Initialized
INFO - 2023-11-30 20:18:35 --> Router Class Initialized
INFO - 2023-11-30 20:18:35 --> Output Class Initialized
INFO - 2023-11-30 20:18:35 --> Security Class Initialized
DEBUG - 2023-11-30 20:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 20:18:35 --> Input Class Initialized
INFO - 2023-11-30 20:18:35 --> Language Class Initialized
INFO - 2023-11-30 20:18:35 --> Loader Class Initialized
INFO - 2023-11-30 20:18:35 --> Helper loaded: url_helper
INFO - 2023-11-30 20:18:35 --> Helper loaded: form_helper
INFO - 2023-11-30 20:18:35 --> Helper loaded: file_helper
INFO - 2023-11-30 20:18:35 --> Database Driver Class Initialized
DEBUG - 2023-11-30 20:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-30 20:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 20:18:35 --> Form Validation Class Initialized
INFO - 2023-11-30 20:18:35 --> Upload Class Initialized
INFO - 2023-11-30 20:18:35 --> Model "M_auth" initialized
INFO - 2023-11-30 20:18:35 --> Model "M_user" initialized
INFO - 2023-11-30 20:18:35 --> Model "M_produk" initialized
INFO - 2023-11-30 20:18:35 --> Controller Class Initialized
INFO - 2023-11-30 20:18:35 --> Model "M_pelanggan" initialized
INFO - 2023-11-30 20:18:35 --> Model "M_produk" initialized
DEBUG - 2023-11-30 20:18:35 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-30 20:18:35 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-30 20:18:35 --> Model "M_transaksi" initialized
INFO - 2023-11-30 20:18:35 --> Model "M_bank" initialized
INFO - 2023-11-30 20:18:35 --> Model "M_pesan" initialized
DEBUG - 2023-11-30 20:18:35 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-30 20:18:35 --> Email Class Initialized
INFO - 2023-11-30 20:18:36 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-11-30 20:18:39 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-30 20:18:39 --> Config Class Initialized
INFO - 2023-11-30 20:18:39 --> Hooks Class Initialized
DEBUG - 2023-11-30 20:18:39 --> UTF-8 Support Enabled
INFO - 2023-11-30 20:18:39 --> Utf8 Class Initialized
INFO - 2023-11-30 20:18:39 --> URI Class Initialized
DEBUG - 2023-11-30 20:18:39 --> No URI present. Default controller set.
INFO - 2023-11-30 20:18:39 --> Router Class Initialized
INFO - 2023-11-30 20:18:39 --> Output Class Initialized
INFO - 2023-11-30 20:18:39 --> Security Class Initialized
DEBUG - 2023-11-30 20:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 20:18:39 --> Input Class Initialized
INFO - 2023-11-30 20:18:39 --> Language Class Initialized
INFO - 2023-11-30 20:18:39 --> Loader Class Initialized
INFO - 2023-11-30 20:18:39 --> Helper loaded: url_helper
INFO - 2023-11-30 20:18:39 --> Helper loaded: form_helper
INFO - 2023-11-30 20:18:39 --> Helper loaded: file_helper
INFO - 2023-11-30 20:18:39 --> Database Driver Class Initialized
DEBUG - 2023-11-30 20:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-30 20:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 20:18:39 --> Form Validation Class Initialized
INFO - 2023-11-30 20:18:39 --> Upload Class Initialized
INFO - 2023-11-30 20:18:39 --> Model "M_auth" initialized
INFO - 2023-11-30 20:18:39 --> Model "M_user" initialized
INFO - 2023-11-30 20:18:39 --> Model "M_produk" initialized
INFO - 2023-11-30 20:18:39 --> Controller Class Initialized
INFO - 2023-11-30 20:18:39 --> Model "M_pelanggan" initialized
INFO - 2023-11-30 20:18:39 --> Model "M_produk" initialized
DEBUG - 2023-11-30 20:18:39 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-30 20:18:39 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-30 20:18:39 --> Model "M_transaksi" initialized
INFO - 2023-11-30 20:18:39 --> Model "M_bank" initialized
INFO - 2023-11-30 20:18:39 --> Model "M_pesan" initialized
DEBUG - 2023-11-30 20:18:39 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-30 20:18:39 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-30 20:18:39 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-30 20:18:39 --> Final output sent to browser
DEBUG - 2023-11-30 20:18:39 --> Total execution time: 0.0041
ERROR - 2023-11-30 20:34:15 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-30 20:34:15 --> Config Class Initialized
INFO - 2023-11-30 20:34:15 --> Hooks Class Initialized
DEBUG - 2023-11-30 20:34:15 --> UTF-8 Support Enabled
INFO - 2023-11-30 20:34:15 --> Utf8 Class Initialized
INFO - 2023-11-30 20:34:15 --> URI Class Initialized
INFO - 2023-11-30 20:34:15 --> Router Class Initialized
INFO - 2023-11-30 20:34:15 --> Output Class Initialized
INFO - 2023-11-30 20:34:15 --> Security Class Initialized
DEBUG - 2023-11-30 20:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 20:34:15 --> Input Class Initialized
INFO - 2023-11-30 20:34:15 --> Language Class Initialized
INFO - 2023-11-30 20:34:15 --> Loader Class Initialized
INFO - 2023-11-30 20:34:15 --> Helper loaded: url_helper
INFO - 2023-11-30 20:34:15 --> Helper loaded: form_helper
INFO - 2023-11-30 20:34:15 --> Helper loaded: file_helper
INFO - 2023-11-30 20:34:15 --> Database Driver Class Initialized
DEBUG - 2023-11-30 20:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-30 20:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 20:34:15 --> Form Validation Class Initialized
INFO - 2023-11-30 20:34:15 --> Upload Class Initialized
INFO - 2023-11-30 20:34:15 --> Model "M_auth" initialized
INFO - 2023-11-30 20:34:15 --> Model "M_user" initialized
INFO - 2023-11-30 20:34:15 --> Model "M_produk" initialized
INFO - 2023-11-30 20:34:15 --> Controller Class Initialized
INFO - 2023-11-30 20:34:15 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-30 20:34:15 --> Final output sent to browser
DEBUG - 2023-11-30 20:34:15 --> Total execution time: 0.0287
ERROR - 2023-11-30 20:34:16 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-30 20:34:16 --> Config Class Initialized
INFO - 2023-11-30 20:34:16 --> Hooks Class Initialized
DEBUG - 2023-11-30 20:34:16 --> UTF-8 Support Enabled
INFO - 2023-11-30 20:34:16 --> Utf8 Class Initialized
INFO - 2023-11-30 20:34:16 --> URI Class Initialized
DEBUG - 2023-11-30 20:34:16 --> No URI present. Default controller set.
INFO - 2023-11-30 20:34:16 --> Router Class Initialized
INFO - 2023-11-30 20:34:16 --> Output Class Initialized
INFO - 2023-11-30 20:34:16 --> Security Class Initialized
DEBUG - 2023-11-30 20:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 20:34:16 --> Input Class Initialized
INFO - 2023-11-30 20:34:16 --> Language Class Initialized
INFO - 2023-11-30 20:34:16 --> Loader Class Initialized
INFO - 2023-11-30 20:34:16 --> Helper loaded: url_helper
INFO - 2023-11-30 20:34:16 --> Helper loaded: form_helper
INFO - 2023-11-30 20:34:16 --> Helper loaded: file_helper
INFO - 2023-11-30 20:34:16 --> Database Driver Class Initialized
DEBUG - 2023-11-30 20:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-30 20:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 20:34:16 --> Form Validation Class Initialized
INFO - 2023-11-30 20:34:16 --> Upload Class Initialized
INFO - 2023-11-30 20:34:16 --> Model "M_auth" initialized
INFO - 2023-11-30 20:34:16 --> Model "M_user" initialized
INFO - 2023-11-30 20:34:16 --> Model "M_produk" initialized
INFO - 2023-11-30 20:34:16 --> Controller Class Initialized
INFO - 2023-11-30 20:34:16 --> Model "M_pelanggan" initialized
INFO - 2023-11-30 20:34:16 --> Model "M_produk" initialized
DEBUG - 2023-11-30 20:34:16 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-30 20:34:16 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-30 20:34:16 --> Model "M_transaksi" initialized
INFO - 2023-11-30 20:34:16 --> Model "M_bank" initialized
INFO - 2023-11-30 20:34:16 --> Model "M_pesan" initialized
DEBUG - 2023-11-30 20:34:16 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-30 20:34:16 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-30 20:34:16 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-30 20:34:16 --> Final output sent to browser
DEBUG - 2023-11-30 20:34:16 --> Total execution time: 0.0087
ERROR - 2023-11-30 21:25:52 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-30 21:25:52 --> Config Class Initialized
INFO - 2023-11-30 21:25:52 --> Hooks Class Initialized
DEBUG - 2023-11-30 21:25:52 --> UTF-8 Support Enabled
INFO - 2023-11-30 21:25:52 --> Utf8 Class Initialized
INFO - 2023-11-30 21:25:52 --> URI Class Initialized
DEBUG - 2023-11-30 21:25:52 --> No URI present. Default controller set.
INFO - 2023-11-30 21:25:52 --> Router Class Initialized
INFO - 2023-11-30 21:25:52 --> Output Class Initialized
INFO - 2023-11-30 21:25:52 --> Security Class Initialized
DEBUG - 2023-11-30 21:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 21:25:52 --> Input Class Initialized
INFO - 2023-11-30 21:25:52 --> Language Class Initialized
INFO - 2023-11-30 21:25:52 --> Loader Class Initialized
INFO - 2023-11-30 21:25:52 --> Helper loaded: url_helper
INFO - 2023-11-30 21:25:52 --> Helper loaded: form_helper
INFO - 2023-11-30 21:25:52 --> Helper loaded: file_helper
INFO - 2023-11-30 21:25:52 --> Database Driver Class Initialized
DEBUG - 2023-11-30 21:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-30 21:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 21:25:52 --> Form Validation Class Initialized
INFO - 2023-11-30 21:25:52 --> Upload Class Initialized
INFO - 2023-11-30 21:25:52 --> Model "M_auth" initialized
INFO - 2023-11-30 21:25:52 --> Model "M_user" initialized
INFO - 2023-11-30 21:25:52 --> Model "M_produk" initialized
INFO - 2023-11-30 21:25:52 --> Controller Class Initialized
INFO - 2023-11-30 21:25:52 --> Model "M_pelanggan" initialized
INFO - 2023-11-30 21:25:52 --> Model "M_produk" initialized
DEBUG - 2023-11-30 21:25:52 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-30 21:25:52 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-30 21:25:52 --> Model "M_transaksi" initialized
INFO - 2023-11-30 21:25:52 --> Model "M_bank" initialized
INFO - 2023-11-30 21:25:52 --> Model "M_pesan" initialized
DEBUG - 2023-11-30 21:25:52 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-30 21:25:52 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-30 21:25:52 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-30 21:25:52 --> Final output sent to browser
DEBUG - 2023-11-30 21:25:52 --> Total execution time: 0.0295
ERROR - 2023-11-30 21:33:34 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-30 21:33:34 --> Config Class Initialized
INFO - 2023-11-30 21:33:34 --> Hooks Class Initialized
DEBUG - 2023-11-30 21:33:34 --> UTF-8 Support Enabled
INFO - 2023-11-30 21:33:34 --> Utf8 Class Initialized
INFO - 2023-11-30 21:33:34 --> URI Class Initialized
INFO - 2023-11-30 21:33:34 --> Router Class Initialized
INFO - 2023-11-30 21:33:34 --> Output Class Initialized
INFO - 2023-11-30 21:33:34 --> Security Class Initialized
DEBUG - 2023-11-30 21:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 21:33:34 --> Input Class Initialized
INFO - 2023-11-30 21:33:34 --> Language Class Initialized
INFO - 2023-11-30 21:33:34 --> Loader Class Initialized
INFO - 2023-11-30 21:33:34 --> Helper loaded: url_helper
INFO - 2023-11-30 21:33:34 --> Helper loaded: form_helper
INFO - 2023-11-30 21:33:34 --> Helper loaded: file_helper
INFO - 2023-11-30 21:33:34 --> Database Driver Class Initialized
DEBUG - 2023-11-30 21:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-30 21:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 21:33:34 --> Form Validation Class Initialized
INFO - 2023-11-30 21:33:34 --> Upload Class Initialized
INFO - 2023-11-30 21:33:34 --> Model "M_auth" initialized
INFO - 2023-11-30 21:33:34 --> Model "M_user" initialized
INFO - 2023-11-30 21:33:34 --> Model "M_produk" initialized
INFO - 2023-11-30 21:33:34 --> Controller Class Initialized
INFO - 2023-11-30 21:33:34 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-30 21:33:34 --> Final output sent to browser
DEBUG - 2023-11-30 21:33:34 --> Total execution time: 0.0250
ERROR - 2023-11-30 21:33:36 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-30 21:33:36 --> Config Class Initialized
INFO - 2023-11-30 21:33:36 --> Hooks Class Initialized
DEBUG - 2023-11-30 21:33:36 --> UTF-8 Support Enabled
INFO - 2023-11-30 21:33:36 --> Utf8 Class Initialized
INFO - 2023-11-30 21:33:36 --> URI Class Initialized
INFO - 2023-11-30 21:33:36 --> Router Class Initialized
INFO - 2023-11-30 21:33:36 --> Output Class Initialized
INFO - 2023-11-30 21:33:36 --> Security Class Initialized
DEBUG - 2023-11-30 21:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 21:33:36 --> Input Class Initialized
INFO - 2023-11-30 21:33:36 --> Language Class Initialized
INFO - 2023-11-30 21:33:36 --> Loader Class Initialized
INFO - 2023-11-30 21:33:36 --> Helper loaded: url_helper
INFO - 2023-11-30 21:33:36 --> Helper loaded: form_helper
INFO - 2023-11-30 21:33:36 --> Helper loaded: file_helper
INFO - 2023-11-30 21:33:36 --> Database Driver Class Initialized
DEBUG - 2023-11-30 21:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-30 21:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 21:33:36 --> Form Validation Class Initialized
INFO - 2023-11-30 21:33:36 --> Upload Class Initialized
INFO - 2023-11-30 21:33:36 --> Model "M_auth" initialized
INFO - 2023-11-30 21:33:36 --> Model "M_user" initialized
INFO - 2023-11-30 21:33:36 --> Model "M_produk" initialized
INFO - 2023-11-30 21:33:36 --> Controller Class Initialized
INFO - 2023-11-30 21:33:36 --> Model "M_pelanggan" initialized
INFO - 2023-11-30 21:33:36 --> Model "M_produk" initialized
DEBUG - 2023-11-30 21:33:36 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-30 21:33:36 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-30 21:33:36 --> Model "M_transaksi" initialized
INFO - 2023-11-30 21:33:36 --> Model "M_bank" initialized
INFO - 2023-11-30 21:33:36 --> Model "M_pesan" initialized
DEBUG - 2023-11-30 21:33:36 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-30 21:33:36 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-30 21:33:36 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-30 21:33:36 --> Final output sent to browser
DEBUG - 2023-11-30 21:33:36 --> Total execution time: 0.0178
ERROR - 2023-11-30 23:07:21 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-30 23:07:21 --> Config Class Initialized
INFO - 2023-11-30 23:07:21 --> Hooks Class Initialized
DEBUG - 2023-11-30 23:07:21 --> UTF-8 Support Enabled
INFO - 2023-11-30 23:07:21 --> Utf8 Class Initialized
INFO - 2023-11-30 23:07:21 --> URI Class Initialized
INFO - 2023-11-30 23:07:21 --> Router Class Initialized
INFO - 2023-11-30 23:07:21 --> Output Class Initialized
INFO - 2023-11-30 23:07:21 --> Security Class Initialized
DEBUG - 2023-11-30 23:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 23:07:21 --> Input Class Initialized
INFO - 2023-11-30 23:07:21 --> Language Class Initialized
INFO - 2023-11-30 23:07:21 --> Loader Class Initialized
INFO - 2023-11-30 23:07:21 --> Helper loaded: url_helper
INFO - 2023-11-30 23:07:21 --> Helper loaded: form_helper
INFO - 2023-11-30 23:07:21 --> Helper loaded: file_helper
INFO - 2023-11-30 23:07:21 --> Database Driver Class Initialized
DEBUG - 2023-11-30 23:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-30 23:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 23:07:21 --> Form Validation Class Initialized
INFO - 2023-11-30 23:07:21 --> Upload Class Initialized
INFO - 2023-11-30 23:07:21 --> Model "M_auth" initialized
INFO - 2023-11-30 23:07:21 --> Model "M_user" initialized
INFO - 2023-11-30 23:07:21 --> Model "M_produk" initialized
INFO - 2023-11-30 23:07:21 --> Controller Class Initialized
INFO - 2023-11-30 23:07:21 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-30 23:07:21 --> Final output sent to browser
DEBUG - 2023-11-30 23:07:21 --> Total execution time: 0.0285
