<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-06 00:00:03 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-06 00:00:03 --> Config Class Initialized
INFO - 2023-11-06 00:00:03 --> Hooks Class Initialized
DEBUG - 2023-11-06 00:00:03 --> UTF-8 Support Enabled
INFO - 2023-11-06 00:00:03 --> Utf8 Class Initialized
INFO - 2023-11-06 00:00:03 --> URI Class Initialized
DEBUG - 2023-11-06 00:00:03 --> No URI present. Default controller set.
INFO - 2023-11-06 00:00:03 --> Router Class Initialized
INFO - 2023-11-06 00:00:03 --> Output Class Initialized
INFO - 2023-11-06 00:00:03 --> Security Class Initialized
DEBUG - 2023-11-06 00:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-06 00:00:03 --> Input Class Initialized
INFO - 2023-11-06 00:00:03 --> Language Class Initialized
INFO - 2023-11-06 00:00:03 --> Loader Class Initialized
INFO - 2023-11-06 00:00:03 --> Helper loaded: url_helper
INFO - 2023-11-06 00:00:03 --> Helper loaded: form_helper
INFO - 2023-11-06 00:00:03 --> Helper loaded: file_helper
INFO - 2023-11-06 00:00:03 --> Database Driver Class Initialized
DEBUG - 2023-11-06 00:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-06 00:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-06 00:00:03 --> Form Validation Class Initialized
INFO - 2023-11-06 00:00:03 --> Upload Class Initialized
INFO - 2023-11-06 00:00:03 --> Model "M_auth" initialized
INFO - 2023-11-06 00:00:03 --> Model "M_user" initialized
INFO - 2023-11-06 00:00:03 --> Model "M_produk" initialized
INFO - 2023-11-06 00:00:03 --> Controller Class Initialized
INFO - 2023-11-06 00:00:03 --> Model "M_pelanggan" initialized
INFO - 2023-11-06 00:00:03 --> Model "M_produk" initialized
DEBUG - 2023-11-06 00:00:03 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-06 00:00:03 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-06 00:00:03 --> Model "M_transaksi" initialized
INFO - 2023-11-06 00:00:03 --> Model "M_bank" initialized
INFO - 2023-11-06 00:00:03 --> Model "M_pesan" initialized
DEBUG - 2023-11-06 00:00:03 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-06 00:00:03 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-06 00:00:03 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-06 00:00:03 --> Final output sent to browser
DEBUG - 2023-11-06 00:00:03 --> Total execution time: 0.0476
ERROR - 2023-11-06 02:32:01 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-06 02:32:01 --> Config Class Initialized
INFO - 2023-11-06 02:32:01 --> Hooks Class Initialized
DEBUG - 2023-11-06 02:32:01 --> UTF-8 Support Enabled
INFO - 2023-11-06 02:32:01 --> Utf8 Class Initialized
INFO - 2023-11-06 02:32:01 --> URI Class Initialized
DEBUG - 2023-11-06 02:32:01 --> No URI present. Default controller set.
INFO - 2023-11-06 02:32:01 --> Router Class Initialized
INFO - 2023-11-06 02:32:01 --> Output Class Initialized
INFO - 2023-11-06 02:32:01 --> Security Class Initialized
DEBUG - 2023-11-06 02:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-06 02:32:01 --> Input Class Initialized
INFO - 2023-11-06 02:32:01 --> Language Class Initialized
INFO - 2023-11-06 02:32:01 --> Loader Class Initialized
INFO - 2023-11-06 02:32:01 --> Helper loaded: url_helper
INFO - 2023-11-06 02:32:01 --> Helper loaded: form_helper
INFO - 2023-11-06 02:32:01 --> Helper loaded: file_helper
INFO - 2023-11-06 02:32:01 --> Database Driver Class Initialized
DEBUG - 2023-11-06 02:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-06 02:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-06 02:32:01 --> Form Validation Class Initialized
INFO - 2023-11-06 02:32:01 --> Upload Class Initialized
INFO - 2023-11-06 02:32:01 --> Model "M_auth" initialized
INFO - 2023-11-06 02:32:01 --> Model "M_user" initialized
INFO - 2023-11-06 02:32:01 --> Model "M_produk" initialized
INFO - 2023-11-06 02:32:01 --> Controller Class Initialized
INFO - 2023-11-06 02:32:01 --> Model "M_pelanggan" initialized
INFO - 2023-11-06 02:32:01 --> Model "M_produk" initialized
DEBUG - 2023-11-06 02:32:01 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-06 02:32:01 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-06 02:32:01 --> Model "M_transaksi" initialized
INFO - 2023-11-06 02:32:01 --> Model "M_bank" initialized
INFO - 2023-11-06 02:32:01 --> Model "M_pesan" initialized
DEBUG - 2023-11-06 02:32:01 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-06 02:32:01 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-06 02:32:01 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-06 02:32:01 --> Final output sent to browser
DEBUG - 2023-11-06 02:32:01 --> Total execution time: 0.0480
ERROR - 2023-11-06 04:22:50 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-06 04:22:50 --> Config Class Initialized
INFO - 2023-11-06 04:22:50 --> Hooks Class Initialized
DEBUG - 2023-11-06 04:22:50 --> UTF-8 Support Enabled
INFO - 2023-11-06 04:22:50 --> Utf8 Class Initialized
INFO - 2023-11-06 04:22:50 --> URI Class Initialized
INFO - 2023-11-06 04:22:50 --> Router Class Initialized
INFO - 2023-11-06 04:22:50 --> Output Class Initialized
INFO - 2023-11-06 04:22:50 --> Security Class Initialized
DEBUG - 2023-11-06 04:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-06 04:22:50 --> Input Class Initialized
INFO - 2023-11-06 04:22:50 --> Language Class Initialized
INFO - 2023-11-06 04:22:50 --> Loader Class Initialized
INFO - 2023-11-06 04:22:50 --> Helper loaded: url_helper
INFO - 2023-11-06 04:22:50 --> Helper loaded: form_helper
INFO - 2023-11-06 04:22:50 --> Helper loaded: file_helper
INFO - 2023-11-06 04:22:50 --> Database Driver Class Initialized
DEBUG - 2023-11-06 04:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-06 04:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-06 04:22:50 --> Form Validation Class Initialized
INFO - 2023-11-06 04:22:50 --> Upload Class Initialized
INFO - 2023-11-06 04:22:50 --> Model "M_auth" initialized
INFO - 2023-11-06 04:22:50 --> Model "M_user" initialized
INFO - 2023-11-06 04:22:50 --> Model "M_produk" initialized
INFO - 2023-11-06 04:22:50 --> Controller Class Initialized
INFO - 2023-11-06 04:22:50 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-06 04:22:50 --> Final output sent to browser
DEBUG - 2023-11-06 04:22:50 --> Total execution time: 0.0248
ERROR - 2023-11-06 04:22:52 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-06 04:22:52 --> Config Class Initialized
INFO - 2023-11-06 04:22:52 --> Hooks Class Initialized
DEBUG - 2023-11-06 04:22:52 --> UTF-8 Support Enabled
INFO - 2023-11-06 04:22:52 --> Utf8 Class Initialized
INFO - 2023-11-06 04:22:52 --> URI Class Initialized
DEBUG - 2023-11-06 04:22:52 --> No URI present. Default controller set.
INFO - 2023-11-06 04:22:52 --> Router Class Initialized
INFO - 2023-11-06 04:22:52 --> Output Class Initialized
INFO - 2023-11-06 04:22:52 --> Security Class Initialized
DEBUG - 2023-11-06 04:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-06 04:22:52 --> Input Class Initialized
INFO - 2023-11-06 04:22:52 --> Language Class Initialized
INFO - 2023-11-06 04:22:52 --> Loader Class Initialized
INFO - 2023-11-06 04:22:52 --> Helper loaded: url_helper
INFO - 2023-11-06 04:22:52 --> Helper loaded: form_helper
INFO - 2023-11-06 04:22:52 --> Helper loaded: file_helper
INFO - 2023-11-06 04:22:52 --> Database Driver Class Initialized
DEBUG - 2023-11-06 04:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-06 04:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-06 04:22:52 --> Form Validation Class Initialized
INFO - 2023-11-06 04:22:52 --> Upload Class Initialized
INFO - 2023-11-06 04:22:52 --> Model "M_auth" initialized
INFO - 2023-11-06 04:22:52 --> Model "M_user" initialized
INFO - 2023-11-06 04:22:52 --> Model "M_produk" initialized
INFO - 2023-11-06 04:22:52 --> Controller Class Initialized
INFO - 2023-11-06 04:22:52 --> Model "M_pelanggan" initialized
INFO - 2023-11-06 04:22:52 --> Model "M_produk" initialized
DEBUG - 2023-11-06 04:22:52 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-06 04:22:52 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-06 04:22:52 --> Model "M_transaksi" initialized
INFO - 2023-11-06 04:22:52 --> Model "M_bank" initialized
INFO - 2023-11-06 04:22:52 --> Model "M_pesan" initialized
DEBUG - 2023-11-06 04:22:52 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-06 04:22:52 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-06 04:22:52 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-06 04:22:52 --> Final output sent to browser
DEBUG - 2023-11-06 04:22:52 --> Total execution time: 0.0087
ERROR - 2023-11-06 05:01:31 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-06 05:01:31 --> Config Class Initialized
INFO - 2023-11-06 05:01:31 --> Hooks Class Initialized
DEBUG - 2023-11-06 05:01:31 --> UTF-8 Support Enabled
INFO - 2023-11-06 05:01:31 --> Utf8 Class Initialized
INFO - 2023-11-06 05:01:31 --> URI Class Initialized
INFO - 2023-11-06 05:01:31 --> Router Class Initialized
INFO - 2023-11-06 05:01:31 --> Output Class Initialized
INFO - 2023-11-06 05:01:31 --> Security Class Initialized
DEBUG - 2023-11-06 05:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-06 05:01:31 --> Input Class Initialized
INFO - 2023-11-06 05:01:31 --> Language Class Initialized
INFO - 2023-11-06 05:01:31 --> Loader Class Initialized
INFO - 2023-11-06 05:01:31 --> Helper loaded: url_helper
INFO - 2023-11-06 05:01:31 --> Helper loaded: form_helper
INFO - 2023-11-06 05:01:31 --> Helper loaded: file_helper
INFO - 2023-11-06 05:01:31 --> Database Driver Class Initialized
DEBUG - 2023-11-06 05:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-06 05:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-06 05:01:31 --> Form Validation Class Initialized
INFO - 2023-11-06 05:01:31 --> Upload Class Initialized
INFO - 2023-11-06 05:01:31 --> Model "M_auth" initialized
INFO - 2023-11-06 05:01:31 --> Model "M_user" initialized
INFO - 2023-11-06 05:01:31 --> Model "M_produk" initialized
INFO - 2023-11-06 05:01:31 --> Controller Class Initialized
INFO - 2023-11-06 05:01:31 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-06 05:01:31 --> Final output sent to browser
DEBUG - 2023-11-06 05:01:31 --> Total execution time: 0.0282
ERROR - 2023-11-06 06:30:34 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-06 06:30:34 --> Config Class Initialized
INFO - 2023-11-06 06:30:34 --> Hooks Class Initialized
DEBUG - 2023-11-06 06:30:34 --> UTF-8 Support Enabled
INFO - 2023-11-06 06:30:34 --> Utf8 Class Initialized
INFO - 2023-11-06 06:30:34 --> URI Class Initialized
INFO - 2023-11-06 06:30:34 --> Router Class Initialized
INFO - 2023-11-06 06:30:34 --> Output Class Initialized
INFO - 2023-11-06 06:30:34 --> Security Class Initialized
DEBUG - 2023-11-06 06:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-06 06:30:34 --> Input Class Initialized
INFO - 2023-11-06 06:30:34 --> Language Class Initialized
INFO - 2023-11-06 06:30:34 --> Loader Class Initialized
INFO - 2023-11-06 06:30:34 --> Helper loaded: url_helper
INFO - 2023-11-06 06:30:34 --> Helper loaded: form_helper
INFO - 2023-11-06 06:30:34 --> Helper loaded: file_helper
INFO - 2023-11-06 06:30:34 --> Database Driver Class Initialized
DEBUG - 2023-11-06 06:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-06 06:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-06 06:30:34 --> Form Validation Class Initialized
INFO - 2023-11-06 06:30:34 --> Upload Class Initialized
INFO - 2023-11-06 06:30:34 --> Model "M_auth" initialized
INFO - 2023-11-06 06:30:34 --> Model "M_user" initialized
INFO - 2023-11-06 06:30:34 --> Model "M_produk" initialized
INFO - 2023-11-06 06:30:34 --> Controller Class Initialized
INFO - 2023-11-06 06:30:34 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-06 06:30:34 --> Final output sent to browser
DEBUG - 2023-11-06 06:30:34 --> Total execution time: 0.0325
ERROR - 2023-11-06 07:44:15 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-06 07:44:15 --> Config Class Initialized
INFO - 2023-11-06 07:44:15 --> Hooks Class Initialized
DEBUG - 2023-11-06 07:44:15 --> UTF-8 Support Enabled
INFO - 2023-11-06 07:44:15 --> Utf8 Class Initialized
INFO - 2023-11-06 07:44:15 --> URI Class Initialized
INFO - 2023-11-06 07:44:15 --> Router Class Initialized
INFO - 2023-11-06 07:44:15 --> Output Class Initialized
INFO - 2023-11-06 07:44:15 --> Security Class Initialized
DEBUG - 2023-11-06 07:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-06 07:44:15 --> Input Class Initialized
INFO - 2023-11-06 07:44:15 --> Language Class Initialized
INFO - 2023-11-06 07:44:15 --> Loader Class Initialized
INFO - 2023-11-06 07:44:15 --> Helper loaded: url_helper
INFO - 2023-11-06 07:44:15 --> Helper loaded: form_helper
INFO - 2023-11-06 07:44:15 --> Helper loaded: file_helper
INFO - 2023-11-06 07:44:15 --> Database Driver Class Initialized
DEBUG - 2023-11-06 07:44:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-06 07:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-06 07:44:15 --> Form Validation Class Initialized
INFO - 2023-11-06 07:44:15 --> Upload Class Initialized
INFO - 2023-11-06 07:44:15 --> Model "M_auth" initialized
INFO - 2023-11-06 07:44:15 --> Model "M_user" initialized
INFO - 2023-11-06 07:44:15 --> Model "M_produk" initialized
INFO - 2023-11-06 07:44:15 --> Controller Class Initialized
INFO - 2023-11-06 07:44:15 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-06 07:44:15 --> Final output sent to browser
DEBUG - 2023-11-06 07:44:15 --> Total execution time: 0.0267
ERROR - 2023-11-06 08:11:35 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-06 08:11:35 --> Config Class Initialized
INFO - 2023-11-06 08:11:35 --> Hooks Class Initialized
DEBUG - 2023-11-06 08:11:35 --> UTF-8 Support Enabled
INFO - 2023-11-06 08:11:35 --> Utf8 Class Initialized
INFO - 2023-11-06 08:11:35 --> URI Class Initialized
DEBUG - 2023-11-06 08:11:35 --> No URI present. Default controller set.
INFO - 2023-11-06 08:11:35 --> Router Class Initialized
INFO - 2023-11-06 08:11:35 --> Output Class Initialized
INFO - 2023-11-06 08:11:35 --> Security Class Initialized
DEBUG - 2023-11-06 08:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-06 08:11:35 --> Input Class Initialized
INFO - 2023-11-06 08:11:35 --> Language Class Initialized
INFO - 2023-11-06 08:11:35 --> Loader Class Initialized
INFO - 2023-11-06 08:11:35 --> Helper loaded: url_helper
INFO - 2023-11-06 08:11:35 --> Helper loaded: form_helper
INFO - 2023-11-06 08:11:35 --> Helper loaded: file_helper
INFO - 2023-11-06 08:11:35 --> Database Driver Class Initialized
DEBUG - 2023-11-06 08:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-06 08:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-06 08:11:35 --> Form Validation Class Initialized
INFO - 2023-11-06 08:11:35 --> Upload Class Initialized
INFO - 2023-11-06 08:11:35 --> Model "M_auth" initialized
INFO - 2023-11-06 08:11:35 --> Model "M_user" initialized
INFO - 2023-11-06 08:11:35 --> Model "M_produk" initialized
INFO - 2023-11-06 08:11:35 --> Controller Class Initialized
INFO - 2023-11-06 08:11:35 --> Model "M_pelanggan" initialized
INFO - 2023-11-06 08:11:35 --> Model "M_produk" initialized
DEBUG - 2023-11-06 08:11:35 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-06 08:11:35 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-06 08:11:35 --> Model "M_transaksi" initialized
INFO - 2023-11-06 08:11:35 --> Model "M_bank" initialized
INFO - 2023-11-06 08:11:35 --> Model "M_pesan" initialized
DEBUG - 2023-11-06 08:11:35 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-06 08:11:35 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-06 08:11:35 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-06 08:11:35 --> Final output sent to browser
DEBUG - 2023-11-06 08:11:35 --> Total execution time: 0.0381
ERROR - 2023-11-06 10:35:32 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-06 10:35:32 --> Config Class Initialized
INFO - 2023-11-06 10:35:32 --> Hooks Class Initialized
DEBUG - 2023-11-06 10:35:32 --> UTF-8 Support Enabled
INFO - 2023-11-06 10:35:32 --> Utf8 Class Initialized
INFO - 2023-11-06 10:35:32 --> URI Class Initialized
DEBUG - 2023-11-06 10:35:32 --> No URI present. Default controller set.
INFO - 2023-11-06 10:35:32 --> Router Class Initialized
INFO - 2023-11-06 10:35:32 --> Output Class Initialized
INFO - 2023-11-06 10:35:32 --> Security Class Initialized
DEBUG - 2023-11-06 10:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-06 10:35:32 --> Input Class Initialized
INFO - 2023-11-06 10:35:32 --> Language Class Initialized
INFO - 2023-11-06 10:35:32 --> Loader Class Initialized
INFO - 2023-11-06 10:35:32 --> Helper loaded: url_helper
INFO - 2023-11-06 10:35:32 --> Helper loaded: form_helper
INFO - 2023-11-06 10:35:32 --> Helper loaded: file_helper
INFO - 2023-11-06 10:35:32 --> Database Driver Class Initialized
DEBUG - 2023-11-06 10:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-06 10:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-06 10:35:32 --> Form Validation Class Initialized
INFO - 2023-11-06 10:35:32 --> Upload Class Initialized
INFO - 2023-11-06 10:35:32 --> Model "M_auth" initialized
INFO - 2023-11-06 10:35:32 --> Model "M_user" initialized
INFO - 2023-11-06 10:35:32 --> Model "M_produk" initialized
INFO - 2023-11-06 10:35:32 --> Controller Class Initialized
INFO - 2023-11-06 10:35:32 --> Model "M_pelanggan" initialized
INFO - 2023-11-06 10:35:32 --> Model "M_produk" initialized
DEBUG - 2023-11-06 10:35:32 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-06 10:35:32 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-06 10:35:32 --> Model "M_transaksi" initialized
INFO - 2023-11-06 10:35:32 --> Model "M_bank" initialized
INFO - 2023-11-06 10:35:32 --> Model "M_pesan" initialized
DEBUG - 2023-11-06 10:35:32 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-06 10:35:32 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-06 10:35:32 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-06 10:35:32 --> Final output sent to browser
DEBUG - 2023-11-06 10:35:32 --> Total execution time: 0.0478
ERROR - 2023-11-06 14:32:07 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-06 14:32:07 --> Config Class Initialized
INFO - 2023-11-06 14:32:07 --> Hooks Class Initialized
DEBUG - 2023-11-06 14:32:07 --> UTF-8 Support Enabled
INFO - 2023-11-06 14:32:07 --> Utf8 Class Initialized
INFO - 2023-11-06 14:32:07 --> URI Class Initialized
INFO - 2023-11-06 14:32:07 --> Router Class Initialized
INFO - 2023-11-06 14:32:07 --> Output Class Initialized
INFO - 2023-11-06 14:32:07 --> Security Class Initialized
DEBUG - 2023-11-06 14:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-06 14:32:07 --> Input Class Initialized
INFO - 2023-11-06 14:32:07 --> Language Class Initialized
INFO - 2023-11-06 14:32:07 --> Loader Class Initialized
INFO - 2023-11-06 14:32:07 --> Helper loaded: url_helper
INFO - 2023-11-06 14:32:07 --> Helper loaded: form_helper
INFO - 2023-11-06 14:32:07 --> Helper loaded: file_helper
INFO - 2023-11-06 14:32:07 --> Database Driver Class Initialized
DEBUG - 2023-11-06 14:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-06 14:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-06 14:32:07 --> Form Validation Class Initialized
INFO - 2023-11-06 14:32:07 --> Upload Class Initialized
INFO - 2023-11-06 14:32:07 --> Model "M_auth" initialized
INFO - 2023-11-06 14:32:07 --> Model "M_user" initialized
INFO - 2023-11-06 14:32:07 --> Model "M_produk" initialized
INFO - 2023-11-06 14:32:07 --> Controller Class Initialized
INFO - 2023-11-06 14:32:07 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-06 14:32:07 --> Final output sent to browser
DEBUG - 2023-11-06 14:32:07 --> Total execution time: 0.0358
ERROR - 2023-11-06 14:32:07 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-06 14:32:07 --> Config Class Initialized
INFO - 2023-11-06 14:32:07 --> Hooks Class Initialized
DEBUG - 2023-11-06 14:32:07 --> UTF-8 Support Enabled
INFO - 2023-11-06 14:32:07 --> Utf8 Class Initialized
INFO - 2023-11-06 14:32:07 --> URI Class Initialized
DEBUG - 2023-11-06 14:32:07 --> No URI present. Default controller set.
INFO - 2023-11-06 14:32:07 --> Router Class Initialized
INFO - 2023-11-06 14:32:07 --> Output Class Initialized
INFO - 2023-11-06 14:32:07 --> Security Class Initialized
DEBUG - 2023-11-06 14:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-06 14:32:07 --> Input Class Initialized
INFO - 2023-11-06 14:32:07 --> Language Class Initialized
INFO - 2023-11-06 14:32:07 --> Loader Class Initialized
INFO - 2023-11-06 14:32:07 --> Helper loaded: url_helper
INFO - 2023-11-06 14:32:07 --> Helper loaded: form_helper
INFO - 2023-11-06 14:32:07 --> Helper loaded: file_helper
INFO - 2023-11-06 14:32:07 --> Database Driver Class Initialized
DEBUG - 2023-11-06 14:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-06 14:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-06 14:32:07 --> Form Validation Class Initialized
INFO - 2023-11-06 14:32:07 --> Upload Class Initialized
INFO - 2023-11-06 14:32:07 --> Model "M_auth" initialized
INFO - 2023-11-06 14:32:07 --> Model "M_user" initialized
INFO - 2023-11-06 14:32:07 --> Model "M_produk" initialized
INFO - 2023-11-06 14:32:07 --> Controller Class Initialized
INFO - 2023-11-06 14:32:07 --> Model "M_pelanggan" initialized
INFO - 2023-11-06 14:32:07 --> Model "M_produk" initialized
DEBUG - 2023-11-06 14:32:07 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-06 14:32:07 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-06 14:32:07 --> Model "M_transaksi" initialized
INFO - 2023-11-06 14:32:07 --> Model "M_bank" initialized
INFO - 2023-11-06 14:32:07 --> Model "M_pesan" initialized
DEBUG - 2023-11-06 14:32:07 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-06 14:32:07 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-06 14:32:07 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-06 14:32:07 --> Final output sent to browser
DEBUG - 2023-11-06 14:32:07 --> Total execution time: 0.0121
ERROR - 2023-11-06 14:32:08 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-06 14:32:08 --> Config Class Initialized
INFO - 2023-11-06 14:32:08 --> Hooks Class Initialized
DEBUG - 2023-11-06 14:32:08 --> UTF-8 Support Enabled
INFO - 2023-11-06 14:32:08 --> Utf8 Class Initialized
INFO - 2023-11-06 14:32:08 --> URI Class Initialized
DEBUG - 2023-11-06 14:32:08 --> No URI present. Default controller set.
INFO - 2023-11-06 14:32:08 --> Router Class Initialized
INFO - 2023-11-06 14:32:08 --> Output Class Initialized
INFO - 2023-11-06 14:32:08 --> Security Class Initialized
DEBUG - 2023-11-06 14:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-06 14:32:08 --> Input Class Initialized
INFO - 2023-11-06 14:32:08 --> Language Class Initialized
INFO - 2023-11-06 14:32:08 --> Loader Class Initialized
INFO - 2023-11-06 14:32:08 --> Helper loaded: url_helper
INFO - 2023-11-06 14:32:08 --> Helper loaded: form_helper
INFO - 2023-11-06 14:32:08 --> Helper loaded: file_helper
INFO - 2023-11-06 14:32:08 --> Database Driver Class Initialized
DEBUG - 2023-11-06 14:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-06 14:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-06 14:32:08 --> Form Validation Class Initialized
INFO - 2023-11-06 14:32:08 --> Upload Class Initialized
INFO - 2023-11-06 14:32:08 --> Model "M_auth" initialized
INFO - 2023-11-06 14:32:08 --> Model "M_user" initialized
INFO - 2023-11-06 14:32:08 --> Model "M_produk" initialized
INFO - 2023-11-06 14:32:08 --> Controller Class Initialized
INFO - 2023-11-06 14:32:08 --> Model "M_pelanggan" initialized
INFO - 2023-11-06 14:32:08 --> Model "M_produk" initialized
DEBUG - 2023-11-06 14:32:08 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-06 14:32:08 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-06 14:32:08 --> Model "M_transaksi" initialized
INFO - 2023-11-06 14:32:08 --> Model "M_bank" initialized
INFO - 2023-11-06 14:32:08 --> Model "M_pesan" initialized
DEBUG - 2023-11-06 14:32:08 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-06 14:32:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-06 14:32:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-06 14:32:08 --> Final output sent to browser
DEBUG - 2023-11-06 14:32:08 --> Total execution time: 0.0040
ERROR - 2023-11-06 14:47:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-06 14:47:45 --> Config Class Initialized
INFO - 2023-11-06 14:47:45 --> Hooks Class Initialized
DEBUG - 2023-11-06 14:47:45 --> UTF-8 Support Enabled
INFO - 2023-11-06 14:47:45 --> Utf8 Class Initialized
INFO - 2023-11-06 14:47:45 --> URI Class Initialized
DEBUG - 2023-11-06 14:47:45 --> No URI present. Default controller set.
INFO - 2023-11-06 14:47:45 --> Router Class Initialized
INFO - 2023-11-06 14:47:45 --> Output Class Initialized
INFO - 2023-11-06 14:47:45 --> Security Class Initialized
DEBUG - 2023-11-06 14:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-06 14:47:45 --> Input Class Initialized
INFO - 2023-11-06 14:47:45 --> Language Class Initialized
INFO - 2023-11-06 14:47:45 --> Loader Class Initialized
INFO - 2023-11-06 14:47:45 --> Helper loaded: url_helper
INFO - 2023-11-06 14:47:45 --> Helper loaded: form_helper
INFO - 2023-11-06 14:47:45 --> Helper loaded: file_helper
INFO - 2023-11-06 14:47:45 --> Database Driver Class Initialized
DEBUG - 2023-11-06 14:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-06 14:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-06 14:47:45 --> Form Validation Class Initialized
INFO - 2023-11-06 14:47:45 --> Upload Class Initialized
INFO - 2023-11-06 14:47:45 --> Model "M_auth" initialized
INFO - 2023-11-06 14:47:45 --> Model "M_user" initialized
INFO - 2023-11-06 14:47:45 --> Model "M_produk" initialized
INFO - 2023-11-06 14:47:45 --> Controller Class Initialized
INFO - 2023-11-06 14:47:45 --> Model "M_pelanggan" initialized
INFO - 2023-11-06 14:47:45 --> Model "M_produk" initialized
DEBUG - 2023-11-06 14:47:45 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-06 14:47:45 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-06 14:47:45 --> Model "M_transaksi" initialized
INFO - 2023-11-06 14:47:45 --> Model "M_bank" initialized
INFO - 2023-11-06 14:47:45 --> Model "M_pesan" initialized
DEBUG - 2023-11-06 14:47:45 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-06 14:47:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-06 14:47:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-06 14:47:45 --> Final output sent to browser
DEBUG - 2023-11-06 14:47:45 --> Total execution time: 0.0438
ERROR - 2023-11-06 15:23:35 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-06 15:23:35 --> Config Class Initialized
INFO - 2023-11-06 15:23:35 --> Hooks Class Initialized
DEBUG - 2023-11-06 15:23:35 --> UTF-8 Support Enabled
INFO - 2023-11-06 15:23:35 --> Utf8 Class Initialized
INFO - 2023-11-06 15:23:35 --> URI Class Initialized
DEBUG - 2023-11-06 15:23:35 --> No URI present. Default controller set.
INFO - 2023-11-06 15:23:35 --> Router Class Initialized
INFO - 2023-11-06 15:23:35 --> Output Class Initialized
INFO - 2023-11-06 15:23:35 --> Security Class Initialized
DEBUG - 2023-11-06 15:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-06 15:23:35 --> Input Class Initialized
INFO - 2023-11-06 15:23:35 --> Language Class Initialized
INFO - 2023-11-06 15:23:35 --> Loader Class Initialized
INFO - 2023-11-06 15:23:35 --> Helper loaded: url_helper
INFO - 2023-11-06 15:23:35 --> Helper loaded: form_helper
INFO - 2023-11-06 15:23:35 --> Helper loaded: file_helper
INFO - 2023-11-06 15:23:35 --> Database Driver Class Initialized
DEBUG - 2023-11-06 15:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-06 15:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-06 15:23:35 --> Form Validation Class Initialized
INFO - 2023-11-06 15:23:35 --> Upload Class Initialized
INFO - 2023-11-06 15:23:35 --> Model "M_auth" initialized
INFO - 2023-11-06 15:23:35 --> Model "M_user" initialized
INFO - 2023-11-06 15:23:35 --> Model "M_produk" initialized
INFO - 2023-11-06 15:23:35 --> Controller Class Initialized
INFO - 2023-11-06 15:23:35 --> Model "M_pelanggan" initialized
INFO - 2023-11-06 15:23:35 --> Model "M_produk" initialized
DEBUG - 2023-11-06 15:23:35 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-06 15:23:35 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-06 15:23:35 --> Model "M_transaksi" initialized
INFO - 2023-11-06 15:23:35 --> Model "M_bank" initialized
INFO - 2023-11-06 15:23:35 --> Model "M_pesan" initialized
DEBUG - 2023-11-06 15:23:35 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-06 15:23:35 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-06 15:23:35 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-06 15:23:35 --> Final output sent to browser
DEBUG - 2023-11-06 15:23:35 --> Total execution time: 0.0387
ERROR - 2023-11-06 15:38:35 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-06 15:38:35 --> Config Class Initialized
INFO - 2023-11-06 15:38:35 --> Hooks Class Initialized
DEBUG - 2023-11-06 15:38:35 --> UTF-8 Support Enabled
INFO - 2023-11-06 15:38:35 --> Utf8 Class Initialized
INFO - 2023-11-06 15:38:35 --> URI Class Initialized
INFO - 2023-11-06 15:38:35 --> Router Class Initialized
INFO - 2023-11-06 15:38:35 --> Output Class Initialized
INFO - 2023-11-06 15:38:35 --> Security Class Initialized
DEBUG - 2023-11-06 15:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-06 15:38:35 --> Input Class Initialized
INFO - 2023-11-06 15:38:35 --> Language Class Initialized
INFO - 2023-11-06 15:38:35 --> Loader Class Initialized
INFO - 2023-11-06 15:38:35 --> Helper loaded: url_helper
INFO - 2023-11-06 15:38:35 --> Helper loaded: form_helper
INFO - 2023-11-06 15:38:35 --> Helper loaded: file_helper
INFO - 2023-11-06 15:38:35 --> Database Driver Class Initialized
DEBUG - 2023-11-06 15:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-06 15:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-06 15:38:35 --> Form Validation Class Initialized
INFO - 2023-11-06 15:38:35 --> Upload Class Initialized
INFO - 2023-11-06 15:38:35 --> Model "M_auth" initialized
INFO - 2023-11-06 15:38:35 --> Model "M_user" initialized
INFO - 2023-11-06 15:38:35 --> Model "M_produk" initialized
INFO - 2023-11-06 15:38:35 --> Controller Class Initialized
INFO - 2023-11-06 15:38:35 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-06 15:38:35 --> Final output sent to browser
DEBUG - 2023-11-06 15:38:35 --> Total execution time: 0.0261
ERROR - 2023-11-06 17:35:43 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-06 17:35:43 --> Config Class Initialized
INFO - 2023-11-06 17:35:43 --> Hooks Class Initialized
DEBUG - 2023-11-06 17:35:43 --> UTF-8 Support Enabled
INFO - 2023-11-06 17:35:43 --> Utf8 Class Initialized
INFO - 2023-11-06 17:35:43 --> URI Class Initialized
INFO - 2023-11-06 17:35:43 --> Router Class Initialized
INFO - 2023-11-06 17:35:43 --> Output Class Initialized
INFO - 2023-11-06 17:35:43 --> Security Class Initialized
DEBUG - 2023-11-06 17:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-06 17:35:43 --> Input Class Initialized
INFO - 2023-11-06 17:35:43 --> Language Class Initialized
INFO - 2023-11-06 17:35:43 --> Loader Class Initialized
INFO - 2023-11-06 17:35:43 --> Helper loaded: url_helper
INFO - 2023-11-06 17:35:43 --> Helper loaded: form_helper
INFO - 2023-11-06 17:35:43 --> Helper loaded: file_helper
INFO - 2023-11-06 17:35:43 --> Database Driver Class Initialized
DEBUG - 2023-11-06 17:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-06 17:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-06 17:35:43 --> Form Validation Class Initialized
INFO - 2023-11-06 17:35:43 --> Upload Class Initialized
INFO - 2023-11-06 17:35:43 --> Model "M_auth" initialized
INFO - 2023-11-06 17:35:43 --> Model "M_user" initialized
INFO - 2023-11-06 17:35:43 --> Model "M_produk" initialized
INFO - 2023-11-06 17:35:43 --> Controller Class Initialized
INFO - 2023-11-06 17:35:43 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-06 17:35:43 --> Final output sent to browser
DEBUG - 2023-11-06 17:35:43 --> Total execution time: 0.0352
ERROR - 2023-11-06 17:35:44 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-06 17:35:44 --> Config Class Initialized
INFO - 2023-11-06 17:35:44 --> Hooks Class Initialized
DEBUG - 2023-11-06 17:35:44 --> UTF-8 Support Enabled
INFO - 2023-11-06 17:35:44 --> Utf8 Class Initialized
INFO - 2023-11-06 17:35:44 --> URI Class Initialized
DEBUG - 2023-11-06 17:35:44 --> No URI present. Default controller set.
INFO - 2023-11-06 17:35:44 --> Router Class Initialized
INFO - 2023-11-06 17:35:44 --> Output Class Initialized
INFO - 2023-11-06 17:35:44 --> Security Class Initialized
DEBUG - 2023-11-06 17:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-06 17:35:44 --> Input Class Initialized
INFO - 2023-11-06 17:35:44 --> Language Class Initialized
INFO - 2023-11-06 17:35:44 --> Loader Class Initialized
INFO - 2023-11-06 17:35:44 --> Helper loaded: url_helper
INFO - 2023-11-06 17:35:44 --> Helper loaded: form_helper
INFO - 2023-11-06 17:35:44 --> Helper loaded: file_helper
INFO - 2023-11-06 17:35:44 --> Database Driver Class Initialized
DEBUG - 2023-11-06 17:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-06 17:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-06 17:35:44 --> Form Validation Class Initialized
INFO - 2023-11-06 17:35:44 --> Upload Class Initialized
INFO - 2023-11-06 17:35:44 --> Model "M_auth" initialized
INFO - 2023-11-06 17:35:44 --> Model "M_user" initialized
INFO - 2023-11-06 17:35:44 --> Model "M_produk" initialized
INFO - 2023-11-06 17:35:44 --> Controller Class Initialized
INFO - 2023-11-06 17:35:44 --> Model "M_pelanggan" initialized
INFO - 2023-11-06 17:35:44 --> Model "M_produk" initialized
DEBUG - 2023-11-06 17:35:44 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-06 17:35:44 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-06 17:35:44 --> Model "M_transaksi" initialized
INFO - 2023-11-06 17:35:44 --> Model "M_bank" initialized
INFO - 2023-11-06 17:35:44 --> Model "M_pesan" initialized
DEBUG - 2023-11-06 17:35:44 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-06 17:35:44 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-06 17:35:44 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-06 17:35:44 --> Final output sent to browser
DEBUG - 2023-11-06 17:35:44 --> Total execution time: 0.0115
ERROR - 2023-11-06 17:53:35 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-06 17:53:35 --> Config Class Initialized
INFO - 2023-11-06 17:53:35 --> Hooks Class Initialized
DEBUG - 2023-11-06 17:53:35 --> UTF-8 Support Enabled
INFO - 2023-11-06 17:53:35 --> Utf8 Class Initialized
INFO - 2023-11-06 17:53:35 --> URI Class Initialized
INFO - 2023-11-06 17:53:35 --> Router Class Initialized
INFO - 2023-11-06 17:53:35 --> Output Class Initialized
INFO - 2023-11-06 17:53:35 --> Security Class Initialized
DEBUG - 2023-11-06 17:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-06 17:53:35 --> Input Class Initialized
INFO - 2023-11-06 17:53:35 --> Language Class Initialized
INFO - 2023-11-06 17:53:35 --> Loader Class Initialized
INFO - 2023-11-06 17:53:35 --> Helper loaded: url_helper
INFO - 2023-11-06 17:53:35 --> Helper loaded: form_helper
INFO - 2023-11-06 17:53:35 --> Helper loaded: file_helper
INFO - 2023-11-06 17:53:35 --> Database Driver Class Initialized
DEBUG - 2023-11-06 17:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-06 17:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-06 17:53:35 --> Form Validation Class Initialized
INFO - 2023-11-06 17:53:35 --> Upload Class Initialized
INFO - 2023-11-06 17:53:35 --> Model "M_auth" initialized
INFO - 2023-11-06 17:53:35 --> Model "M_user" initialized
INFO - 2023-11-06 17:53:35 --> Model "M_produk" initialized
INFO - 2023-11-06 17:53:35 --> Controller Class Initialized
INFO - 2023-11-06 17:53:35 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-06 17:53:35 --> Final output sent to browser
DEBUG - 2023-11-06 17:53:35 --> Total execution time: 0.0264
ERROR - 2023-11-06 17:53:35 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-06 17:53:35 --> Config Class Initialized
INFO - 2023-11-06 17:53:35 --> Hooks Class Initialized
DEBUG - 2023-11-06 17:53:35 --> UTF-8 Support Enabled
INFO - 2023-11-06 17:53:35 --> Utf8 Class Initialized
INFO - 2023-11-06 17:53:35 --> URI Class Initialized
DEBUG - 2023-11-06 17:53:35 --> No URI present. Default controller set.
INFO - 2023-11-06 17:53:35 --> Router Class Initialized
INFO - 2023-11-06 17:53:35 --> Output Class Initialized
INFO - 2023-11-06 17:53:35 --> Security Class Initialized
DEBUG - 2023-11-06 17:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-06 17:53:35 --> Input Class Initialized
INFO - 2023-11-06 17:53:35 --> Language Class Initialized
INFO - 2023-11-06 17:53:35 --> Loader Class Initialized
INFO - 2023-11-06 17:53:35 --> Helper loaded: url_helper
INFO - 2023-11-06 17:53:35 --> Helper loaded: form_helper
INFO - 2023-11-06 17:53:35 --> Helper loaded: file_helper
INFO - 2023-11-06 17:53:35 --> Database Driver Class Initialized
DEBUG - 2023-11-06 17:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-06 17:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-06 17:53:35 --> Form Validation Class Initialized
INFO - 2023-11-06 17:53:35 --> Upload Class Initialized
INFO - 2023-11-06 17:53:35 --> Model "M_auth" initialized
INFO - 2023-11-06 17:53:35 --> Model "M_user" initialized
INFO - 2023-11-06 17:53:35 --> Model "M_produk" initialized
INFO - 2023-11-06 17:53:35 --> Controller Class Initialized
INFO - 2023-11-06 17:53:35 --> Model "M_pelanggan" initialized
INFO - 2023-11-06 17:53:35 --> Model "M_produk" initialized
DEBUG - 2023-11-06 17:53:35 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-06 17:53:35 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-06 17:53:35 --> Model "M_transaksi" initialized
INFO - 2023-11-06 17:53:35 --> Model "M_bank" initialized
INFO - 2023-11-06 17:53:35 --> Model "M_pesan" initialized
DEBUG - 2023-11-06 17:53:35 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-06 17:53:35 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-06 17:53:35 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-06 17:53:35 --> Final output sent to browser
DEBUG - 2023-11-06 17:53:35 --> Total execution time: 0.0112
ERROR - 2023-11-06 20:11:39 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-06 20:11:39 --> Config Class Initialized
INFO - 2023-11-06 20:11:39 --> Hooks Class Initialized
DEBUG - 2023-11-06 20:11:39 --> UTF-8 Support Enabled
INFO - 2023-11-06 20:11:39 --> Utf8 Class Initialized
INFO - 2023-11-06 20:11:39 --> URI Class Initialized
INFO - 2023-11-06 20:11:39 --> Router Class Initialized
INFO - 2023-11-06 20:11:39 --> Output Class Initialized
INFO - 2023-11-06 20:11:39 --> Security Class Initialized
DEBUG - 2023-11-06 20:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-06 20:11:39 --> Input Class Initialized
INFO - 2023-11-06 20:11:39 --> Language Class Initialized
INFO - 2023-11-06 20:11:39 --> Loader Class Initialized
INFO - 2023-11-06 20:11:39 --> Helper loaded: url_helper
INFO - 2023-11-06 20:11:39 --> Helper loaded: form_helper
INFO - 2023-11-06 20:11:39 --> Helper loaded: file_helper
INFO - 2023-11-06 20:11:39 --> Database Driver Class Initialized
DEBUG - 2023-11-06 20:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-06 20:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-06 20:11:39 --> Form Validation Class Initialized
INFO - 2023-11-06 20:11:39 --> Upload Class Initialized
INFO - 2023-11-06 20:11:39 --> Model "M_auth" initialized
INFO - 2023-11-06 20:11:39 --> Model "M_user" initialized
INFO - 2023-11-06 20:11:39 --> Model "M_produk" initialized
INFO - 2023-11-06 20:11:39 --> Controller Class Initialized
INFO - 2023-11-06 20:11:39 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-06 20:11:39 --> Final output sent to browser
DEBUG - 2023-11-06 20:11:39 --> Total execution time: 0.0349
ERROR - 2023-11-06 20:39:23 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-06 20:39:23 --> Config Class Initialized
INFO - 2023-11-06 20:39:23 --> Hooks Class Initialized
DEBUG - 2023-11-06 20:39:23 --> UTF-8 Support Enabled
INFO - 2023-11-06 20:39:23 --> Utf8 Class Initialized
INFO - 2023-11-06 20:39:23 --> URI Class Initialized
DEBUG - 2023-11-06 20:39:23 --> No URI present. Default controller set.
INFO - 2023-11-06 20:39:23 --> Router Class Initialized
INFO - 2023-11-06 20:39:23 --> Output Class Initialized
INFO - 2023-11-06 20:39:23 --> Security Class Initialized
DEBUG - 2023-11-06 20:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-06 20:39:23 --> Input Class Initialized
INFO - 2023-11-06 20:39:23 --> Language Class Initialized
INFO - 2023-11-06 20:39:23 --> Loader Class Initialized
INFO - 2023-11-06 20:39:23 --> Helper loaded: url_helper
INFO - 2023-11-06 20:39:23 --> Helper loaded: form_helper
INFO - 2023-11-06 20:39:23 --> Helper loaded: file_helper
INFO - 2023-11-06 20:39:23 --> Database Driver Class Initialized
DEBUG - 2023-11-06 20:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-06 20:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-06 20:39:23 --> Form Validation Class Initialized
INFO - 2023-11-06 20:39:23 --> Upload Class Initialized
INFO - 2023-11-06 20:39:23 --> Model "M_auth" initialized
INFO - 2023-11-06 20:39:23 --> Model "M_user" initialized
INFO - 2023-11-06 20:39:23 --> Model "M_produk" initialized
INFO - 2023-11-06 20:39:23 --> Controller Class Initialized
INFO - 2023-11-06 20:39:23 --> Model "M_pelanggan" initialized
INFO - 2023-11-06 20:39:23 --> Model "M_produk" initialized
DEBUG - 2023-11-06 20:39:23 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-06 20:39:23 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-06 20:39:23 --> Model "M_transaksi" initialized
INFO - 2023-11-06 20:39:23 --> Model "M_bank" initialized
INFO - 2023-11-06 20:39:23 --> Model "M_pesan" initialized
DEBUG - 2023-11-06 20:39:23 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-06 20:39:23 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-06 20:39:23 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-06 20:39:23 --> Final output sent to browser
DEBUG - 2023-11-06 20:39:23 --> Total execution time: 0.0347
