<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-24 02:13:21 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-24 02:13:21 --> Config Class Initialized
INFO - 2023-11-24 02:13:21 --> Hooks Class Initialized
DEBUG - 2023-11-24 02:13:21 --> UTF-8 Support Enabled
INFO - 2023-11-24 02:13:21 --> Utf8 Class Initialized
INFO - 2023-11-24 02:13:21 --> URI Class Initialized
DEBUG - 2023-11-24 02:13:21 --> No URI present. Default controller set.
INFO - 2023-11-24 02:13:21 --> Router Class Initialized
INFO - 2023-11-24 02:13:21 --> Output Class Initialized
INFO - 2023-11-24 02:13:21 --> Security Class Initialized
DEBUG - 2023-11-24 02:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-24 02:13:21 --> Input Class Initialized
INFO - 2023-11-24 02:13:21 --> Language Class Initialized
INFO - 2023-11-24 02:13:21 --> Loader Class Initialized
INFO - 2023-11-24 02:13:21 --> Helper loaded: url_helper
INFO - 2023-11-24 02:13:21 --> Helper loaded: form_helper
INFO - 2023-11-24 02:13:21 --> Helper loaded: file_helper
INFO - 2023-11-24 02:13:21 --> Database Driver Class Initialized
DEBUG - 2023-11-24 02:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-24 02:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-24 02:13:21 --> Form Validation Class Initialized
INFO - 2023-11-24 02:13:21 --> Upload Class Initialized
INFO - 2023-11-24 02:13:21 --> Model "M_auth" initialized
INFO - 2023-11-24 02:13:21 --> Model "M_user" initialized
INFO - 2023-11-24 02:13:21 --> Model "M_produk" initialized
INFO - 2023-11-24 02:13:21 --> Controller Class Initialized
INFO - 2023-11-24 02:13:21 --> Model "M_pelanggan" initialized
INFO - 2023-11-24 02:13:21 --> Model "M_produk" initialized
DEBUG - 2023-11-24 02:13:21 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-24 02:13:21 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-24 02:13:21 --> Model "M_transaksi" initialized
INFO - 2023-11-24 02:13:21 --> Model "M_bank" initialized
INFO - 2023-11-24 02:13:21 --> Model "M_pesan" initialized
DEBUG - 2023-11-24 02:13:21 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-24 02:13:21 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-24 02:13:21 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-24 02:13:21 --> Final output sent to browser
DEBUG - 2023-11-24 02:13:21 --> Total execution time: 0.0300
ERROR - 2023-11-24 03:08:26 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-24 03:08:26 --> Config Class Initialized
INFO - 2023-11-24 03:08:26 --> Hooks Class Initialized
DEBUG - 2023-11-24 03:08:26 --> UTF-8 Support Enabled
INFO - 2023-11-24 03:08:26 --> Utf8 Class Initialized
INFO - 2023-11-24 03:08:26 --> URI Class Initialized
INFO - 2023-11-24 03:08:26 --> Router Class Initialized
INFO - 2023-11-24 03:08:26 --> Output Class Initialized
INFO - 2023-11-24 03:08:26 --> Security Class Initialized
DEBUG - 2023-11-24 03:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-24 03:08:26 --> Input Class Initialized
INFO - 2023-11-24 03:08:26 --> Language Class Initialized
INFO - 2023-11-24 03:08:26 --> Loader Class Initialized
INFO - 2023-11-24 03:08:26 --> Helper loaded: url_helper
INFO - 2023-11-24 03:08:26 --> Helper loaded: form_helper
INFO - 2023-11-24 03:08:26 --> Helper loaded: file_helper
INFO - 2023-11-24 03:08:26 --> Database Driver Class Initialized
DEBUG - 2023-11-24 03:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-24 03:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-24 03:08:26 --> Form Validation Class Initialized
INFO - 2023-11-24 03:08:26 --> Upload Class Initialized
INFO - 2023-11-24 03:08:26 --> Model "M_auth" initialized
INFO - 2023-11-24 03:08:26 --> Model "M_user" initialized
INFO - 2023-11-24 03:08:26 --> Model "M_produk" initialized
INFO - 2023-11-24 03:08:26 --> Controller Class Initialized
INFO - 2023-11-24 03:08:26 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-24 03:08:26 --> Final output sent to browser
DEBUG - 2023-11-24 03:08:26 --> Total execution time: 0.0283
ERROR - 2023-11-24 03:08:26 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-24 03:08:26 --> Config Class Initialized
INFO - 2023-11-24 03:08:26 --> Hooks Class Initialized
DEBUG - 2023-11-24 03:08:26 --> UTF-8 Support Enabled
INFO - 2023-11-24 03:08:26 --> Utf8 Class Initialized
INFO - 2023-11-24 03:08:26 --> URI Class Initialized
INFO - 2023-11-24 03:08:26 --> Router Class Initialized
INFO - 2023-11-24 03:08:26 --> Output Class Initialized
INFO - 2023-11-24 03:08:26 --> Security Class Initialized
DEBUG - 2023-11-24 03:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-24 03:08:26 --> Input Class Initialized
INFO - 2023-11-24 03:08:26 --> Language Class Initialized
INFO - 2023-11-24 03:08:26 --> Loader Class Initialized
INFO - 2023-11-24 03:08:26 --> Helper loaded: url_helper
INFO - 2023-11-24 03:08:26 --> Helper loaded: form_helper
INFO - 2023-11-24 03:08:26 --> Helper loaded: file_helper
INFO - 2023-11-24 03:08:26 --> Database Driver Class Initialized
DEBUG - 2023-11-24 03:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-24 03:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-24 03:08:26 --> Form Validation Class Initialized
INFO - 2023-11-24 03:08:26 --> Upload Class Initialized
INFO - 2023-11-24 03:08:26 --> Model "M_auth" initialized
INFO - 2023-11-24 03:08:26 --> Model "M_user" initialized
INFO - 2023-11-24 03:08:26 --> Model "M_produk" initialized
INFO - 2023-11-24 03:08:26 --> Controller Class Initialized
INFO - 2023-11-24 03:08:26 --> Model "M_pelanggan" initialized
INFO - 2023-11-24 03:08:26 --> Model "M_produk" initialized
DEBUG - 2023-11-24 03:08:26 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-24 03:08:26 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-24 03:08:26 --> Model "M_transaksi" initialized
INFO - 2023-11-24 03:08:26 --> Model "M_bank" initialized
INFO - 2023-11-24 03:08:26 --> Model "M_pesan" initialized
DEBUG - 2023-11-24 03:08:26 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-24 03:08:26 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-24 03:08:26 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-24 03:08:26 --> Final output sent to browser
DEBUG - 2023-11-24 03:08:26 --> Total execution time: 0.0107
ERROR - 2023-11-24 07:48:04 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-24 07:48:04 --> Config Class Initialized
INFO - 2023-11-24 07:48:04 --> Hooks Class Initialized
DEBUG - 2023-11-24 07:48:04 --> UTF-8 Support Enabled
INFO - 2023-11-24 07:48:04 --> Utf8 Class Initialized
INFO - 2023-11-24 07:48:04 --> URI Class Initialized
DEBUG - 2023-11-24 07:48:04 --> No URI present. Default controller set.
INFO - 2023-11-24 07:48:04 --> Router Class Initialized
INFO - 2023-11-24 07:48:04 --> Output Class Initialized
INFO - 2023-11-24 07:48:04 --> Security Class Initialized
DEBUG - 2023-11-24 07:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-24 07:48:04 --> Input Class Initialized
INFO - 2023-11-24 07:48:04 --> Language Class Initialized
INFO - 2023-11-24 07:48:04 --> Loader Class Initialized
INFO - 2023-11-24 07:48:04 --> Helper loaded: url_helper
INFO - 2023-11-24 07:48:04 --> Helper loaded: form_helper
INFO - 2023-11-24 07:48:04 --> Helper loaded: file_helper
INFO - 2023-11-24 07:48:04 --> Database Driver Class Initialized
DEBUG - 2023-11-24 07:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-24 07:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-24 07:48:04 --> Form Validation Class Initialized
INFO - 2023-11-24 07:48:04 --> Upload Class Initialized
INFO - 2023-11-24 07:48:04 --> Model "M_auth" initialized
INFO - 2023-11-24 07:48:04 --> Model "M_user" initialized
INFO - 2023-11-24 07:48:04 --> Model "M_produk" initialized
INFO - 2023-11-24 07:48:04 --> Controller Class Initialized
INFO - 2023-11-24 07:48:04 --> Model "M_pelanggan" initialized
INFO - 2023-11-24 07:48:04 --> Model "M_produk" initialized
DEBUG - 2023-11-24 07:48:04 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-24 07:48:04 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-24 07:48:04 --> Model "M_transaksi" initialized
INFO - 2023-11-24 07:48:04 --> Model "M_bank" initialized
INFO - 2023-11-24 07:48:04 --> Model "M_pesan" initialized
DEBUG - 2023-11-24 07:48:04 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-24 07:48:04 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-24 07:48:04 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-24 07:48:04 --> Final output sent to browser
DEBUG - 2023-11-24 07:48:04 --> Total execution time: 0.0479
ERROR - 2023-11-24 09:40:41 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-24 09:40:41 --> Config Class Initialized
INFO - 2023-11-24 09:40:41 --> Hooks Class Initialized
DEBUG - 2023-11-24 09:40:41 --> UTF-8 Support Enabled
INFO - 2023-11-24 09:40:41 --> Utf8 Class Initialized
INFO - 2023-11-24 09:40:41 --> URI Class Initialized
DEBUG - 2023-11-24 09:40:41 --> No URI present. Default controller set.
INFO - 2023-11-24 09:40:41 --> Router Class Initialized
INFO - 2023-11-24 09:40:41 --> Output Class Initialized
INFO - 2023-11-24 09:40:41 --> Security Class Initialized
DEBUG - 2023-11-24 09:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-24 09:40:41 --> Input Class Initialized
INFO - 2023-11-24 09:40:41 --> Language Class Initialized
INFO - 2023-11-24 09:40:41 --> Loader Class Initialized
INFO - 2023-11-24 09:40:41 --> Helper loaded: url_helper
INFO - 2023-11-24 09:40:41 --> Helper loaded: form_helper
INFO - 2023-11-24 09:40:41 --> Helper loaded: file_helper
INFO - 2023-11-24 09:40:41 --> Database Driver Class Initialized
DEBUG - 2023-11-24 09:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-24 09:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-24 09:40:41 --> Form Validation Class Initialized
INFO - 2023-11-24 09:40:41 --> Upload Class Initialized
INFO - 2023-11-24 09:40:41 --> Model "M_auth" initialized
INFO - 2023-11-24 09:40:41 --> Model "M_user" initialized
INFO - 2023-11-24 09:40:41 --> Model "M_produk" initialized
INFO - 2023-11-24 09:40:41 --> Controller Class Initialized
INFO - 2023-11-24 09:40:41 --> Model "M_pelanggan" initialized
INFO - 2023-11-24 09:40:41 --> Model "M_produk" initialized
DEBUG - 2023-11-24 09:40:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-24 09:40:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-24 09:40:41 --> Model "M_transaksi" initialized
INFO - 2023-11-24 09:40:41 --> Model "M_bank" initialized
INFO - 2023-11-24 09:40:41 --> Model "M_pesan" initialized
DEBUG - 2023-11-24 09:40:41 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-24 09:40:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-24 09:40:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-24 09:40:41 --> Final output sent to browser
DEBUG - 2023-11-24 09:40:41 --> Total execution time: 0.0337
ERROR - 2023-11-24 10:33:47 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-24 10:33:47 --> Config Class Initialized
INFO - 2023-11-24 10:33:47 --> Hooks Class Initialized
DEBUG - 2023-11-24 10:33:47 --> UTF-8 Support Enabled
INFO - 2023-11-24 10:33:47 --> Utf8 Class Initialized
INFO - 2023-11-24 10:33:47 --> URI Class Initialized
INFO - 2023-11-24 10:33:47 --> Router Class Initialized
INFO - 2023-11-24 10:33:47 --> Output Class Initialized
INFO - 2023-11-24 10:33:47 --> Security Class Initialized
DEBUG - 2023-11-24 10:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-24 10:33:47 --> Input Class Initialized
INFO - 2023-11-24 10:33:47 --> Language Class Initialized
INFO - 2023-11-24 10:33:47 --> Loader Class Initialized
INFO - 2023-11-24 10:33:47 --> Helper loaded: url_helper
INFO - 2023-11-24 10:33:47 --> Helper loaded: form_helper
INFO - 2023-11-24 10:33:47 --> Helper loaded: file_helper
INFO - 2023-11-24 10:33:47 --> Database Driver Class Initialized
DEBUG - 2023-11-24 10:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-24 10:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-24 10:33:47 --> Form Validation Class Initialized
INFO - 2023-11-24 10:33:47 --> Upload Class Initialized
INFO - 2023-11-24 10:33:47 --> Model "M_auth" initialized
INFO - 2023-11-24 10:33:47 --> Model "M_user" initialized
INFO - 2023-11-24 10:33:47 --> Model "M_produk" initialized
INFO - 2023-11-24 10:33:47 --> Controller Class Initialized
INFO - 2023-11-24 10:33:47 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-24 10:33:47 --> Final output sent to browser
DEBUG - 2023-11-24 10:33:47 --> Total execution time: 0.0255
ERROR - 2023-11-24 10:33:49 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-24 10:33:49 --> Config Class Initialized
INFO - 2023-11-24 10:33:49 --> Hooks Class Initialized
DEBUG - 2023-11-24 10:33:49 --> UTF-8 Support Enabled
INFO - 2023-11-24 10:33:49 --> Utf8 Class Initialized
INFO - 2023-11-24 10:33:49 --> URI Class Initialized
INFO - 2023-11-24 10:33:49 --> Router Class Initialized
INFO - 2023-11-24 10:33:49 --> Output Class Initialized
INFO - 2023-11-24 10:33:49 --> Security Class Initialized
DEBUG - 2023-11-24 10:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-24 10:33:49 --> Input Class Initialized
INFO - 2023-11-24 10:33:49 --> Language Class Initialized
INFO - 2023-11-24 10:33:49 --> Loader Class Initialized
INFO - 2023-11-24 10:33:49 --> Helper loaded: url_helper
INFO - 2023-11-24 10:33:49 --> Helper loaded: form_helper
INFO - 2023-11-24 10:33:49 --> Helper loaded: file_helper
INFO - 2023-11-24 10:33:49 --> Database Driver Class Initialized
DEBUG - 2023-11-24 10:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-24 10:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-24 10:33:49 --> Form Validation Class Initialized
INFO - 2023-11-24 10:33:49 --> Upload Class Initialized
INFO - 2023-11-24 10:33:49 --> Model "M_auth" initialized
INFO - 2023-11-24 10:33:49 --> Model "M_user" initialized
INFO - 2023-11-24 10:33:49 --> Model "M_produk" initialized
INFO - 2023-11-24 10:33:49 --> Controller Class Initialized
INFO - 2023-11-24 10:33:49 --> Model "M_pelanggan" initialized
INFO - 2023-11-24 10:33:49 --> Model "M_produk" initialized
DEBUG - 2023-11-24 10:33:49 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-24 10:33:49 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-24 10:33:49 --> Model "M_transaksi" initialized
INFO - 2023-11-24 10:33:49 --> Model "M_bank" initialized
INFO - 2023-11-24 10:33:49 --> Model "M_pesan" initialized
DEBUG - 2023-11-24 10:33:49 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
ERROR - 2023-11-24 10:33:49 --> Severity: Warning --> Attempt to read property "nama_merek" on null /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_kategori_detail.php 112
INFO - 2023-11-24 10:33:49 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-24 10:33:49 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_kategori_detail.php
INFO - 2023-11-24 10:33:49 --> Final output sent to browser
DEBUG - 2023-11-24 10:33:49 --> Total execution time: 0.0104
ERROR - 2023-11-24 12:03:47 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-24 12:03:47 --> Config Class Initialized
INFO - 2023-11-24 12:03:47 --> Hooks Class Initialized
DEBUG - 2023-11-24 12:03:47 --> UTF-8 Support Enabled
INFO - 2023-11-24 12:03:47 --> Utf8 Class Initialized
INFO - 2023-11-24 12:03:47 --> URI Class Initialized
INFO - 2023-11-24 12:03:47 --> Router Class Initialized
INFO - 2023-11-24 12:03:47 --> Output Class Initialized
INFO - 2023-11-24 12:03:47 --> Security Class Initialized
DEBUG - 2023-11-24 12:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-24 12:03:47 --> Input Class Initialized
INFO - 2023-11-24 12:03:47 --> Language Class Initialized
INFO - 2023-11-24 12:03:47 --> Loader Class Initialized
INFO - 2023-11-24 12:03:47 --> Helper loaded: url_helper
INFO - 2023-11-24 12:03:47 --> Helper loaded: form_helper
INFO - 2023-11-24 12:03:47 --> Helper loaded: file_helper
INFO - 2023-11-24 12:03:47 --> Database Driver Class Initialized
DEBUG - 2023-11-24 12:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-24 12:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-24 12:03:47 --> Form Validation Class Initialized
INFO - 2023-11-24 12:03:47 --> Upload Class Initialized
INFO - 2023-11-24 12:03:47 --> Model "M_auth" initialized
INFO - 2023-11-24 12:03:47 --> Model "M_user" initialized
INFO - 2023-11-24 12:03:47 --> Model "M_produk" initialized
INFO - 2023-11-24 12:03:47 --> Controller Class Initialized
INFO - 2023-11-24 12:03:47 --> Model "M_pelanggan" initialized
INFO - 2023-11-24 12:03:47 --> Model "M_produk" initialized
DEBUG - 2023-11-24 12:03:47 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-24 12:03:47 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-24 12:03:47 --> Model "M_transaksi" initialized
INFO - 2023-11-24 12:03:47 --> Model "M_bank" initialized
INFO - 2023-11-24 12:03:47 --> Model "M_pesan" initialized
DEBUG - 2023-11-24 12:03:47 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-24 12:03:47 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-24 12:03:47 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_kategori_detail.php
INFO - 2023-11-24 12:03:47 --> Final output sent to browser
DEBUG - 2023-11-24 12:03:47 --> Total execution time: 0.0319
ERROR - 2023-11-24 14:05:32 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-24 14:05:32 --> Config Class Initialized
INFO - 2023-11-24 14:05:32 --> Hooks Class Initialized
DEBUG - 2023-11-24 14:05:32 --> UTF-8 Support Enabled
INFO - 2023-11-24 14:05:32 --> Utf8 Class Initialized
INFO - 2023-11-24 14:05:32 --> URI Class Initialized
INFO - 2023-11-24 14:05:32 --> Router Class Initialized
INFO - 2023-11-24 14:05:32 --> Output Class Initialized
INFO - 2023-11-24 14:05:32 --> Security Class Initialized
DEBUG - 2023-11-24 14:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-24 14:05:32 --> Input Class Initialized
INFO - 2023-11-24 14:05:32 --> Language Class Initialized
INFO - 2023-11-24 14:05:32 --> Loader Class Initialized
INFO - 2023-11-24 14:05:32 --> Helper loaded: url_helper
INFO - 2023-11-24 14:05:32 --> Helper loaded: form_helper
INFO - 2023-11-24 14:05:32 --> Helper loaded: file_helper
INFO - 2023-11-24 14:05:32 --> Database Driver Class Initialized
DEBUG - 2023-11-24 14:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-24 14:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-24 14:05:32 --> Form Validation Class Initialized
INFO - 2023-11-24 14:05:32 --> Upload Class Initialized
INFO - 2023-11-24 14:05:32 --> Model "M_auth" initialized
INFO - 2023-11-24 14:05:32 --> Model "M_user" initialized
INFO - 2023-11-24 14:05:32 --> Model "M_produk" initialized
INFO - 2023-11-24 14:05:32 --> Controller Class Initialized
INFO - 2023-11-24 14:05:32 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-24 14:05:32 --> Final output sent to browser
DEBUG - 2023-11-24 14:05:32 --> Total execution time: 0.0291
ERROR - 2023-11-24 15:16:28 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-24 15:16:28 --> Config Class Initialized
INFO - 2023-11-24 15:16:28 --> Hooks Class Initialized
DEBUG - 2023-11-24 15:16:28 --> UTF-8 Support Enabled
INFO - 2023-11-24 15:16:28 --> Utf8 Class Initialized
INFO - 2023-11-24 15:16:28 --> URI Class Initialized
INFO - 2023-11-24 15:16:28 --> Router Class Initialized
INFO - 2023-11-24 15:16:28 --> Output Class Initialized
INFO - 2023-11-24 15:16:28 --> Security Class Initialized
DEBUG - 2023-11-24 15:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-24 15:16:28 --> Input Class Initialized
INFO - 2023-11-24 15:16:28 --> Language Class Initialized
INFO - 2023-11-24 15:16:28 --> Loader Class Initialized
INFO - 2023-11-24 15:16:28 --> Helper loaded: url_helper
INFO - 2023-11-24 15:16:28 --> Helper loaded: form_helper
INFO - 2023-11-24 15:16:28 --> Helper loaded: file_helper
INFO - 2023-11-24 15:16:28 --> Database Driver Class Initialized
DEBUG - 2023-11-24 15:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-24 15:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-24 15:16:28 --> Form Validation Class Initialized
INFO - 2023-11-24 15:16:28 --> Upload Class Initialized
INFO - 2023-11-24 15:16:28 --> Model "M_auth" initialized
INFO - 2023-11-24 15:16:28 --> Model "M_user" initialized
INFO - 2023-11-24 15:16:28 --> Model "M_produk" initialized
INFO - 2023-11-24 15:16:28 --> Controller Class Initialized
INFO - 2023-11-24 15:16:28 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-24 15:16:28 --> Final output sent to browser
DEBUG - 2023-11-24 15:16:28 --> Total execution time: 0.0269
ERROR - 2023-11-24 16:29:42 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-24 16:29:42 --> Config Class Initialized
INFO - 2023-11-24 16:29:42 --> Hooks Class Initialized
DEBUG - 2023-11-24 16:29:42 --> UTF-8 Support Enabled
INFO - 2023-11-24 16:29:42 --> Utf8 Class Initialized
INFO - 2023-11-24 16:29:42 --> URI Class Initialized
DEBUG - 2023-11-24 16:29:42 --> No URI present. Default controller set.
INFO - 2023-11-24 16:29:42 --> Router Class Initialized
INFO - 2023-11-24 16:29:42 --> Output Class Initialized
INFO - 2023-11-24 16:29:42 --> Security Class Initialized
DEBUG - 2023-11-24 16:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-24 16:29:42 --> Input Class Initialized
INFO - 2023-11-24 16:29:42 --> Language Class Initialized
INFO - 2023-11-24 16:29:42 --> Loader Class Initialized
INFO - 2023-11-24 16:29:42 --> Helper loaded: url_helper
INFO - 2023-11-24 16:29:42 --> Helper loaded: form_helper
INFO - 2023-11-24 16:29:42 --> Helper loaded: file_helper
INFO - 2023-11-24 16:29:42 --> Database Driver Class Initialized
DEBUG - 2023-11-24 16:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-24 16:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-24 16:29:42 --> Form Validation Class Initialized
INFO - 2023-11-24 16:29:42 --> Upload Class Initialized
INFO - 2023-11-24 16:29:42 --> Model "M_auth" initialized
INFO - 2023-11-24 16:29:42 --> Model "M_user" initialized
INFO - 2023-11-24 16:29:42 --> Model "M_produk" initialized
INFO - 2023-11-24 16:29:42 --> Controller Class Initialized
INFO - 2023-11-24 16:29:42 --> Model "M_pelanggan" initialized
INFO - 2023-11-24 16:29:42 --> Model "M_produk" initialized
DEBUG - 2023-11-24 16:29:42 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-24 16:29:42 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-24 16:29:42 --> Model "M_transaksi" initialized
INFO - 2023-11-24 16:29:42 --> Model "M_bank" initialized
INFO - 2023-11-24 16:29:42 --> Model "M_pesan" initialized
DEBUG - 2023-11-24 16:29:42 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-24 16:29:42 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-24 16:29:42 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-24 16:29:42 --> Final output sent to browser
DEBUG - 2023-11-24 16:29:42 --> Total execution time: 0.0331
ERROR - 2023-11-24 16:29:43 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-24 16:29:43 --> Config Class Initialized
INFO - 2023-11-24 16:29:43 --> Hooks Class Initialized
DEBUG - 2023-11-24 16:29:43 --> UTF-8 Support Enabled
INFO - 2023-11-24 16:29:43 --> Utf8 Class Initialized
INFO - 2023-11-24 16:29:43 --> URI Class Initialized
DEBUG - 2023-11-24 16:29:43 --> No URI present. Default controller set.
INFO - 2023-11-24 16:29:43 --> Router Class Initialized
INFO - 2023-11-24 16:29:43 --> Output Class Initialized
INFO - 2023-11-24 16:29:43 --> Security Class Initialized
DEBUG - 2023-11-24 16:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-24 16:29:43 --> Input Class Initialized
INFO - 2023-11-24 16:29:43 --> Language Class Initialized
INFO - 2023-11-24 16:29:43 --> Loader Class Initialized
INFO - 2023-11-24 16:29:43 --> Helper loaded: url_helper
INFO - 2023-11-24 16:29:43 --> Helper loaded: form_helper
INFO - 2023-11-24 16:29:43 --> Helper loaded: file_helper
INFO - 2023-11-24 16:29:43 --> Database Driver Class Initialized
DEBUG - 2023-11-24 16:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-24 16:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-24 16:29:43 --> Form Validation Class Initialized
INFO - 2023-11-24 16:29:43 --> Upload Class Initialized
INFO - 2023-11-24 16:29:43 --> Model "M_auth" initialized
INFO - 2023-11-24 16:29:43 --> Model "M_user" initialized
INFO - 2023-11-24 16:29:43 --> Model "M_produk" initialized
INFO - 2023-11-24 16:29:43 --> Controller Class Initialized
INFO - 2023-11-24 16:29:43 --> Model "M_pelanggan" initialized
INFO - 2023-11-24 16:29:43 --> Model "M_produk" initialized
DEBUG - 2023-11-24 16:29:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-24 16:29:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-24 16:29:43 --> Model "M_transaksi" initialized
INFO - 2023-11-24 16:29:43 --> Model "M_bank" initialized
INFO - 2023-11-24 16:29:43 --> Model "M_pesan" initialized
DEBUG - 2023-11-24 16:29:43 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-24 16:29:43 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-24 16:29:43 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-24 16:29:43 --> Final output sent to browser
DEBUG - 2023-11-24 16:29:43 --> Total execution time: 0.0032
ERROR - 2023-11-24 18:56:03 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-24 18:56:03 --> Config Class Initialized
INFO - 2023-11-24 18:56:03 --> Hooks Class Initialized
DEBUG - 2023-11-24 18:56:03 --> UTF-8 Support Enabled
INFO - 2023-11-24 18:56:03 --> Utf8 Class Initialized
INFO - 2023-11-24 18:56:03 --> URI Class Initialized
INFO - 2023-11-24 18:56:03 --> Router Class Initialized
INFO - 2023-11-24 18:56:03 --> Output Class Initialized
INFO - 2023-11-24 18:56:03 --> Security Class Initialized
DEBUG - 2023-11-24 18:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-24 18:56:03 --> Input Class Initialized
INFO - 2023-11-24 18:56:03 --> Language Class Initialized
INFO - 2023-11-24 18:56:03 --> Loader Class Initialized
INFO - 2023-11-24 18:56:03 --> Helper loaded: url_helper
INFO - 2023-11-24 18:56:03 --> Helper loaded: form_helper
INFO - 2023-11-24 18:56:03 --> Helper loaded: file_helper
INFO - 2023-11-24 18:56:03 --> Database Driver Class Initialized
DEBUG - 2023-11-24 18:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-24 18:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-24 18:56:03 --> Form Validation Class Initialized
INFO - 2023-11-24 18:56:03 --> Upload Class Initialized
INFO - 2023-11-24 18:56:03 --> Model "M_auth" initialized
INFO - 2023-11-24 18:56:03 --> Model "M_user" initialized
INFO - 2023-11-24 18:56:03 --> Model "M_produk" initialized
INFO - 2023-11-24 18:56:03 --> Controller Class Initialized
INFO - 2023-11-24 18:56:03 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-24 18:56:03 --> Final output sent to browser
DEBUG - 2023-11-24 18:56:03 --> Total execution time: 0.0258
ERROR - 2023-11-24 18:56:04 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-24 18:56:04 --> Config Class Initialized
INFO - 2023-11-24 18:56:04 --> Hooks Class Initialized
DEBUG - 2023-11-24 18:56:04 --> UTF-8 Support Enabled
INFO - 2023-11-24 18:56:04 --> Utf8 Class Initialized
INFO - 2023-11-24 18:56:04 --> URI Class Initialized
DEBUG - 2023-11-24 18:56:04 --> No URI present. Default controller set.
INFO - 2023-11-24 18:56:04 --> Router Class Initialized
INFO - 2023-11-24 18:56:04 --> Output Class Initialized
INFO - 2023-11-24 18:56:04 --> Security Class Initialized
DEBUG - 2023-11-24 18:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-24 18:56:04 --> Input Class Initialized
INFO - 2023-11-24 18:56:04 --> Language Class Initialized
INFO - 2023-11-24 18:56:04 --> Loader Class Initialized
INFO - 2023-11-24 18:56:04 --> Helper loaded: url_helper
INFO - 2023-11-24 18:56:04 --> Helper loaded: form_helper
INFO - 2023-11-24 18:56:04 --> Helper loaded: file_helper
INFO - 2023-11-24 18:56:04 --> Database Driver Class Initialized
DEBUG - 2023-11-24 18:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-24 18:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-24 18:56:04 --> Form Validation Class Initialized
INFO - 2023-11-24 18:56:04 --> Upload Class Initialized
INFO - 2023-11-24 18:56:04 --> Model "M_auth" initialized
INFO - 2023-11-24 18:56:04 --> Model "M_user" initialized
INFO - 2023-11-24 18:56:04 --> Model "M_produk" initialized
INFO - 2023-11-24 18:56:04 --> Controller Class Initialized
INFO - 2023-11-24 18:56:04 --> Model "M_pelanggan" initialized
INFO - 2023-11-24 18:56:04 --> Model "M_produk" initialized
DEBUG - 2023-11-24 18:56:04 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-24 18:56:04 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-24 18:56:04 --> Model "M_transaksi" initialized
INFO - 2023-11-24 18:56:04 --> Model "M_bank" initialized
INFO - 2023-11-24 18:56:04 --> Model "M_pesan" initialized
DEBUG - 2023-11-24 18:56:04 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-24 18:56:04 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-24 18:56:04 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-24 18:56:04 --> Final output sent to browser
DEBUG - 2023-11-24 18:56:04 --> Total execution time: 0.0089
ERROR - 2023-11-24 23:19:54 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-24 23:19:54 --> Config Class Initialized
INFO - 2023-11-24 23:19:54 --> Hooks Class Initialized
DEBUG - 2023-11-24 23:19:54 --> UTF-8 Support Enabled
INFO - 2023-11-24 23:19:54 --> Utf8 Class Initialized
INFO - 2023-11-24 23:19:54 --> URI Class Initialized
DEBUG - 2023-11-24 23:19:54 --> No URI present. Default controller set.
INFO - 2023-11-24 23:19:54 --> Router Class Initialized
INFO - 2023-11-24 23:19:54 --> Output Class Initialized
INFO - 2023-11-24 23:19:54 --> Security Class Initialized
DEBUG - 2023-11-24 23:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-24 23:19:54 --> Input Class Initialized
INFO - 2023-11-24 23:19:54 --> Language Class Initialized
INFO - 2023-11-24 23:19:54 --> Loader Class Initialized
INFO - 2023-11-24 23:19:54 --> Helper loaded: url_helper
INFO - 2023-11-24 23:19:54 --> Helper loaded: form_helper
INFO - 2023-11-24 23:19:54 --> Helper loaded: file_helper
INFO - 2023-11-24 23:19:54 --> Database Driver Class Initialized
DEBUG - 2023-11-24 23:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-24 23:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-24 23:19:54 --> Form Validation Class Initialized
INFO - 2023-11-24 23:19:54 --> Upload Class Initialized
INFO - 2023-11-24 23:19:54 --> Model "M_auth" initialized
INFO - 2023-11-24 23:19:54 --> Model "M_user" initialized
INFO - 2023-11-24 23:19:54 --> Model "M_produk" initialized
INFO - 2023-11-24 23:19:54 --> Controller Class Initialized
INFO - 2023-11-24 23:19:54 --> Model "M_pelanggan" initialized
INFO - 2023-11-24 23:19:54 --> Model "M_produk" initialized
DEBUG - 2023-11-24 23:19:54 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-24 23:19:54 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-24 23:19:54 --> Model "M_transaksi" initialized
INFO - 2023-11-24 23:19:54 --> Model "M_bank" initialized
INFO - 2023-11-24 23:19:54 --> Model "M_pesan" initialized
DEBUG - 2023-11-24 23:19:54 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-24 23:19:54 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-24 23:19:54 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-24 23:19:54 --> Final output sent to browser
DEBUG - 2023-11-24 23:19:54 --> Total execution time: 0.0315
