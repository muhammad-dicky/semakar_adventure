<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-09 00:15:58 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-09 00:15:58 --> Config Class Initialized
INFO - 2023-11-09 00:15:58 --> Hooks Class Initialized
DEBUG - 2023-11-09 00:15:58 --> UTF-8 Support Enabled
INFO - 2023-11-09 00:15:58 --> Utf8 Class Initialized
INFO - 2023-11-09 00:15:58 --> URI Class Initialized
INFO - 2023-11-09 00:15:58 --> Router Class Initialized
INFO - 2023-11-09 00:15:58 --> Output Class Initialized
INFO - 2023-11-09 00:15:58 --> Security Class Initialized
DEBUG - 2023-11-09 00:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 00:15:58 --> Input Class Initialized
INFO - 2023-11-09 00:15:58 --> Language Class Initialized
INFO - 2023-11-09 00:15:58 --> Loader Class Initialized
INFO - 2023-11-09 00:15:58 --> Helper loaded: url_helper
INFO - 2023-11-09 00:15:58 --> Helper loaded: form_helper
INFO - 2023-11-09 00:15:58 --> Helper loaded: file_helper
INFO - 2023-11-09 00:15:58 --> Database Driver Class Initialized
DEBUG - 2023-11-09 00:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 00:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 00:15:58 --> Form Validation Class Initialized
INFO - 2023-11-09 00:15:58 --> Upload Class Initialized
INFO - 2023-11-09 00:15:58 --> Model "M_auth" initialized
INFO - 2023-11-09 00:15:58 --> Model "M_user" initialized
INFO - 2023-11-09 00:15:58 --> Model "M_produk" initialized
INFO - 2023-11-09 00:15:58 --> Controller Class Initialized
INFO - 2023-11-09 00:15:58 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-09 00:15:58 --> Final output sent to browser
DEBUG - 2023-11-09 00:15:58 --> Total execution time: 0.0322
ERROR - 2023-11-09 00:15:59 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-09 00:15:59 --> Config Class Initialized
INFO - 2023-11-09 00:15:59 --> Hooks Class Initialized
DEBUG - 2023-11-09 00:15:59 --> UTF-8 Support Enabled
INFO - 2023-11-09 00:15:59 --> Utf8 Class Initialized
INFO - 2023-11-09 00:15:59 --> URI Class Initialized
DEBUG - 2023-11-09 00:15:59 --> No URI present. Default controller set.
INFO - 2023-11-09 00:15:59 --> Router Class Initialized
INFO - 2023-11-09 00:15:59 --> Output Class Initialized
INFO - 2023-11-09 00:15:59 --> Security Class Initialized
DEBUG - 2023-11-09 00:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 00:15:59 --> Input Class Initialized
INFO - 2023-11-09 00:15:59 --> Language Class Initialized
INFO - 2023-11-09 00:15:59 --> Loader Class Initialized
INFO - 2023-11-09 00:15:59 --> Helper loaded: url_helper
INFO - 2023-11-09 00:15:59 --> Helper loaded: form_helper
INFO - 2023-11-09 00:15:59 --> Helper loaded: file_helper
INFO - 2023-11-09 00:15:59 --> Database Driver Class Initialized
DEBUG - 2023-11-09 00:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 00:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 00:15:59 --> Form Validation Class Initialized
INFO - 2023-11-09 00:15:59 --> Upload Class Initialized
INFO - 2023-11-09 00:15:59 --> Model "M_auth" initialized
INFO - 2023-11-09 00:15:59 --> Model "M_user" initialized
INFO - 2023-11-09 00:15:59 --> Model "M_produk" initialized
INFO - 2023-11-09 00:15:59 --> Controller Class Initialized
INFO - 2023-11-09 00:15:59 --> Model "M_pelanggan" initialized
INFO - 2023-11-09 00:15:59 --> Model "M_produk" initialized
DEBUG - 2023-11-09 00:15:59 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-09 00:15:59 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-09 00:15:59 --> Model "M_transaksi" initialized
INFO - 2023-11-09 00:15:59 --> Model "M_bank" initialized
INFO - 2023-11-09 00:15:59 --> Model "M_pesan" initialized
DEBUG - 2023-11-09 00:15:59 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-09 00:15:59 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-09 00:15:59 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-09 00:15:59 --> Final output sent to browser
DEBUG - 2023-11-09 00:15:59 --> Total execution time: 0.0098
ERROR - 2023-11-09 01:17:17 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-09 01:17:17 --> Config Class Initialized
INFO - 2023-11-09 01:17:17 --> Hooks Class Initialized
DEBUG - 2023-11-09 01:17:17 --> UTF-8 Support Enabled
INFO - 2023-11-09 01:17:17 --> Utf8 Class Initialized
INFO - 2023-11-09 01:17:17 --> URI Class Initialized
INFO - 2023-11-09 01:17:17 --> Router Class Initialized
INFO - 2023-11-09 01:17:17 --> Output Class Initialized
INFO - 2023-11-09 01:17:17 --> Security Class Initialized
DEBUG - 2023-11-09 01:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 01:17:17 --> Input Class Initialized
INFO - 2023-11-09 01:17:17 --> Language Class Initialized
INFO - 2023-11-09 01:17:17 --> Loader Class Initialized
INFO - 2023-11-09 01:17:17 --> Helper loaded: url_helper
INFO - 2023-11-09 01:17:17 --> Helper loaded: form_helper
INFO - 2023-11-09 01:17:17 --> Helper loaded: file_helper
INFO - 2023-11-09 01:17:17 --> Database Driver Class Initialized
DEBUG - 2023-11-09 01:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 01:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 01:17:17 --> Form Validation Class Initialized
INFO - 2023-11-09 01:17:17 --> Upload Class Initialized
INFO - 2023-11-09 01:17:17 --> Model "M_auth" initialized
INFO - 2023-11-09 01:17:17 --> Model "M_user" initialized
INFO - 2023-11-09 01:17:17 --> Model "M_produk" initialized
INFO - 2023-11-09 01:17:17 --> Controller Class Initialized
INFO - 2023-11-09 01:17:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-09 01:17:17 --> Final output sent to browser
DEBUG - 2023-11-09 01:17:17 --> Total execution time: 0.0363
ERROR - 2023-11-09 01:57:30 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-09 01:57:30 --> Config Class Initialized
INFO - 2023-11-09 01:57:30 --> Hooks Class Initialized
DEBUG - 2023-11-09 01:57:30 --> UTF-8 Support Enabled
INFO - 2023-11-09 01:57:30 --> Utf8 Class Initialized
INFO - 2023-11-09 01:57:30 --> URI Class Initialized
DEBUG - 2023-11-09 01:57:30 --> No URI present. Default controller set.
INFO - 2023-11-09 01:57:30 --> Router Class Initialized
INFO - 2023-11-09 01:57:30 --> Output Class Initialized
INFO - 2023-11-09 01:57:30 --> Security Class Initialized
DEBUG - 2023-11-09 01:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 01:57:30 --> Input Class Initialized
INFO - 2023-11-09 01:57:30 --> Language Class Initialized
INFO - 2023-11-09 01:57:30 --> Loader Class Initialized
INFO - 2023-11-09 01:57:30 --> Helper loaded: url_helper
INFO - 2023-11-09 01:57:30 --> Helper loaded: form_helper
INFO - 2023-11-09 01:57:30 --> Helper loaded: file_helper
INFO - 2023-11-09 01:57:30 --> Database Driver Class Initialized
DEBUG - 2023-11-09 01:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 01:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 01:57:30 --> Form Validation Class Initialized
INFO - 2023-11-09 01:57:30 --> Upload Class Initialized
INFO - 2023-11-09 01:57:30 --> Model "M_auth" initialized
INFO - 2023-11-09 01:57:30 --> Model "M_user" initialized
INFO - 2023-11-09 01:57:30 --> Model "M_produk" initialized
INFO - 2023-11-09 01:57:30 --> Controller Class Initialized
INFO - 2023-11-09 01:57:30 --> Model "M_pelanggan" initialized
INFO - 2023-11-09 01:57:30 --> Model "M_produk" initialized
DEBUG - 2023-11-09 01:57:30 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-09 01:57:30 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-09 01:57:30 --> Model "M_transaksi" initialized
INFO - 2023-11-09 01:57:30 --> Model "M_bank" initialized
INFO - 2023-11-09 01:57:30 --> Model "M_pesan" initialized
DEBUG - 2023-11-09 01:57:30 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-09 01:57:30 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-09 01:57:30 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-09 01:57:30 --> Final output sent to browser
DEBUG - 2023-11-09 01:57:30 --> Total execution time: 0.0374
ERROR - 2023-11-09 04:10:24 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-09 04:10:24 --> Config Class Initialized
INFO - 2023-11-09 04:10:24 --> Hooks Class Initialized
DEBUG - 2023-11-09 04:10:24 --> UTF-8 Support Enabled
INFO - 2023-11-09 04:10:24 --> Utf8 Class Initialized
INFO - 2023-11-09 04:10:24 --> URI Class Initialized
INFO - 2023-11-09 04:10:24 --> Router Class Initialized
INFO - 2023-11-09 04:10:24 --> Output Class Initialized
INFO - 2023-11-09 04:10:24 --> Security Class Initialized
DEBUG - 2023-11-09 04:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 04:10:24 --> Input Class Initialized
INFO - 2023-11-09 04:10:24 --> Language Class Initialized
INFO - 2023-11-09 04:10:24 --> Loader Class Initialized
INFO - 2023-11-09 04:10:24 --> Helper loaded: url_helper
INFO - 2023-11-09 04:10:24 --> Helper loaded: form_helper
INFO - 2023-11-09 04:10:24 --> Helper loaded: file_helper
INFO - 2023-11-09 04:10:24 --> Database Driver Class Initialized
DEBUG - 2023-11-09 04:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 04:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 04:10:24 --> Form Validation Class Initialized
INFO - 2023-11-09 04:10:24 --> Upload Class Initialized
INFO - 2023-11-09 04:10:24 --> Model "M_auth" initialized
INFO - 2023-11-09 04:10:24 --> Model "M_user" initialized
INFO - 2023-11-09 04:10:24 --> Model "M_produk" initialized
INFO - 2023-11-09 04:10:24 --> Controller Class Initialized
INFO - 2023-11-09 04:10:24 --> Model "M_pelanggan" initialized
INFO - 2023-11-09 04:10:24 --> Model "M_produk" initialized
DEBUG - 2023-11-09 04:10:24 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-09 04:10:24 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-09 04:10:24 --> Model "M_transaksi" initialized
INFO - 2023-11-09 04:10:24 --> Model "M_bank" initialized
INFO - 2023-11-09 04:10:24 --> Model "M_pesan" initialized
DEBUG - 2023-11-09 04:10:24 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-09 04:10:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-09 04:10:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-09 04:10:24 --> Final output sent to browser
DEBUG - 2023-11-09 04:10:24 --> Total execution time: 0.0471
ERROR - 2023-11-09 04:28:08 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-09 04:28:08 --> Config Class Initialized
INFO - 2023-11-09 04:28:08 --> Hooks Class Initialized
DEBUG - 2023-11-09 04:28:08 --> UTF-8 Support Enabled
INFO - 2023-11-09 04:28:08 --> Utf8 Class Initialized
INFO - 2023-11-09 04:28:08 --> URI Class Initialized
DEBUG - 2023-11-09 04:28:08 --> No URI present. Default controller set.
INFO - 2023-11-09 04:28:08 --> Router Class Initialized
INFO - 2023-11-09 04:28:08 --> Output Class Initialized
INFO - 2023-11-09 04:28:08 --> Security Class Initialized
DEBUG - 2023-11-09 04:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 04:28:08 --> Input Class Initialized
INFO - 2023-11-09 04:28:08 --> Language Class Initialized
INFO - 2023-11-09 04:28:08 --> Loader Class Initialized
INFO - 2023-11-09 04:28:08 --> Helper loaded: url_helper
INFO - 2023-11-09 04:28:08 --> Helper loaded: form_helper
INFO - 2023-11-09 04:28:08 --> Helper loaded: file_helper
INFO - 2023-11-09 04:28:08 --> Database Driver Class Initialized
DEBUG - 2023-11-09 04:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 04:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 04:28:08 --> Form Validation Class Initialized
INFO - 2023-11-09 04:28:08 --> Upload Class Initialized
INFO - 2023-11-09 04:28:08 --> Model "M_auth" initialized
INFO - 2023-11-09 04:28:08 --> Model "M_user" initialized
INFO - 2023-11-09 04:28:08 --> Model "M_produk" initialized
INFO - 2023-11-09 04:28:08 --> Controller Class Initialized
INFO - 2023-11-09 04:28:08 --> Model "M_pelanggan" initialized
INFO - 2023-11-09 04:28:08 --> Model "M_produk" initialized
DEBUG - 2023-11-09 04:28:08 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-09 04:28:08 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-09 04:28:08 --> Model "M_transaksi" initialized
INFO - 2023-11-09 04:28:08 --> Model "M_bank" initialized
INFO - 2023-11-09 04:28:08 --> Model "M_pesan" initialized
DEBUG - 2023-11-09 04:28:08 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-09 04:28:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-09 04:28:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-09 04:28:08 --> Final output sent to browser
DEBUG - 2023-11-09 04:28:08 --> Total execution time: 0.0379
ERROR - 2023-11-09 05:54:00 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-09 05:54:00 --> Config Class Initialized
INFO - 2023-11-09 05:54:00 --> Hooks Class Initialized
DEBUG - 2023-11-09 05:54:00 --> UTF-8 Support Enabled
INFO - 2023-11-09 05:54:00 --> Utf8 Class Initialized
INFO - 2023-11-09 05:54:00 --> URI Class Initialized
INFO - 2023-11-09 05:54:00 --> Router Class Initialized
INFO - 2023-11-09 05:54:00 --> Output Class Initialized
INFO - 2023-11-09 05:54:00 --> Security Class Initialized
DEBUG - 2023-11-09 05:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 05:54:00 --> Input Class Initialized
INFO - 2023-11-09 05:54:00 --> Language Class Initialized
INFO - 2023-11-09 05:54:00 --> Loader Class Initialized
INFO - 2023-11-09 05:54:00 --> Helper loaded: url_helper
INFO - 2023-11-09 05:54:00 --> Helper loaded: form_helper
INFO - 2023-11-09 05:54:00 --> Helper loaded: file_helper
INFO - 2023-11-09 05:54:00 --> Database Driver Class Initialized
DEBUG - 2023-11-09 05:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 05:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 05:54:00 --> Form Validation Class Initialized
INFO - 2023-11-09 05:54:00 --> Upload Class Initialized
INFO - 2023-11-09 05:54:00 --> Model "M_auth" initialized
INFO - 2023-11-09 05:54:00 --> Model "M_user" initialized
INFO - 2023-11-09 05:54:00 --> Model "M_produk" initialized
INFO - 2023-11-09 05:54:00 --> Controller Class Initialized
INFO - 2023-11-09 05:54:00 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-09 05:54:00 --> Final output sent to browser
DEBUG - 2023-11-09 05:54:00 --> Total execution time: 0.0288
ERROR - 2023-11-09 05:54:08 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-09 05:54:08 --> Config Class Initialized
INFO - 2023-11-09 05:54:08 --> Hooks Class Initialized
DEBUG - 2023-11-09 05:54:08 --> UTF-8 Support Enabled
INFO - 2023-11-09 05:54:08 --> Utf8 Class Initialized
INFO - 2023-11-09 05:54:08 --> URI Class Initialized
INFO - 2023-11-09 05:54:08 --> Router Class Initialized
INFO - 2023-11-09 05:54:08 --> Output Class Initialized
INFO - 2023-11-09 05:54:08 --> Security Class Initialized
DEBUG - 2023-11-09 05:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 05:54:08 --> Input Class Initialized
INFO - 2023-11-09 05:54:08 --> Language Class Initialized
INFO - 2023-11-09 05:54:08 --> Loader Class Initialized
INFO - 2023-11-09 05:54:08 --> Helper loaded: url_helper
INFO - 2023-11-09 05:54:08 --> Helper loaded: form_helper
INFO - 2023-11-09 05:54:08 --> Helper loaded: file_helper
INFO - 2023-11-09 05:54:08 --> Database Driver Class Initialized
DEBUG - 2023-11-09 05:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 05:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 05:54:08 --> Form Validation Class Initialized
INFO - 2023-11-09 05:54:08 --> Upload Class Initialized
INFO - 2023-11-09 05:54:08 --> Model "M_auth" initialized
INFO - 2023-11-09 05:54:08 --> Model "M_user" initialized
INFO - 2023-11-09 05:54:08 --> Model "M_produk" initialized
INFO - 2023-11-09 05:54:08 --> Controller Class Initialized
INFO - 2023-11-09 05:54:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-09 05:54:08 --> Final output sent to browser
DEBUG - 2023-11-09 05:54:08 --> Total execution time: 0.0025
ERROR - 2023-11-09 06:55:49 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-09 06:55:49 --> Config Class Initialized
INFO - 2023-11-09 06:55:49 --> Hooks Class Initialized
DEBUG - 2023-11-09 06:55:49 --> UTF-8 Support Enabled
INFO - 2023-11-09 06:55:49 --> Utf8 Class Initialized
INFO - 2023-11-09 06:55:49 --> URI Class Initialized
INFO - 2023-11-09 06:55:49 --> Router Class Initialized
INFO - 2023-11-09 06:55:49 --> Output Class Initialized
INFO - 2023-11-09 06:55:49 --> Security Class Initialized
DEBUG - 2023-11-09 06:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 06:55:49 --> Input Class Initialized
INFO - 2023-11-09 06:55:49 --> Language Class Initialized
INFO - 2023-11-09 06:55:49 --> Loader Class Initialized
INFO - 2023-11-09 06:55:49 --> Helper loaded: url_helper
INFO - 2023-11-09 06:55:49 --> Helper loaded: form_helper
INFO - 2023-11-09 06:55:49 --> Helper loaded: file_helper
INFO - 2023-11-09 06:55:49 --> Database Driver Class Initialized
DEBUG - 2023-11-09 06:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 06:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 06:55:49 --> Form Validation Class Initialized
INFO - 2023-11-09 06:55:49 --> Upload Class Initialized
INFO - 2023-11-09 06:55:49 --> Model "M_auth" initialized
INFO - 2023-11-09 06:55:49 --> Model "M_user" initialized
INFO - 2023-11-09 06:55:49 --> Model "M_produk" initialized
INFO - 2023-11-09 06:55:49 --> Controller Class Initialized
INFO - 2023-11-09 06:55:49 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-09 06:55:49 --> Final output sent to browser
DEBUG - 2023-11-09 06:55:49 --> Total execution time: 0.0376
ERROR - 2023-11-09 07:24:17 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-09 07:24:17 --> Config Class Initialized
INFO - 2023-11-09 07:24:17 --> Hooks Class Initialized
DEBUG - 2023-11-09 07:24:17 --> UTF-8 Support Enabled
INFO - 2023-11-09 07:24:17 --> Utf8 Class Initialized
INFO - 2023-11-09 07:24:17 --> URI Class Initialized
DEBUG - 2023-11-09 07:24:17 --> No URI present. Default controller set.
INFO - 2023-11-09 07:24:17 --> Router Class Initialized
INFO - 2023-11-09 07:24:17 --> Output Class Initialized
INFO - 2023-11-09 07:24:17 --> Security Class Initialized
DEBUG - 2023-11-09 07:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 07:24:17 --> Input Class Initialized
INFO - 2023-11-09 07:24:17 --> Language Class Initialized
INFO - 2023-11-09 07:24:17 --> Loader Class Initialized
INFO - 2023-11-09 07:24:17 --> Helper loaded: url_helper
INFO - 2023-11-09 07:24:17 --> Helper loaded: form_helper
INFO - 2023-11-09 07:24:17 --> Helper loaded: file_helper
INFO - 2023-11-09 07:24:17 --> Database Driver Class Initialized
DEBUG - 2023-11-09 07:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 07:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 07:24:17 --> Form Validation Class Initialized
INFO - 2023-11-09 07:24:17 --> Upload Class Initialized
INFO - 2023-11-09 07:24:17 --> Model "M_auth" initialized
INFO - 2023-11-09 07:24:17 --> Model "M_user" initialized
INFO - 2023-11-09 07:24:17 --> Model "M_produk" initialized
INFO - 2023-11-09 07:24:17 --> Controller Class Initialized
INFO - 2023-11-09 07:24:17 --> Model "M_pelanggan" initialized
INFO - 2023-11-09 07:24:17 --> Model "M_produk" initialized
DEBUG - 2023-11-09 07:24:17 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-09 07:24:17 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-09 07:24:17 --> Model "M_transaksi" initialized
INFO - 2023-11-09 07:24:17 --> Model "M_bank" initialized
INFO - 2023-11-09 07:24:17 --> Model "M_pesan" initialized
DEBUG - 2023-11-09 07:24:17 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-09 07:24:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-09 07:24:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-09 07:24:17 --> Final output sent to browser
DEBUG - 2023-11-09 07:24:17 --> Total execution time: 0.0406
ERROR - 2023-11-09 08:37:39 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-09 08:37:39 --> Config Class Initialized
INFO - 2023-11-09 08:37:39 --> Hooks Class Initialized
DEBUG - 2023-11-09 08:37:39 --> UTF-8 Support Enabled
INFO - 2023-11-09 08:37:39 --> Utf8 Class Initialized
INFO - 2023-11-09 08:37:39 --> URI Class Initialized
INFO - 2023-11-09 08:37:39 --> Router Class Initialized
INFO - 2023-11-09 08:37:39 --> Output Class Initialized
INFO - 2023-11-09 08:37:39 --> Security Class Initialized
DEBUG - 2023-11-09 08:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 08:37:39 --> Input Class Initialized
INFO - 2023-11-09 08:37:39 --> Language Class Initialized
INFO - 2023-11-09 08:37:39 --> Loader Class Initialized
INFO - 2023-11-09 08:37:39 --> Helper loaded: url_helper
INFO - 2023-11-09 08:37:39 --> Helper loaded: form_helper
INFO - 2023-11-09 08:37:39 --> Helper loaded: file_helper
INFO - 2023-11-09 08:37:39 --> Database Driver Class Initialized
DEBUG - 2023-11-09 08:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 08:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 08:37:39 --> Form Validation Class Initialized
INFO - 2023-11-09 08:37:39 --> Upload Class Initialized
INFO - 2023-11-09 08:37:39 --> Model "M_auth" initialized
INFO - 2023-11-09 08:37:39 --> Model "M_user" initialized
INFO - 2023-11-09 08:37:39 --> Model "M_produk" initialized
INFO - 2023-11-09 08:37:39 --> Controller Class Initialized
INFO - 2023-11-09 08:37:39 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-09 08:37:39 --> Final output sent to browser
DEBUG - 2023-11-09 08:37:39 --> Total execution time: 0.0256
ERROR - 2023-11-09 11:53:34 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-09 11:53:34 --> Config Class Initialized
INFO - 2023-11-09 11:53:34 --> Hooks Class Initialized
DEBUG - 2023-11-09 11:53:34 --> UTF-8 Support Enabled
INFO - 2023-11-09 11:53:34 --> Utf8 Class Initialized
INFO - 2023-11-09 11:53:34 --> URI Class Initialized
INFO - 2023-11-09 11:53:34 --> Router Class Initialized
INFO - 2023-11-09 11:53:34 --> Output Class Initialized
INFO - 2023-11-09 11:53:34 --> Security Class Initialized
DEBUG - 2023-11-09 11:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 11:53:34 --> Input Class Initialized
INFO - 2023-11-09 11:53:34 --> Language Class Initialized
INFO - 2023-11-09 11:53:34 --> Loader Class Initialized
INFO - 2023-11-09 11:53:34 --> Helper loaded: url_helper
INFO - 2023-11-09 11:53:34 --> Helper loaded: form_helper
INFO - 2023-11-09 11:53:34 --> Helper loaded: file_helper
INFO - 2023-11-09 11:53:34 --> Database Driver Class Initialized
DEBUG - 2023-11-09 11:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 11:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 11:53:34 --> Form Validation Class Initialized
INFO - 2023-11-09 11:53:34 --> Upload Class Initialized
INFO - 2023-11-09 11:53:34 --> Model "M_auth" initialized
INFO - 2023-11-09 11:53:34 --> Model "M_user" initialized
INFO - 2023-11-09 11:53:34 --> Model "M_produk" initialized
INFO - 2023-11-09 11:53:34 --> Controller Class Initialized
INFO - 2023-11-09 11:53:34 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-09 11:53:34 --> Final output sent to browser
DEBUG - 2023-11-09 11:53:34 --> Total execution time: 0.0324
ERROR - 2023-11-09 13:06:43 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-09 13:06:43 --> Config Class Initialized
INFO - 2023-11-09 13:06:43 --> Hooks Class Initialized
DEBUG - 2023-11-09 13:06:43 --> UTF-8 Support Enabled
INFO - 2023-11-09 13:06:43 --> Utf8 Class Initialized
INFO - 2023-11-09 13:06:43 --> URI Class Initialized
INFO - 2023-11-09 13:06:43 --> Router Class Initialized
INFO - 2023-11-09 13:06:43 --> Output Class Initialized
INFO - 2023-11-09 13:06:43 --> Security Class Initialized
DEBUG - 2023-11-09 13:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 13:06:43 --> Input Class Initialized
INFO - 2023-11-09 13:06:43 --> Language Class Initialized
INFO - 2023-11-09 13:06:43 --> Loader Class Initialized
INFO - 2023-11-09 13:06:43 --> Helper loaded: url_helper
INFO - 2023-11-09 13:06:43 --> Helper loaded: form_helper
INFO - 2023-11-09 13:06:43 --> Helper loaded: file_helper
INFO - 2023-11-09 13:06:43 --> Database Driver Class Initialized
DEBUG - 2023-11-09 13:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 13:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 13:06:43 --> Form Validation Class Initialized
INFO - 2023-11-09 13:06:43 --> Upload Class Initialized
INFO - 2023-11-09 13:06:43 --> Model "M_auth" initialized
INFO - 2023-11-09 13:06:43 --> Model "M_user" initialized
INFO - 2023-11-09 13:06:43 --> Model "M_produk" initialized
INFO - 2023-11-09 13:06:43 --> Controller Class Initialized
INFO - 2023-11-09 13:06:43 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-09 13:06:43 --> Final output sent to browser
DEBUG - 2023-11-09 13:06:43 --> Total execution time: 0.0323
ERROR - 2023-11-09 14:47:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-09 14:47:45 --> Config Class Initialized
INFO - 2023-11-09 14:47:45 --> Hooks Class Initialized
DEBUG - 2023-11-09 14:47:45 --> UTF-8 Support Enabled
INFO - 2023-11-09 14:47:45 --> Utf8 Class Initialized
INFO - 2023-11-09 14:47:45 --> URI Class Initialized
DEBUG - 2023-11-09 14:47:45 --> No URI present. Default controller set.
INFO - 2023-11-09 14:47:45 --> Router Class Initialized
INFO - 2023-11-09 14:47:45 --> Output Class Initialized
INFO - 2023-11-09 14:47:45 --> Security Class Initialized
DEBUG - 2023-11-09 14:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 14:47:45 --> Input Class Initialized
INFO - 2023-11-09 14:47:45 --> Language Class Initialized
INFO - 2023-11-09 14:47:45 --> Loader Class Initialized
INFO - 2023-11-09 14:47:45 --> Helper loaded: url_helper
INFO - 2023-11-09 14:47:45 --> Helper loaded: form_helper
INFO - 2023-11-09 14:47:45 --> Helper loaded: file_helper
INFO - 2023-11-09 14:47:45 --> Database Driver Class Initialized
DEBUG - 2023-11-09 14:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 14:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 14:47:45 --> Form Validation Class Initialized
INFO - 2023-11-09 14:47:45 --> Upload Class Initialized
INFO - 2023-11-09 14:47:45 --> Model "M_auth" initialized
INFO - 2023-11-09 14:47:45 --> Model "M_user" initialized
INFO - 2023-11-09 14:47:45 --> Model "M_produk" initialized
INFO - 2023-11-09 14:47:45 --> Controller Class Initialized
INFO - 2023-11-09 14:47:45 --> Model "M_pelanggan" initialized
INFO - 2023-11-09 14:47:45 --> Model "M_produk" initialized
DEBUG - 2023-11-09 14:47:45 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-09 14:47:45 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-09 14:47:45 --> Model "M_transaksi" initialized
INFO - 2023-11-09 14:47:45 --> Model "M_bank" initialized
INFO - 2023-11-09 14:47:45 --> Model "M_pesan" initialized
DEBUG - 2023-11-09 14:47:45 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-09 14:47:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-09 14:47:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-09 14:47:45 --> Final output sent to browser
DEBUG - 2023-11-09 14:47:45 --> Total execution time: 0.0390
ERROR - 2023-11-09 16:39:50 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-09 16:39:50 --> Config Class Initialized
INFO - 2023-11-09 16:39:50 --> Hooks Class Initialized
DEBUG - 2023-11-09 16:39:50 --> UTF-8 Support Enabled
INFO - 2023-11-09 16:39:50 --> Utf8 Class Initialized
INFO - 2023-11-09 16:39:50 --> URI Class Initialized
DEBUG - 2023-11-09 16:39:50 --> No URI present. Default controller set.
INFO - 2023-11-09 16:39:50 --> Router Class Initialized
INFO - 2023-11-09 16:39:50 --> Output Class Initialized
INFO - 2023-11-09 16:39:50 --> Security Class Initialized
DEBUG - 2023-11-09 16:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 16:39:50 --> Input Class Initialized
INFO - 2023-11-09 16:39:50 --> Language Class Initialized
INFO - 2023-11-09 16:39:50 --> Loader Class Initialized
INFO - 2023-11-09 16:39:50 --> Helper loaded: url_helper
INFO - 2023-11-09 16:39:50 --> Helper loaded: form_helper
INFO - 2023-11-09 16:39:50 --> Helper loaded: file_helper
INFO - 2023-11-09 16:39:50 --> Database Driver Class Initialized
DEBUG - 2023-11-09 16:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 16:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 16:39:50 --> Form Validation Class Initialized
INFO - 2023-11-09 16:39:50 --> Upload Class Initialized
INFO - 2023-11-09 16:39:50 --> Model "M_auth" initialized
INFO - 2023-11-09 16:39:50 --> Model "M_user" initialized
INFO - 2023-11-09 16:39:50 --> Model "M_produk" initialized
INFO - 2023-11-09 16:39:50 --> Controller Class Initialized
INFO - 2023-11-09 16:39:50 --> Model "M_pelanggan" initialized
INFO - 2023-11-09 16:39:50 --> Model "M_produk" initialized
DEBUG - 2023-11-09 16:39:50 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-09 16:39:50 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-09 16:39:50 --> Model "M_transaksi" initialized
INFO - 2023-11-09 16:39:50 --> Model "M_bank" initialized
INFO - 2023-11-09 16:39:50 --> Model "M_pesan" initialized
DEBUG - 2023-11-09 16:39:50 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-09 16:39:50 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-09 16:39:50 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-09 16:39:50 --> Final output sent to browser
DEBUG - 2023-11-09 16:39:50 --> Total execution time: 0.0456
ERROR - 2023-11-09 17:27:36 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-09 17:27:36 --> Config Class Initialized
INFO - 2023-11-09 17:27:36 --> Hooks Class Initialized
DEBUG - 2023-11-09 17:27:36 --> UTF-8 Support Enabled
INFO - 2023-11-09 17:27:36 --> Utf8 Class Initialized
INFO - 2023-11-09 17:27:36 --> URI Class Initialized
INFO - 2023-11-09 17:27:36 --> Router Class Initialized
INFO - 2023-11-09 17:27:36 --> Output Class Initialized
INFO - 2023-11-09 17:27:36 --> Security Class Initialized
DEBUG - 2023-11-09 17:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 17:27:36 --> Input Class Initialized
INFO - 2023-11-09 17:27:36 --> Language Class Initialized
INFO - 2023-11-09 17:27:36 --> Loader Class Initialized
INFO - 2023-11-09 17:27:36 --> Helper loaded: url_helper
INFO - 2023-11-09 17:27:36 --> Helper loaded: form_helper
INFO - 2023-11-09 17:27:36 --> Helper loaded: file_helper
INFO - 2023-11-09 17:27:36 --> Database Driver Class Initialized
DEBUG - 2023-11-09 17:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 17:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 17:27:36 --> Form Validation Class Initialized
INFO - 2023-11-09 17:27:36 --> Upload Class Initialized
INFO - 2023-11-09 17:27:36 --> Model "M_auth" initialized
INFO - 2023-11-09 17:27:36 --> Model "M_user" initialized
INFO - 2023-11-09 17:27:36 --> Model "M_produk" initialized
INFO - 2023-11-09 17:27:36 --> Controller Class Initialized
INFO - 2023-11-09 17:27:36 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-09 17:27:36 --> Final output sent to browser
DEBUG - 2023-11-09 17:27:36 --> Total execution time: 0.0378
ERROR - 2023-11-09 17:27:38 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-09 17:27:38 --> Config Class Initialized
INFO - 2023-11-09 17:27:38 --> Hooks Class Initialized
DEBUG - 2023-11-09 17:27:38 --> UTF-8 Support Enabled
INFO - 2023-11-09 17:27:38 --> Utf8 Class Initialized
INFO - 2023-11-09 17:27:38 --> URI Class Initialized
DEBUG - 2023-11-09 17:27:38 --> No URI present. Default controller set.
INFO - 2023-11-09 17:27:38 --> Router Class Initialized
INFO - 2023-11-09 17:27:38 --> Output Class Initialized
INFO - 2023-11-09 17:27:38 --> Security Class Initialized
DEBUG - 2023-11-09 17:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 17:27:38 --> Input Class Initialized
INFO - 2023-11-09 17:27:38 --> Language Class Initialized
INFO - 2023-11-09 17:27:38 --> Loader Class Initialized
INFO - 2023-11-09 17:27:38 --> Helper loaded: url_helper
INFO - 2023-11-09 17:27:38 --> Helper loaded: form_helper
INFO - 2023-11-09 17:27:38 --> Helper loaded: file_helper
INFO - 2023-11-09 17:27:38 --> Database Driver Class Initialized
DEBUG - 2023-11-09 17:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 17:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 17:27:38 --> Form Validation Class Initialized
INFO - 2023-11-09 17:27:38 --> Upload Class Initialized
INFO - 2023-11-09 17:27:38 --> Model "M_auth" initialized
INFO - 2023-11-09 17:27:38 --> Model "M_user" initialized
INFO - 2023-11-09 17:27:38 --> Model "M_produk" initialized
INFO - 2023-11-09 17:27:38 --> Controller Class Initialized
INFO - 2023-11-09 17:27:38 --> Model "M_pelanggan" initialized
INFO - 2023-11-09 17:27:38 --> Model "M_produk" initialized
DEBUG - 2023-11-09 17:27:38 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-09 17:27:38 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-09 17:27:38 --> Model "M_transaksi" initialized
INFO - 2023-11-09 17:27:38 --> Model "M_bank" initialized
INFO - 2023-11-09 17:27:38 --> Model "M_pesan" initialized
DEBUG - 2023-11-09 17:27:38 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-09 17:27:38 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-09 17:27:38 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-09 17:27:38 --> Final output sent to browser
DEBUG - 2023-11-09 17:27:38 --> Total execution time: 0.0142
ERROR - 2023-11-09 20:18:02 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-09 20:18:02 --> Config Class Initialized
INFO - 2023-11-09 20:18:02 --> Hooks Class Initialized
DEBUG - 2023-11-09 20:18:02 --> UTF-8 Support Enabled
INFO - 2023-11-09 20:18:02 --> Utf8 Class Initialized
INFO - 2023-11-09 20:18:02 --> URI Class Initialized
INFO - 2023-11-09 20:18:02 --> Router Class Initialized
INFO - 2023-11-09 20:18:02 --> Output Class Initialized
INFO - 2023-11-09 20:18:02 --> Security Class Initialized
DEBUG - 2023-11-09 20:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 20:18:02 --> Input Class Initialized
INFO - 2023-11-09 20:18:02 --> Language Class Initialized
INFO - 2023-11-09 20:18:02 --> Loader Class Initialized
INFO - 2023-11-09 20:18:02 --> Helper loaded: url_helper
INFO - 2023-11-09 20:18:02 --> Helper loaded: form_helper
INFO - 2023-11-09 20:18:02 --> Helper loaded: file_helper
INFO - 2023-11-09 20:18:02 --> Database Driver Class Initialized
DEBUG - 2023-11-09 20:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 20:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 20:18:02 --> Form Validation Class Initialized
INFO - 2023-11-09 20:18:02 --> Upload Class Initialized
INFO - 2023-11-09 20:18:02 --> Model "M_auth" initialized
INFO - 2023-11-09 20:18:02 --> Model "M_user" initialized
INFO - 2023-11-09 20:18:02 --> Model "M_produk" initialized
INFO - 2023-11-09 20:18:02 --> Controller Class Initialized
INFO - 2023-11-09 20:18:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-09 20:18:02 --> Final output sent to browser
DEBUG - 2023-11-09 20:18:02 --> Total execution time: 0.0386
ERROR - 2023-11-09 20:18:04 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-09 20:18:04 --> Config Class Initialized
INFO - 2023-11-09 20:18:04 --> Hooks Class Initialized
DEBUG - 2023-11-09 20:18:04 --> UTF-8 Support Enabled
INFO - 2023-11-09 20:18:04 --> Utf8 Class Initialized
INFO - 2023-11-09 20:18:04 --> URI Class Initialized
DEBUG - 2023-11-09 20:18:04 --> No URI present. Default controller set.
INFO - 2023-11-09 20:18:04 --> Router Class Initialized
INFO - 2023-11-09 20:18:04 --> Output Class Initialized
INFO - 2023-11-09 20:18:04 --> Security Class Initialized
DEBUG - 2023-11-09 20:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 20:18:04 --> Input Class Initialized
INFO - 2023-11-09 20:18:04 --> Language Class Initialized
INFO - 2023-11-09 20:18:04 --> Loader Class Initialized
INFO - 2023-11-09 20:18:04 --> Helper loaded: url_helper
INFO - 2023-11-09 20:18:04 --> Helper loaded: form_helper
INFO - 2023-11-09 20:18:04 --> Helper loaded: file_helper
INFO - 2023-11-09 20:18:04 --> Database Driver Class Initialized
DEBUG - 2023-11-09 20:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 20:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 20:18:04 --> Form Validation Class Initialized
INFO - 2023-11-09 20:18:04 --> Upload Class Initialized
INFO - 2023-11-09 20:18:04 --> Model "M_auth" initialized
INFO - 2023-11-09 20:18:04 --> Model "M_user" initialized
INFO - 2023-11-09 20:18:04 --> Model "M_produk" initialized
INFO - 2023-11-09 20:18:04 --> Controller Class Initialized
INFO - 2023-11-09 20:18:04 --> Model "M_pelanggan" initialized
INFO - 2023-11-09 20:18:04 --> Model "M_produk" initialized
DEBUG - 2023-11-09 20:18:04 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-09 20:18:04 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-09 20:18:04 --> Model "M_transaksi" initialized
INFO - 2023-11-09 20:18:04 --> Model "M_bank" initialized
INFO - 2023-11-09 20:18:04 --> Model "M_pesan" initialized
DEBUG - 2023-11-09 20:18:04 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-09 20:18:04 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-09 20:18:04 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-09 20:18:04 --> Final output sent to browser
DEBUG - 2023-11-09 20:18:04 --> Total execution time: 0.0146
ERROR - 2023-11-09 20:54:27 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-09 20:54:27 --> Config Class Initialized
INFO - 2023-11-09 20:54:27 --> Hooks Class Initialized
DEBUG - 2023-11-09 20:54:27 --> UTF-8 Support Enabled
INFO - 2023-11-09 20:54:27 --> Utf8 Class Initialized
INFO - 2023-11-09 20:54:27 --> URI Class Initialized
DEBUG - 2023-11-09 20:54:27 --> No URI present. Default controller set.
INFO - 2023-11-09 20:54:27 --> Router Class Initialized
INFO - 2023-11-09 20:54:27 --> Output Class Initialized
INFO - 2023-11-09 20:54:27 --> Security Class Initialized
DEBUG - 2023-11-09 20:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-09 20:54:27 --> Input Class Initialized
INFO - 2023-11-09 20:54:27 --> Language Class Initialized
INFO - 2023-11-09 20:54:27 --> Loader Class Initialized
INFO - 2023-11-09 20:54:27 --> Helper loaded: url_helper
INFO - 2023-11-09 20:54:27 --> Helper loaded: form_helper
INFO - 2023-11-09 20:54:27 --> Helper loaded: file_helper
INFO - 2023-11-09 20:54:27 --> Database Driver Class Initialized
DEBUG - 2023-11-09 20:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-09 20:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-09 20:54:28 --> Form Validation Class Initialized
INFO - 2023-11-09 20:54:28 --> Upload Class Initialized
INFO - 2023-11-09 20:54:28 --> Model "M_auth" initialized
INFO - 2023-11-09 20:54:28 --> Model "M_user" initialized
INFO - 2023-11-09 20:54:28 --> Model "M_produk" initialized
INFO - 2023-11-09 20:54:28 --> Controller Class Initialized
INFO - 2023-11-09 20:54:28 --> Model "M_pelanggan" initialized
INFO - 2023-11-09 20:54:28 --> Model "M_produk" initialized
DEBUG - 2023-11-09 20:54:28 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-09 20:54:28 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-09 20:54:28 --> Model "M_transaksi" initialized
INFO - 2023-11-09 20:54:28 --> Model "M_bank" initialized
INFO - 2023-11-09 20:54:28 --> Model "M_pesan" initialized
DEBUG - 2023-11-09 20:54:28 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-09 20:54:28 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-09 20:54:28 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-09 20:54:28 --> Final output sent to browser
DEBUG - 2023-11-09 20:54:28 --> Total execution time: 0.0461
