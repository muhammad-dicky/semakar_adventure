<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-07 00:02:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-07 00:02:45 --> Config Class Initialized
INFO - 2023-11-07 00:02:45 --> Hooks Class Initialized
DEBUG - 2023-11-07 00:02:45 --> UTF-8 Support Enabled
INFO - 2023-11-07 00:02:45 --> Utf8 Class Initialized
INFO - 2023-11-07 00:02:45 --> URI Class Initialized
DEBUG - 2023-11-07 00:02:45 --> No URI present. Default controller set.
INFO - 2023-11-07 00:02:45 --> Router Class Initialized
INFO - 2023-11-07 00:02:45 --> Output Class Initialized
INFO - 2023-11-07 00:02:45 --> Security Class Initialized
DEBUG - 2023-11-07 00:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 00:02:45 --> Input Class Initialized
INFO - 2023-11-07 00:02:45 --> Language Class Initialized
INFO - 2023-11-07 00:02:46 --> Loader Class Initialized
INFO - 2023-11-07 00:02:46 --> Helper loaded: url_helper
INFO - 2023-11-07 00:02:46 --> Helper loaded: form_helper
INFO - 2023-11-07 00:02:46 --> Helper loaded: file_helper
INFO - 2023-11-07 00:02:46 --> Database Driver Class Initialized
DEBUG - 2023-11-07 00:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-07 00:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 00:02:46 --> Form Validation Class Initialized
INFO - 2023-11-07 00:02:46 --> Upload Class Initialized
INFO - 2023-11-07 00:02:46 --> Model "M_auth" initialized
INFO - 2023-11-07 00:02:46 --> Model "M_user" initialized
INFO - 2023-11-07 00:02:46 --> Model "M_produk" initialized
INFO - 2023-11-07 00:02:46 --> Controller Class Initialized
INFO - 2023-11-07 00:02:46 --> Model "M_pelanggan" initialized
INFO - 2023-11-07 00:02:46 --> Model "M_produk" initialized
DEBUG - 2023-11-07 00:02:46 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-07 00:02:46 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-07 00:02:46 --> Model "M_transaksi" initialized
INFO - 2023-11-07 00:02:46 --> Model "M_bank" initialized
INFO - 2023-11-07 00:02:46 --> Model "M_pesan" initialized
DEBUG - 2023-11-07 00:02:46 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-07 00:02:46 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-07 00:02:46 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-07 00:02:46 --> Final output sent to browser
DEBUG - 2023-11-07 00:02:46 --> Total execution time: 0.0489
ERROR - 2023-11-07 02:50:39 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-07 02:50:39 --> Config Class Initialized
INFO - 2023-11-07 02:50:39 --> Hooks Class Initialized
DEBUG - 2023-11-07 02:50:39 --> UTF-8 Support Enabled
INFO - 2023-11-07 02:50:39 --> Utf8 Class Initialized
INFO - 2023-11-07 02:50:39 --> URI Class Initialized
INFO - 2023-11-07 02:50:39 --> Router Class Initialized
INFO - 2023-11-07 02:50:39 --> Output Class Initialized
INFO - 2023-11-07 02:50:39 --> Security Class Initialized
DEBUG - 2023-11-07 02:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 02:50:39 --> Input Class Initialized
INFO - 2023-11-07 02:50:39 --> Language Class Initialized
INFO - 2023-11-07 02:50:39 --> Loader Class Initialized
INFO - 2023-11-07 02:50:39 --> Helper loaded: url_helper
INFO - 2023-11-07 02:50:39 --> Helper loaded: form_helper
INFO - 2023-11-07 02:50:39 --> Helper loaded: file_helper
INFO - 2023-11-07 02:50:39 --> Database Driver Class Initialized
DEBUG - 2023-11-07 02:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-07 02:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 02:50:39 --> Form Validation Class Initialized
INFO - 2023-11-07 02:50:39 --> Upload Class Initialized
INFO - 2023-11-07 02:50:39 --> Model "M_auth" initialized
INFO - 2023-11-07 02:50:39 --> Model "M_user" initialized
INFO - 2023-11-07 02:50:39 --> Model "M_produk" initialized
INFO - 2023-11-07 02:50:39 --> Controller Class Initialized
INFO - 2023-11-07 02:50:39 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-07 02:50:39 --> Final output sent to browser
DEBUG - 2023-11-07 02:50:39 --> Total execution time: 0.0330
ERROR - 2023-11-07 02:50:44 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-07 02:50:44 --> Config Class Initialized
INFO - 2023-11-07 02:50:44 --> Hooks Class Initialized
DEBUG - 2023-11-07 02:50:44 --> UTF-8 Support Enabled
INFO - 2023-11-07 02:50:44 --> Utf8 Class Initialized
INFO - 2023-11-07 02:50:44 --> URI Class Initialized
INFO - 2023-11-07 02:50:44 --> Router Class Initialized
INFO - 2023-11-07 02:50:44 --> Output Class Initialized
INFO - 2023-11-07 02:50:44 --> Security Class Initialized
DEBUG - 2023-11-07 02:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 02:50:44 --> Input Class Initialized
INFO - 2023-11-07 02:50:44 --> Language Class Initialized
INFO - 2023-11-07 02:50:44 --> Loader Class Initialized
INFO - 2023-11-07 02:50:44 --> Helper loaded: url_helper
INFO - 2023-11-07 02:50:44 --> Helper loaded: form_helper
INFO - 2023-11-07 02:50:44 --> Helper loaded: file_helper
INFO - 2023-11-07 02:50:44 --> Database Driver Class Initialized
DEBUG - 2023-11-07 02:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-07 02:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 02:50:44 --> Form Validation Class Initialized
INFO - 2023-11-07 02:50:44 --> Upload Class Initialized
INFO - 2023-11-07 02:50:44 --> Model "M_auth" initialized
INFO - 2023-11-07 02:50:44 --> Model "M_user" initialized
INFO - 2023-11-07 02:50:44 --> Model "M_produk" initialized
INFO - 2023-11-07 02:50:44 --> Controller Class Initialized
INFO - 2023-11-07 02:50:44 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-07 02:50:44 --> Final output sent to browser
DEBUG - 2023-11-07 02:50:44 --> Total execution time: 0.0026
ERROR - 2023-11-07 03:37:40 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-07 03:37:40 --> Config Class Initialized
INFO - 2023-11-07 03:37:40 --> Hooks Class Initialized
DEBUG - 2023-11-07 03:37:40 --> UTF-8 Support Enabled
INFO - 2023-11-07 03:37:40 --> Utf8 Class Initialized
INFO - 2023-11-07 03:37:40 --> URI Class Initialized
DEBUG - 2023-11-07 03:37:40 --> No URI present. Default controller set.
INFO - 2023-11-07 03:37:40 --> Router Class Initialized
INFO - 2023-11-07 03:37:40 --> Output Class Initialized
INFO - 2023-11-07 03:37:40 --> Security Class Initialized
DEBUG - 2023-11-07 03:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 03:37:40 --> Input Class Initialized
INFO - 2023-11-07 03:37:40 --> Language Class Initialized
INFO - 2023-11-07 03:37:40 --> Loader Class Initialized
INFO - 2023-11-07 03:37:40 --> Helper loaded: url_helper
INFO - 2023-11-07 03:37:40 --> Helper loaded: form_helper
INFO - 2023-11-07 03:37:40 --> Helper loaded: file_helper
INFO - 2023-11-07 03:37:40 --> Database Driver Class Initialized
DEBUG - 2023-11-07 03:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-07 03:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 03:37:40 --> Form Validation Class Initialized
INFO - 2023-11-07 03:37:40 --> Upload Class Initialized
INFO - 2023-11-07 03:37:40 --> Model "M_auth" initialized
INFO - 2023-11-07 03:37:40 --> Model "M_user" initialized
INFO - 2023-11-07 03:37:40 --> Model "M_produk" initialized
INFO - 2023-11-07 03:37:40 --> Controller Class Initialized
INFO - 2023-11-07 03:37:40 --> Model "M_pelanggan" initialized
INFO - 2023-11-07 03:37:40 --> Model "M_produk" initialized
DEBUG - 2023-11-07 03:37:40 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-07 03:37:40 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-07 03:37:40 --> Model "M_transaksi" initialized
INFO - 2023-11-07 03:37:40 --> Model "M_bank" initialized
INFO - 2023-11-07 03:37:40 --> Model "M_pesan" initialized
DEBUG - 2023-11-07 03:37:40 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-07 03:37:40 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-07 03:37:40 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-07 03:37:40 --> Final output sent to browser
DEBUG - 2023-11-07 03:37:40 --> Total execution time: 0.0407
ERROR - 2023-11-07 06:39:50 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-07 06:39:50 --> Config Class Initialized
INFO - 2023-11-07 06:39:50 --> Hooks Class Initialized
DEBUG - 2023-11-07 06:39:50 --> UTF-8 Support Enabled
INFO - 2023-11-07 06:39:50 --> Utf8 Class Initialized
INFO - 2023-11-07 06:39:50 --> URI Class Initialized
INFO - 2023-11-07 06:39:50 --> Router Class Initialized
INFO - 2023-11-07 06:39:50 --> Output Class Initialized
INFO - 2023-11-07 06:39:50 --> Security Class Initialized
DEBUG - 2023-11-07 06:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 06:39:50 --> Input Class Initialized
INFO - 2023-11-07 06:39:50 --> Language Class Initialized
INFO - 2023-11-07 06:39:50 --> Loader Class Initialized
INFO - 2023-11-07 06:39:50 --> Helper loaded: url_helper
INFO - 2023-11-07 06:39:50 --> Helper loaded: form_helper
INFO - 2023-11-07 06:39:50 --> Helper loaded: file_helper
INFO - 2023-11-07 06:39:50 --> Database Driver Class Initialized
DEBUG - 2023-11-07 06:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-07 06:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 06:39:50 --> Form Validation Class Initialized
INFO - 2023-11-07 06:39:50 --> Upload Class Initialized
INFO - 2023-11-07 06:39:50 --> Model "M_auth" initialized
INFO - 2023-11-07 06:39:50 --> Model "M_user" initialized
INFO - 2023-11-07 06:39:50 --> Model "M_produk" initialized
INFO - 2023-11-07 06:39:50 --> Controller Class Initialized
INFO - 2023-11-07 06:39:50 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-07 06:39:50 --> Final output sent to browser
DEBUG - 2023-11-07 06:39:50 --> Total execution time: 0.0280
ERROR - 2023-11-07 07:00:02 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-07 07:00:02 --> Config Class Initialized
INFO - 2023-11-07 07:00:02 --> Hooks Class Initialized
DEBUG - 2023-11-07 07:00:02 --> UTF-8 Support Enabled
INFO - 2023-11-07 07:00:02 --> Utf8 Class Initialized
INFO - 2023-11-07 07:00:02 --> URI Class Initialized
INFO - 2023-11-07 07:00:02 --> Router Class Initialized
INFO - 2023-11-07 07:00:02 --> Output Class Initialized
INFO - 2023-11-07 07:00:02 --> Security Class Initialized
DEBUG - 2023-11-07 07:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 07:00:02 --> Input Class Initialized
INFO - 2023-11-07 07:00:02 --> Language Class Initialized
INFO - 2023-11-07 07:00:02 --> Loader Class Initialized
INFO - 2023-11-07 07:00:02 --> Helper loaded: url_helper
INFO - 2023-11-07 07:00:02 --> Helper loaded: form_helper
INFO - 2023-11-07 07:00:02 --> Helper loaded: file_helper
INFO - 2023-11-07 07:00:02 --> Database Driver Class Initialized
DEBUG - 2023-11-07 07:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-07 07:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 07:00:02 --> Form Validation Class Initialized
INFO - 2023-11-07 07:00:02 --> Upload Class Initialized
INFO - 2023-11-07 07:00:02 --> Model "M_auth" initialized
INFO - 2023-11-07 07:00:02 --> Model "M_user" initialized
INFO - 2023-11-07 07:00:02 --> Model "M_produk" initialized
INFO - 2023-11-07 07:00:02 --> Controller Class Initialized
INFO - 2023-11-07 07:00:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-07 07:00:02 --> Final output sent to browser
DEBUG - 2023-11-07 07:00:02 --> Total execution time: 0.0354
ERROR - 2023-11-07 07:16:49 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-07 07:16:49 --> Config Class Initialized
INFO - 2023-11-07 07:16:49 --> Hooks Class Initialized
DEBUG - 2023-11-07 07:16:49 --> UTF-8 Support Enabled
INFO - 2023-11-07 07:16:49 --> Utf8 Class Initialized
INFO - 2023-11-07 07:16:49 --> URI Class Initialized
DEBUG - 2023-11-07 07:16:49 --> No URI present. Default controller set.
INFO - 2023-11-07 07:16:49 --> Router Class Initialized
INFO - 2023-11-07 07:16:49 --> Output Class Initialized
INFO - 2023-11-07 07:16:49 --> Security Class Initialized
DEBUG - 2023-11-07 07:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 07:16:49 --> Input Class Initialized
INFO - 2023-11-07 07:16:49 --> Language Class Initialized
INFO - 2023-11-07 07:16:49 --> Loader Class Initialized
INFO - 2023-11-07 07:16:49 --> Helper loaded: url_helper
INFO - 2023-11-07 07:16:49 --> Helper loaded: form_helper
INFO - 2023-11-07 07:16:49 --> Helper loaded: file_helper
INFO - 2023-11-07 07:16:49 --> Database Driver Class Initialized
DEBUG - 2023-11-07 07:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-07 07:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 07:16:49 --> Form Validation Class Initialized
INFO - 2023-11-07 07:16:49 --> Upload Class Initialized
INFO - 2023-11-07 07:16:49 --> Model "M_auth" initialized
INFO - 2023-11-07 07:16:49 --> Model "M_user" initialized
INFO - 2023-11-07 07:16:49 --> Model "M_produk" initialized
INFO - 2023-11-07 07:16:49 --> Controller Class Initialized
INFO - 2023-11-07 07:16:49 --> Model "M_pelanggan" initialized
INFO - 2023-11-07 07:16:49 --> Model "M_produk" initialized
DEBUG - 2023-11-07 07:16:49 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-07 07:16:49 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-07 07:16:49 --> Model "M_transaksi" initialized
INFO - 2023-11-07 07:16:49 --> Model "M_bank" initialized
INFO - 2023-11-07 07:16:49 --> Model "M_pesan" initialized
DEBUG - 2023-11-07 07:16:49 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-07 07:16:49 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-07 07:16:49 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-07 07:16:49 --> Final output sent to browser
DEBUG - 2023-11-07 07:16:49 --> Total execution time: 0.0470
ERROR - 2023-11-07 07:34:49 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-07 07:34:49 --> Config Class Initialized
INFO - 2023-11-07 07:34:49 --> Hooks Class Initialized
DEBUG - 2023-11-07 07:34:49 --> UTF-8 Support Enabled
INFO - 2023-11-07 07:34:49 --> Utf8 Class Initialized
INFO - 2023-11-07 07:34:49 --> URI Class Initialized
INFO - 2023-11-07 07:34:49 --> Router Class Initialized
INFO - 2023-11-07 07:34:49 --> Output Class Initialized
INFO - 2023-11-07 07:34:49 --> Security Class Initialized
DEBUG - 2023-11-07 07:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 07:34:49 --> Input Class Initialized
INFO - 2023-11-07 07:34:49 --> Language Class Initialized
INFO - 2023-11-07 07:34:49 --> Loader Class Initialized
INFO - 2023-11-07 07:34:49 --> Helper loaded: url_helper
INFO - 2023-11-07 07:34:49 --> Helper loaded: form_helper
INFO - 2023-11-07 07:34:49 --> Helper loaded: file_helper
INFO - 2023-11-07 07:34:49 --> Database Driver Class Initialized
DEBUG - 2023-11-07 07:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-07 07:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 07:34:49 --> Form Validation Class Initialized
INFO - 2023-11-07 07:34:49 --> Upload Class Initialized
INFO - 2023-11-07 07:34:49 --> Model "M_auth" initialized
INFO - 2023-11-07 07:34:49 --> Model "M_user" initialized
INFO - 2023-11-07 07:34:49 --> Model "M_produk" initialized
INFO - 2023-11-07 07:34:49 --> Controller Class Initialized
INFO - 2023-11-07 07:34:49 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-07 07:34:49 --> Final output sent to browser
DEBUG - 2023-11-07 07:34:49 --> Total execution time: 0.0360
ERROR - 2023-11-07 08:14:35 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-07 08:14:35 --> Config Class Initialized
INFO - 2023-11-07 08:14:35 --> Hooks Class Initialized
DEBUG - 2023-11-07 08:14:35 --> UTF-8 Support Enabled
INFO - 2023-11-07 08:14:35 --> Utf8 Class Initialized
INFO - 2023-11-07 08:14:35 --> URI Class Initialized
INFO - 2023-11-07 08:14:35 --> Router Class Initialized
INFO - 2023-11-07 08:14:35 --> Output Class Initialized
INFO - 2023-11-07 08:14:35 --> Security Class Initialized
DEBUG - 2023-11-07 08:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 08:14:35 --> Input Class Initialized
INFO - 2023-11-07 08:14:35 --> Language Class Initialized
INFO - 2023-11-07 08:14:35 --> Loader Class Initialized
INFO - 2023-11-07 08:14:35 --> Helper loaded: url_helper
INFO - 2023-11-07 08:14:35 --> Helper loaded: form_helper
INFO - 2023-11-07 08:14:35 --> Helper loaded: file_helper
INFO - 2023-11-07 08:14:35 --> Database Driver Class Initialized
DEBUG - 2023-11-07 08:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-07 08:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 08:14:35 --> Form Validation Class Initialized
INFO - 2023-11-07 08:14:35 --> Upload Class Initialized
INFO - 2023-11-07 08:14:35 --> Model "M_auth" initialized
INFO - 2023-11-07 08:14:35 --> Model "M_user" initialized
INFO - 2023-11-07 08:14:35 --> Model "M_produk" initialized
INFO - 2023-11-07 08:14:35 --> Controller Class Initialized
INFO - 2023-11-07 08:14:35 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-07 08:14:35 --> Final output sent to browser
DEBUG - 2023-11-07 08:14:35 --> Total execution time: 0.0281
ERROR - 2023-11-07 08:37:20 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-07 08:37:20 --> Config Class Initialized
INFO - 2023-11-07 08:37:20 --> Hooks Class Initialized
DEBUG - 2023-11-07 08:37:20 --> UTF-8 Support Enabled
INFO - 2023-11-07 08:37:20 --> Utf8 Class Initialized
INFO - 2023-11-07 08:37:20 --> URI Class Initialized
INFO - 2023-11-07 08:37:20 --> Router Class Initialized
INFO - 2023-11-07 08:37:20 --> Output Class Initialized
INFO - 2023-11-07 08:37:20 --> Security Class Initialized
DEBUG - 2023-11-07 08:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 08:37:20 --> Input Class Initialized
INFO - 2023-11-07 08:37:20 --> Language Class Initialized
INFO - 2023-11-07 08:37:20 --> Loader Class Initialized
INFO - 2023-11-07 08:37:20 --> Helper loaded: url_helper
INFO - 2023-11-07 08:37:20 --> Helper loaded: form_helper
INFO - 2023-11-07 08:37:20 --> Helper loaded: file_helper
INFO - 2023-11-07 08:37:20 --> Database Driver Class Initialized
DEBUG - 2023-11-07 08:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-07 08:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 08:37:20 --> Form Validation Class Initialized
INFO - 2023-11-07 08:37:20 --> Upload Class Initialized
INFO - 2023-11-07 08:37:20 --> Model "M_auth" initialized
INFO - 2023-11-07 08:37:20 --> Model "M_user" initialized
INFO - 2023-11-07 08:37:20 --> Model "M_produk" initialized
INFO - 2023-11-07 08:37:20 --> Controller Class Initialized
INFO - 2023-11-07 08:37:20 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-07 08:37:20 --> Final output sent to browser
DEBUG - 2023-11-07 08:37:20 --> Total execution time: 0.0339
ERROR - 2023-11-07 10:56:00 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-07 10:56:00 --> Config Class Initialized
INFO - 2023-11-07 10:56:00 --> Hooks Class Initialized
DEBUG - 2023-11-07 10:56:00 --> UTF-8 Support Enabled
INFO - 2023-11-07 10:56:00 --> Utf8 Class Initialized
INFO - 2023-11-07 10:56:00 --> URI Class Initialized
DEBUG - 2023-11-07 10:56:00 --> No URI present. Default controller set.
INFO - 2023-11-07 10:56:00 --> Router Class Initialized
INFO - 2023-11-07 10:56:00 --> Output Class Initialized
INFO - 2023-11-07 10:56:00 --> Security Class Initialized
DEBUG - 2023-11-07 10:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 10:56:00 --> Input Class Initialized
INFO - 2023-11-07 10:56:00 --> Language Class Initialized
INFO - 2023-11-07 10:56:00 --> Loader Class Initialized
INFO - 2023-11-07 10:56:00 --> Helper loaded: url_helper
INFO - 2023-11-07 10:56:00 --> Helper loaded: form_helper
INFO - 2023-11-07 10:56:00 --> Helper loaded: file_helper
INFO - 2023-11-07 10:56:00 --> Database Driver Class Initialized
DEBUG - 2023-11-07 10:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-07 10:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 10:56:00 --> Form Validation Class Initialized
INFO - 2023-11-07 10:56:00 --> Upload Class Initialized
INFO - 2023-11-07 10:56:00 --> Model "M_auth" initialized
INFO - 2023-11-07 10:56:00 --> Model "M_user" initialized
INFO - 2023-11-07 10:56:00 --> Model "M_produk" initialized
INFO - 2023-11-07 10:56:00 --> Controller Class Initialized
INFO - 2023-11-07 10:56:00 --> Model "M_pelanggan" initialized
INFO - 2023-11-07 10:56:00 --> Model "M_produk" initialized
DEBUG - 2023-11-07 10:56:00 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-07 10:56:00 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-07 10:56:00 --> Model "M_transaksi" initialized
INFO - 2023-11-07 10:56:00 --> Model "M_bank" initialized
INFO - 2023-11-07 10:56:00 --> Model "M_pesan" initialized
DEBUG - 2023-11-07 10:56:00 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-07 10:56:00 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-07 10:56:00 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-07 10:56:00 --> Final output sent to browser
DEBUG - 2023-11-07 10:56:00 --> Total execution time: 0.0410
ERROR - 2023-11-07 11:05:11 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-07 11:05:11 --> Config Class Initialized
INFO - 2023-11-07 11:05:11 --> Hooks Class Initialized
DEBUG - 2023-11-07 11:05:11 --> UTF-8 Support Enabled
INFO - 2023-11-07 11:05:11 --> Utf8 Class Initialized
INFO - 2023-11-07 11:05:11 --> URI Class Initialized
DEBUG - 2023-11-07 11:05:11 --> No URI present. Default controller set.
INFO - 2023-11-07 11:05:11 --> Router Class Initialized
INFO - 2023-11-07 11:05:11 --> Output Class Initialized
INFO - 2023-11-07 11:05:11 --> Security Class Initialized
DEBUG - 2023-11-07 11:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 11:05:11 --> Input Class Initialized
INFO - 2023-11-07 11:05:11 --> Language Class Initialized
INFO - 2023-11-07 11:05:11 --> Loader Class Initialized
INFO - 2023-11-07 11:05:11 --> Helper loaded: url_helper
INFO - 2023-11-07 11:05:11 --> Helper loaded: form_helper
INFO - 2023-11-07 11:05:11 --> Helper loaded: file_helper
INFO - 2023-11-07 11:05:11 --> Database Driver Class Initialized
DEBUG - 2023-11-07 11:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-07 11:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 11:05:11 --> Form Validation Class Initialized
INFO - 2023-11-07 11:05:11 --> Upload Class Initialized
INFO - 2023-11-07 11:05:11 --> Model "M_auth" initialized
INFO - 2023-11-07 11:05:11 --> Model "M_user" initialized
INFO - 2023-11-07 11:05:11 --> Model "M_produk" initialized
INFO - 2023-11-07 11:05:11 --> Controller Class Initialized
INFO - 2023-11-07 11:05:11 --> Model "M_pelanggan" initialized
INFO - 2023-11-07 11:05:11 --> Model "M_produk" initialized
DEBUG - 2023-11-07 11:05:11 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-07 11:05:11 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-07 11:05:11 --> Model "M_transaksi" initialized
INFO - 2023-11-07 11:05:11 --> Model "M_bank" initialized
INFO - 2023-11-07 11:05:11 --> Model "M_pesan" initialized
DEBUG - 2023-11-07 11:05:11 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-07 11:05:11 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-07 11:05:11 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-07 11:05:11 --> Final output sent to browser
DEBUG - 2023-11-07 11:05:11 --> Total execution time: 0.0347
ERROR - 2023-11-07 13:41:29 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-07 13:41:29 --> Config Class Initialized
INFO - 2023-11-07 13:41:29 --> Hooks Class Initialized
DEBUG - 2023-11-07 13:41:29 --> UTF-8 Support Enabled
INFO - 2023-11-07 13:41:29 --> Utf8 Class Initialized
INFO - 2023-11-07 13:41:29 --> URI Class Initialized
INFO - 2023-11-07 13:41:29 --> Router Class Initialized
INFO - 2023-11-07 13:41:29 --> Output Class Initialized
INFO - 2023-11-07 13:41:29 --> Security Class Initialized
DEBUG - 2023-11-07 13:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 13:41:29 --> Input Class Initialized
INFO - 2023-11-07 13:41:29 --> Language Class Initialized
INFO - 2023-11-07 13:41:29 --> Loader Class Initialized
INFO - 2023-11-07 13:41:29 --> Helper loaded: url_helper
INFO - 2023-11-07 13:41:29 --> Helper loaded: form_helper
INFO - 2023-11-07 13:41:29 --> Helper loaded: file_helper
INFO - 2023-11-07 13:41:29 --> Database Driver Class Initialized
DEBUG - 2023-11-07 13:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-07 13:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 13:41:30 --> Form Validation Class Initialized
INFO - 2023-11-07 13:41:30 --> Upload Class Initialized
INFO - 2023-11-07 13:41:30 --> Model "M_auth" initialized
INFO - 2023-11-07 13:41:30 --> Model "M_user" initialized
INFO - 2023-11-07 13:41:30 --> Model "M_produk" initialized
INFO - 2023-11-07 13:41:30 --> Controller Class Initialized
INFO - 2023-11-07 13:41:30 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-07 13:41:30 --> Final output sent to browser
DEBUG - 2023-11-07 13:41:30 --> Total execution time: 0.0381
ERROR - 2023-11-07 13:41:30 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-07 13:41:30 --> Config Class Initialized
INFO - 2023-11-07 13:41:30 --> Hooks Class Initialized
DEBUG - 2023-11-07 13:41:30 --> UTF-8 Support Enabled
INFO - 2023-11-07 13:41:30 --> Utf8 Class Initialized
INFO - 2023-11-07 13:41:30 --> URI Class Initialized
INFO - 2023-11-07 13:41:30 --> Router Class Initialized
INFO - 2023-11-07 13:41:30 --> Output Class Initialized
INFO - 2023-11-07 13:41:30 --> Security Class Initialized
DEBUG - 2023-11-07 13:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 13:41:30 --> Input Class Initialized
INFO - 2023-11-07 13:41:30 --> Language Class Initialized
INFO - 2023-11-07 13:41:30 --> Loader Class Initialized
INFO - 2023-11-07 13:41:30 --> Helper loaded: url_helper
INFO - 2023-11-07 13:41:30 --> Helper loaded: form_helper
INFO - 2023-11-07 13:41:30 --> Helper loaded: file_helper
INFO - 2023-11-07 13:41:30 --> Database Driver Class Initialized
DEBUG - 2023-11-07 13:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-07 13:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 13:41:30 --> Form Validation Class Initialized
INFO - 2023-11-07 13:41:30 --> Upload Class Initialized
INFO - 2023-11-07 13:41:30 --> Model "M_auth" initialized
INFO - 2023-11-07 13:41:30 --> Model "M_user" initialized
INFO - 2023-11-07 13:41:30 --> Model "M_produk" initialized
INFO - 2023-11-07 13:41:30 --> Controller Class Initialized
INFO - 2023-11-07 13:41:30 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-07 13:41:30 --> Final output sent to browser
DEBUG - 2023-11-07 13:41:30 --> Total execution time: 0.0030
ERROR - 2023-11-07 14:13:05 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-07 14:13:05 --> Config Class Initialized
INFO - 2023-11-07 14:13:05 --> Hooks Class Initialized
DEBUG - 2023-11-07 14:13:05 --> UTF-8 Support Enabled
INFO - 2023-11-07 14:13:05 --> Utf8 Class Initialized
INFO - 2023-11-07 14:13:05 --> URI Class Initialized
DEBUG - 2023-11-07 14:13:05 --> No URI present. Default controller set.
INFO - 2023-11-07 14:13:05 --> Router Class Initialized
INFO - 2023-11-07 14:13:05 --> Output Class Initialized
INFO - 2023-11-07 14:13:05 --> Security Class Initialized
DEBUG - 2023-11-07 14:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 14:13:05 --> Input Class Initialized
INFO - 2023-11-07 14:13:05 --> Language Class Initialized
INFO - 2023-11-07 14:13:05 --> Loader Class Initialized
INFO - 2023-11-07 14:13:05 --> Helper loaded: url_helper
INFO - 2023-11-07 14:13:05 --> Helper loaded: form_helper
INFO - 2023-11-07 14:13:05 --> Helper loaded: file_helper
INFO - 2023-11-07 14:13:05 --> Database Driver Class Initialized
DEBUG - 2023-11-07 14:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-07 14:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 14:13:05 --> Form Validation Class Initialized
INFO - 2023-11-07 14:13:05 --> Upload Class Initialized
INFO - 2023-11-07 14:13:05 --> Model "M_auth" initialized
INFO - 2023-11-07 14:13:05 --> Model "M_user" initialized
INFO - 2023-11-07 14:13:05 --> Model "M_produk" initialized
INFO - 2023-11-07 14:13:05 --> Controller Class Initialized
INFO - 2023-11-07 14:13:05 --> Model "M_pelanggan" initialized
INFO - 2023-11-07 14:13:05 --> Model "M_produk" initialized
DEBUG - 2023-11-07 14:13:05 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-07 14:13:05 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-07 14:13:05 --> Model "M_transaksi" initialized
INFO - 2023-11-07 14:13:05 --> Model "M_bank" initialized
INFO - 2023-11-07 14:13:05 --> Model "M_pesan" initialized
DEBUG - 2023-11-07 14:13:05 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-07 14:13:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-07 14:13:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-07 14:13:05 --> Final output sent to browser
DEBUG - 2023-11-07 14:13:05 --> Total execution time: 0.0353
ERROR - 2023-11-07 14:38:40 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-07 14:38:40 --> Config Class Initialized
INFO - 2023-11-07 14:38:40 --> Hooks Class Initialized
DEBUG - 2023-11-07 14:38:40 --> UTF-8 Support Enabled
INFO - 2023-11-07 14:38:40 --> Utf8 Class Initialized
INFO - 2023-11-07 14:38:40 --> URI Class Initialized
DEBUG - 2023-11-07 14:38:40 --> No URI present. Default controller set.
INFO - 2023-11-07 14:38:40 --> Router Class Initialized
INFO - 2023-11-07 14:38:40 --> Output Class Initialized
INFO - 2023-11-07 14:38:40 --> Security Class Initialized
DEBUG - 2023-11-07 14:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 14:38:40 --> Input Class Initialized
INFO - 2023-11-07 14:38:40 --> Language Class Initialized
INFO - 2023-11-07 14:38:40 --> Loader Class Initialized
INFO - 2023-11-07 14:38:40 --> Helper loaded: url_helper
INFO - 2023-11-07 14:38:40 --> Helper loaded: form_helper
INFO - 2023-11-07 14:38:40 --> Helper loaded: file_helper
INFO - 2023-11-07 14:38:40 --> Database Driver Class Initialized
DEBUG - 2023-11-07 14:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-07 14:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 14:38:40 --> Form Validation Class Initialized
INFO - 2023-11-07 14:38:40 --> Upload Class Initialized
INFO - 2023-11-07 14:38:40 --> Model "M_auth" initialized
INFO - 2023-11-07 14:38:40 --> Model "M_user" initialized
INFO - 2023-11-07 14:38:40 --> Model "M_produk" initialized
INFO - 2023-11-07 14:38:40 --> Controller Class Initialized
INFO - 2023-11-07 14:38:40 --> Model "M_pelanggan" initialized
INFO - 2023-11-07 14:38:40 --> Model "M_produk" initialized
DEBUG - 2023-11-07 14:38:40 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-07 14:38:40 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-07 14:38:40 --> Model "M_transaksi" initialized
INFO - 2023-11-07 14:38:40 --> Model "M_bank" initialized
INFO - 2023-11-07 14:38:40 --> Model "M_pesan" initialized
DEBUG - 2023-11-07 14:38:40 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-07 14:38:40 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-07 14:38:40 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-07 14:38:40 --> Final output sent to browser
DEBUG - 2023-11-07 14:38:40 --> Total execution time: 0.0424
ERROR - 2023-11-07 14:47:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-07 14:47:45 --> Config Class Initialized
INFO - 2023-11-07 14:47:45 --> Hooks Class Initialized
DEBUG - 2023-11-07 14:47:45 --> UTF-8 Support Enabled
INFO - 2023-11-07 14:47:45 --> Utf8 Class Initialized
INFO - 2023-11-07 14:47:45 --> URI Class Initialized
DEBUG - 2023-11-07 14:47:45 --> No URI present. Default controller set.
INFO - 2023-11-07 14:47:45 --> Router Class Initialized
INFO - 2023-11-07 14:47:45 --> Output Class Initialized
INFO - 2023-11-07 14:47:45 --> Security Class Initialized
DEBUG - 2023-11-07 14:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 14:47:45 --> Input Class Initialized
INFO - 2023-11-07 14:47:45 --> Language Class Initialized
INFO - 2023-11-07 14:47:45 --> Loader Class Initialized
INFO - 2023-11-07 14:47:45 --> Helper loaded: url_helper
INFO - 2023-11-07 14:47:45 --> Helper loaded: form_helper
INFO - 2023-11-07 14:47:45 --> Helper loaded: file_helper
INFO - 2023-11-07 14:47:45 --> Database Driver Class Initialized
DEBUG - 2023-11-07 14:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-07 14:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 14:47:45 --> Form Validation Class Initialized
INFO - 2023-11-07 14:47:45 --> Upload Class Initialized
INFO - 2023-11-07 14:47:45 --> Model "M_auth" initialized
INFO - 2023-11-07 14:47:45 --> Model "M_user" initialized
INFO - 2023-11-07 14:47:45 --> Model "M_produk" initialized
INFO - 2023-11-07 14:47:45 --> Controller Class Initialized
INFO - 2023-11-07 14:47:45 --> Model "M_pelanggan" initialized
INFO - 2023-11-07 14:47:45 --> Model "M_produk" initialized
DEBUG - 2023-11-07 14:47:45 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-07 14:47:45 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-07 14:47:45 --> Model "M_transaksi" initialized
INFO - 2023-11-07 14:47:45 --> Model "M_bank" initialized
INFO - 2023-11-07 14:47:45 --> Model "M_pesan" initialized
DEBUG - 2023-11-07 14:47:45 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-07 14:47:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-07 14:47:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-07 14:47:45 --> Final output sent to browser
DEBUG - 2023-11-07 14:47:45 --> Total execution time: 0.0445
ERROR - 2023-11-07 15:33:03 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-07 15:33:03 --> Config Class Initialized
INFO - 2023-11-07 15:33:03 --> Hooks Class Initialized
DEBUG - 2023-11-07 15:33:03 --> UTF-8 Support Enabled
INFO - 2023-11-07 15:33:03 --> Utf8 Class Initialized
INFO - 2023-11-07 15:33:03 --> URI Class Initialized
DEBUG - 2023-11-07 15:33:03 --> No URI present. Default controller set.
INFO - 2023-11-07 15:33:03 --> Router Class Initialized
INFO - 2023-11-07 15:33:03 --> Output Class Initialized
INFO - 2023-11-07 15:33:03 --> Security Class Initialized
DEBUG - 2023-11-07 15:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 15:33:03 --> Input Class Initialized
INFO - 2023-11-07 15:33:03 --> Language Class Initialized
INFO - 2023-11-07 15:33:03 --> Loader Class Initialized
INFO - 2023-11-07 15:33:03 --> Helper loaded: url_helper
INFO - 2023-11-07 15:33:03 --> Helper loaded: form_helper
INFO - 2023-11-07 15:33:03 --> Helper loaded: file_helper
INFO - 2023-11-07 15:33:03 --> Database Driver Class Initialized
DEBUG - 2023-11-07 15:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-07 15:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 15:33:03 --> Form Validation Class Initialized
INFO - 2023-11-07 15:33:03 --> Upload Class Initialized
INFO - 2023-11-07 15:33:03 --> Model "M_auth" initialized
INFO - 2023-11-07 15:33:03 --> Model "M_user" initialized
INFO - 2023-11-07 15:33:03 --> Model "M_produk" initialized
INFO - 2023-11-07 15:33:03 --> Controller Class Initialized
INFO - 2023-11-07 15:33:03 --> Model "M_pelanggan" initialized
INFO - 2023-11-07 15:33:03 --> Model "M_produk" initialized
DEBUG - 2023-11-07 15:33:03 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-07 15:33:03 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-07 15:33:03 --> Model "M_transaksi" initialized
INFO - 2023-11-07 15:33:03 --> Model "M_bank" initialized
INFO - 2023-11-07 15:33:03 --> Model "M_pesan" initialized
DEBUG - 2023-11-07 15:33:03 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-07 15:33:03 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-07 15:33:03 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-07 15:33:03 --> Final output sent to browser
DEBUG - 2023-11-07 15:33:03 --> Total execution time: 0.0454
ERROR - 2023-11-07 16:20:47 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-07 16:20:47 --> Config Class Initialized
INFO - 2023-11-07 16:20:47 --> Hooks Class Initialized
DEBUG - 2023-11-07 16:20:47 --> UTF-8 Support Enabled
INFO - 2023-11-07 16:20:47 --> Utf8 Class Initialized
INFO - 2023-11-07 16:20:47 --> URI Class Initialized
DEBUG - 2023-11-07 16:20:47 --> No URI present. Default controller set.
INFO - 2023-11-07 16:20:47 --> Router Class Initialized
INFO - 2023-11-07 16:20:47 --> Output Class Initialized
INFO - 2023-11-07 16:20:47 --> Security Class Initialized
DEBUG - 2023-11-07 16:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 16:20:47 --> Input Class Initialized
INFO - 2023-11-07 16:20:47 --> Language Class Initialized
INFO - 2023-11-07 16:20:47 --> Loader Class Initialized
INFO - 2023-11-07 16:20:47 --> Helper loaded: url_helper
INFO - 2023-11-07 16:20:47 --> Helper loaded: form_helper
INFO - 2023-11-07 16:20:47 --> Helper loaded: file_helper
INFO - 2023-11-07 16:20:47 --> Database Driver Class Initialized
DEBUG - 2023-11-07 16:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-07 16:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 16:20:47 --> Form Validation Class Initialized
INFO - 2023-11-07 16:20:47 --> Upload Class Initialized
INFO - 2023-11-07 16:20:47 --> Model "M_auth" initialized
INFO - 2023-11-07 16:20:47 --> Model "M_user" initialized
INFO - 2023-11-07 16:20:47 --> Model "M_produk" initialized
INFO - 2023-11-07 16:20:47 --> Controller Class Initialized
INFO - 2023-11-07 16:20:47 --> Model "M_pelanggan" initialized
INFO - 2023-11-07 16:20:47 --> Model "M_produk" initialized
DEBUG - 2023-11-07 16:20:47 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-07 16:20:47 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-07 16:20:47 --> Model "M_transaksi" initialized
INFO - 2023-11-07 16:20:47 --> Model "M_bank" initialized
INFO - 2023-11-07 16:20:47 --> Model "M_pesan" initialized
DEBUG - 2023-11-07 16:20:47 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-07 16:20:47 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-07 16:20:47 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-07 16:20:47 --> Final output sent to browser
DEBUG - 2023-11-07 16:20:47 --> Total execution time: 0.0324
ERROR - 2023-11-07 18:28:09 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-07 18:28:09 --> Config Class Initialized
INFO - 2023-11-07 18:28:09 --> Hooks Class Initialized
DEBUG - 2023-11-07 18:28:09 --> UTF-8 Support Enabled
INFO - 2023-11-07 18:28:09 --> Utf8 Class Initialized
INFO - 2023-11-07 18:28:09 --> URI Class Initialized
DEBUG - 2023-11-07 18:28:09 --> No URI present. Default controller set.
INFO - 2023-11-07 18:28:09 --> Router Class Initialized
INFO - 2023-11-07 18:28:09 --> Output Class Initialized
INFO - 2023-11-07 18:28:09 --> Security Class Initialized
DEBUG - 2023-11-07 18:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 18:28:09 --> Input Class Initialized
INFO - 2023-11-07 18:28:09 --> Language Class Initialized
INFO - 2023-11-07 18:28:09 --> Loader Class Initialized
INFO - 2023-11-07 18:28:09 --> Helper loaded: url_helper
INFO - 2023-11-07 18:28:09 --> Helper loaded: form_helper
INFO - 2023-11-07 18:28:09 --> Helper loaded: file_helper
INFO - 2023-11-07 18:28:09 --> Database Driver Class Initialized
DEBUG - 2023-11-07 18:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-07 18:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 18:28:09 --> Form Validation Class Initialized
INFO - 2023-11-07 18:28:09 --> Upload Class Initialized
INFO - 2023-11-07 18:28:09 --> Model "M_auth" initialized
INFO - 2023-11-07 18:28:09 --> Model "M_user" initialized
INFO - 2023-11-07 18:28:09 --> Model "M_produk" initialized
INFO - 2023-11-07 18:28:09 --> Controller Class Initialized
INFO - 2023-11-07 18:28:09 --> Model "M_pelanggan" initialized
INFO - 2023-11-07 18:28:09 --> Model "M_produk" initialized
DEBUG - 2023-11-07 18:28:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-07 18:28:09 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-07 18:28:09 --> Model "M_transaksi" initialized
INFO - 2023-11-07 18:28:09 --> Model "M_bank" initialized
INFO - 2023-11-07 18:28:09 --> Model "M_pesan" initialized
DEBUG - 2023-11-07 18:28:09 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-07 18:28:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-07 18:28:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-07 18:28:09 --> Final output sent to browser
DEBUG - 2023-11-07 18:28:09 --> Total execution time: 0.0369
ERROR - 2023-11-07 18:33:18 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-07 18:33:18 --> Config Class Initialized
INFO - 2023-11-07 18:33:18 --> Hooks Class Initialized
DEBUG - 2023-11-07 18:33:18 --> UTF-8 Support Enabled
INFO - 2023-11-07 18:33:18 --> Utf8 Class Initialized
INFO - 2023-11-07 18:33:18 --> URI Class Initialized
DEBUG - 2023-11-07 18:33:18 --> No URI present. Default controller set.
INFO - 2023-11-07 18:33:18 --> Router Class Initialized
INFO - 2023-11-07 18:33:18 --> Output Class Initialized
INFO - 2023-11-07 18:33:18 --> Security Class Initialized
DEBUG - 2023-11-07 18:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 18:33:18 --> Input Class Initialized
INFO - 2023-11-07 18:33:18 --> Language Class Initialized
INFO - 2023-11-07 18:33:18 --> Loader Class Initialized
INFO - 2023-11-07 18:33:18 --> Helper loaded: url_helper
INFO - 2023-11-07 18:33:18 --> Helper loaded: form_helper
INFO - 2023-11-07 18:33:18 --> Helper loaded: file_helper
INFO - 2023-11-07 18:33:18 --> Database Driver Class Initialized
DEBUG - 2023-11-07 18:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-07 18:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 18:33:18 --> Form Validation Class Initialized
INFO - 2023-11-07 18:33:18 --> Upload Class Initialized
INFO - 2023-11-07 18:33:18 --> Model "M_auth" initialized
INFO - 2023-11-07 18:33:18 --> Model "M_user" initialized
INFO - 2023-11-07 18:33:18 --> Model "M_produk" initialized
INFO - 2023-11-07 18:33:18 --> Controller Class Initialized
INFO - 2023-11-07 18:33:18 --> Model "M_pelanggan" initialized
INFO - 2023-11-07 18:33:18 --> Model "M_produk" initialized
DEBUG - 2023-11-07 18:33:18 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-07 18:33:18 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-07 18:33:18 --> Model "M_transaksi" initialized
INFO - 2023-11-07 18:33:18 --> Model "M_bank" initialized
INFO - 2023-11-07 18:33:18 --> Model "M_pesan" initialized
DEBUG - 2023-11-07 18:33:18 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-07 18:33:18 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-07 18:33:18 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-07 18:33:18 --> Final output sent to browser
DEBUG - 2023-11-07 18:33:18 --> Total execution time: 0.0053
ERROR - 2023-11-07 18:55:58 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-07 18:55:58 --> Config Class Initialized
INFO - 2023-11-07 18:55:58 --> Hooks Class Initialized
DEBUG - 2023-11-07 18:55:58 --> UTF-8 Support Enabled
INFO - 2023-11-07 18:55:58 --> Utf8 Class Initialized
INFO - 2023-11-07 18:55:58 --> URI Class Initialized
DEBUG - 2023-11-07 18:55:58 --> No URI present. Default controller set.
INFO - 2023-11-07 18:55:58 --> Router Class Initialized
INFO - 2023-11-07 18:55:58 --> Output Class Initialized
INFO - 2023-11-07 18:55:58 --> Security Class Initialized
DEBUG - 2023-11-07 18:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 18:55:58 --> Input Class Initialized
INFO - 2023-11-07 18:55:58 --> Language Class Initialized
INFO - 2023-11-07 18:55:58 --> Loader Class Initialized
INFO - 2023-11-07 18:55:58 --> Helper loaded: url_helper
INFO - 2023-11-07 18:55:58 --> Helper loaded: form_helper
INFO - 2023-11-07 18:55:58 --> Helper loaded: file_helper
INFO - 2023-11-07 18:55:58 --> Database Driver Class Initialized
DEBUG - 2023-11-07 18:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-07 18:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 18:55:58 --> Form Validation Class Initialized
INFO - 2023-11-07 18:55:58 --> Upload Class Initialized
INFO - 2023-11-07 18:55:58 --> Model "M_auth" initialized
INFO - 2023-11-07 18:55:58 --> Model "M_user" initialized
INFO - 2023-11-07 18:55:58 --> Model "M_produk" initialized
INFO - 2023-11-07 18:55:58 --> Controller Class Initialized
INFO - 2023-11-07 18:55:58 --> Model "M_pelanggan" initialized
INFO - 2023-11-07 18:55:58 --> Model "M_produk" initialized
DEBUG - 2023-11-07 18:55:58 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-07 18:55:58 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-07 18:55:58 --> Model "M_transaksi" initialized
INFO - 2023-11-07 18:55:58 --> Model "M_bank" initialized
INFO - 2023-11-07 18:55:58 --> Model "M_pesan" initialized
DEBUG - 2023-11-07 18:55:58 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-07 18:55:58 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-07 18:55:58 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-07 18:55:58 --> Final output sent to browser
DEBUG - 2023-11-07 18:55:58 --> Total execution time: 0.0315
ERROR - 2023-11-07 19:54:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-07 19:54:45 --> Config Class Initialized
INFO - 2023-11-07 19:54:45 --> Hooks Class Initialized
DEBUG - 2023-11-07 19:54:45 --> UTF-8 Support Enabled
INFO - 2023-11-07 19:54:45 --> Utf8 Class Initialized
INFO - 2023-11-07 19:54:45 --> URI Class Initialized
INFO - 2023-11-07 19:54:45 --> Router Class Initialized
INFO - 2023-11-07 19:54:45 --> Output Class Initialized
INFO - 2023-11-07 19:54:45 --> Security Class Initialized
DEBUG - 2023-11-07 19:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 19:54:45 --> Input Class Initialized
INFO - 2023-11-07 19:54:45 --> Language Class Initialized
INFO - 2023-11-07 19:54:45 --> Loader Class Initialized
INFO - 2023-11-07 19:54:45 --> Helper loaded: url_helper
INFO - 2023-11-07 19:54:45 --> Helper loaded: form_helper
INFO - 2023-11-07 19:54:45 --> Helper loaded: file_helper
INFO - 2023-11-07 19:54:45 --> Database Driver Class Initialized
DEBUG - 2023-11-07 19:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-07 19:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 19:54:45 --> Form Validation Class Initialized
INFO - 2023-11-07 19:54:45 --> Upload Class Initialized
INFO - 2023-11-07 19:54:45 --> Model "M_auth" initialized
INFO - 2023-11-07 19:54:45 --> Model "M_user" initialized
INFO - 2023-11-07 19:54:45 --> Model "M_produk" initialized
INFO - 2023-11-07 19:54:45 --> Controller Class Initialized
INFO - 2023-11-07 19:54:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-07 19:54:45 --> Final output sent to browser
DEBUG - 2023-11-07 19:54:45 --> Total execution time: 0.0267
ERROR - 2023-11-07 21:17:02 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-07 21:17:02 --> Config Class Initialized
INFO - 2023-11-07 21:17:02 --> Hooks Class Initialized
DEBUG - 2023-11-07 21:17:02 --> UTF-8 Support Enabled
INFO - 2023-11-07 21:17:02 --> Utf8 Class Initialized
INFO - 2023-11-07 21:17:02 --> URI Class Initialized
INFO - 2023-11-07 21:17:02 --> Router Class Initialized
INFO - 2023-11-07 21:17:02 --> Output Class Initialized
INFO - 2023-11-07 21:17:02 --> Security Class Initialized
DEBUG - 2023-11-07 21:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 21:17:02 --> Input Class Initialized
INFO - 2023-11-07 21:17:02 --> Language Class Initialized
INFO - 2023-11-07 21:17:02 --> Loader Class Initialized
INFO - 2023-11-07 21:17:02 --> Helper loaded: url_helper
INFO - 2023-11-07 21:17:02 --> Helper loaded: form_helper
INFO - 2023-11-07 21:17:02 --> Helper loaded: file_helper
INFO - 2023-11-07 21:17:02 --> Database Driver Class Initialized
DEBUG - 2023-11-07 21:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-07 21:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 21:17:02 --> Form Validation Class Initialized
INFO - 2023-11-07 21:17:02 --> Upload Class Initialized
INFO - 2023-11-07 21:17:02 --> Model "M_auth" initialized
INFO - 2023-11-07 21:17:02 --> Model "M_user" initialized
INFO - 2023-11-07 21:17:02 --> Model "M_produk" initialized
INFO - 2023-11-07 21:17:02 --> Controller Class Initialized
INFO - 2023-11-07 21:17:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-07 21:17:02 --> Final output sent to browser
DEBUG - 2023-11-07 21:17:02 --> Total execution time: 0.0352
ERROR - 2023-11-07 22:30:11 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-07 22:30:11 --> Config Class Initialized
INFO - 2023-11-07 22:30:11 --> Hooks Class Initialized
DEBUG - 2023-11-07 22:30:11 --> UTF-8 Support Enabled
INFO - 2023-11-07 22:30:11 --> Utf8 Class Initialized
INFO - 2023-11-07 22:30:11 --> URI Class Initialized
INFO - 2023-11-07 22:30:11 --> Router Class Initialized
INFO - 2023-11-07 22:30:11 --> Output Class Initialized
INFO - 2023-11-07 22:30:11 --> Security Class Initialized
DEBUG - 2023-11-07 22:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 22:30:11 --> Input Class Initialized
INFO - 2023-11-07 22:30:11 --> Language Class Initialized
INFO - 2023-11-07 22:30:11 --> Loader Class Initialized
INFO - 2023-11-07 22:30:11 --> Helper loaded: url_helper
INFO - 2023-11-07 22:30:11 --> Helper loaded: form_helper
INFO - 2023-11-07 22:30:11 --> Helper loaded: file_helper
INFO - 2023-11-07 22:30:11 --> Database Driver Class Initialized
DEBUG - 2023-11-07 22:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-07 22:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 22:30:11 --> Form Validation Class Initialized
INFO - 2023-11-07 22:30:11 --> Upload Class Initialized
INFO - 2023-11-07 22:30:11 --> Model "M_auth" initialized
INFO - 2023-11-07 22:30:11 --> Model "M_user" initialized
INFO - 2023-11-07 22:30:11 --> Model "M_produk" initialized
INFO - 2023-11-07 22:30:11 --> Controller Class Initialized
INFO - 2023-11-07 22:30:11 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-07 22:30:11 --> Final output sent to browser
DEBUG - 2023-11-07 22:30:11 --> Total execution time: 0.0339
ERROR - 2023-11-07 22:30:12 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-07 22:30:12 --> Config Class Initialized
INFO - 2023-11-07 22:30:12 --> Hooks Class Initialized
DEBUG - 2023-11-07 22:30:12 --> UTF-8 Support Enabled
INFO - 2023-11-07 22:30:12 --> Utf8 Class Initialized
INFO - 2023-11-07 22:30:12 --> URI Class Initialized
INFO - 2023-11-07 22:30:12 --> Router Class Initialized
INFO - 2023-11-07 22:30:12 --> Output Class Initialized
INFO - 2023-11-07 22:30:12 --> Security Class Initialized
DEBUG - 2023-11-07 22:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 22:30:12 --> Input Class Initialized
INFO - 2023-11-07 22:30:12 --> Language Class Initialized
INFO - 2023-11-07 22:30:12 --> Loader Class Initialized
INFO - 2023-11-07 22:30:12 --> Helper loaded: url_helper
INFO - 2023-11-07 22:30:12 --> Helper loaded: form_helper
INFO - 2023-11-07 22:30:12 --> Helper loaded: file_helper
INFO - 2023-11-07 22:30:12 --> Database Driver Class Initialized
DEBUG - 2023-11-07 22:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-07 22:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 22:30:12 --> Form Validation Class Initialized
INFO - 2023-11-07 22:30:12 --> Upload Class Initialized
INFO - 2023-11-07 22:30:12 --> Model "M_auth" initialized
INFO - 2023-11-07 22:30:12 --> Model "M_user" initialized
INFO - 2023-11-07 22:30:12 --> Model "M_produk" initialized
INFO - 2023-11-07 22:30:12 --> Controller Class Initialized
INFO - 2023-11-07 22:30:12 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-07 22:30:12 --> Final output sent to browser
DEBUG - 2023-11-07 22:30:12 --> Total execution time: 0.0025
ERROR - 2023-11-07 22:30:13 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-07 22:30:13 --> Config Class Initialized
INFO - 2023-11-07 22:30:13 --> Hooks Class Initialized
DEBUG - 2023-11-07 22:30:13 --> UTF-8 Support Enabled
INFO - 2023-11-07 22:30:13 --> Utf8 Class Initialized
INFO - 2023-11-07 22:30:13 --> URI Class Initialized
INFO - 2023-11-07 22:30:13 --> Router Class Initialized
INFO - 2023-11-07 22:30:13 --> Output Class Initialized
INFO - 2023-11-07 22:30:13 --> Security Class Initialized
DEBUG - 2023-11-07 22:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 22:30:13 --> Input Class Initialized
INFO - 2023-11-07 22:30:13 --> Language Class Initialized
INFO - 2023-11-07 22:30:13 --> Loader Class Initialized
INFO - 2023-11-07 22:30:13 --> Helper loaded: url_helper
INFO - 2023-11-07 22:30:13 --> Helper loaded: form_helper
INFO - 2023-11-07 22:30:13 --> Helper loaded: file_helper
INFO - 2023-11-07 22:30:13 --> Database Driver Class Initialized
DEBUG - 2023-11-07 22:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-07 22:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 22:30:13 --> Form Validation Class Initialized
INFO - 2023-11-07 22:30:13 --> Upload Class Initialized
INFO - 2023-11-07 22:30:13 --> Model "M_auth" initialized
INFO - 2023-11-07 22:30:13 --> Model "M_user" initialized
INFO - 2023-11-07 22:30:13 --> Model "M_produk" initialized
INFO - 2023-11-07 22:30:13 --> Controller Class Initialized
INFO - 2023-11-07 22:30:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-07 22:30:13 --> Final output sent to browser
DEBUG - 2023-11-07 22:30:13 --> Total execution time: 0.0027
ERROR - 2023-11-07 22:30:14 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-07 22:30:14 --> Config Class Initialized
INFO - 2023-11-07 22:30:14 --> Hooks Class Initialized
DEBUG - 2023-11-07 22:30:14 --> UTF-8 Support Enabled
INFO - 2023-11-07 22:30:14 --> Utf8 Class Initialized
INFO - 2023-11-07 22:30:14 --> URI Class Initialized
DEBUG - 2023-11-07 22:30:14 --> No URI present. Default controller set.
INFO - 2023-11-07 22:30:14 --> Router Class Initialized
INFO - 2023-11-07 22:30:14 --> Output Class Initialized
INFO - 2023-11-07 22:30:14 --> Security Class Initialized
DEBUG - 2023-11-07 22:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 22:30:14 --> Input Class Initialized
INFO - 2023-11-07 22:30:14 --> Language Class Initialized
INFO - 2023-11-07 22:30:14 --> Loader Class Initialized
INFO - 2023-11-07 22:30:14 --> Helper loaded: url_helper
INFO - 2023-11-07 22:30:14 --> Helper loaded: form_helper
INFO - 2023-11-07 22:30:14 --> Helper loaded: file_helper
INFO - 2023-11-07 22:30:14 --> Database Driver Class Initialized
DEBUG - 2023-11-07 22:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-07 22:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 22:30:14 --> Form Validation Class Initialized
INFO - 2023-11-07 22:30:14 --> Upload Class Initialized
INFO - 2023-11-07 22:30:14 --> Model "M_auth" initialized
INFO - 2023-11-07 22:30:14 --> Model "M_user" initialized
INFO - 2023-11-07 22:30:14 --> Model "M_produk" initialized
INFO - 2023-11-07 22:30:14 --> Controller Class Initialized
INFO - 2023-11-07 22:30:14 --> Model "M_pelanggan" initialized
INFO - 2023-11-07 22:30:14 --> Model "M_produk" initialized
DEBUG - 2023-11-07 22:30:14 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-07 22:30:14 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-07 22:30:14 --> Model "M_transaksi" initialized
INFO - 2023-11-07 22:30:14 --> Model "M_bank" initialized
INFO - 2023-11-07 22:30:14 --> Model "M_pesan" initialized
DEBUG - 2023-11-07 22:30:14 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-07 22:30:14 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-07 22:30:14 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-07 22:30:14 --> Final output sent to browser
DEBUG - 2023-11-07 22:30:14 --> Total execution time: 0.0113
ERROR - 2023-11-07 23:41:11 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-07 23:41:11 --> Config Class Initialized
INFO - 2023-11-07 23:41:11 --> Hooks Class Initialized
DEBUG - 2023-11-07 23:41:11 --> UTF-8 Support Enabled
INFO - 2023-11-07 23:41:11 --> Utf8 Class Initialized
INFO - 2023-11-07 23:41:11 --> URI Class Initialized
INFO - 2023-11-07 23:41:11 --> Router Class Initialized
INFO - 2023-11-07 23:41:11 --> Output Class Initialized
INFO - 2023-11-07 23:41:11 --> Security Class Initialized
DEBUG - 2023-11-07 23:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-07 23:41:11 --> Input Class Initialized
INFO - 2023-11-07 23:41:11 --> Language Class Initialized
INFO - 2023-11-07 23:41:11 --> Loader Class Initialized
INFO - 2023-11-07 23:41:11 --> Helper loaded: url_helper
INFO - 2023-11-07 23:41:11 --> Helper loaded: form_helper
INFO - 2023-11-07 23:41:11 --> Helper loaded: file_helper
INFO - 2023-11-07 23:41:11 --> Database Driver Class Initialized
DEBUG - 2023-11-07 23:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-07 23:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-07 23:41:11 --> Form Validation Class Initialized
INFO - 2023-11-07 23:41:11 --> Upload Class Initialized
INFO - 2023-11-07 23:41:11 --> Model "M_auth" initialized
INFO - 2023-11-07 23:41:11 --> Model "M_user" initialized
INFO - 2023-11-07 23:41:11 --> Model "M_produk" initialized
INFO - 2023-11-07 23:41:11 --> Controller Class Initialized
INFO - 2023-11-07 23:41:11 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-07 23:41:11 --> Final output sent to browser
DEBUG - 2023-11-07 23:41:11 --> Total execution time: 0.0296
