<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-19 16:27:38 --> Config Class Initialized
INFO - 2023-05-19 16:27:38 --> Hooks Class Initialized
DEBUG - 2023-05-19 16:27:39 --> UTF-8 Support Enabled
INFO - 2023-05-19 16:27:39 --> Utf8 Class Initialized
INFO - 2023-05-19 16:27:39 --> URI Class Initialized
DEBUG - 2023-05-19 16:27:39 --> No URI present. Default controller set.
INFO - 2023-05-19 16:27:39 --> Router Class Initialized
INFO - 2023-05-19 16:27:39 --> Output Class Initialized
INFO - 2023-05-19 16:27:39 --> Security Class Initialized
DEBUG - 2023-05-19 16:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 16:27:39 --> Input Class Initialized
INFO - 2023-05-19 16:27:39 --> Language Class Initialized
INFO - 2023-05-19 16:27:39 --> Loader Class Initialized
INFO - 2023-05-19 16:27:39 --> Helper loaded: url_helper
INFO - 2023-05-19 16:27:39 --> Helper loaded: form_helper
INFO - 2023-05-19 16:27:39 --> Helper loaded: file_helper
INFO - 2023-05-19 16:27:39 --> Database Driver Class Initialized
DEBUG - 2023-05-19 16:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 16:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 16:27:40 --> Form Validation Class Initialized
INFO - 2023-05-19 16:27:40 --> Upload Class Initialized
INFO - 2023-05-19 16:27:40 --> Model "M_auth" initialized
INFO - 2023-05-19 16:27:40 --> Model "M_user" initialized
INFO - 2023-05-19 16:27:40 --> Model "M_produk" initialized
INFO - 2023-05-19 16:27:40 --> Controller Class Initialized
INFO - 2023-05-19 16:27:40 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 16:27:40 --> Model "M_produk" initialized
DEBUG - 2023-05-19 16:27:40 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 16:27:40 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 16:27:40 --> Model "M_transaksi" initialized
INFO - 2023-05-19 16:27:40 --> Model "M_bank" initialized
INFO - 2023-05-19 16:27:40 --> Model "M_pesan" initialized
INFO - 2023-05-19 16:27:40 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-05-19 16:27:40 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-05-19 16:27:40 --> Final output sent to browser
DEBUG - 2023-05-19 16:27:40 --> Total execution time: 2.2385
INFO - 2023-05-19 16:51:15 --> Config Class Initialized
INFO - 2023-05-19 16:51:15 --> Hooks Class Initialized
DEBUG - 2023-05-19 16:51:15 --> UTF-8 Support Enabled
INFO - 2023-05-19 16:51:15 --> Utf8 Class Initialized
INFO - 2023-05-19 16:51:15 --> URI Class Initialized
DEBUG - 2023-05-19 16:51:15 --> No URI present. Default controller set.
INFO - 2023-05-19 16:51:15 --> Router Class Initialized
INFO - 2023-05-19 16:51:15 --> Output Class Initialized
INFO - 2023-05-19 16:51:15 --> Security Class Initialized
DEBUG - 2023-05-19 16:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 16:51:15 --> Input Class Initialized
INFO - 2023-05-19 16:51:15 --> Language Class Initialized
INFO - 2023-05-19 16:51:15 --> Loader Class Initialized
INFO - 2023-05-19 16:51:15 --> Helper loaded: url_helper
INFO - 2023-05-19 16:51:15 --> Helper loaded: form_helper
INFO - 2023-05-19 16:51:15 --> Helper loaded: file_helper
INFO - 2023-05-19 16:51:15 --> Database Driver Class Initialized
DEBUG - 2023-05-19 16:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 16:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 16:51:15 --> Form Validation Class Initialized
INFO - 2023-05-19 16:51:15 --> Upload Class Initialized
INFO - 2023-05-19 16:51:15 --> Model "M_auth" initialized
INFO - 2023-05-19 16:51:15 --> Model "M_user" initialized
INFO - 2023-05-19 16:51:15 --> Model "M_produk" initialized
INFO - 2023-05-19 16:51:15 --> Controller Class Initialized
INFO - 2023-05-19 16:51:15 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 16:51:15 --> Model "M_produk" initialized
DEBUG - 2023-05-19 16:51:15 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 16:51:15 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 16:51:15 --> Model "M_transaksi" initialized
INFO - 2023-05-19 16:51:15 --> Model "M_bank" initialized
INFO - 2023-05-19 16:51:15 --> Model "M_pesan" initialized
INFO - 2023-05-19 16:51:15 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-05-19 16:51:15 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-05-19 16:51:15 --> Final output sent to browser
DEBUG - 2023-05-19 16:51:15 --> Total execution time: 0.2756
INFO - 2023-05-19 16:51:25 --> Config Class Initialized
INFO - 2023-05-19 16:51:25 --> Hooks Class Initialized
DEBUG - 2023-05-19 16:51:25 --> UTF-8 Support Enabled
INFO - 2023-05-19 16:51:25 --> Utf8 Class Initialized
INFO - 2023-05-19 16:51:25 --> URI Class Initialized
DEBUG - 2023-05-19 16:51:25 --> No URI present. Default controller set.
INFO - 2023-05-19 16:51:25 --> Router Class Initialized
INFO - 2023-05-19 16:51:25 --> Output Class Initialized
INFO - 2023-05-19 16:51:25 --> Security Class Initialized
DEBUG - 2023-05-19 16:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 16:51:25 --> Input Class Initialized
INFO - 2023-05-19 16:51:25 --> Language Class Initialized
INFO - 2023-05-19 16:51:26 --> Loader Class Initialized
INFO - 2023-05-19 16:51:26 --> Helper loaded: url_helper
INFO - 2023-05-19 16:51:26 --> Helper loaded: form_helper
INFO - 2023-05-19 16:51:26 --> Helper loaded: file_helper
INFO - 2023-05-19 16:51:26 --> Database Driver Class Initialized
DEBUG - 2023-05-19 16:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 16:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 16:51:26 --> Form Validation Class Initialized
INFO - 2023-05-19 16:51:26 --> Upload Class Initialized
INFO - 2023-05-19 16:51:26 --> Model "M_auth" initialized
INFO - 2023-05-19 16:51:26 --> Model "M_user" initialized
INFO - 2023-05-19 16:51:26 --> Model "M_produk" initialized
INFO - 2023-05-19 16:51:26 --> Controller Class Initialized
INFO - 2023-05-19 16:51:26 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 16:51:26 --> Model "M_produk" initialized
DEBUG - 2023-05-19 16:51:26 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 16:51:26 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 16:51:26 --> Model "M_transaksi" initialized
INFO - 2023-05-19 16:51:26 --> Model "M_bank" initialized
INFO - 2023-05-19 16:51:26 --> Model "M_pesan" initialized
INFO - 2023-05-19 16:51:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-05-19 16:51:26 --> Email Class Initialized
INFO - 2023-05-19 16:51:28 --> Language file loaded: language/english/email_lang.php
INFO - 2023-05-19 16:51:33 --> Config Class Initialized
INFO - 2023-05-19 16:51:33 --> Hooks Class Initialized
DEBUG - 2023-05-19 16:51:33 --> UTF-8 Support Enabled
INFO - 2023-05-19 16:51:33 --> Utf8 Class Initialized
INFO - 2023-05-19 16:51:33 --> URI Class Initialized
DEBUG - 2023-05-19 16:51:33 --> No URI present. Default controller set.
INFO - 2023-05-19 16:51:33 --> Router Class Initialized
INFO - 2023-05-19 16:51:33 --> Output Class Initialized
INFO - 2023-05-19 16:51:33 --> Security Class Initialized
DEBUG - 2023-05-19 16:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 16:51:33 --> Input Class Initialized
INFO - 2023-05-19 16:51:33 --> Language Class Initialized
INFO - 2023-05-19 16:51:33 --> Loader Class Initialized
INFO - 2023-05-19 16:51:33 --> Helper loaded: url_helper
INFO - 2023-05-19 16:51:33 --> Helper loaded: form_helper
INFO - 2023-05-19 16:51:33 --> Helper loaded: file_helper
INFO - 2023-05-19 16:51:33 --> Database Driver Class Initialized
DEBUG - 2023-05-19 16:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 16:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 16:51:34 --> Form Validation Class Initialized
INFO - 2023-05-19 16:51:34 --> Upload Class Initialized
INFO - 2023-05-19 16:51:34 --> Model "M_auth" initialized
INFO - 2023-05-19 16:51:34 --> Model "M_user" initialized
INFO - 2023-05-19 16:51:34 --> Model "M_produk" initialized
INFO - 2023-05-19 16:51:34 --> Controller Class Initialized
INFO - 2023-05-19 16:51:34 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 16:51:34 --> Model "M_produk" initialized
DEBUG - 2023-05-19 16:51:34 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 16:51:34 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 16:51:34 --> Model "M_transaksi" initialized
INFO - 2023-05-19 16:51:34 --> Model "M_bank" initialized
INFO - 2023-05-19 16:51:34 --> Model "M_pesan" initialized
INFO - 2023-05-19 16:51:34 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-05-19 16:51:34 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-05-19 16:51:34 --> Final output sent to browser
DEBUG - 2023-05-19 16:51:34 --> Total execution time: 0.1729
INFO - 2023-05-19 16:52:25 --> Config Class Initialized
INFO - 2023-05-19 16:52:25 --> Hooks Class Initialized
DEBUG - 2023-05-19 16:52:25 --> UTF-8 Support Enabled
INFO - 2023-05-19 16:52:25 --> Utf8 Class Initialized
INFO - 2023-05-19 16:52:25 --> URI Class Initialized
INFO - 2023-05-19 16:52:25 --> Router Class Initialized
INFO - 2023-05-19 16:52:25 --> Output Class Initialized
INFO - 2023-05-19 16:52:25 --> Security Class Initialized
DEBUG - 2023-05-19 16:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 16:52:25 --> Input Class Initialized
INFO - 2023-05-19 16:52:25 --> Language Class Initialized
INFO - 2023-05-19 16:52:25 --> Loader Class Initialized
INFO - 2023-05-19 16:52:25 --> Helper loaded: url_helper
INFO - 2023-05-19 16:52:25 --> Helper loaded: form_helper
INFO - 2023-05-19 16:52:25 --> Helper loaded: file_helper
INFO - 2023-05-19 16:52:25 --> Database Driver Class Initialized
DEBUG - 2023-05-19 16:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 16:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 16:52:25 --> Form Validation Class Initialized
INFO - 2023-05-19 16:52:25 --> Upload Class Initialized
INFO - 2023-05-19 16:52:25 --> Model "M_auth" initialized
INFO - 2023-05-19 16:52:25 --> Model "M_user" initialized
INFO - 2023-05-19 16:52:25 --> Model "M_produk" initialized
INFO - 2023-05-19 16:52:25 --> Controller Class Initialized
INFO - 2023-05-19 16:52:25 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 16:52:25 --> Model "M_produk" initialized
DEBUG - 2023-05-19 16:52:25 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 16:52:25 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 16:52:25 --> Model "M_transaksi" initialized
INFO - 2023-05-19 16:52:25 --> Model "M_bank" initialized
INFO - 2023-05-19 16:52:25 --> Model "M_pesan" initialized
INFO - 2023-05-19 16:52:29 --> Email Class Initialized
INFO - 2023-05-19 16:52:31 --> Language file loaded: language/english/email_lang.php
INFO - 2023-05-19 16:52:37 --> Config Class Initialized
INFO - 2023-05-19 16:52:37 --> Hooks Class Initialized
DEBUG - 2023-05-19 16:52:37 --> UTF-8 Support Enabled
INFO - 2023-05-19 16:52:37 --> Utf8 Class Initialized
INFO - 2023-05-19 16:52:37 --> URI Class Initialized
DEBUG - 2023-05-19 16:52:37 --> No URI present. Default controller set.
INFO - 2023-05-19 16:52:37 --> Router Class Initialized
INFO - 2023-05-19 16:52:37 --> Output Class Initialized
INFO - 2023-05-19 16:52:37 --> Security Class Initialized
DEBUG - 2023-05-19 16:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 16:52:37 --> Input Class Initialized
INFO - 2023-05-19 16:52:37 --> Language Class Initialized
INFO - 2023-05-19 16:52:37 --> Loader Class Initialized
INFO - 2023-05-19 16:52:37 --> Helper loaded: url_helper
INFO - 2023-05-19 16:52:37 --> Helper loaded: form_helper
INFO - 2023-05-19 16:52:37 --> Helper loaded: file_helper
INFO - 2023-05-19 16:52:37 --> Database Driver Class Initialized
DEBUG - 2023-05-19 16:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 16:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 16:52:37 --> Form Validation Class Initialized
INFO - 2023-05-19 16:52:37 --> Upload Class Initialized
INFO - 2023-05-19 16:52:37 --> Model "M_auth" initialized
INFO - 2023-05-19 16:52:37 --> Model "M_user" initialized
INFO - 2023-05-19 16:52:37 --> Model "M_produk" initialized
INFO - 2023-05-19 16:52:37 --> Controller Class Initialized
INFO - 2023-05-19 16:52:37 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 16:52:37 --> Model "M_produk" initialized
DEBUG - 2023-05-19 16:52:37 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 16:52:37 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 16:52:37 --> Model "M_transaksi" initialized
INFO - 2023-05-19 16:52:37 --> Model "M_bank" initialized
INFO - 2023-05-19 16:52:37 --> Model "M_pesan" initialized
INFO - 2023-05-19 16:52:37 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-05-19 16:52:37 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-05-19 16:52:37 --> Final output sent to browser
DEBUG - 2023-05-19 16:52:37 --> Total execution time: 0.1553
INFO - 2023-05-19 16:53:09 --> Config Class Initialized
INFO - 2023-05-19 16:53:09 --> Hooks Class Initialized
DEBUG - 2023-05-19 16:53:09 --> UTF-8 Support Enabled
INFO - 2023-05-19 16:53:09 --> Utf8 Class Initialized
INFO - 2023-05-19 16:53:09 --> URI Class Initialized
INFO - 2023-05-19 16:53:09 --> Router Class Initialized
INFO - 2023-05-19 16:53:09 --> Output Class Initialized
INFO - 2023-05-19 16:53:09 --> Security Class Initialized
DEBUG - 2023-05-19 16:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 16:53:09 --> Input Class Initialized
INFO - 2023-05-19 16:53:09 --> Language Class Initialized
INFO - 2023-05-19 16:53:09 --> Loader Class Initialized
INFO - 2023-05-19 16:53:09 --> Helper loaded: url_helper
INFO - 2023-05-19 16:53:09 --> Helper loaded: form_helper
INFO - 2023-05-19 16:53:09 --> Helper loaded: file_helper
INFO - 2023-05-19 16:53:09 --> Database Driver Class Initialized
DEBUG - 2023-05-19 16:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 16:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 16:53:09 --> Form Validation Class Initialized
INFO - 2023-05-19 16:53:09 --> Upload Class Initialized
INFO - 2023-05-19 16:53:09 --> Model "M_auth" initialized
INFO - 2023-05-19 16:53:09 --> Model "M_user" initialized
INFO - 2023-05-19 16:53:09 --> Model "M_produk" initialized
INFO - 2023-05-19 16:53:09 --> Controller Class Initialized
INFO - 2023-05-19 16:53:09 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 16:53:09 --> Model "M_produk" initialized
DEBUG - 2023-05-19 16:53:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 16:53:09 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 16:53:09 --> Model "M_transaksi" initialized
INFO - 2023-05-19 16:53:09 --> Model "M_bank" initialized
INFO - 2023-05-19 16:53:09 --> Model "M_pesan" initialized
INFO - 2023-05-19 16:53:09 --> Config Class Initialized
INFO - 2023-05-19 16:53:09 --> Hooks Class Initialized
DEBUG - 2023-05-19 16:53:09 --> UTF-8 Support Enabled
INFO - 2023-05-19 16:53:09 --> Utf8 Class Initialized
INFO - 2023-05-19 16:53:09 --> URI Class Initialized
DEBUG - 2023-05-19 16:53:09 --> No URI present. Default controller set.
INFO - 2023-05-19 16:53:09 --> Router Class Initialized
INFO - 2023-05-19 16:53:09 --> Output Class Initialized
INFO - 2023-05-19 16:53:09 --> Security Class Initialized
DEBUG - 2023-05-19 16:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 16:53:09 --> Input Class Initialized
INFO - 2023-05-19 16:53:09 --> Language Class Initialized
INFO - 2023-05-19 16:53:09 --> Loader Class Initialized
INFO - 2023-05-19 16:53:09 --> Helper loaded: url_helper
INFO - 2023-05-19 16:53:09 --> Helper loaded: form_helper
INFO - 2023-05-19 16:53:09 --> Helper loaded: file_helper
INFO - 2023-05-19 16:53:09 --> Database Driver Class Initialized
DEBUG - 2023-05-19 16:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 16:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 16:53:09 --> Form Validation Class Initialized
INFO - 2023-05-19 16:53:09 --> Upload Class Initialized
INFO - 2023-05-19 16:53:09 --> Model "M_auth" initialized
INFO - 2023-05-19 16:53:09 --> Model "M_user" initialized
INFO - 2023-05-19 16:53:09 --> Model "M_produk" initialized
INFO - 2023-05-19 16:53:09 --> Controller Class Initialized
INFO - 2023-05-19 16:53:09 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 16:53:09 --> Model "M_produk" initialized
DEBUG - 2023-05-19 16:53:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 16:53:09 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 16:53:09 --> Model "M_transaksi" initialized
INFO - 2023-05-19 16:53:09 --> Model "M_bank" initialized
INFO - 2023-05-19 16:53:09 --> Model "M_pesan" initialized
INFO - 2023-05-19 16:53:09 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-05-19 16:53:09 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-05-19 16:53:09 --> Final output sent to browser
DEBUG - 2023-05-19 16:53:09 --> Total execution time: 0.2140
INFO - 2023-05-19 16:53:16 --> Config Class Initialized
INFO - 2023-05-19 16:53:16 --> Hooks Class Initialized
DEBUG - 2023-05-19 16:53:16 --> UTF-8 Support Enabled
INFO - 2023-05-19 16:53:16 --> Utf8 Class Initialized
INFO - 2023-05-19 16:53:16 --> URI Class Initialized
INFO - 2023-05-19 16:53:16 --> Router Class Initialized
INFO - 2023-05-19 16:53:16 --> Output Class Initialized
INFO - 2023-05-19 16:53:16 --> Security Class Initialized
DEBUG - 2023-05-19 16:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 16:53:16 --> Input Class Initialized
INFO - 2023-05-19 16:53:16 --> Language Class Initialized
INFO - 2023-05-19 16:53:16 --> Loader Class Initialized
INFO - 2023-05-19 16:53:16 --> Helper loaded: url_helper
INFO - 2023-05-19 16:53:16 --> Helper loaded: form_helper
INFO - 2023-05-19 16:53:16 --> Helper loaded: file_helper
INFO - 2023-05-19 16:53:16 --> Database Driver Class Initialized
DEBUG - 2023-05-19 16:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 16:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 16:53:16 --> Form Validation Class Initialized
INFO - 2023-05-19 16:53:16 --> Upload Class Initialized
INFO - 2023-05-19 16:53:16 --> Model "M_auth" initialized
INFO - 2023-05-19 16:53:16 --> Model "M_user" initialized
INFO - 2023-05-19 16:53:16 --> Model "M_produk" initialized
INFO - 2023-05-19 16:53:16 --> Controller Class Initialized
INFO - 2023-05-19 16:53:16 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-05-19 16:53:16 --> Final output sent to browser
DEBUG - 2023-05-19 16:53:16 --> Total execution time: 0.3657
INFO - 2023-05-19 16:53:27 --> Config Class Initialized
INFO - 2023-05-19 16:53:27 --> Hooks Class Initialized
DEBUG - 2023-05-19 16:53:27 --> UTF-8 Support Enabled
INFO - 2023-05-19 16:53:27 --> Utf8 Class Initialized
INFO - 2023-05-19 16:53:27 --> URI Class Initialized
INFO - 2023-05-19 16:53:27 --> Router Class Initialized
INFO - 2023-05-19 16:53:27 --> Output Class Initialized
INFO - 2023-05-19 16:53:27 --> Security Class Initialized
DEBUG - 2023-05-19 16:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 16:53:27 --> Input Class Initialized
INFO - 2023-05-19 16:53:27 --> Language Class Initialized
INFO - 2023-05-19 16:53:27 --> Loader Class Initialized
INFO - 2023-05-19 16:53:27 --> Helper loaded: url_helper
INFO - 2023-05-19 16:53:27 --> Helper loaded: form_helper
INFO - 2023-05-19 16:53:27 --> Helper loaded: file_helper
INFO - 2023-05-19 16:53:27 --> Database Driver Class Initialized
DEBUG - 2023-05-19 16:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 16:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 16:53:27 --> Form Validation Class Initialized
INFO - 2023-05-19 16:53:27 --> Upload Class Initialized
INFO - 2023-05-19 16:53:27 --> Model "M_auth" initialized
INFO - 2023-05-19 16:53:27 --> Model "M_user" initialized
INFO - 2023-05-19 16:53:27 --> Model "M_produk" initialized
INFO - 2023-05-19 16:53:27 --> Controller Class Initialized
INFO - 2023-05-19 16:53:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-05-19 16:53:27 --> Config Class Initialized
INFO - 2023-05-19 16:53:27 --> Hooks Class Initialized
DEBUG - 2023-05-19 16:53:27 --> UTF-8 Support Enabled
INFO - 2023-05-19 16:53:27 --> Utf8 Class Initialized
INFO - 2023-05-19 16:53:27 --> URI Class Initialized
INFO - 2023-05-19 16:53:27 --> Router Class Initialized
INFO - 2023-05-19 16:53:27 --> Output Class Initialized
INFO - 2023-05-19 16:53:27 --> Security Class Initialized
DEBUG - 2023-05-19 16:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 16:53:27 --> Input Class Initialized
INFO - 2023-05-19 16:53:27 --> Language Class Initialized
INFO - 2023-05-19 16:53:28 --> Loader Class Initialized
INFO - 2023-05-19 16:53:28 --> Helper loaded: url_helper
INFO - 2023-05-19 16:53:28 --> Helper loaded: form_helper
INFO - 2023-05-19 16:53:28 --> Helper loaded: file_helper
INFO - 2023-05-19 16:53:28 --> Database Driver Class Initialized
DEBUG - 2023-05-19 16:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 16:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 16:53:28 --> Form Validation Class Initialized
INFO - 2023-05-19 16:53:28 --> Upload Class Initialized
INFO - 2023-05-19 16:53:28 --> Model "M_auth" initialized
INFO - 2023-05-19 16:53:28 --> Model "M_user" initialized
INFO - 2023-05-19 16:53:28 --> Model "M_produk" initialized
INFO - 2023-05-19 16:53:28 --> Controller Class Initialized
INFO - 2023-05-19 16:53:28 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-05-19 16:53:28 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 16:53:28 --> Final output sent to browser
DEBUG - 2023-05-19 16:53:28 --> Total execution time: 0.3196
INFO - 2023-05-19 16:53:32 --> Config Class Initialized
INFO - 2023-05-19 16:53:32 --> Hooks Class Initialized
DEBUG - 2023-05-19 16:53:32 --> UTF-8 Support Enabled
INFO - 2023-05-19 16:53:32 --> Utf8 Class Initialized
INFO - 2023-05-19 16:53:32 --> URI Class Initialized
INFO - 2023-05-19 16:53:32 --> Router Class Initialized
INFO - 2023-05-19 16:53:32 --> Output Class Initialized
INFO - 2023-05-19 16:53:32 --> Security Class Initialized
DEBUG - 2023-05-19 16:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 16:53:32 --> Input Class Initialized
INFO - 2023-05-19 16:53:32 --> Language Class Initialized
INFO - 2023-05-19 16:53:32 --> Loader Class Initialized
INFO - 2023-05-19 16:53:32 --> Helper loaded: url_helper
INFO - 2023-05-19 16:53:32 --> Helper loaded: form_helper
INFO - 2023-05-19 16:53:32 --> Helper loaded: file_helper
INFO - 2023-05-19 16:53:32 --> Database Driver Class Initialized
DEBUG - 2023-05-19 16:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 16:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 16:53:32 --> Form Validation Class Initialized
INFO - 2023-05-19 16:53:32 --> Upload Class Initialized
INFO - 2023-05-19 16:53:32 --> Model "M_auth" initialized
INFO - 2023-05-19 16:53:32 --> Model "M_user" initialized
INFO - 2023-05-19 16:53:32 --> Model "M_produk" initialized
INFO - 2023-05-19 16:53:32 --> Controller Class Initialized
INFO - 2023-05-19 16:53:32 --> Model "M_pesan" initialized
INFO - 2023-05-19 16:53:32 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_pengaduan.php
INFO - 2023-05-19 16:53:32 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 16:53:32 --> Final output sent to browser
DEBUG - 2023-05-19 16:53:32 --> Total execution time: 0.2292
INFO - 2023-05-19 16:54:29 --> Config Class Initialized
INFO - 2023-05-19 16:54:29 --> Hooks Class Initialized
DEBUG - 2023-05-19 16:54:29 --> UTF-8 Support Enabled
INFO - 2023-05-19 16:54:29 --> Utf8 Class Initialized
INFO - 2023-05-19 16:54:29 --> URI Class Initialized
INFO - 2023-05-19 16:54:29 --> Router Class Initialized
INFO - 2023-05-19 16:54:29 --> Output Class Initialized
INFO - 2023-05-19 16:54:29 --> Security Class Initialized
DEBUG - 2023-05-19 16:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 16:54:29 --> Input Class Initialized
INFO - 2023-05-19 16:54:29 --> Language Class Initialized
INFO - 2023-05-19 16:54:29 --> Loader Class Initialized
INFO - 2023-05-19 16:54:29 --> Helper loaded: url_helper
INFO - 2023-05-19 16:54:29 --> Helper loaded: form_helper
INFO - 2023-05-19 16:54:29 --> Helper loaded: file_helper
INFO - 2023-05-19 16:54:29 --> Database Driver Class Initialized
DEBUG - 2023-05-19 16:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 16:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 16:54:29 --> Form Validation Class Initialized
INFO - 2023-05-19 16:54:29 --> Upload Class Initialized
INFO - 2023-05-19 16:54:29 --> Model "M_auth" initialized
INFO - 2023-05-19 16:54:29 --> Model "M_user" initialized
INFO - 2023-05-19 16:54:29 --> Model "M_produk" initialized
INFO - 2023-05-19 16:54:29 --> Controller Class Initialized
INFO - 2023-05-19 16:54:30 --> Config Class Initialized
INFO - 2023-05-19 16:54:30 --> Hooks Class Initialized
DEBUG - 2023-05-19 16:54:30 --> UTF-8 Support Enabled
INFO - 2023-05-19 16:54:30 --> Utf8 Class Initialized
INFO - 2023-05-19 16:54:30 --> URI Class Initialized
INFO - 2023-05-19 16:54:30 --> Router Class Initialized
INFO - 2023-05-19 16:54:30 --> Output Class Initialized
INFO - 2023-05-19 16:54:30 --> Security Class Initialized
DEBUG - 2023-05-19 16:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 16:54:30 --> Input Class Initialized
INFO - 2023-05-19 16:54:30 --> Language Class Initialized
INFO - 2023-05-19 16:54:30 --> Loader Class Initialized
INFO - 2023-05-19 16:54:30 --> Helper loaded: url_helper
INFO - 2023-05-19 16:54:30 --> Helper loaded: form_helper
INFO - 2023-05-19 16:54:30 --> Helper loaded: file_helper
INFO - 2023-05-19 16:54:30 --> Database Driver Class Initialized
DEBUG - 2023-05-19 16:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 16:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 16:54:30 --> Form Validation Class Initialized
INFO - 2023-05-19 16:54:30 --> Upload Class Initialized
INFO - 2023-05-19 16:54:30 --> Model "M_auth" initialized
INFO - 2023-05-19 16:54:30 --> Model "M_user" initialized
INFO - 2023-05-19 16:54:30 --> Model "M_produk" initialized
INFO - 2023-05-19 16:54:30 --> Controller Class Initialized
INFO - 2023-05-19 16:54:30 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-05-19 16:54:30 --> Final output sent to browser
DEBUG - 2023-05-19 16:54:30 --> Total execution time: 0.1512
INFO - 2023-05-19 16:54:34 --> Config Class Initialized
INFO - 2023-05-19 16:54:34 --> Hooks Class Initialized
DEBUG - 2023-05-19 16:54:34 --> UTF-8 Support Enabled
INFO - 2023-05-19 16:54:34 --> Utf8 Class Initialized
INFO - 2023-05-19 16:54:34 --> URI Class Initialized
DEBUG - 2023-05-19 16:54:34 --> No URI present. Default controller set.
INFO - 2023-05-19 16:54:34 --> Router Class Initialized
INFO - 2023-05-19 16:54:34 --> Output Class Initialized
INFO - 2023-05-19 16:54:34 --> Security Class Initialized
DEBUG - 2023-05-19 16:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 16:54:34 --> Input Class Initialized
INFO - 2023-05-19 16:54:34 --> Language Class Initialized
INFO - 2023-05-19 16:54:34 --> Loader Class Initialized
INFO - 2023-05-19 16:54:34 --> Helper loaded: url_helper
INFO - 2023-05-19 16:54:34 --> Helper loaded: form_helper
INFO - 2023-05-19 16:54:34 --> Helper loaded: file_helper
INFO - 2023-05-19 16:54:34 --> Database Driver Class Initialized
DEBUG - 2023-05-19 16:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 16:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 16:54:34 --> Form Validation Class Initialized
INFO - 2023-05-19 16:54:34 --> Upload Class Initialized
INFO - 2023-05-19 16:54:34 --> Model "M_auth" initialized
INFO - 2023-05-19 16:54:34 --> Model "M_user" initialized
INFO - 2023-05-19 16:54:34 --> Model "M_produk" initialized
INFO - 2023-05-19 16:54:34 --> Controller Class Initialized
INFO - 2023-05-19 16:54:34 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 16:54:34 --> Model "M_produk" initialized
DEBUG - 2023-05-19 16:54:34 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 16:54:34 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 16:54:34 --> Model "M_transaksi" initialized
INFO - 2023-05-19 16:54:34 --> Model "M_bank" initialized
INFO - 2023-05-19 16:54:34 --> Model "M_pesan" initialized
INFO - 2023-05-19 16:54:34 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-05-19 16:54:34 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-05-19 16:54:34 --> Final output sent to browser
DEBUG - 2023-05-19 16:54:34 --> Total execution time: 0.1716
INFO - 2023-05-19 16:54:57 --> Config Class Initialized
INFO - 2023-05-19 16:54:57 --> Hooks Class Initialized
DEBUG - 2023-05-19 16:54:57 --> UTF-8 Support Enabled
INFO - 2023-05-19 16:54:57 --> Utf8 Class Initialized
INFO - 2023-05-19 16:54:57 --> URI Class Initialized
INFO - 2023-05-19 16:54:57 --> Router Class Initialized
INFO - 2023-05-19 16:54:57 --> Output Class Initialized
INFO - 2023-05-19 16:54:57 --> Security Class Initialized
DEBUG - 2023-05-19 16:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 16:54:57 --> Input Class Initialized
INFO - 2023-05-19 16:54:57 --> Language Class Initialized
INFO - 2023-05-19 16:54:57 --> Loader Class Initialized
INFO - 2023-05-19 16:54:57 --> Helper loaded: url_helper
INFO - 2023-05-19 16:54:57 --> Helper loaded: form_helper
INFO - 2023-05-19 16:54:57 --> Helper loaded: file_helper
INFO - 2023-05-19 16:54:57 --> Database Driver Class Initialized
DEBUG - 2023-05-19 16:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 16:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 16:54:57 --> Form Validation Class Initialized
INFO - 2023-05-19 16:54:57 --> Upload Class Initialized
INFO - 2023-05-19 16:54:57 --> Model "M_auth" initialized
INFO - 2023-05-19 16:54:57 --> Model "M_user" initialized
INFO - 2023-05-19 16:54:57 --> Model "M_produk" initialized
INFO - 2023-05-19 16:54:57 --> Controller Class Initialized
INFO - 2023-05-19 16:54:57 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 16:54:57 --> Model "M_produk" initialized
DEBUG - 2023-05-19 16:54:57 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 16:54:57 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 16:54:57 --> Model "M_transaksi" initialized
INFO - 2023-05-19 16:54:57 --> Model "M_bank" initialized
INFO - 2023-05-19 16:54:57 --> Model "M_pesan" initialized
INFO - 2023-05-19 16:54:57 --> Email Class Initialized
INFO - 2023-05-19 16:54:59 --> Language file loaded: language/english/email_lang.php
INFO - 2023-05-19 16:55:02 --> Config Class Initialized
INFO - 2023-05-19 16:55:02 --> Hooks Class Initialized
DEBUG - 2023-05-19 16:55:02 --> UTF-8 Support Enabled
INFO - 2023-05-19 16:55:02 --> Utf8 Class Initialized
INFO - 2023-05-19 16:55:02 --> URI Class Initialized
DEBUG - 2023-05-19 16:55:02 --> No URI present. Default controller set.
INFO - 2023-05-19 16:55:02 --> Router Class Initialized
INFO - 2023-05-19 16:55:02 --> Output Class Initialized
INFO - 2023-05-19 16:55:02 --> Security Class Initialized
DEBUG - 2023-05-19 16:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 16:55:02 --> Input Class Initialized
INFO - 2023-05-19 16:55:02 --> Language Class Initialized
INFO - 2023-05-19 16:55:02 --> Loader Class Initialized
INFO - 2023-05-19 16:55:02 --> Helper loaded: url_helper
INFO - 2023-05-19 16:55:02 --> Helper loaded: form_helper
INFO - 2023-05-19 16:55:02 --> Helper loaded: file_helper
INFO - 2023-05-19 16:55:02 --> Database Driver Class Initialized
DEBUG - 2023-05-19 16:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 16:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 16:55:02 --> Form Validation Class Initialized
INFO - 2023-05-19 16:55:02 --> Upload Class Initialized
INFO - 2023-05-19 16:55:02 --> Model "M_auth" initialized
INFO - 2023-05-19 16:55:02 --> Model "M_user" initialized
INFO - 2023-05-19 16:55:02 --> Model "M_produk" initialized
INFO - 2023-05-19 16:55:02 --> Controller Class Initialized
INFO - 2023-05-19 16:55:02 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 16:55:02 --> Model "M_produk" initialized
DEBUG - 2023-05-19 16:55:02 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 16:55:02 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 16:55:02 --> Model "M_transaksi" initialized
INFO - 2023-05-19 16:55:02 --> Model "M_bank" initialized
INFO - 2023-05-19 16:55:02 --> Model "M_pesan" initialized
INFO - 2023-05-19 16:55:02 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-05-19 16:55:02 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-05-19 16:55:02 --> Final output sent to browser
DEBUG - 2023-05-19 16:55:02 --> Total execution time: 0.1752
INFO - 2023-05-19 16:56:02 --> Config Class Initialized
INFO - 2023-05-19 16:56:02 --> Hooks Class Initialized
DEBUG - 2023-05-19 16:56:02 --> UTF-8 Support Enabled
INFO - 2023-05-19 16:56:02 --> Utf8 Class Initialized
INFO - 2023-05-19 16:56:02 --> URI Class Initialized
INFO - 2023-05-19 16:56:02 --> Router Class Initialized
INFO - 2023-05-19 16:56:02 --> Output Class Initialized
INFO - 2023-05-19 16:56:02 --> Security Class Initialized
DEBUG - 2023-05-19 16:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 16:56:02 --> Input Class Initialized
INFO - 2023-05-19 16:56:02 --> Language Class Initialized
INFO - 2023-05-19 16:56:02 --> Loader Class Initialized
INFO - 2023-05-19 16:56:02 --> Helper loaded: url_helper
INFO - 2023-05-19 16:56:02 --> Helper loaded: form_helper
INFO - 2023-05-19 16:56:02 --> Helper loaded: file_helper
INFO - 2023-05-19 16:56:02 --> Database Driver Class Initialized
DEBUG - 2023-05-19 16:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 16:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 16:56:02 --> Form Validation Class Initialized
INFO - 2023-05-19 16:56:02 --> Upload Class Initialized
INFO - 2023-05-19 16:56:02 --> Model "M_auth" initialized
INFO - 2023-05-19 16:56:02 --> Model "M_user" initialized
INFO - 2023-05-19 16:56:02 --> Model "M_produk" initialized
INFO - 2023-05-19 16:56:02 --> Controller Class Initialized
INFO - 2023-05-19 16:56:02 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-05-19 16:56:02 --> Final output sent to browser
DEBUG - 2023-05-19 16:56:02 --> Total execution time: 0.1877
INFO - 2023-05-19 16:56:09 --> Config Class Initialized
INFO - 2023-05-19 16:56:09 --> Hooks Class Initialized
DEBUG - 2023-05-19 16:56:09 --> UTF-8 Support Enabled
INFO - 2023-05-19 16:56:09 --> Utf8 Class Initialized
INFO - 2023-05-19 16:56:09 --> URI Class Initialized
INFO - 2023-05-19 16:56:09 --> Router Class Initialized
INFO - 2023-05-19 16:56:09 --> Output Class Initialized
INFO - 2023-05-19 16:56:09 --> Security Class Initialized
DEBUG - 2023-05-19 16:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 16:56:09 --> Input Class Initialized
INFO - 2023-05-19 16:56:09 --> Language Class Initialized
INFO - 2023-05-19 16:56:09 --> Loader Class Initialized
INFO - 2023-05-19 16:56:09 --> Helper loaded: url_helper
INFO - 2023-05-19 16:56:09 --> Helper loaded: form_helper
INFO - 2023-05-19 16:56:10 --> Helper loaded: file_helper
INFO - 2023-05-19 16:56:10 --> Database Driver Class Initialized
DEBUG - 2023-05-19 16:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 16:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 16:56:10 --> Form Validation Class Initialized
INFO - 2023-05-19 16:56:10 --> Upload Class Initialized
INFO - 2023-05-19 16:56:10 --> Model "M_auth" initialized
INFO - 2023-05-19 16:56:10 --> Model "M_user" initialized
INFO - 2023-05-19 16:56:10 --> Model "M_produk" initialized
INFO - 2023-05-19 16:56:10 --> Controller Class Initialized
INFO - 2023-05-19 16:56:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-05-19 16:56:10 --> Config Class Initialized
INFO - 2023-05-19 16:56:10 --> Hooks Class Initialized
DEBUG - 2023-05-19 16:56:10 --> UTF-8 Support Enabled
INFO - 2023-05-19 16:56:10 --> Utf8 Class Initialized
INFO - 2023-05-19 16:56:10 --> URI Class Initialized
INFO - 2023-05-19 16:56:10 --> Router Class Initialized
INFO - 2023-05-19 16:56:10 --> Output Class Initialized
INFO - 2023-05-19 16:56:10 --> Security Class Initialized
DEBUG - 2023-05-19 16:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 16:56:10 --> Input Class Initialized
INFO - 2023-05-19 16:56:10 --> Language Class Initialized
INFO - 2023-05-19 16:56:10 --> Loader Class Initialized
INFO - 2023-05-19 16:56:10 --> Helper loaded: url_helper
INFO - 2023-05-19 16:56:10 --> Helper loaded: form_helper
INFO - 2023-05-19 16:56:10 --> Helper loaded: file_helper
INFO - 2023-05-19 16:56:10 --> Database Driver Class Initialized
DEBUG - 2023-05-19 16:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 16:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 16:56:10 --> Form Validation Class Initialized
INFO - 2023-05-19 16:56:10 --> Upload Class Initialized
INFO - 2023-05-19 16:56:10 --> Model "M_auth" initialized
INFO - 2023-05-19 16:56:10 --> Model "M_user" initialized
INFO - 2023-05-19 16:56:10 --> Model "M_produk" initialized
INFO - 2023-05-19 16:56:10 --> Controller Class Initialized
INFO - 2023-05-19 16:56:10 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-05-19 16:56:10 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 16:56:10 --> Final output sent to browser
DEBUG - 2023-05-19 16:56:10 --> Total execution time: 0.1676
INFO - 2023-05-19 16:56:16 --> Config Class Initialized
INFO - 2023-05-19 16:56:16 --> Hooks Class Initialized
DEBUG - 2023-05-19 16:56:16 --> UTF-8 Support Enabled
INFO - 2023-05-19 16:56:16 --> Utf8 Class Initialized
INFO - 2023-05-19 16:56:16 --> URI Class Initialized
INFO - 2023-05-19 16:56:16 --> Router Class Initialized
INFO - 2023-05-19 16:56:16 --> Output Class Initialized
INFO - 2023-05-19 16:56:16 --> Security Class Initialized
DEBUG - 2023-05-19 16:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 16:56:16 --> Input Class Initialized
INFO - 2023-05-19 16:56:16 --> Language Class Initialized
INFO - 2023-05-19 16:56:16 --> Loader Class Initialized
INFO - 2023-05-19 16:56:16 --> Helper loaded: url_helper
INFO - 2023-05-19 16:56:16 --> Helper loaded: form_helper
INFO - 2023-05-19 16:56:16 --> Helper loaded: file_helper
INFO - 2023-05-19 16:56:16 --> Database Driver Class Initialized
DEBUG - 2023-05-19 16:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 16:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 16:56:16 --> Form Validation Class Initialized
INFO - 2023-05-19 16:56:16 --> Upload Class Initialized
INFO - 2023-05-19 16:56:16 --> Model "M_auth" initialized
INFO - 2023-05-19 16:56:16 --> Model "M_user" initialized
INFO - 2023-05-19 16:56:16 --> Model "M_produk" initialized
INFO - 2023-05-19 16:56:16 --> Controller Class Initialized
INFO - 2023-05-19 16:56:16 --> Model "M_pesan" initialized
INFO - 2023-05-19 16:56:16 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_pengaduan.php
INFO - 2023-05-19 16:56:16 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 16:56:16 --> Final output sent to browser
DEBUG - 2023-05-19 16:56:16 --> Total execution time: 0.1526
INFO - 2023-05-19 16:57:00 --> Config Class Initialized
INFO - 2023-05-19 16:57:00 --> Hooks Class Initialized
DEBUG - 2023-05-19 16:57:00 --> UTF-8 Support Enabled
INFO - 2023-05-19 16:57:00 --> Utf8 Class Initialized
INFO - 2023-05-19 16:57:00 --> URI Class Initialized
INFO - 2023-05-19 16:57:00 --> Router Class Initialized
INFO - 2023-05-19 16:57:00 --> Output Class Initialized
INFO - 2023-05-19 16:57:00 --> Security Class Initialized
DEBUG - 2023-05-19 16:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 16:57:00 --> Input Class Initialized
INFO - 2023-05-19 16:57:00 --> Language Class Initialized
INFO - 2023-05-19 16:57:00 --> Loader Class Initialized
INFO - 2023-05-19 16:57:00 --> Helper loaded: url_helper
INFO - 2023-05-19 16:57:00 --> Helper loaded: form_helper
INFO - 2023-05-19 16:57:00 --> Helper loaded: file_helper
INFO - 2023-05-19 16:57:00 --> Database Driver Class Initialized
DEBUG - 2023-05-19 16:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 16:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 16:57:00 --> Form Validation Class Initialized
INFO - 2023-05-19 16:57:00 --> Upload Class Initialized
INFO - 2023-05-19 16:57:00 --> Model "M_auth" initialized
INFO - 2023-05-19 16:57:00 --> Model "M_user" initialized
INFO - 2023-05-19 16:57:00 --> Model "M_produk" initialized
INFO - 2023-05-19 16:57:00 --> Controller Class Initialized
INFO - 2023-05-19 16:57:00 --> Config Class Initialized
INFO - 2023-05-19 16:57:00 --> Hooks Class Initialized
DEBUG - 2023-05-19 16:57:00 --> UTF-8 Support Enabled
INFO - 2023-05-19 16:57:00 --> Utf8 Class Initialized
INFO - 2023-05-19 16:57:00 --> URI Class Initialized
INFO - 2023-05-19 16:57:00 --> Router Class Initialized
INFO - 2023-05-19 16:57:00 --> Output Class Initialized
INFO - 2023-05-19 16:57:00 --> Security Class Initialized
DEBUG - 2023-05-19 16:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 16:57:00 --> Input Class Initialized
INFO - 2023-05-19 16:57:00 --> Language Class Initialized
INFO - 2023-05-19 16:57:00 --> Loader Class Initialized
INFO - 2023-05-19 16:57:00 --> Helper loaded: url_helper
INFO - 2023-05-19 16:57:00 --> Helper loaded: form_helper
INFO - 2023-05-19 16:57:00 --> Helper loaded: file_helper
INFO - 2023-05-19 16:57:01 --> Database Driver Class Initialized
DEBUG - 2023-05-19 16:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 16:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 16:57:01 --> Form Validation Class Initialized
INFO - 2023-05-19 16:57:01 --> Upload Class Initialized
INFO - 2023-05-19 16:57:01 --> Model "M_auth" initialized
INFO - 2023-05-19 16:57:01 --> Model "M_user" initialized
INFO - 2023-05-19 16:57:01 --> Model "M_produk" initialized
INFO - 2023-05-19 16:57:01 --> Controller Class Initialized
INFO - 2023-05-19 16:57:01 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-05-19 16:57:01 --> Final output sent to browser
DEBUG - 2023-05-19 16:57:01 --> Total execution time: 0.1139
INFO - 2023-05-19 16:57:07 --> Config Class Initialized
INFO - 2023-05-19 16:57:07 --> Hooks Class Initialized
DEBUG - 2023-05-19 16:57:07 --> UTF-8 Support Enabled
INFO - 2023-05-19 16:57:07 --> Utf8 Class Initialized
INFO - 2023-05-19 16:57:07 --> URI Class Initialized
DEBUG - 2023-05-19 16:57:07 --> No URI present. Default controller set.
INFO - 2023-05-19 16:57:07 --> Router Class Initialized
INFO - 2023-05-19 16:57:07 --> Output Class Initialized
INFO - 2023-05-19 16:57:07 --> Security Class Initialized
DEBUG - 2023-05-19 16:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 16:57:07 --> Input Class Initialized
INFO - 2023-05-19 16:57:07 --> Language Class Initialized
INFO - 2023-05-19 16:57:07 --> Loader Class Initialized
INFO - 2023-05-19 16:57:07 --> Helper loaded: url_helper
INFO - 2023-05-19 16:57:07 --> Helper loaded: form_helper
INFO - 2023-05-19 16:57:07 --> Helper loaded: file_helper
INFO - 2023-05-19 16:57:07 --> Database Driver Class Initialized
DEBUG - 2023-05-19 16:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 16:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 16:57:07 --> Form Validation Class Initialized
INFO - 2023-05-19 16:57:07 --> Upload Class Initialized
INFO - 2023-05-19 16:57:07 --> Model "M_auth" initialized
INFO - 2023-05-19 16:57:07 --> Model "M_user" initialized
INFO - 2023-05-19 16:57:07 --> Model "M_produk" initialized
INFO - 2023-05-19 16:57:07 --> Controller Class Initialized
INFO - 2023-05-19 16:57:07 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 16:57:07 --> Model "M_produk" initialized
DEBUG - 2023-05-19 16:57:07 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 16:57:07 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 16:57:07 --> Model "M_transaksi" initialized
INFO - 2023-05-19 16:57:07 --> Model "M_bank" initialized
INFO - 2023-05-19 16:57:07 --> Model "M_pesan" initialized
INFO - 2023-05-19 16:57:07 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-05-19 16:57:07 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-05-19 16:57:07 --> Final output sent to browser
DEBUG - 2023-05-19 16:57:07 --> Total execution time: 0.1742
INFO - 2023-05-19 16:57:20 --> Config Class Initialized
INFO - 2023-05-19 16:57:20 --> Hooks Class Initialized
DEBUG - 2023-05-19 16:57:20 --> UTF-8 Support Enabled
INFO - 2023-05-19 16:57:20 --> Utf8 Class Initialized
INFO - 2023-05-19 16:57:20 --> URI Class Initialized
INFO - 2023-05-19 16:57:20 --> Router Class Initialized
INFO - 2023-05-19 16:57:20 --> Output Class Initialized
INFO - 2023-05-19 16:57:20 --> Security Class Initialized
DEBUG - 2023-05-19 16:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 16:57:20 --> Input Class Initialized
INFO - 2023-05-19 16:57:20 --> Language Class Initialized
INFO - 2023-05-19 16:57:20 --> Loader Class Initialized
INFO - 2023-05-19 16:57:20 --> Helper loaded: url_helper
INFO - 2023-05-19 16:57:20 --> Helper loaded: form_helper
INFO - 2023-05-19 16:57:20 --> Helper loaded: file_helper
INFO - 2023-05-19 16:57:20 --> Database Driver Class Initialized
DEBUG - 2023-05-19 16:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 16:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 16:57:20 --> Form Validation Class Initialized
INFO - 2023-05-19 16:57:20 --> Upload Class Initialized
INFO - 2023-05-19 16:57:20 --> Model "M_auth" initialized
INFO - 2023-05-19 16:57:20 --> Model "M_user" initialized
INFO - 2023-05-19 16:57:20 --> Model "M_produk" initialized
INFO - 2023-05-19 16:57:20 --> Controller Class Initialized
INFO - 2023-05-19 16:57:20 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 16:57:20 --> Model "M_produk" initialized
DEBUG - 2023-05-19 16:57:20 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 16:57:20 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 16:57:20 --> Model "M_transaksi" initialized
INFO - 2023-05-19 16:57:20 --> Model "M_bank" initialized
INFO - 2023-05-19 16:57:20 --> Model "M_pesan" initialized
INFO - 2023-05-19 16:57:20 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-05-19 16:57:20 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/v_produk_detail.php
INFO - 2023-05-19 16:57:20 --> Final output sent to browser
DEBUG - 2023-05-19 16:57:20 --> Total execution time: 0.3655
INFO - 2023-05-19 16:57:48 --> Config Class Initialized
INFO - 2023-05-19 16:57:48 --> Hooks Class Initialized
DEBUG - 2023-05-19 16:57:49 --> UTF-8 Support Enabled
INFO - 2023-05-19 16:57:49 --> Utf8 Class Initialized
INFO - 2023-05-19 16:57:49 --> URI Class Initialized
DEBUG - 2023-05-19 16:57:49 --> No URI present. Default controller set.
INFO - 2023-05-19 16:57:49 --> Router Class Initialized
INFO - 2023-05-19 16:57:49 --> Output Class Initialized
INFO - 2023-05-19 16:57:49 --> Security Class Initialized
DEBUG - 2023-05-19 16:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 16:57:49 --> Input Class Initialized
INFO - 2023-05-19 16:57:49 --> Language Class Initialized
INFO - 2023-05-19 16:57:49 --> Loader Class Initialized
INFO - 2023-05-19 16:57:49 --> Helper loaded: url_helper
INFO - 2023-05-19 16:57:49 --> Helper loaded: form_helper
INFO - 2023-05-19 16:57:49 --> Helper loaded: file_helper
INFO - 2023-05-19 16:57:49 --> Database Driver Class Initialized
DEBUG - 2023-05-19 16:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 16:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 16:57:49 --> Form Validation Class Initialized
INFO - 2023-05-19 16:57:49 --> Upload Class Initialized
INFO - 2023-05-19 16:57:49 --> Model "M_auth" initialized
INFO - 2023-05-19 16:57:49 --> Model "M_user" initialized
INFO - 2023-05-19 16:57:49 --> Model "M_produk" initialized
INFO - 2023-05-19 16:57:49 --> Controller Class Initialized
INFO - 2023-05-19 16:57:49 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 16:57:49 --> Model "M_produk" initialized
DEBUG - 2023-05-19 16:57:49 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 16:57:49 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 16:57:49 --> Model "M_transaksi" initialized
INFO - 2023-05-19 16:57:49 --> Model "M_bank" initialized
INFO - 2023-05-19 16:57:49 --> Model "M_pesan" initialized
INFO - 2023-05-19 16:57:49 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-05-19 16:57:49 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-05-19 16:57:49 --> Final output sent to browser
DEBUG - 2023-05-19 16:57:49 --> Total execution time: 0.2013
INFO - 2023-05-19 16:58:16 --> Config Class Initialized
INFO - 2023-05-19 16:58:16 --> Hooks Class Initialized
DEBUG - 2023-05-19 16:58:16 --> UTF-8 Support Enabled
INFO - 2023-05-19 16:58:16 --> Utf8 Class Initialized
INFO - 2023-05-19 16:58:16 --> URI Class Initialized
DEBUG - 2023-05-19 16:58:16 --> No URI present. Default controller set.
INFO - 2023-05-19 16:58:16 --> Router Class Initialized
INFO - 2023-05-19 16:58:16 --> Output Class Initialized
INFO - 2023-05-19 16:58:16 --> Security Class Initialized
DEBUG - 2023-05-19 16:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 16:58:16 --> Input Class Initialized
INFO - 2023-05-19 16:58:16 --> Language Class Initialized
INFO - 2023-05-19 16:58:16 --> Loader Class Initialized
INFO - 2023-05-19 16:58:16 --> Helper loaded: url_helper
INFO - 2023-05-19 16:58:16 --> Helper loaded: form_helper
INFO - 2023-05-19 16:58:16 --> Helper loaded: file_helper
INFO - 2023-05-19 16:58:16 --> Database Driver Class Initialized
DEBUG - 2023-05-19 16:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 16:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 16:58:16 --> Form Validation Class Initialized
INFO - 2023-05-19 16:58:16 --> Upload Class Initialized
INFO - 2023-05-19 16:58:16 --> Model "M_auth" initialized
INFO - 2023-05-19 16:58:16 --> Model "M_user" initialized
INFO - 2023-05-19 16:58:16 --> Model "M_produk" initialized
INFO - 2023-05-19 16:58:16 --> Controller Class Initialized
INFO - 2023-05-19 16:58:16 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 16:58:16 --> Model "M_produk" initialized
DEBUG - 2023-05-19 16:58:16 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 16:58:16 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 16:58:16 --> Model "M_transaksi" initialized
INFO - 2023-05-19 16:58:16 --> Model "M_bank" initialized
INFO - 2023-05-19 16:58:16 --> Model "M_pesan" initialized
INFO - 2023-05-19 16:58:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-05-19 16:58:16 --> Email Class Initialized
INFO - 2023-05-19 16:58:18 --> Language file loaded: language/english/email_lang.php
INFO - 2023-05-19 16:58:21 --> Config Class Initialized
INFO - 2023-05-19 16:58:21 --> Hooks Class Initialized
DEBUG - 2023-05-19 16:58:21 --> UTF-8 Support Enabled
INFO - 2023-05-19 16:58:21 --> Utf8 Class Initialized
INFO - 2023-05-19 16:58:21 --> URI Class Initialized
DEBUG - 2023-05-19 16:58:21 --> No URI present. Default controller set.
INFO - 2023-05-19 16:58:21 --> Router Class Initialized
INFO - 2023-05-19 16:58:21 --> Output Class Initialized
INFO - 2023-05-19 16:58:21 --> Security Class Initialized
DEBUG - 2023-05-19 16:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 16:58:21 --> Input Class Initialized
INFO - 2023-05-19 16:58:21 --> Language Class Initialized
INFO - 2023-05-19 16:58:21 --> Loader Class Initialized
INFO - 2023-05-19 16:58:21 --> Helper loaded: url_helper
INFO - 2023-05-19 16:58:21 --> Helper loaded: form_helper
INFO - 2023-05-19 16:58:21 --> Helper loaded: file_helper
INFO - 2023-05-19 16:58:21 --> Database Driver Class Initialized
DEBUG - 2023-05-19 16:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 16:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 16:58:21 --> Form Validation Class Initialized
INFO - 2023-05-19 16:58:21 --> Upload Class Initialized
INFO - 2023-05-19 16:58:21 --> Model "M_auth" initialized
INFO - 2023-05-19 16:58:21 --> Model "M_user" initialized
INFO - 2023-05-19 16:58:21 --> Model "M_produk" initialized
INFO - 2023-05-19 16:58:21 --> Controller Class Initialized
INFO - 2023-05-19 16:58:21 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 16:58:21 --> Model "M_produk" initialized
DEBUG - 2023-05-19 16:58:21 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 16:58:21 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 16:58:21 --> Model "M_transaksi" initialized
INFO - 2023-05-19 16:58:21 --> Model "M_bank" initialized
INFO - 2023-05-19 16:58:21 --> Model "M_pesan" initialized
INFO - 2023-05-19 16:58:21 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-05-19 16:58:21 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-05-19 16:58:21 --> Final output sent to browser
DEBUG - 2023-05-19 16:58:21 --> Total execution time: 0.1767
INFO - 2023-05-19 16:58:31 --> Config Class Initialized
INFO - 2023-05-19 16:58:31 --> Hooks Class Initialized
DEBUG - 2023-05-19 16:58:31 --> UTF-8 Support Enabled
INFO - 2023-05-19 16:58:31 --> Utf8 Class Initialized
INFO - 2023-05-19 16:58:31 --> URI Class Initialized
INFO - 2023-05-19 16:58:31 --> Router Class Initialized
INFO - 2023-05-19 16:58:31 --> Output Class Initialized
INFO - 2023-05-19 16:58:31 --> Security Class Initialized
DEBUG - 2023-05-19 16:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 16:58:31 --> Input Class Initialized
INFO - 2023-05-19 16:58:31 --> Language Class Initialized
INFO - 2023-05-19 16:58:31 --> Loader Class Initialized
INFO - 2023-05-19 16:58:31 --> Helper loaded: url_helper
INFO - 2023-05-19 16:58:31 --> Helper loaded: form_helper
INFO - 2023-05-19 16:58:31 --> Helper loaded: file_helper
INFO - 2023-05-19 16:58:31 --> Database Driver Class Initialized
DEBUG - 2023-05-19 16:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 16:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 16:58:31 --> Form Validation Class Initialized
INFO - 2023-05-19 16:58:31 --> Upload Class Initialized
INFO - 2023-05-19 16:58:31 --> Model "M_auth" initialized
INFO - 2023-05-19 16:58:31 --> Model "M_user" initialized
INFO - 2023-05-19 16:58:31 --> Model "M_produk" initialized
INFO - 2023-05-19 16:58:31 --> Controller Class Initialized
INFO - 2023-05-19 16:58:31 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 16:58:31 --> Model "M_produk" initialized
DEBUG - 2023-05-19 16:58:31 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 16:58:31 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 16:58:31 --> Model "M_transaksi" initialized
INFO - 2023-05-19 16:58:31 --> Model "M_bank" initialized
INFO - 2023-05-19 16:58:31 --> Model "M_pesan" initialized
INFO - 2023-05-19 16:58:31 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-05-19 16:58:31 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/v_produk_detail.php
INFO - 2023-05-19 16:58:31 --> Final output sent to browser
DEBUG - 2023-05-19 16:58:31 --> Total execution time: 0.1840
INFO - 2023-05-19 16:59:33 --> Config Class Initialized
INFO - 2023-05-19 16:59:33 --> Hooks Class Initialized
DEBUG - 2023-05-19 16:59:33 --> UTF-8 Support Enabled
INFO - 2023-05-19 16:59:33 --> Utf8 Class Initialized
INFO - 2023-05-19 16:59:33 --> URI Class Initialized
INFO - 2023-05-19 16:59:33 --> Router Class Initialized
INFO - 2023-05-19 16:59:33 --> Output Class Initialized
INFO - 2023-05-19 16:59:33 --> Security Class Initialized
DEBUG - 2023-05-19 16:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 16:59:33 --> Input Class Initialized
INFO - 2023-05-19 16:59:33 --> Language Class Initialized
INFO - 2023-05-19 16:59:33 --> Loader Class Initialized
INFO - 2023-05-19 16:59:33 --> Helper loaded: url_helper
INFO - 2023-05-19 16:59:33 --> Helper loaded: form_helper
INFO - 2023-05-19 16:59:33 --> Helper loaded: file_helper
INFO - 2023-05-19 16:59:33 --> Database Driver Class Initialized
DEBUG - 2023-05-19 16:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 16:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 16:59:33 --> Form Validation Class Initialized
INFO - 2023-05-19 16:59:33 --> Upload Class Initialized
INFO - 2023-05-19 16:59:33 --> Model "M_auth" initialized
INFO - 2023-05-19 16:59:33 --> Model "M_user" initialized
INFO - 2023-05-19 16:59:33 --> Model "M_produk" initialized
INFO - 2023-05-19 16:59:33 --> Controller Class Initialized
INFO - 2023-05-19 16:59:33 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 16:59:33 --> Model "M_produk" initialized
DEBUG - 2023-05-19 16:59:33 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 16:59:33 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 16:59:33 --> Model "M_transaksi" initialized
INFO - 2023-05-19 16:59:33 --> Model "M_bank" initialized
INFO - 2023-05-19 16:59:33 --> Model "M_pesan" initialized
INFO - 2023-05-19 16:59:33 --> Email Class Initialized
INFO - 2023-05-19 16:59:36 --> Language file loaded: language/english/email_lang.php
INFO - 2023-05-19 16:59:41 --> Config Class Initialized
INFO - 2023-05-19 16:59:41 --> Hooks Class Initialized
DEBUG - 2023-05-19 16:59:41 --> UTF-8 Support Enabled
INFO - 2023-05-19 16:59:41 --> Utf8 Class Initialized
INFO - 2023-05-19 16:59:41 --> URI Class Initialized
INFO - 2023-05-19 16:59:41 --> Router Class Initialized
INFO - 2023-05-19 16:59:41 --> Output Class Initialized
INFO - 2023-05-19 16:59:41 --> Security Class Initialized
DEBUG - 2023-05-19 16:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 16:59:41 --> Input Class Initialized
INFO - 2023-05-19 16:59:41 --> Language Class Initialized
INFO - 2023-05-19 16:59:41 --> Loader Class Initialized
INFO - 2023-05-19 16:59:41 --> Helper loaded: url_helper
INFO - 2023-05-19 16:59:41 --> Helper loaded: form_helper
INFO - 2023-05-19 16:59:41 --> Helper loaded: file_helper
INFO - 2023-05-19 16:59:41 --> Database Driver Class Initialized
DEBUG - 2023-05-19 16:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 16:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 16:59:41 --> Form Validation Class Initialized
INFO - 2023-05-19 16:59:41 --> Upload Class Initialized
INFO - 2023-05-19 16:59:41 --> Model "M_auth" initialized
INFO - 2023-05-19 16:59:41 --> Model "M_user" initialized
INFO - 2023-05-19 16:59:41 --> Model "M_produk" initialized
INFO - 2023-05-19 16:59:41 --> Controller Class Initialized
INFO - 2023-05-19 16:59:41 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 16:59:41 --> Model "M_produk" initialized
DEBUG - 2023-05-19 16:59:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 16:59:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 16:59:41 --> Model "M_transaksi" initialized
INFO - 2023-05-19 16:59:41 --> Model "M_bank" initialized
INFO - 2023-05-19 16:59:41 --> Model "M_pesan" initialized
INFO - 2023-05-19 16:59:41 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-05-19 16:59:41 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-05-19 16:59:41 --> Final output sent to browser
DEBUG - 2023-05-19 16:59:41 --> Total execution time: 0.2837
INFO - 2023-05-19 17:00:33 --> Config Class Initialized
INFO - 2023-05-19 17:00:33 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:00:33 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:00:33 --> Utf8 Class Initialized
INFO - 2023-05-19 17:00:33 --> URI Class Initialized
INFO - 2023-05-19 17:00:33 --> Router Class Initialized
INFO - 2023-05-19 17:00:33 --> Output Class Initialized
INFO - 2023-05-19 17:00:33 --> Security Class Initialized
DEBUG - 2023-05-19 17:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:00:33 --> Input Class Initialized
INFO - 2023-05-19 17:00:33 --> Language Class Initialized
INFO - 2023-05-19 17:00:33 --> Loader Class Initialized
INFO - 2023-05-19 17:00:33 --> Helper loaded: url_helper
INFO - 2023-05-19 17:00:33 --> Helper loaded: form_helper
INFO - 2023-05-19 17:00:33 --> Helper loaded: file_helper
INFO - 2023-05-19 17:00:33 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:00:33 --> Form Validation Class Initialized
INFO - 2023-05-19 17:00:33 --> Upload Class Initialized
INFO - 2023-05-19 17:00:33 --> Model "M_auth" initialized
INFO - 2023-05-19 17:00:33 --> Model "M_user" initialized
INFO - 2023-05-19 17:00:33 --> Model "M_produk" initialized
INFO - 2023-05-19 17:00:33 --> Controller Class Initialized
INFO - 2023-05-19 17:00:33 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 17:00:33 --> Model "M_produk" initialized
DEBUG - 2023-05-19 17:00:33 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 17:00:33 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 17:00:33 --> Model "M_transaksi" initialized
INFO - 2023-05-19 17:00:33 --> Model "M_bank" initialized
INFO - 2023-05-19 17:00:33 --> Model "M_pesan" initialized
INFO - 2023-05-19 17:00:33 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-05-19 17:00:33 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/v_bayar_sekarang.php
INFO - 2023-05-19 17:00:33 --> Final output sent to browser
DEBUG - 2023-05-19 17:00:33 --> Total execution time: 0.3160
INFO - 2023-05-19 17:01:54 --> Config Class Initialized
INFO - 2023-05-19 17:01:54 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:01:54 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:01:54 --> Utf8 Class Initialized
INFO - 2023-05-19 17:01:54 --> URI Class Initialized
INFO - 2023-05-19 17:01:54 --> Router Class Initialized
INFO - 2023-05-19 17:01:54 --> Output Class Initialized
INFO - 2023-05-19 17:01:54 --> Security Class Initialized
DEBUG - 2023-05-19 17:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:01:54 --> Input Class Initialized
INFO - 2023-05-19 17:01:54 --> Language Class Initialized
INFO - 2023-05-19 17:01:54 --> Loader Class Initialized
INFO - 2023-05-19 17:01:54 --> Helper loaded: url_helper
INFO - 2023-05-19 17:01:54 --> Helper loaded: form_helper
INFO - 2023-05-19 17:01:54 --> Helper loaded: file_helper
INFO - 2023-05-19 17:01:54 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:01:54 --> Form Validation Class Initialized
INFO - 2023-05-19 17:01:54 --> Upload Class Initialized
INFO - 2023-05-19 17:01:54 --> Model "M_auth" initialized
INFO - 2023-05-19 17:01:54 --> Model "M_user" initialized
INFO - 2023-05-19 17:01:54 --> Model "M_produk" initialized
INFO - 2023-05-19 17:01:54 --> Controller Class Initialized
INFO - 2023-05-19 17:01:54 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 17:01:54 --> Model "M_produk" initialized
DEBUG - 2023-05-19 17:01:54 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 17:01:54 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 17:01:54 --> Model "M_transaksi" initialized
INFO - 2023-05-19 17:01:54 --> Model "M_bank" initialized
INFO - 2023-05-19 17:01:54 --> Model "M_pesan" initialized
INFO - 2023-05-19 17:01:54 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-05-19 17:01:54 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-05-19 17:01:54 --> Final output sent to browser
DEBUG - 2023-05-19 17:01:54 --> Total execution time: 0.1773
INFO - 2023-05-19 17:02:50 --> Config Class Initialized
INFO - 2023-05-19 17:02:50 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:02:50 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:02:50 --> Utf8 Class Initialized
INFO - 2023-05-19 17:02:50 --> URI Class Initialized
INFO - 2023-05-19 17:02:50 --> Router Class Initialized
INFO - 2023-05-19 17:02:50 --> Output Class Initialized
INFO - 2023-05-19 17:02:50 --> Security Class Initialized
DEBUG - 2023-05-19 17:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:02:50 --> Input Class Initialized
INFO - 2023-05-19 17:02:50 --> Language Class Initialized
INFO - 2023-05-19 17:02:50 --> Loader Class Initialized
INFO - 2023-05-19 17:02:50 --> Helper loaded: url_helper
INFO - 2023-05-19 17:02:50 --> Helper loaded: form_helper
INFO - 2023-05-19 17:02:50 --> Helper loaded: file_helper
INFO - 2023-05-19 17:02:50 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:02:50 --> Form Validation Class Initialized
INFO - 2023-05-19 17:02:50 --> Upload Class Initialized
INFO - 2023-05-19 17:02:50 --> Model "M_auth" initialized
INFO - 2023-05-19 17:02:50 --> Model "M_user" initialized
INFO - 2023-05-19 17:02:50 --> Model "M_produk" initialized
INFO - 2023-05-19 17:02:50 --> Controller Class Initialized
INFO - 2023-05-19 17:02:50 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 17:02:50 --> Model "M_produk" initialized
DEBUG - 2023-05-19 17:02:50 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 17:02:50 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 17:02:50 --> Model "M_transaksi" initialized
INFO - 2023-05-19 17:02:50 --> Model "M_bank" initialized
INFO - 2023-05-19 17:02:50 --> Model "M_pesan" initialized
INFO - 2023-05-19 17:02:50 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-05-19 17:02:50 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/v_edit_profile_pelanggan.php
INFO - 2023-05-19 17:02:50 --> Final output sent to browser
DEBUG - 2023-05-19 17:02:50 --> Total execution time: 0.3774
INFO - 2023-05-19 17:02:57 --> Config Class Initialized
INFO - 2023-05-19 17:02:57 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:02:57 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:02:57 --> Utf8 Class Initialized
INFO - 2023-05-19 17:02:57 --> URI Class Initialized
INFO - 2023-05-19 17:02:57 --> Router Class Initialized
INFO - 2023-05-19 17:02:58 --> Output Class Initialized
INFO - 2023-05-19 17:02:58 --> Security Class Initialized
DEBUG - 2023-05-19 17:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:02:58 --> Input Class Initialized
INFO - 2023-05-19 17:02:58 --> Language Class Initialized
INFO - 2023-05-19 17:02:58 --> Loader Class Initialized
INFO - 2023-05-19 17:02:58 --> Helper loaded: url_helper
INFO - 2023-05-19 17:02:58 --> Helper loaded: form_helper
INFO - 2023-05-19 17:02:58 --> Helper loaded: file_helper
INFO - 2023-05-19 17:02:58 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:02:58 --> Form Validation Class Initialized
INFO - 2023-05-19 17:02:58 --> Upload Class Initialized
INFO - 2023-05-19 17:02:58 --> Model "M_auth" initialized
INFO - 2023-05-19 17:02:58 --> Model "M_user" initialized
INFO - 2023-05-19 17:02:58 --> Model "M_produk" initialized
INFO - 2023-05-19 17:02:58 --> Controller Class Initialized
INFO - 2023-05-19 17:02:58 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 17:02:58 --> Model "M_produk" initialized
DEBUG - 2023-05-19 17:02:58 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 17:02:58 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 17:02:58 --> Model "M_transaksi" initialized
INFO - 2023-05-19 17:02:58 --> Model "M_bank" initialized
INFO - 2023-05-19 17:02:58 --> Model "M_pesan" initialized
INFO - 2023-05-19 17:02:58 --> Config Class Initialized
INFO - 2023-05-19 17:02:58 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:02:58 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:02:58 --> Utf8 Class Initialized
INFO - 2023-05-19 17:02:58 --> URI Class Initialized
DEBUG - 2023-05-19 17:02:58 --> No URI present. Default controller set.
INFO - 2023-05-19 17:02:58 --> Router Class Initialized
INFO - 2023-05-19 17:02:58 --> Output Class Initialized
INFO - 2023-05-19 17:02:58 --> Security Class Initialized
DEBUG - 2023-05-19 17:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:02:58 --> Input Class Initialized
INFO - 2023-05-19 17:02:58 --> Language Class Initialized
INFO - 2023-05-19 17:02:58 --> Loader Class Initialized
INFO - 2023-05-19 17:02:58 --> Helper loaded: url_helper
INFO - 2023-05-19 17:02:58 --> Helper loaded: form_helper
INFO - 2023-05-19 17:02:58 --> Helper loaded: file_helper
INFO - 2023-05-19 17:02:58 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:02:58 --> Form Validation Class Initialized
INFO - 2023-05-19 17:02:58 --> Upload Class Initialized
INFO - 2023-05-19 17:02:58 --> Model "M_auth" initialized
INFO - 2023-05-19 17:02:58 --> Model "M_user" initialized
INFO - 2023-05-19 17:02:58 --> Model "M_produk" initialized
INFO - 2023-05-19 17:02:58 --> Controller Class Initialized
INFO - 2023-05-19 17:02:58 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 17:02:58 --> Model "M_produk" initialized
DEBUG - 2023-05-19 17:02:58 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 17:02:58 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 17:02:58 --> Model "M_transaksi" initialized
INFO - 2023-05-19 17:02:58 --> Model "M_bank" initialized
INFO - 2023-05-19 17:02:58 --> Model "M_pesan" initialized
INFO - 2023-05-19 17:02:58 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-05-19 17:02:58 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-05-19 17:02:58 --> Final output sent to browser
DEBUG - 2023-05-19 17:02:58 --> Total execution time: 0.2039
INFO - 2023-05-19 17:03:22 --> Config Class Initialized
INFO - 2023-05-19 17:03:22 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:03:23 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:03:23 --> Utf8 Class Initialized
INFO - 2023-05-19 17:03:23 --> URI Class Initialized
DEBUG - 2023-05-19 17:03:23 --> No URI present. Default controller set.
INFO - 2023-05-19 17:03:23 --> Router Class Initialized
INFO - 2023-05-19 17:03:23 --> Output Class Initialized
INFO - 2023-05-19 17:03:23 --> Security Class Initialized
DEBUG - 2023-05-19 17:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:03:23 --> Input Class Initialized
INFO - 2023-05-19 17:03:23 --> Language Class Initialized
INFO - 2023-05-19 17:03:23 --> Loader Class Initialized
INFO - 2023-05-19 17:03:23 --> Helper loaded: url_helper
INFO - 2023-05-19 17:03:23 --> Helper loaded: form_helper
INFO - 2023-05-19 17:03:23 --> Helper loaded: file_helper
INFO - 2023-05-19 17:03:23 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:03:23 --> Form Validation Class Initialized
INFO - 2023-05-19 17:03:23 --> Upload Class Initialized
INFO - 2023-05-19 17:03:23 --> Model "M_auth" initialized
INFO - 2023-05-19 17:03:23 --> Model "M_user" initialized
INFO - 2023-05-19 17:03:23 --> Model "M_produk" initialized
INFO - 2023-05-19 17:03:23 --> Controller Class Initialized
INFO - 2023-05-19 17:03:23 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 17:03:23 --> Model "M_produk" initialized
DEBUG - 2023-05-19 17:03:23 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 17:03:23 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 17:03:23 --> Model "M_transaksi" initialized
INFO - 2023-05-19 17:03:23 --> Model "M_bank" initialized
INFO - 2023-05-19 17:03:23 --> Model "M_pesan" initialized
INFO - 2023-05-19 17:03:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-05-19 17:03:23 --> Email Class Initialized
INFO - 2023-05-19 17:03:24 --> Language file loaded: language/english/email_lang.php
INFO - 2023-05-19 17:03:28 --> Config Class Initialized
INFO - 2023-05-19 17:03:28 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:03:28 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:03:28 --> Utf8 Class Initialized
INFO - 2023-05-19 17:03:28 --> URI Class Initialized
DEBUG - 2023-05-19 17:03:28 --> No URI present. Default controller set.
INFO - 2023-05-19 17:03:28 --> Router Class Initialized
INFO - 2023-05-19 17:03:28 --> Output Class Initialized
INFO - 2023-05-19 17:03:28 --> Security Class Initialized
DEBUG - 2023-05-19 17:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:03:28 --> Input Class Initialized
INFO - 2023-05-19 17:03:28 --> Language Class Initialized
INFO - 2023-05-19 17:03:28 --> Loader Class Initialized
INFO - 2023-05-19 17:03:28 --> Helper loaded: url_helper
INFO - 2023-05-19 17:03:28 --> Helper loaded: form_helper
INFO - 2023-05-19 17:03:28 --> Helper loaded: file_helper
INFO - 2023-05-19 17:03:28 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:03:28 --> Form Validation Class Initialized
INFO - 2023-05-19 17:03:28 --> Upload Class Initialized
INFO - 2023-05-19 17:03:28 --> Model "M_auth" initialized
INFO - 2023-05-19 17:03:28 --> Model "M_user" initialized
INFO - 2023-05-19 17:03:28 --> Model "M_produk" initialized
INFO - 2023-05-19 17:03:28 --> Controller Class Initialized
INFO - 2023-05-19 17:03:28 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 17:03:28 --> Model "M_produk" initialized
DEBUG - 2023-05-19 17:03:28 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 17:03:28 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 17:03:28 --> Model "M_transaksi" initialized
INFO - 2023-05-19 17:03:28 --> Model "M_bank" initialized
INFO - 2023-05-19 17:03:28 --> Model "M_pesan" initialized
INFO - 2023-05-19 17:03:28 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-05-19 17:03:28 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-05-19 17:03:28 --> Final output sent to browser
DEBUG - 2023-05-19 17:03:28 --> Total execution time: 0.1558
INFO - 2023-05-19 17:03:30 --> Config Class Initialized
INFO - 2023-05-19 17:03:30 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:03:30 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:03:30 --> Utf8 Class Initialized
INFO - 2023-05-19 17:03:30 --> URI Class Initialized
INFO - 2023-05-19 17:03:30 --> Router Class Initialized
INFO - 2023-05-19 17:03:30 --> Output Class Initialized
INFO - 2023-05-19 17:03:30 --> Security Class Initialized
DEBUG - 2023-05-19 17:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:03:30 --> Input Class Initialized
INFO - 2023-05-19 17:03:30 --> Language Class Initialized
INFO - 2023-05-19 17:03:30 --> Loader Class Initialized
INFO - 2023-05-19 17:03:30 --> Helper loaded: url_helper
INFO - 2023-05-19 17:03:30 --> Helper loaded: form_helper
INFO - 2023-05-19 17:03:30 --> Helper loaded: file_helper
INFO - 2023-05-19 17:03:30 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:03:31 --> Form Validation Class Initialized
INFO - 2023-05-19 17:03:31 --> Upload Class Initialized
INFO - 2023-05-19 17:03:31 --> Model "M_auth" initialized
INFO - 2023-05-19 17:03:31 --> Model "M_user" initialized
INFO - 2023-05-19 17:03:31 --> Model "M_produk" initialized
INFO - 2023-05-19 17:03:31 --> Controller Class Initialized
INFO - 2023-05-19 17:03:31 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 17:03:31 --> Model "M_produk" initialized
DEBUG - 2023-05-19 17:03:31 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 17:03:31 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 17:03:31 --> Model "M_transaksi" initialized
INFO - 2023-05-19 17:03:31 --> Model "M_bank" initialized
INFO - 2023-05-19 17:03:31 --> Model "M_pesan" initialized
INFO - 2023-05-19 17:03:31 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-05-19 17:03:31 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-05-19 17:03:31 --> Final output sent to browser
DEBUG - 2023-05-19 17:03:31 --> Total execution time: 0.3111
INFO - 2023-05-19 17:04:41 --> Config Class Initialized
INFO - 2023-05-19 17:04:41 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:04:41 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:04:41 --> Utf8 Class Initialized
INFO - 2023-05-19 17:04:41 --> URI Class Initialized
INFO - 2023-05-19 17:04:41 --> Router Class Initialized
INFO - 2023-05-19 17:04:41 --> Output Class Initialized
INFO - 2023-05-19 17:04:41 --> Security Class Initialized
DEBUG - 2023-05-19 17:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:04:41 --> Input Class Initialized
INFO - 2023-05-19 17:04:41 --> Language Class Initialized
INFO - 2023-05-19 17:04:41 --> Loader Class Initialized
INFO - 2023-05-19 17:04:41 --> Helper loaded: url_helper
INFO - 2023-05-19 17:04:41 --> Helper loaded: form_helper
INFO - 2023-05-19 17:04:41 --> Helper loaded: file_helper
INFO - 2023-05-19 17:04:41 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:04:41 --> Form Validation Class Initialized
INFO - 2023-05-19 17:04:41 --> Upload Class Initialized
INFO - 2023-05-19 17:04:41 --> Model "M_auth" initialized
INFO - 2023-05-19 17:04:41 --> Model "M_user" initialized
INFO - 2023-05-19 17:04:41 --> Model "M_produk" initialized
INFO - 2023-05-19 17:04:41 --> Controller Class Initialized
INFO - 2023-05-19 17:04:41 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 17:04:41 --> Model "M_produk" initialized
DEBUG - 2023-05-19 17:04:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 17:04:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 17:04:41 --> Model "M_transaksi" initialized
INFO - 2023-05-19 17:04:41 --> Model "M_bank" initialized
INFO - 2023-05-19 17:04:41 --> Model "M_pesan" initialized
INFO - 2023-05-19 17:04:41 --> Config Class Initialized
INFO - 2023-05-19 17:04:41 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:04:41 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:04:41 --> Utf8 Class Initialized
INFO - 2023-05-19 17:04:41 --> URI Class Initialized
DEBUG - 2023-05-19 17:04:41 --> No URI present. Default controller set.
INFO - 2023-05-19 17:04:41 --> Router Class Initialized
INFO - 2023-05-19 17:04:41 --> Output Class Initialized
INFO - 2023-05-19 17:04:41 --> Security Class Initialized
DEBUG - 2023-05-19 17:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:04:41 --> Input Class Initialized
INFO - 2023-05-19 17:04:41 --> Language Class Initialized
INFO - 2023-05-19 17:04:41 --> Loader Class Initialized
INFO - 2023-05-19 17:04:41 --> Helper loaded: url_helper
INFO - 2023-05-19 17:04:41 --> Helper loaded: form_helper
INFO - 2023-05-19 17:04:41 --> Helper loaded: file_helper
INFO - 2023-05-19 17:04:41 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:04:41 --> Form Validation Class Initialized
INFO - 2023-05-19 17:04:41 --> Upload Class Initialized
INFO - 2023-05-19 17:04:41 --> Model "M_auth" initialized
INFO - 2023-05-19 17:04:41 --> Model "M_user" initialized
INFO - 2023-05-19 17:04:41 --> Model "M_produk" initialized
INFO - 2023-05-19 17:04:41 --> Controller Class Initialized
INFO - 2023-05-19 17:04:41 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 17:04:41 --> Model "M_produk" initialized
DEBUG - 2023-05-19 17:04:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 17:04:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 17:04:41 --> Model "M_transaksi" initialized
INFO - 2023-05-19 17:04:41 --> Model "M_bank" initialized
INFO - 2023-05-19 17:04:41 --> Model "M_pesan" initialized
INFO - 2023-05-19 17:04:41 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-05-19 17:04:41 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-05-19 17:04:41 --> Final output sent to browser
DEBUG - 2023-05-19 17:04:41 --> Total execution time: 0.1239
INFO - 2023-05-19 17:04:46 --> Config Class Initialized
INFO - 2023-05-19 17:04:46 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:04:46 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:04:46 --> Utf8 Class Initialized
INFO - 2023-05-19 17:04:47 --> URI Class Initialized
INFO - 2023-05-19 17:04:47 --> Router Class Initialized
INFO - 2023-05-19 17:04:47 --> Output Class Initialized
INFO - 2023-05-19 17:04:47 --> Security Class Initialized
DEBUG - 2023-05-19 17:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:04:47 --> Input Class Initialized
INFO - 2023-05-19 17:04:47 --> Language Class Initialized
INFO - 2023-05-19 17:04:47 --> Loader Class Initialized
INFO - 2023-05-19 17:04:47 --> Helper loaded: url_helper
INFO - 2023-05-19 17:04:47 --> Helper loaded: form_helper
INFO - 2023-05-19 17:04:47 --> Helper loaded: file_helper
INFO - 2023-05-19 17:04:47 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:04:47 --> Form Validation Class Initialized
INFO - 2023-05-19 17:04:47 --> Upload Class Initialized
INFO - 2023-05-19 17:04:47 --> Model "M_auth" initialized
INFO - 2023-05-19 17:04:47 --> Model "M_user" initialized
INFO - 2023-05-19 17:04:47 --> Model "M_produk" initialized
INFO - 2023-05-19 17:04:47 --> Controller Class Initialized
INFO - 2023-05-19 17:04:47 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-05-19 17:04:47 --> Final output sent to browser
DEBUG - 2023-05-19 17:04:47 --> Total execution time: 0.1786
INFO - 2023-05-19 17:04:57 --> Config Class Initialized
INFO - 2023-05-19 17:04:57 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:04:57 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:04:57 --> Utf8 Class Initialized
INFO - 2023-05-19 17:04:57 --> URI Class Initialized
INFO - 2023-05-19 17:04:57 --> Router Class Initialized
INFO - 2023-05-19 17:04:57 --> Output Class Initialized
INFO - 2023-05-19 17:04:57 --> Security Class Initialized
DEBUG - 2023-05-19 17:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:04:57 --> Input Class Initialized
INFO - 2023-05-19 17:04:57 --> Language Class Initialized
INFO - 2023-05-19 17:04:57 --> Loader Class Initialized
INFO - 2023-05-19 17:04:57 --> Helper loaded: url_helper
INFO - 2023-05-19 17:04:57 --> Helper loaded: form_helper
INFO - 2023-05-19 17:04:57 --> Helper loaded: file_helper
INFO - 2023-05-19 17:04:57 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:04:57 --> Form Validation Class Initialized
INFO - 2023-05-19 17:04:57 --> Upload Class Initialized
INFO - 2023-05-19 17:04:57 --> Model "M_auth" initialized
INFO - 2023-05-19 17:04:57 --> Model "M_user" initialized
INFO - 2023-05-19 17:04:57 --> Model "M_produk" initialized
INFO - 2023-05-19 17:04:57 --> Controller Class Initialized
INFO - 2023-05-19 17:04:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-05-19 17:04:57 --> Config Class Initialized
INFO - 2023-05-19 17:04:57 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:04:57 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:04:57 --> Utf8 Class Initialized
INFO - 2023-05-19 17:04:57 --> URI Class Initialized
INFO - 2023-05-19 17:04:57 --> Router Class Initialized
INFO - 2023-05-19 17:04:57 --> Output Class Initialized
INFO - 2023-05-19 17:04:57 --> Security Class Initialized
DEBUG - 2023-05-19 17:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:04:57 --> Input Class Initialized
INFO - 2023-05-19 17:04:57 --> Language Class Initialized
INFO - 2023-05-19 17:04:57 --> Loader Class Initialized
INFO - 2023-05-19 17:04:57 --> Helper loaded: url_helper
INFO - 2023-05-19 17:04:57 --> Helper loaded: form_helper
INFO - 2023-05-19 17:04:57 --> Helper loaded: file_helper
INFO - 2023-05-19 17:04:57 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:04:57 --> Form Validation Class Initialized
INFO - 2023-05-19 17:04:57 --> Upload Class Initialized
INFO - 2023-05-19 17:04:57 --> Model "M_auth" initialized
INFO - 2023-05-19 17:04:57 --> Model "M_user" initialized
INFO - 2023-05-19 17:04:57 --> Model "M_produk" initialized
INFO - 2023-05-19 17:04:57 --> Controller Class Initialized
INFO - 2023-05-19 17:04:57 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-05-19 17:04:57 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 17:04:57 --> Final output sent to browser
DEBUG - 2023-05-19 17:04:57 --> Total execution time: 0.1095
INFO - 2023-05-19 17:05:02 --> Config Class Initialized
INFO - 2023-05-19 17:05:02 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:05:02 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:05:02 --> Utf8 Class Initialized
INFO - 2023-05-19 17:05:02 --> URI Class Initialized
INFO - 2023-05-19 17:05:02 --> Router Class Initialized
INFO - 2023-05-19 17:05:02 --> Output Class Initialized
INFO - 2023-05-19 17:05:02 --> Security Class Initialized
DEBUG - 2023-05-19 17:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:05:02 --> Input Class Initialized
INFO - 2023-05-19 17:05:02 --> Language Class Initialized
INFO - 2023-05-19 17:05:02 --> Loader Class Initialized
INFO - 2023-05-19 17:05:02 --> Helper loaded: url_helper
INFO - 2023-05-19 17:05:02 --> Helper loaded: form_helper
INFO - 2023-05-19 17:05:02 --> Helper loaded: file_helper
INFO - 2023-05-19 17:05:02 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:05:02 --> Form Validation Class Initialized
INFO - 2023-05-19 17:05:02 --> Upload Class Initialized
INFO - 2023-05-19 17:05:02 --> Model "M_auth" initialized
INFO - 2023-05-19 17:05:02 --> Model "M_user" initialized
INFO - 2023-05-19 17:05:02 --> Model "M_produk" initialized
INFO - 2023-05-19 17:05:02 --> Controller Class Initialized
INFO - 2023-05-19 17:05:02 --> Model "M_produk" initialized
INFO - 2023-05-19 17:05:02 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-05-19 17:05:02 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 17:05:02 --> Final output sent to browser
DEBUG - 2023-05-19 17:05:02 --> Total execution time: 0.2379
INFO - 2023-05-19 17:05:10 --> Config Class Initialized
INFO - 2023-05-19 17:05:10 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:05:10 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:05:10 --> Utf8 Class Initialized
INFO - 2023-05-19 17:05:10 --> URI Class Initialized
INFO - 2023-05-19 17:05:10 --> Router Class Initialized
INFO - 2023-05-19 17:05:10 --> Output Class Initialized
INFO - 2023-05-19 17:05:10 --> Security Class Initialized
DEBUG - 2023-05-19 17:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:05:10 --> Input Class Initialized
INFO - 2023-05-19 17:05:10 --> Language Class Initialized
INFO - 2023-05-19 17:05:10 --> Loader Class Initialized
INFO - 2023-05-19 17:05:10 --> Helper loaded: url_helper
INFO - 2023-05-19 17:05:10 --> Helper loaded: form_helper
INFO - 2023-05-19 17:05:10 --> Helper loaded: file_helper
INFO - 2023-05-19 17:05:10 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:05:10 --> Form Validation Class Initialized
INFO - 2023-05-19 17:05:10 --> Upload Class Initialized
INFO - 2023-05-19 17:05:10 --> Model "M_auth" initialized
INFO - 2023-05-19 17:05:10 --> Model "M_user" initialized
INFO - 2023-05-19 17:05:10 --> Model "M_produk" initialized
INFO - 2023-05-19 17:05:10 --> Controller Class Initialized
INFO - 2023-05-19 17:05:10 --> Model "M_produk" initialized
INFO - 2023-05-19 17:05:10 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_type_merek.php
INFO - 2023-05-19 17:05:10 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 17:05:10 --> Final output sent to browser
DEBUG - 2023-05-19 17:05:10 --> Total execution time: 0.2064
INFO - 2023-05-19 17:05:13 --> Config Class Initialized
INFO - 2023-05-19 17:05:13 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:05:13 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:05:13 --> Utf8 Class Initialized
INFO - 2023-05-19 17:05:13 --> URI Class Initialized
INFO - 2023-05-19 17:05:13 --> Router Class Initialized
INFO - 2023-05-19 17:05:13 --> Output Class Initialized
INFO - 2023-05-19 17:05:13 --> Security Class Initialized
DEBUG - 2023-05-19 17:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:05:13 --> Input Class Initialized
INFO - 2023-05-19 17:05:13 --> Language Class Initialized
INFO - 2023-05-19 17:05:13 --> Loader Class Initialized
INFO - 2023-05-19 17:05:13 --> Helper loaded: url_helper
INFO - 2023-05-19 17:05:13 --> Helper loaded: form_helper
INFO - 2023-05-19 17:05:13 --> Helper loaded: file_helper
INFO - 2023-05-19 17:05:13 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:05:13 --> Form Validation Class Initialized
INFO - 2023-05-19 17:05:13 --> Upload Class Initialized
INFO - 2023-05-19 17:05:13 --> Model "M_auth" initialized
INFO - 2023-05-19 17:05:13 --> Model "M_user" initialized
INFO - 2023-05-19 17:05:13 --> Model "M_produk" initialized
INFO - 2023-05-19 17:05:13 --> Controller Class Initialized
INFO - 2023-05-19 17:05:13 --> Model "M_produk" initialized
INFO - 2023-05-19 17:05:13 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_typeproduk.php
INFO - 2023-05-19 17:05:13 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 17:05:13 --> Final output sent to browser
DEBUG - 2023-05-19 17:05:13 --> Total execution time: 0.2346
INFO - 2023-05-19 17:05:15 --> Config Class Initialized
INFO - 2023-05-19 17:05:15 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:05:15 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:05:15 --> Utf8 Class Initialized
INFO - 2023-05-19 17:05:15 --> URI Class Initialized
INFO - 2023-05-19 17:05:15 --> Router Class Initialized
INFO - 2023-05-19 17:05:15 --> Output Class Initialized
INFO - 2023-05-19 17:05:15 --> Security Class Initialized
DEBUG - 2023-05-19 17:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:05:15 --> Input Class Initialized
INFO - 2023-05-19 17:05:15 --> Language Class Initialized
INFO - 2023-05-19 17:05:15 --> Loader Class Initialized
INFO - 2023-05-19 17:05:15 --> Helper loaded: url_helper
INFO - 2023-05-19 17:05:15 --> Helper loaded: form_helper
INFO - 2023-05-19 17:05:15 --> Helper loaded: file_helper
INFO - 2023-05-19 17:05:15 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:05:15 --> Form Validation Class Initialized
INFO - 2023-05-19 17:05:15 --> Upload Class Initialized
INFO - 2023-05-19 17:05:15 --> Model "M_auth" initialized
INFO - 2023-05-19 17:05:15 --> Model "M_user" initialized
INFO - 2023-05-19 17:05:15 --> Model "M_produk" initialized
INFO - 2023-05-19 17:05:15 --> Controller Class Initialized
INFO - 2023-05-19 17:05:15 --> Model "M_produk" initialized
INFO - 2023-05-19 17:05:16 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-05-19 17:05:16 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 17:05:16 --> Final output sent to browser
DEBUG - 2023-05-19 17:05:16 --> Total execution time: 0.1377
INFO - 2023-05-19 17:05:19 --> Config Class Initialized
INFO - 2023-05-19 17:05:19 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:05:19 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:05:19 --> Utf8 Class Initialized
INFO - 2023-05-19 17:05:19 --> URI Class Initialized
INFO - 2023-05-19 17:05:19 --> Router Class Initialized
INFO - 2023-05-19 17:05:19 --> Output Class Initialized
INFO - 2023-05-19 17:05:19 --> Security Class Initialized
DEBUG - 2023-05-19 17:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:05:19 --> Input Class Initialized
INFO - 2023-05-19 17:05:19 --> Language Class Initialized
INFO - 2023-05-19 17:05:19 --> Loader Class Initialized
INFO - 2023-05-19 17:05:19 --> Helper loaded: url_helper
INFO - 2023-05-19 17:05:19 --> Helper loaded: form_helper
INFO - 2023-05-19 17:05:19 --> Helper loaded: file_helper
INFO - 2023-05-19 17:05:19 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:05:19 --> Form Validation Class Initialized
INFO - 2023-05-19 17:05:19 --> Upload Class Initialized
INFO - 2023-05-19 17:05:19 --> Model "M_auth" initialized
INFO - 2023-05-19 17:05:19 --> Model "M_user" initialized
INFO - 2023-05-19 17:05:19 --> Model "M_produk" initialized
INFO - 2023-05-19 17:05:19 --> Controller Class Initialized
INFO - 2023-05-19 17:05:19 --> Model "M_produk" initialized
INFO - 2023-05-19 17:05:19 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_edit_produk.php
INFO - 2023-05-19 17:05:19 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 17:05:19 --> Final output sent to browser
DEBUG - 2023-05-19 17:05:19 --> Total execution time: 0.2503
INFO - 2023-05-19 17:05:28 --> Config Class Initialized
INFO - 2023-05-19 17:05:28 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:05:28 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:05:28 --> Utf8 Class Initialized
INFO - 2023-05-19 17:05:28 --> URI Class Initialized
INFO - 2023-05-19 17:05:28 --> Router Class Initialized
INFO - 2023-05-19 17:05:28 --> Output Class Initialized
INFO - 2023-05-19 17:05:28 --> Security Class Initialized
DEBUG - 2023-05-19 17:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:05:28 --> Input Class Initialized
INFO - 2023-05-19 17:05:28 --> Language Class Initialized
INFO - 2023-05-19 17:05:28 --> Loader Class Initialized
INFO - 2023-05-19 17:05:28 --> Helper loaded: url_helper
INFO - 2023-05-19 17:05:28 --> Helper loaded: form_helper
INFO - 2023-05-19 17:05:28 --> Helper loaded: file_helper
INFO - 2023-05-19 17:05:28 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:05:28 --> Form Validation Class Initialized
INFO - 2023-05-19 17:05:28 --> Upload Class Initialized
INFO - 2023-05-19 17:05:28 --> Model "M_auth" initialized
INFO - 2023-05-19 17:05:28 --> Model "M_user" initialized
INFO - 2023-05-19 17:05:28 --> Model "M_produk" initialized
INFO - 2023-05-19 17:05:28 --> Controller Class Initialized
INFO - 2023-05-19 17:05:28 --> Model "M_produk" initialized
INFO - 2023-05-19 17:05:28 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-05-19 17:05:28 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 17:05:28 --> Final output sent to browser
DEBUG - 2023-05-19 17:05:28 --> Total execution time: 0.1240
INFO - 2023-05-19 17:05:33 --> Config Class Initialized
INFO - 2023-05-19 17:05:33 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:05:33 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:05:33 --> Utf8 Class Initialized
INFO - 2023-05-19 17:05:33 --> URI Class Initialized
INFO - 2023-05-19 17:05:33 --> Router Class Initialized
INFO - 2023-05-19 17:05:33 --> Output Class Initialized
INFO - 2023-05-19 17:05:33 --> Security Class Initialized
DEBUG - 2023-05-19 17:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:05:33 --> Input Class Initialized
INFO - 2023-05-19 17:05:33 --> Language Class Initialized
INFO - 2023-05-19 17:05:33 --> Loader Class Initialized
INFO - 2023-05-19 17:05:33 --> Helper loaded: url_helper
INFO - 2023-05-19 17:05:33 --> Helper loaded: form_helper
INFO - 2023-05-19 17:05:33 --> Helper loaded: file_helper
INFO - 2023-05-19 17:05:33 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:05:33 --> Form Validation Class Initialized
INFO - 2023-05-19 17:05:33 --> Upload Class Initialized
INFO - 2023-05-19 17:05:33 --> Model "M_auth" initialized
INFO - 2023-05-19 17:05:33 --> Model "M_user" initialized
INFO - 2023-05-19 17:05:33 --> Model "M_produk" initialized
INFO - 2023-05-19 17:05:33 --> Controller Class Initialized
INFO - 2023-05-19 17:05:33 --> Model "M_produk" initialized
INFO - 2023-05-19 17:05:33 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_add_produk.php
INFO - 2023-05-19 17:05:33 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 17:05:33 --> Final output sent to browser
DEBUG - 2023-05-19 17:05:33 --> Total execution time: 0.2296
INFO - 2023-05-19 17:05:46 --> Config Class Initialized
INFO - 2023-05-19 17:05:46 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:05:46 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:05:46 --> Utf8 Class Initialized
INFO - 2023-05-19 17:05:46 --> URI Class Initialized
INFO - 2023-05-19 17:05:46 --> Router Class Initialized
INFO - 2023-05-19 17:05:46 --> Output Class Initialized
INFO - 2023-05-19 17:05:46 --> Security Class Initialized
DEBUG - 2023-05-19 17:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:05:46 --> Input Class Initialized
INFO - 2023-05-19 17:05:46 --> Language Class Initialized
INFO - 2023-05-19 17:05:46 --> Loader Class Initialized
INFO - 2023-05-19 17:05:46 --> Helper loaded: url_helper
INFO - 2023-05-19 17:05:46 --> Helper loaded: form_helper
INFO - 2023-05-19 17:05:46 --> Helper loaded: file_helper
INFO - 2023-05-19 17:05:46 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:05:46 --> Form Validation Class Initialized
INFO - 2023-05-19 17:05:46 --> Upload Class Initialized
INFO - 2023-05-19 17:05:46 --> Model "M_auth" initialized
INFO - 2023-05-19 17:05:46 --> Model "M_user" initialized
INFO - 2023-05-19 17:05:46 --> Model "M_produk" initialized
INFO - 2023-05-19 17:05:46 --> Controller Class Initialized
INFO - 2023-05-19 17:05:46 --> Model "M_produk" initialized
INFO - 2023-05-19 17:05:46 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-05-19 17:05:46 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 17:05:46 --> Final output sent to browser
DEBUG - 2023-05-19 17:05:46 --> Total execution time: 0.1643
INFO - 2023-05-19 17:05:50 --> Config Class Initialized
INFO - 2023-05-19 17:05:50 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:05:50 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:05:50 --> Utf8 Class Initialized
INFO - 2023-05-19 17:05:50 --> URI Class Initialized
INFO - 2023-05-19 17:05:50 --> Router Class Initialized
INFO - 2023-05-19 17:05:50 --> Output Class Initialized
INFO - 2023-05-19 17:05:50 --> Security Class Initialized
DEBUG - 2023-05-19 17:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:05:51 --> Input Class Initialized
INFO - 2023-05-19 17:05:51 --> Language Class Initialized
INFO - 2023-05-19 17:05:51 --> Loader Class Initialized
INFO - 2023-05-19 17:05:51 --> Helper loaded: url_helper
INFO - 2023-05-19 17:05:51 --> Helper loaded: form_helper
INFO - 2023-05-19 17:05:51 --> Helper loaded: file_helper
INFO - 2023-05-19 17:05:51 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:05:51 --> Form Validation Class Initialized
INFO - 2023-05-19 17:05:51 --> Upload Class Initialized
INFO - 2023-05-19 17:05:51 --> Model "M_auth" initialized
INFO - 2023-05-19 17:05:51 --> Model "M_user" initialized
INFO - 2023-05-19 17:05:51 --> Model "M_produk" initialized
INFO - 2023-05-19 17:05:51 --> Controller Class Initialized
INFO - 2023-05-19 17:05:51 --> Model "M_produk" initialized
INFO - 2023-05-19 17:05:51 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_edit_produk.php
INFO - 2023-05-19 17:05:51 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 17:05:51 --> Final output sent to browser
DEBUG - 2023-05-19 17:05:51 --> Total execution time: 0.1825
INFO - 2023-05-19 17:06:09 --> Config Class Initialized
INFO - 2023-05-19 17:06:09 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:06:09 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:06:09 --> Utf8 Class Initialized
INFO - 2023-05-19 17:06:09 --> URI Class Initialized
INFO - 2023-05-19 17:06:09 --> Router Class Initialized
INFO - 2023-05-19 17:06:09 --> Output Class Initialized
INFO - 2023-05-19 17:06:09 --> Security Class Initialized
DEBUG - 2023-05-19 17:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:06:09 --> Input Class Initialized
INFO - 2023-05-19 17:06:09 --> Language Class Initialized
INFO - 2023-05-19 17:06:09 --> Loader Class Initialized
INFO - 2023-05-19 17:06:09 --> Helper loaded: url_helper
INFO - 2023-05-19 17:06:09 --> Helper loaded: form_helper
INFO - 2023-05-19 17:06:09 --> Helper loaded: file_helper
INFO - 2023-05-19 17:06:09 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:06:09 --> Form Validation Class Initialized
INFO - 2023-05-19 17:06:09 --> Upload Class Initialized
INFO - 2023-05-19 17:06:09 --> Model "M_auth" initialized
INFO - 2023-05-19 17:06:09 --> Model "M_user" initialized
INFO - 2023-05-19 17:06:09 --> Model "M_produk" initialized
INFO - 2023-05-19 17:06:09 --> Controller Class Initialized
INFO - 2023-05-19 17:06:09 --> Model "M_produk" initialized
INFO - 2023-05-19 17:06:09 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-05-19 17:06:09 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 17:06:09 --> Final output sent to browser
DEBUG - 2023-05-19 17:06:09 --> Total execution time: 0.1330
INFO - 2023-05-19 17:08:19 --> Config Class Initialized
INFO - 2023-05-19 17:08:19 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:08:19 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:08:19 --> Utf8 Class Initialized
INFO - 2023-05-19 17:08:19 --> URI Class Initialized
INFO - 2023-05-19 17:08:19 --> Router Class Initialized
INFO - 2023-05-19 17:08:19 --> Output Class Initialized
INFO - 2023-05-19 17:08:19 --> Security Class Initialized
DEBUG - 2023-05-19 17:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:08:19 --> Input Class Initialized
INFO - 2023-05-19 17:08:19 --> Language Class Initialized
INFO - 2023-05-19 17:08:19 --> Loader Class Initialized
INFO - 2023-05-19 17:08:19 --> Helper loaded: url_helper
INFO - 2023-05-19 17:08:19 --> Helper loaded: form_helper
INFO - 2023-05-19 17:08:19 --> Helper loaded: file_helper
INFO - 2023-05-19 17:08:19 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:08:19 --> Form Validation Class Initialized
INFO - 2023-05-19 17:08:19 --> Upload Class Initialized
INFO - 2023-05-19 17:08:19 --> Model "M_auth" initialized
INFO - 2023-05-19 17:08:19 --> Model "M_user" initialized
INFO - 2023-05-19 17:08:19 --> Model "M_produk" initialized
INFO - 2023-05-19 17:08:19 --> Controller Class Initialized
INFO - 2023-05-19 17:08:19 --> Model "M_produk" initialized
INFO - 2023-05-19 17:08:19 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_edit_produk.php
INFO - 2023-05-19 17:08:19 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 17:08:19 --> Final output sent to browser
DEBUG - 2023-05-19 17:08:19 --> Total execution time: 0.2125
INFO - 2023-05-19 17:09:26 --> Config Class Initialized
INFO - 2023-05-19 17:09:26 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:09:26 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:09:26 --> Utf8 Class Initialized
INFO - 2023-05-19 17:09:26 --> URI Class Initialized
INFO - 2023-05-19 17:09:26 --> Router Class Initialized
INFO - 2023-05-19 17:09:26 --> Output Class Initialized
INFO - 2023-05-19 17:09:26 --> Security Class Initialized
DEBUG - 2023-05-19 17:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:09:26 --> Input Class Initialized
INFO - 2023-05-19 17:09:26 --> Language Class Initialized
INFO - 2023-05-19 17:09:26 --> Loader Class Initialized
INFO - 2023-05-19 17:09:26 --> Helper loaded: url_helper
INFO - 2023-05-19 17:09:26 --> Helper loaded: form_helper
INFO - 2023-05-19 17:09:26 --> Helper loaded: file_helper
INFO - 2023-05-19 17:09:27 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:09:27 --> Form Validation Class Initialized
INFO - 2023-05-19 17:09:27 --> Upload Class Initialized
INFO - 2023-05-19 17:09:27 --> Model "M_auth" initialized
INFO - 2023-05-19 17:09:27 --> Model "M_user" initialized
INFO - 2023-05-19 17:09:27 --> Model "M_produk" initialized
INFO - 2023-05-19 17:09:27 --> Controller Class Initialized
INFO - 2023-05-19 17:09:27 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 17:09:27 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_pelanggan.php
INFO - 2023-05-19 17:09:27 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 17:09:27 --> Final output sent to browser
DEBUG - 2023-05-19 17:09:27 --> Total execution time: 0.3488
INFO - 2023-05-19 17:09:35 --> Config Class Initialized
INFO - 2023-05-19 17:09:35 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:09:35 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:09:35 --> Utf8 Class Initialized
INFO - 2023-05-19 17:09:35 --> URI Class Initialized
INFO - 2023-05-19 17:09:35 --> Router Class Initialized
INFO - 2023-05-19 17:09:35 --> Output Class Initialized
INFO - 2023-05-19 17:09:35 --> Security Class Initialized
DEBUG - 2023-05-19 17:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:09:35 --> Input Class Initialized
INFO - 2023-05-19 17:09:35 --> Language Class Initialized
INFO - 2023-05-19 17:09:35 --> Loader Class Initialized
INFO - 2023-05-19 17:09:35 --> Helper loaded: url_helper
INFO - 2023-05-19 17:09:35 --> Helper loaded: form_helper
INFO - 2023-05-19 17:09:35 --> Helper loaded: file_helper
INFO - 2023-05-19 17:09:35 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:09:35 --> Form Validation Class Initialized
INFO - 2023-05-19 17:09:35 --> Upload Class Initialized
INFO - 2023-05-19 17:09:35 --> Model "M_auth" initialized
INFO - 2023-05-19 17:09:35 --> Model "M_user" initialized
INFO - 2023-05-19 17:09:35 --> Model "M_produk" initialized
INFO - 2023-05-19 17:09:35 --> Controller Class Initialized
INFO - 2023-05-19 17:09:35 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 17:09:35 --> Model "M_produk" initialized
DEBUG - 2023-05-19 17:09:35 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 17:09:35 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 17:09:35 --> Model "M_transaksi" initialized
INFO - 2023-05-19 17:09:35 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_transaksi_all.php
INFO - 2023-05-19 17:09:35 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 17:09:35 --> Final output sent to browser
DEBUG - 2023-05-19 17:09:35 --> Total execution time: 0.3965
INFO - 2023-05-19 17:09:42 --> Config Class Initialized
INFO - 2023-05-19 17:09:42 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:09:42 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:09:42 --> Utf8 Class Initialized
INFO - 2023-05-19 17:09:42 --> URI Class Initialized
INFO - 2023-05-19 17:09:42 --> Router Class Initialized
INFO - 2023-05-19 17:09:42 --> Output Class Initialized
INFO - 2023-05-19 17:09:42 --> Security Class Initialized
DEBUG - 2023-05-19 17:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:09:42 --> Input Class Initialized
INFO - 2023-05-19 17:09:42 --> Language Class Initialized
INFO - 2023-05-19 17:09:42 --> Loader Class Initialized
INFO - 2023-05-19 17:09:42 --> Helper loaded: url_helper
INFO - 2023-05-19 17:09:42 --> Helper loaded: form_helper
INFO - 2023-05-19 17:09:42 --> Helper loaded: file_helper
INFO - 2023-05-19 17:09:42 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:09:42 --> Form Validation Class Initialized
INFO - 2023-05-19 17:09:42 --> Upload Class Initialized
INFO - 2023-05-19 17:09:42 --> Model "M_auth" initialized
INFO - 2023-05-19 17:09:42 --> Model "M_user" initialized
INFO - 2023-05-19 17:09:42 --> Model "M_produk" initialized
INFO - 2023-05-19 17:09:42 --> Controller Class Initialized
INFO - 2023-05-19 17:09:42 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 17:09:42 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_pelanggan.php
INFO - 2023-05-19 17:09:42 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 17:09:42 --> Final output sent to browser
DEBUG - 2023-05-19 17:09:42 --> Total execution time: 0.1443
INFO - 2023-05-19 17:09:47 --> Config Class Initialized
INFO - 2023-05-19 17:09:47 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:09:47 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:09:47 --> Utf8 Class Initialized
INFO - 2023-05-19 17:09:47 --> URI Class Initialized
INFO - 2023-05-19 17:09:47 --> Router Class Initialized
INFO - 2023-05-19 17:09:47 --> Output Class Initialized
INFO - 2023-05-19 17:09:47 --> Security Class Initialized
DEBUG - 2023-05-19 17:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:09:47 --> Input Class Initialized
INFO - 2023-05-19 17:09:47 --> Language Class Initialized
INFO - 2023-05-19 17:09:47 --> Loader Class Initialized
INFO - 2023-05-19 17:09:47 --> Helper loaded: url_helper
INFO - 2023-05-19 17:09:47 --> Helper loaded: form_helper
INFO - 2023-05-19 17:09:47 --> Helper loaded: file_helper
INFO - 2023-05-19 17:09:47 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:09:47 --> Form Validation Class Initialized
INFO - 2023-05-19 17:09:47 --> Upload Class Initialized
INFO - 2023-05-19 17:09:47 --> Model "M_auth" initialized
INFO - 2023-05-19 17:09:47 --> Model "M_user" initialized
INFO - 2023-05-19 17:09:47 --> Model "M_produk" initialized
INFO - 2023-05-19 17:09:47 --> Controller Class Initialized
INFO - 2023-05-19 17:09:47 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 17:09:47 --> Model "M_produk" initialized
DEBUG - 2023-05-19 17:09:47 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 17:09:47 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 17:09:47 --> Model "M_transaksi" initialized
INFO - 2023-05-19 17:09:47 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_transaksi_all.php
INFO - 2023-05-19 17:09:47 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 17:09:47 --> Final output sent to browser
DEBUG - 2023-05-19 17:09:47 --> Total execution time: 0.1199
INFO - 2023-05-19 17:09:58 --> Config Class Initialized
INFO - 2023-05-19 17:09:58 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:09:58 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:09:58 --> Utf8 Class Initialized
INFO - 2023-05-19 17:09:58 --> URI Class Initialized
INFO - 2023-05-19 17:09:58 --> Router Class Initialized
INFO - 2023-05-19 17:09:58 --> Output Class Initialized
INFO - 2023-05-19 17:09:58 --> Security Class Initialized
DEBUG - 2023-05-19 17:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:09:58 --> Input Class Initialized
INFO - 2023-05-19 17:09:58 --> Language Class Initialized
INFO - 2023-05-19 17:09:58 --> Loader Class Initialized
INFO - 2023-05-19 17:09:58 --> Helper loaded: url_helper
INFO - 2023-05-19 17:09:58 --> Helper loaded: form_helper
INFO - 2023-05-19 17:09:58 --> Helper loaded: file_helper
INFO - 2023-05-19 17:09:58 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:09:58 --> Form Validation Class Initialized
INFO - 2023-05-19 17:09:58 --> Upload Class Initialized
INFO - 2023-05-19 17:09:58 --> Model "M_auth" initialized
INFO - 2023-05-19 17:09:58 --> Model "M_user" initialized
INFO - 2023-05-19 17:09:58 --> Model "M_produk" initialized
INFO - 2023-05-19 17:09:58 --> Controller Class Initialized
INFO - 2023-05-19 17:09:58 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 17:09:58 --> Model "M_produk" initialized
DEBUG - 2023-05-19 17:09:58 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 17:09:58 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 17:09:58 --> Model "M_transaksi" initialized
INFO - 2023-05-19 17:09:58 --> Model "M_bank" initialized
INFO - 2023-05-19 17:09:58 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_all_bank.php
INFO - 2023-05-19 17:09:58 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 17:09:58 --> Final output sent to browser
DEBUG - 2023-05-19 17:09:58 --> Total execution time: 0.2911
INFO - 2023-05-19 17:10:12 --> Config Class Initialized
INFO - 2023-05-19 17:10:12 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:10:12 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:10:12 --> Utf8 Class Initialized
INFO - 2023-05-19 17:10:12 --> URI Class Initialized
INFO - 2023-05-19 17:10:12 --> Router Class Initialized
INFO - 2023-05-19 17:10:12 --> Output Class Initialized
INFO - 2023-05-19 17:10:12 --> Security Class Initialized
DEBUG - 2023-05-19 17:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:10:12 --> Input Class Initialized
INFO - 2023-05-19 17:10:12 --> Language Class Initialized
INFO - 2023-05-19 17:10:12 --> Loader Class Initialized
INFO - 2023-05-19 17:10:12 --> Helper loaded: url_helper
INFO - 2023-05-19 17:10:12 --> Helper loaded: form_helper
INFO - 2023-05-19 17:10:12 --> Helper loaded: file_helper
INFO - 2023-05-19 17:10:12 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:10:12 --> Form Validation Class Initialized
INFO - 2023-05-19 17:10:12 --> Upload Class Initialized
INFO - 2023-05-19 17:10:12 --> Model "M_auth" initialized
INFO - 2023-05-19 17:10:12 --> Model "M_user" initialized
INFO - 2023-05-19 17:10:12 --> Model "M_produk" initialized
INFO - 2023-05-19 17:10:12 --> Controller Class Initialized
INFO - 2023-05-19 17:10:12 --> Model "M_produk" initialized
INFO - 2023-05-19 17:10:12 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-05-19 17:10:12 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 17:10:12 --> Final output sent to browser
DEBUG - 2023-05-19 17:10:12 --> Total execution time: 0.1475
INFO - 2023-05-19 17:10:49 --> Config Class Initialized
INFO - 2023-05-19 17:10:49 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:10:49 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:10:49 --> Utf8 Class Initialized
INFO - 2023-05-19 17:10:49 --> URI Class Initialized
INFO - 2023-05-19 17:10:49 --> Router Class Initialized
INFO - 2023-05-19 17:10:49 --> Output Class Initialized
INFO - 2023-05-19 17:10:49 --> Security Class Initialized
DEBUG - 2023-05-19 17:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:10:49 --> Input Class Initialized
INFO - 2023-05-19 17:10:49 --> Language Class Initialized
INFO - 2023-05-19 17:10:49 --> Loader Class Initialized
INFO - 2023-05-19 17:10:49 --> Helper loaded: url_helper
INFO - 2023-05-19 17:10:49 --> Helper loaded: form_helper
INFO - 2023-05-19 17:10:49 --> Helper loaded: file_helper
INFO - 2023-05-19 17:10:49 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:10:49 --> Form Validation Class Initialized
INFO - 2023-05-19 17:10:49 --> Upload Class Initialized
INFO - 2023-05-19 17:10:49 --> Model "M_auth" initialized
INFO - 2023-05-19 17:10:49 --> Model "M_user" initialized
INFO - 2023-05-19 17:10:49 --> Model "M_produk" initialized
INFO - 2023-05-19 17:10:49 --> Controller Class Initialized
INFO - 2023-05-19 17:10:49 --> Config Class Initialized
INFO - 2023-05-19 17:10:49 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:10:49 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:10:49 --> Utf8 Class Initialized
INFO - 2023-05-19 17:10:49 --> URI Class Initialized
INFO - 2023-05-19 17:10:49 --> Router Class Initialized
INFO - 2023-05-19 17:10:49 --> Output Class Initialized
INFO - 2023-05-19 17:10:49 --> Security Class Initialized
DEBUG - 2023-05-19 17:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:10:49 --> Input Class Initialized
INFO - 2023-05-19 17:10:49 --> Language Class Initialized
INFO - 2023-05-19 17:10:49 --> Loader Class Initialized
INFO - 2023-05-19 17:10:49 --> Helper loaded: url_helper
INFO - 2023-05-19 17:10:49 --> Helper loaded: form_helper
INFO - 2023-05-19 17:10:49 --> Helper loaded: file_helper
INFO - 2023-05-19 17:10:49 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:10:49 --> Form Validation Class Initialized
INFO - 2023-05-19 17:10:49 --> Upload Class Initialized
INFO - 2023-05-19 17:10:49 --> Model "M_auth" initialized
INFO - 2023-05-19 17:10:49 --> Model "M_user" initialized
INFO - 2023-05-19 17:10:49 --> Model "M_produk" initialized
INFO - 2023-05-19 17:10:49 --> Controller Class Initialized
INFO - 2023-05-19 17:10:49 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-05-19 17:10:49 --> Final output sent to browser
DEBUG - 2023-05-19 17:10:49 --> Total execution time: 0.1050
INFO - 2023-05-19 17:10:53 --> Config Class Initialized
INFO - 2023-05-19 17:10:53 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:10:53 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:10:53 --> Utf8 Class Initialized
INFO - 2023-05-19 17:10:53 --> URI Class Initialized
DEBUG - 2023-05-19 17:10:53 --> No URI present. Default controller set.
INFO - 2023-05-19 17:10:53 --> Router Class Initialized
INFO - 2023-05-19 17:10:53 --> Output Class Initialized
INFO - 2023-05-19 17:10:53 --> Security Class Initialized
DEBUG - 2023-05-19 17:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:10:53 --> Input Class Initialized
INFO - 2023-05-19 17:10:53 --> Language Class Initialized
INFO - 2023-05-19 17:10:53 --> Loader Class Initialized
INFO - 2023-05-19 17:10:53 --> Helper loaded: url_helper
INFO - 2023-05-19 17:10:53 --> Helper loaded: form_helper
INFO - 2023-05-19 17:10:53 --> Helper loaded: file_helper
INFO - 2023-05-19 17:10:53 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:10:54 --> Form Validation Class Initialized
INFO - 2023-05-19 17:10:54 --> Upload Class Initialized
INFO - 2023-05-19 17:10:54 --> Model "M_auth" initialized
INFO - 2023-05-19 17:10:54 --> Model "M_user" initialized
INFO - 2023-05-19 17:10:54 --> Model "M_produk" initialized
INFO - 2023-05-19 17:10:54 --> Controller Class Initialized
INFO - 2023-05-19 17:10:54 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 17:10:54 --> Model "M_produk" initialized
DEBUG - 2023-05-19 17:10:54 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 17:10:54 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 17:10:54 --> Model "M_transaksi" initialized
INFO - 2023-05-19 17:10:54 --> Model "M_bank" initialized
INFO - 2023-05-19 17:10:54 --> Model "M_pesan" initialized
INFO - 2023-05-19 17:10:54 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-05-19 17:10:54 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-05-19 17:10:54 --> Final output sent to browser
DEBUG - 2023-05-19 17:10:54 --> Total execution time: 0.1437
INFO - 2023-05-19 17:11:03 --> Config Class Initialized
INFO - 2023-05-19 17:11:03 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:11:03 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:11:03 --> Utf8 Class Initialized
INFO - 2023-05-19 17:11:03 --> URI Class Initialized
DEBUG - 2023-05-19 17:11:03 --> No URI present. Default controller set.
INFO - 2023-05-19 17:11:03 --> Router Class Initialized
INFO - 2023-05-19 17:11:03 --> Output Class Initialized
INFO - 2023-05-19 17:11:03 --> Security Class Initialized
DEBUG - 2023-05-19 17:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:11:03 --> Input Class Initialized
INFO - 2023-05-19 17:11:03 --> Language Class Initialized
INFO - 2023-05-19 17:11:03 --> Loader Class Initialized
INFO - 2023-05-19 17:11:03 --> Helper loaded: url_helper
INFO - 2023-05-19 17:11:03 --> Helper loaded: form_helper
INFO - 2023-05-19 17:11:03 --> Helper loaded: file_helper
INFO - 2023-05-19 17:11:03 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:11:03 --> Form Validation Class Initialized
INFO - 2023-05-19 17:11:03 --> Upload Class Initialized
INFO - 2023-05-19 17:11:03 --> Model "M_auth" initialized
INFO - 2023-05-19 17:11:03 --> Model "M_user" initialized
INFO - 2023-05-19 17:11:03 --> Model "M_produk" initialized
INFO - 2023-05-19 17:11:03 --> Controller Class Initialized
INFO - 2023-05-19 17:11:03 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 17:11:03 --> Model "M_produk" initialized
DEBUG - 2023-05-19 17:11:03 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 17:11:03 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 17:11:03 --> Model "M_transaksi" initialized
INFO - 2023-05-19 17:11:03 --> Model "M_bank" initialized
INFO - 2023-05-19 17:11:03 --> Model "M_pesan" initialized
INFO - 2023-05-19 17:11:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-05-19 17:11:03 --> Email Class Initialized
INFO - 2023-05-19 17:11:04 --> Language file loaded: language/english/email_lang.php
INFO - 2023-05-19 17:11:07 --> Config Class Initialized
INFO - 2023-05-19 17:11:07 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:11:07 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:11:07 --> Utf8 Class Initialized
INFO - 2023-05-19 17:11:07 --> URI Class Initialized
DEBUG - 2023-05-19 17:11:07 --> No URI present. Default controller set.
INFO - 2023-05-19 17:11:07 --> Router Class Initialized
INFO - 2023-05-19 17:11:07 --> Output Class Initialized
INFO - 2023-05-19 17:11:07 --> Security Class Initialized
DEBUG - 2023-05-19 17:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:11:07 --> Input Class Initialized
INFO - 2023-05-19 17:11:07 --> Language Class Initialized
INFO - 2023-05-19 17:11:07 --> Loader Class Initialized
INFO - 2023-05-19 17:11:07 --> Helper loaded: url_helper
INFO - 2023-05-19 17:11:07 --> Helper loaded: form_helper
INFO - 2023-05-19 17:11:07 --> Helper loaded: file_helper
INFO - 2023-05-19 17:11:07 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:11:07 --> Form Validation Class Initialized
INFO - 2023-05-19 17:11:07 --> Upload Class Initialized
INFO - 2023-05-19 17:11:07 --> Model "M_auth" initialized
INFO - 2023-05-19 17:11:07 --> Model "M_user" initialized
INFO - 2023-05-19 17:11:07 --> Model "M_produk" initialized
INFO - 2023-05-19 17:11:07 --> Controller Class Initialized
INFO - 2023-05-19 17:11:07 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 17:11:07 --> Model "M_produk" initialized
DEBUG - 2023-05-19 17:11:07 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 17:11:07 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 17:11:07 --> Model "M_transaksi" initialized
INFO - 2023-05-19 17:11:07 --> Model "M_bank" initialized
INFO - 2023-05-19 17:11:07 --> Model "M_pesan" initialized
INFO - 2023-05-19 17:11:07 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-05-19 17:11:07 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-05-19 17:11:07 --> Final output sent to browser
DEBUG - 2023-05-19 17:11:07 --> Total execution time: 0.1330
INFO - 2023-05-19 17:11:10 --> Config Class Initialized
INFO - 2023-05-19 17:11:10 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:11:10 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:11:10 --> Utf8 Class Initialized
INFO - 2023-05-19 17:11:10 --> URI Class Initialized
INFO - 2023-05-19 17:11:10 --> Router Class Initialized
INFO - 2023-05-19 17:11:10 --> Output Class Initialized
INFO - 2023-05-19 17:11:10 --> Security Class Initialized
DEBUG - 2023-05-19 17:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:11:10 --> Input Class Initialized
INFO - 2023-05-19 17:11:10 --> Language Class Initialized
INFO - 2023-05-19 17:11:10 --> Loader Class Initialized
INFO - 2023-05-19 17:11:10 --> Helper loaded: url_helper
INFO - 2023-05-19 17:11:11 --> Helper loaded: form_helper
INFO - 2023-05-19 17:11:11 --> Helper loaded: file_helper
INFO - 2023-05-19 17:11:11 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:11:11 --> Form Validation Class Initialized
INFO - 2023-05-19 17:11:11 --> Upload Class Initialized
INFO - 2023-05-19 17:11:11 --> Model "M_auth" initialized
INFO - 2023-05-19 17:11:11 --> Model "M_user" initialized
INFO - 2023-05-19 17:11:11 --> Model "M_produk" initialized
INFO - 2023-05-19 17:11:11 --> Controller Class Initialized
INFO - 2023-05-19 17:11:11 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 17:11:11 --> Model "M_produk" initialized
DEBUG - 2023-05-19 17:11:11 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 17:11:11 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 17:11:11 --> Model "M_transaksi" initialized
INFO - 2023-05-19 17:11:11 --> Model "M_bank" initialized
INFO - 2023-05-19 17:11:11 --> Model "M_pesan" initialized
INFO - 2023-05-19 17:11:11 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-05-19 17:11:11 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-05-19 17:11:11 --> Final output sent to browser
DEBUG - 2023-05-19 17:11:11 --> Total execution time: 0.1916
INFO - 2023-05-19 17:14:22 --> Config Class Initialized
INFO - 2023-05-19 17:14:22 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:14:22 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:14:22 --> Utf8 Class Initialized
INFO - 2023-05-19 17:14:22 --> URI Class Initialized
INFO - 2023-05-19 17:14:22 --> Router Class Initialized
INFO - 2023-05-19 17:14:22 --> Output Class Initialized
INFO - 2023-05-19 17:14:22 --> Security Class Initialized
DEBUG - 2023-05-19 17:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:14:22 --> Input Class Initialized
INFO - 2023-05-19 17:14:22 --> Language Class Initialized
INFO - 2023-05-19 17:14:22 --> Loader Class Initialized
INFO - 2023-05-19 17:14:22 --> Helper loaded: url_helper
INFO - 2023-05-19 17:14:22 --> Helper loaded: form_helper
INFO - 2023-05-19 17:14:22 --> Helper loaded: file_helper
INFO - 2023-05-19 17:14:22 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:14:22 --> Form Validation Class Initialized
INFO - 2023-05-19 17:14:22 --> Upload Class Initialized
INFO - 2023-05-19 17:14:22 --> Model "M_auth" initialized
INFO - 2023-05-19 17:14:22 --> Model "M_user" initialized
INFO - 2023-05-19 17:14:22 --> Model "M_produk" initialized
INFO - 2023-05-19 17:14:22 --> Controller Class Initialized
INFO - 2023-05-19 17:14:22 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 17:14:22 --> Model "M_produk" initialized
DEBUG - 2023-05-19 17:14:22 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 17:14:22 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 17:14:22 --> Model "M_transaksi" initialized
INFO - 2023-05-19 17:14:22 --> Model "M_bank" initialized
INFO - 2023-05-19 17:14:22 --> Model "M_pesan" initialized
INFO - 2023-05-19 17:14:22 --> Config Class Initialized
INFO - 2023-05-19 17:14:22 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:14:22 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:14:22 --> Utf8 Class Initialized
INFO - 2023-05-19 17:14:22 --> URI Class Initialized
DEBUG - 2023-05-19 17:14:22 --> No URI present. Default controller set.
INFO - 2023-05-19 17:14:22 --> Router Class Initialized
INFO - 2023-05-19 17:14:22 --> Output Class Initialized
INFO - 2023-05-19 17:14:22 --> Security Class Initialized
DEBUG - 2023-05-19 17:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:14:22 --> Input Class Initialized
INFO - 2023-05-19 17:14:22 --> Language Class Initialized
INFO - 2023-05-19 17:14:22 --> Loader Class Initialized
INFO - 2023-05-19 17:14:22 --> Helper loaded: url_helper
INFO - 2023-05-19 17:14:22 --> Helper loaded: form_helper
INFO - 2023-05-19 17:14:22 --> Helper loaded: file_helper
INFO - 2023-05-19 17:14:22 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:14:22 --> Form Validation Class Initialized
INFO - 2023-05-19 17:14:22 --> Upload Class Initialized
INFO - 2023-05-19 17:14:22 --> Model "M_auth" initialized
INFO - 2023-05-19 17:14:22 --> Model "M_user" initialized
INFO - 2023-05-19 17:14:22 --> Model "M_produk" initialized
INFO - 2023-05-19 17:14:22 --> Controller Class Initialized
INFO - 2023-05-19 17:14:22 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 17:14:22 --> Model "M_produk" initialized
DEBUG - 2023-05-19 17:14:22 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 17:14:22 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 17:14:22 --> Model "M_transaksi" initialized
INFO - 2023-05-19 17:14:22 --> Model "M_bank" initialized
INFO - 2023-05-19 17:14:22 --> Model "M_pesan" initialized
INFO - 2023-05-19 17:14:22 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-05-19 17:14:22 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-05-19 17:14:22 --> Final output sent to browser
DEBUG - 2023-05-19 17:14:22 --> Total execution time: 0.1327
INFO - 2023-05-19 17:14:30 --> Config Class Initialized
INFO - 2023-05-19 17:14:30 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:14:30 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:14:30 --> Utf8 Class Initialized
INFO - 2023-05-19 17:14:30 --> URI Class Initialized
INFO - 2023-05-19 17:14:30 --> Router Class Initialized
INFO - 2023-05-19 17:14:30 --> Output Class Initialized
INFO - 2023-05-19 17:14:30 --> Security Class Initialized
DEBUG - 2023-05-19 17:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:14:30 --> Input Class Initialized
INFO - 2023-05-19 17:14:30 --> Language Class Initialized
INFO - 2023-05-19 17:14:30 --> Loader Class Initialized
INFO - 2023-05-19 17:14:30 --> Helper loaded: url_helper
INFO - 2023-05-19 17:14:30 --> Helper loaded: form_helper
INFO - 2023-05-19 17:14:30 --> Helper loaded: file_helper
INFO - 2023-05-19 17:14:30 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:14:30 --> Form Validation Class Initialized
INFO - 2023-05-19 17:14:30 --> Upload Class Initialized
INFO - 2023-05-19 17:14:30 --> Model "M_auth" initialized
INFO - 2023-05-19 17:14:30 --> Model "M_user" initialized
INFO - 2023-05-19 17:14:30 --> Model "M_produk" initialized
INFO - 2023-05-19 17:14:30 --> Controller Class Initialized
INFO - 2023-05-19 17:14:30 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-05-19 17:14:30 --> Final output sent to browser
DEBUG - 2023-05-19 17:14:30 --> Total execution time: 0.1626
INFO - 2023-05-19 17:14:39 --> Config Class Initialized
INFO - 2023-05-19 17:14:39 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:14:39 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:14:39 --> Utf8 Class Initialized
INFO - 2023-05-19 17:14:39 --> URI Class Initialized
INFO - 2023-05-19 17:14:39 --> Router Class Initialized
INFO - 2023-05-19 17:14:39 --> Output Class Initialized
INFO - 2023-05-19 17:14:39 --> Security Class Initialized
DEBUG - 2023-05-19 17:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:14:39 --> Input Class Initialized
INFO - 2023-05-19 17:14:39 --> Language Class Initialized
INFO - 2023-05-19 17:14:39 --> Loader Class Initialized
INFO - 2023-05-19 17:14:39 --> Helper loaded: url_helper
INFO - 2023-05-19 17:14:39 --> Helper loaded: form_helper
INFO - 2023-05-19 17:14:39 --> Helper loaded: file_helper
INFO - 2023-05-19 17:14:39 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:14:39 --> Form Validation Class Initialized
INFO - 2023-05-19 17:14:39 --> Upload Class Initialized
INFO - 2023-05-19 17:14:39 --> Model "M_auth" initialized
INFO - 2023-05-19 17:14:39 --> Model "M_user" initialized
INFO - 2023-05-19 17:14:39 --> Model "M_produk" initialized
INFO - 2023-05-19 17:14:39 --> Controller Class Initialized
INFO - 2023-05-19 17:14:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-05-19 17:14:40 --> Config Class Initialized
INFO - 2023-05-19 17:14:40 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:14:40 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:14:40 --> Utf8 Class Initialized
INFO - 2023-05-19 17:14:40 --> URI Class Initialized
INFO - 2023-05-19 17:14:40 --> Router Class Initialized
INFO - 2023-05-19 17:14:40 --> Output Class Initialized
INFO - 2023-05-19 17:14:40 --> Security Class Initialized
DEBUG - 2023-05-19 17:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:14:40 --> Input Class Initialized
INFO - 2023-05-19 17:14:40 --> Language Class Initialized
INFO - 2023-05-19 17:14:40 --> Loader Class Initialized
INFO - 2023-05-19 17:14:40 --> Helper loaded: url_helper
INFO - 2023-05-19 17:14:40 --> Helper loaded: form_helper
INFO - 2023-05-19 17:14:40 --> Helper loaded: file_helper
INFO - 2023-05-19 17:14:40 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:14:40 --> Form Validation Class Initialized
INFO - 2023-05-19 17:14:40 --> Upload Class Initialized
INFO - 2023-05-19 17:14:40 --> Model "M_auth" initialized
INFO - 2023-05-19 17:14:40 --> Model "M_user" initialized
INFO - 2023-05-19 17:14:40 --> Model "M_produk" initialized
INFO - 2023-05-19 17:14:40 --> Controller Class Initialized
INFO - 2023-05-19 17:14:40 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-05-19 17:14:40 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 17:14:40 --> Final output sent to browser
DEBUG - 2023-05-19 17:14:40 --> Total execution time: 0.1232
INFO - 2023-05-19 17:14:47 --> Config Class Initialized
INFO - 2023-05-19 17:14:47 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:14:47 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:14:47 --> Utf8 Class Initialized
INFO - 2023-05-19 17:14:47 --> URI Class Initialized
INFO - 2023-05-19 17:14:47 --> Router Class Initialized
INFO - 2023-05-19 17:14:47 --> Output Class Initialized
INFO - 2023-05-19 17:14:47 --> Security Class Initialized
DEBUG - 2023-05-19 17:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:14:47 --> Input Class Initialized
INFO - 2023-05-19 17:14:47 --> Language Class Initialized
INFO - 2023-05-19 17:14:47 --> Loader Class Initialized
INFO - 2023-05-19 17:14:47 --> Helper loaded: url_helper
INFO - 2023-05-19 17:14:47 --> Helper loaded: form_helper
INFO - 2023-05-19 17:14:47 --> Helper loaded: file_helper
INFO - 2023-05-19 17:14:47 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:14:47 --> Form Validation Class Initialized
INFO - 2023-05-19 17:14:47 --> Upload Class Initialized
INFO - 2023-05-19 17:14:47 --> Model "M_auth" initialized
INFO - 2023-05-19 17:14:47 --> Model "M_user" initialized
INFO - 2023-05-19 17:14:47 --> Model "M_produk" initialized
INFO - 2023-05-19 17:14:47 --> Controller Class Initialized
INFO - 2023-05-19 17:14:47 --> Model "M_produk" initialized
INFO - 2023-05-19 17:14:47 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_typeproduk.php
INFO - 2023-05-19 17:14:47 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 17:14:47 --> Final output sent to browser
DEBUG - 2023-05-19 17:14:47 --> Total execution time: 0.1287
INFO - 2023-05-19 17:14:52 --> Config Class Initialized
INFO - 2023-05-19 17:14:52 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:14:52 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:14:52 --> Utf8 Class Initialized
INFO - 2023-05-19 17:14:52 --> URI Class Initialized
INFO - 2023-05-19 17:14:52 --> Router Class Initialized
INFO - 2023-05-19 17:14:52 --> Output Class Initialized
INFO - 2023-05-19 17:14:52 --> Security Class Initialized
DEBUG - 2023-05-19 17:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:14:52 --> Input Class Initialized
INFO - 2023-05-19 17:14:52 --> Language Class Initialized
INFO - 2023-05-19 17:14:52 --> Loader Class Initialized
INFO - 2023-05-19 17:14:52 --> Helper loaded: url_helper
INFO - 2023-05-19 17:14:52 --> Helper loaded: form_helper
INFO - 2023-05-19 17:14:52 --> Helper loaded: file_helper
INFO - 2023-05-19 17:14:52 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:14:52 --> Form Validation Class Initialized
INFO - 2023-05-19 17:14:52 --> Upload Class Initialized
INFO - 2023-05-19 17:14:52 --> Model "M_auth" initialized
INFO - 2023-05-19 17:14:52 --> Model "M_user" initialized
INFO - 2023-05-19 17:14:52 --> Model "M_produk" initialized
INFO - 2023-05-19 17:14:52 --> Controller Class Initialized
INFO - 2023-05-19 17:14:52 --> Model "M_produk" initialized
INFO - 2023-05-19 17:14:52 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_type_merek.php
INFO - 2023-05-19 17:14:52 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 17:14:52 --> Final output sent to browser
DEBUG - 2023-05-19 17:14:52 --> Total execution time: 0.1138
INFO - 2023-05-19 17:14:59 --> Config Class Initialized
INFO - 2023-05-19 17:14:59 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:14:59 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:14:59 --> Utf8 Class Initialized
INFO - 2023-05-19 17:14:59 --> URI Class Initialized
INFO - 2023-05-19 17:14:59 --> Router Class Initialized
INFO - 2023-05-19 17:14:59 --> Output Class Initialized
INFO - 2023-05-19 17:14:59 --> Security Class Initialized
DEBUG - 2023-05-19 17:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:14:59 --> Input Class Initialized
INFO - 2023-05-19 17:14:59 --> Language Class Initialized
INFO - 2023-05-19 17:14:59 --> Loader Class Initialized
INFO - 2023-05-19 17:14:59 --> Helper loaded: url_helper
INFO - 2023-05-19 17:14:59 --> Helper loaded: form_helper
INFO - 2023-05-19 17:14:59 --> Helper loaded: file_helper
INFO - 2023-05-19 17:14:59 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:14:59 --> Form Validation Class Initialized
INFO - 2023-05-19 17:14:59 --> Upload Class Initialized
INFO - 2023-05-19 17:14:59 --> Model "M_auth" initialized
INFO - 2023-05-19 17:14:59 --> Model "M_user" initialized
INFO - 2023-05-19 17:14:59 --> Model "M_produk" initialized
INFO - 2023-05-19 17:14:59 --> Controller Class Initialized
INFO - 2023-05-19 17:14:59 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_user_profile.php
INFO - 2023-05-19 17:14:59 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 17:14:59 --> Final output sent to browser
DEBUG - 2023-05-19 17:14:59 --> Total execution time: 0.2194
INFO - 2023-05-19 17:15:03 --> Config Class Initialized
INFO - 2023-05-19 17:15:03 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:15:03 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:15:03 --> Utf8 Class Initialized
INFO - 2023-05-19 17:15:03 --> URI Class Initialized
INFO - 2023-05-19 17:15:03 --> Router Class Initialized
INFO - 2023-05-19 17:15:03 --> Output Class Initialized
INFO - 2023-05-19 17:15:03 --> Security Class Initialized
DEBUG - 2023-05-19 17:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:15:03 --> Input Class Initialized
INFO - 2023-05-19 17:15:03 --> Language Class Initialized
INFO - 2023-05-19 17:15:03 --> Loader Class Initialized
INFO - 2023-05-19 17:15:03 --> Helper loaded: url_helper
INFO - 2023-05-19 17:15:03 --> Helper loaded: form_helper
INFO - 2023-05-19 17:15:03 --> Helper loaded: file_helper
INFO - 2023-05-19 17:15:03 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:15:03 --> Form Validation Class Initialized
INFO - 2023-05-19 17:15:03 --> Upload Class Initialized
INFO - 2023-05-19 17:15:03 --> Model "M_auth" initialized
INFO - 2023-05-19 17:15:03 --> Model "M_user" initialized
INFO - 2023-05-19 17:15:03 --> Model "M_produk" initialized
INFO - 2023-05-19 17:15:03 --> Controller Class Initialized
INFO - 2023-05-19 17:15:03 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_user.php
INFO - 2023-05-19 17:15:03 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 17:15:03 --> Final output sent to browser
DEBUG - 2023-05-19 17:15:03 --> Total execution time: 0.2012
INFO - 2023-05-19 17:23:27 --> Config Class Initialized
INFO - 2023-05-19 17:23:27 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:23:27 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:23:27 --> Utf8 Class Initialized
INFO - 2023-05-19 17:23:27 --> URI Class Initialized
INFO - 2023-05-19 17:23:27 --> Router Class Initialized
INFO - 2023-05-19 17:23:27 --> Output Class Initialized
INFO - 2023-05-19 17:23:27 --> Security Class Initialized
DEBUG - 2023-05-19 17:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:23:27 --> Input Class Initialized
INFO - 2023-05-19 17:23:27 --> Language Class Initialized
INFO - 2023-05-19 17:23:27 --> Loader Class Initialized
INFO - 2023-05-19 17:23:27 --> Helper loaded: url_helper
INFO - 2023-05-19 17:23:27 --> Helper loaded: form_helper
INFO - 2023-05-19 17:23:27 --> Helper loaded: file_helper
INFO - 2023-05-19 17:23:27 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:23:27 --> Form Validation Class Initialized
INFO - 2023-05-19 17:23:27 --> Upload Class Initialized
INFO - 2023-05-19 17:23:27 --> Model "M_auth" initialized
INFO - 2023-05-19 17:23:27 --> Model "M_user" initialized
INFO - 2023-05-19 17:23:27 --> Model "M_produk" initialized
INFO - 2023-05-19 17:23:27 --> Controller Class Initialized
INFO - 2023-05-19 17:23:27 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 17:23:27 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_pelanggan.php
INFO - 2023-05-19 17:23:27 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 17:23:27 --> Final output sent to browser
DEBUG - 2023-05-19 17:23:27 --> Total execution time: 0.1337
INFO - 2023-05-19 17:23:29 --> Config Class Initialized
INFO - 2023-05-19 17:23:29 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:23:29 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:23:29 --> Utf8 Class Initialized
INFO - 2023-05-19 17:23:29 --> URI Class Initialized
INFO - 2023-05-19 17:23:29 --> Router Class Initialized
INFO - 2023-05-19 17:23:29 --> Output Class Initialized
INFO - 2023-05-19 17:23:29 --> Security Class Initialized
DEBUG - 2023-05-19 17:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:23:29 --> Input Class Initialized
INFO - 2023-05-19 17:23:29 --> Language Class Initialized
INFO - 2023-05-19 17:23:29 --> Loader Class Initialized
INFO - 2023-05-19 17:23:29 --> Helper loaded: url_helper
INFO - 2023-05-19 17:23:29 --> Helper loaded: form_helper
INFO - 2023-05-19 17:23:29 --> Helper loaded: file_helper
INFO - 2023-05-19 17:23:29 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:23:29 --> Form Validation Class Initialized
INFO - 2023-05-19 17:23:29 --> Upload Class Initialized
INFO - 2023-05-19 17:23:29 --> Model "M_auth" initialized
INFO - 2023-05-19 17:23:29 --> Model "M_user" initialized
INFO - 2023-05-19 17:23:29 --> Model "M_produk" initialized
INFO - 2023-05-19 17:23:29 --> Controller Class Initialized
INFO - 2023-05-19 17:23:29 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 17:23:29 --> Model "M_produk" initialized
DEBUG - 2023-05-19 17:23:29 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 17:23:29 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 17:23:29 --> Model "M_transaksi" initialized
INFO - 2023-05-19 17:23:29 --> Model "M_bank" initialized
INFO - 2023-05-19 17:23:29 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_all_bank.php
INFO - 2023-05-19 17:23:29 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 17:23:29 --> Final output sent to browser
DEBUG - 2023-05-19 17:23:29 --> Total execution time: 0.1654
INFO - 2023-05-19 17:23:32 --> Config Class Initialized
INFO - 2023-05-19 17:23:32 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:23:32 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:23:32 --> Utf8 Class Initialized
INFO - 2023-05-19 17:23:32 --> URI Class Initialized
INFO - 2023-05-19 17:23:32 --> Router Class Initialized
INFO - 2023-05-19 17:23:32 --> Output Class Initialized
INFO - 2023-05-19 17:23:32 --> Security Class Initialized
DEBUG - 2023-05-19 17:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:23:32 --> Input Class Initialized
INFO - 2023-05-19 17:23:32 --> Language Class Initialized
INFO - 2023-05-19 17:23:32 --> Loader Class Initialized
INFO - 2023-05-19 17:23:32 --> Helper loaded: url_helper
INFO - 2023-05-19 17:23:32 --> Helper loaded: form_helper
INFO - 2023-05-19 17:23:32 --> Helper loaded: file_helper
INFO - 2023-05-19 17:23:32 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:23:32 --> Form Validation Class Initialized
INFO - 2023-05-19 17:23:32 --> Upload Class Initialized
INFO - 2023-05-19 17:23:32 --> Model "M_auth" initialized
INFO - 2023-05-19 17:23:32 --> Model "M_user" initialized
INFO - 2023-05-19 17:23:32 --> Model "M_produk" initialized
INFO - 2023-05-19 17:23:32 --> Controller Class Initialized
INFO - 2023-05-19 17:23:32 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 17:23:32 --> Model "M_produk" initialized
DEBUG - 2023-05-19 17:23:32 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 17:23:32 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 17:23:32 --> Model "M_transaksi" initialized
INFO - 2023-05-19 17:23:32 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_transaksi_all.php
INFO - 2023-05-19 17:23:32 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 17:23:32 --> Final output sent to browser
DEBUG - 2023-05-19 17:23:32 --> Total execution time: 0.1628
INFO - 2023-05-19 17:23:39 --> Config Class Initialized
INFO - 2023-05-19 17:23:39 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:23:39 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:23:39 --> Utf8 Class Initialized
INFO - 2023-05-19 17:23:39 --> URI Class Initialized
INFO - 2023-05-19 17:23:39 --> Router Class Initialized
INFO - 2023-05-19 17:23:39 --> Output Class Initialized
INFO - 2023-05-19 17:23:39 --> Security Class Initialized
DEBUG - 2023-05-19 17:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:23:39 --> Input Class Initialized
INFO - 2023-05-19 17:23:39 --> Language Class Initialized
INFO - 2023-05-19 17:23:39 --> Loader Class Initialized
INFO - 2023-05-19 17:23:39 --> Helper loaded: url_helper
INFO - 2023-05-19 17:23:39 --> Helper loaded: form_helper
INFO - 2023-05-19 17:23:39 --> Helper loaded: file_helper
INFO - 2023-05-19 17:23:39 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:23:39 --> Form Validation Class Initialized
INFO - 2023-05-19 17:23:39 --> Upload Class Initialized
INFO - 2023-05-19 17:23:39 --> Model "M_auth" initialized
INFO - 2023-05-19 17:23:39 --> Model "M_user" initialized
INFO - 2023-05-19 17:23:39 --> Model "M_produk" initialized
INFO - 2023-05-19 17:23:39 --> Controller Class Initialized
INFO - 2023-05-19 17:23:39 --> Model "M_produk" initialized
INFO - 2023-05-19 17:23:39 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_type_merek.php
INFO - 2023-05-19 17:23:39 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 17:23:39 --> Final output sent to browser
DEBUG - 2023-05-19 17:23:39 --> Total execution time: 0.1437
INFO - 2023-05-19 17:24:01 --> Config Class Initialized
INFO - 2023-05-19 17:24:01 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:24:01 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:24:01 --> Utf8 Class Initialized
INFO - 2023-05-19 17:24:01 --> URI Class Initialized
INFO - 2023-05-19 17:24:01 --> Router Class Initialized
INFO - 2023-05-19 17:24:01 --> Output Class Initialized
INFO - 2023-05-19 17:24:01 --> Security Class Initialized
DEBUG - 2023-05-19 17:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:24:01 --> Input Class Initialized
INFO - 2023-05-19 17:24:01 --> Language Class Initialized
INFO - 2023-05-19 17:24:01 --> Loader Class Initialized
INFO - 2023-05-19 17:24:01 --> Helper loaded: url_helper
INFO - 2023-05-19 17:24:01 --> Helper loaded: form_helper
INFO - 2023-05-19 17:24:01 --> Helper loaded: file_helper
INFO - 2023-05-19 17:24:01 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:24:01 --> Form Validation Class Initialized
INFO - 2023-05-19 17:24:01 --> Upload Class Initialized
INFO - 2023-05-19 17:24:01 --> Model "M_auth" initialized
INFO - 2023-05-19 17:24:01 --> Model "M_user" initialized
INFO - 2023-05-19 17:24:01 --> Model "M_produk" initialized
INFO - 2023-05-19 17:24:01 --> Controller Class Initialized
INFO - 2023-05-19 17:24:01 --> Model "M_pesan" initialized
INFO - 2023-05-19 17:24:01 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_pengaduan.php
INFO - 2023-05-19 17:24:01 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 17:24:01 --> Final output sent to browser
DEBUG - 2023-05-19 17:24:01 --> Total execution time: 0.1306
INFO - 2023-05-19 17:24:35 --> Config Class Initialized
INFO - 2023-05-19 17:24:35 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:24:35 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:24:35 --> Utf8 Class Initialized
INFO - 2023-05-19 17:24:35 --> URI Class Initialized
INFO - 2023-05-19 17:24:35 --> Router Class Initialized
INFO - 2023-05-19 17:24:35 --> Output Class Initialized
INFO - 2023-05-19 17:24:35 --> Security Class Initialized
DEBUG - 2023-05-19 17:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:24:35 --> Input Class Initialized
INFO - 2023-05-19 17:24:35 --> Language Class Initialized
INFO - 2023-05-19 17:24:35 --> Loader Class Initialized
INFO - 2023-05-19 17:24:35 --> Helper loaded: url_helper
INFO - 2023-05-19 17:24:35 --> Helper loaded: form_helper
INFO - 2023-05-19 17:24:35 --> Helper loaded: file_helper
INFO - 2023-05-19 17:24:35 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:24:35 --> Form Validation Class Initialized
INFO - 2023-05-19 17:24:35 --> Upload Class Initialized
INFO - 2023-05-19 17:24:35 --> Model "M_auth" initialized
INFO - 2023-05-19 17:24:35 --> Model "M_user" initialized
INFO - 2023-05-19 17:24:35 --> Model "M_produk" initialized
INFO - 2023-05-19 17:24:35 --> Controller Class Initialized
INFO - 2023-05-19 17:24:35 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_user.php
INFO - 2023-05-19 17:24:35 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 17:24:35 --> Final output sent to browser
DEBUG - 2023-05-19 17:24:35 --> Total execution time: 0.1412
INFO - 2023-05-19 17:26:55 --> Config Class Initialized
INFO - 2023-05-19 17:26:55 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:26:55 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:26:55 --> Utf8 Class Initialized
INFO - 2023-05-19 17:26:55 --> URI Class Initialized
INFO - 2023-05-19 17:26:55 --> Router Class Initialized
INFO - 2023-05-19 17:26:55 --> Output Class Initialized
INFO - 2023-05-19 17:26:55 --> Security Class Initialized
DEBUG - 2023-05-19 17:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:26:55 --> Input Class Initialized
INFO - 2023-05-19 17:26:55 --> Language Class Initialized
INFO - 2023-05-19 17:26:55 --> Loader Class Initialized
INFO - 2023-05-19 17:26:55 --> Helper loaded: url_helper
INFO - 2023-05-19 17:26:55 --> Helper loaded: form_helper
INFO - 2023-05-19 17:26:55 --> Helper loaded: file_helper
INFO - 2023-05-19 17:26:55 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:26:55 --> Form Validation Class Initialized
INFO - 2023-05-19 17:26:55 --> Upload Class Initialized
INFO - 2023-05-19 17:26:55 --> Model "M_auth" initialized
INFO - 2023-05-19 17:26:55 --> Model "M_user" initialized
INFO - 2023-05-19 17:26:55 --> Model "M_produk" initialized
INFO - 2023-05-19 17:26:55 --> Controller Class Initialized
INFO - 2023-05-19 17:26:55 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_user_profile.php
INFO - 2023-05-19 17:26:55 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 17:26:55 --> Final output sent to browser
DEBUG - 2023-05-19 17:26:55 --> Total execution time: 0.2155
INFO - 2023-05-19 17:27:01 --> Config Class Initialized
INFO - 2023-05-19 17:27:01 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:27:01 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:27:01 --> Utf8 Class Initialized
INFO - 2023-05-19 17:27:01 --> URI Class Initialized
INFO - 2023-05-19 17:27:01 --> Router Class Initialized
INFO - 2023-05-19 17:27:01 --> Output Class Initialized
INFO - 2023-05-19 17:27:01 --> Security Class Initialized
DEBUG - 2023-05-19 17:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:27:01 --> Input Class Initialized
INFO - 2023-05-19 17:27:01 --> Language Class Initialized
INFO - 2023-05-19 17:27:01 --> Loader Class Initialized
INFO - 2023-05-19 17:27:01 --> Helper loaded: url_helper
INFO - 2023-05-19 17:27:01 --> Helper loaded: form_helper
INFO - 2023-05-19 17:27:01 --> Helper loaded: file_helper
INFO - 2023-05-19 17:27:01 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:27:01 --> Form Validation Class Initialized
INFO - 2023-05-19 17:27:01 --> Upload Class Initialized
INFO - 2023-05-19 17:27:01 --> Model "M_auth" initialized
INFO - 2023-05-19 17:27:01 --> Model "M_user" initialized
INFO - 2023-05-19 17:27:01 --> Model "M_produk" initialized
INFO - 2023-05-19 17:27:01 --> Controller Class Initialized
INFO - 2023-05-19 17:27:01 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_user.php
INFO - 2023-05-19 17:27:01 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 17:27:01 --> Final output sent to browser
DEBUG - 2023-05-19 17:27:01 --> Total execution time: 0.1402
INFO - 2023-05-19 17:27:12 --> Config Class Initialized
INFO - 2023-05-19 17:27:12 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:27:12 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:27:12 --> Utf8 Class Initialized
INFO - 2023-05-19 17:27:12 --> URI Class Initialized
INFO - 2023-05-19 17:27:12 --> Router Class Initialized
INFO - 2023-05-19 17:27:12 --> Output Class Initialized
INFO - 2023-05-19 17:27:12 --> Security Class Initialized
DEBUG - 2023-05-19 17:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:27:12 --> Input Class Initialized
INFO - 2023-05-19 17:27:12 --> Language Class Initialized
INFO - 2023-05-19 17:27:12 --> Loader Class Initialized
INFO - 2023-05-19 17:27:12 --> Helper loaded: url_helper
INFO - 2023-05-19 17:27:12 --> Helper loaded: form_helper
INFO - 2023-05-19 17:27:12 --> Helper loaded: file_helper
INFO - 2023-05-19 17:27:12 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:27:12 --> Form Validation Class Initialized
INFO - 2023-05-19 17:27:12 --> Upload Class Initialized
INFO - 2023-05-19 17:27:12 --> Model "M_auth" initialized
INFO - 2023-05-19 17:27:12 --> Model "M_user" initialized
INFO - 2023-05-19 17:27:12 --> Model "M_produk" initialized
INFO - 2023-05-19 17:27:12 --> Controller Class Initialized
INFO - 2023-05-19 17:27:12 --> Model "M_produk" initialized
INFO - 2023-05-19 17:27:12 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-05-19 17:27:12 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-19 17:27:12 --> Final output sent to browser
DEBUG - 2023-05-19 17:27:12 --> Total execution time: 0.1462
INFO - 2023-05-19 17:28:28 --> Config Class Initialized
INFO - 2023-05-19 17:28:28 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:28:28 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:28:28 --> Utf8 Class Initialized
INFO - 2023-05-19 17:28:28 --> URI Class Initialized
DEBUG - 2023-05-19 17:28:28 --> No URI present. Default controller set.
INFO - 2023-05-19 17:28:28 --> Router Class Initialized
INFO - 2023-05-19 17:28:28 --> Output Class Initialized
INFO - 2023-05-19 17:28:28 --> Security Class Initialized
DEBUG - 2023-05-19 17:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:28:28 --> Input Class Initialized
INFO - 2023-05-19 17:28:28 --> Language Class Initialized
INFO - 2023-05-19 17:28:28 --> Loader Class Initialized
INFO - 2023-05-19 17:28:28 --> Helper loaded: url_helper
INFO - 2023-05-19 17:28:28 --> Helper loaded: form_helper
INFO - 2023-05-19 17:28:28 --> Helper loaded: file_helper
INFO - 2023-05-19 17:28:28 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:28:28 --> Form Validation Class Initialized
INFO - 2023-05-19 17:28:28 --> Upload Class Initialized
INFO - 2023-05-19 17:28:28 --> Model "M_auth" initialized
INFO - 2023-05-19 17:28:28 --> Model "M_user" initialized
INFO - 2023-05-19 17:28:28 --> Model "M_produk" initialized
INFO - 2023-05-19 17:28:28 --> Controller Class Initialized
INFO - 2023-05-19 17:28:28 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 17:28:28 --> Model "M_produk" initialized
DEBUG - 2023-05-19 17:28:28 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 17:28:28 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 17:28:28 --> Model "M_transaksi" initialized
INFO - 2023-05-19 17:28:28 --> Model "M_bank" initialized
INFO - 2023-05-19 17:28:28 --> Model "M_pesan" initialized
INFO - 2023-05-19 17:28:28 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-05-19 17:28:28 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-05-19 17:28:28 --> Final output sent to browser
DEBUG - 2023-05-19 17:28:28 --> Total execution time: 0.2263
INFO - 2023-05-19 17:28:36 --> Config Class Initialized
INFO - 2023-05-19 17:28:36 --> Hooks Class Initialized
DEBUG - 2023-05-19 17:28:36 --> UTF-8 Support Enabled
INFO - 2023-05-19 17:28:36 --> Utf8 Class Initialized
INFO - 2023-05-19 17:28:36 --> URI Class Initialized
INFO - 2023-05-19 17:28:36 --> Router Class Initialized
INFO - 2023-05-19 17:28:36 --> Output Class Initialized
INFO - 2023-05-19 17:28:36 --> Security Class Initialized
DEBUG - 2023-05-19 17:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-19 17:28:36 --> Input Class Initialized
INFO - 2023-05-19 17:28:36 --> Language Class Initialized
INFO - 2023-05-19 17:28:36 --> Loader Class Initialized
INFO - 2023-05-19 17:28:36 --> Helper loaded: url_helper
INFO - 2023-05-19 17:28:36 --> Helper loaded: form_helper
INFO - 2023-05-19 17:28:36 --> Helper loaded: file_helper
INFO - 2023-05-19 17:28:36 --> Database Driver Class Initialized
DEBUG - 2023-05-19 17:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-19 17:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-19 17:28:36 --> Form Validation Class Initialized
INFO - 2023-05-19 17:28:36 --> Upload Class Initialized
INFO - 2023-05-19 17:28:36 --> Model "M_auth" initialized
INFO - 2023-05-19 17:28:36 --> Model "M_user" initialized
INFO - 2023-05-19 17:28:36 --> Model "M_produk" initialized
INFO - 2023-05-19 17:28:36 --> Controller Class Initialized
INFO - 2023-05-19 17:28:36 --> Model "M_pelanggan" initialized
INFO - 2023-05-19 17:28:36 --> Model "M_produk" initialized
DEBUG - 2023-05-19 17:28:36 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-19 17:28:36 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-19 17:28:36 --> Model "M_transaksi" initialized
INFO - 2023-05-19 17:28:36 --> Model "M_bank" initialized
INFO - 2023-05-19 17:28:36 --> Model "M_pesan" initialized
INFO - 2023-05-19 17:28:36 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-05-19 17:28:36 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/v_produk_detail.php
INFO - 2023-05-19 17:28:36 --> Final output sent to browser
DEBUG - 2023-05-19 17:28:36 --> Total execution time: 0.2700
