<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-06-23 10:46:45 --> Config Class Initialized
INFO - 2023-06-23 10:46:45 --> Hooks Class Initialized
DEBUG - 2023-06-23 10:46:46 --> UTF-8 Support Enabled
INFO - 2023-06-23 10:46:46 --> Utf8 Class Initialized
INFO - 2023-06-23 10:46:46 --> URI Class Initialized
DEBUG - 2023-06-23 10:46:46 --> No URI present. Default controller set.
INFO - 2023-06-23 10:46:46 --> Router Class Initialized
INFO - 2023-06-23 10:46:46 --> Output Class Initialized
INFO - 2023-06-23 10:46:46 --> Security Class Initialized
DEBUG - 2023-06-23 10:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 10:46:46 --> Input Class Initialized
INFO - 2023-06-23 10:46:46 --> Language Class Initialized
INFO - 2023-06-23 10:46:46 --> Loader Class Initialized
INFO - 2023-06-23 10:46:47 --> Helper loaded: url_helper
INFO - 2023-06-23 10:46:47 --> Helper loaded: form_helper
INFO - 2023-06-23 10:46:47 --> Helper loaded: file_helper
INFO - 2023-06-23 10:46:47 --> Database Driver Class Initialized
DEBUG - 2023-06-23 10:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-23 10:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:46:47 --> Form Validation Class Initialized
INFO - 2023-06-23 10:46:48 --> Upload Class Initialized
INFO - 2023-06-23 10:46:48 --> Model "M_auth" initialized
INFO - 2023-06-23 10:46:48 --> Model "M_user" initialized
INFO - 2023-06-23 10:46:48 --> Model "M_produk" initialized
INFO - 2023-06-23 10:46:48 --> Controller Class Initialized
INFO - 2023-06-23 10:46:48 --> Model "M_pelanggan" initialized
INFO - 2023-06-23 10:46:48 --> Model "M_produk" initialized
DEBUG - 2023-06-23 10:46:48 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-06-23 10:46:48 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-06-23 10:46:48 --> Model "M_transaksi" initialized
INFO - 2023-06-23 10:46:48 --> Model "M_bank" initialized
INFO - 2023-06-23 10:46:48 --> Model "M_pesan" initialized
ERROR - 2023-06-23 10:46:48 --> Query error: Table 'aan.tbl_produk' doesn't exist in engine - Invalid query: SELECT *
FROM `tbl_produk`
LEFT JOIN `tbl_type` ON `tbl_type`.`id_type` = `tbl_produk`.`id_type`
LEFT JOIN `tbl_merek` ON `tbl_merek`.`id_merek` = `tbl_produk`.`id_merek`
ORDER BY `tbl_produk`.`id_produk` DESC
 LIMIT 9
INFO - 2023-06-23 10:46:49 --> Language file loaded: language/english/db_lang.php
INFO - 2023-06-23 10:47:43 --> Config Class Initialized
INFO - 2023-06-23 10:47:43 --> Hooks Class Initialized
DEBUG - 2023-06-23 10:47:43 --> UTF-8 Support Enabled
INFO - 2023-06-23 10:47:43 --> Utf8 Class Initialized
INFO - 2023-06-23 10:47:43 --> URI Class Initialized
DEBUG - 2023-06-23 10:47:43 --> No URI present. Default controller set.
INFO - 2023-06-23 10:47:43 --> Router Class Initialized
INFO - 2023-06-23 10:47:43 --> Output Class Initialized
INFO - 2023-06-23 10:47:43 --> Security Class Initialized
DEBUG - 2023-06-23 10:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 10:47:43 --> Input Class Initialized
INFO - 2023-06-23 10:47:43 --> Language Class Initialized
INFO - 2023-06-23 10:47:43 --> Loader Class Initialized
INFO - 2023-06-23 10:47:43 --> Helper loaded: url_helper
INFO - 2023-06-23 10:47:43 --> Helper loaded: form_helper
INFO - 2023-06-23 10:47:43 --> Helper loaded: file_helper
INFO - 2023-06-23 10:47:43 --> Database Driver Class Initialized
DEBUG - 2023-06-23 10:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-23 10:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:47:43 --> Form Validation Class Initialized
INFO - 2023-06-23 10:47:43 --> Upload Class Initialized
INFO - 2023-06-23 10:47:43 --> Model "M_auth" initialized
INFO - 2023-06-23 10:47:43 --> Model "M_user" initialized
INFO - 2023-06-23 10:47:43 --> Model "M_produk" initialized
INFO - 2023-06-23 10:47:43 --> Controller Class Initialized
INFO - 2023-06-23 10:47:43 --> Model "M_pelanggan" initialized
INFO - 2023-06-23 10:47:43 --> Model "M_produk" initialized
DEBUG - 2023-06-23 10:47:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-06-23 10:47:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-06-23 10:47:43 --> Model "M_transaksi" initialized
INFO - 2023-06-23 10:47:43 --> Model "M_bank" initialized
INFO - 2023-06-23 10:47:43 --> Model "M_pesan" initialized
ERROR - 2023-06-23 10:47:43 --> Query error: Table 'aan.tbl_produk' doesn't exist in engine - Invalid query: SELECT *
FROM `tbl_produk`
LEFT JOIN `tbl_type` ON `tbl_type`.`id_type` = `tbl_produk`.`id_type`
LEFT JOIN `tbl_merek` ON `tbl_merek`.`id_merek` = `tbl_produk`.`id_merek`
ORDER BY `tbl_produk`.`id_produk` DESC
 LIMIT 9
INFO - 2023-06-23 10:47:43 --> Language file loaded: language/english/db_lang.php
INFO - 2023-06-23 10:49:07 --> Config Class Initialized
INFO - 2023-06-23 10:49:07 --> Hooks Class Initialized
DEBUG - 2023-06-23 10:49:07 --> UTF-8 Support Enabled
INFO - 2023-06-23 10:49:07 --> Utf8 Class Initialized
INFO - 2023-06-23 10:49:07 --> URI Class Initialized
DEBUG - 2023-06-23 10:49:07 --> No URI present. Default controller set.
INFO - 2023-06-23 10:49:07 --> Router Class Initialized
INFO - 2023-06-23 10:49:07 --> Output Class Initialized
INFO - 2023-06-23 10:49:07 --> Security Class Initialized
DEBUG - 2023-06-23 10:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 10:49:07 --> Input Class Initialized
INFO - 2023-06-23 10:49:07 --> Language Class Initialized
INFO - 2023-06-23 10:49:08 --> Loader Class Initialized
INFO - 2023-06-23 10:49:08 --> Helper loaded: url_helper
INFO - 2023-06-23 10:49:08 --> Helper loaded: form_helper
INFO - 2023-06-23 10:49:08 --> Helper loaded: file_helper
INFO - 2023-06-23 10:49:08 --> Database Driver Class Initialized
DEBUG - 2023-06-23 10:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-23 10:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:49:08 --> Form Validation Class Initialized
INFO - 2023-06-23 10:49:08 --> Upload Class Initialized
INFO - 2023-06-23 10:49:08 --> Model "M_auth" initialized
INFO - 2023-06-23 10:49:08 --> Model "M_user" initialized
INFO - 2023-06-23 10:49:08 --> Model "M_produk" initialized
INFO - 2023-06-23 10:49:08 --> Controller Class Initialized
INFO - 2023-06-23 10:49:08 --> Model "M_pelanggan" initialized
INFO - 2023-06-23 10:49:08 --> Model "M_produk" initialized
DEBUG - 2023-06-23 10:49:08 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-06-23 10:49:08 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-06-23 10:49:08 --> Model "M_transaksi" initialized
INFO - 2023-06-23 10:49:08 --> Model "M_bank" initialized
INFO - 2023-06-23 10:49:08 --> Model "M_pesan" initialized
ERROR - 2023-06-23 10:49:08 --> Query error: Table 'aan.tbl_produk' doesn't exist in engine - Invalid query: SELECT *
FROM `tbl_produk`
LEFT JOIN `tbl_type` ON `tbl_type`.`id_type` = `tbl_produk`.`id_type`
LEFT JOIN `tbl_merek` ON `tbl_merek`.`id_merek` = `tbl_produk`.`id_merek`
ORDER BY `tbl_produk`.`id_produk` DESC
 LIMIT 9
INFO - 2023-06-23 10:49:08 --> Language file loaded: language/english/db_lang.php
INFO - 2023-06-23 10:49:11 --> Config Class Initialized
INFO - 2023-06-23 10:49:11 --> Hooks Class Initialized
DEBUG - 2023-06-23 10:49:11 --> UTF-8 Support Enabled
INFO - 2023-06-23 10:49:11 --> Utf8 Class Initialized
INFO - 2023-06-23 10:49:11 --> URI Class Initialized
DEBUG - 2023-06-23 10:49:11 --> No URI present. Default controller set.
INFO - 2023-06-23 10:49:11 --> Router Class Initialized
INFO - 2023-06-23 10:49:11 --> Output Class Initialized
INFO - 2023-06-23 10:49:11 --> Security Class Initialized
DEBUG - 2023-06-23 10:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 10:49:11 --> Input Class Initialized
INFO - 2023-06-23 10:49:11 --> Language Class Initialized
INFO - 2023-06-23 10:49:11 --> Loader Class Initialized
INFO - 2023-06-23 10:49:11 --> Helper loaded: url_helper
INFO - 2023-06-23 10:49:11 --> Helper loaded: form_helper
INFO - 2023-06-23 10:49:11 --> Helper loaded: file_helper
INFO - 2023-06-23 10:49:11 --> Database Driver Class Initialized
DEBUG - 2023-06-23 10:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-23 10:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 10:49:11 --> Form Validation Class Initialized
INFO - 2023-06-23 10:49:11 --> Upload Class Initialized
INFO - 2023-06-23 10:49:11 --> Model "M_auth" initialized
INFO - 2023-06-23 10:49:11 --> Model "M_user" initialized
INFO - 2023-06-23 10:49:11 --> Model "M_produk" initialized
INFO - 2023-06-23 10:49:11 --> Controller Class Initialized
INFO - 2023-06-23 10:49:11 --> Model "M_pelanggan" initialized
INFO - 2023-06-23 10:49:11 --> Model "M_produk" initialized
DEBUG - 2023-06-23 10:49:11 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-06-23 10:49:11 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-06-23 10:49:11 --> Model "M_transaksi" initialized
INFO - 2023-06-23 10:49:11 --> Model "M_bank" initialized
INFO - 2023-06-23 10:49:11 --> Model "M_pesan" initialized
ERROR - 2023-06-23 10:49:11 --> Query error: Table 'aan.tbl_produk' doesn't exist in engine - Invalid query: SELECT *
FROM `tbl_produk`
LEFT JOIN `tbl_type` ON `tbl_type`.`id_type` = `tbl_produk`.`id_type`
LEFT JOIN `tbl_merek` ON `tbl_merek`.`id_merek` = `tbl_produk`.`id_merek`
ORDER BY `tbl_produk`.`id_produk` DESC
 LIMIT 9
INFO - 2023-06-23 10:49:11 --> Language file loaded: language/english/db_lang.php
INFO - 2023-06-23 11:32:56 --> Config Class Initialized
INFO - 2023-06-23 11:32:56 --> Hooks Class Initialized
DEBUG - 2023-06-23 11:32:56 --> UTF-8 Support Enabled
INFO - 2023-06-23 11:32:56 --> Utf8 Class Initialized
INFO - 2023-06-23 11:32:57 --> URI Class Initialized
DEBUG - 2023-06-23 11:32:57 --> No URI present. Default controller set.
INFO - 2023-06-23 11:32:57 --> Router Class Initialized
INFO - 2023-06-23 11:32:57 --> Output Class Initialized
INFO - 2023-06-23 11:32:57 --> Security Class Initialized
DEBUG - 2023-06-23 11:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 11:32:57 --> Input Class Initialized
INFO - 2023-06-23 11:32:57 --> Language Class Initialized
INFO - 2023-06-23 11:32:57 --> Loader Class Initialized
INFO - 2023-06-23 11:32:57 --> Helper loaded: url_helper
INFO - 2023-06-23 11:32:57 --> Helper loaded: form_helper
INFO - 2023-06-23 11:32:57 --> Helper loaded: file_helper
INFO - 2023-06-23 11:32:57 --> Database Driver Class Initialized
DEBUG - 2023-06-23 11:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-23 11:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:32:58 --> Form Validation Class Initialized
INFO - 2023-06-23 11:32:58 --> Upload Class Initialized
INFO - 2023-06-23 11:32:58 --> Model "M_auth" initialized
INFO - 2023-06-23 11:32:58 --> Model "M_user" initialized
INFO - 2023-06-23 11:32:58 --> Model "M_produk" initialized
INFO - 2023-06-23 11:32:58 --> Controller Class Initialized
INFO - 2023-06-23 11:32:58 --> Model "M_pelanggan" initialized
INFO - 2023-06-23 11:32:58 --> Model "M_produk" initialized
DEBUG - 2023-06-23 11:32:58 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-06-23 11:32:58 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-06-23 11:32:58 --> Model "M_transaksi" initialized
INFO - 2023-06-23 11:32:58 --> Model "M_bank" initialized
INFO - 2023-06-23 11:32:58 --> Model "M_pesan" initialized
INFO - 2023-06-23 11:32:58 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-06-23 11:32:58 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-06-23 11:32:58 --> Final output sent to browser
DEBUG - 2023-06-23 11:32:58 --> Total execution time: 1.7404
INFO - 2023-06-23 11:54:29 --> Config Class Initialized
INFO - 2023-06-23 11:54:29 --> Hooks Class Initialized
DEBUG - 2023-06-23 11:54:29 --> UTF-8 Support Enabled
INFO - 2023-06-23 11:54:29 --> Utf8 Class Initialized
INFO - 2023-06-23 11:54:29 --> URI Class Initialized
DEBUG - 2023-06-23 11:54:29 --> No URI present. Default controller set.
INFO - 2023-06-23 11:54:29 --> Router Class Initialized
INFO - 2023-06-23 11:54:29 --> Output Class Initialized
INFO - 2023-06-23 11:54:29 --> Security Class Initialized
DEBUG - 2023-06-23 11:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 11:54:29 --> Input Class Initialized
INFO - 2023-06-23 11:54:29 --> Language Class Initialized
INFO - 2023-06-23 11:54:29 --> Loader Class Initialized
INFO - 2023-06-23 11:54:29 --> Helper loaded: url_helper
INFO - 2023-06-23 11:54:29 --> Helper loaded: form_helper
INFO - 2023-06-23 11:54:29 --> Helper loaded: file_helper
INFO - 2023-06-23 11:54:29 --> Database Driver Class Initialized
DEBUG - 2023-06-23 11:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-23 11:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 11:54:29 --> Form Validation Class Initialized
INFO - 2023-06-23 11:54:29 --> Upload Class Initialized
INFO - 2023-06-23 11:54:29 --> Model "M_auth" initialized
INFO - 2023-06-23 11:54:29 --> Model "M_user" initialized
INFO - 2023-06-23 11:54:29 --> Model "M_produk" initialized
INFO - 2023-06-23 11:54:29 --> Controller Class Initialized
INFO - 2023-06-23 11:54:29 --> Model "M_pelanggan" initialized
INFO - 2023-06-23 11:54:29 --> Model "M_produk" initialized
DEBUG - 2023-06-23 11:54:29 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-06-23 11:54:29 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-06-23 11:54:29 --> Model "M_transaksi" initialized
INFO - 2023-06-23 11:54:29 --> Model "M_bank" initialized
INFO - 2023-06-23 11:54:29 --> Model "M_pesan" initialized
INFO - 2023-06-23 11:54:29 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-06-23 11:54:29 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-06-23 11:54:29 --> Final output sent to browser
DEBUG - 2023-06-23 11:54:29 --> Total execution time: 0.2541
