<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-30 11:04:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 11:04:17 --> Config Class Initialized
INFO - 2023-10-30 11:04:17 --> Hooks Class Initialized
DEBUG - 2023-10-30 11:04:17 --> UTF-8 Support Enabled
INFO - 2023-10-30 11:04:17 --> Utf8 Class Initialized
INFO - 2023-10-30 11:04:17 --> URI Class Initialized
DEBUG - 2023-10-30 11:04:17 --> No URI present. Default controller set.
INFO - 2023-10-30 11:04:17 --> Router Class Initialized
INFO - 2023-10-30 11:04:17 --> Output Class Initialized
INFO - 2023-10-30 11:04:17 --> Security Class Initialized
DEBUG - 2023-10-30 11:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 11:04:17 --> Input Class Initialized
INFO - 2023-10-30 11:04:17 --> Language Class Initialized
INFO - 2023-10-30 11:04:17 --> Loader Class Initialized
INFO - 2023-10-30 11:04:17 --> Helper loaded: url_helper
INFO - 2023-10-30 11:04:17 --> Helper loaded: form_helper
INFO - 2023-10-30 11:04:17 --> Helper loaded: file_helper
INFO - 2023-10-30 11:04:17 --> Database Driver Class Initialized
DEBUG - 2023-10-30 11:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 11:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 11:04:17 --> Form Validation Class Initialized
INFO - 2023-10-30 11:04:17 --> Upload Class Initialized
INFO - 2023-10-30 11:04:17 --> Model "M_auth" initialized
INFO - 2023-10-30 11:04:17 --> Model "M_user" initialized
INFO - 2023-10-30 11:04:17 --> Model "M_produk" initialized
INFO - 2023-10-30 11:04:17 --> Controller Class Initialized
INFO - 2023-10-30 11:04:17 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 11:04:17 --> Model "M_produk" initialized
DEBUG - 2023-10-30 11:04:17 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 11:04:17 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 11:04:17 --> Model "M_transaksi" initialized
INFO - 2023-10-30 11:04:17 --> Model "M_bank" initialized
INFO - 2023-10-30 11:04:17 --> Model "M_pesan" initialized
INFO - 2023-10-30 11:04:17 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 11:04:17 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-30 11:04:17 --> Final output sent to browser
DEBUG - 2023-10-30 11:04:17 --> Total execution time: 0.5561
ERROR - 2023-10-30 11:23:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 11:23:14 --> Config Class Initialized
INFO - 2023-10-30 11:23:14 --> Hooks Class Initialized
DEBUG - 2023-10-30 11:23:14 --> UTF-8 Support Enabled
INFO - 2023-10-30 11:23:14 --> Utf8 Class Initialized
INFO - 2023-10-30 11:23:14 --> URI Class Initialized
INFO - 2023-10-30 11:23:14 --> Router Class Initialized
INFO - 2023-10-30 11:23:14 --> Output Class Initialized
INFO - 2023-10-30 11:23:14 --> Security Class Initialized
DEBUG - 2023-10-30 11:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 11:23:14 --> Input Class Initialized
INFO - 2023-10-30 11:23:14 --> Language Class Initialized
INFO - 2023-10-30 11:23:14 --> Loader Class Initialized
INFO - 2023-10-30 11:23:14 --> Helper loaded: url_helper
INFO - 2023-10-30 11:23:14 --> Helper loaded: form_helper
INFO - 2023-10-30 11:23:14 --> Helper loaded: file_helper
INFO - 2023-10-30 11:23:14 --> Database Driver Class Initialized
DEBUG - 2023-10-30 11:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 11:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 11:23:14 --> Form Validation Class Initialized
INFO - 2023-10-30 11:23:14 --> Upload Class Initialized
INFO - 2023-10-30 11:23:14 --> Model "M_auth" initialized
INFO - 2023-10-30 11:23:14 --> Model "M_user" initialized
INFO - 2023-10-30 11:23:14 --> Model "M_produk" initialized
INFO - 2023-10-30 11:23:14 --> Controller Class Initialized
DEBUG - 2023-10-30 11:23:14 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 11:23:16 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-30 11:23:16 --> Final output sent to browser
DEBUG - 2023-10-30 11:23:16 --> Total execution time: 1.8044
ERROR - 2023-10-30 11:23:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 11:23:46 --> Config Class Initialized
INFO - 2023-10-30 11:23:46 --> Hooks Class Initialized
DEBUG - 2023-10-30 11:23:46 --> UTF-8 Support Enabled
INFO - 2023-10-30 11:23:46 --> Utf8 Class Initialized
INFO - 2023-10-30 11:23:46 --> URI Class Initialized
INFO - 2023-10-30 11:23:46 --> Router Class Initialized
INFO - 2023-10-30 11:23:46 --> Output Class Initialized
INFO - 2023-10-30 11:23:46 --> Security Class Initialized
DEBUG - 2023-10-30 11:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 11:23:46 --> Input Class Initialized
INFO - 2023-10-30 11:23:46 --> Language Class Initialized
INFO - 2023-10-30 11:23:46 --> Loader Class Initialized
INFO - 2023-10-30 11:23:46 --> Helper loaded: url_helper
INFO - 2023-10-30 11:23:46 --> Helper loaded: form_helper
INFO - 2023-10-30 11:23:46 --> Helper loaded: file_helper
INFO - 2023-10-30 11:23:46 --> Database Driver Class Initialized
DEBUG - 2023-10-30 11:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 11:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 11:23:46 --> Form Validation Class Initialized
INFO - 2023-10-30 11:23:46 --> Upload Class Initialized
INFO - 2023-10-30 11:23:46 --> Model "M_auth" initialized
INFO - 2023-10-30 11:23:46 --> Model "M_user" initialized
INFO - 2023-10-30 11:23:46 --> Model "M_produk" initialized
INFO - 2023-10-30 11:23:46 --> Controller Class Initialized
DEBUG - 2023-10-30 11:23:46 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 11:23:46 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-30 11:23:46 --> Final output sent to browser
DEBUG - 2023-10-30 11:23:46 --> Total execution time: 0.3560
ERROR - 2023-10-30 11:40:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 11:40:55 --> Config Class Initialized
INFO - 2023-10-30 11:40:55 --> Hooks Class Initialized
DEBUG - 2023-10-30 11:40:55 --> UTF-8 Support Enabled
INFO - 2023-10-30 11:40:55 --> Utf8 Class Initialized
INFO - 2023-10-30 11:40:55 --> URI Class Initialized
INFO - 2023-10-30 11:40:55 --> Router Class Initialized
INFO - 2023-10-30 11:40:55 --> Output Class Initialized
INFO - 2023-10-30 11:40:55 --> Security Class Initialized
DEBUG - 2023-10-30 11:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 11:40:55 --> Input Class Initialized
INFO - 2023-10-30 11:40:55 --> Language Class Initialized
INFO - 2023-10-30 11:40:55 --> Loader Class Initialized
INFO - 2023-10-30 11:40:55 --> Helper loaded: url_helper
INFO - 2023-10-30 11:40:55 --> Helper loaded: form_helper
INFO - 2023-10-30 11:40:55 --> Helper loaded: file_helper
INFO - 2023-10-30 11:40:55 --> Database Driver Class Initialized
DEBUG - 2023-10-30 11:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 11:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 11:40:55 --> Form Validation Class Initialized
INFO - 2023-10-30 11:40:55 --> Upload Class Initialized
INFO - 2023-10-30 11:40:55 --> Model "M_auth" initialized
INFO - 2023-10-30 11:40:55 --> Model "M_user" initialized
INFO - 2023-10-30 11:40:55 --> Model "M_produk" initialized
INFO - 2023-10-30 11:40:55 --> Controller Class Initialized
ERROR - 2023-10-30 11:40:56 --> Severity: error --> Exception: Class "Midtrans\Config" not found C:\xampp\htdocs\4_aan\semakar_adventure\application\config\midtrans.php 9
ERROR - 2023-10-30 11:41:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 11:41:18 --> Config Class Initialized
INFO - 2023-10-30 11:41:18 --> Hooks Class Initialized
DEBUG - 2023-10-30 11:41:18 --> UTF-8 Support Enabled
INFO - 2023-10-30 11:41:18 --> Utf8 Class Initialized
INFO - 2023-10-30 11:41:18 --> URI Class Initialized
INFO - 2023-10-30 11:41:18 --> Router Class Initialized
INFO - 2023-10-30 11:41:18 --> Output Class Initialized
INFO - 2023-10-30 11:41:18 --> Security Class Initialized
DEBUG - 2023-10-30 11:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 11:41:18 --> Input Class Initialized
INFO - 2023-10-30 11:41:18 --> Language Class Initialized
INFO - 2023-10-30 11:41:18 --> Loader Class Initialized
INFO - 2023-10-30 11:41:18 --> Helper loaded: url_helper
INFO - 2023-10-30 11:41:18 --> Helper loaded: form_helper
INFO - 2023-10-30 11:41:18 --> Helper loaded: file_helper
INFO - 2023-10-30 11:41:18 --> Database Driver Class Initialized
DEBUG - 2023-10-30 11:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 11:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 11:41:18 --> Form Validation Class Initialized
INFO - 2023-10-30 11:41:18 --> Upload Class Initialized
INFO - 2023-10-30 11:41:18 --> Model "M_auth" initialized
INFO - 2023-10-30 11:41:18 --> Model "M_user" initialized
INFO - 2023-10-30 11:41:18 --> Model "M_produk" initialized
INFO - 2023-10-30 11:41:18 --> Controller Class Initialized
ERROR - 2023-10-30 11:41:18 --> Severity: error --> Exception: Class "Midtrans\Config" not found C:\xampp\htdocs\4_aan\semakar_adventure\application\config\midtrans.php 9
ERROR - 2023-10-30 11:41:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 11:41:33 --> Config Class Initialized
INFO - 2023-10-30 11:41:33 --> Hooks Class Initialized
DEBUG - 2023-10-30 11:41:33 --> UTF-8 Support Enabled
INFO - 2023-10-30 11:41:33 --> Utf8 Class Initialized
INFO - 2023-10-30 11:41:33 --> URI Class Initialized
INFO - 2023-10-30 11:41:33 --> Router Class Initialized
INFO - 2023-10-30 11:41:33 --> Output Class Initialized
INFO - 2023-10-30 11:41:33 --> Security Class Initialized
DEBUG - 2023-10-30 11:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 11:41:33 --> Input Class Initialized
INFO - 2023-10-30 11:41:33 --> Language Class Initialized
INFO - 2023-10-30 11:41:33 --> Loader Class Initialized
INFO - 2023-10-30 11:41:33 --> Helper loaded: url_helper
INFO - 2023-10-30 11:41:33 --> Helper loaded: form_helper
INFO - 2023-10-30 11:41:33 --> Helper loaded: file_helper
INFO - 2023-10-30 11:41:33 --> Database Driver Class Initialized
DEBUG - 2023-10-30 11:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 11:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 11:41:33 --> Form Validation Class Initialized
INFO - 2023-10-30 11:41:33 --> Upload Class Initialized
INFO - 2023-10-30 11:41:33 --> Model "M_auth" initialized
INFO - 2023-10-30 11:41:33 --> Model "M_user" initialized
INFO - 2023-10-30 11:41:33 --> Model "M_produk" initialized
INFO - 2023-10-30 11:41:33 --> Controller Class Initialized
ERROR - 2023-10-30 11:41:33 --> Severity: error --> Exception: Class "Midtrans\Config" not found C:\xampp\htdocs\4_aan\semakar_adventure\application\config\midtrans.php 9
ERROR - 2023-10-30 11:41:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 11:41:34 --> Config Class Initialized
INFO - 2023-10-30 11:41:34 --> Hooks Class Initialized
DEBUG - 2023-10-30 11:41:34 --> UTF-8 Support Enabled
INFO - 2023-10-30 11:41:34 --> Utf8 Class Initialized
INFO - 2023-10-30 11:41:34 --> URI Class Initialized
INFO - 2023-10-30 11:41:34 --> Router Class Initialized
INFO - 2023-10-30 11:41:34 --> Output Class Initialized
INFO - 2023-10-30 11:41:34 --> Security Class Initialized
DEBUG - 2023-10-30 11:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 11:41:34 --> Input Class Initialized
INFO - 2023-10-30 11:41:34 --> Language Class Initialized
INFO - 2023-10-30 11:41:34 --> Loader Class Initialized
INFO - 2023-10-30 11:41:34 --> Helper loaded: url_helper
INFO - 2023-10-30 11:41:34 --> Helper loaded: form_helper
INFO - 2023-10-30 11:41:34 --> Helper loaded: file_helper
INFO - 2023-10-30 11:41:34 --> Database Driver Class Initialized
DEBUG - 2023-10-30 11:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 11:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 11:41:34 --> Form Validation Class Initialized
INFO - 2023-10-30 11:41:34 --> Upload Class Initialized
INFO - 2023-10-30 11:41:34 --> Model "M_auth" initialized
INFO - 2023-10-30 11:41:34 --> Model "M_user" initialized
INFO - 2023-10-30 11:41:34 --> Model "M_produk" initialized
INFO - 2023-10-30 11:41:34 --> Controller Class Initialized
ERROR - 2023-10-30 11:41:34 --> Severity: error --> Exception: Class "Midtrans\Config" not found C:\xampp\htdocs\4_aan\semakar_adventure\application\config\midtrans.php 9
ERROR - 2023-10-30 11:41:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 11:41:35 --> Config Class Initialized
INFO - 2023-10-30 11:41:35 --> Hooks Class Initialized
DEBUG - 2023-10-30 11:41:35 --> UTF-8 Support Enabled
INFO - 2023-10-30 11:41:35 --> Utf8 Class Initialized
INFO - 2023-10-30 11:41:35 --> URI Class Initialized
INFO - 2023-10-30 11:41:35 --> Router Class Initialized
INFO - 2023-10-30 11:41:35 --> Output Class Initialized
INFO - 2023-10-30 11:41:35 --> Security Class Initialized
DEBUG - 2023-10-30 11:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 11:41:35 --> Input Class Initialized
INFO - 2023-10-30 11:41:35 --> Language Class Initialized
INFO - 2023-10-30 11:41:35 --> Loader Class Initialized
INFO - 2023-10-30 11:41:35 --> Helper loaded: url_helper
INFO - 2023-10-30 11:41:35 --> Helper loaded: form_helper
INFO - 2023-10-30 11:41:35 --> Helper loaded: file_helper
INFO - 2023-10-30 11:41:35 --> Database Driver Class Initialized
DEBUG - 2023-10-30 11:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 11:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 11:41:35 --> Form Validation Class Initialized
INFO - 2023-10-30 11:41:35 --> Upload Class Initialized
INFO - 2023-10-30 11:41:35 --> Model "M_auth" initialized
INFO - 2023-10-30 11:41:35 --> Model "M_user" initialized
INFO - 2023-10-30 11:41:35 --> Model "M_produk" initialized
INFO - 2023-10-30 11:41:35 --> Controller Class Initialized
ERROR - 2023-10-30 11:41:35 --> Severity: error --> Exception: Class "Midtrans\Config" not found C:\xampp\htdocs\4_aan\semakar_adventure\application\config\midtrans.php 9
ERROR - 2023-10-30 11:41:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 11:41:35 --> Config Class Initialized
INFO - 2023-10-30 11:41:35 --> Hooks Class Initialized
DEBUG - 2023-10-30 11:41:35 --> UTF-8 Support Enabled
INFO - 2023-10-30 11:41:35 --> Utf8 Class Initialized
INFO - 2023-10-30 11:41:35 --> URI Class Initialized
INFO - 2023-10-30 11:41:35 --> Router Class Initialized
INFO - 2023-10-30 11:41:35 --> Output Class Initialized
INFO - 2023-10-30 11:41:35 --> Security Class Initialized
DEBUG - 2023-10-30 11:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 11:41:35 --> Input Class Initialized
INFO - 2023-10-30 11:41:35 --> Language Class Initialized
INFO - 2023-10-30 11:41:35 --> Loader Class Initialized
INFO - 2023-10-30 11:41:35 --> Helper loaded: url_helper
INFO - 2023-10-30 11:41:35 --> Helper loaded: form_helper
INFO - 2023-10-30 11:41:35 --> Helper loaded: file_helper
INFO - 2023-10-30 11:41:35 --> Database Driver Class Initialized
DEBUG - 2023-10-30 11:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 11:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 11:41:35 --> Form Validation Class Initialized
INFO - 2023-10-30 11:41:35 --> Upload Class Initialized
INFO - 2023-10-30 11:41:35 --> Model "M_auth" initialized
INFO - 2023-10-30 11:41:35 --> Model "M_user" initialized
INFO - 2023-10-30 11:41:35 --> Model "M_produk" initialized
INFO - 2023-10-30 11:41:35 --> Controller Class Initialized
ERROR - 2023-10-30 11:41:35 --> Severity: error --> Exception: Class "Midtrans\Config" not found C:\xampp\htdocs\4_aan\semakar_adventure\application\config\midtrans.php 9
ERROR - 2023-10-30 11:41:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 11:41:42 --> Config Class Initialized
INFO - 2023-10-30 11:41:42 --> Hooks Class Initialized
DEBUG - 2023-10-30 11:41:42 --> UTF-8 Support Enabled
INFO - 2023-10-30 11:41:42 --> Utf8 Class Initialized
INFO - 2023-10-30 11:41:42 --> URI Class Initialized
INFO - 2023-10-30 11:41:42 --> Router Class Initialized
INFO - 2023-10-30 11:41:42 --> Output Class Initialized
INFO - 2023-10-30 11:41:42 --> Security Class Initialized
DEBUG - 2023-10-30 11:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 11:41:42 --> Input Class Initialized
INFO - 2023-10-30 11:41:42 --> Language Class Initialized
INFO - 2023-10-30 11:41:42 --> Loader Class Initialized
INFO - 2023-10-30 11:41:42 --> Helper loaded: url_helper
INFO - 2023-10-30 11:41:42 --> Helper loaded: form_helper
INFO - 2023-10-30 11:41:42 --> Helper loaded: file_helper
INFO - 2023-10-30 11:41:42 --> Database Driver Class Initialized
DEBUG - 2023-10-30 11:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 11:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 11:41:42 --> Form Validation Class Initialized
INFO - 2023-10-30 11:41:42 --> Upload Class Initialized
INFO - 2023-10-30 11:41:42 --> Model "M_auth" initialized
INFO - 2023-10-30 11:41:42 --> Model "M_user" initialized
INFO - 2023-10-30 11:41:42 --> Model "M_produk" initialized
INFO - 2023-10-30 11:41:42 --> Controller Class Initialized
ERROR - 2023-10-30 11:41:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 11:41:47 --> Config Class Initialized
INFO - 2023-10-30 11:41:47 --> Hooks Class Initialized
DEBUG - 2023-10-30 11:41:47 --> UTF-8 Support Enabled
INFO - 2023-10-30 11:41:47 --> Utf8 Class Initialized
INFO - 2023-10-30 11:41:47 --> URI Class Initialized
INFO - 2023-10-30 11:41:47 --> Router Class Initialized
INFO - 2023-10-30 11:41:47 --> Output Class Initialized
INFO - 2023-10-30 11:41:47 --> Security Class Initialized
DEBUG - 2023-10-30 11:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 11:41:47 --> Input Class Initialized
INFO - 2023-10-30 11:41:47 --> Language Class Initialized
INFO - 2023-10-30 11:41:47 --> Loader Class Initialized
INFO - 2023-10-30 11:41:47 --> Helper loaded: url_helper
INFO - 2023-10-30 11:41:47 --> Helper loaded: form_helper
INFO - 2023-10-30 11:41:47 --> Helper loaded: file_helper
INFO - 2023-10-30 11:41:47 --> Database Driver Class Initialized
DEBUG - 2023-10-30 11:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 11:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 11:41:47 --> Form Validation Class Initialized
INFO - 2023-10-30 11:41:47 --> Upload Class Initialized
INFO - 2023-10-30 11:41:47 --> Model "M_auth" initialized
INFO - 2023-10-30 11:41:47 --> Model "M_user" initialized
INFO - 2023-10-30 11:41:47 --> Model "M_produk" initialized
INFO - 2023-10-30 11:41:47 --> Controller Class Initialized
DEBUG - 2023-10-30 11:41:47 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 11:41:48 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-30 11:41:48 --> Final output sent to browser
DEBUG - 2023-10-30 11:41:48 --> Total execution time: 0.7742
ERROR - 2023-10-30 11:42:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 11:42:04 --> Config Class Initialized
INFO - 2023-10-30 11:42:04 --> Hooks Class Initialized
DEBUG - 2023-10-30 11:42:04 --> UTF-8 Support Enabled
INFO - 2023-10-30 11:42:04 --> Utf8 Class Initialized
INFO - 2023-10-30 11:42:04 --> URI Class Initialized
INFO - 2023-10-30 11:42:04 --> Router Class Initialized
INFO - 2023-10-30 11:42:04 --> Output Class Initialized
INFO - 2023-10-30 11:42:04 --> Security Class Initialized
DEBUG - 2023-10-30 11:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 11:42:04 --> Input Class Initialized
INFO - 2023-10-30 11:42:04 --> Language Class Initialized
INFO - 2023-10-30 11:42:04 --> Loader Class Initialized
INFO - 2023-10-30 11:42:04 --> Helper loaded: url_helper
INFO - 2023-10-30 11:42:04 --> Helper loaded: form_helper
INFO - 2023-10-30 11:42:04 --> Helper loaded: file_helper
INFO - 2023-10-30 11:42:04 --> Database Driver Class Initialized
DEBUG - 2023-10-30 11:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 11:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 11:42:04 --> Form Validation Class Initialized
INFO - 2023-10-30 11:42:04 --> Upload Class Initialized
INFO - 2023-10-30 11:42:04 --> Model "M_auth" initialized
INFO - 2023-10-30 11:42:04 --> Model "M_user" initialized
INFO - 2023-10-30 11:42:04 --> Model "M_produk" initialized
INFO - 2023-10-30 11:42:04 --> Controller Class Initialized
DEBUG - 2023-10-30 11:42:04 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 11:42:04 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-30 11:42:04 --> Final output sent to browser
DEBUG - 2023-10-30 11:42:04 --> Total execution time: 0.0740
ERROR - 2023-10-30 11:42:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 11:42:15 --> Config Class Initialized
INFO - 2023-10-30 11:42:15 --> Hooks Class Initialized
DEBUG - 2023-10-30 11:42:15 --> UTF-8 Support Enabled
INFO - 2023-10-30 11:42:15 --> Utf8 Class Initialized
INFO - 2023-10-30 11:42:15 --> URI Class Initialized
INFO - 2023-10-30 11:42:15 --> Router Class Initialized
INFO - 2023-10-30 11:42:15 --> Output Class Initialized
INFO - 2023-10-30 11:42:15 --> Security Class Initialized
DEBUG - 2023-10-30 11:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 11:42:15 --> Input Class Initialized
INFO - 2023-10-30 11:42:15 --> Language Class Initialized
INFO - 2023-10-30 11:42:15 --> Loader Class Initialized
INFO - 2023-10-30 11:42:15 --> Helper loaded: url_helper
INFO - 2023-10-30 11:42:15 --> Helper loaded: form_helper
INFO - 2023-10-30 11:42:15 --> Helper loaded: file_helper
INFO - 2023-10-30 11:42:15 --> Database Driver Class Initialized
DEBUG - 2023-10-30 11:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 11:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 11:42:15 --> Form Validation Class Initialized
INFO - 2023-10-30 11:42:15 --> Upload Class Initialized
INFO - 2023-10-30 11:42:15 --> Model "M_auth" initialized
INFO - 2023-10-30 11:42:15 --> Model "M_user" initialized
INFO - 2023-10-30 11:42:15 --> Model "M_produk" initialized
INFO - 2023-10-30 11:42:15 --> Controller Class Initialized
DEBUG - 2023-10-30 11:42:15 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 11:42:16 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-30 11:42:16 --> Final output sent to browser
DEBUG - 2023-10-30 11:42:16 --> Total execution time: 1.2989
ERROR - 2023-10-30 11:42:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 11:42:29 --> Config Class Initialized
INFO - 2023-10-30 11:42:29 --> Hooks Class Initialized
DEBUG - 2023-10-30 11:42:29 --> UTF-8 Support Enabled
INFO - 2023-10-30 11:42:29 --> Utf8 Class Initialized
INFO - 2023-10-30 11:42:29 --> URI Class Initialized
DEBUG - 2023-10-30 11:42:29 --> No URI present. Default controller set.
INFO - 2023-10-30 11:42:29 --> Router Class Initialized
INFO - 2023-10-30 11:42:29 --> Output Class Initialized
INFO - 2023-10-30 11:42:29 --> Security Class Initialized
DEBUG - 2023-10-30 11:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 11:42:29 --> Input Class Initialized
INFO - 2023-10-30 11:42:29 --> Language Class Initialized
INFO - 2023-10-30 11:42:29 --> Loader Class Initialized
INFO - 2023-10-30 11:42:29 --> Helper loaded: url_helper
INFO - 2023-10-30 11:42:29 --> Helper loaded: form_helper
INFO - 2023-10-30 11:42:29 --> Helper loaded: file_helper
INFO - 2023-10-30 11:42:29 --> Database Driver Class Initialized
DEBUG - 2023-10-30 11:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 11:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 11:42:29 --> Form Validation Class Initialized
INFO - 2023-10-30 11:42:29 --> Upload Class Initialized
INFO - 2023-10-30 11:42:29 --> Model "M_auth" initialized
INFO - 2023-10-30 11:42:29 --> Model "M_user" initialized
INFO - 2023-10-30 11:42:29 --> Model "M_produk" initialized
INFO - 2023-10-30 11:42:29 --> Controller Class Initialized
INFO - 2023-10-30 11:42:29 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 11:42:29 --> Model "M_produk" initialized
DEBUG - 2023-10-30 11:42:29 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 11:42:29 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 11:42:29 --> Model "M_transaksi" initialized
INFO - 2023-10-30 11:42:29 --> Model "M_bank" initialized
INFO - 2023-10-30 11:42:29 --> Model "M_pesan" initialized
INFO - 2023-10-30 11:42:29 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 11:42:29 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-30 11:42:29 --> Final output sent to browser
DEBUG - 2023-10-30 11:42:29 --> Total execution time: 0.0989
ERROR - 2023-10-30 11:46:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 11:46:21 --> Config Class Initialized
INFO - 2023-10-30 11:46:21 --> Hooks Class Initialized
DEBUG - 2023-10-30 11:46:21 --> UTF-8 Support Enabled
INFO - 2023-10-30 11:46:21 --> Utf8 Class Initialized
INFO - 2023-10-30 11:46:21 --> URI Class Initialized
DEBUG - 2023-10-30 11:46:21 --> No URI present. Default controller set.
INFO - 2023-10-30 11:46:21 --> Router Class Initialized
INFO - 2023-10-30 11:46:21 --> Output Class Initialized
INFO - 2023-10-30 11:46:21 --> Security Class Initialized
DEBUG - 2023-10-30 11:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 11:46:21 --> Input Class Initialized
INFO - 2023-10-30 11:46:21 --> Language Class Initialized
INFO - 2023-10-30 11:46:21 --> Loader Class Initialized
INFO - 2023-10-30 11:46:21 --> Helper loaded: url_helper
INFO - 2023-10-30 11:46:21 --> Helper loaded: form_helper
INFO - 2023-10-30 11:46:21 --> Helper loaded: file_helper
INFO - 2023-10-30 11:46:21 --> Database Driver Class Initialized
DEBUG - 2023-10-30 11:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 11:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 11:46:21 --> Form Validation Class Initialized
INFO - 2023-10-30 11:46:21 --> Upload Class Initialized
INFO - 2023-10-30 11:46:21 --> Model "M_auth" initialized
INFO - 2023-10-30 11:46:21 --> Model "M_user" initialized
INFO - 2023-10-30 11:46:21 --> Model "M_produk" initialized
INFO - 2023-10-30 11:46:21 --> Controller Class Initialized
INFO - 2023-10-30 11:46:21 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 11:46:21 --> Model "M_produk" initialized
DEBUG - 2023-10-30 11:46:21 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 11:46:21 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 11:46:21 --> Model "M_transaksi" initialized
INFO - 2023-10-30 11:46:21 --> Model "M_bank" initialized
INFO - 2023-10-30 11:46:21 --> Model "M_pesan" initialized
INFO - 2023-10-30 11:46:21 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 11:46:21 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-30 11:46:21 --> Final output sent to browser
DEBUG - 2023-10-30 11:46:21 --> Total execution time: 0.1050
ERROR - 2023-10-30 11:46:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 11:46:23 --> Config Class Initialized
INFO - 2023-10-30 11:46:23 --> Hooks Class Initialized
DEBUG - 2023-10-30 11:46:23 --> UTF-8 Support Enabled
INFO - 2023-10-30 11:46:23 --> Utf8 Class Initialized
INFO - 2023-10-30 11:46:23 --> URI Class Initialized
INFO - 2023-10-30 11:46:23 --> Router Class Initialized
INFO - 2023-10-30 11:46:23 --> Output Class Initialized
INFO - 2023-10-30 11:46:23 --> Security Class Initialized
DEBUG - 2023-10-30 11:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 11:46:23 --> Input Class Initialized
INFO - 2023-10-30 11:46:23 --> Language Class Initialized
INFO - 2023-10-30 11:46:23 --> Loader Class Initialized
INFO - 2023-10-30 11:46:23 --> Helper loaded: url_helper
INFO - 2023-10-30 11:46:23 --> Helper loaded: form_helper
INFO - 2023-10-30 11:46:23 --> Helper loaded: file_helper
INFO - 2023-10-30 11:46:23 --> Database Driver Class Initialized
DEBUG - 2023-10-30 11:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 11:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 11:46:23 --> Form Validation Class Initialized
INFO - 2023-10-30 11:46:23 --> Upload Class Initialized
INFO - 2023-10-30 11:46:23 --> Model "M_auth" initialized
INFO - 2023-10-30 11:46:23 --> Model "M_user" initialized
INFO - 2023-10-30 11:46:23 --> Model "M_produk" initialized
INFO - 2023-10-30 11:46:23 --> Controller Class Initialized
DEBUG - 2023-10-30 11:46:23 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 11:46:24 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-30 11:46:24 --> Final output sent to browser
DEBUG - 2023-10-30 11:46:24 --> Total execution time: 0.3491
ERROR - 2023-10-30 11:46:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 11:46:32 --> Config Class Initialized
INFO - 2023-10-30 11:46:32 --> Hooks Class Initialized
DEBUG - 2023-10-30 11:46:32 --> UTF-8 Support Enabled
INFO - 2023-10-30 11:46:32 --> Utf8 Class Initialized
INFO - 2023-10-30 11:46:32 --> URI Class Initialized
INFO - 2023-10-30 11:46:32 --> Router Class Initialized
INFO - 2023-10-30 11:46:32 --> Output Class Initialized
INFO - 2023-10-30 11:46:32 --> Security Class Initialized
DEBUG - 2023-10-30 11:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 11:46:32 --> Input Class Initialized
INFO - 2023-10-30 11:46:32 --> Language Class Initialized
INFO - 2023-10-30 11:46:32 --> Loader Class Initialized
INFO - 2023-10-30 11:46:32 --> Helper loaded: url_helper
INFO - 2023-10-30 11:46:32 --> Helper loaded: form_helper
INFO - 2023-10-30 11:46:32 --> Helper loaded: file_helper
INFO - 2023-10-30 11:46:32 --> Database Driver Class Initialized
DEBUG - 2023-10-30 11:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 11:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 11:46:32 --> Form Validation Class Initialized
INFO - 2023-10-30 11:46:32 --> Upload Class Initialized
INFO - 2023-10-30 11:46:32 --> Model "M_auth" initialized
INFO - 2023-10-30 11:46:32 --> Model "M_user" initialized
INFO - 2023-10-30 11:46:32 --> Model "M_produk" initialized
INFO - 2023-10-30 11:46:32 --> Controller Class Initialized
DEBUG - 2023-10-30 11:46:32 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 11:46:33 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-30 11:46:33 --> Final output sent to browser
DEBUG - 2023-10-30 11:46:33 --> Total execution time: 0.3677
ERROR - 2023-10-30 11:46:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 11:46:40 --> Config Class Initialized
INFO - 2023-10-30 11:46:40 --> Hooks Class Initialized
DEBUG - 2023-10-30 11:46:40 --> UTF-8 Support Enabled
INFO - 2023-10-30 11:46:40 --> Utf8 Class Initialized
INFO - 2023-10-30 11:46:40 --> URI Class Initialized
INFO - 2023-10-30 11:46:40 --> Router Class Initialized
INFO - 2023-10-30 11:46:40 --> Output Class Initialized
INFO - 2023-10-30 11:46:40 --> Security Class Initialized
DEBUG - 2023-10-30 11:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 11:46:40 --> Input Class Initialized
INFO - 2023-10-30 11:46:40 --> Language Class Initialized
INFO - 2023-10-30 11:46:40 --> Loader Class Initialized
INFO - 2023-10-30 11:46:40 --> Helper loaded: url_helper
INFO - 2023-10-30 11:46:40 --> Helper loaded: form_helper
INFO - 2023-10-30 11:46:40 --> Helper loaded: file_helper
INFO - 2023-10-30 11:46:40 --> Database Driver Class Initialized
DEBUG - 2023-10-30 11:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 11:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 11:46:40 --> Form Validation Class Initialized
INFO - 2023-10-30 11:46:40 --> Upload Class Initialized
INFO - 2023-10-30 11:46:40 --> Model "M_auth" initialized
INFO - 2023-10-30 11:46:40 --> Model "M_user" initialized
INFO - 2023-10-30 11:46:40 --> Model "M_produk" initialized
INFO - 2023-10-30 11:46:40 --> Controller Class Initialized
DEBUG - 2023-10-30 11:46:40 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 11:46:40 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-30 11:46:40 --> Final output sent to browser
DEBUG - 2023-10-30 11:46:40 --> Total execution time: 0.4564
ERROR - 2023-10-30 18:42:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 18:42:40 --> Config Class Initialized
INFO - 2023-10-30 18:42:40 --> Hooks Class Initialized
DEBUG - 2023-10-30 18:42:40 --> UTF-8 Support Enabled
INFO - 2023-10-30 18:42:40 --> Utf8 Class Initialized
INFO - 2023-10-30 18:42:40 --> URI Class Initialized
DEBUG - 2023-10-30 18:42:40 --> No URI present. Default controller set.
INFO - 2023-10-30 18:42:40 --> Router Class Initialized
INFO - 2023-10-30 18:42:40 --> Output Class Initialized
INFO - 2023-10-30 18:42:40 --> Security Class Initialized
DEBUG - 2023-10-30 18:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 18:42:40 --> Input Class Initialized
INFO - 2023-10-30 18:42:40 --> Language Class Initialized
INFO - 2023-10-30 18:42:40 --> Loader Class Initialized
INFO - 2023-10-30 18:42:40 --> Helper loaded: url_helper
INFO - 2023-10-30 18:42:40 --> Helper loaded: form_helper
INFO - 2023-10-30 18:42:40 --> Helper loaded: file_helper
INFO - 2023-10-30 18:42:40 --> Database Driver Class Initialized
DEBUG - 2023-10-30 18:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 18:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 18:42:40 --> Form Validation Class Initialized
INFO - 2023-10-30 18:42:40 --> Upload Class Initialized
INFO - 2023-10-30 18:42:40 --> Model "M_auth" initialized
INFO - 2023-10-30 18:42:40 --> Model "M_user" initialized
INFO - 2023-10-30 18:42:40 --> Model "M_produk" initialized
INFO - 2023-10-30 18:42:40 --> Controller Class Initialized
INFO - 2023-10-30 18:42:40 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 18:42:40 --> Model "M_produk" initialized
DEBUG - 2023-10-30 18:42:40 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 18:42:40 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 18:42:40 --> Model "M_transaksi" initialized
INFO - 2023-10-30 18:42:40 --> Model "M_bank" initialized
INFO - 2023-10-30 18:42:40 --> Model "M_pesan" initialized
INFO - 2023-10-30 18:42:40 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 18:42:40 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-30 18:42:40 --> Final output sent to browser
DEBUG - 2023-10-30 18:42:40 --> Total execution time: 0.5623
ERROR - 2023-10-30 18:42:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 18:42:47 --> Config Class Initialized
INFO - 2023-10-30 18:42:47 --> Hooks Class Initialized
DEBUG - 2023-10-30 18:42:47 --> UTF-8 Support Enabled
INFO - 2023-10-30 18:42:47 --> Utf8 Class Initialized
INFO - 2023-10-30 18:42:47 --> URI Class Initialized
INFO - 2023-10-30 18:42:47 --> Router Class Initialized
INFO - 2023-10-30 18:42:47 --> Output Class Initialized
INFO - 2023-10-30 18:42:47 --> Security Class Initialized
DEBUG - 2023-10-30 18:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 18:42:47 --> Input Class Initialized
INFO - 2023-10-30 18:42:47 --> Language Class Initialized
INFO - 2023-10-30 18:42:47 --> Loader Class Initialized
INFO - 2023-10-30 18:42:47 --> Helper loaded: url_helper
INFO - 2023-10-30 18:42:47 --> Helper loaded: form_helper
INFO - 2023-10-30 18:42:47 --> Helper loaded: file_helper
INFO - 2023-10-30 18:42:47 --> Database Driver Class Initialized
DEBUG - 2023-10-30 18:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 18:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 18:42:47 --> Form Validation Class Initialized
INFO - 2023-10-30 18:42:47 --> Upload Class Initialized
INFO - 2023-10-30 18:42:47 --> Model "M_auth" initialized
INFO - 2023-10-30 18:42:47 --> Model "M_user" initialized
INFO - 2023-10-30 18:42:47 --> Model "M_produk" initialized
INFO - 2023-10-30 18:42:47 --> Controller Class Initialized
DEBUG - 2023-10-30 18:42:47 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 18:42:48 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-30 18:42:48 --> Final output sent to browser
DEBUG - 2023-10-30 18:42:48 --> Total execution time: 1.3831
ERROR - 2023-10-30 18:44:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 18:44:10 --> Config Class Initialized
INFO - 2023-10-30 18:44:10 --> Hooks Class Initialized
DEBUG - 2023-10-30 18:44:10 --> UTF-8 Support Enabled
INFO - 2023-10-30 18:44:10 --> Utf8 Class Initialized
INFO - 2023-10-30 18:44:10 --> URI Class Initialized
INFO - 2023-10-30 18:44:10 --> Router Class Initialized
INFO - 2023-10-30 18:44:10 --> Output Class Initialized
INFO - 2023-10-30 18:44:10 --> Security Class Initialized
DEBUG - 2023-10-30 18:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 18:44:10 --> Input Class Initialized
INFO - 2023-10-30 18:44:10 --> Language Class Initialized
INFO - 2023-10-30 18:44:10 --> Loader Class Initialized
INFO - 2023-10-30 18:44:10 --> Helper loaded: url_helper
INFO - 2023-10-30 18:44:10 --> Helper loaded: form_helper
INFO - 2023-10-30 18:44:10 --> Helper loaded: file_helper
INFO - 2023-10-30 18:44:10 --> Database Driver Class Initialized
DEBUG - 2023-10-30 18:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 18:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 18:44:11 --> Form Validation Class Initialized
INFO - 2023-10-30 18:44:11 --> Upload Class Initialized
INFO - 2023-10-30 18:44:11 --> Model "M_auth" initialized
INFO - 2023-10-30 18:44:11 --> Model "M_user" initialized
INFO - 2023-10-30 18:44:11 --> Model "M_produk" initialized
INFO - 2023-10-30 18:44:11 --> Controller Class Initialized
DEBUG - 2023-10-30 18:44:11 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 18:44:14 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-30 18:44:14 --> Final output sent to browser
DEBUG - 2023-10-30 18:44:14 --> Total execution time: 3.5425
ERROR - 2023-10-30 18:50:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 18:50:42 --> Config Class Initialized
INFO - 2023-10-30 18:50:42 --> Hooks Class Initialized
DEBUG - 2023-10-30 18:50:42 --> UTF-8 Support Enabled
INFO - 2023-10-30 18:50:42 --> Utf8 Class Initialized
INFO - 2023-10-30 18:50:42 --> URI Class Initialized
DEBUG - 2023-10-30 18:50:42 --> No URI present. Default controller set.
INFO - 2023-10-30 18:50:42 --> Router Class Initialized
INFO - 2023-10-30 18:50:42 --> Output Class Initialized
INFO - 2023-10-30 18:50:42 --> Security Class Initialized
DEBUG - 2023-10-30 18:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 18:50:42 --> Input Class Initialized
INFO - 2023-10-30 18:50:42 --> Language Class Initialized
INFO - 2023-10-30 18:50:42 --> Loader Class Initialized
INFO - 2023-10-30 18:50:42 --> Helper loaded: url_helper
INFO - 2023-10-30 18:50:42 --> Helper loaded: form_helper
INFO - 2023-10-30 18:50:42 --> Helper loaded: file_helper
INFO - 2023-10-30 18:50:42 --> Database Driver Class Initialized
DEBUG - 2023-10-30 18:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 18:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 18:50:42 --> Form Validation Class Initialized
INFO - 2023-10-30 18:50:42 --> Upload Class Initialized
INFO - 2023-10-30 18:50:42 --> Model "M_auth" initialized
INFO - 2023-10-30 18:50:42 --> Model "M_user" initialized
INFO - 2023-10-30 18:50:42 --> Model "M_produk" initialized
INFO - 2023-10-30 18:50:42 --> Controller Class Initialized
INFO - 2023-10-30 18:50:42 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 18:50:42 --> Model "M_produk" initialized
DEBUG - 2023-10-30 18:50:42 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 18:50:42 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 18:50:42 --> Model "M_transaksi" initialized
INFO - 2023-10-30 18:50:42 --> Model "M_bank" initialized
INFO - 2023-10-30 18:50:42 --> Model "M_pesan" initialized
INFO - 2023-10-30 18:50:42 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 18:50:42 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-30 18:50:42 --> Final output sent to browser
DEBUG - 2023-10-30 18:50:42 --> Total execution time: 0.0592
ERROR - 2023-10-30 18:50:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 18:50:58 --> Config Class Initialized
INFO - 2023-10-30 18:50:58 --> Hooks Class Initialized
DEBUG - 2023-10-30 18:50:58 --> UTF-8 Support Enabled
INFO - 2023-10-30 18:50:58 --> Utf8 Class Initialized
INFO - 2023-10-30 18:50:58 --> URI Class Initialized
DEBUG - 2023-10-30 18:50:58 --> No URI present. Default controller set.
INFO - 2023-10-30 18:50:58 --> Router Class Initialized
INFO - 2023-10-30 18:50:58 --> Output Class Initialized
INFO - 2023-10-30 18:50:58 --> Security Class Initialized
DEBUG - 2023-10-30 18:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 18:50:58 --> Input Class Initialized
INFO - 2023-10-30 18:50:58 --> Language Class Initialized
INFO - 2023-10-30 18:50:58 --> Loader Class Initialized
INFO - 2023-10-30 18:50:58 --> Helper loaded: url_helper
INFO - 2023-10-30 18:50:58 --> Helper loaded: form_helper
INFO - 2023-10-30 18:50:58 --> Helper loaded: file_helper
INFO - 2023-10-30 18:50:58 --> Database Driver Class Initialized
DEBUG - 2023-10-30 18:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 18:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 18:50:58 --> Form Validation Class Initialized
INFO - 2023-10-30 18:50:58 --> Upload Class Initialized
INFO - 2023-10-30 18:50:58 --> Model "M_auth" initialized
INFO - 2023-10-30 18:50:58 --> Model "M_user" initialized
INFO - 2023-10-30 18:50:58 --> Model "M_produk" initialized
INFO - 2023-10-30 18:50:58 --> Controller Class Initialized
INFO - 2023-10-30 18:50:58 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 18:50:58 --> Model "M_produk" initialized
DEBUG - 2023-10-30 18:50:58 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 18:50:58 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 18:50:58 --> Model "M_transaksi" initialized
INFO - 2023-10-30 18:50:58 --> Model "M_bank" initialized
INFO - 2023-10-30 18:50:58 --> Model "M_pesan" initialized
INFO - 2023-10-30 18:50:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-10-30 18:50:58 --> Email Class Initialized
INFO - 2023-10-30 18:51:00 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-10-30 18:51:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 18:51:03 --> Config Class Initialized
INFO - 2023-10-30 18:51:03 --> Hooks Class Initialized
DEBUG - 2023-10-30 18:51:03 --> UTF-8 Support Enabled
INFO - 2023-10-30 18:51:03 --> Utf8 Class Initialized
INFO - 2023-10-30 18:51:03 --> URI Class Initialized
DEBUG - 2023-10-30 18:51:03 --> No URI present. Default controller set.
INFO - 2023-10-30 18:51:03 --> Router Class Initialized
INFO - 2023-10-30 18:51:03 --> Output Class Initialized
INFO - 2023-10-30 18:51:03 --> Security Class Initialized
DEBUG - 2023-10-30 18:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 18:51:03 --> Input Class Initialized
INFO - 2023-10-30 18:51:03 --> Language Class Initialized
INFO - 2023-10-30 18:51:03 --> Loader Class Initialized
INFO - 2023-10-30 18:51:03 --> Helper loaded: url_helper
INFO - 2023-10-30 18:51:03 --> Helper loaded: form_helper
INFO - 2023-10-30 18:51:03 --> Helper loaded: file_helper
INFO - 2023-10-30 18:51:03 --> Database Driver Class Initialized
DEBUG - 2023-10-30 18:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 18:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 18:51:03 --> Form Validation Class Initialized
INFO - 2023-10-30 18:51:03 --> Upload Class Initialized
INFO - 2023-10-30 18:51:03 --> Model "M_auth" initialized
INFO - 2023-10-30 18:51:03 --> Model "M_user" initialized
INFO - 2023-10-30 18:51:03 --> Model "M_produk" initialized
INFO - 2023-10-30 18:51:03 --> Controller Class Initialized
INFO - 2023-10-30 18:51:03 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 18:51:03 --> Model "M_produk" initialized
DEBUG - 2023-10-30 18:51:03 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 18:51:03 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 18:51:03 --> Model "M_transaksi" initialized
INFO - 2023-10-30 18:51:03 --> Model "M_bank" initialized
INFO - 2023-10-30 18:51:03 --> Model "M_pesan" initialized
INFO - 2023-10-30 18:51:03 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 18:51:03 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-30 18:51:03 --> Final output sent to browser
DEBUG - 2023-10-30 18:51:03 --> Total execution time: 0.0983
ERROR - 2023-10-30 18:51:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 18:51:07 --> Config Class Initialized
INFO - 2023-10-30 18:51:07 --> Hooks Class Initialized
DEBUG - 2023-10-30 18:51:07 --> UTF-8 Support Enabled
INFO - 2023-10-30 18:51:07 --> Utf8 Class Initialized
INFO - 2023-10-30 18:51:07 --> URI Class Initialized
INFO - 2023-10-30 18:51:07 --> Router Class Initialized
INFO - 2023-10-30 18:51:07 --> Output Class Initialized
INFO - 2023-10-30 18:51:07 --> Security Class Initialized
DEBUG - 2023-10-30 18:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 18:51:07 --> Input Class Initialized
INFO - 2023-10-30 18:51:07 --> Language Class Initialized
INFO - 2023-10-30 18:51:07 --> Loader Class Initialized
INFO - 2023-10-30 18:51:07 --> Helper loaded: url_helper
INFO - 2023-10-30 18:51:07 --> Helper loaded: form_helper
INFO - 2023-10-30 18:51:07 --> Helper loaded: file_helper
INFO - 2023-10-30 18:51:07 --> Database Driver Class Initialized
DEBUG - 2023-10-30 18:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 18:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 18:51:07 --> Form Validation Class Initialized
INFO - 2023-10-30 18:51:07 --> Upload Class Initialized
INFO - 2023-10-30 18:51:07 --> Model "M_auth" initialized
INFO - 2023-10-30 18:51:07 --> Model "M_user" initialized
INFO - 2023-10-30 18:51:07 --> Model "M_produk" initialized
INFO - 2023-10-30 18:51:07 --> Controller Class Initialized
INFO - 2023-10-30 18:51:07 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 18:51:07 --> Model "M_produk" initialized
DEBUG - 2023-10-30 18:51:07 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 18:51:07 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 18:51:07 --> Model "M_transaksi" initialized
INFO - 2023-10-30 18:51:07 --> Model "M_bank" initialized
INFO - 2023-10-30 18:51:07 --> Model "M_pesan" initialized
INFO - 2023-10-30 18:51:07 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 18:51:07 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 18:51:07 --> Final output sent to browser
DEBUG - 2023-10-30 18:51:07 --> Total execution time: 0.2534
ERROR - 2023-10-30 18:51:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 18:51:10 --> Config Class Initialized
INFO - 2023-10-30 18:51:10 --> Hooks Class Initialized
DEBUG - 2023-10-30 18:51:10 --> UTF-8 Support Enabled
INFO - 2023-10-30 18:51:10 --> Utf8 Class Initialized
INFO - 2023-10-30 18:51:10 --> URI Class Initialized
INFO - 2023-10-30 18:51:10 --> Router Class Initialized
INFO - 2023-10-30 18:51:10 --> Output Class Initialized
INFO - 2023-10-30 18:51:10 --> Security Class Initialized
DEBUG - 2023-10-30 18:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 18:51:10 --> Input Class Initialized
INFO - 2023-10-30 18:51:10 --> Language Class Initialized
INFO - 2023-10-30 18:51:10 --> Loader Class Initialized
INFO - 2023-10-30 18:51:10 --> Helper loaded: url_helper
INFO - 2023-10-30 18:51:10 --> Helper loaded: form_helper
INFO - 2023-10-30 18:51:10 --> Helper loaded: file_helper
INFO - 2023-10-30 18:51:10 --> Database Driver Class Initialized
DEBUG - 2023-10-30 18:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 18:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 18:51:10 --> Form Validation Class Initialized
INFO - 2023-10-30 18:51:10 --> Upload Class Initialized
INFO - 2023-10-30 18:51:10 --> Model "M_auth" initialized
INFO - 2023-10-30 18:51:10 --> Model "M_user" initialized
INFO - 2023-10-30 18:51:10 --> Model "M_produk" initialized
INFO - 2023-10-30 18:51:10 --> Controller Class Initialized
INFO - 2023-10-30 18:51:10 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 18:51:10 --> Model "M_produk" initialized
DEBUG - 2023-10-30 18:51:10 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 18:51:10 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 18:51:10 --> Model "M_transaksi" initialized
INFO - 2023-10-30 18:51:10 --> Model "M_bank" initialized
INFO - 2023-10-30 18:51:10 --> Model "M_pesan" initialized
INFO - 2023-10-30 18:51:10 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 18:51:10 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_bayar_sekarang.php
INFO - 2023-10-30 18:51:10 --> Final output sent to browser
DEBUG - 2023-10-30 18:51:10 --> Total execution time: 0.0850
ERROR - 2023-10-30 18:51:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 18:51:10 --> Config Class Initialized
INFO - 2023-10-30 18:51:10 --> Hooks Class Initialized
DEBUG - 2023-10-30 18:51:10 --> UTF-8 Support Enabled
INFO - 2023-10-30 18:51:10 --> Utf8 Class Initialized
INFO - 2023-10-30 18:51:10 --> URI Class Initialized
INFO - 2023-10-30 18:51:10 --> Router Class Initialized
INFO - 2023-10-30 18:51:10 --> Output Class Initialized
INFO - 2023-10-30 18:51:10 --> Security Class Initialized
DEBUG - 2023-10-30 18:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 18:51:10 --> Input Class Initialized
INFO - 2023-10-30 18:51:10 --> Language Class Initialized
INFO - 2023-10-30 18:51:10 --> Loader Class Initialized
INFO - 2023-10-30 18:51:10 --> Helper loaded: url_helper
INFO - 2023-10-30 18:51:10 --> Helper loaded: form_helper
INFO - 2023-10-30 18:51:10 --> Helper loaded: file_helper
INFO - 2023-10-30 18:51:10 --> Database Driver Class Initialized
DEBUG - 2023-10-30 18:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 18:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 18:51:10 --> Form Validation Class Initialized
INFO - 2023-10-30 18:51:10 --> Upload Class Initialized
INFO - 2023-10-30 18:51:10 --> Model "M_auth" initialized
INFO - 2023-10-30 18:51:10 --> Model "M_user" initialized
INFO - 2023-10-30 18:51:10 --> Model "M_produk" initialized
INFO - 2023-10-30 18:51:10 --> Controller Class Initialized
INFO - 2023-10-30 18:51:10 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-10-30 18:51:10 --> Final output sent to browser
DEBUG - 2023-10-30 18:51:10 --> Total execution time: 0.1009
ERROR - 2023-10-30 18:51:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 18:51:13 --> Config Class Initialized
INFO - 2023-10-30 18:51:13 --> Hooks Class Initialized
DEBUG - 2023-10-30 18:51:13 --> UTF-8 Support Enabled
INFO - 2023-10-30 18:51:13 --> Utf8 Class Initialized
INFO - 2023-10-30 18:51:13 --> URI Class Initialized
INFO - 2023-10-30 18:51:13 --> Router Class Initialized
INFO - 2023-10-30 18:51:13 --> Output Class Initialized
INFO - 2023-10-30 18:51:13 --> Security Class Initialized
DEBUG - 2023-10-30 18:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 18:51:13 --> Input Class Initialized
INFO - 2023-10-30 18:51:13 --> Language Class Initialized
INFO - 2023-10-30 18:51:13 --> Loader Class Initialized
INFO - 2023-10-30 18:51:13 --> Helper loaded: url_helper
INFO - 2023-10-30 18:51:13 --> Helper loaded: form_helper
INFO - 2023-10-30 18:51:13 --> Helper loaded: file_helper
INFO - 2023-10-30 18:51:13 --> Database Driver Class Initialized
DEBUG - 2023-10-30 18:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 18:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 18:51:13 --> Form Validation Class Initialized
INFO - 2023-10-30 18:51:13 --> Upload Class Initialized
INFO - 2023-10-30 18:51:13 --> Model "M_auth" initialized
INFO - 2023-10-30 18:51:13 --> Model "M_user" initialized
INFO - 2023-10-30 18:51:13 --> Model "M_produk" initialized
INFO - 2023-10-30 18:51:13 --> Controller Class Initialized
INFO - 2023-10-30 18:51:13 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 18:51:13 --> Model "M_produk" initialized
DEBUG - 2023-10-30 18:51:13 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 18:51:13 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 18:51:13 --> Model "M_transaksi" initialized
INFO - 2023-10-30 18:51:13 --> Model "M_bank" initialized
INFO - 2023-10-30 18:51:13 --> Model "M_pesan" initialized
INFO - 2023-10-30 18:51:13 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 18:51:13 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 18:51:13 --> Final output sent to browser
DEBUG - 2023-10-30 18:51:13 --> Total execution time: 0.1236
ERROR - 2023-10-30 18:51:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 18:51:51 --> Config Class Initialized
INFO - 2023-10-30 18:51:51 --> Hooks Class Initialized
DEBUG - 2023-10-30 18:51:51 --> UTF-8 Support Enabled
INFO - 2023-10-30 18:51:51 --> Utf8 Class Initialized
INFO - 2023-10-30 18:51:51 --> URI Class Initialized
INFO - 2023-10-30 18:51:51 --> Router Class Initialized
INFO - 2023-10-30 18:51:51 --> Output Class Initialized
INFO - 2023-10-30 18:51:51 --> Security Class Initialized
DEBUG - 2023-10-30 18:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 18:51:51 --> Input Class Initialized
INFO - 2023-10-30 18:51:51 --> Language Class Initialized
INFO - 2023-10-30 18:51:51 --> Loader Class Initialized
INFO - 2023-10-30 18:51:51 --> Helper loaded: url_helper
INFO - 2023-10-30 18:51:51 --> Helper loaded: form_helper
INFO - 2023-10-30 18:51:51 --> Helper loaded: file_helper
INFO - 2023-10-30 18:51:51 --> Database Driver Class Initialized
DEBUG - 2023-10-30 18:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 18:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 18:51:51 --> Form Validation Class Initialized
INFO - 2023-10-30 18:51:51 --> Upload Class Initialized
INFO - 2023-10-30 18:51:51 --> Model "M_auth" initialized
INFO - 2023-10-30 18:51:51 --> Model "M_user" initialized
INFO - 2023-10-30 18:51:51 --> Model "M_produk" initialized
INFO - 2023-10-30 18:51:51 --> Controller Class Initialized
INFO - 2023-10-30 18:51:51 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 18:51:51 --> Model "M_produk" initialized
DEBUG - 2023-10-30 18:51:51 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 18:51:51 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 18:51:51 --> Model "M_transaksi" initialized
INFO - 2023-10-30 18:51:51 --> Model "M_bank" initialized
INFO - 2023-10-30 18:51:51 --> Model "M_pesan" initialized
INFO - 2023-10-30 18:51:51 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 18:51:51 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_bayar_sekarang.php
INFO - 2023-10-30 18:51:51 --> Final output sent to browser
DEBUG - 2023-10-30 18:51:51 --> Total execution time: 0.0753
ERROR - 2023-10-30 18:51:51 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 18:51:51 --> Config Class Initialized
INFO - 2023-10-30 18:51:51 --> Hooks Class Initialized
DEBUG - 2023-10-30 18:51:51 --> UTF-8 Support Enabled
INFO - 2023-10-30 18:51:51 --> Utf8 Class Initialized
INFO - 2023-10-30 18:51:51 --> URI Class Initialized
INFO - 2023-10-30 18:51:51 --> Router Class Initialized
INFO - 2023-10-30 18:51:51 --> Output Class Initialized
INFO - 2023-10-30 18:51:51 --> Security Class Initialized
DEBUG - 2023-10-30 18:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 18:51:51 --> Input Class Initialized
INFO - 2023-10-30 18:51:51 --> Language Class Initialized
INFO - 2023-10-30 18:51:51 --> Loader Class Initialized
INFO - 2023-10-30 18:51:51 --> Helper loaded: url_helper
INFO - 2023-10-30 18:51:51 --> Helper loaded: form_helper
INFO - 2023-10-30 18:51:51 --> Helper loaded: file_helper
INFO - 2023-10-30 18:51:51 --> Database Driver Class Initialized
DEBUG - 2023-10-30 18:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 18:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 18:51:51 --> Form Validation Class Initialized
INFO - 2023-10-30 18:51:51 --> Upload Class Initialized
INFO - 2023-10-30 18:51:51 --> Model "M_auth" initialized
INFO - 2023-10-30 18:51:51 --> Model "M_user" initialized
INFO - 2023-10-30 18:51:51 --> Model "M_produk" initialized
INFO - 2023-10-30 18:51:51 --> Controller Class Initialized
INFO - 2023-10-30 18:51:51 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-10-30 18:51:51 --> Final output sent to browser
DEBUG - 2023-10-30 18:51:51 --> Total execution time: 0.0255
ERROR - 2023-10-30 18:52:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 18:52:07 --> Config Class Initialized
INFO - 2023-10-30 18:52:07 --> Hooks Class Initialized
DEBUG - 2023-10-30 18:52:07 --> UTF-8 Support Enabled
INFO - 2023-10-30 18:52:07 --> Utf8 Class Initialized
INFO - 2023-10-30 18:52:07 --> URI Class Initialized
INFO - 2023-10-30 18:52:07 --> Router Class Initialized
INFO - 2023-10-30 18:52:07 --> Output Class Initialized
INFO - 2023-10-30 18:52:07 --> Security Class Initialized
DEBUG - 2023-10-30 18:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 18:52:07 --> Input Class Initialized
INFO - 2023-10-30 18:52:07 --> Language Class Initialized
INFO - 2023-10-30 18:52:07 --> Loader Class Initialized
INFO - 2023-10-30 18:52:07 --> Helper loaded: url_helper
INFO - 2023-10-30 18:52:07 --> Helper loaded: form_helper
INFO - 2023-10-30 18:52:07 --> Helper loaded: file_helper
INFO - 2023-10-30 18:52:07 --> Database Driver Class Initialized
DEBUG - 2023-10-30 18:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 18:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 18:52:07 --> Form Validation Class Initialized
INFO - 2023-10-30 18:52:07 --> Upload Class Initialized
INFO - 2023-10-30 18:52:07 --> Model "M_auth" initialized
INFO - 2023-10-30 18:52:07 --> Model "M_user" initialized
INFO - 2023-10-30 18:52:07 --> Model "M_produk" initialized
INFO - 2023-10-30 18:52:07 --> Controller Class Initialized
INFO - 2023-10-30 18:52:07 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 18:52:07 --> Model "M_produk" initialized
DEBUG - 2023-10-30 18:52:07 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 18:52:07 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 18:52:07 --> Model "M_transaksi" initialized
INFO - 2023-10-30 18:52:07 --> Model "M_bank" initialized
INFO - 2023-10-30 18:52:07 --> Model "M_pesan" initialized
INFO - 2023-10-30 18:52:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-10-30 18:52:07 --> Image Lib Class Initialized
ERROR - 2023-10-30 18:52:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 18:52:07 --> Config Class Initialized
INFO - 2023-10-30 18:52:07 --> Hooks Class Initialized
DEBUG - 2023-10-30 18:52:07 --> UTF-8 Support Enabled
INFO - 2023-10-30 18:52:07 --> Utf8 Class Initialized
INFO - 2023-10-30 18:52:07 --> URI Class Initialized
INFO - 2023-10-30 18:52:07 --> Router Class Initialized
INFO - 2023-10-30 18:52:07 --> Output Class Initialized
INFO - 2023-10-30 18:52:07 --> Security Class Initialized
DEBUG - 2023-10-30 18:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 18:52:07 --> Input Class Initialized
INFO - 2023-10-30 18:52:07 --> Language Class Initialized
INFO - 2023-10-30 18:52:07 --> Loader Class Initialized
INFO - 2023-10-30 18:52:07 --> Helper loaded: url_helper
INFO - 2023-10-30 18:52:07 --> Helper loaded: form_helper
INFO - 2023-10-30 18:52:07 --> Helper loaded: file_helper
INFO - 2023-10-30 18:52:07 --> Database Driver Class Initialized
DEBUG - 2023-10-30 18:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 18:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 18:52:07 --> Form Validation Class Initialized
INFO - 2023-10-30 18:52:08 --> Upload Class Initialized
INFO - 2023-10-30 18:52:08 --> Model "M_auth" initialized
INFO - 2023-10-30 18:52:08 --> Model "M_user" initialized
INFO - 2023-10-30 18:52:08 --> Model "M_produk" initialized
INFO - 2023-10-30 18:52:08 --> Controller Class Initialized
INFO - 2023-10-30 18:52:08 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 18:52:08 --> Model "M_produk" initialized
DEBUG - 2023-10-30 18:52:08 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 18:52:08 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 18:52:08 --> Model "M_transaksi" initialized
INFO - 2023-10-30 18:52:08 --> Model "M_bank" initialized
INFO - 2023-10-30 18:52:08 --> Model "M_pesan" initialized
INFO - 2023-10-30 18:52:08 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 18:52:08 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 18:52:08 --> Final output sent to browser
DEBUG - 2023-10-30 18:52:08 --> Total execution time: 0.0271
ERROR - 2023-10-30 18:52:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 18:52:31 --> Config Class Initialized
INFO - 2023-10-30 18:52:31 --> Hooks Class Initialized
DEBUG - 2023-10-30 18:52:31 --> UTF-8 Support Enabled
INFO - 2023-10-30 18:52:31 --> Utf8 Class Initialized
INFO - 2023-10-30 18:52:31 --> URI Class Initialized
INFO - 2023-10-30 18:52:31 --> Router Class Initialized
INFO - 2023-10-30 18:52:31 --> Output Class Initialized
INFO - 2023-10-30 18:52:31 --> Security Class Initialized
DEBUG - 2023-10-30 18:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 18:52:31 --> Input Class Initialized
INFO - 2023-10-30 18:52:31 --> Language Class Initialized
INFO - 2023-10-30 18:52:31 --> Loader Class Initialized
INFO - 2023-10-30 18:52:31 --> Helper loaded: url_helper
INFO - 2023-10-30 18:52:31 --> Helper loaded: form_helper
INFO - 2023-10-30 18:52:31 --> Helper loaded: file_helper
INFO - 2023-10-30 18:52:31 --> Database Driver Class Initialized
DEBUG - 2023-10-30 18:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 18:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 18:52:31 --> Form Validation Class Initialized
INFO - 2023-10-30 18:52:31 --> Upload Class Initialized
INFO - 2023-10-30 18:52:31 --> Model "M_auth" initialized
INFO - 2023-10-30 18:52:31 --> Model "M_user" initialized
INFO - 2023-10-30 18:52:31 --> Model "M_produk" initialized
INFO - 2023-10-30 18:52:31 --> Controller Class Initialized
INFO - 2023-10-30 18:52:31 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 18:52:31 --> Model "M_produk" initialized
DEBUG - 2023-10-30 18:52:31 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 18:52:31 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 18:52:31 --> Model "M_transaksi" initialized
INFO - 2023-10-30 18:52:31 --> Model "M_bank" initialized
INFO - 2023-10-30 18:52:31 --> Model "M_pesan" initialized
ERROR - 2023-10-30 18:52:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 18:52:31 --> Config Class Initialized
INFO - 2023-10-30 18:52:31 --> Hooks Class Initialized
DEBUG - 2023-10-30 18:52:31 --> UTF-8 Support Enabled
INFO - 2023-10-30 18:52:31 --> Utf8 Class Initialized
INFO - 2023-10-30 18:52:31 --> URI Class Initialized
DEBUG - 2023-10-30 18:52:31 --> No URI present. Default controller set.
INFO - 2023-10-30 18:52:31 --> Router Class Initialized
INFO - 2023-10-30 18:52:31 --> Output Class Initialized
INFO - 2023-10-30 18:52:31 --> Security Class Initialized
DEBUG - 2023-10-30 18:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 18:52:31 --> Input Class Initialized
INFO - 2023-10-30 18:52:31 --> Language Class Initialized
INFO - 2023-10-30 18:52:31 --> Loader Class Initialized
INFO - 2023-10-30 18:52:31 --> Helper loaded: url_helper
INFO - 2023-10-30 18:52:31 --> Helper loaded: form_helper
INFO - 2023-10-30 18:52:31 --> Helper loaded: file_helper
INFO - 2023-10-30 18:52:31 --> Database Driver Class Initialized
DEBUG - 2023-10-30 18:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 18:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 18:52:31 --> Form Validation Class Initialized
INFO - 2023-10-30 18:52:31 --> Upload Class Initialized
INFO - 2023-10-30 18:52:31 --> Model "M_auth" initialized
INFO - 2023-10-30 18:52:31 --> Model "M_user" initialized
INFO - 2023-10-30 18:52:31 --> Model "M_produk" initialized
INFO - 2023-10-30 18:52:31 --> Controller Class Initialized
INFO - 2023-10-30 18:52:31 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 18:52:31 --> Model "M_produk" initialized
DEBUG - 2023-10-30 18:52:31 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 18:52:31 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 18:52:31 --> Model "M_transaksi" initialized
INFO - 2023-10-30 18:52:31 --> Model "M_bank" initialized
INFO - 2023-10-30 18:52:31 --> Model "M_pesan" initialized
INFO - 2023-10-30 18:52:31 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 18:52:31 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-30 18:52:31 --> Final output sent to browser
DEBUG - 2023-10-30 18:52:31 --> Total execution time: 0.0873
ERROR - 2023-10-30 19:05:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 19:05:30 --> Config Class Initialized
INFO - 2023-10-30 19:05:30 --> Hooks Class Initialized
DEBUG - 2023-10-30 19:05:30 --> UTF-8 Support Enabled
INFO - 2023-10-30 19:05:30 --> Utf8 Class Initialized
INFO - 2023-10-30 19:05:30 --> URI Class Initialized
INFO - 2023-10-30 19:05:30 --> Router Class Initialized
INFO - 2023-10-30 19:05:30 --> Output Class Initialized
INFO - 2023-10-30 19:05:30 --> Security Class Initialized
DEBUG - 2023-10-30 19:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 19:05:30 --> Input Class Initialized
INFO - 2023-10-30 19:05:30 --> Language Class Initialized
INFO - 2023-10-30 19:05:30 --> Loader Class Initialized
INFO - 2023-10-30 19:05:30 --> Helper loaded: url_helper
INFO - 2023-10-30 19:05:30 --> Helper loaded: form_helper
INFO - 2023-10-30 19:05:30 --> Helper loaded: file_helper
INFO - 2023-10-30 19:05:30 --> Database Driver Class Initialized
DEBUG - 2023-10-30 19:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 19:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 19:05:30 --> Form Validation Class Initialized
INFO - 2023-10-30 19:05:30 --> Upload Class Initialized
INFO - 2023-10-30 19:05:30 --> Model "M_auth" initialized
INFO - 2023-10-30 19:05:30 --> Model "M_user" initialized
INFO - 2023-10-30 19:05:30 --> Model "M_produk" initialized
INFO - 2023-10-30 19:05:30 --> Controller Class Initialized
DEBUG - 2023-10-30 19:05:30 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 19:05:30 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-30 19:05:30 --> Final output sent to browser
DEBUG - 2023-10-30 19:05:30 --> Total execution time: 0.5714
ERROR - 2023-10-30 19:06:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 19:06:39 --> Config Class Initialized
INFO - 2023-10-30 19:06:39 --> Hooks Class Initialized
DEBUG - 2023-10-30 19:06:39 --> UTF-8 Support Enabled
INFO - 2023-10-30 19:06:39 --> Utf8 Class Initialized
INFO - 2023-10-30 19:06:39 --> URI Class Initialized
INFO - 2023-10-30 19:06:39 --> Router Class Initialized
INFO - 2023-10-30 19:06:39 --> Output Class Initialized
INFO - 2023-10-30 19:06:39 --> Security Class Initialized
DEBUG - 2023-10-30 19:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 19:06:39 --> Input Class Initialized
INFO - 2023-10-30 19:06:39 --> Language Class Initialized
INFO - 2023-10-30 19:06:39 --> Loader Class Initialized
INFO - 2023-10-30 19:06:39 --> Helper loaded: url_helper
INFO - 2023-10-30 19:06:39 --> Helper loaded: form_helper
INFO - 2023-10-30 19:06:39 --> Helper loaded: file_helper
INFO - 2023-10-30 19:06:39 --> Database Driver Class Initialized
DEBUG - 2023-10-30 19:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 19:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 19:06:39 --> Form Validation Class Initialized
INFO - 2023-10-30 19:06:39 --> Upload Class Initialized
INFO - 2023-10-30 19:06:39 --> Model "M_auth" initialized
INFO - 2023-10-30 19:06:39 --> Model "M_user" initialized
INFO - 2023-10-30 19:06:39 --> Model "M_produk" initialized
INFO - 2023-10-30 19:06:39 --> Controller Class Initialized
DEBUG - 2023-10-30 19:06:39 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 19:06:40 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-30 19:06:40 --> Final output sent to browser
DEBUG - 2023-10-30 19:06:40 --> Total execution time: 0.5316
ERROR - 2023-10-30 19:07:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 19:07:49 --> Config Class Initialized
INFO - 2023-10-30 19:07:49 --> Hooks Class Initialized
DEBUG - 2023-10-30 19:07:49 --> UTF-8 Support Enabled
INFO - 2023-10-30 19:07:49 --> Utf8 Class Initialized
INFO - 2023-10-30 19:07:49 --> URI Class Initialized
INFO - 2023-10-30 19:07:49 --> Router Class Initialized
INFO - 2023-10-30 19:07:49 --> Output Class Initialized
INFO - 2023-10-30 19:07:49 --> Security Class Initialized
DEBUG - 2023-10-30 19:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 19:07:49 --> Input Class Initialized
INFO - 2023-10-30 19:07:49 --> Language Class Initialized
INFO - 2023-10-30 19:07:49 --> Loader Class Initialized
INFO - 2023-10-30 19:07:49 --> Helper loaded: url_helper
INFO - 2023-10-30 19:07:49 --> Helper loaded: form_helper
INFO - 2023-10-30 19:07:49 --> Helper loaded: file_helper
INFO - 2023-10-30 19:07:49 --> Database Driver Class Initialized
DEBUG - 2023-10-30 19:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 19:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 19:07:49 --> Form Validation Class Initialized
INFO - 2023-10-30 19:07:49 --> Upload Class Initialized
INFO - 2023-10-30 19:07:49 --> Model "M_auth" initialized
INFO - 2023-10-30 19:07:49 --> Model "M_user" initialized
INFO - 2023-10-30 19:07:49 --> Model "M_produk" initialized
INFO - 2023-10-30 19:07:49 --> Controller Class Initialized
DEBUG - 2023-10-30 19:07:49 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 19:07:49 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-30 19:07:49 --> Final output sent to browser
DEBUG - 2023-10-30 19:07:49 --> Total execution time: 0.5213
ERROR - 2023-10-30 19:07:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 19:07:55 --> Config Class Initialized
INFO - 2023-10-30 19:07:55 --> Hooks Class Initialized
DEBUG - 2023-10-30 19:07:55 --> UTF-8 Support Enabled
INFO - 2023-10-30 19:07:55 --> Utf8 Class Initialized
INFO - 2023-10-30 19:07:55 --> URI Class Initialized
DEBUG - 2023-10-30 19:07:55 --> No URI present. Default controller set.
INFO - 2023-10-30 19:07:55 --> Router Class Initialized
INFO - 2023-10-30 19:07:55 --> Output Class Initialized
INFO - 2023-10-30 19:07:55 --> Security Class Initialized
DEBUG - 2023-10-30 19:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 19:07:55 --> Input Class Initialized
INFO - 2023-10-30 19:07:55 --> Language Class Initialized
INFO - 2023-10-30 19:07:55 --> Loader Class Initialized
INFO - 2023-10-30 19:07:55 --> Helper loaded: url_helper
INFO - 2023-10-30 19:07:55 --> Helper loaded: form_helper
INFO - 2023-10-30 19:07:55 --> Helper loaded: file_helper
INFO - 2023-10-30 19:07:55 --> Database Driver Class Initialized
DEBUG - 2023-10-30 19:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 19:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 19:07:55 --> Form Validation Class Initialized
INFO - 2023-10-30 19:07:55 --> Upload Class Initialized
INFO - 2023-10-30 19:07:55 --> Model "M_auth" initialized
INFO - 2023-10-30 19:07:55 --> Model "M_user" initialized
INFO - 2023-10-30 19:07:55 --> Model "M_produk" initialized
INFO - 2023-10-30 19:07:55 --> Controller Class Initialized
INFO - 2023-10-30 19:07:55 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 19:07:55 --> Model "M_produk" initialized
DEBUG - 2023-10-30 19:07:55 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 19:07:55 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 19:07:55 --> Model "M_transaksi" initialized
INFO - 2023-10-30 19:07:55 --> Model "M_bank" initialized
INFO - 2023-10-30 19:07:55 --> Model "M_pesan" initialized
INFO - 2023-10-30 19:07:55 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 19:07:55 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-30 19:07:55 --> Final output sent to browser
DEBUG - 2023-10-30 19:07:55 --> Total execution time: 0.0509
ERROR - 2023-10-30 19:08:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 19:08:05 --> Config Class Initialized
INFO - 2023-10-30 19:08:05 --> Hooks Class Initialized
DEBUG - 2023-10-30 19:08:05 --> UTF-8 Support Enabled
INFO - 2023-10-30 19:08:05 --> Utf8 Class Initialized
INFO - 2023-10-30 19:08:05 --> URI Class Initialized
DEBUG - 2023-10-30 19:08:05 --> No URI present. Default controller set.
INFO - 2023-10-30 19:08:05 --> Router Class Initialized
INFO - 2023-10-30 19:08:05 --> Output Class Initialized
INFO - 2023-10-30 19:08:05 --> Security Class Initialized
DEBUG - 2023-10-30 19:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 19:08:05 --> Input Class Initialized
INFO - 2023-10-30 19:08:05 --> Language Class Initialized
INFO - 2023-10-30 19:08:05 --> Loader Class Initialized
INFO - 2023-10-30 19:08:05 --> Helper loaded: url_helper
INFO - 2023-10-30 19:08:05 --> Helper loaded: form_helper
INFO - 2023-10-30 19:08:05 --> Helper loaded: file_helper
INFO - 2023-10-30 19:08:05 --> Database Driver Class Initialized
DEBUG - 2023-10-30 19:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 19:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 19:08:05 --> Form Validation Class Initialized
INFO - 2023-10-30 19:08:05 --> Upload Class Initialized
INFO - 2023-10-30 19:08:05 --> Model "M_auth" initialized
INFO - 2023-10-30 19:08:05 --> Model "M_user" initialized
INFO - 2023-10-30 19:08:05 --> Model "M_produk" initialized
INFO - 2023-10-30 19:08:05 --> Controller Class Initialized
INFO - 2023-10-30 19:08:05 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 19:08:05 --> Model "M_produk" initialized
DEBUG - 2023-10-30 19:08:05 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 19:08:05 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 19:08:05 --> Model "M_transaksi" initialized
INFO - 2023-10-30 19:08:05 --> Model "M_bank" initialized
INFO - 2023-10-30 19:08:05 --> Model "M_pesan" initialized
INFO - 2023-10-30 19:08:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-10-30 19:08:05 --> Email Class Initialized
INFO - 2023-10-30 19:08:06 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-10-30 19:08:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 19:08:09 --> Config Class Initialized
INFO - 2023-10-30 19:08:09 --> Hooks Class Initialized
DEBUG - 2023-10-30 19:08:09 --> UTF-8 Support Enabled
INFO - 2023-10-30 19:08:09 --> Utf8 Class Initialized
INFO - 2023-10-30 19:08:09 --> URI Class Initialized
DEBUG - 2023-10-30 19:08:09 --> No URI present. Default controller set.
INFO - 2023-10-30 19:08:09 --> Router Class Initialized
INFO - 2023-10-30 19:08:09 --> Output Class Initialized
INFO - 2023-10-30 19:08:09 --> Security Class Initialized
DEBUG - 2023-10-30 19:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 19:08:09 --> Input Class Initialized
INFO - 2023-10-30 19:08:09 --> Language Class Initialized
INFO - 2023-10-30 19:08:09 --> Loader Class Initialized
INFO - 2023-10-30 19:08:09 --> Helper loaded: url_helper
INFO - 2023-10-30 19:08:09 --> Helper loaded: form_helper
INFO - 2023-10-30 19:08:09 --> Helper loaded: file_helper
INFO - 2023-10-30 19:08:09 --> Database Driver Class Initialized
DEBUG - 2023-10-30 19:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 19:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 19:08:09 --> Form Validation Class Initialized
INFO - 2023-10-30 19:08:09 --> Upload Class Initialized
INFO - 2023-10-30 19:08:09 --> Model "M_auth" initialized
INFO - 2023-10-30 19:08:09 --> Model "M_user" initialized
INFO - 2023-10-30 19:08:09 --> Model "M_produk" initialized
INFO - 2023-10-30 19:08:09 --> Controller Class Initialized
INFO - 2023-10-30 19:08:09 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 19:08:09 --> Model "M_produk" initialized
DEBUG - 2023-10-30 19:08:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 19:08:09 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 19:08:09 --> Model "M_transaksi" initialized
INFO - 2023-10-30 19:08:09 --> Model "M_bank" initialized
INFO - 2023-10-30 19:08:09 --> Model "M_pesan" initialized
INFO - 2023-10-30 19:08:09 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 19:08:09 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-30 19:08:09 --> Final output sent to browser
DEBUG - 2023-10-30 19:08:09 --> Total execution time: 0.0934
ERROR - 2023-10-30 19:08:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 19:08:17 --> Config Class Initialized
INFO - 2023-10-30 19:08:17 --> Hooks Class Initialized
DEBUG - 2023-10-30 19:08:17 --> UTF-8 Support Enabled
INFO - 2023-10-30 19:08:17 --> Utf8 Class Initialized
INFO - 2023-10-30 19:08:17 --> URI Class Initialized
DEBUG - 2023-10-30 19:08:17 --> No URI present. Default controller set.
INFO - 2023-10-30 19:08:17 --> Router Class Initialized
INFO - 2023-10-30 19:08:17 --> Output Class Initialized
INFO - 2023-10-30 19:08:17 --> Security Class Initialized
DEBUG - 2023-10-30 19:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 19:08:17 --> Input Class Initialized
INFO - 2023-10-30 19:08:17 --> Language Class Initialized
INFO - 2023-10-30 19:08:17 --> Loader Class Initialized
INFO - 2023-10-30 19:08:17 --> Helper loaded: url_helper
INFO - 2023-10-30 19:08:17 --> Helper loaded: form_helper
INFO - 2023-10-30 19:08:17 --> Helper loaded: file_helper
INFO - 2023-10-30 19:08:17 --> Database Driver Class Initialized
DEBUG - 2023-10-30 19:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 19:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 19:08:17 --> Form Validation Class Initialized
INFO - 2023-10-30 19:08:17 --> Upload Class Initialized
INFO - 2023-10-30 19:08:17 --> Model "M_auth" initialized
INFO - 2023-10-30 19:08:17 --> Model "M_user" initialized
INFO - 2023-10-30 19:08:17 --> Model "M_produk" initialized
INFO - 2023-10-30 19:08:17 --> Controller Class Initialized
INFO - 2023-10-30 19:08:17 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 19:08:17 --> Model "M_produk" initialized
DEBUG - 2023-10-30 19:08:17 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 19:08:17 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 19:08:17 --> Model "M_transaksi" initialized
INFO - 2023-10-30 19:08:17 --> Model "M_bank" initialized
INFO - 2023-10-30 19:08:17 --> Model "M_pesan" initialized
INFO - 2023-10-30 19:08:17 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 19:08:17 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-30 19:08:17 --> Final output sent to browser
DEBUG - 2023-10-30 19:08:17 --> Total execution time: 0.0796
ERROR - 2023-10-30 19:08:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 19:08:22 --> Config Class Initialized
INFO - 2023-10-30 19:08:22 --> Hooks Class Initialized
DEBUG - 2023-10-30 19:08:22 --> UTF-8 Support Enabled
INFO - 2023-10-30 19:08:22 --> Utf8 Class Initialized
INFO - 2023-10-30 19:08:22 --> URI Class Initialized
INFO - 2023-10-30 19:08:22 --> Router Class Initialized
INFO - 2023-10-30 19:08:22 --> Output Class Initialized
INFO - 2023-10-30 19:08:22 --> Security Class Initialized
DEBUG - 2023-10-30 19:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 19:08:22 --> Input Class Initialized
INFO - 2023-10-30 19:08:22 --> Language Class Initialized
INFO - 2023-10-30 19:08:22 --> Loader Class Initialized
INFO - 2023-10-30 19:08:22 --> Helper loaded: url_helper
INFO - 2023-10-30 19:08:22 --> Helper loaded: form_helper
INFO - 2023-10-30 19:08:22 --> Helper loaded: file_helper
INFO - 2023-10-30 19:08:22 --> Database Driver Class Initialized
DEBUG - 2023-10-30 19:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 19:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 19:08:22 --> Form Validation Class Initialized
INFO - 2023-10-30 19:08:22 --> Upload Class Initialized
INFO - 2023-10-30 19:08:22 --> Model "M_auth" initialized
INFO - 2023-10-30 19:08:22 --> Model "M_user" initialized
INFO - 2023-10-30 19:08:22 --> Model "M_produk" initialized
INFO - 2023-10-30 19:08:22 --> Controller Class Initialized
INFO - 2023-10-30 19:08:22 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 19:08:22 --> Model "M_produk" initialized
DEBUG - 2023-10-30 19:08:22 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 19:08:22 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 19:08:22 --> Model "M_transaksi" initialized
INFO - 2023-10-30 19:08:22 --> Model "M_bank" initialized
INFO - 2023-10-30 19:08:22 --> Model "M_pesan" initialized
INFO - 2023-10-30 19:08:22 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 19:08:22 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_produk_detail.php
INFO - 2023-10-30 19:08:22 --> Final output sent to browser
DEBUG - 2023-10-30 19:08:22 --> Total execution time: 0.1580
ERROR - 2023-10-30 19:08:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 19:08:22 --> Config Class Initialized
INFO - 2023-10-30 19:08:22 --> Hooks Class Initialized
DEBUG - 2023-10-30 19:08:22 --> UTF-8 Support Enabled
INFO - 2023-10-30 19:08:22 --> Utf8 Class Initialized
INFO - 2023-10-30 19:08:22 --> URI Class Initialized
INFO - 2023-10-30 19:08:22 --> Router Class Initialized
INFO - 2023-10-30 19:08:22 --> Output Class Initialized
INFO - 2023-10-30 19:08:22 --> Security Class Initialized
DEBUG - 2023-10-30 19:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 19:08:22 --> Input Class Initialized
INFO - 2023-10-30 19:08:22 --> Language Class Initialized
INFO - 2023-10-30 19:08:22 --> Loader Class Initialized
INFO - 2023-10-30 19:08:22 --> Helper loaded: url_helper
INFO - 2023-10-30 19:08:22 --> Helper loaded: form_helper
INFO - 2023-10-30 19:08:22 --> Helper loaded: file_helper
INFO - 2023-10-30 19:08:22 --> Database Driver Class Initialized
DEBUG - 2023-10-30 19:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 19:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 19:08:22 --> Form Validation Class Initialized
INFO - 2023-10-30 19:08:22 --> Upload Class Initialized
INFO - 2023-10-30 19:08:22 --> Model "M_auth" initialized
INFO - 2023-10-30 19:08:22 --> Model "M_user" initialized
INFO - 2023-10-30 19:08:22 --> Model "M_produk" initialized
INFO - 2023-10-30 19:08:22 --> Controller Class Initialized
INFO - 2023-10-30 19:08:22 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-10-30 19:08:22 --> Final output sent to browser
DEBUG - 2023-10-30 19:08:22 --> Total execution time: 0.0423
ERROR - 2023-10-30 19:08:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 19:08:41 --> Config Class Initialized
INFO - 2023-10-30 19:08:41 --> Hooks Class Initialized
DEBUG - 2023-10-30 19:08:41 --> UTF-8 Support Enabled
INFO - 2023-10-30 19:08:41 --> Utf8 Class Initialized
INFO - 2023-10-30 19:08:41 --> URI Class Initialized
INFO - 2023-10-30 19:08:41 --> Router Class Initialized
INFO - 2023-10-30 19:08:41 --> Output Class Initialized
INFO - 2023-10-30 19:08:41 --> Security Class Initialized
DEBUG - 2023-10-30 19:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 19:08:41 --> Input Class Initialized
INFO - 2023-10-30 19:08:41 --> Language Class Initialized
INFO - 2023-10-30 19:08:41 --> Loader Class Initialized
INFO - 2023-10-30 19:08:41 --> Helper loaded: url_helper
INFO - 2023-10-30 19:08:41 --> Helper loaded: form_helper
INFO - 2023-10-30 19:08:41 --> Helper loaded: file_helper
INFO - 2023-10-30 19:08:41 --> Database Driver Class Initialized
DEBUG - 2023-10-30 19:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 19:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 19:08:41 --> Form Validation Class Initialized
INFO - 2023-10-30 19:08:41 --> Upload Class Initialized
INFO - 2023-10-30 19:08:41 --> Model "M_auth" initialized
INFO - 2023-10-30 19:08:41 --> Model "M_user" initialized
INFO - 2023-10-30 19:08:41 --> Model "M_produk" initialized
INFO - 2023-10-30 19:08:41 --> Controller Class Initialized
INFO - 2023-10-30 19:08:41 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 19:08:41 --> Model "M_produk" initialized
DEBUG - 2023-10-30 19:08:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 19:08:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 19:08:41 --> Model "M_transaksi" initialized
INFO - 2023-10-30 19:08:41 --> Model "M_bank" initialized
INFO - 2023-10-30 19:08:41 --> Model "M_pesan" initialized
INFO - 2023-10-30 19:08:41 --> Email Class Initialized
INFO - 2023-10-30 19:08:42 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-10-30 19:08:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 19:08:44 --> Config Class Initialized
INFO - 2023-10-30 19:08:44 --> Hooks Class Initialized
DEBUG - 2023-10-30 19:08:44 --> UTF-8 Support Enabled
INFO - 2023-10-30 19:08:44 --> Utf8 Class Initialized
INFO - 2023-10-30 19:08:44 --> URI Class Initialized
INFO - 2023-10-30 19:08:44 --> Router Class Initialized
INFO - 2023-10-30 19:08:44 --> Output Class Initialized
INFO - 2023-10-30 19:08:44 --> Security Class Initialized
DEBUG - 2023-10-30 19:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 19:08:44 --> Input Class Initialized
INFO - 2023-10-30 19:08:44 --> Language Class Initialized
INFO - 2023-10-30 19:08:44 --> Loader Class Initialized
INFO - 2023-10-30 19:08:44 --> Helper loaded: url_helper
INFO - 2023-10-30 19:08:44 --> Helper loaded: form_helper
INFO - 2023-10-30 19:08:44 --> Helper loaded: file_helper
INFO - 2023-10-30 19:08:44 --> Database Driver Class Initialized
DEBUG - 2023-10-30 19:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 19:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 19:08:44 --> Form Validation Class Initialized
INFO - 2023-10-30 19:08:44 --> Upload Class Initialized
INFO - 2023-10-30 19:08:44 --> Model "M_auth" initialized
INFO - 2023-10-30 19:08:44 --> Model "M_user" initialized
INFO - 2023-10-30 19:08:44 --> Model "M_produk" initialized
INFO - 2023-10-30 19:08:44 --> Controller Class Initialized
INFO - 2023-10-30 19:08:44 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 19:08:44 --> Model "M_produk" initialized
DEBUG - 2023-10-30 19:08:44 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 19:08:44 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 19:08:45 --> Model "M_transaksi" initialized
INFO - 2023-10-30 19:08:45 --> Model "M_bank" initialized
INFO - 2023-10-30 19:08:45 --> Model "M_pesan" initialized
INFO - 2023-10-30 19:08:45 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 19:08:45 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 19:08:45 --> Final output sent to browser
DEBUG - 2023-10-30 19:08:45 --> Total execution time: 0.1114
ERROR - 2023-10-30 19:18:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 19:18:35 --> Config Class Initialized
INFO - 2023-10-30 19:18:35 --> Hooks Class Initialized
DEBUG - 2023-10-30 19:18:35 --> UTF-8 Support Enabled
INFO - 2023-10-30 19:18:35 --> Utf8 Class Initialized
INFO - 2023-10-30 19:18:35 --> URI Class Initialized
INFO - 2023-10-30 19:18:35 --> Router Class Initialized
INFO - 2023-10-30 19:18:35 --> Output Class Initialized
INFO - 2023-10-30 19:18:35 --> Security Class Initialized
DEBUG - 2023-10-30 19:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 19:18:35 --> Input Class Initialized
INFO - 2023-10-30 19:18:35 --> Language Class Initialized
INFO - 2023-10-30 19:18:35 --> Loader Class Initialized
INFO - 2023-10-30 19:18:35 --> Helper loaded: url_helper
INFO - 2023-10-30 19:18:35 --> Helper loaded: form_helper
INFO - 2023-10-30 19:18:35 --> Helper loaded: file_helper
INFO - 2023-10-30 19:18:35 --> Database Driver Class Initialized
DEBUG - 2023-10-30 19:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 19:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 19:18:35 --> Form Validation Class Initialized
INFO - 2023-10-30 19:18:35 --> Upload Class Initialized
INFO - 2023-10-30 19:18:35 --> Model "M_auth" initialized
INFO - 2023-10-30 19:18:35 --> Model "M_user" initialized
INFO - 2023-10-30 19:18:35 --> Model "M_produk" initialized
INFO - 2023-10-30 19:18:35 --> Controller Class Initialized
INFO - 2023-10-30 19:18:35 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 19:18:35 --> Model "M_produk" initialized
DEBUG - 2023-10-30 19:18:35 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 19:18:35 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 19:18:35 --> Model "M_transaksi" initialized
INFO - 2023-10-30 19:18:35 --> Model "M_bank" initialized
INFO - 2023-10-30 19:18:35 --> Model "M_pesan" initialized
INFO - 2023-10-30 19:18:35 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 19:18:35 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_bayar_sekarang.php
INFO - 2023-10-30 19:18:35 --> Final output sent to browser
DEBUG - 2023-10-30 19:18:35 --> Total execution time: 0.1187
ERROR - 2023-10-30 19:18:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 19:18:35 --> Config Class Initialized
INFO - 2023-10-30 19:18:35 --> Hooks Class Initialized
DEBUG - 2023-10-30 19:18:35 --> UTF-8 Support Enabled
INFO - 2023-10-30 19:18:35 --> Utf8 Class Initialized
INFO - 2023-10-30 19:18:35 --> URI Class Initialized
INFO - 2023-10-30 19:18:35 --> Router Class Initialized
INFO - 2023-10-30 19:18:35 --> Output Class Initialized
INFO - 2023-10-30 19:18:35 --> Security Class Initialized
DEBUG - 2023-10-30 19:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 19:18:35 --> Input Class Initialized
INFO - 2023-10-30 19:18:35 --> Language Class Initialized
INFO - 2023-10-30 19:18:35 --> Loader Class Initialized
INFO - 2023-10-30 19:18:35 --> Helper loaded: url_helper
INFO - 2023-10-30 19:18:35 --> Helper loaded: form_helper
INFO - 2023-10-30 19:18:35 --> Helper loaded: file_helper
INFO - 2023-10-30 19:18:35 --> Database Driver Class Initialized
DEBUG - 2023-10-30 19:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 19:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 19:18:35 --> Form Validation Class Initialized
INFO - 2023-10-30 19:18:35 --> Upload Class Initialized
INFO - 2023-10-30 19:18:35 --> Model "M_auth" initialized
INFO - 2023-10-30 19:18:35 --> Model "M_user" initialized
INFO - 2023-10-30 19:18:35 --> Model "M_produk" initialized
INFO - 2023-10-30 19:18:35 --> Controller Class Initialized
INFO - 2023-10-30 19:18:35 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-10-30 19:18:35 --> Final output sent to browser
DEBUG - 2023-10-30 19:18:35 --> Total execution time: 0.0304
ERROR - 2023-10-30 19:18:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 19:18:36 --> Config Class Initialized
INFO - 2023-10-30 19:18:36 --> Hooks Class Initialized
DEBUG - 2023-10-30 19:18:36 --> UTF-8 Support Enabled
INFO - 2023-10-30 19:18:36 --> Utf8 Class Initialized
INFO - 2023-10-30 19:18:36 --> URI Class Initialized
INFO - 2023-10-30 19:18:36 --> Router Class Initialized
INFO - 2023-10-30 19:18:36 --> Output Class Initialized
INFO - 2023-10-30 19:18:36 --> Security Class Initialized
DEBUG - 2023-10-30 19:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 19:18:36 --> Input Class Initialized
INFO - 2023-10-30 19:18:36 --> Language Class Initialized
INFO - 2023-10-30 19:18:36 --> Loader Class Initialized
INFO - 2023-10-30 19:18:36 --> Helper loaded: url_helper
INFO - 2023-10-30 19:18:36 --> Helper loaded: form_helper
INFO - 2023-10-30 19:18:36 --> Helper loaded: file_helper
INFO - 2023-10-30 19:18:36 --> Database Driver Class Initialized
DEBUG - 2023-10-30 19:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 19:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 19:18:36 --> Form Validation Class Initialized
INFO - 2023-10-30 19:18:36 --> Upload Class Initialized
INFO - 2023-10-30 19:18:36 --> Model "M_auth" initialized
INFO - 2023-10-30 19:18:36 --> Model "M_user" initialized
INFO - 2023-10-30 19:18:36 --> Model "M_produk" initialized
INFO - 2023-10-30 19:18:36 --> Controller Class Initialized
INFO - 2023-10-30 19:18:36 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 19:18:36 --> Model "M_produk" initialized
DEBUG - 2023-10-30 19:18:36 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 19:18:36 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 19:18:36 --> Model "M_transaksi" initialized
INFO - 2023-10-30 19:18:36 --> Model "M_bank" initialized
INFO - 2023-10-30 19:18:36 --> Model "M_pesan" initialized
INFO - 2023-10-30 19:18:36 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 19:18:36 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 19:18:36 --> Final output sent to browser
DEBUG - 2023-10-30 19:18:36 --> Total execution time: 0.0808
ERROR - 2023-10-30 19:23:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 19:23:33 --> Config Class Initialized
INFO - 2023-10-30 19:23:33 --> Hooks Class Initialized
DEBUG - 2023-10-30 19:23:33 --> UTF-8 Support Enabled
INFO - 2023-10-30 19:23:33 --> Utf8 Class Initialized
INFO - 2023-10-30 19:23:33 --> URI Class Initialized
INFO - 2023-10-30 19:23:33 --> Router Class Initialized
INFO - 2023-10-30 19:23:33 --> Output Class Initialized
INFO - 2023-10-30 19:23:33 --> Security Class Initialized
DEBUG - 2023-10-30 19:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 19:23:33 --> Input Class Initialized
INFO - 2023-10-30 19:23:33 --> Language Class Initialized
INFO - 2023-10-30 19:23:33 --> Loader Class Initialized
INFO - 2023-10-30 19:23:33 --> Helper loaded: url_helper
INFO - 2023-10-30 19:23:33 --> Helper loaded: form_helper
INFO - 2023-10-30 19:23:33 --> Helper loaded: file_helper
INFO - 2023-10-30 19:23:33 --> Database Driver Class Initialized
DEBUG - 2023-10-30 19:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 19:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 19:23:33 --> Form Validation Class Initialized
INFO - 2023-10-30 19:23:33 --> Upload Class Initialized
INFO - 2023-10-30 19:23:34 --> Model "M_auth" initialized
INFO - 2023-10-30 19:23:34 --> Model "M_user" initialized
INFO - 2023-10-30 19:23:34 --> Model "M_produk" initialized
INFO - 2023-10-30 19:23:34 --> Controller Class Initialized
INFO - 2023-10-30 19:23:34 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 19:23:34 --> Model "M_produk" initialized
DEBUG - 2023-10-30 19:23:34 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 19:23:34 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 19:23:34 --> Model "M_transaksi" initialized
INFO - 2023-10-30 19:23:34 --> Model "M_bank" initialized
INFO - 2023-10-30 19:23:34 --> Model "M_pesan" initialized
INFO - 2023-10-30 19:23:34 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 19:23:34 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_bayar_sekarang.php
INFO - 2023-10-30 19:23:34 --> Final output sent to browser
DEBUG - 2023-10-30 19:23:34 --> Total execution time: 0.0831
ERROR - 2023-10-30 19:23:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 19:23:34 --> Config Class Initialized
INFO - 2023-10-30 19:23:34 --> Hooks Class Initialized
DEBUG - 2023-10-30 19:23:34 --> UTF-8 Support Enabled
INFO - 2023-10-30 19:23:34 --> Utf8 Class Initialized
INFO - 2023-10-30 19:23:34 --> URI Class Initialized
INFO - 2023-10-30 19:23:34 --> Router Class Initialized
INFO - 2023-10-30 19:23:34 --> Output Class Initialized
INFO - 2023-10-30 19:23:34 --> Security Class Initialized
DEBUG - 2023-10-30 19:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 19:23:34 --> Input Class Initialized
INFO - 2023-10-30 19:23:34 --> Language Class Initialized
INFO - 2023-10-30 19:23:34 --> Loader Class Initialized
INFO - 2023-10-30 19:23:34 --> Helper loaded: url_helper
INFO - 2023-10-30 19:23:34 --> Helper loaded: form_helper
INFO - 2023-10-30 19:23:34 --> Helper loaded: file_helper
INFO - 2023-10-30 19:23:34 --> Database Driver Class Initialized
DEBUG - 2023-10-30 19:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 19:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 19:23:34 --> Form Validation Class Initialized
INFO - 2023-10-30 19:23:34 --> Upload Class Initialized
INFO - 2023-10-30 19:23:34 --> Model "M_auth" initialized
INFO - 2023-10-30 19:23:34 --> Model "M_user" initialized
INFO - 2023-10-30 19:23:34 --> Model "M_produk" initialized
INFO - 2023-10-30 19:23:34 --> Controller Class Initialized
INFO - 2023-10-30 19:23:34 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-10-30 19:23:34 --> Final output sent to browser
DEBUG - 2023-10-30 19:23:34 --> Total execution time: 0.0415
ERROR - 2023-10-30 19:23:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 19:23:37 --> Config Class Initialized
INFO - 2023-10-30 19:23:37 --> Hooks Class Initialized
DEBUG - 2023-10-30 19:23:37 --> UTF-8 Support Enabled
INFO - 2023-10-30 19:23:37 --> Utf8 Class Initialized
INFO - 2023-10-30 19:23:37 --> URI Class Initialized
INFO - 2023-10-30 19:23:37 --> Router Class Initialized
INFO - 2023-10-30 19:23:37 --> Output Class Initialized
INFO - 2023-10-30 19:23:37 --> Security Class Initialized
DEBUG - 2023-10-30 19:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 19:23:37 --> Input Class Initialized
INFO - 2023-10-30 19:23:37 --> Language Class Initialized
INFO - 2023-10-30 19:23:37 --> Loader Class Initialized
INFO - 2023-10-30 19:23:37 --> Helper loaded: url_helper
INFO - 2023-10-30 19:23:37 --> Helper loaded: form_helper
INFO - 2023-10-30 19:23:37 --> Helper loaded: file_helper
INFO - 2023-10-30 19:23:37 --> Database Driver Class Initialized
DEBUG - 2023-10-30 19:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 19:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 19:23:37 --> Form Validation Class Initialized
INFO - 2023-10-30 19:23:37 --> Upload Class Initialized
INFO - 2023-10-30 19:23:37 --> Model "M_auth" initialized
INFO - 2023-10-30 19:23:37 --> Model "M_user" initialized
INFO - 2023-10-30 19:23:37 --> Model "M_produk" initialized
INFO - 2023-10-30 19:23:37 --> Controller Class Initialized
INFO - 2023-10-30 19:23:37 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 19:23:37 --> Model "M_produk" initialized
DEBUG - 2023-10-30 19:23:37 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 19:23:37 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 19:23:37 --> Model "M_transaksi" initialized
INFO - 2023-10-30 19:23:37 --> Model "M_bank" initialized
INFO - 2023-10-30 19:23:37 --> Model "M_pesan" initialized
INFO - 2023-10-30 19:23:37 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 19:23:37 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 19:23:37 --> Final output sent to browser
DEBUG - 2023-10-30 19:23:37 --> Total execution time: 0.0842
ERROR - 2023-10-30 19:23:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 19:23:50 --> Config Class Initialized
INFO - 2023-10-30 19:23:50 --> Hooks Class Initialized
DEBUG - 2023-10-30 19:23:50 --> UTF-8 Support Enabled
INFO - 2023-10-30 19:23:50 --> Utf8 Class Initialized
INFO - 2023-10-30 19:23:50 --> URI Class Initialized
INFO - 2023-10-30 19:23:50 --> Router Class Initialized
INFO - 2023-10-30 19:23:50 --> Output Class Initialized
INFO - 2023-10-30 19:23:50 --> Security Class Initialized
DEBUG - 2023-10-30 19:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 19:23:50 --> Input Class Initialized
INFO - 2023-10-30 19:23:50 --> Language Class Initialized
INFO - 2023-10-30 19:23:50 --> Loader Class Initialized
INFO - 2023-10-30 19:23:50 --> Helper loaded: url_helper
INFO - 2023-10-30 19:23:50 --> Helper loaded: form_helper
INFO - 2023-10-30 19:23:50 --> Helper loaded: file_helper
INFO - 2023-10-30 19:23:50 --> Database Driver Class Initialized
DEBUG - 2023-10-30 19:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 19:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 19:23:50 --> Form Validation Class Initialized
INFO - 2023-10-30 19:23:50 --> Upload Class Initialized
INFO - 2023-10-30 19:23:50 --> Model "M_auth" initialized
INFO - 2023-10-30 19:23:50 --> Model "M_user" initialized
INFO - 2023-10-30 19:23:50 --> Model "M_produk" initialized
INFO - 2023-10-30 19:23:50 --> Controller Class Initialized
INFO - 2023-10-30 19:23:50 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 19:23:50 --> Model "M_produk" initialized
DEBUG - 2023-10-30 19:23:50 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 19:23:50 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 19:23:50 --> Model "M_transaksi" initialized
INFO - 2023-10-30 19:23:50 --> Model "M_bank" initialized
INFO - 2023-10-30 19:23:50 --> Model "M_pesan" initialized
INFO - 2023-10-30 19:23:50 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 19:23:50 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_bayar_sekarang.php
INFO - 2023-10-30 19:23:50 --> Final output sent to browser
DEBUG - 2023-10-30 19:23:50 --> Total execution time: 0.0588
ERROR - 2023-10-30 19:23:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 19:23:50 --> Config Class Initialized
INFO - 2023-10-30 19:23:50 --> Hooks Class Initialized
DEBUG - 2023-10-30 19:23:50 --> UTF-8 Support Enabled
INFO - 2023-10-30 19:23:50 --> Utf8 Class Initialized
INFO - 2023-10-30 19:23:50 --> URI Class Initialized
INFO - 2023-10-30 19:23:50 --> Router Class Initialized
INFO - 2023-10-30 19:23:50 --> Output Class Initialized
INFO - 2023-10-30 19:23:50 --> Security Class Initialized
DEBUG - 2023-10-30 19:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 19:23:50 --> Input Class Initialized
INFO - 2023-10-30 19:23:50 --> Language Class Initialized
INFO - 2023-10-30 19:23:50 --> Loader Class Initialized
INFO - 2023-10-30 19:23:50 --> Helper loaded: url_helper
INFO - 2023-10-30 19:23:50 --> Helper loaded: form_helper
INFO - 2023-10-30 19:23:50 --> Helper loaded: file_helper
INFO - 2023-10-30 19:23:50 --> Database Driver Class Initialized
DEBUG - 2023-10-30 19:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 19:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 19:23:50 --> Form Validation Class Initialized
INFO - 2023-10-30 19:23:50 --> Upload Class Initialized
INFO - 2023-10-30 19:23:50 --> Model "M_auth" initialized
INFO - 2023-10-30 19:23:50 --> Model "M_user" initialized
INFO - 2023-10-30 19:23:50 --> Model "M_produk" initialized
INFO - 2023-10-30 19:23:50 --> Controller Class Initialized
INFO - 2023-10-30 19:23:50 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-10-30 19:23:50 --> Final output sent to browser
DEBUG - 2023-10-30 19:23:50 --> Total execution time: 0.0528
ERROR - 2023-10-30 19:24:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 19:24:02 --> Config Class Initialized
INFO - 2023-10-30 19:24:02 --> Hooks Class Initialized
DEBUG - 2023-10-30 19:24:02 --> UTF-8 Support Enabled
INFO - 2023-10-30 19:24:02 --> Utf8 Class Initialized
INFO - 2023-10-30 19:24:02 --> URI Class Initialized
INFO - 2023-10-30 19:24:02 --> Router Class Initialized
INFO - 2023-10-30 19:24:02 --> Output Class Initialized
INFO - 2023-10-30 19:24:02 --> Security Class Initialized
DEBUG - 2023-10-30 19:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 19:24:02 --> Input Class Initialized
INFO - 2023-10-30 19:24:02 --> Language Class Initialized
INFO - 2023-10-30 19:24:02 --> Loader Class Initialized
INFO - 2023-10-30 19:24:02 --> Helper loaded: url_helper
INFO - 2023-10-30 19:24:02 --> Helper loaded: form_helper
INFO - 2023-10-30 19:24:02 --> Helper loaded: file_helper
INFO - 2023-10-30 19:24:02 --> Database Driver Class Initialized
DEBUG - 2023-10-30 19:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 19:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 19:24:02 --> Form Validation Class Initialized
INFO - 2023-10-30 19:24:02 --> Upload Class Initialized
INFO - 2023-10-30 19:24:02 --> Model "M_auth" initialized
INFO - 2023-10-30 19:24:02 --> Model "M_user" initialized
INFO - 2023-10-30 19:24:02 --> Model "M_produk" initialized
INFO - 2023-10-30 19:24:02 --> Controller Class Initialized
INFO - 2023-10-30 19:24:02 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 19:24:02 --> Model "M_produk" initialized
DEBUG - 2023-10-30 19:24:02 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 19:24:02 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 19:24:02 --> Model "M_transaksi" initialized
INFO - 2023-10-30 19:24:02 --> Model "M_bank" initialized
INFO - 2023-10-30 19:24:02 --> Model "M_pesan" initialized
INFO - 2023-10-30 19:24:02 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 19:24:02 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 19:24:02 --> Final output sent to browser
DEBUG - 2023-10-30 19:24:02 --> Total execution time: 0.1065
ERROR - 2023-10-30 19:28:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 19:28:32 --> Config Class Initialized
INFO - 2023-10-30 19:28:32 --> Hooks Class Initialized
DEBUG - 2023-10-30 19:28:32 --> UTF-8 Support Enabled
INFO - 2023-10-30 19:28:32 --> Utf8 Class Initialized
INFO - 2023-10-30 19:28:32 --> URI Class Initialized
INFO - 2023-10-30 19:28:32 --> Router Class Initialized
INFO - 2023-10-30 19:28:32 --> Output Class Initialized
INFO - 2023-10-30 19:28:32 --> Security Class Initialized
DEBUG - 2023-10-30 19:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 19:28:32 --> Input Class Initialized
INFO - 2023-10-30 19:28:32 --> Language Class Initialized
INFO - 2023-10-30 19:28:32 --> Loader Class Initialized
INFO - 2023-10-30 19:28:32 --> Helper loaded: url_helper
INFO - 2023-10-30 19:28:32 --> Helper loaded: form_helper
INFO - 2023-10-30 19:28:32 --> Helper loaded: file_helper
INFO - 2023-10-30 19:28:32 --> Database Driver Class Initialized
DEBUG - 2023-10-30 19:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 19:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 19:28:32 --> Form Validation Class Initialized
INFO - 2023-10-30 19:28:32 --> Upload Class Initialized
INFO - 2023-10-30 19:28:32 --> Model "M_auth" initialized
INFO - 2023-10-30 19:28:32 --> Model "M_user" initialized
INFO - 2023-10-30 19:28:32 --> Model "M_produk" initialized
INFO - 2023-10-30 19:28:32 --> Controller Class Initialized
INFO - 2023-10-30 19:28:32 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 19:28:32 --> Model "M_produk" initialized
DEBUG - 2023-10-30 19:28:32 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 19:28:32 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 19:28:32 --> Model "M_transaksi" initialized
INFO - 2023-10-30 19:28:32 --> Model "M_bank" initialized
INFO - 2023-10-30 19:28:32 --> Model "M_pesan" initialized
ERROR - 2023-10-30 19:28:32 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front\v_booking_saya.php 218
INFO - 2023-10-30 19:28:32 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 19:28:32 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 19:28:32 --> Final output sent to browser
DEBUG - 2023-10-30 19:28:32 --> Total execution time: 0.1358
ERROR - 2023-10-30 19:28:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 19:28:55 --> Config Class Initialized
INFO - 2023-10-30 19:28:55 --> Hooks Class Initialized
DEBUG - 2023-10-30 19:28:55 --> UTF-8 Support Enabled
INFO - 2023-10-30 19:28:55 --> Utf8 Class Initialized
INFO - 2023-10-30 19:28:55 --> URI Class Initialized
INFO - 2023-10-30 19:28:55 --> Router Class Initialized
INFO - 2023-10-30 19:28:55 --> Output Class Initialized
INFO - 2023-10-30 19:28:55 --> Security Class Initialized
DEBUG - 2023-10-30 19:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 19:28:55 --> Input Class Initialized
INFO - 2023-10-30 19:28:55 --> Language Class Initialized
INFO - 2023-10-30 19:28:55 --> Loader Class Initialized
INFO - 2023-10-30 19:28:55 --> Helper loaded: url_helper
INFO - 2023-10-30 19:28:55 --> Helper loaded: form_helper
INFO - 2023-10-30 19:28:55 --> Helper loaded: file_helper
INFO - 2023-10-30 19:28:55 --> Database Driver Class Initialized
DEBUG - 2023-10-30 19:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 19:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 19:28:55 --> Form Validation Class Initialized
INFO - 2023-10-30 19:28:55 --> Upload Class Initialized
INFO - 2023-10-30 19:28:55 --> Model "M_auth" initialized
INFO - 2023-10-30 19:28:55 --> Model "M_user" initialized
INFO - 2023-10-30 19:28:55 --> Model "M_produk" initialized
INFO - 2023-10-30 19:28:55 --> Controller Class Initialized
INFO - 2023-10-30 19:28:55 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 19:28:55 --> Model "M_produk" initialized
DEBUG - 2023-10-30 19:28:55 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 19:28:55 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 19:28:55 --> Model "M_transaksi" initialized
INFO - 2023-10-30 19:28:55 --> Model "M_bank" initialized
INFO - 2023-10-30 19:28:55 --> Model "M_pesan" initialized
ERROR - 2023-10-30 19:28:55 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front\v_booking_saya.php 218
INFO - 2023-10-30 19:28:55 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 19:28:55 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 19:28:55 --> Final output sent to browser
DEBUG - 2023-10-30 19:28:55 --> Total execution time: 0.0632
ERROR - 2023-10-30 19:59:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 19:59:17 --> Config Class Initialized
INFO - 2023-10-30 19:59:17 --> Hooks Class Initialized
DEBUG - 2023-10-30 19:59:17 --> UTF-8 Support Enabled
INFO - 2023-10-30 19:59:17 --> Utf8 Class Initialized
INFO - 2023-10-30 19:59:17 --> URI Class Initialized
INFO - 2023-10-30 19:59:17 --> Router Class Initialized
INFO - 2023-10-30 19:59:17 --> Output Class Initialized
INFO - 2023-10-30 19:59:17 --> Security Class Initialized
DEBUG - 2023-10-30 19:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 19:59:17 --> Input Class Initialized
INFO - 2023-10-30 19:59:17 --> Language Class Initialized
INFO - 2023-10-30 19:59:17 --> Loader Class Initialized
INFO - 2023-10-30 19:59:17 --> Helper loaded: url_helper
INFO - 2023-10-30 19:59:17 --> Helper loaded: form_helper
INFO - 2023-10-30 19:59:17 --> Helper loaded: file_helper
INFO - 2023-10-30 19:59:17 --> Database Driver Class Initialized
DEBUG - 2023-10-30 19:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 19:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 19:59:17 --> Form Validation Class Initialized
INFO - 2023-10-30 19:59:17 --> Upload Class Initialized
INFO - 2023-10-30 19:59:17 --> Model "M_auth" initialized
INFO - 2023-10-30 19:59:17 --> Model "M_user" initialized
INFO - 2023-10-30 19:59:17 --> Model "M_produk" initialized
INFO - 2023-10-30 19:59:17 --> Controller Class Initialized
INFO - 2023-10-30 19:59:17 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 19:59:17 --> Model "M_produk" initialized
DEBUG - 2023-10-30 19:59:17 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 19:59:17 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 19:59:17 --> Model "M_transaksi" initialized
INFO - 2023-10-30 19:59:17 --> Model "M_bank" initialized
INFO - 2023-10-30 19:59:17 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 19:59:17 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-30 19:59:17 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front\v_booking_saya.php 218
INFO - 2023-10-30 19:59:17 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 19:59:17 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 19:59:17 --> Final output sent to browser
DEBUG - 2023-10-30 19:59:17 --> Total execution time: 0.0888
ERROR - 2023-10-30 20:00:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:00:00 --> Config Class Initialized
INFO - 2023-10-30 20:00:00 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:00:00 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:00:00 --> Utf8 Class Initialized
INFO - 2023-10-30 20:00:00 --> URI Class Initialized
INFO - 2023-10-30 20:00:00 --> Router Class Initialized
INFO - 2023-10-30 20:00:00 --> Output Class Initialized
INFO - 2023-10-30 20:00:00 --> Security Class Initialized
DEBUG - 2023-10-30 20:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:00:00 --> Input Class Initialized
INFO - 2023-10-30 20:00:00 --> Language Class Initialized
INFO - 2023-10-30 20:00:00 --> Loader Class Initialized
INFO - 2023-10-30 20:00:00 --> Helper loaded: url_helper
INFO - 2023-10-30 20:00:00 --> Helper loaded: form_helper
INFO - 2023-10-30 20:00:00 --> Helper loaded: file_helper
INFO - 2023-10-30 20:00:00 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:00:00 --> Form Validation Class Initialized
INFO - 2023-10-30 20:00:00 --> Upload Class Initialized
INFO - 2023-10-30 20:00:00 --> Model "M_auth" initialized
INFO - 2023-10-30 20:00:00 --> Model "M_user" initialized
INFO - 2023-10-30 20:00:00 --> Model "M_produk" initialized
INFO - 2023-10-30 20:00:00 --> Controller Class Initialized
INFO - 2023-10-30 20:00:00 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:00:00 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:00:00 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:00:00 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:00:00 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:00:00 --> Model "M_bank" initialized
INFO - 2023-10-30 20:00:00 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:00:00 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-30 20:00:00 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front\v_booking_saya.php 217
INFO - 2023-10-30 20:00:00 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:00:00 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:00:00 --> Final output sent to browser
DEBUG - 2023-10-30 20:00:00 --> Total execution time: 0.1205
ERROR - 2023-10-30 20:00:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:00:04 --> Config Class Initialized
INFO - 2023-10-30 20:00:04 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:00:04 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:00:04 --> Utf8 Class Initialized
INFO - 2023-10-30 20:00:04 --> URI Class Initialized
INFO - 2023-10-30 20:00:04 --> Router Class Initialized
INFO - 2023-10-30 20:00:04 --> Output Class Initialized
INFO - 2023-10-30 20:00:04 --> Security Class Initialized
DEBUG - 2023-10-30 20:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:00:04 --> Input Class Initialized
INFO - 2023-10-30 20:00:04 --> Language Class Initialized
INFO - 2023-10-30 20:00:04 --> Loader Class Initialized
INFO - 2023-10-30 20:00:04 --> Helper loaded: url_helper
INFO - 2023-10-30 20:00:04 --> Helper loaded: form_helper
INFO - 2023-10-30 20:00:04 --> Helper loaded: file_helper
INFO - 2023-10-30 20:00:04 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:00:04 --> Form Validation Class Initialized
INFO - 2023-10-30 20:00:04 --> Upload Class Initialized
INFO - 2023-10-30 20:00:04 --> Model "M_auth" initialized
INFO - 2023-10-30 20:00:04 --> Model "M_user" initialized
INFO - 2023-10-30 20:00:04 --> Model "M_produk" initialized
INFO - 2023-10-30 20:00:04 --> Controller Class Initialized
INFO - 2023-10-30 20:00:04 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:00:04 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:00:04 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:00:04 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:00:04 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:00:04 --> Model "M_bank" initialized
INFO - 2023-10-30 20:00:04 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:00:04 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 20:00:04 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:00:04 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_bayar_sekarang.php
INFO - 2023-10-30 20:00:04 --> Final output sent to browser
DEBUG - 2023-10-30 20:00:04 --> Total execution time: 0.0618
ERROR - 2023-10-30 20:00:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:00:04 --> Config Class Initialized
INFO - 2023-10-30 20:00:04 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:00:04 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:00:04 --> Utf8 Class Initialized
INFO - 2023-10-30 20:00:04 --> URI Class Initialized
INFO - 2023-10-30 20:00:04 --> Router Class Initialized
INFO - 2023-10-30 20:00:04 --> Output Class Initialized
INFO - 2023-10-30 20:00:04 --> Security Class Initialized
DEBUG - 2023-10-30 20:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:00:04 --> Input Class Initialized
INFO - 2023-10-30 20:00:04 --> Language Class Initialized
INFO - 2023-10-30 20:00:04 --> Loader Class Initialized
INFO - 2023-10-30 20:00:04 --> Helper loaded: url_helper
INFO - 2023-10-30 20:00:04 --> Helper loaded: form_helper
INFO - 2023-10-30 20:00:04 --> Helper loaded: file_helper
INFO - 2023-10-30 20:00:04 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:00:04 --> Form Validation Class Initialized
INFO - 2023-10-30 20:00:04 --> Upload Class Initialized
INFO - 2023-10-30 20:00:04 --> Model "M_auth" initialized
INFO - 2023-10-30 20:00:04 --> Model "M_user" initialized
INFO - 2023-10-30 20:00:04 --> Model "M_produk" initialized
INFO - 2023-10-30 20:00:04 --> Controller Class Initialized
INFO - 2023-10-30 20:00:04 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-10-30 20:00:04 --> Final output sent to browser
DEBUG - 2023-10-30 20:00:04 --> Total execution time: 0.0454
ERROR - 2023-10-30 20:00:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:00:06 --> Config Class Initialized
INFO - 2023-10-30 20:00:06 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:00:06 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:00:06 --> Utf8 Class Initialized
INFO - 2023-10-30 20:00:06 --> URI Class Initialized
INFO - 2023-10-30 20:00:06 --> Router Class Initialized
INFO - 2023-10-30 20:00:06 --> Output Class Initialized
INFO - 2023-10-30 20:00:06 --> Security Class Initialized
DEBUG - 2023-10-30 20:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:00:06 --> Input Class Initialized
INFO - 2023-10-30 20:00:06 --> Language Class Initialized
INFO - 2023-10-30 20:00:06 --> Loader Class Initialized
INFO - 2023-10-30 20:00:06 --> Helper loaded: url_helper
INFO - 2023-10-30 20:00:06 --> Helper loaded: form_helper
INFO - 2023-10-30 20:00:06 --> Helper loaded: file_helper
INFO - 2023-10-30 20:00:06 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:00:06 --> Form Validation Class Initialized
INFO - 2023-10-30 20:00:06 --> Upload Class Initialized
INFO - 2023-10-30 20:00:06 --> Model "M_auth" initialized
INFO - 2023-10-30 20:00:06 --> Model "M_user" initialized
INFO - 2023-10-30 20:00:06 --> Model "M_produk" initialized
INFO - 2023-10-30 20:00:06 --> Controller Class Initialized
INFO - 2023-10-30 20:00:06 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:00:06 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:00:06 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:00:06 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:00:06 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:00:06 --> Model "M_bank" initialized
INFO - 2023-10-30 20:00:06 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:00:06 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-30 20:00:06 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front\v_booking_saya.php 217
INFO - 2023-10-30 20:00:06 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:00:06 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:00:06 --> Final output sent to browser
DEBUG - 2023-10-30 20:00:06 --> Total execution time: 0.1031
ERROR - 2023-10-30 20:01:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:01:26 --> Config Class Initialized
INFO - 2023-10-30 20:01:26 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:01:26 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:01:26 --> Utf8 Class Initialized
INFO - 2023-10-30 20:01:26 --> URI Class Initialized
INFO - 2023-10-30 20:01:26 --> Router Class Initialized
INFO - 2023-10-30 20:01:26 --> Output Class Initialized
INFO - 2023-10-30 20:01:26 --> Security Class Initialized
DEBUG - 2023-10-30 20:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:01:26 --> Input Class Initialized
INFO - 2023-10-30 20:01:26 --> Language Class Initialized
INFO - 2023-10-30 20:01:26 --> Loader Class Initialized
INFO - 2023-10-30 20:01:26 --> Helper loaded: url_helper
INFO - 2023-10-30 20:01:26 --> Helper loaded: form_helper
INFO - 2023-10-30 20:01:26 --> Helper loaded: file_helper
INFO - 2023-10-30 20:01:26 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:01:26 --> Form Validation Class Initialized
INFO - 2023-10-30 20:01:26 --> Upload Class Initialized
INFO - 2023-10-30 20:01:26 --> Model "M_auth" initialized
INFO - 2023-10-30 20:01:26 --> Model "M_user" initialized
INFO - 2023-10-30 20:01:26 --> Model "M_produk" initialized
INFO - 2023-10-30 20:01:26 --> Controller Class Initialized
INFO - 2023-10-30 20:01:26 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:01:26 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:01:26 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:01:26 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:01:26 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:01:26 --> Model "M_bank" initialized
INFO - 2023-10-30 20:01:26 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:01:26 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-30 20:01:26 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front\v_booking_saya.php 218
INFO - 2023-10-30 20:01:26 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:01:26 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:01:26 --> Final output sent to browser
DEBUG - 2023-10-30 20:01:26 --> Total execution time: 0.0851
ERROR - 2023-10-30 20:02:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:02:09 --> Config Class Initialized
INFO - 2023-10-30 20:02:09 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:02:09 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:02:09 --> Utf8 Class Initialized
INFO - 2023-10-30 20:02:09 --> URI Class Initialized
INFO - 2023-10-30 20:02:09 --> Router Class Initialized
INFO - 2023-10-30 20:02:09 --> Output Class Initialized
INFO - 2023-10-30 20:02:09 --> Security Class Initialized
DEBUG - 2023-10-30 20:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:02:09 --> Input Class Initialized
INFO - 2023-10-30 20:02:09 --> Language Class Initialized
INFO - 2023-10-30 20:02:09 --> Loader Class Initialized
INFO - 2023-10-30 20:02:09 --> Helper loaded: url_helper
INFO - 2023-10-30 20:02:09 --> Helper loaded: form_helper
INFO - 2023-10-30 20:02:09 --> Helper loaded: file_helper
INFO - 2023-10-30 20:02:09 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:02:09 --> Form Validation Class Initialized
INFO - 2023-10-30 20:02:09 --> Upload Class Initialized
INFO - 2023-10-30 20:02:09 --> Model "M_auth" initialized
INFO - 2023-10-30 20:02:09 --> Model "M_user" initialized
INFO - 2023-10-30 20:02:09 --> Model "M_produk" initialized
INFO - 2023-10-30 20:02:09 --> Controller Class Initialized
INFO - 2023-10-30 20:02:09 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:02:09 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:02:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:02:09 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:02:09 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:02:09 --> Model "M_bank" initialized
INFO - 2023-10-30 20:02:09 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:02:09 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-30 20:02:09 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front\v_booking_saya.php 218
INFO - 2023-10-30 20:02:09 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:02:09 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:02:09 --> Final output sent to browser
DEBUG - 2023-10-30 20:02:09 --> Total execution time: 0.0585
ERROR - 2023-10-30 20:03:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:03:09 --> Config Class Initialized
INFO - 2023-10-30 20:03:09 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:03:09 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:03:09 --> Utf8 Class Initialized
INFO - 2023-10-30 20:03:09 --> URI Class Initialized
INFO - 2023-10-30 20:03:09 --> Router Class Initialized
INFO - 2023-10-30 20:03:09 --> Output Class Initialized
INFO - 2023-10-30 20:03:09 --> Security Class Initialized
DEBUG - 2023-10-30 20:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:03:09 --> Input Class Initialized
INFO - 2023-10-30 20:03:09 --> Language Class Initialized
INFO - 2023-10-30 20:03:09 --> Loader Class Initialized
INFO - 2023-10-30 20:03:09 --> Helper loaded: url_helper
INFO - 2023-10-30 20:03:09 --> Helper loaded: form_helper
INFO - 2023-10-30 20:03:09 --> Helper loaded: file_helper
INFO - 2023-10-30 20:03:09 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:03:09 --> Form Validation Class Initialized
INFO - 2023-10-30 20:03:09 --> Upload Class Initialized
INFO - 2023-10-30 20:03:09 --> Model "M_auth" initialized
INFO - 2023-10-30 20:03:09 --> Model "M_user" initialized
INFO - 2023-10-30 20:03:09 --> Model "M_produk" initialized
INFO - 2023-10-30 20:03:09 --> Controller Class Initialized
INFO - 2023-10-30 20:03:09 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:03:09 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:03:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:03:10 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:03:10 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:03:10 --> Model "M_bank" initialized
INFO - 2023-10-30 20:03:10 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:03:10 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-30 20:03:10 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front\v_booking_saya.php 218
INFO - 2023-10-30 20:03:10 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:03:10 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:03:10 --> Final output sent to browser
DEBUG - 2023-10-30 20:03:10 --> Total execution time: 0.1012
ERROR - 2023-10-30 20:06:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:06:59 --> Config Class Initialized
INFO - 2023-10-30 20:06:59 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:06:59 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:06:59 --> Utf8 Class Initialized
INFO - 2023-10-30 20:07:00 --> URI Class Initialized
INFO - 2023-10-30 20:07:00 --> Router Class Initialized
INFO - 2023-10-30 20:07:00 --> Output Class Initialized
INFO - 2023-10-30 20:07:00 --> Security Class Initialized
DEBUG - 2023-10-30 20:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:07:00 --> Input Class Initialized
INFO - 2023-10-30 20:07:00 --> Language Class Initialized
INFO - 2023-10-30 20:07:00 --> Loader Class Initialized
INFO - 2023-10-30 20:07:00 --> Helper loaded: url_helper
INFO - 2023-10-30 20:07:00 --> Helper loaded: form_helper
INFO - 2023-10-30 20:07:00 --> Helper loaded: file_helper
INFO - 2023-10-30 20:07:00 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:07:00 --> Form Validation Class Initialized
INFO - 2023-10-30 20:07:00 --> Upload Class Initialized
INFO - 2023-10-30 20:07:00 --> Model "M_auth" initialized
INFO - 2023-10-30 20:07:00 --> Model "M_user" initialized
INFO - 2023-10-30 20:07:00 --> Model "M_produk" initialized
INFO - 2023-10-30 20:07:00 --> Controller Class Initialized
INFO - 2023-10-30 20:07:00 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:07:00 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:07:00 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:07:00 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:07:00 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:07:00 --> Model "M_bank" initialized
INFO - 2023-10-30 20:07:00 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:07:00 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-30 20:07:00 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front\v_booking_saya.php 218
INFO - 2023-10-30 20:07:00 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:07:00 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:07:00 --> Final output sent to browser
DEBUG - 2023-10-30 20:07:00 --> Total execution time: 0.1098
ERROR - 2023-10-30 20:07:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:07:13 --> Config Class Initialized
INFO - 2023-10-30 20:07:13 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:07:13 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:07:13 --> Utf8 Class Initialized
INFO - 2023-10-30 20:07:14 --> URI Class Initialized
DEBUG - 2023-10-30 20:07:14 --> No URI present. Default controller set.
INFO - 2023-10-30 20:07:14 --> Router Class Initialized
INFO - 2023-10-30 20:07:14 --> Output Class Initialized
INFO - 2023-10-30 20:07:14 --> Security Class Initialized
DEBUG - 2023-10-30 20:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:07:14 --> Input Class Initialized
INFO - 2023-10-30 20:07:14 --> Language Class Initialized
INFO - 2023-10-30 20:07:14 --> Loader Class Initialized
INFO - 2023-10-30 20:07:14 --> Helper loaded: url_helper
INFO - 2023-10-30 20:07:14 --> Helper loaded: form_helper
INFO - 2023-10-30 20:07:14 --> Helper loaded: file_helper
INFO - 2023-10-30 20:07:14 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:07:14 --> Form Validation Class Initialized
INFO - 2023-10-30 20:07:14 --> Upload Class Initialized
INFO - 2023-10-30 20:07:14 --> Model "M_auth" initialized
INFO - 2023-10-30 20:07:14 --> Model "M_user" initialized
INFO - 2023-10-30 20:07:14 --> Model "M_produk" initialized
INFO - 2023-10-30 20:07:14 --> Controller Class Initialized
INFO - 2023-10-30 20:07:14 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:07:14 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:07:14 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:07:14 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:07:14 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:07:14 --> Model "M_bank" initialized
INFO - 2023-10-30 20:07:14 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:07:14 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 20:07:14 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:07:14 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-30 20:07:14 --> Final output sent to browser
DEBUG - 2023-10-30 20:07:14 --> Total execution time: 0.0911
ERROR - 2023-10-30 20:07:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:07:18 --> Config Class Initialized
INFO - 2023-10-30 20:07:18 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:07:18 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:07:18 --> Utf8 Class Initialized
INFO - 2023-10-30 20:07:18 --> URI Class Initialized
INFO - 2023-10-30 20:07:18 --> Router Class Initialized
INFO - 2023-10-30 20:07:18 --> Output Class Initialized
INFO - 2023-10-30 20:07:18 --> Security Class Initialized
DEBUG - 2023-10-30 20:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:07:18 --> Input Class Initialized
INFO - 2023-10-30 20:07:18 --> Language Class Initialized
INFO - 2023-10-30 20:07:18 --> Loader Class Initialized
INFO - 2023-10-30 20:07:18 --> Helper loaded: url_helper
INFO - 2023-10-30 20:07:18 --> Helper loaded: form_helper
INFO - 2023-10-30 20:07:18 --> Helper loaded: file_helper
INFO - 2023-10-30 20:07:18 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:07:18 --> Form Validation Class Initialized
INFO - 2023-10-30 20:07:18 --> Upload Class Initialized
INFO - 2023-10-30 20:07:18 --> Model "M_auth" initialized
INFO - 2023-10-30 20:07:18 --> Model "M_user" initialized
INFO - 2023-10-30 20:07:18 --> Model "M_produk" initialized
INFO - 2023-10-30 20:07:18 --> Controller Class Initialized
INFO - 2023-10-30 20:07:18 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:07:18 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:07:18 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:07:18 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:07:18 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:07:18 --> Model "M_bank" initialized
INFO - 2023-10-30 20:07:18 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:07:18 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-30 20:07:18 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front\v_booking_saya.php 218
INFO - 2023-10-30 20:07:18 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:07:18 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:07:18 --> Final output sent to browser
DEBUG - 2023-10-30 20:07:18 --> Total execution time: 0.0785
ERROR - 2023-10-30 20:11:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:11:30 --> Config Class Initialized
INFO - 2023-10-30 20:11:30 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:11:30 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:11:30 --> Utf8 Class Initialized
INFO - 2023-10-30 20:11:30 --> URI Class Initialized
INFO - 2023-10-30 20:11:30 --> Router Class Initialized
INFO - 2023-10-30 20:11:30 --> Output Class Initialized
INFO - 2023-10-30 20:11:30 --> Security Class Initialized
DEBUG - 2023-10-30 20:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:11:30 --> Input Class Initialized
INFO - 2023-10-30 20:11:30 --> Language Class Initialized
INFO - 2023-10-30 20:11:30 --> Loader Class Initialized
INFO - 2023-10-30 20:11:30 --> Helper loaded: url_helper
INFO - 2023-10-30 20:11:30 --> Helper loaded: form_helper
INFO - 2023-10-30 20:11:30 --> Helper loaded: file_helper
INFO - 2023-10-30 20:11:30 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:11:30 --> Form Validation Class Initialized
INFO - 2023-10-30 20:11:30 --> Upload Class Initialized
INFO - 2023-10-30 20:11:30 --> Model "M_auth" initialized
INFO - 2023-10-30 20:11:30 --> Model "M_user" initialized
INFO - 2023-10-30 20:11:30 --> Model "M_produk" initialized
INFO - 2023-10-30 20:11:30 --> Controller Class Initialized
DEBUG - 2023-10-30 20:11:30 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 20:11:34 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\payment_form.php
INFO - 2023-10-30 20:11:34 --> Final output sent to browser
DEBUG - 2023-10-30 20:11:34 --> Total execution time: 4.7971
ERROR - 2023-10-30 20:11:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:11:41 --> Config Class Initialized
INFO - 2023-10-30 20:11:41 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:11:41 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:11:41 --> Utf8 Class Initialized
INFO - 2023-10-30 20:11:41 --> URI Class Initialized
DEBUG - 2023-10-30 20:11:41 --> No URI present. Default controller set.
INFO - 2023-10-30 20:11:41 --> Router Class Initialized
INFO - 2023-10-30 20:11:41 --> Output Class Initialized
INFO - 2023-10-30 20:11:41 --> Security Class Initialized
DEBUG - 2023-10-30 20:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:11:41 --> Input Class Initialized
INFO - 2023-10-30 20:11:41 --> Language Class Initialized
INFO - 2023-10-30 20:11:41 --> Loader Class Initialized
INFO - 2023-10-30 20:11:41 --> Helper loaded: url_helper
INFO - 2023-10-30 20:11:41 --> Helper loaded: form_helper
INFO - 2023-10-30 20:11:41 --> Helper loaded: file_helper
INFO - 2023-10-30 20:11:41 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:11:41 --> Form Validation Class Initialized
INFO - 2023-10-30 20:11:41 --> Upload Class Initialized
INFO - 2023-10-30 20:11:41 --> Model "M_auth" initialized
INFO - 2023-10-30 20:11:41 --> Model "M_user" initialized
INFO - 2023-10-30 20:11:41 --> Model "M_produk" initialized
INFO - 2023-10-30 20:11:41 --> Controller Class Initialized
INFO - 2023-10-30 20:11:41 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:11:41 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:11:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:11:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:11:41 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:11:41 --> Model "M_bank" initialized
INFO - 2023-10-30 20:11:41 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:11:41 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 20:11:41 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:11:41 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-30 20:11:41 --> Final output sent to browser
DEBUG - 2023-10-30 20:11:41 --> Total execution time: 0.0618
ERROR - 2023-10-30 20:11:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:11:43 --> Config Class Initialized
INFO - 2023-10-30 20:11:43 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:11:43 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:11:43 --> Utf8 Class Initialized
INFO - 2023-10-30 20:11:43 --> URI Class Initialized
INFO - 2023-10-30 20:11:43 --> Router Class Initialized
INFO - 2023-10-30 20:11:43 --> Output Class Initialized
INFO - 2023-10-30 20:11:43 --> Security Class Initialized
DEBUG - 2023-10-30 20:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:11:43 --> Input Class Initialized
INFO - 2023-10-30 20:11:43 --> Language Class Initialized
INFO - 2023-10-30 20:11:43 --> Loader Class Initialized
INFO - 2023-10-30 20:11:43 --> Helper loaded: url_helper
INFO - 2023-10-30 20:11:43 --> Helper loaded: form_helper
INFO - 2023-10-30 20:11:43 --> Helper loaded: file_helper
INFO - 2023-10-30 20:11:43 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:11:43 --> Form Validation Class Initialized
INFO - 2023-10-30 20:11:43 --> Upload Class Initialized
INFO - 2023-10-30 20:11:43 --> Model "M_auth" initialized
INFO - 2023-10-30 20:11:43 --> Model "M_user" initialized
INFO - 2023-10-30 20:11:43 --> Model "M_produk" initialized
INFO - 2023-10-30 20:11:43 --> Controller Class Initialized
INFO - 2023-10-30 20:11:43 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:11:43 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:11:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:11:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:11:43 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:11:43 --> Model "M_bank" initialized
INFO - 2023-10-30 20:11:43 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:11:43 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-30 20:11:43 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front\v_booking_saya.php 218
INFO - 2023-10-30 20:11:43 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:11:43 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:11:43 --> Final output sent to browser
DEBUG - 2023-10-30 20:11:43 --> Total execution time: 0.0374
ERROR - 2023-10-30 20:14:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:14:32 --> Config Class Initialized
INFO - 2023-10-30 20:14:32 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:14:32 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:14:32 --> Utf8 Class Initialized
INFO - 2023-10-30 20:14:32 --> URI Class Initialized
INFO - 2023-10-30 20:14:32 --> Router Class Initialized
INFO - 2023-10-30 20:14:32 --> Output Class Initialized
INFO - 2023-10-30 20:14:32 --> Security Class Initialized
DEBUG - 2023-10-30 20:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:14:32 --> Input Class Initialized
INFO - 2023-10-30 20:14:32 --> Language Class Initialized
INFO - 2023-10-30 20:14:32 --> Loader Class Initialized
INFO - 2023-10-30 20:14:32 --> Helper loaded: url_helper
INFO - 2023-10-30 20:14:32 --> Helper loaded: form_helper
INFO - 2023-10-30 20:14:32 --> Helper loaded: file_helper
INFO - 2023-10-30 20:14:32 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:14:32 --> Form Validation Class Initialized
INFO - 2023-10-30 20:14:32 --> Upload Class Initialized
INFO - 2023-10-30 20:14:32 --> Model "M_auth" initialized
INFO - 2023-10-30 20:14:32 --> Model "M_user" initialized
INFO - 2023-10-30 20:14:32 --> Model "M_produk" initialized
INFO - 2023-10-30 20:14:32 --> Controller Class Initialized
INFO - 2023-10-30 20:14:32 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:14:32 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:14:32 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:14:32 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:14:32 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:14:32 --> Model "M_bank" initialized
INFO - 2023-10-30 20:14:32 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:14:32 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 20:14:32 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:14:32 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:14:32 --> Final output sent to browser
DEBUG - 2023-10-30 20:14:32 --> Total execution time: 0.8956
ERROR - 2023-10-30 20:15:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:15:31 --> Config Class Initialized
INFO - 2023-10-30 20:15:31 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:15:31 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:15:31 --> Utf8 Class Initialized
INFO - 2023-10-30 20:15:31 --> URI Class Initialized
INFO - 2023-10-30 20:15:31 --> Router Class Initialized
INFO - 2023-10-30 20:15:31 --> Output Class Initialized
INFO - 2023-10-30 20:15:31 --> Security Class Initialized
DEBUG - 2023-10-30 20:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:15:31 --> Input Class Initialized
INFO - 2023-10-30 20:15:31 --> Language Class Initialized
INFO - 2023-10-30 20:15:31 --> Loader Class Initialized
INFO - 2023-10-30 20:15:31 --> Helper loaded: url_helper
INFO - 2023-10-30 20:15:31 --> Helper loaded: form_helper
INFO - 2023-10-30 20:15:31 --> Helper loaded: file_helper
INFO - 2023-10-30 20:15:31 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:15:31 --> Form Validation Class Initialized
INFO - 2023-10-30 20:15:31 --> Upload Class Initialized
INFO - 2023-10-30 20:15:31 --> Model "M_auth" initialized
INFO - 2023-10-30 20:15:31 --> Model "M_user" initialized
INFO - 2023-10-30 20:15:31 --> Model "M_produk" initialized
INFO - 2023-10-30 20:15:31 --> Controller Class Initialized
INFO - 2023-10-30 20:15:31 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:15:31 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:15:31 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:15:31 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:15:31 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:15:31 --> Model "M_bank" initialized
INFO - 2023-10-30 20:15:31 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:15:31 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 20:15:35 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:15:35 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:15:35 --> Final output sent to browser
DEBUG - 2023-10-30 20:15:35 --> Total execution time: 4.3909
ERROR - 2023-10-30 20:16:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:16:02 --> Config Class Initialized
INFO - 2023-10-30 20:16:02 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:16:02 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:16:02 --> Utf8 Class Initialized
INFO - 2023-10-30 20:16:02 --> URI Class Initialized
INFO - 2023-10-30 20:16:02 --> Router Class Initialized
INFO - 2023-10-30 20:16:02 --> Output Class Initialized
INFO - 2023-10-30 20:16:02 --> Security Class Initialized
DEBUG - 2023-10-30 20:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:16:02 --> Input Class Initialized
INFO - 2023-10-30 20:16:02 --> Language Class Initialized
INFO - 2023-10-30 20:16:02 --> Loader Class Initialized
INFO - 2023-10-30 20:16:02 --> Helper loaded: url_helper
INFO - 2023-10-30 20:16:02 --> Helper loaded: form_helper
INFO - 2023-10-30 20:16:02 --> Helper loaded: file_helper
INFO - 2023-10-30 20:16:02 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:16:02 --> Form Validation Class Initialized
INFO - 2023-10-30 20:16:02 --> Upload Class Initialized
INFO - 2023-10-30 20:16:02 --> Model "M_auth" initialized
INFO - 2023-10-30 20:16:02 --> Model "M_user" initialized
INFO - 2023-10-30 20:16:02 --> Model "M_produk" initialized
INFO - 2023-10-30 20:16:02 --> Controller Class Initialized
INFO - 2023-10-30 20:16:02 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:16:02 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:16:02 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:16:02 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:16:02 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:16:02 --> Model "M_bank" initialized
INFO - 2023-10-30 20:16:02 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:16:02 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 20:16:03 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:16:03 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:16:03 --> Final output sent to browser
DEBUG - 2023-10-30 20:16:03 --> Total execution time: 0.5288
ERROR - 2023-10-30 20:18:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:18:05 --> Config Class Initialized
INFO - 2023-10-30 20:18:05 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:18:05 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:18:05 --> Utf8 Class Initialized
INFO - 2023-10-30 20:18:05 --> URI Class Initialized
INFO - 2023-10-30 20:18:05 --> Router Class Initialized
INFO - 2023-10-30 20:18:05 --> Output Class Initialized
INFO - 2023-10-30 20:18:05 --> Security Class Initialized
DEBUG - 2023-10-30 20:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:18:05 --> Input Class Initialized
INFO - 2023-10-30 20:18:05 --> Language Class Initialized
INFO - 2023-10-30 20:18:05 --> Loader Class Initialized
INFO - 2023-10-30 20:18:05 --> Helper loaded: url_helper
INFO - 2023-10-30 20:18:05 --> Helper loaded: form_helper
INFO - 2023-10-30 20:18:05 --> Helper loaded: file_helper
INFO - 2023-10-30 20:18:05 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:18:05 --> Form Validation Class Initialized
INFO - 2023-10-30 20:18:05 --> Upload Class Initialized
INFO - 2023-10-30 20:18:05 --> Model "M_auth" initialized
INFO - 2023-10-30 20:18:05 --> Model "M_user" initialized
INFO - 2023-10-30 20:18:05 --> Model "M_produk" initialized
INFO - 2023-10-30 20:18:05 --> Controller Class Initialized
INFO - 2023-10-30 20:18:05 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:18:05 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:18:05 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:18:05 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:18:05 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:18:05 --> Model "M_bank" initialized
INFO - 2023-10-30 20:18:05 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:18:05 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-30 20:18:10 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front\v_booking_saya.php 8
ERROR - 2023-10-30 20:18:10 --> Severity: Warning --> Undefined variable $transaksi C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front\v_booking_saya.php 186
ERROR - 2023-10-30 20:18:10 --> Severity: Warning --> Undefined variable $transaksi_pending C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front\v_booking_saya.php 265
ERROR - 2023-10-30 20:18:10 --> Severity: Warning --> Undefined variable $transaksi_lunas C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front\v_booking_saya.php 318
ERROR - 2023-10-30 20:18:10 --> Severity: Warning --> Undefined variable $transaksi_sewaselesai C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front\v_booking_saya.php 372
INFO - 2023-10-30 20:18:10 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:18:10 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:18:10 --> Final output sent to browser
DEBUG - 2023-10-30 20:18:10 --> Total execution time: 4.5842
ERROR - 2023-10-30 20:18:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:18:22 --> Config Class Initialized
INFO - 2023-10-30 20:18:22 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:18:22 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:18:22 --> Utf8 Class Initialized
INFO - 2023-10-30 20:18:22 --> URI Class Initialized
INFO - 2023-10-30 20:18:22 --> Router Class Initialized
INFO - 2023-10-30 20:18:22 --> Output Class Initialized
INFO - 2023-10-30 20:18:22 --> Security Class Initialized
DEBUG - 2023-10-30 20:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:18:22 --> Input Class Initialized
INFO - 2023-10-30 20:18:22 --> Language Class Initialized
INFO - 2023-10-30 20:18:22 --> Loader Class Initialized
INFO - 2023-10-30 20:18:22 --> Helper loaded: url_helper
INFO - 2023-10-30 20:18:22 --> Helper loaded: form_helper
INFO - 2023-10-30 20:18:22 --> Helper loaded: file_helper
INFO - 2023-10-30 20:18:22 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:18:22 --> Form Validation Class Initialized
INFO - 2023-10-30 20:18:22 --> Upload Class Initialized
INFO - 2023-10-30 20:18:22 --> Model "M_auth" initialized
INFO - 2023-10-30 20:18:22 --> Model "M_user" initialized
INFO - 2023-10-30 20:18:22 --> Model "M_produk" initialized
INFO - 2023-10-30 20:18:22 --> Controller Class Initialized
INFO - 2023-10-30 20:18:22 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:18:22 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:18:22 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:18:22 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:18:22 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:18:22 --> Model "M_bank" initialized
INFO - 2023-10-30 20:18:22 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:18:22 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-30 20:18:22 --> Severity: Warning --> Undefined variable $params C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Home.php 358
INFO - 2023-10-30 20:18:22 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:18:22 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:18:22 --> Final output sent to browser
DEBUG - 2023-10-30 20:18:22 --> Total execution time: 0.0387
ERROR - 2023-10-30 20:18:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:18:42 --> Config Class Initialized
INFO - 2023-10-30 20:18:42 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:18:42 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:18:42 --> Utf8 Class Initialized
INFO - 2023-10-30 20:18:42 --> URI Class Initialized
INFO - 2023-10-30 20:18:42 --> Router Class Initialized
INFO - 2023-10-30 20:18:42 --> Output Class Initialized
INFO - 2023-10-30 20:18:42 --> Security Class Initialized
DEBUG - 2023-10-30 20:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:18:42 --> Input Class Initialized
INFO - 2023-10-30 20:18:42 --> Language Class Initialized
INFO - 2023-10-30 20:18:42 --> Loader Class Initialized
INFO - 2023-10-30 20:18:42 --> Helper loaded: url_helper
INFO - 2023-10-30 20:18:42 --> Helper loaded: form_helper
INFO - 2023-10-30 20:18:42 --> Helper loaded: file_helper
INFO - 2023-10-30 20:18:42 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:18:42 --> Form Validation Class Initialized
INFO - 2023-10-30 20:18:42 --> Upload Class Initialized
INFO - 2023-10-30 20:18:42 --> Model "M_auth" initialized
INFO - 2023-10-30 20:18:42 --> Model "M_user" initialized
INFO - 2023-10-30 20:18:42 --> Model "M_produk" initialized
INFO - 2023-10-30 20:18:42 --> Controller Class Initialized
INFO - 2023-10-30 20:18:42 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:18:42 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:18:42 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:18:42 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:18:42 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:18:42 --> Model "M_bank" initialized
INFO - 2023-10-30 20:18:42 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:18:42 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 20:18:46 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:18:46 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:18:46 --> Final output sent to browser
DEBUG - 2023-10-30 20:18:46 --> Total execution time: 4.5286
ERROR - 2023-10-30 20:18:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:18:54 --> Config Class Initialized
INFO - 2023-10-30 20:18:54 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:18:54 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:18:54 --> Utf8 Class Initialized
INFO - 2023-10-30 20:18:54 --> URI Class Initialized
INFO - 2023-10-30 20:18:54 --> Router Class Initialized
INFO - 2023-10-30 20:18:54 --> Output Class Initialized
INFO - 2023-10-30 20:18:54 --> Security Class Initialized
DEBUG - 2023-10-30 20:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:18:54 --> Input Class Initialized
INFO - 2023-10-30 20:18:54 --> Language Class Initialized
INFO - 2023-10-30 20:18:54 --> Loader Class Initialized
INFO - 2023-10-30 20:18:54 --> Helper loaded: url_helper
INFO - 2023-10-30 20:18:54 --> Helper loaded: form_helper
INFO - 2023-10-30 20:18:54 --> Helper loaded: file_helper
INFO - 2023-10-30 20:18:54 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:18:54 --> Form Validation Class Initialized
INFO - 2023-10-30 20:18:54 --> Upload Class Initialized
INFO - 2023-10-30 20:18:54 --> Model "M_auth" initialized
INFO - 2023-10-30 20:18:54 --> Model "M_user" initialized
INFO - 2023-10-30 20:18:54 --> Model "M_produk" initialized
INFO - 2023-10-30 20:18:54 --> Controller Class Initialized
INFO - 2023-10-30 20:18:54 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:18:54 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:18:54 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:18:54 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:18:54 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:18:54 --> Model "M_bank" initialized
INFO - 2023-10-30 20:18:54 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:18:54 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 20:18:54 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:18:54 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:18:54 --> Final output sent to browser
DEBUG - 2023-10-30 20:18:54 --> Total execution time: 0.5568
ERROR - 2023-10-30 20:19:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:19:39 --> Config Class Initialized
INFO - 2023-10-30 20:19:39 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:19:39 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:19:39 --> Utf8 Class Initialized
INFO - 2023-10-30 20:19:39 --> URI Class Initialized
INFO - 2023-10-30 20:19:39 --> Router Class Initialized
INFO - 2023-10-30 20:19:39 --> Output Class Initialized
INFO - 2023-10-30 20:19:39 --> Security Class Initialized
DEBUG - 2023-10-30 20:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:19:39 --> Input Class Initialized
INFO - 2023-10-30 20:19:39 --> Language Class Initialized
INFO - 2023-10-30 20:19:39 --> Loader Class Initialized
INFO - 2023-10-30 20:19:39 --> Helper loaded: url_helper
INFO - 2023-10-30 20:19:39 --> Helper loaded: form_helper
INFO - 2023-10-30 20:19:39 --> Helper loaded: file_helper
INFO - 2023-10-30 20:19:39 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:19:39 --> Form Validation Class Initialized
INFO - 2023-10-30 20:19:39 --> Upload Class Initialized
INFO - 2023-10-30 20:19:39 --> Model "M_auth" initialized
INFO - 2023-10-30 20:19:39 --> Model "M_user" initialized
INFO - 2023-10-30 20:19:39 --> Model "M_produk" initialized
INFO - 2023-10-30 20:19:39 --> Controller Class Initialized
INFO - 2023-10-30 20:19:39 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:19:39 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:19:39 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:19:39 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:19:40 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:19:40 --> Model "M_bank" initialized
INFO - 2023-10-30 20:19:40 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:19:40 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 20:19:44 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:19:44 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:19:44 --> Final output sent to browser
DEBUG - 2023-10-30 20:19:44 --> Total execution time: 4.3551
ERROR - 2023-10-30 20:19:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:19:56 --> Config Class Initialized
INFO - 2023-10-30 20:19:56 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:19:56 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:19:56 --> Utf8 Class Initialized
INFO - 2023-10-30 20:19:56 --> URI Class Initialized
INFO - 2023-10-30 20:19:56 --> Router Class Initialized
INFO - 2023-10-30 20:19:56 --> Output Class Initialized
INFO - 2023-10-30 20:19:56 --> Security Class Initialized
DEBUG - 2023-10-30 20:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:19:56 --> Input Class Initialized
INFO - 2023-10-30 20:19:56 --> Language Class Initialized
INFO - 2023-10-30 20:19:56 --> Loader Class Initialized
INFO - 2023-10-30 20:19:56 --> Helper loaded: url_helper
INFO - 2023-10-30 20:19:56 --> Helper loaded: form_helper
INFO - 2023-10-30 20:19:56 --> Helper loaded: file_helper
INFO - 2023-10-30 20:19:56 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:19:56 --> Form Validation Class Initialized
INFO - 2023-10-30 20:19:56 --> Upload Class Initialized
INFO - 2023-10-30 20:19:56 --> Model "M_auth" initialized
INFO - 2023-10-30 20:19:56 --> Model "M_user" initialized
INFO - 2023-10-30 20:19:56 --> Model "M_produk" initialized
INFO - 2023-10-30 20:19:56 --> Controller Class Initialized
INFO - 2023-10-30 20:19:56 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:19:56 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:19:56 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:19:56 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:19:56 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:19:56 --> Model "M_bank" initialized
INFO - 2023-10-30 20:19:56 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:19:56 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 20:19:57 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:19:57 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:19:57 --> Final output sent to browser
DEBUG - 2023-10-30 20:19:57 --> Total execution time: 0.8427
ERROR - 2023-10-30 20:20:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:20:10 --> Config Class Initialized
INFO - 2023-10-30 20:20:10 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:20:10 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:20:10 --> Utf8 Class Initialized
INFO - 2023-10-30 20:20:10 --> URI Class Initialized
INFO - 2023-10-30 20:20:10 --> Router Class Initialized
INFO - 2023-10-30 20:20:10 --> Output Class Initialized
INFO - 2023-10-30 20:20:10 --> Security Class Initialized
DEBUG - 2023-10-30 20:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:20:10 --> Input Class Initialized
INFO - 2023-10-30 20:20:10 --> Language Class Initialized
INFO - 2023-10-30 20:20:10 --> Loader Class Initialized
INFO - 2023-10-30 20:20:10 --> Helper loaded: url_helper
INFO - 2023-10-30 20:20:10 --> Helper loaded: form_helper
INFO - 2023-10-30 20:20:10 --> Helper loaded: file_helper
INFO - 2023-10-30 20:20:10 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:20:10 --> Form Validation Class Initialized
INFO - 2023-10-30 20:20:10 --> Upload Class Initialized
INFO - 2023-10-30 20:20:10 --> Model "M_auth" initialized
INFO - 2023-10-30 20:20:10 --> Model "M_user" initialized
INFO - 2023-10-30 20:20:10 --> Model "M_produk" initialized
INFO - 2023-10-30 20:20:10 --> Controller Class Initialized
INFO - 2023-10-30 20:20:10 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:20:10 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:20:10 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:20:10 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:20:10 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:20:10 --> Model "M_bank" initialized
INFO - 2023-10-30 20:20:10 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:20:10 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 20:20:11 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:20:11 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:20:11 --> Final output sent to browser
DEBUG - 2023-10-30 20:20:11 --> Total execution time: 1.1859
ERROR - 2023-10-30 20:20:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:20:58 --> Config Class Initialized
INFO - 2023-10-30 20:20:58 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:20:58 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:20:58 --> Utf8 Class Initialized
INFO - 2023-10-30 20:20:58 --> URI Class Initialized
INFO - 2023-10-30 20:20:58 --> Router Class Initialized
INFO - 2023-10-30 20:20:58 --> Output Class Initialized
INFO - 2023-10-30 20:20:58 --> Security Class Initialized
DEBUG - 2023-10-30 20:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:20:58 --> Input Class Initialized
INFO - 2023-10-30 20:20:58 --> Language Class Initialized
INFO - 2023-10-30 20:20:58 --> Loader Class Initialized
INFO - 2023-10-30 20:20:58 --> Helper loaded: url_helper
INFO - 2023-10-30 20:20:58 --> Helper loaded: form_helper
INFO - 2023-10-30 20:20:58 --> Helper loaded: file_helper
INFO - 2023-10-30 20:20:58 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:20:58 --> Form Validation Class Initialized
INFO - 2023-10-30 20:20:58 --> Upload Class Initialized
INFO - 2023-10-30 20:20:58 --> Model "M_auth" initialized
INFO - 2023-10-30 20:20:58 --> Model "M_user" initialized
INFO - 2023-10-30 20:20:58 --> Model "M_produk" initialized
INFO - 2023-10-30 20:20:58 --> Controller Class Initialized
INFO - 2023-10-30 20:20:58 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:20:58 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:20:58 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:20:58 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:20:58 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:20:58 --> Model "M_bank" initialized
INFO - 2023-10-30 20:20:58 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:20:58 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-30 20:20:58 --> Severity: Warning --> Undefined variable $sub_total C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Home.php 357
INFO - 2023-10-30 20:20:59 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:20:59 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:20:59 --> Final output sent to browser
DEBUG - 2023-10-30 20:20:59 --> Total execution time: 1.1542
ERROR - 2023-10-30 20:21:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:21:10 --> Config Class Initialized
INFO - 2023-10-30 20:21:10 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:21:10 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:21:10 --> Utf8 Class Initialized
INFO - 2023-10-30 20:21:10 --> URI Class Initialized
INFO - 2023-10-30 20:21:10 --> Router Class Initialized
INFO - 2023-10-30 20:21:10 --> Output Class Initialized
INFO - 2023-10-30 20:21:10 --> Security Class Initialized
DEBUG - 2023-10-30 20:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:21:10 --> Input Class Initialized
INFO - 2023-10-30 20:21:10 --> Language Class Initialized
INFO - 2023-10-30 20:21:10 --> Loader Class Initialized
INFO - 2023-10-30 20:21:10 --> Helper loaded: url_helper
INFO - 2023-10-30 20:21:10 --> Helper loaded: form_helper
INFO - 2023-10-30 20:21:10 --> Helper loaded: file_helper
INFO - 2023-10-30 20:21:10 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:21:10 --> Form Validation Class Initialized
INFO - 2023-10-30 20:21:10 --> Upload Class Initialized
INFO - 2023-10-30 20:21:10 --> Model "M_auth" initialized
INFO - 2023-10-30 20:21:10 --> Model "M_user" initialized
INFO - 2023-10-30 20:21:10 --> Model "M_produk" initialized
INFO - 2023-10-30 20:21:10 --> Controller Class Initialized
INFO - 2023-10-30 20:21:10 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:21:10 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:21:10 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:21:10 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:21:10 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:21:10 --> Model "M_bank" initialized
INFO - 2023-10-30 20:21:10 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:21:10 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 20:21:11 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:21:11 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:21:11 --> Final output sent to browser
DEBUG - 2023-10-30 20:21:11 --> Total execution time: 1.1372
ERROR - 2023-10-30 20:21:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:21:18 --> Config Class Initialized
INFO - 2023-10-30 20:21:18 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:21:18 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:21:18 --> Utf8 Class Initialized
INFO - 2023-10-30 20:21:18 --> URI Class Initialized
INFO - 2023-10-30 20:21:18 --> Router Class Initialized
INFO - 2023-10-30 20:21:18 --> Output Class Initialized
INFO - 2023-10-30 20:21:18 --> Security Class Initialized
DEBUG - 2023-10-30 20:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:21:18 --> Input Class Initialized
INFO - 2023-10-30 20:21:18 --> Language Class Initialized
INFO - 2023-10-30 20:21:18 --> Loader Class Initialized
INFO - 2023-10-30 20:21:18 --> Helper loaded: url_helper
INFO - 2023-10-30 20:21:18 --> Helper loaded: form_helper
INFO - 2023-10-30 20:21:18 --> Helper loaded: file_helper
INFO - 2023-10-30 20:21:18 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:21:18 --> Form Validation Class Initialized
INFO - 2023-10-30 20:21:18 --> Upload Class Initialized
INFO - 2023-10-30 20:21:18 --> Model "M_auth" initialized
INFO - 2023-10-30 20:21:18 --> Model "M_user" initialized
INFO - 2023-10-30 20:21:18 --> Model "M_produk" initialized
INFO - 2023-10-30 20:21:18 --> Controller Class Initialized
INFO - 2023-10-30 20:21:18 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:21:18 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:21:18 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:21:18 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:21:18 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:21:18 --> Model "M_bank" initialized
INFO - 2023-10-30 20:21:18 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:21:18 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 20:21:19 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:21:19 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:21:19 --> Final output sent to browser
DEBUG - 2023-10-30 20:21:19 --> Total execution time: 0.5650
ERROR - 2023-10-30 20:23:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:23:14 --> Config Class Initialized
INFO - 2023-10-30 20:23:14 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:23:14 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:23:14 --> Utf8 Class Initialized
INFO - 2023-10-30 20:23:14 --> URI Class Initialized
INFO - 2023-10-30 20:23:14 --> Router Class Initialized
INFO - 2023-10-30 20:23:14 --> Output Class Initialized
INFO - 2023-10-30 20:23:14 --> Security Class Initialized
DEBUG - 2023-10-30 20:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:23:14 --> Input Class Initialized
INFO - 2023-10-30 20:23:14 --> Language Class Initialized
INFO - 2023-10-30 20:23:14 --> Loader Class Initialized
INFO - 2023-10-30 20:23:14 --> Helper loaded: url_helper
INFO - 2023-10-30 20:23:14 --> Helper loaded: form_helper
INFO - 2023-10-30 20:23:14 --> Helper loaded: file_helper
INFO - 2023-10-30 20:23:14 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:23:14 --> Form Validation Class Initialized
INFO - 2023-10-30 20:23:14 --> Upload Class Initialized
INFO - 2023-10-30 20:23:14 --> Model "M_auth" initialized
INFO - 2023-10-30 20:23:14 --> Model "M_user" initialized
INFO - 2023-10-30 20:23:14 --> Model "M_produk" initialized
INFO - 2023-10-30 20:23:14 --> Controller Class Initialized
INFO - 2023-10-30 20:23:14 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:23:14 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:23:14 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:23:14 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:23:14 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:23:14 --> Model "M_bank" initialized
INFO - 2023-10-30 20:23:14 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:23:14 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 20:23:14 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:23:14 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:23:14 --> Final output sent to browser
DEBUG - 2023-10-30 20:23:14 --> Total execution time: 0.1235
ERROR - 2023-10-30 20:23:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:23:26 --> Config Class Initialized
INFO - 2023-10-30 20:23:26 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:23:26 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:23:26 --> Utf8 Class Initialized
INFO - 2023-10-30 20:23:26 --> URI Class Initialized
INFO - 2023-10-30 20:23:26 --> Router Class Initialized
INFO - 2023-10-30 20:23:26 --> Output Class Initialized
INFO - 2023-10-30 20:23:26 --> Security Class Initialized
DEBUG - 2023-10-30 20:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:23:26 --> Input Class Initialized
INFO - 2023-10-30 20:23:26 --> Language Class Initialized
INFO - 2023-10-30 20:23:26 --> Loader Class Initialized
INFO - 2023-10-30 20:23:26 --> Helper loaded: url_helper
INFO - 2023-10-30 20:23:26 --> Helper loaded: form_helper
INFO - 2023-10-30 20:23:26 --> Helper loaded: file_helper
INFO - 2023-10-30 20:23:26 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:23:26 --> Form Validation Class Initialized
INFO - 2023-10-30 20:23:26 --> Upload Class Initialized
INFO - 2023-10-30 20:23:26 --> Model "M_auth" initialized
INFO - 2023-10-30 20:23:26 --> Model "M_user" initialized
INFO - 2023-10-30 20:23:26 --> Model "M_produk" initialized
INFO - 2023-10-30 20:23:26 --> Controller Class Initialized
INFO - 2023-10-30 20:23:26 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:23:26 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:23:26 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:23:26 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:23:26 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:23:26 --> Model "M_bank" initialized
INFO - 2023-10-30 20:23:26 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:23:26 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 20:23:26 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:23:26 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:23:26 --> Final output sent to browser
DEBUG - 2023-10-30 20:23:26 --> Total execution time: 0.1183
ERROR - 2023-10-30 20:23:35 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:23:35 --> Config Class Initialized
INFO - 2023-10-30 20:23:35 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:23:35 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:23:35 --> Utf8 Class Initialized
INFO - 2023-10-30 20:23:35 --> URI Class Initialized
INFO - 2023-10-30 20:23:35 --> Router Class Initialized
INFO - 2023-10-30 20:23:35 --> Output Class Initialized
INFO - 2023-10-30 20:23:35 --> Security Class Initialized
DEBUG - 2023-10-30 20:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:23:35 --> Input Class Initialized
INFO - 2023-10-30 20:23:35 --> Language Class Initialized
INFO - 2023-10-30 20:23:35 --> Loader Class Initialized
INFO - 2023-10-30 20:23:35 --> Helper loaded: url_helper
INFO - 2023-10-30 20:23:35 --> Helper loaded: form_helper
INFO - 2023-10-30 20:23:35 --> Helper loaded: file_helper
INFO - 2023-10-30 20:23:35 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:23:35 --> Form Validation Class Initialized
INFO - 2023-10-30 20:23:35 --> Upload Class Initialized
INFO - 2023-10-30 20:23:35 --> Model "M_auth" initialized
INFO - 2023-10-30 20:23:35 --> Model "M_user" initialized
INFO - 2023-10-30 20:23:35 --> Model "M_produk" initialized
INFO - 2023-10-30 20:23:35 --> Controller Class Initialized
INFO - 2023-10-30 20:23:35 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:23:35 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:23:35 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:23:35 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:23:35 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:23:35 --> Model "M_bank" initialized
INFO - 2023-10-30 20:23:35 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:23:35 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 20:23:36 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:23:36 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:23:36 --> Final output sent to browser
DEBUG - 2023-10-30 20:23:36 --> Total execution time: 0.6398
ERROR - 2023-10-30 20:35:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:35:40 --> Config Class Initialized
INFO - 2023-10-30 20:35:40 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:35:40 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:35:40 --> Utf8 Class Initialized
INFO - 2023-10-30 20:35:40 --> URI Class Initialized
INFO - 2023-10-30 20:35:40 --> Router Class Initialized
INFO - 2023-10-30 20:35:40 --> Output Class Initialized
INFO - 2023-10-30 20:35:40 --> Security Class Initialized
DEBUG - 2023-10-30 20:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:35:40 --> Input Class Initialized
INFO - 2023-10-30 20:35:40 --> Language Class Initialized
INFO - 2023-10-30 20:35:40 --> Loader Class Initialized
INFO - 2023-10-30 20:35:40 --> Helper loaded: url_helper
INFO - 2023-10-30 20:35:40 --> Helper loaded: form_helper
INFO - 2023-10-30 20:35:40 --> Helper loaded: file_helper
INFO - 2023-10-30 20:35:40 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:35:40 --> Form Validation Class Initialized
INFO - 2023-10-30 20:35:40 --> Upload Class Initialized
INFO - 2023-10-30 20:35:40 --> Model "M_auth" initialized
INFO - 2023-10-30 20:35:40 --> Model "M_user" initialized
INFO - 2023-10-30 20:35:40 --> Model "M_produk" initialized
INFO - 2023-10-30 20:35:40 --> Controller Class Initialized
INFO - 2023-10-30 20:35:40 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:35:40 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:35:40 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:35:40 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:35:40 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:35:40 --> Model "M_bank" initialized
INFO - 2023-10-30 20:35:40 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:35:40 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 20:35:42 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:35:42 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:35:42 --> Final output sent to browser
DEBUG - 2023-10-30 20:35:42 --> Total execution time: 1.3874
ERROR - 2023-10-30 20:35:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:35:49 --> Config Class Initialized
INFO - 2023-10-30 20:35:49 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:35:49 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:35:49 --> Utf8 Class Initialized
INFO - 2023-10-30 20:35:49 --> URI Class Initialized
INFO - 2023-10-30 20:35:49 --> Router Class Initialized
INFO - 2023-10-30 20:35:49 --> Output Class Initialized
INFO - 2023-10-30 20:35:49 --> Security Class Initialized
DEBUG - 2023-10-30 20:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:35:49 --> Input Class Initialized
INFO - 2023-10-30 20:35:49 --> Language Class Initialized
INFO - 2023-10-30 20:35:49 --> Loader Class Initialized
INFO - 2023-10-30 20:35:49 --> Helper loaded: url_helper
INFO - 2023-10-30 20:35:49 --> Helper loaded: form_helper
INFO - 2023-10-30 20:35:49 --> Helper loaded: file_helper
INFO - 2023-10-30 20:35:49 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:35:49 --> Form Validation Class Initialized
INFO - 2023-10-30 20:35:49 --> Upload Class Initialized
INFO - 2023-10-30 20:35:49 --> Model "M_auth" initialized
INFO - 2023-10-30 20:35:49 --> Model "M_user" initialized
INFO - 2023-10-30 20:35:49 --> Model "M_produk" initialized
INFO - 2023-10-30 20:35:49 --> Controller Class Initialized
INFO - 2023-10-30 20:35:49 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:35:49 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:35:49 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:35:49 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:35:49 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:35:49 --> Model "M_bank" initialized
INFO - 2023-10-30 20:35:49 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:35:49 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 20:35:54 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:35:54 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:35:54 --> Final output sent to browser
DEBUG - 2023-10-30 20:35:54 --> Total execution time: 5.3896
ERROR - 2023-10-30 20:36:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:36:22 --> Config Class Initialized
INFO - 2023-10-30 20:36:22 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:36:22 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:36:22 --> Utf8 Class Initialized
INFO - 2023-10-30 20:36:22 --> URI Class Initialized
INFO - 2023-10-30 20:36:22 --> Router Class Initialized
INFO - 2023-10-30 20:36:22 --> Output Class Initialized
INFO - 2023-10-30 20:36:22 --> Security Class Initialized
DEBUG - 2023-10-30 20:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:36:22 --> Input Class Initialized
INFO - 2023-10-30 20:36:22 --> Language Class Initialized
INFO - 2023-10-30 20:36:22 --> Loader Class Initialized
INFO - 2023-10-30 20:36:22 --> Helper loaded: url_helper
INFO - 2023-10-30 20:36:22 --> Helper loaded: form_helper
INFO - 2023-10-30 20:36:22 --> Helper loaded: file_helper
INFO - 2023-10-30 20:36:22 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:36:22 --> Form Validation Class Initialized
INFO - 2023-10-30 20:36:22 --> Upload Class Initialized
INFO - 2023-10-30 20:36:22 --> Model "M_auth" initialized
INFO - 2023-10-30 20:36:22 --> Model "M_user" initialized
INFO - 2023-10-30 20:36:22 --> Model "M_produk" initialized
INFO - 2023-10-30 20:36:22 --> Controller Class Initialized
INFO - 2023-10-30 20:36:22 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:36:22 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:36:22 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:36:22 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:36:22 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:36:22 --> Model "M_bank" initialized
INFO - 2023-10-30 20:36:22 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:36:22 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 20:36:23 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:36:23 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:36:23 --> Final output sent to browser
DEBUG - 2023-10-30 20:36:23 --> Total execution time: 1.4221
ERROR - 2023-10-30 20:36:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:36:42 --> Config Class Initialized
INFO - 2023-10-30 20:36:42 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:36:42 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:36:42 --> Utf8 Class Initialized
INFO - 2023-10-30 20:36:42 --> URI Class Initialized
INFO - 2023-10-30 20:36:42 --> Router Class Initialized
INFO - 2023-10-30 20:36:42 --> Output Class Initialized
INFO - 2023-10-30 20:36:42 --> Security Class Initialized
DEBUG - 2023-10-30 20:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:36:42 --> Input Class Initialized
INFO - 2023-10-30 20:36:42 --> Language Class Initialized
INFO - 2023-10-30 20:36:42 --> Loader Class Initialized
INFO - 2023-10-30 20:36:42 --> Helper loaded: url_helper
INFO - 2023-10-30 20:36:42 --> Helper loaded: form_helper
INFO - 2023-10-30 20:36:42 --> Helper loaded: file_helper
INFO - 2023-10-30 20:36:42 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:36:42 --> Form Validation Class Initialized
INFO - 2023-10-30 20:36:42 --> Upload Class Initialized
INFO - 2023-10-30 20:36:42 --> Model "M_auth" initialized
INFO - 2023-10-30 20:36:42 --> Model "M_user" initialized
INFO - 2023-10-30 20:36:42 --> Model "M_produk" initialized
INFO - 2023-10-30 20:36:42 --> Controller Class Initialized
INFO - 2023-10-30 20:36:42 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:36:42 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:36:42 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:36:42 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:36:42 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:36:42 --> Model "M_bank" initialized
INFO - 2023-10-30 20:36:42 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:36:42 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-30 20:36:42 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front\v_booking_saya.php 218
INFO - 2023-10-30 20:36:42 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:36:42 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:36:42 --> Final output sent to browser
DEBUG - 2023-10-30 20:36:42 --> Total execution time: 0.1203
ERROR - 2023-10-30 20:39:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:39:23 --> Config Class Initialized
INFO - 2023-10-30 20:39:23 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:39:23 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:39:23 --> Utf8 Class Initialized
INFO - 2023-10-30 20:39:23 --> URI Class Initialized
INFO - 2023-10-30 20:39:23 --> Router Class Initialized
INFO - 2023-10-30 20:39:23 --> Output Class Initialized
INFO - 2023-10-30 20:39:23 --> Security Class Initialized
DEBUG - 2023-10-30 20:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:39:23 --> Input Class Initialized
INFO - 2023-10-30 20:39:23 --> Language Class Initialized
INFO - 2023-10-30 20:39:23 --> Loader Class Initialized
INFO - 2023-10-30 20:39:23 --> Helper loaded: url_helper
INFO - 2023-10-30 20:39:23 --> Helper loaded: form_helper
INFO - 2023-10-30 20:39:23 --> Helper loaded: file_helper
INFO - 2023-10-30 20:39:23 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:39:23 --> Form Validation Class Initialized
INFO - 2023-10-30 20:39:23 --> Upload Class Initialized
INFO - 2023-10-30 20:39:23 --> Model "M_auth" initialized
INFO - 2023-10-30 20:39:23 --> Model "M_user" initialized
INFO - 2023-10-30 20:39:23 --> Model "M_produk" initialized
INFO - 2023-10-30 20:39:23 --> Controller Class Initialized
INFO - 2023-10-30 20:39:23 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:39:23 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:39:23 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:39:23 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:39:23 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:39:23 --> Model "M_bank" initialized
INFO - 2023-10-30 20:39:23 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:39:23 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-30 20:39:23 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front\v_booking_saya.php 218
INFO - 2023-10-30 20:39:23 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:39:23 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:39:23 --> Final output sent to browser
DEBUG - 2023-10-30 20:39:23 --> Total execution time: 0.0597
ERROR - 2023-10-30 20:39:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:39:31 --> Config Class Initialized
INFO - 2023-10-30 20:39:31 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:39:31 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:39:31 --> Utf8 Class Initialized
INFO - 2023-10-30 20:39:31 --> URI Class Initialized
INFO - 2023-10-30 20:39:31 --> Router Class Initialized
INFO - 2023-10-30 20:39:31 --> Output Class Initialized
INFO - 2023-10-30 20:39:31 --> Security Class Initialized
DEBUG - 2023-10-30 20:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:39:31 --> Input Class Initialized
INFO - 2023-10-30 20:39:31 --> Language Class Initialized
INFO - 2023-10-30 20:39:31 --> Loader Class Initialized
INFO - 2023-10-30 20:39:31 --> Helper loaded: url_helper
INFO - 2023-10-30 20:39:31 --> Helper loaded: form_helper
INFO - 2023-10-30 20:39:31 --> Helper loaded: file_helper
INFO - 2023-10-30 20:39:31 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:39:31 --> Form Validation Class Initialized
INFO - 2023-10-30 20:39:31 --> Upload Class Initialized
INFO - 2023-10-30 20:39:31 --> Model "M_auth" initialized
INFO - 2023-10-30 20:39:31 --> Model "M_user" initialized
INFO - 2023-10-30 20:39:31 --> Model "M_produk" initialized
INFO - 2023-10-30 20:39:31 --> Controller Class Initialized
INFO - 2023-10-30 20:39:31 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:39:31 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:39:31 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:39:31 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:39:31 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:39:31 --> Model "M_bank" initialized
INFO - 2023-10-30 20:39:31 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:39:31 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-30 20:39:31 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front\v_booking_saya.php 218
INFO - 2023-10-30 20:39:31 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:39:31 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:39:31 --> Final output sent to browser
DEBUG - 2023-10-30 20:39:31 --> Total execution time: 0.1498
ERROR - 2023-10-30 20:40:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:40:34 --> Config Class Initialized
INFO - 2023-10-30 20:40:34 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:40:34 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:40:34 --> Utf8 Class Initialized
INFO - 2023-10-30 20:40:34 --> URI Class Initialized
INFO - 2023-10-30 20:40:34 --> Router Class Initialized
INFO - 2023-10-30 20:40:34 --> Output Class Initialized
INFO - 2023-10-30 20:40:34 --> Security Class Initialized
DEBUG - 2023-10-30 20:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:40:34 --> Input Class Initialized
INFO - 2023-10-30 20:40:34 --> Language Class Initialized
INFO - 2023-10-30 20:40:34 --> Loader Class Initialized
INFO - 2023-10-30 20:40:34 --> Helper loaded: url_helper
INFO - 2023-10-30 20:40:34 --> Helper loaded: form_helper
INFO - 2023-10-30 20:40:34 --> Helper loaded: file_helper
INFO - 2023-10-30 20:40:34 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:40:34 --> Form Validation Class Initialized
INFO - 2023-10-30 20:40:34 --> Upload Class Initialized
INFO - 2023-10-30 20:40:34 --> Model "M_auth" initialized
INFO - 2023-10-30 20:40:34 --> Model "M_user" initialized
INFO - 2023-10-30 20:40:34 --> Model "M_produk" initialized
INFO - 2023-10-30 20:40:34 --> Controller Class Initialized
INFO - 2023-10-30 20:40:34 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:40:34 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:40:34 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:40:34 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:40:34 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:40:34 --> Model "M_bank" initialized
INFO - 2023-10-30 20:40:34 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:40:34 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 20:40:43 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:40:43 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:40:43 --> Final output sent to browser
DEBUG - 2023-10-30 20:40:43 --> Total execution time: 9.4796
ERROR - 2023-10-30 20:40:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:40:59 --> Config Class Initialized
INFO - 2023-10-30 20:40:59 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:40:59 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:40:59 --> Utf8 Class Initialized
INFO - 2023-10-30 20:40:59 --> URI Class Initialized
INFO - 2023-10-30 20:40:59 --> Router Class Initialized
INFO - 2023-10-30 20:40:59 --> Output Class Initialized
INFO - 2023-10-30 20:40:59 --> Security Class Initialized
DEBUG - 2023-10-30 20:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:40:59 --> Input Class Initialized
INFO - 2023-10-30 20:40:59 --> Language Class Initialized
INFO - 2023-10-30 20:40:59 --> Loader Class Initialized
INFO - 2023-10-30 20:40:59 --> Helper loaded: url_helper
INFO - 2023-10-30 20:40:59 --> Helper loaded: form_helper
INFO - 2023-10-30 20:40:59 --> Helper loaded: file_helper
INFO - 2023-10-30 20:40:59 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:40:59 --> Form Validation Class Initialized
INFO - 2023-10-30 20:40:59 --> Upload Class Initialized
INFO - 2023-10-30 20:40:59 --> Model "M_auth" initialized
INFO - 2023-10-30 20:40:59 --> Model "M_user" initialized
INFO - 2023-10-30 20:40:59 --> Model "M_produk" initialized
INFO - 2023-10-30 20:40:59 --> Controller Class Initialized
INFO - 2023-10-30 20:40:59 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:40:59 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:40:59 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:40:59 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:40:59 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:40:59 --> Model "M_bank" initialized
INFO - 2023-10-30 20:40:59 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:40:59 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 20:41:00 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:41:00 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:41:00 --> Final output sent to browser
DEBUG - 2023-10-30 20:41:00 --> Total execution time: 0.8675
ERROR - 2023-10-30 20:42:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:42:50 --> Config Class Initialized
INFO - 2023-10-30 20:42:50 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:42:50 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:42:50 --> Utf8 Class Initialized
INFO - 2023-10-30 20:42:50 --> URI Class Initialized
INFO - 2023-10-30 20:42:50 --> Router Class Initialized
INFO - 2023-10-30 20:42:50 --> Output Class Initialized
INFO - 2023-10-30 20:42:50 --> Security Class Initialized
DEBUG - 2023-10-30 20:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:42:50 --> Input Class Initialized
INFO - 2023-10-30 20:42:50 --> Language Class Initialized
INFO - 2023-10-30 20:42:50 --> Loader Class Initialized
INFO - 2023-10-30 20:42:50 --> Helper loaded: url_helper
INFO - 2023-10-30 20:42:50 --> Helper loaded: form_helper
INFO - 2023-10-30 20:42:50 --> Helper loaded: file_helper
INFO - 2023-10-30 20:42:50 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:42:50 --> Form Validation Class Initialized
INFO - 2023-10-30 20:42:50 --> Upload Class Initialized
INFO - 2023-10-30 20:42:50 --> Model "M_auth" initialized
INFO - 2023-10-30 20:42:50 --> Model "M_user" initialized
INFO - 2023-10-30 20:42:50 --> Model "M_produk" initialized
INFO - 2023-10-30 20:42:50 --> Controller Class Initialized
INFO - 2023-10-30 20:42:50 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:42:50 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:42:50 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:42:50 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:42:50 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:42:50 --> Model "M_bank" initialized
INFO - 2023-10-30 20:42:50 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:42:50 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 20:43:01 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:43:01 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:43:01 --> Final output sent to browser
DEBUG - 2023-10-30 20:43:01 --> Total execution time: 10.6857
ERROR - 2023-10-30 20:43:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:43:54 --> Config Class Initialized
INFO - 2023-10-30 20:43:54 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:43:54 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:43:54 --> Utf8 Class Initialized
INFO - 2023-10-30 20:43:54 --> URI Class Initialized
INFO - 2023-10-30 20:43:54 --> Router Class Initialized
INFO - 2023-10-30 20:43:54 --> Output Class Initialized
INFO - 2023-10-30 20:43:54 --> Security Class Initialized
DEBUG - 2023-10-30 20:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:43:54 --> Input Class Initialized
INFO - 2023-10-30 20:43:54 --> Language Class Initialized
INFO - 2023-10-30 20:43:54 --> Loader Class Initialized
INFO - 2023-10-30 20:43:54 --> Helper loaded: url_helper
INFO - 2023-10-30 20:43:54 --> Helper loaded: form_helper
INFO - 2023-10-30 20:43:54 --> Helper loaded: file_helper
INFO - 2023-10-30 20:43:54 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:43:54 --> Form Validation Class Initialized
INFO - 2023-10-30 20:43:54 --> Upload Class Initialized
INFO - 2023-10-30 20:43:54 --> Model "M_auth" initialized
INFO - 2023-10-30 20:43:54 --> Model "M_user" initialized
INFO - 2023-10-30 20:43:54 --> Model "M_produk" initialized
INFO - 2023-10-30 20:43:54 --> Controller Class Initialized
INFO - 2023-10-30 20:43:54 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:43:54 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:43:54 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:43:54 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:43:54 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:43:54 --> Model "M_bank" initialized
INFO - 2023-10-30 20:43:54 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:43:54 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-30 20:43:54 --> Severity: Warning --> Undefined variable $params C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Home.php 356
INFO - 2023-10-30 20:43:54 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:43:54 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:43:54 --> Final output sent to browser
DEBUG - 2023-10-30 20:43:54 --> Total execution time: 0.0839
ERROR - 2023-10-30 20:51:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:51:22 --> Config Class Initialized
INFO - 2023-10-30 20:51:22 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:51:22 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:51:22 --> Utf8 Class Initialized
INFO - 2023-10-30 20:51:22 --> URI Class Initialized
INFO - 2023-10-30 20:51:22 --> Router Class Initialized
INFO - 2023-10-30 20:51:22 --> Output Class Initialized
INFO - 2023-10-30 20:51:22 --> Security Class Initialized
DEBUG - 2023-10-30 20:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:51:22 --> Input Class Initialized
INFO - 2023-10-30 20:51:22 --> Language Class Initialized
INFO - 2023-10-30 20:51:22 --> Loader Class Initialized
INFO - 2023-10-30 20:51:22 --> Helper loaded: url_helper
INFO - 2023-10-30 20:51:22 --> Helper loaded: form_helper
INFO - 2023-10-30 20:51:22 --> Helper loaded: file_helper
INFO - 2023-10-30 20:51:22 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:51:22 --> Form Validation Class Initialized
INFO - 2023-10-30 20:51:22 --> Upload Class Initialized
INFO - 2023-10-30 20:51:22 --> Model "M_auth" initialized
INFO - 2023-10-30 20:51:22 --> Model "M_user" initialized
INFO - 2023-10-30 20:51:22 --> Model "M_produk" initialized
INFO - 2023-10-30 20:51:22 --> Controller Class Initialized
INFO - 2023-10-30 20:51:22 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:51:22 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:51:22 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:51:22 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:51:22 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:51:22 --> Model "M_bank" initialized
INFO - 2023-10-30 20:51:22 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:51:22 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 20:51:23 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:51:23 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:51:23 --> Final output sent to browser
DEBUG - 2023-10-30 20:51:23 --> Total execution time: 0.6259
ERROR - 2023-10-30 20:51:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:51:30 --> Config Class Initialized
INFO - 2023-10-30 20:51:30 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:51:30 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:51:30 --> Utf8 Class Initialized
INFO - 2023-10-30 20:51:30 --> URI Class Initialized
INFO - 2023-10-30 20:51:30 --> Router Class Initialized
INFO - 2023-10-30 20:51:30 --> Output Class Initialized
INFO - 2023-10-30 20:51:30 --> Security Class Initialized
DEBUG - 2023-10-30 20:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:51:30 --> Input Class Initialized
INFO - 2023-10-30 20:51:30 --> Language Class Initialized
INFO - 2023-10-30 20:51:30 --> Loader Class Initialized
INFO - 2023-10-30 20:51:30 --> Helper loaded: url_helper
INFO - 2023-10-30 20:51:30 --> Helper loaded: form_helper
INFO - 2023-10-30 20:51:30 --> Helper loaded: file_helper
INFO - 2023-10-30 20:51:30 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:51:30 --> Form Validation Class Initialized
INFO - 2023-10-30 20:51:30 --> Upload Class Initialized
INFO - 2023-10-30 20:51:30 --> Model "M_auth" initialized
INFO - 2023-10-30 20:51:30 --> Model "M_user" initialized
INFO - 2023-10-30 20:51:30 --> Model "M_produk" initialized
INFO - 2023-10-30 20:51:30 --> Controller Class Initialized
INFO - 2023-10-30 20:51:30 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:51:30 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:51:30 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:51:30 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:51:30 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:51:30 --> Model "M_bank" initialized
INFO - 2023-10-30 20:51:30 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:51:30 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 20:51:31 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:51:31 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:51:31 --> Final output sent to browser
DEBUG - 2023-10-30 20:51:31 --> Total execution time: 0.9766
ERROR - 2023-10-30 20:54:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:54:57 --> Config Class Initialized
INFO - 2023-10-30 20:54:57 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:54:57 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:54:57 --> Utf8 Class Initialized
INFO - 2023-10-30 20:54:57 --> URI Class Initialized
INFO - 2023-10-30 20:54:57 --> Router Class Initialized
INFO - 2023-10-30 20:54:57 --> Output Class Initialized
INFO - 2023-10-30 20:54:57 --> Security Class Initialized
DEBUG - 2023-10-30 20:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:54:57 --> Input Class Initialized
INFO - 2023-10-30 20:54:57 --> Language Class Initialized
INFO - 2023-10-30 20:54:57 --> Loader Class Initialized
INFO - 2023-10-30 20:54:57 --> Helper loaded: url_helper
INFO - 2023-10-30 20:54:57 --> Helper loaded: form_helper
INFO - 2023-10-30 20:54:57 --> Helper loaded: file_helper
INFO - 2023-10-30 20:54:57 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:54:57 --> Form Validation Class Initialized
INFO - 2023-10-30 20:54:57 --> Upload Class Initialized
INFO - 2023-10-30 20:54:57 --> Model "M_auth" initialized
INFO - 2023-10-30 20:54:57 --> Model "M_user" initialized
INFO - 2023-10-30 20:54:57 --> Model "M_produk" initialized
INFO - 2023-10-30 20:54:57 --> Controller Class Initialized
INFO - 2023-10-30 20:54:57 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:54:57 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:54:57 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:54:57 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:54:57 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:54:57 --> Model "M_bank" initialized
INFO - 2023-10-30 20:54:57 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:54:57 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 20:54:58 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:54:58 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:54:58 --> Final output sent to browser
DEBUG - 2023-10-30 20:54:58 --> Total execution time: 1.0778
ERROR - 2023-10-30 20:56:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:56:04 --> Config Class Initialized
INFO - 2023-10-30 20:56:04 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:56:04 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:56:04 --> Utf8 Class Initialized
INFO - 2023-10-30 20:56:04 --> URI Class Initialized
INFO - 2023-10-30 20:56:04 --> Router Class Initialized
INFO - 2023-10-30 20:56:04 --> Output Class Initialized
INFO - 2023-10-30 20:56:04 --> Security Class Initialized
DEBUG - 2023-10-30 20:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:56:04 --> Input Class Initialized
INFO - 2023-10-30 20:56:04 --> Language Class Initialized
INFO - 2023-10-30 20:56:04 --> Loader Class Initialized
INFO - 2023-10-30 20:56:04 --> Helper loaded: url_helper
INFO - 2023-10-30 20:56:04 --> Helper loaded: form_helper
INFO - 2023-10-30 20:56:05 --> Helper loaded: file_helper
INFO - 2023-10-30 20:56:05 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:56:05 --> Form Validation Class Initialized
INFO - 2023-10-30 20:56:05 --> Upload Class Initialized
INFO - 2023-10-30 20:56:05 --> Model "M_auth" initialized
INFO - 2023-10-30 20:56:05 --> Model "M_user" initialized
INFO - 2023-10-30 20:56:05 --> Model "M_produk" initialized
INFO - 2023-10-30 20:56:05 --> Controller Class Initialized
INFO - 2023-10-30 20:56:05 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:56:05 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:56:05 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:56:05 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:56:05 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:56:05 --> Model "M_bank" initialized
INFO - 2023-10-30 20:56:05 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:56:05 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 20:56:05 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:56:05 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:56:05 --> Final output sent to browser
DEBUG - 2023-10-30 20:56:05 --> Total execution time: 0.7207
ERROR - 2023-10-30 20:56:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 20:56:13 --> Config Class Initialized
INFO - 2023-10-30 20:56:13 --> Hooks Class Initialized
DEBUG - 2023-10-30 20:56:13 --> UTF-8 Support Enabled
INFO - 2023-10-30 20:56:13 --> Utf8 Class Initialized
INFO - 2023-10-30 20:56:13 --> URI Class Initialized
INFO - 2023-10-30 20:56:13 --> Router Class Initialized
INFO - 2023-10-30 20:56:13 --> Output Class Initialized
INFO - 2023-10-30 20:56:13 --> Security Class Initialized
DEBUG - 2023-10-30 20:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 20:56:13 --> Input Class Initialized
INFO - 2023-10-30 20:56:13 --> Language Class Initialized
INFO - 2023-10-30 20:56:13 --> Loader Class Initialized
INFO - 2023-10-30 20:56:13 --> Helper loaded: url_helper
INFO - 2023-10-30 20:56:13 --> Helper loaded: form_helper
INFO - 2023-10-30 20:56:13 --> Helper loaded: file_helper
INFO - 2023-10-30 20:56:13 --> Database Driver Class Initialized
DEBUG - 2023-10-30 20:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 20:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 20:56:13 --> Form Validation Class Initialized
INFO - 2023-10-30 20:56:13 --> Upload Class Initialized
INFO - 2023-10-30 20:56:13 --> Model "M_auth" initialized
INFO - 2023-10-30 20:56:13 --> Model "M_user" initialized
INFO - 2023-10-30 20:56:13 --> Model "M_produk" initialized
INFO - 2023-10-30 20:56:13 --> Controller Class Initialized
INFO - 2023-10-30 20:56:13 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 20:56:13 --> Model "M_produk" initialized
DEBUG - 2023-10-30 20:56:13 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 20:56:13 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 20:56:13 --> Model "M_transaksi" initialized
INFO - 2023-10-30 20:56:13 --> Model "M_bank" initialized
INFO - 2023-10-30 20:56:13 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 20:56:13 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-30 20:56:13 --> Severity: Warning --> Undefined variable $sub_total C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Home.php 559
INFO - 2023-10-30 20:56:14 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 20:56:14 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 20:56:14 --> Final output sent to browser
DEBUG - 2023-10-30 20:56:14 --> Total execution time: 0.8258
ERROR - 2023-10-30 21:00:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 21:00:09 --> Config Class Initialized
INFO - 2023-10-30 21:00:09 --> Hooks Class Initialized
DEBUG - 2023-10-30 21:00:09 --> UTF-8 Support Enabled
INFO - 2023-10-30 21:00:09 --> Utf8 Class Initialized
INFO - 2023-10-30 21:00:09 --> URI Class Initialized
INFO - 2023-10-30 21:00:09 --> Router Class Initialized
INFO - 2023-10-30 21:00:09 --> Output Class Initialized
INFO - 2023-10-30 21:00:09 --> Security Class Initialized
DEBUG - 2023-10-30 21:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 21:00:09 --> Input Class Initialized
INFO - 2023-10-30 21:00:09 --> Language Class Initialized
INFO - 2023-10-30 21:00:09 --> Loader Class Initialized
INFO - 2023-10-30 21:00:09 --> Helper loaded: url_helper
INFO - 2023-10-30 21:00:09 --> Helper loaded: form_helper
INFO - 2023-10-30 21:00:09 --> Helper loaded: file_helper
INFO - 2023-10-30 21:00:09 --> Database Driver Class Initialized
DEBUG - 2023-10-30 21:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 21:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 21:00:09 --> Form Validation Class Initialized
INFO - 2023-10-30 21:00:09 --> Upload Class Initialized
INFO - 2023-10-30 21:00:09 --> Model "M_auth" initialized
INFO - 2023-10-30 21:00:09 --> Model "M_user" initialized
INFO - 2023-10-30 21:00:09 --> Model "M_produk" initialized
INFO - 2023-10-30 21:00:09 --> Controller Class Initialized
INFO - 2023-10-30 21:00:09 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 21:00:09 --> Model "M_produk" initialized
DEBUG - 2023-10-30 21:00:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 21:00:09 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 21:00:09 --> Model "M_transaksi" initialized
INFO - 2023-10-30 21:00:09 --> Model "M_bank" initialized
INFO - 2023-10-30 21:00:09 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 21:00:09 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 21:00:10 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 21:00:10 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 21:00:10 --> Final output sent to browser
DEBUG - 2023-10-30 21:00:10 --> Total execution time: 0.5330
ERROR - 2023-10-30 21:00:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-30 21:00:17 --> Config Class Initialized
INFO - 2023-10-30 21:00:17 --> Hooks Class Initialized
DEBUG - 2023-10-30 21:00:17 --> UTF-8 Support Enabled
INFO - 2023-10-30 21:00:17 --> Utf8 Class Initialized
INFO - 2023-10-30 21:00:17 --> URI Class Initialized
INFO - 2023-10-30 21:00:17 --> Router Class Initialized
INFO - 2023-10-30 21:00:17 --> Output Class Initialized
INFO - 2023-10-30 21:00:17 --> Security Class Initialized
DEBUG - 2023-10-30 21:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 21:00:17 --> Input Class Initialized
INFO - 2023-10-30 21:00:17 --> Language Class Initialized
INFO - 2023-10-30 21:00:17 --> Loader Class Initialized
INFO - 2023-10-30 21:00:17 --> Helper loaded: url_helper
INFO - 2023-10-30 21:00:17 --> Helper loaded: form_helper
INFO - 2023-10-30 21:00:17 --> Helper loaded: file_helper
INFO - 2023-10-30 21:00:17 --> Database Driver Class Initialized
DEBUG - 2023-10-30 21:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-30 21:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 21:00:17 --> Form Validation Class Initialized
INFO - 2023-10-30 21:00:17 --> Upload Class Initialized
INFO - 2023-10-30 21:00:17 --> Model "M_auth" initialized
INFO - 2023-10-30 21:00:17 --> Model "M_user" initialized
INFO - 2023-10-30 21:00:17 --> Model "M_produk" initialized
INFO - 2023-10-30 21:00:17 --> Controller Class Initialized
INFO - 2023-10-30 21:00:17 --> Model "M_pelanggan" initialized
INFO - 2023-10-30 21:00:17 --> Model "M_produk" initialized
DEBUG - 2023-10-30 21:00:17 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-30 21:00:17 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-30 21:00:17 --> Model "M_transaksi" initialized
INFO - 2023-10-30 21:00:17 --> Model "M_bank" initialized
INFO - 2023-10-30 21:00:17 --> Model "M_pesan" initialized
DEBUG - 2023-10-30 21:00:17 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-30 21:00:17 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-30 21:00:17 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-30 21:00:17 --> Final output sent to browser
DEBUG - 2023-10-30 21:00:17 --> Total execution time: 0.4949
