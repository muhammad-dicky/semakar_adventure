<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-10-13 19:28:53 --> Config Class Initialized
INFO - 2023-10-13 19:28:53 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:28:53 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:28:53 --> Utf8 Class Initialized
INFO - 2023-10-13 19:28:53 --> URI Class Initialized
DEBUG - 2023-10-13 19:28:53 --> No URI present. Default controller set.
INFO - 2023-10-13 19:28:53 --> Router Class Initialized
INFO - 2023-10-13 19:28:53 --> Output Class Initialized
INFO - 2023-10-13 19:28:53 --> Security Class Initialized
DEBUG - 2023-10-13 19:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:28:53 --> Input Class Initialized
INFO - 2023-10-13 19:28:53 --> Language Class Initialized
INFO - 2023-10-13 19:28:53 --> Loader Class Initialized
INFO - 2023-10-13 19:28:53 --> Helper loaded: url_helper
INFO - 2023-10-13 19:28:53 --> Helper loaded: form_helper
INFO - 2023-10-13 19:28:53 --> Helper loaded: file_helper
INFO - 2023-10-13 19:28:53 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:28:53 --> Form Validation Class Initialized
INFO - 2023-10-13 19:28:53 --> Upload Class Initialized
INFO - 2023-10-13 19:28:53 --> Model "M_auth" initialized
INFO - 2023-10-13 19:28:53 --> Model "M_user" initialized
INFO - 2023-10-13 19:28:53 --> Model "M_produk" initialized
INFO - 2023-10-13 19:28:53 --> Controller Class Initialized
INFO - 2023-10-13 19:28:53 --> Model "M_pelanggan" initialized
INFO - 2023-10-13 19:28:53 --> Model "M_produk" initialized
DEBUG - 2023-10-13 19:28:53 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-13 19:28:53 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-13 19:28:53 --> Model "M_transaksi" initialized
INFO - 2023-10-13 19:28:53 --> Model "M_bank" initialized
INFO - 2023-10-13 19:28:53 --> Model "M_pesan" initialized
INFO - 2023-10-13 19:28:53 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-13 19:28:53 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-13 19:28:53 --> Final output sent to browser
DEBUG - 2023-10-13 19:28:53 --> Total execution time: 0.5730
INFO - 2023-10-13 19:29:19 --> Config Class Initialized
INFO - 2023-10-13 19:29:19 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:29:19 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:29:19 --> Utf8 Class Initialized
INFO - 2023-10-13 19:29:19 --> URI Class Initialized
INFO - 2023-10-13 19:29:19 --> Router Class Initialized
INFO - 2023-10-13 19:29:19 --> Output Class Initialized
INFO - 2023-10-13 19:29:19 --> Security Class Initialized
DEBUG - 2023-10-13 19:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:29:19 --> Input Class Initialized
INFO - 2023-10-13 19:29:19 --> Language Class Initialized
INFO - 2023-10-13 19:29:19 --> Loader Class Initialized
INFO - 2023-10-13 19:29:19 --> Helper loaded: url_helper
INFO - 2023-10-13 19:29:19 --> Helper loaded: form_helper
INFO - 2023-10-13 19:29:19 --> Helper loaded: file_helper
INFO - 2023-10-13 19:29:19 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:29:19 --> Form Validation Class Initialized
INFO - 2023-10-13 19:29:19 --> Upload Class Initialized
INFO - 2023-10-13 19:29:19 --> Model "M_auth" initialized
INFO - 2023-10-13 19:29:19 --> Model "M_user" initialized
INFO - 2023-10-13 19:29:19 --> Model "M_produk" initialized
INFO - 2023-10-13 19:29:19 --> Controller Class Initialized
INFO - 2023-10-13 19:29:19 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-10-13 19:29:19 --> Final output sent to browser
DEBUG - 2023-10-13 19:29:19 --> Total execution time: 0.0424
INFO - 2023-10-13 19:29:25 --> Config Class Initialized
INFO - 2023-10-13 19:29:25 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:29:25 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:29:25 --> Utf8 Class Initialized
INFO - 2023-10-13 19:29:25 --> URI Class Initialized
INFO - 2023-10-13 19:29:25 --> Router Class Initialized
INFO - 2023-10-13 19:29:25 --> Output Class Initialized
INFO - 2023-10-13 19:29:25 --> Security Class Initialized
DEBUG - 2023-10-13 19:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:29:25 --> Input Class Initialized
INFO - 2023-10-13 19:29:25 --> Language Class Initialized
INFO - 2023-10-13 19:29:25 --> Loader Class Initialized
INFO - 2023-10-13 19:29:25 --> Helper loaded: url_helper
INFO - 2023-10-13 19:29:25 --> Helper loaded: form_helper
INFO - 2023-10-13 19:29:25 --> Helper loaded: file_helper
INFO - 2023-10-13 19:29:25 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:29:25 --> Form Validation Class Initialized
INFO - 2023-10-13 19:29:25 --> Upload Class Initialized
INFO - 2023-10-13 19:29:25 --> Model "M_auth" initialized
INFO - 2023-10-13 19:29:25 --> Model "M_user" initialized
INFO - 2023-10-13 19:29:25 --> Model "M_produk" initialized
INFO - 2023-10-13 19:29:25 --> Controller Class Initialized
INFO - 2023-10-13 19:29:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-10-13 19:29:25 --> Config Class Initialized
INFO - 2023-10-13 19:29:25 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:29:25 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:29:25 --> Utf8 Class Initialized
INFO - 2023-10-13 19:29:25 --> URI Class Initialized
INFO - 2023-10-13 19:29:25 --> Router Class Initialized
INFO - 2023-10-13 19:29:25 --> Output Class Initialized
INFO - 2023-10-13 19:29:25 --> Security Class Initialized
DEBUG - 2023-10-13 19:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:29:25 --> Input Class Initialized
INFO - 2023-10-13 19:29:25 --> Language Class Initialized
INFO - 2023-10-13 19:29:25 --> Loader Class Initialized
INFO - 2023-10-13 19:29:25 --> Helper loaded: url_helper
INFO - 2023-10-13 19:29:25 --> Helper loaded: form_helper
INFO - 2023-10-13 19:29:25 --> Helper loaded: file_helper
INFO - 2023-10-13 19:29:25 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:29:25 --> Form Validation Class Initialized
INFO - 2023-10-13 19:29:25 --> Upload Class Initialized
INFO - 2023-10-13 19:29:25 --> Model "M_auth" initialized
INFO - 2023-10-13 19:29:25 --> Model "M_user" initialized
INFO - 2023-10-13 19:29:25 --> Model "M_produk" initialized
INFO - 2023-10-13 19:29:25 --> Controller Class Initialized
INFO - 2023-10-13 19:29:25 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-10-13 19:29:25 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-13 19:29:25 --> Final output sent to browser
DEBUG - 2023-10-13 19:29:25 --> Total execution time: 0.1041
INFO - 2023-10-13 19:29:31 --> Config Class Initialized
INFO - 2023-10-13 19:29:31 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:29:31 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:29:31 --> Utf8 Class Initialized
INFO - 2023-10-13 19:29:31 --> URI Class Initialized
INFO - 2023-10-13 19:29:31 --> Router Class Initialized
INFO - 2023-10-13 19:29:31 --> Output Class Initialized
INFO - 2023-10-13 19:29:31 --> Security Class Initialized
DEBUG - 2023-10-13 19:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:29:31 --> Input Class Initialized
INFO - 2023-10-13 19:29:31 --> Language Class Initialized
INFO - 2023-10-13 19:29:31 --> Loader Class Initialized
INFO - 2023-10-13 19:29:31 --> Helper loaded: url_helper
INFO - 2023-10-13 19:29:31 --> Helper loaded: form_helper
INFO - 2023-10-13 19:29:31 --> Helper loaded: file_helper
INFO - 2023-10-13 19:29:31 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:29:31 --> Form Validation Class Initialized
INFO - 2023-10-13 19:29:31 --> Upload Class Initialized
INFO - 2023-10-13 19:29:31 --> Model "M_auth" initialized
INFO - 2023-10-13 19:29:31 --> Model "M_user" initialized
INFO - 2023-10-13 19:29:31 --> Model "M_produk" initialized
INFO - 2023-10-13 19:29:31 --> Controller Class Initialized
INFO - 2023-10-13 19:29:31 --> Model "M_pesan" initialized
INFO - 2023-10-13 19:29:31 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_pengaduan.php
INFO - 2023-10-13 19:29:31 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-13 19:29:31 --> Final output sent to browser
DEBUG - 2023-10-13 19:29:31 --> Total execution time: 0.0479
INFO - 2023-10-13 19:31:35 --> Config Class Initialized
INFO - 2023-10-13 19:31:35 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:31:35 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:31:35 --> Utf8 Class Initialized
INFO - 2023-10-13 19:31:35 --> URI Class Initialized
INFO - 2023-10-13 19:31:35 --> Router Class Initialized
INFO - 2023-10-13 19:31:35 --> Output Class Initialized
INFO - 2023-10-13 19:31:35 --> Security Class Initialized
DEBUG - 2023-10-13 19:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:31:35 --> Input Class Initialized
INFO - 2023-10-13 19:31:35 --> Language Class Initialized
INFO - 2023-10-13 19:31:35 --> Loader Class Initialized
INFO - 2023-10-13 19:31:35 --> Helper loaded: url_helper
INFO - 2023-10-13 19:31:35 --> Helper loaded: form_helper
INFO - 2023-10-13 19:31:35 --> Helper loaded: file_helper
INFO - 2023-10-13 19:31:35 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:31:35 --> Form Validation Class Initialized
INFO - 2023-10-13 19:31:35 --> Upload Class Initialized
INFO - 2023-10-13 19:31:35 --> Model "M_auth" initialized
INFO - 2023-10-13 19:31:35 --> Model "M_user" initialized
INFO - 2023-10-13 19:31:35 --> Model "M_produk" initialized
INFO - 2023-10-13 19:31:35 --> Controller Class Initialized
INFO - 2023-10-13 19:31:35 --> Model "M_pelanggan" initialized
INFO - 2023-10-13 19:31:35 --> Model "M_produk" initialized
DEBUG - 2023-10-13 19:31:35 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-13 19:31:35 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-13 19:31:35 --> Model "M_transaksi" initialized
INFO - 2023-10-13 19:31:35 --> Model "M_bank" initialized
INFO - 2023-10-13 19:31:35 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_all_bank.php
INFO - 2023-10-13 19:31:35 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-13 19:31:35 --> Final output sent to browser
DEBUG - 2023-10-13 19:31:35 --> Total execution time: 0.0512
INFO - 2023-10-13 19:33:10 --> Config Class Initialized
INFO - 2023-10-13 19:33:10 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:33:10 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:33:10 --> Utf8 Class Initialized
INFO - 2023-10-13 19:33:10 --> URI Class Initialized
INFO - 2023-10-13 19:33:10 --> Router Class Initialized
INFO - 2023-10-13 19:33:10 --> Output Class Initialized
INFO - 2023-10-13 19:33:10 --> Security Class Initialized
DEBUG - 2023-10-13 19:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:33:10 --> Input Class Initialized
INFO - 2023-10-13 19:33:10 --> Language Class Initialized
INFO - 2023-10-13 19:33:10 --> Loader Class Initialized
INFO - 2023-10-13 19:33:10 --> Helper loaded: url_helper
INFO - 2023-10-13 19:33:10 --> Helper loaded: form_helper
INFO - 2023-10-13 19:33:10 --> Helper loaded: file_helper
INFO - 2023-10-13 19:33:10 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:33:10 --> Form Validation Class Initialized
INFO - 2023-10-13 19:33:10 --> Upload Class Initialized
INFO - 2023-10-13 19:33:10 --> Model "M_auth" initialized
INFO - 2023-10-13 19:33:10 --> Model "M_user" initialized
INFO - 2023-10-13 19:33:10 --> Model "M_produk" initialized
INFO - 2023-10-13 19:33:10 --> Controller Class Initialized
INFO - 2023-10-13 19:33:10 --> Model "M_pelanggan" initialized
INFO - 2023-10-13 19:33:10 --> Model "M_produk" initialized
DEBUG - 2023-10-13 19:33:10 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-13 19:33:10 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-13 19:33:10 --> Model "M_transaksi" initialized
INFO - 2023-10-13 19:33:10 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_transaksi_all.php
INFO - 2023-10-13 19:33:10 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-13 19:33:10 --> Final output sent to browser
DEBUG - 2023-10-13 19:33:10 --> Total execution time: 0.0919
INFO - 2023-10-13 19:34:04 --> Config Class Initialized
INFO - 2023-10-13 19:34:04 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:34:04 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:34:04 --> Utf8 Class Initialized
INFO - 2023-10-13 19:34:04 --> URI Class Initialized
INFO - 2023-10-13 19:34:04 --> Router Class Initialized
INFO - 2023-10-13 19:34:04 --> Output Class Initialized
INFO - 2023-10-13 19:34:04 --> Security Class Initialized
DEBUG - 2023-10-13 19:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:34:04 --> Input Class Initialized
INFO - 2023-10-13 19:34:04 --> Language Class Initialized
INFO - 2023-10-13 19:34:04 --> Loader Class Initialized
INFO - 2023-10-13 19:34:04 --> Helper loaded: url_helper
INFO - 2023-10-13 19:34:04 --> Helper loaded: form_helper
INFO - 2023-10-13 19:34:04 --> Helper loaded: file_helper
INFO - 2023-10-13 19:34:04 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:34:04 --> Form Validation Class Initialized
INFO - 2023-10-13 19:34:04 --> Upload Class Initialized
INFO - 2023-10-13 19:34:04 --> Model "M_auth" initialized
INFO - 2023-10-13 19:34:04 --> Model "M_user" initialized
INFO - 2023-10-13 19:34:04 --> Model "M_produk" initialized
INFO - 2023-10-13 19:34:04 --> Controller Class Initialized
INFO - 2023-10-13 19:34:04 --> Model "M_pelanggan" initialized
INFO - 2023-10-13 19:34:04 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_pelanggan.php
INFO - 2023-10-13 19:34:04 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-13 19:34:04 --> Final output sent to browser
DEBUG - 2023-10-13 19:34:04 --> Total execution time: 0.0777
INFO - 2023-10-13 19:34:06 --> Config Class Initialized
INFO - 2023-10-13 19:34:06 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:34:06 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:34:06 --> Utf8 Class Initialized
INFO - 2023-10-13 19:34:06 --> URI Class Initialized
INFO - 2023-10-13 19:34:06 --> Router Class Initialized
INFO - 2023-10-13 19:34:06 --> Output Class Initialized
INFO - 2023-10-13 19:34:06 --> Security Class Initialized
DEBUG - 2023-10-13 19:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:34:06 --> Input Class Initialized
INFO - 2023-10-13 19:34:06 --> Language Class Initialized
INFO - 2023-10-13 19:34:06 --> Loader Class Initialized
INFO - 2023-10-13 19:34:06 --> Helper loaded: url_helper
INFO - 2023-10-13 19:34:06 --> Helper loaded: form_helper
INFO - 2023-10-13 19:34:06 --> Helper loaded: file_helper
INFO - 2023-10-13 19:34:06 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:34:06 --> Form Validation Class Initialized
INFO - 2023-10-13 19:34:06 --> Upload Class Initialized
INFO - 2023-10-13 19:34:06 --> Model "M_auth" initialized
INFO - 2023-10-13 19:34:06 --> Model "M_user" initialized
INFO - 2023-10-13 19:34:06 --> Model "M_produk" initialized
INFO - 2023-10-13 19:34:06 --> Controller Class Initialized
INFO - 2023-10-13 19:34:06 --> Model "M_pelanggan" initialized
INFO - 2023-10-13 19:34:06 --> Model "M_produk" initialized
DEBUG - 2023-10-13 19:34:06 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-13 19:34:06 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-13 19:34:06 --> Model "M_transaksi" initialized
INFO - 2023-10-13 19:34:06 --> Model "M_bank" initialized
INFO - 2023-10-13 19:34:06 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_all_bank.php
INFO - 2023-10-13 19:34:06 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-13 19:34:06 --> Final output sent to browser
DEBUG - 2023-10-13 19:34:06 --> Total execution time: 0.0241
INFO - 2023-10-13 19:34:10 --> Config Class Initialized
INFO - 2023-10-13 19:34:10 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:34:10 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:34:10 --> Utf8 Class Initialized
INFO - 2023-10-13 19:34:10 --> URI Class Initialized
INFO - 2023-10-13 19:34:10 --> Router Class Initialized
INFO - 2023-10-13 19:34:10 --> Output Class Initialized
INFO - 2023-10-13 19:34:10 --> Security Class Initialized
DEBUG - 2023-10-13 19:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:34:10 --> Input Class Initialized
INFO - 2023-10-13 19:34:10 --> Language Class Initialized
INFO - 2023-10-13 19:34:10 --> Loader Class Initialized
INFO - 2023-10-13 19:34:10 --> Helper loaded: url_helper
INFO - 2023-10-13 19:34:10 --> Helper loaded: form_helper
INFO - 2023-10-13 19:34:10 --> Helper loaded: file_helper
INFO - 2023-10-13 19:34:10 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:34:10 --> Form Validation Class Initialized
INFO - 2023-10-13 19:34:10 --> Upload Class Initialized
INFO - 2023-10-13 19:34:10 --> Model "M_auth" initialized
INFO - 2023-10-13 19:34:10 --> Model "M_user" initialized
INFO - 2023-10-13 19:34:10 --> Model "M_produk" initialized
INFO - 2023-10-13 19:34:10 --> Controller Class Initialized
INFO - 2023-10-13 19:34:10 --> Model "M_pelanggan" initialized
INFO - 2023-10-13 19:34:10 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_pelanggan.php
INFO - 2023-10-13 19:34:10 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-13 19:34:10 --> Final output sent to browser
DEBUG - 2023-10-13 19:34:10 --> Total execution time: 0.0251
INFO - 2023-10-13 19:34:15 --> Config Class Initialized
INFO - 2023-10-13 19:34:15 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:34:15 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:34:15 --> Utf8 Class Initialized
INFO - 2023-10-13 19:34:15 --> URI Class Initialized
INFO - 2023-10-13 19:34:15 --> Router Class Initialized
INFO - 2023-10-13 19:34:15 --> Output Class Initialized
INFO - 2023-10-13 19:34:15 --> Security Class Initialized
DEBUG - 2023-10-13 19:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:34:15 --> Input Class Initialized
INFO - 2023-10-13 19:34:15 --> Language Class Initialized
INFO - 2023-10-13 19:34:15 --> Loader Class Initialized
INFO - 2023-10-13 19:34:15 --> Helper loaded: url_helper
INFO - 2023-10-13 19:34:15 --> Helper loaded: form_helper
INFO - 2023-10-13 19:34:15 --> Helper loaded: file_helper
INFO - 2023-10-13 19:34:15 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:34:15 --> Form Validation Class Initialized
INFO - 2023-10-13 19:34:15 --> Upload Class Initialized
INFO - 2023-10-13 19:34:15 --> Model "M_auth" initialized
INFO - 2023-10-13 19:34:15 --> Model "M_user" initialized
INFO - 2023-10-13 19:34:15 --> Model "M_produk" initialized
INFO - 2023-10-13 19:34:15 --> Controller Class Initialized
INFO - 2023-10-13 19:34:15 --> Config Class Initialized
INFO - 2023-10-13 19:34:15 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:34:15 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:34:15 --> Utf8 Class Initialized
INFO - 2023-10-13 19:34:15 --> URI Class Initialized
INFO - 2023-10-13 19:34:15 --> Router Class Initialized
INFO - 2023-10-13 19:34:15 --> Output Class Initialized
INFO - 2023-10-13 19:34:15 --> Security Class Initialized
DEBUG - 2023-10-13 19:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:34:15 --> Input Class Initialized
INFO - 2023-10-13 19:34:15 --> Language Class Initialized
INFO - 2023-10-13 19:34:15 --> Loader Class Initialized
INFO - 2023-10-13 19:34:15 --> Helper loaded: url_helper
INFO - 2023-10-13 19:34:15 --> Helper loaded: form_helper
INFO - 2023-10-13 19:34:15 --> Helper loaded: file_helper
INFO - 2023-10-13 19:34:15 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:34:15 --> Form Validation Class Initialized
INFO - 2023-10-13 19:34:15 --> Upload Class Initialized
INFO - 2023-10-13 19:34:15 --> Model "M_auth" initialized
INFO - 2023-10-13 19:34:15 --> Model "M_user" initialized
INFO - 2023-10-13 19:34:15 --> Model "M_produk" initialized
INFO - 2023-10-13 19:34:15 --> Controller Class Initialized
INFO - 2023-10-13 19:34:15 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-10-13 19:34:15 --> Final output sent to browser
DEBUG - 2023-10-13 19:34:15 --> Total execution time: 0.0220
INFO - 2023-10-13 19:34:23 --> Config Class Initialized
INFO - 2023-10-13 19:34:23 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:34:23 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:34:23 --> Utf8 Class Initialized
INFO - 2023-10-13 19:34:23 --> URI Class Initialized
INFO - 2023-10-13 19:34:23 --> Router Class Initialized
INFO - 2023-10-13 19:34:23 --> Output Class Initialized
INFO - 2023-10-13 19:34:23 --> Security Class Initialized
DEBUG - 2023-10-13 19:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:34:23 --> Input Class Initialized
INFO - 2023-10-13 19:34:23 --> Language Class Initialized
INFO - 2023-10-13 19:34:23 --> Loader Class Initialized
INFO - 2023-10-13 19:34:23 --> Helper loaded: url_helper
INFO - 2023-10-13 19:34:23 --> Helper loaded: form_helper
INFO - 2023-10-13 19:34:23 --> Helper loaded: file_helper
INFO - 2023-10-13 19:34:23 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:34:23 --> Form Validation Class Initialized
INFO - 2023-10-13 19:34:23 --> Upload Class Initialized
INFO - 2023-10-13 19:34:23 --> Model "M_auth" initialized
INFO - 2023-10-13 19:34:23 --> Model "M_user" initialized
INFO - 2023-10-13 19:34:23 --> Model "M_produk" initialized
INFO - 2023-10-13 19:34:23 --> Controller Class Initialized
INFO - 2023-10-13 19:34:23 --> Model "M_pelanggan" initialized
ERROR - 2023-10-13 19:34:23 --> Severity: Warning --> Attempt to read property "level_user" on null C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Pelanggan.php 40
INFO - 2023-10-13 19:34:23 --> Config Class Initialized
INFO - 2023-10-13 19:34:23 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:34:23 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:34:23 --> Utf8 Class Initialized
INFO - 2023-10-13 19:34:23 --> URI Class Initialized
INFO - 2023-10-13 19:34:23 --> Router Class Initialized
INFO - 2023-10-13 19:34:23 --> Output Class Initialized
INFO - 2023-10-13 19:34:23 --> Security Class Initialized
DEBUG - 2023-10-13 19:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:34:23 --> Input Class Initialized
INFO - 2023-10-13 19:34:23 --> Language Class Initialized
INFO - 2023-10-13 19:34:23 --> Loader Class Initialized
INFO - 2023-10-13 19:34:23 --> Helper loaded: url_helper
INFO - 2023-10-13 19:34:23 --> Helper loaded: form_helper
INFO - 2023-10-13 19:34:23 --> Helper loaded: file_helper
INFO - 2023-10-13 19:34:23 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:34:23 --> Form Validation Class Initialized
INFO - 2023-10-13 19:34:23 --> Upload Class Initialized
INFO - 2023-10-13 19:34:23 --> Model "M_auth" initialized
INFO - 2023-10-13 19:34:23 --> Model "M_user" initialized
INFO - 2023-10-13 19:34:23 --> Model "M_produk" initialized
INFO - 2023-10-13 19:34:23 --> Controller Class Initialized
INFO - 2023-10-13 19:34:23 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-10-13 19:34:23 --> Final output sent to browser
DEBUG - 2023-10-13 19:34:23 --> Total execution time: 0.0220
INFO - 2023-10-13 19:34:27 --> Config Class Initialized
INFO - 2023-10-13 19:34:27 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:34:27 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:34:27 --> Utf8 Class Initialized
INFO - 2023-10-13 19:34:27 --> URI Class Initialized
DEBUG - 2023-10-13 19:34:27 --> No URI present. Default controller set.
INFO - 2023-10-13 19:34:27 --> Router Class Initialized
INFO - 2023-10-13 19:34:27 --> Output Class Initialized
INFO - 2023-10-13 19:34:27 --> Security Class Initialized
DEBUG - 2023-10-13 19:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:34:27 --> Input Class Initialized
INFO - 2023-10-13 19:34:27 --> Language Class Initialized
INFO - 2023-10-13 19:34:27 --> Loader Class Initialized
INFO - 2023-10-13 19:34:27 --> Helper loaded: url_helper
INFO - 2023-10-13 19:34:27 --> Helper loaded: form_helper
INFO - 2023-10-13 19:34:27 --> Helper loaded: file_helper
INFO - 2023-10-13 19:34:27 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:34:27 --> Form Validation Class Initialized
INFO - 2023-10-13 19:34:27 --> Upload Class Initialized
INFO - 2023-10-13 19:34:27 --> Model "M_auth" initialized
INFO - 2023-10-13 19:34:27 --> Model "M_user" initialized
INFO - 2023-10-13 19:34:27 --> Model "M_produk" initialized
INFO - 2023-10-13 19:34:27 --> Controller Class Initialized
INFO - 2023-10-13 19:34:27 --> Model "M_pelanggan" initialized
INFO - 2023-10-13 19:34:27 --> Model "M_produk" initialized
DEBUG - 2023-10-13 19:34:27 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-13 19:34:27 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-13 19:34:27 --> Model "M_transaksi" initialized
INFO - 2023-10-13 19:34:27 --> Model "M_bank" initialized
INFO - 2023-10-13 19:34:27 --> Model "M_pesan" initialized
INFO - 2023-10-13 19:34:27 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-13 19:34:27 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-13 19:34:27 --> Final output sent to browser
DEBUG - 2023-10-13 19:34:27 --> Total execution time: 0.0299
INFO - 2023-10-13 19:34:33 --> Config Class Initialized
INFO - 2023-10-13 19:34:33 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:34:33 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:34:33 --> Utf8 Class Initialized
INFO - 2023-10-13 19:34:33 --> URI Class Initialized
DEBUG - 2023-10-13 19:34:33 --> No URI present. Default controller set.
INFO - 2023-10-13 19:34:33 --> Router Class Initialized
INFO - 2023-10-13 19:34:33 --> Output Class Initialized
INFO - 2023-10-13 19:34:33 --> Security Class Initialized
DEBUG - 2023-10-13 19:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:34:33 --> Input Class Initialized
INFO - 2023-10-13 19:34:33 --> Language Class Initialized
INFO - 2023-10-13 19:34:33 --> Loader Class Initialized
INFO - 2023-10-13 19:34:33 --> Helper loaded: url_helper
INFO - 2023-10-13 19:34:33 --> Helper loaded: form_helper
INFO - 2023-10-13 19:34:33 --> Helper loaded: file_helper
INFO - 2023-10-13 19:34:33 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:34:33 --> Form Validation Class Initialized
INFO - 2023-10-13 19:34:33 --> Upload Class Initialized
INFO - 2023-10-13 19:34:33 --> Model "M_auth" initialized
INFO - 2023-10-13 19:34:33 --> Model "M_user" initialized
INFO - 2023-10-13 19:34:33 --> Model "M_produk" initialized
INFO - 2023-10-13 19:34:33 --> Controller Class Initialized
INFO - 2023-10-13 19:34:33 --> Model "M_pelanggan" initialized
INFO - 2023-10-13 19:34:33 --> Model "M_produk" initialized
DEBUG - 2023-10-13 19:34:33 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-13 19:34:33 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-13 19:34:33 --> Model "M_transaksi" initialized
INFO - 2023-10-13 19:34:33 --> Model "M_bank" initialized
INFO - 2023-10-13 19:34:33 --> Model "M_pesan" initialized
INFO - 2023-10-13 19:34:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-10-13 19:34:33 --> Email Class Initialized
INFO - 2023-10-13 19:34:35 --> Language file loaded: language/english/email_lang.php
INFO - 2023-10-13 19:34:38 --> Config Class Initialized
INFO - 2023-10-13 19:34:38 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:34:38 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:34:38 --> Utf8 Class Initialized
INFO - 2023-10-13 19:34:38 --> URI Class Initialized
DEBUG - 2023-10-13 19:34:38 --> No URI present. Default controller set.
INFO - 2023-10-13 19:34:38 --> Router Class Initialized
INFO - 2023-10-13 19:34:38 --> Output Class Initialized
INFO - 2023-10-13 19:34:38 --> Security Class Initialized
DEBUG - 2023-10-13 19:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:34:38 --> Input Class Initialized
INFO - 2023-10-13 19:34:38 --> Language Class Initialized
INFO - 2023-10-13 19:34:38 --> Loader Class Initialized
INFO - 2023-10-13 19:34:38 --> Helper loaded: url_helper
INFO - 2023-10-13 19:34:38 --> Helper loaded: form_helper
INFO - 2023-10-13 19:34:38 --> Helper loaded: file_helper
INFO - 2023-10-13 19:34:38 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:34:38 --> Form Validation Class Initialized
INFO - 2023-10-13 19:34:38 --> Upload Class Initialized
INFO - 2023-10-13 19:34:38 --> Model "M_auth" initialized
INFO - 2023-10-13 19:34:38 --> Model "M_user" initialized
INFO - 2023-10-13 19:34:38 --> Model "M_produk" initialized
INFO - 2023-10-13 19:34:38 --> Controller Class Initialized
INFO - 2023-10-13 19:34:38 --> Model "M_pelanggan" initialized
INFO - 2023-10-13 19:34:38 --> Model "M_produk" initialized
DEBUG - 2023-10-13 19:34:38 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-13 19:34:38 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-13 19:34:38 --> Model "M_transaksi" initialized
INFO - 2023-10-13 19:34:38 --> Model "M_bank" initialized
INFO - 2023-10-13 19:34:38 --> Model "M_pesan" initialized
INFO - 2023-10-13 19:34:38 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-13 19:34:38 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-13 19:34:38 --> Final output sent to browser
DEBUG - 2023-10-13 19:34:38 --> Total execution time: 0.0283
INFO - 2023-10-13 19:37:12 --> Config Class Initialized
INFO - 2023-10-13 19:37:12 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:37:12 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:37:12 --> Utf8 Class Initialized
INFO - 2023-10-13 19:37:12 --> URI Class Initialized
INFO - 2023-10-13 19:37:12 --> Router Class Initialized
INFO - 2023-10-13 19:37:12 --> Output Class Initialized
INFO - 2023-10-13 19:37:12 --> Security Class Initialized
DEBUG - 2023-10-13 19:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:37:12 --> Input Class Initialized
INFO - 2023-10-13 19:37:12 --> Language Class Initialized
INFO - 2023-10-13 19:37:12 --> Loader Class Initialized
INFO - 2023-10-13 19:37:12 --> Helper loaded: url_helper
INFO - 2023-10-13 19:37:12 --> Helper loaded: form_helper
INFO - 2023-10-13 19:37:12 --> Helper loaded: file_helper
INFO - 2023-10-13 19:37:12 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:37:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:37:12 --> Form Validation Class Initialized
INFO - 2023-10-13 19:37:12 --> Upload Class Initialized
INFO - 2023-10-13 19:37:12 --> Model "M_auth" initialized
INFO - 2023-10-13 19:37:12 --> Model "M_user" initialized
INFO - 2023-10-13 19:37:12 --> Model "M_produk" initialized
INFO - 2023-10-13 19:37:12 --> Controller Class Initialized
INFO - 2023-10-13 19:37:12 --> Model "M_pelanggan" initialized
INFO - 2023-10-13 19:37:12 --> Model "M_produk" initialized
DEBUG - 2023-10-13 19:37:12 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-13 19:37:12 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-13 19:37:12 --> Model "M_transaksi" initialized
INFO - 2023-10-13 19:37:12 --> Model "M_bank" initialized
INFO - 2023-10-13 19:37:12 --> Model "M_pesan" initialized
INFO - 2023-10-13 19:37:12 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-13 19:37:12 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_produk_detail.php
INFO - 2023-10-13 19:37:12 --> Final output sent to browser
DEBUG - 2023-10-13 19:37:12 --> Total execution time: 0.0293
INFO - 2023-10-13 19:37:12 --> Config Class Initialized
INFO - 2023-10-13 19:37:12 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:37:12 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:37:12 --> Utf8 Class Initialized
INFO - 2023-10-13 19:37:12 --> URI Class Initialized
INFO - 2023-10-13 19:37:12 --> Router Class Initialized
INFO - 2023-10-13 19:37:12 --> Output Class Initialized
INFO - 2023-10-13 19:37:12 --> Security Class Initialized
DEBUG - 2023-10-13 19:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:37:12 --> Input Class Initialized
INFO - 2023-10-13 19:37:12 --> Language Class Initialized
INFO - 2023-10-13 19:37:12 --> Loader Class Initialized
INFO - 2023-10-13 19:37:12 --> Helper loaded: url_helper
INFO - 2023-10-13 19:37:12 --> Helper loaded: form_helper
INFO - 2023-10-13 19:37:12 --> Helper loaded: file_helper
INFO - 2023-10-13 19:37:12 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:37:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:37:12 --> Form Validation Class Initialized
INFO - 2023-10-13 19:37:12 --> Upload Class Initialized
INFO - 2023-10-13 19:37:12 --> Model "M_auth" initialized
INFO - 2023-10-13 19:37:12 --> Model "M_user" initialized
INFO - 2023-10-13 19:37:12 --> Model "M_produk" initialized
INFO - 2023-10-13 19:37:12 --> Controller Class Initialized
INFO - 2023-10-13 19:37:12 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-10-13 19:37:12 --> Final output sent to browser
DEBUG - 2023-10-13 19:37:12 --> Total execution time: 0.0440
INFO - 2023-10-13 19:37:31 --> Config Class Initialized
INFO - 2023-10-13 19:37:31 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:37:31 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:37:31 --> Utf8 Class Initialized
INFO - 2023-10-13 19:37:31 --> URI Class Initialized
INFO - 2023-10-13 19:37:31 --> Router Class Initialized
INFO - 2023-10-13 19:37:31 --> Output Class Initialized
INFO - 2023-10-13 19:37:31 --> Security Class Initialized
DEBUG - 2023-10-13 19:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:37:31 --> Input Class Initialized
INFO - 2023-10-13 19:37:31 --> Language Class Initialized
INFO - 2023-10-13 19:37:31 --> Loader Class Initialized
INFO - 2023-10-13 19:37:31 --> Helper loaded: url_helper
INFO - 2023-10-13 19:37:31 --> Helper loaded: form_helper
INFO - 2023-10-13 19:37:31 --> Helper loaded: file_helper
INFO - 2023-10-13 19:37:31 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:37:31 --> Form Validation Class Initialized
INFO - 2023-10-13 19:37:31 --> Upload Class Initialized
INFO - 2023-10-13 19:37:31 --> Model "M_auth" initialized
INFO - 2023-10-13 19:37:31 --> Model "M_user" initialized
INFO - 2023-10-13 19:37:31 --> Model "M_produk" initialized
INFO - 2023-10-13 19:37:31 --> Controller Class Initialized
INFO - 2023-10-13 19:37:31 --> Model "M_pelanggan" initialized
INFO - 2023-10-13 19:37:31 --> Model "M_produk" initialized
DEBUG - 2023-10-13 19:37:31 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-13 19:37:31 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-13 19:37:31 --> Model "M_transaksi" initialized
INFO - 2023-10-13 19:37:31 --> Model "M_bank" initialized
INFO - 2023-10-13 19:37:31 --> Model "M_pesan" initialized
INFO - 2023-10-13 19:37:31 --> Email Class Initialized
INFO - 2023-10-13 19:37:32 --> Language file loaded: language/english/email_lang.php
INFO - 2023-10-13 19:37:35 --> Config Class Initialized
INFO - 2023-10-13 19:37:35 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:37:35 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:37:35 --> Utf8 Class Initialized
INFO - 2023-10-13 19:37:35 --> URI Class Initialized
INFO - 2023-10-13 19:37:35 --> Router Class Initialized
INFO - 2023-10-13 19:37:35 --> Output Class Initialized
INFO - 2023-10-13 19:37:35 --> Security Class Initialized
DEBUG - 2023-10-13 19:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:37:35 --> Input Class Initialized
INFO - 2023-10-13 19:37:35 --> Language Class Initialized
INFO - 2023-10-13 19:37:35 --> Loader Class Initialized
INFO - 2023-10-13 19:37:35 --> Helper loaded: url_helper
INFO - 2023-10-13 19:37:35 --> Helper loaded: form_helper
INFO - 2023-10-13 19:37:35 --> Helper loaded: file_helper
INFO - 2023-10-13 19:37:35 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:37:35 --> Form Validation Class Initialized
INFO - 2023-10-13 19:37:35 --> Upload Class Initialized
INFO - 2023-10-13 19:37:35 --> Model "M_auth" initialized
INFO - 2023-10-13 19:37:35 --> Model "M_user" initialized
INFO - 2023-10-13 19:37:35 --> Model "M_produk" initialized
INFO - 2023-10-13 19:37:35 --> Controller Class Initialized
INFO - 2023-10-13 19:37:35 --> Model "M_pelanggan" initialized
INFO - 2023-10-13 19:37:35 --> Model "M_produk" initialized
DEBUG - 2023-10-13 19:37:35 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-13 19:37:35 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-13 19:37:35 --> Model "M_transaksi" initialized
INFO - 2023-10-13 19:37:35 --> Model "M_bank" initialized
INFO - 2023-10-13 19:37:35 --> Model "M_pesan" initialized
INFO - 2023-10-13 19:37:35 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-13 19:37:35 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-13 19:37:35 --> Final output sent to browser
DEBUG - 2023-10-13 19:37:35 --> Total execution time: 0.0489
INFO - 2023-10-13 19:37:47 --> Config Class Initialized
INFO - 2023-10-13 19:37:47 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:37:47 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:37:47 --> Utf8 Class Initialized
INFO - 2023-10-13 19:37:47 --> URI Class Initialized
INFO - 2023-10-13 19:37:47 --> Router Class Initialized
INFO - 2023-10-13 19:37:47 --> Output Class Initialized
INFO - 2023-10-13 19:37:47 --> Security Class Initialized
DEBUG - 2023-10-13 19:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:37:47 --> Input Class Initialized
INFO - 2023-10-13 19:37:47 --> Language Class Initialized
INFO - 2023-10-13 19:37:47 --> Loader Class Initialized
INFO - 2023-10-13 19:37:47 --> Helper loaded: url_helper
INFO - 2023-10-13 19:37:47 --> Helper loaded: form_helper
INFO - 2023-10-13 19:37:47 --> Helper loaded: file_helper
INFO - 2023-10-13 19:37:47 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:37:47 --> Form Validation Class Initialized
INFO - 2023-10-13 19:37:47 --> Upload Class Initialized
INFO - 2023-10-13 19:37:47 --> Model "M_auth" initialized
INFO - 2023-10-13 19:37:47 --> Model "M_user" initialized
INFO - 2023-10-13 19:37:47 --> Model "M_produk" initialized
INFO - 2023-10-13 19:37:47 --> Controller Class Initialized
INFO - 2023-10-13 19:37:47 --> Model "M_pelanggan" initialized
INFO - 2023-10-13 19:37:47 --> Model "M_produk" initialized
DEBUG - 2023-10-13 19:37:47 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-13 19:37:47 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-13 19:37:47 --> Model "M_transaksi" initialized
INFO - 2023-10-13 19:37:47 --> Model "M_bank" initialized
INFO - 2023-10-13 19:37:47 --> Model "M_pesan" initialized
INFO - 2023-10-13 19:37:47 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-13 19:37:47 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_bayar_sekarang.php
INFO - 2023-10-13 19:37:47 --> Final output sent to browser
DEBUG - 2023-10-13 19:37:47 --> Total execution time: 0.0301
INFO - 2023-10-13 19:37:48 --> Config Class Initialized
INFO - 2023-10-13 19:37:48 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:37:48 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:37:48 --> Utf8 Class Initialized
INFO - 2023-10-13 19:37:48 --> URI Class Initialized
INFO - 2023-10-13 19:37:48 --> Router Class Initialized
INFO - 2023-10-13 19:37:48 --> Output Class Initialized
INFO - 2023-10-13 19:37:48 --> Security Class Initialized
DEBUG - 2023-10-13 19:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:37:48 --> Input Class Initialized
INFO - 2023-10-13 19:37:48 --> Language Class Initialized
INFO - 2023-10-13 19:37:48 --> Loader Class Initialized
INFO - 2023-10-13 19:37:48 --> Helper loaded: url_helper
INFO - 2023-10-13 19:37:48 --> Helper loaded: form_helper
INFO - 2023-10-13 19:37:48 --> Helper loaded: file_helper
INFO - 2023-10-13 19:37:48 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:37:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:37:48 --> Form Validation Class Initialized
INFO - 2023-10-13 19:37:48 --> Upload Class Initialized
INFO - 2023-10-13 19:37:48 --> Model "M_auth" initialized
INFO - 2023-10-13 19:37:48 --> Model "M_user" initialized
INFO - 2023-10-13 19:37:48 --> Model "M_produk" initialized
INFO - 2023-10-13 19:37:48 --> Controller Class Initialized
INFO - 2023-10-13 19:37:48 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-10-13 19:37:48 --> Final output sent to browser
DEBUG - 2023-10-13 19:37:48 --> Total execution time: 0.0252
INFO - 2023-10-13 19:38:05 --> Config Class Initialized
INFO - 2023-10-13 19:38:05 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:38:05 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:38:05 --> Utf8 Class Initialized
INFO - 2023-10-13 19:38:05 --> URI Class Initialized
DEBUG - 2023-10-13 19:38:05 --> No URI present. Default controller set.
INFO - 2023-10-13 19:38:05 --> Router Class Initialized
INFO - 2023-10-13 19:38:05 --> Output Class Initialized
INFO - 2023-10-13 19:38:05 --> Security Class Initialized
DEBUG - 2023-10-13 19:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:38:05 --> Input Class Initialized
INFO - 2023-10-13 19:38:05 --> Language Class Initialized
INFO - 2023-10-13 19:38:05 --> Loader Class Initialized
INFO - 2023-10-13 19:38:05 --> Helper loaded: url_helper
INFO - 2023-10-13 19:38:05 --> Helper loaded: form_helper
INFO - 2023-10-13 19:38:05 --> Helper loaded: file_helper
INFO - 2023-10-13 19:38:05 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:38:05 --> Form Validation Class Initialized
INFO - 2023-10-13 19:38:05 --> Upload Class Initialized
INFO - 2023-10-13 19:38:05 --> Model "M_auth" initialized
INFO - 2023-10-13 19:38:05 --> Model "M_user" initialized
INFO - 2023-10-13 19:38:05 --> Model "M_produk" initialized
INFO - 2023-10-13 19:38:05 --> Controller Class Initialized
INFO - 2023-10-13 19:38:05 --> Model "M_pelanggan" initialized
INFO - 2023-10-13 19:38:05 --> Model "M_produk" initialized
DEBUG - 2023-10-13 19:38:05 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-13 19:38:05 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-13 19:38:05 --> Model "M_transaksi" initialized
INFO - 2023-10-13 19:38:05 --> Model "M_bank" initialized
INFO - 2023-10-13 19:38:05 --> Model "M_pesan" initialized
INFO - 2023-10-13 19:38:05 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-13 19:38:05 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-13 19:38:05 --> Final output sent to browser
DEBUG - 2023-10-13 19:38:05 --> Total execution time: 0.0446
INFO - 2023-10-13 19:40:46 --> Config Class Initialized
INFO - 2023-10-13 19:40:46 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:40:46 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:40:46 --> Utf8 Class Initialized
INFO - 2023-10-13 19:40:46 --> URI Class Initialized
INFO - 2023-10-13 19:40:46 --> Router Class Initialized
INFO - 2023-10-13 19:40:46 --> Output Class Initialized
INFO - 2023-10-13 19:40:46 --> Security Class Initialized
DEBUG - 2023-10-13 19:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:40:46 --> Input Class Initialized
INFO - 2023-10-13 19:40:46 --> Language Class Initialized
INFO - 2023-10-13 19:40:46 --> Loader Class Initialized
INFO - 2023-10-13 19:40:46 --> Helper loaded: url_helper
INFO - 2023-10-13 19:40:46 --> Helper loaded: form_helper
INFO - 2023-10-13 19:40:46 --> Helper loaded: file_helper
INFO - 2023-10-13 19:40:46 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:40:46 --> Form Validation Class Initialized
INFO - 2023-10-13 19:40:46 --> Upload Class Initialized
INFO - 2023-10-13 19:40:46 --> Model "M_auth" initialized
INFO - 2023-10-13 19:40:46 --> Model "M_user" initialized
INFO - 2023-10-13 19:40:46 --> Model "M_produk" initialized
INFO - 2023-10-13 19:40:46 --> Controller Class Initialized
INFO - 2023-10-13 19:40:46 --> Model "M_pelanggan" initialized
INFO - 2023-10-13 19:40:46 --> Model "M_produk" initialized
DEBUG - 2023-10-13 19:40:46 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-13 19:40:46 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-13 19:40:46 --> Model "M_transaksi" initialized
INFO - 2023-10-13 19:40:46 --> Model "M_bank" initialized
INFO - 2023-10-13 19:40:46 --> Model "M_pesan" initialized
INFO - 2023-10-13 19:40:46 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-13 19:40:46 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_edit_profile_pelanggan.php
INFO - 2023-10-13 19:40:46 --> Final output sent to browser
DEBUG - 2023-10-13 19:40:46 --> Total execution time: 0.0287
INFO - 2023-10-13 19:40:51 --> Config Class Initialized
INFO - 2023-10-13 19:40:51 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:40:51 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:40:51 --> Utf8 Class Initialized
INFO - 2023-10-13 19:40:51 --> URI Class Initialized
INFO - 2023-10-13 19:40:51 --> Router Class Initialized
INFO - 2023-10-13 19:40:51 --> Output Class Initialized
INFO - 2023-10-13 19:40:51 --> Security Class Initialized
DEBUG - 2023-10-13 19:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:40:51 --> Input Class Initialized
INFO - 2023-10-13 19:40:51 --> Language Class Initialized
INFO - 2023-10-13 19:40:51 --> Loader Class Initialized
INFO - 2023-10-13 19:40:51 --> Helper loaded: url_helper
INFO - 2023-10-13 19:40:51 --> Helper loaded: form_helper
INFO - 2023-10-13 19:40:51 --> Helper loaded: file_helper
INFO - 2023-10-13 19:40:51 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:40:51 --> Form Validation Class Initialized
INFO - 2023-10-13 19:40:51 --> Upload Class Initialized
INFO - 2023-10-13 19:40:51 --> Model "M_auth" initialized
INFO - 2023-10-13 19:40:51 --> Model "M_user" initialized
INFO - 2023-10-13 19:40:51 --> Model "M_produk" initialized
INFO - 2023-10-13 19:40:51 --> Controller Class Initialized
INFO - 2023-10-13 19:40:51 --> Model "M_pelanggan" initialized
INFO - 2023-10-13 19:40:51 --> Model "M_produk" initialized
DEBUG - 2023-10-13 19:40:51 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-13 19:40:51 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-13 19:40:51 --> Model "M_transaksi" initialized
INFO - 2023-10-13 19:40:51 --> Model "M_bank" initialized
INFO - 2023-10-13 19:40:51 --> Model "M_pesan" initialized
INFO - 2023-10-13 19:40:51 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-13 19:40:51 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-13 19:40:51 --> Final output sent to browser
DEBUG - 2023-10-13 19:40:51 --> Total execution time: 0.0283
INFO - 2023-10-13 19:40:55 --> Config Class Initialized
INFO - 2023-10-13 19:40:55 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:40:55 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:40:55 --> Utf8 Class Initialized
INFO - 2023-10-13 19:40:55 --> URI Class Initialized
INFO - 2023-10-13 19:40:55 --> Router Class Initialized
INFO - 2023-10-13 19:40:55 --> Output Class Initialized
INFO - 2023-10-13 19:40:55 --> Security Class Initialized
DEBUG - 2023-10-13 19:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:40:55 --> Input Class Initialized
INFO - 2023-10-13 19:40:55 --> Language Class Initialized
INFO - 2023-10-13 19:40:55 --> Loader Class Initialized
INFO - 2023-10-13 19:40:55 --> Helper loaded: url_helper
INFO - 2023-10-13 19:40:55 --> Helper loaded: form_helper
INFO - 2023-10-13 19:40:55 --> Helper loaded: file_helper
INFO - 2023-10-13 19:40:55 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:40:55 --> Form Validation Class Initialized
INFO - 2023-10-13 19:40:55 --> Upload Class Initialized
INFO - 2023-10-13 19:40:55 --> Model "M_auth" initialized
INFO - 2023-10-13 19:40:55 --> Model "M_user" initialized
INFO - 2023-10-13 19:40:55 --> Model "M_produk" initialized
INFO - 2023-10-13 19:40:55 --> Controller Class Initialized
INFO - 2023-10-13 19:40:55 --> Model "M_pelanggan" initialized
INFO - 2023-10-13 19:40:55 --> Model "M_produk" initialized
DEBUG - 2023-10-13 19:40:55 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-13 19:40:55 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-13 19:40:55 --> Model "M_transaksi" initialized
INFO - 2023-10-13 19:40:55 --> Model "M_bank" initialized
INFO - 2023-10-13 19:40:55 --> Model "M_pesan" initialized
INFO - 2023-10-13 19:40:55 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-13 19:40:55 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_bayar_sekarang.php
INFO - 2023-10-13 19:40:55 --> Final output sent to browser
DEBUG - 2023-10-13 19:40:55 --> Total execution time: 0.0310
INFO - 2023-10-13 19:40:55 --> Config Class Initialized
INFO - 2023-10-13 19:40:55 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:40:55 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:40:55 --> Utf8 Class Initialized
INFO - 2023-10-13 19:40:55 --> URI Class Initialized
INFO - 2023-10-13 19:40:55 --> Router Class Initialized
INFO - 2023-10-13 19:40:55 --> Output Class Initialized
INFO - 2023-10-13 19:40:55 --> Security Class Initialized
DEBUG - 2023-10-13 19:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:40:55 --> Input Class Initialized
INFO - 2023-10-13 19:40:55 --> Language Class Initialized
INFO - 2023-10-13 19:40:55 --> Loader Class Initialized
INFO - 2023-10-13 19:40:55 --> Helper loaded: url_helper
INFO - 2023-10-13 19:40:55 --> Helper loaded: form_helper
INFO - 2023-10-13 19:40:55 --> Helper loaded: file_helper
INFO - 2023-10-13 19:40:55 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:40:55 --> Form Validation Class Initialized
INFO - 2023-10-13 19:40:56 --> Upload Class Initialized
INFO - 2023-10-13 19:40:56 --> Model "M_auth" initialized
INFO - 2023-10-13 19:40:56 --> Model "M_user" initialized
INFO - 2023-10-13 19:40:56 --> Model "M_produk" initialized
INFO - 2023-10-13 19:40:56 --> Controller Class Initialized
INFO - 2023-10-13 19:40:56 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-10-13 19:40:56 --> Final output sent to browser
DEBUG - 2023-10-13 19:40:56 --> Total execution time: 0.0241
INFO - 2023-10-13 19:41:23 --> Config Class Initialized
INFO - 2023-10-13 19:41:23 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:41:23 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:41:23 --> Utf8 Class Initialized
INFO - 2023-10-13 19:41:23 --> URI Class Initialized
INFO - 2023-10-13 19:41:23 --> Router Class Initialized
INFO - 2023-10-13 19:41:23 --> Output Class Initialized
INFO - 2023-10-13 19:41:23 --> Security Class Initialized
DEBUG - 2023-10-13 19:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:41:23 --> Input Class Initialized
INFO - 2023-10-13 19:41:23 --> Language Class Initialized
INFO - 2023-10-13 19:41:23 --> Loader Class Initialized
INFO - 2023-10-13 19:41:23 --> Helper loaded: url_helper
INFO - 2023-10-13 19:41:23 --> Helper loaded: form_helper
INFO - 2023-10-13 19:41:23 --> Helper loaded: file_helper
INFO - 2023-10-13 19:41:23 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:41:23 --> Form Validation Class Initialized
INFO - 2023-10-13 19:41:23 --> Upload Class Initialized
INFO - 2023-10-13 19:41:23 --> Model "M_auth" initialized
INFO - 2023-10-13 19:41:23 --> Model "M_user" initialized
INFO - 2023-10-13 19:41:23 --> Model "M_produk" initialized
INFO - 2023-10-13 19:41:23 --> Controller Class Initialized
INFO - 2023-10-13 19:41:23 --> Model "M_pelanggan" initialized
INFO - 2023-10-13 19:41:23 --> Model "M_produk" initialized
DEBUG - 2023-10-13 19:41:23 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-13 19:41:23 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-13 19:41:23 --> Model "M_transaksi" initialized
INFO - 2023-10-13 19:41:23 --> Model "M_bank" initialized
INFO - 2023-10-13 19:41:23 --> Model "M_pesan" initialized
INFO - 2023-10-13 19:41:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-10-13 19:41:23 --> Image Lib Class Initialized
INFO - 2023-10-13 19:41:23 --> Config Class Initialized
INFO - 2023-10-13 19:41:23 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:41:23 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:41:23 --> Utf8 Class Initialized
INFO - 2023-10-13 19:41:23 --> URI Class Initialized
INFO - 2023-10-13 19:41:23 --> Router Class Initialized
INFO - 2023-10-13 19:41:23 --> Output Class Initialized
INFO - 2023-10-13 19:41:23 --> Security Class Initialized
DEBUG - 2023-10-13 19:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:41:23 --> Input Class Initialized
INFO - 2023-10-13 19:41:23 --> Language Class Initialized
INFO - 2023-10-13 19:41:23 --> Loader Class Initialized
INFO - 2023-10-13 19:41:23 --> Helper loaded: url_helper
INFO - 2023-10-13 19:41:23 --> Helper loaded: form_helper
INFO - 2023-10-13 19:41:23 --> Helper loaded: file_helper
INFO - 2023-10-13 19:41:23 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:41:23 --> Form Validation Class Initialized
INFO - 2023-10-13 19:41:23 --> Upload Class Initialized
INFO - 2023-10-13 19:41:23 --> Model "M_auth" initialized
INFO - 2023-10-13 19:41:23 --> Model "M_user" initialized
INFO - 2023-10-13 19:41:23 --> Model "M_produk" initialized
INFO - 2023-10-13 19:41:23 --> Controller Class Initialized
INFO - 2023-10-13 19:41:23 --> Model "M_pelanggan" initialized
INFO - 2023-10-13 19:41:23 --> Model "M_produk" initialized
DEBUG - 2023-10-13 19:41:23 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-13 19:41:23 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-13 19:41:23 --> Model "M_transaksi" initialized
INFO - 2023-10-13 19:41:23 --> Model "M_bank" initialized
INFO - 2023-10-13 19:41:23 --> Model "M_pesan" initialized
INFO - 2023-10-13 19:41:23 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-13 19:41:23 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-13 19:41:23 --> Final output sent to browser
DEBUG - 2023-10-13 19:41:23 --> Total execution time: 0.0270
INFO - 2023-10-13 19:41:32 --> Config Class Initialized
INFO - 2023-10-13 19:41:32 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:41:32 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:41:32 --> Utf8 Class Initialized
INFO - 2023-10-13 19:41:32 --> URI Class Initialized
INFO - 2023-10-13 19:41:32 --> Router Class Initialized
INFO - 2023-10-13 19:41:32 --> Output Class Initialized
INFO - 2023-10-13 19:41:32 --> Security Class Initialized
DEBUG - 2023-10-13 19:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:41:32 --> Input Class Initialized
INFO - 2023-10-13 19:41:32 --> Language Class Initialized
INFO - 2023-10-13 19:41:32 --> Loader Class Initialized
INFO - 2023-10-13 19:41:32 --> Helper loaded: url_helper
INFO - 2023-10-13 19:41:32 --> Helper loaded: form_helper
INFO - 2023-10-13 19:41:32 --> Helper loaded: file_helper
INFO - 2023-10-13 19:41:32 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:41:32 --> Form Validation Class Initialized
INFO - 2023-10-13 19:41:32 --> Upload Class Initialized
INFO - 2023-10-13 19:41:32 --> Model "M_auth" initialized
INFO - 2023-10-13 19:41:32 --> Model "M_user" initialized
INFO - 2023-10-13 19:41:32 --> Model "M_produk" initialized
INFO - 2023-10-13 19:41:32 --> Controller Class Initialized
INFO - 2023-10-13 19:41:32 --> Model "M_pelanggan" initialized
INFO - 2023-10-13 19:41:32 --> Model "M_produk" initialized
DEBUG - 2023-10-13 19:41:32 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-13 19:41:32 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-13 19:41:32 --> Model "M_transaksi" initialized
INFO - 2023-10-13 19:41:32 --> Model "M_bank" initialized
INFO - 2023-10-13 19:41:32 --> Model "M_pesan" initialized
INFO - 2023-10-13 19:41:32 --> Config Class Initialized
INFO - 2023-10-13 19:41:32 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:41:32 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:41:32 --> Utf8 Class Initialized
INFO - 2023-10-13 19:41:32 --> URI Class Initialized
DEBUG - 2023-10-13 19:41:32 --> No URI present. Default controller set.
INFO - 2023-10-13 19:41:32 --> Router Class Initialized
INFO - 2023-10-13 19:41:32 --> Output Class Initialized
INFO - 2023-10-13 19:41:32 --> Security Class Initialized
DEBUG - 2023-10-13 19:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:41:32 --> Input Class Initialized
INFO - 2023-10-13 19:41:32 --> Language Class Initialized
INFO - 2023-10-13 19:41:32 --> Loader Class Initialized
INFO - 2023-10-13 19:41:32 --> Helper loaded: url_helper
INFO - 2023-10-13 19:41:32 --> Helper loaded: form_helper
INFO - 2023-10-13 19:41:32 --> Helper loaded: file_helper
INFO - 2023-10-13 19:41:32 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:41:32 --> Form Validation Class Initialized
INFO - 2023-10-13 19:41:32 --> Upload Class Initialized
INFO - 2023-10-13 19:41:32 --> Model "M_auth" initialized
INFO - 2023-10-13 19:41:32 --> Model "M_user" initialized
INFO - 2023-10-13 19:41:32 --> Model "M_produk" initialized
INFO - 2023-10-13 19:41:32 --> Controller Class Initialized
INFO - 2023-10-13 19:41:32 --> Model "M_pelanggan" initialized
INFO - 2023-10-13 19:41:32 --> Model "M_produk" initialized
DEBUG - 2023-10-13 19:41:32 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-13 19:41:32 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-13 19:41:32 --> Model "M_transaksi" initialized
INFO - 2023-10-13 19:41:32 --> Model "M_bank" initialized
INFO - 2023-10-13 19:41:32 --> Model "M_pesan" initialized
INFO - 2023-10-13 19:41:32 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-13 19:41:32 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-13 19:41:32 --> Final output sent to browser
DEBUG - 2023-10-13 19:41:32 --> Total execution time: 0.0286
INFO - 2023-10-13 19:41:35 --> Config Class Initialized
INFO - 2023-10-13 19:41:35 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:41:35 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:41:35 --> Utf8 Class Initialized
INFO - 2023-10-13 19:41:35 --> URI Class Initialized
INFO - 2023-10-13 19:41:35 --> Router Class Initialized
INFO - 2023-10-13 19:41:35 --> Output Class Initialized
INFO - 2023-10-13 19:41:35 --> Security Class Initialized
DEBUG - 2023-10-13 19:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:41:35 --> Input Class Initialized
INFO - 2023-10-13 19:41:35 --> Language Class Initialized
INFO - 2023-10-13 19:41:35 --> Loader Class Initialized
INFO - 2023-10-13 19:41:35 --> Helper loaded: url_helper
INFO - 2023-10-13 19:41:35 --> Helper loaded: form_helper
INFO - 2023-10-13 19:41:35 --> Helper loaded: file_helper
INFO - 2023-10-13 19:41:35 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:41:35 --> Form Validation Class Initialized
INFO - 2023-10-13 19:41:35 --> Upload Class Initialized
INFO - 2023-10-13 19:41:35 --> Model "M_auth" initialized
INFO - 2023-10-13 19:41:35 --> Model "M_user" initialized
INFO - 2023-10-13 19:41:35 --> Model "M_produk" initialized
INFO - 2023-10-13 19:41:35 --> Controller Class Initialized
INFO - 2023-10-13 19:41:35 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-10-13 19:41:35 --> Final output sent to browser
DEBUG - 2023-10-13 19:41:35 --> Total execution time: 0.0378
INFO - 2023-10-13 19:41:42 --> Config Class Initialized
INFO - 2023-10-13 19:41:42 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:41:42 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:41:42 --> Utf8 Class Initialized
INFO - 2023-10-13 19:41:42 --> URI Class Initialized
INFO - 2023-10-13 19:41:42 --> Router Class Initialized
INFO - 2023-10-13 19:41:42 --> Output Class Initialized
INFO - 2023-10-13 19:41:42 --> Security Class Initialized
DEBUG - 2023-10-13 19:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:41:42 --> Input Class Initialized
INFO - 2023-10-13 19:41:42 --> Language Class Initialized
INFO - 2023-10-13 19:41:42 --> Loader Class Initialized
INFO - 2023-10-13 19:41:42 --> Helper loaded: url_helper
INFO - 2023-10-13 19:41:42 --> Helper loaded: form_helper
INFO - 2023-10-13 19:41:42 --> Helper loaded: file_helper
INFO - 2023-10-13 19:41:42 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:41:42 --> Form Validation Class Initialized
INFO - 2023-10-13 19:41:42 --> Upload Class Initialized
INFO - 2023-10-13 19:41:42 --> Model "M_auth" initialized
INFO - 2023-10-13 19:41:42 --> Model "M_user" initialized
INFO - 2023-10-13 19:41:42 --> Model "M_produk" initialized
INFO - 2023-10-13 19:41:42 --> Controller Class Initialized
INFO - 2023-10-13 19:41:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-10-13 19:41:42 --> Config Class Initialized
INFO - 2023-10-13 19:41:42 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:41:42 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:41:42 --> Utf8 Class Initialized
INFO - 2023-10-13 19:41:42 --> URI Class Initialized
INFO - 2023-10-13 19:41:42 --> Router Class Initialized
INFO - 2023-10-13 19:41:42 --> Output Class Initialized
INFO - 2023-10-13 19:41:42 --> Security Class Initialized
DEBUG - 2023-10-13 19:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:41:42 --> Input Class Initialized
INFO - 2023-10-13 19:41:42 --> Language Class Initialized
INFO - 2023-10-13 19:41:42 --> Loader Class Initialized
INFO - 2023-10-13 19:41:42 --> Helper loaded: url_helper
INFO - 2023-10-13 19:41:42 --> Helper loaded: form_helper
INFO - 2023-10-13 19:41:42 --> Helper loaded: file_helper
INFO - 2023-10-13 19:41:42 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:41:42 --> Form Validation Class Initialized
INFO - 2023-10-13 19:41:42 --> Upload Class Initialized
INFO - 2023-10-13 19:41:42 --> Model "M_auth" initialized
INFO - 2023-10-13 19:41:42 --> Model "M_user" initialized
INFO - 2023-10-13 19:41:42 --> Model "M_produk" initialized
INFO - 2023-10-13 19:41:42 --> Controller Class Initialized
INFO - 2023-10-13 19:41:42 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-10-13 19:41:42 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-13 19:41:42 --> Final output sent to browser
DEBUG - 2023-10-13 19:41:42 --> Total execution time: 0.0249
INFO - 2023-10-13 19:41:46 --> Config Class Initialized
INFO - 2023-10-13 19:41:46 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:41:46 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:41:46 --> Utf8 Class Initialized
INFO - 2023-10-13 19:41:46 --> URI Class Initialized
INFO - 2023-10-13 19:41:46 --> Router Class Initialized
INFO - 2023-10-13 19:41:46 --> Output Class Initialized
INFO - 2023-10-13 19:41:46 --> Security Class Initialized
DEBUG - 2023-10-13 19:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:41:46 --> Input Class Initialized
INFO - 2023-10-13 19:41:46 --> Language Class Initialized
INFO - 2023-10-13 19:41:46 --> Loader Class Initialized
INFO - 2023-10-13 19:41:46 --> Helper loaded: url_helper
INFO - 2023-10-13 19:41:46 --> Helper loaded: form_helper
INFO - 2023-10-13 19:41:46 --> Helper loaded: file_helper
INFO - 2023-10-13 19:41:46 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:41:46 --> Form Validation Class Initialized
INFO - 2023-10-13 19:41:46 --> Upload Class Initialized
INFO - 2023-10-13 19:41:46 --> Model "M_auth" initialized
INFO - 2023-10-13 19:41:46 --> Model "M_user" initialized
INFO - 2023-10-13 19:41:46 --> Model "M_produk" initialized
INFO - 2023-10-13 19:41:46 --> Controller Class Initialized
INFO - 2023-10-13 19:41:46 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_user_profile.php
INFO - 2023-10-13 19:41:46 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-13 19:41:46 --> Final output sent to browser
DEBUG - 2023-10-13 19:41:46 --> Total execution time: 0.0264
INFO - 2023-10-13 19:41:48 --> Config Class Initialized
INFO - 2023-10-13 19:41:48 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:41:48 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:41:48 --> Utf8 Class Initialized
INFO - 2023-10-13 19:41:48 --> URI Class Initialized
INFO - 2023-10-13 19:41:48 --> Router Class Initialized
INFO - 2023-10-13 19:41:48 --> Output Class Initialized
INFO - 2023-10-13 19:41:48 --> Security Class Initialized
DEBUG - 2023-10-13 19:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:41:48 --> Input Class Initialized
INFO - 2023-10-13 19:41:48 --> Language Class Initialized
INFO - 2023-10-13 19:41:48 --> Loader Class Initialized
INFO - 2023-10-13 19:41:48 --> Helper loaded: url_helper
INFO - 2023-10-13 19:41:48 --> Helper loaded: form_helper
INFO - 2023-10-13 19:41:48 --> Helper loaded: file_helper
INFO - 2023-10-13 19:41:48 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:41:48 --> Form Validation Class Initialized
INFO - 2023-10-13 19:41:48 --> Upload Class Initialized
INFO - 2023-10-13 19:41:48 --> Model "M_auth" initialized
INFO - 2023-10-13 19:41:48 --> Model "M_user" initialized
INFO - 2023-10-13 19:41:48 --> Model "M_produk" initialized
INFO - 2023-10-13 19:41:48 --> Controller Class Initialized
INFO - 2023-10-13 19:41:48 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_user_profile.php
INFO - 2023-10-13 19:41:48 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-13 19:41:48 --> Final output sent to browser
DEBUG - 2023-10-13 19:41:48 --> Total execution time: 0.0509
INFO - 2023-10-13 19:41:50 --> Config Class Initialized
INFO - 2023-10-13 19:41:50 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:41:50 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:41:50 --> Utf8 Class Initialized
INFO - 2023-10-13 19:41:50 --> URI Class Initialized
INFO - 2023-10-13 19:41:50 --> Router Class Initialized
INFO - 2023-10-13 19:41:50 --> Output Class Initialized
INFO - 2023-10-13 19:41:50 --> Security Class Initialized
DEBUG - 2023-10-13 19:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:41:50 --> Input Class Initialized
INFO - 2023-10-13 19:41:50 --> Language Class Initialized
INFO - 2023-10-13 19:41:50 --> Loader Class Initialized
INFO - 2023-10-13 19:41:50 --> Helper loaded: url_helper
INFO - 2023-10-13 19:41:50 --> Helper loaded: form_helper
INFO - 2023-10-13 19:41:50 --> Helper loaded: file_helper
INFO - 2023-10-13 19:41:50 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:41:50 --> Form Validation Class Initialized
INFO - 2023-10-13 19:41:50 --> Upload Class Initialized
INFO - 2023-10-13 19:41:50 --> Model "M_auth" initialized
INFO - 2023-10-13 19:41:50 --> Model "M_user" initialized
INFO - 2023-10-13 19:41:50 --> Model "M_produk" initialized
INFO - 2023-10-13 19:41:50 --> Controller Class Initialized
INFO - 2023-10-13 19:41:50 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_ganti_password.php
INFO - 2023-10-13 19:41:50 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-13 19:41:50 --> Final output sent to browser
DEBUG - 2023-10-13 19:41:50 --> Total execution time: 0.0260
INFO - 2023-10-13 19:41:53 --> Config Class Initialized
INFO - 2023-10-13 19:41:53 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:41:53 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:41:53 --> Utf8 Class Initialized
INFO - 2023-10-13 19:41:53 --> URI Class Initialized
INFO - 2023-10-13 19:41:53 --> Router Class Initialized
INFO - 2023-10-13 19:41:53 --> Output Class Initialized
INFO - 2023-10-13 19:41:53 --> Security Class Initialized
DEBUG - 2023-10-13 19:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:41:53 --> Input Class Initialized
INFO - 2023-10-13 19:41:53 --> Language Class Initialized
INFO - 2023-10-13 19:41:53 --> Loader Class Initialized
INFO - 2023-10-13 19:41:53 --> Helper loaded: url_helper
INFO - 2023-10-13 19:41:53 --> Helper loaded: form_helper
INFO - 2023-10-13 19:41:53 --> Helper loaded: file_helper
INFO - 2023-10-13 19:41:53 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:41:53 --> Form Validation Class Initialized
INFO - 2023-10-13 19:41:53 --> Upload Class Initialized
INFO - 2023-10-13 19:41:53 --> Model "M_auth" initialized
INFO - 2023-10-13 19:41:53 --> Model "M_user" initialized
INFO - 2023-10-13 19:41:53 --> Model "M_produk" initialized
INFO - 2023-10-13 19:41:53 --> Controller Class Initialized
INFO - 2023-10-13 19:41:53 --> Model "M_pelanggan" initialized
INFO - 2023-10-13 19:41:53 --> Model "M_produk" initialized
DEBUG - 2023-10-13 19:41:53 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-13 19:41:53 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-13 19:41:53 --> Model "M_transaksi" initialized
INFO - 2023-10-13 19:41:53 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_transaksi_all.php
INFO - 2023-10-13 19:41:53 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-13 19:41:53 --> Final output sent to browser
DEBUG - 2023-10-13 19:41:53 --> Total execution time: 0.0383
INFO - 2023-10-13 19:42:14 --> Config Class Initialized
INFO - 2023-10-13 19:42:14 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:42:14 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:42:14 --> Utf8 Class Initialized
INFO - 2023-10-13 19:42:14 --> URI Class Initialized
INFO - 2023-10-13 19:42:14 --> Router Class Initialized
INFO - 2023-10-13 19:42:14 --> Output Class Initialized
INFO - 2023-10-13 19:42:14 --> Security Class Initialized
DEBUG - 2023-10-13 19:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:42:14 --> Input Class Initialized
INFO - 2023-10-13 19:42:14 --> Language Class Initialized
INFO - 2023-10-13 19:42:14 --> Loader Class Initialized
INFO - 2023-10-13 19:42:14 --> Helper loaded: url_helper
INFO - 2023-10-13 19:42:14 --> Helper loaded: form_helper
INFO - 2023-10-13 19:42:14 --> Helper loaded: file_helper
INFO - 2023-10-13 19:42:14 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:42:14 --> Form Validation Class Initialized
INFO - 2023-10-13 19:42:14 --> Upload Class Initialized
INFO - 2023-10-13 19:42:14 --> Model "M_auth" initialized
INFO - 2023-10-13 19:42:14 --> Model "M_user" initialized
INFO - 2023-10-13 19:42:14 --> Model "M_produk" initialized
INFO - 2023-10-13 19:42:14 --> Controller Class Initialized
INFO - 2023-10-13 19:42:14 --> Model "M_pelanggan" initialized
INFO - 2023-10-13 19:42:14 --> Model "M_produk" initialized
DEBUG - 2023-10-13 19:42:14 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-13 19:42:14 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-13 19:42:14 --> Model "M_transaksi" initialized
INFO - 2023-10-13 19:42:14 --> Config Class Initialized
INFO - 2023-10-13 19:42:14 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:42:14 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:42:14 --> Utf8 Class Initialized
INFO - 2023-10-13 19:42:14 --> URI Class Initialized
INFO - 2023-10-13 19:42:14 --> Router Class Initialized
INFO - 2023-10-13 19:42:14 --> Output Class Initialized
INFO - 2023-10-13 19:42:14 --> Security Class Initialized
DEBUG - 2023-10-13 19:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:42:14 --> Input Class Initialized
INFO - 2023-10-13 19:42:14 --> Language Class Initialized
INFO - 2023-10-13 19:42:14 --> Loader Class Initialized
INFO - 2023-10-13 19:42:14 --> Helper loaded: url_helper
INFO - 2023-10-13 19:42:14 --> Helper loaded: form_helper
INFO - 2023-10-13 19:42:14 --> Helper loaded: file_helper
INFO - 2023-10-13 19:42:14 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:42:15 --> Form Validation Class Initialized
INFO - 2023-10-13 19:42:15 --> Upload Class Initialized
INFO - 2023-10-13 19:42:15 --> Model "M_auth" initialized
INFO - 2023-10-13 19:42:15 --> Model "M_user" initialized
INFO - 2023-10-13 19:42:15 --> Model "M_produk" initialized
INFO - 2023-10-13 19:42:15 --> Controller Class Initialized
INFO - 2023-10-13 19:42:15 --> Model "M_pelanggan" initialized
INFO - 2023-10-13 19:42:15 --> Model "M_produk" initialized
DEBUG - 2023-10-13 19:42:15 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-13 19:42:15 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-13 19:42:15 --> Model "M_transaksi" initialized
INFO - 2023-10-13 19:42:15 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_transaksi_all.php
INFO - 2023-10-13 19:42:15 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-13 19:42:15 --> Final output sent to browser
DEBUG - 2023-10-13 19:42:15 --> Total execution time: 0.0263
INFO - 2023-10-13 19:42:21 --> Config Class Initialized
INFO - 2023-10-13 19:42:21 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:42:21 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:42:21 --> Utf8 Class Initialized
INFO - 2023-10-13 19:42:21 --> URI Class Initialized
INFO - 2023-10-13 19:42:21 --> Router Class Initialized
INFO - 2023-10-13 19:42:21 --> Output Class Initialized
INFO - 2023-10-13 19:42:21 --> Security Class Initialized
DEBUG - 2023-10-13 19:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:42:21 --> Input Class Initialized
INFO - 2023-10-13 19:42:21 --> Language Class Initialized
INFO - 2023-10-13 19:42:21 --> Loader Class Initialized
INFO - 2023-10-13 19:42:21 --> Helper loaded: url_helper
INFO - 2023-10-13 19:42:21 --> Helper loaded: form_helper
INFO - 2023-10-13 19:42:21 --> Helper loaded: file_helper
INFO - 2023-10-13 19:42:21 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:42:21 --> Form Validation Class Initialized
INFO - 2023-10-13 19:42:21 --> Upload Class Initialized
INFO - 2023-10-13 19:42:21 --> Model "M_auth" initialized
INFO - 2023-10-13 19:42:21 --> Model "M_user" initialized
INFO - 2023-10-13 19:42:21 --> Model "M_produk" initialized
INFO - 2023-10-13 19:42:21 --> Controller Class Initialized
INFO - 2023-10-13 19:42:21 --> Config Class Initialized
INFO - 2023-10-13 19:42:21 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:42:21 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:42:21 --> Utf8 Class Initialized
INFO - 2023-10-13 19:42:21 --> URI Class Initialized
INFO - 2023-10-13 19:42:21 --> Router Class Initialized
INFO - 2023-10-13 19:42:21 --> Output Class Initialized
INFO - 2023-10-13 19:42:21 --> Security Class Initialized
DEBUG - 2023-10-13 19:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:42:21 --> Input Class Initialized
INFO - 2023-10-13 19:42:21 --> Language Class Initialized
INFO - 2023-10-13 19:42:21 --> Loader Class Initialized
INFO - 2023-10-13 19:42:21 --> Helper loaded: url_helper
INFO - 2023-10-13 19:42:21 --> Helper loaded: form_helper
INFO - 2023-10-13 19:42:21 --> Helper loaded: file_helper
INFO - 2023-10-13 19:42:21 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:42:21 --> Form Validation Class Initialized
INFO - 2023-10-13 19:42:21 --> Upload Class Initialized
INFO - 2023-10-13 19:42:21 --> Model "M_auth" initialized
INFO - 2023-10-13 19:42:21 --> Model "M_user" initialized
INFO - 2023-10-13 19:42:21 --> Model "M_produk" initialized
INFO - 2023-10-13 19:42:21 --> Controller Class Initialized
INFO - 2023-10-13 19:42:21 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-10-13 19:42:21 --> Final output sent to browser
DEBUG - 2023-10-13 19:42:21 --> Total execution time: 0.0264
INFO - 2023-10-13 19:42:25 --> Config Class Initialized
INFO - 2023-10-13 19:42:25 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:42:25 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:42:25 --> Utf8 Class Initialized
INFO - 2023-10-13 19:42:25 --> URI Class Initialized
DEBUG - 2023-10-13 19:42:25 --> No URI present. Default controller set.
INFO - 2023-10-13 19:42:25 --> Router Class Initialized
INFO - 2023-10-13 19:42:25 --> Output Class Initialized
INFO - 2023-10-13 19:42:25 --> Security Class Initialized
DEBUG - 2023-10-13 19:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:42:25 --> Input Class Initialized
INFO - 2023-10-13 19:42:25 --> Language Class Initialized
INFO - 2023-10-13 19:42:25 --> Loader Class Initialized
INFO - 2023-10-13 19:42:25 --> Helper loaded: url_helper
INFO - 2023-10-13 19:42:25 --> Helper loaded: form_helper
INFO - 2023-10-13 19:42:25 --> Helper loaded: file_helper
INFO - 2023-10-13 19:42:25 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:42:25 --> Form Validation Class Initialized
INFO - 2023-10-13 19:42:25 --> Upload Class Initialized
INFO - 2023-10-13 19:42:25 --> Model "M_auth" initialized
INFO - 2023-10-13 19:42:25 --> Model "M_user" initialized
INFO - 2023-10-13 19:42:25 --> Model "M_produk" initialized
INFO - 2023-10-13 19:42:25 --> Controller Class Initialized
INFO - 2023-10-13 19:42:25 --> Model "M_pelanggan" initialized
INFO - 2023-10-13 19:42:25 --> Model "M_produk" initialized
DEBUG - 2023-10-13 19:42:25 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-13 19:42:25 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-13 19:42:25 --> Model "M_transaksi" initialized
INFO - 2023-10-13 19:42:25 --> Model "M_bank" initialized
INFO - 2023-10-13 19:42:25 --> Model "M_pesan" initialized
INFO - 2023-10-13 19:42:25 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-13 19:42:25 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-13 19:42:25 --> Final output sent to browser
DEBUG - 2023-10-13 19:42:25 --> Total execution time: 0.0428
INFO - 2023-10-13 19:42:32 --> Config Class Initialized
INFO - 2023-10-13 19:42:32 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:42:32 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:42:32 --> Utf8 Class Initialized
INFO - 2023-10-13 19:42:32 --> URI Class Initialized
DEBUG - 2023-10-13 19:42:32 --> No URI present. Default controller set.
INFO - 2023-10-13 19:42:32 --> Router Class Initialized
INFO - 2023-10-13 19:42:32 --> Output Class Initialized
INFO - 2023-10-13 19:42:32 --> Security Class Initialized
DEBUG - 2023-10-13 19:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:42:32 --> Input Class Initialized
INFO - 2023-10-13 19:42:32 --> Language Class Initialized
INFO - 2023-10-13 19:42:32 --> Loader Class Initialized
INFO - 2023-10-13 19:42:32 --> Helper loaded: url_helper
INFO - 2023-10-13 19:42:32 --> Helper loaded: form_helper
INFO - 2023-10-13 19:42:32 --> Helper loaded: file_helper
INFO - 2023-10-13 19:42:32 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:42:32 --> Form Validation Class Initialized
INFO - 2023-10-13 19:42:32 --> Upload Class Initialized
INFO - 2023-10-13 19:42:32 --> Model "M_auth" initialized
INFO - 2023-10-13 19:42:32 --> Model "M_user" initialized
INFO - 2023-10-13 19:42:32 --> Model "M_produk" initialized
INFO - 2023-10-13 19:42:32 --> Controller Class Initialized
INFO - 2023-10-13 19:42:32 --> Model "M_pelanggan" initialized
INFO - 2023-10-13 19:42:32 --> Model "M_produk" initialized
DEBUG - 2023-10-13 19:42:32 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-13 19:42:32 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-13 19:42:32 --> Model "M_transaksi" initialized
INFO - 2023-10-13 19:42:32 --> Model "M_bank" initialized
INFO - 2023-10-13 19:42:32 --> Model "M_pesan" initialized
INFO - 2023-10-13 19:42:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-10-13 19:42:32 --> Email Class Initialized
INFO - 2023-10-13 19:42:33 --> Language file loaded: language/english/email_lang.php
INFO - 2023-10-13 19:42:35 --> Config Class Initialized
INFO - 2023-10-13 19:42:35 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:42:35 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:42:35 --> Utf8 Class Initialized
INFO - 2023-10-13 19:42:35 --> URI Class Initialized
DEBUG - 2023-10-13 19:42:35 --> No URI present. Default controller set.
INFO - 2023-10-13 19:42:35 --> Router Class Initialized
INFO - 2023-10-13 19:42:36 --> Output Class Initialized
INFO - 2023-10-13 19:42:36 --> Security Class Initialized
DEBUG - 2023-10-13 19:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:42:36 --> Input Class Initialized
INFO - 2023-10-13 19:42:36 --> Language Class Initialized
INFO - 2023-10-13 19:42:36 --> Loader Class Initialized
INFO - 2023-10-13 19:42:36 --> Helper loaded: url_helper
INFO - 2023-10-13 19:42:36 --> Helper loaded: form_helper
INFO - 2023-10-13 19:42:36 --> Helper loaded: file_helper
INFO - 2023-10-13 19:42:36 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:42:36 --> Form Validation Class Initialized
INFO - 2023-10-13 19:42:36 --> Upload Class Initialized
INFO - 2023-10-13 19:42:36 --> Model "M_auth" initialized
INFO - 2023-10-13 19:42:36 --> Model "M_user" initialized
INFO - 2023-10-13 19:42:36 --> Model "M_produk" initialized
INFO - 2023-10-13 19:42:36 --> Controller Class Initialized
INFO - 2023-10-13 19:42:36 --> Model "M_pelanggan" initialized
INFO - 2023-10-13 19:42:36 --> Model "M_produk" initialized
DEBUG - 2023-10-13 19:42:36 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-13 19:42:36 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-13 19:42:36 --> Model "M_transaksi" initialized
INFO - 2023-10-13 19:42:36 --> Model "M_bank" initialized
INFO - 2023-10-13 19:42:36 --> Model "M_pesan" initialized
INFO - 2023-10-13 19:42:36 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-13 19:42:36 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-13 19:42:36 --> Final output sent to browser
DEBUG - 2023-10-13 19:42:36 --> Total execution time: 0.0333
INFO - 2023-10-13 19:42:39 --> Config Class Initialized
INFO - 2023-10-13 19:42:39 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:42:39 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:42:39 --> Utf8 Class Initialized
INFO - 2023-10-13 19:42:39 --> URI Class Initialized
INFO - 2023-10-13 19:42:39 --> Router Class Initialized
INFO - 2023-10-13 19:42:39 --> Output Class Initialized
INFO - 2023-10-13 19:42:39 --> Security Class Initialized
DEBUG - 2023-10-13 19:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:42:39 --> Input Class Initialized
INFO - 2023-10-13 19:42:39 --> Language Class Initialized
INFO - 2023-10-13 19:42:39 --> Loader Class Initialized
INFO - 2023-10-13 19:42:39 --> Helper loaded: url_helper
INFO - 2023-10-13 19:42:39 --> Helper loaded: form_helper
INFO - 2023-10-13 19:42:39 --> Helper loaded: file_helper
INFO - 2023-10-13 19:42:39 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:42:39 --> Form Validation Class Initialized
INFO - 2023-10-13 19:42:39 --> Upload Class Initialized
INFO - 2023-10-13 19:42:39 --> Model "M_auth" initialized
INFO - 2023-10-13 19:42:39 --> Model "M_user" initialized
INFO - 2023-10-13 19:42:39 --> Model "M_produk" initialized
INFO - 2023-10-13 19:42:39 --> Controller Class Initialized
INFO - 2023-10-13 19:42:39 --> Model "M_pelanggan" initialized
INFO - 2023-10-13 19:42:39 --> Model "M_produk" initialized
DEBUG - 2023-10-13 19:42:39 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-13 19:42:39 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-13 19:42:39 --> Model "M_transaksi" initialized
INFO - 2023-10-13 19:42:39 --> Model "M_bank" initialized
INFO - 2023-10-13 19:42:39 --> Model "M_pesan" initialized
INFO - 2023-10-13 19:42:39 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-13 19:42:39 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-13 19:42:39 --> Final output sent to browser
DEBUG - 2023-10-13 19:42:39 --> Total execution time: 0.0296
INFO - 2023-10-13 19:43:28 --> Config Class Initialized
INFO - 2023-10-13 19:43:28 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:43:28 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:43:28 --> Utf8 Class Initialized
INFO - 2023-10-13 19:43:28 --> URI Class Initialized
INFO - 2023-10-13 19:43:28 --> Router Class Initialized
INFO - 2023-10-13 19:43:28 --> Output Class Initialized
INFO - 2023-10-13 19:43:28 --> Security Class Initialized
DEBUG - 2023-10-13 19:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:43:28 --> Input Class Initialized
INFO - 2023-10-13 19:43:28 --> Language Class Initialized
INFO - 2023-10-13 19:43:28 --> Loader Class Initialized
INFO - 2023-10-13 19:43:28 --> Helper loaded: url_helper
INFO - 2023-10-13 19:43:28 --> Helper loaded: form_helper
INFO - 2023-10-13 19:43:28 --> Helper loaded: file_helper
INFO - 2023-10-13 19:43:28 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:43:28 --> Form Validation Class Initialized
INFO - 2023-10-13 19:43:28 --> Upload Class Initialized
INFO - 2023-10-13 19:43:28 --> Model "M_auth" initialized
INFO - 2023-10-13 19:43:28 --> Model "M_user" initialized
INFO - 2023-10-13 19:43:28 --> Model "M_produk" initialized
INFO - 2023-10-13 19:43:28 --> Controller Class Initialized
INFO - 2023-10-13 19:43:28 --> Model "M_pelanggan" initialized
INFO - 2023-10-13 19:43:28 --> Model "M_produk" initialized
DEBUG - 2023-10-13 19:43:28 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-13 19:43:28 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-13 19:43:28 --> Model "M_transaksi" initialized
INFO - 2023-10-13 19:43:28 --> Model "M_bank" initialized
INFO - 2023-10-13 19:43:28 --> Model "M_pesan" initialized
INFO - 2023-10-13 19:43:28 --> Config Class Initialized
INFO - 2023-10-13 19:43:28 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:43:28 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:43:28 --> Utf8 Class Initialized
INFO - 2023-10-13 19:43:28 --> URI Class Initialized
DEBUG - 2023-10-13 19:43:28 --> No URI present. Default controller set.
INFO - 2023-10-13 19:43:28 --> Router Class Initialized
INFO - 2023-10-13 19:43:28 --> Output Class Initialized
INFO - 2023-10-13 19:43:28 --> Security Class Initialized
DEBUG - 2023-10-13 19:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:43:28 --> Input Class Initialized
INFO - 2023-10-13 19:43:28 --> Language Class Initialized
INFO - 2023-10-13 19:43:28 --> Loader Class Initialized
INFO - 2023-10-13 19:43:28 --> Helper loaded: url_helper
INFO - 2023-10-13 19:43:28 --> Helper loaded: form_helper
INFO - 2023-10-13 19:43:28 --> Helper loaded: file_helper
INFO - 2023-10-13 19:43:28 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:43:28 --> Form Validation Class Initialized
INFO - 2023-10-13 19:43:28 --> Upload Class Initialized
INFO - 2023-10-13 19:43:28 --> Model "M_auth" initialized
INFO - 2023-10-13 19:43:28 --> Model "M_user" initialized
INFO - 2023-10-13 19:43:28 --> Model "M_produk" initialized
INFO - 2023-10-13 19:43:28 --> Controller Class Initialized
INFO - 2023-10-13 19:43:28 --> Model "M_pelanggan" initialized
INFO - 2023-10-13 19:43:28 --> Model "M_produk" initialized
DEBUG - 2023-10-13 19:43:28 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-13 19:43:28 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-13 19:43:28 --> Model "M_transaksi" initialized
INFO - 2023-10-13 19:43:28 --> Model "M_bank" initialized
INFO - 2023-10-13 19:43:28 --> Model "M_pesan" initialized
INFO - 2023-10-13 19:43:28 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-13 19:43:28 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-13 19:43:28 --> Final output sent to browser
DEBUG - 2023-10-13 19:43:28 --> Total execution time: 0.0258
INFO - 2023-10-13 19:43:31 --> Config Class Initialized
INFO - 2023-10-13 19:43:31 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:43:31 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:43:31 --> Utf8 Class Initialized
INFO - 2023-10-13 19:43:31 --> URI Class Initialized
INFO - 2023-10-13 19:43:31 --> Router Class Initialized
INFO - 2023-10-13 19:43:31 --> Output Class Initialized
INFO - 2023-10-13 19:43:31 --> Security Class Initialized
DEBUG - 2023-10-13 19:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:43:31 --> Input Class Initialized
INFO - 2023-10-13 19:43:31 --> Language Class Initialized
INFO - 2023-10-13 19:43:31 --> Loader Class Initialized
INFO - 2023-10-13 19:43:31 --> Helper loaded: url_helper
INFO - 2023-10-13 19:43:31 --> Helper loaded: form_helper
INFO - 2023-10-13 19:43:31 --> Helper loaded: file_helper
INFO - 2023-10-13 19:43:31 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:43:31 --> Form Validation Class Initialized
INFO - 2023-10-13 19:43:31 --> Upload Class Initialized
INFO - 2023-10-13 19:43:31 --> Model "M_auth" initialized
INFO - 2023-10-13 19:43:31 --> Model "M_user" initialized
INFO - 2023-10-13 19:43:31 --> Model "M_produk" initialized
INFO - 2023-10-13 19:43:31 --> Controller Class Initialized
INFO - 2023-10-13 19:43:31 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-10-13 19:43:31 --> Final output sent to browser
DEBUG - 2023-10-13 19:43:31 --> Total execution time: 0.0228
INFO - 2023-10-13 19:43:40 --> Config Class Initialized
INFO - 2023-10-13 19:43:40 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:43:40 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:43:40 --> Utf8 Class Initialized
INFO - 2023-10-13 19:43:40 --> URI Class Initialized
INFO - 2023-10-13 19:43:40 --> Router Class Initialized
INFO - 2023-10-13 19:43:40 --> Output Class Initialized
INFO - 2023-10-13 19:43:40 --> Security Class Initialized
DEBUG - 2023-10-13 19:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:43:40 --> Input Class Initialized
INFO - 2023-10-13 19:43:40 --> Language Class Initialized
INFO - 2023-10-13 19:43:40 --> Loader Class Initialized
INFO - 2023-10-13 19:43:40 --> Helper loaded: url_helper
INFO - 2023-10-13 19:43:40 --> Helper loaded: form_helper
INFO - 2023-10-13 19:43:40 --> Helper loaded: file_helper
INFO - 2023-10-13 19:43:40 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:43:40 --> Form Validation Class Initialized
INFO - 2023-10-13 19:43:40 --> Upload Class Initialized
INFO - 2023-10-13 19:43:40 --> Model "M_auth" initialized
INFO - 2023-10-13 19:43:40 --> Model "M_user" initialized
INFO - 2023-10-13 19:43:40 --> Model "M_produk" initialized
INFO - 2023-10-13 19:43:40 --> Controller Class Initialized
INFO - 2023-10-13 19:43:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-10-13 19:43:40 --> Config Class Initialized
INFO - 2023-10-13 19:43:40 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:43:40 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:43:40 --> Utf8 Class Initialized
INFO - 2023-10-13 19:43:40 --> URI Class Initialized
INFO - 2023-10-13 19:43:40 --> Router Class Initialized
INFO - 2023-10-13 19:43:40 --> Output Class Initialized
INFO - 2023-10-13 19:43:40 --> Security Class Initialized
DEBUG - 2023-10-13 19:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:43:40 --> Input Class Initialized
INFO - 2023-10-13 19:43:40 --> Language Class Initialized
INFO - 2023-10-13 19:43:40 --> Loader Class Initialized
INFO - 2023-10-13 19:43:40 --> Helper loaded: url_helper
INFO - 2023-10-13 19:43:40 --> Helper loaded: form_helper
INFO - 2023-10-13 19:43:40 --> Helper loaded: file_helper
INFO - 2023-10-13 19:43:40 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:43:40 --> Form Validation Class Initialized
INFO - 2023-10-13 19:43:40 --> Upload Class Initialized
INFO - 2023-10-13 19:43:40 --> Model "M_auth" initialized
INFO - 2023-10-13 19:43:40 --> Model "M_user" initialized
INFO - 2023-10-13 19:43:40 --> Model "M_produk" initialized
INFO - 2023-10-13 19:43:40 --> Controller Class Initialized
INFO - 2023-10-13 19:43:40 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-10-13 19:43:40 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-13 19:43:40 --> Final output sent to browser
DEBUG - 2023-10-13 19:43:40 --> Total execution time: 0.0232
INFO - 2023-10-13 19:43:43 --> Config Class Initialized
INFO - 2023-10-13 19:43:43 --> Hooks Class Initialized
DEBUG - 2023-10-13 19:43:43 --> UTF-8 Support Enabled
INFO - 2023-10-13 19:43:43 --> Utf8 Class Initialized
INFO - 2023-10-13 19:43:43 --> URI Class Initialized
INFO - 2023-10-13 19:43:43 --> Router Class Initialized
INFO - 2023-10-13 19:43:43 --> Output Class Initialized
INFO - 2023-10-13 19:43:43 --> Security Class Initialized
DEBUG - 2023-10-13 19:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-13 19:43:43 --> Input Class Initialized
INFO - 2023-10-13 19:43:43 --> Language Class Initialized
INFO - 2023-10-13 19:43:43 --> Loader Class Initialized
INFO - 2023-10-13 19:43:43 --> Helper loaded: url_helper
INFO - 2023-10-13 19:43:43 --> Helper loaded: form_helper
INFO - 2023-10-13 19:43:43 --> Helper loaded: file_helper
INFO - 2023-10-13 19:43:43 --> Database Driver Class Initialized
DEBUG - 2023-10-13 19:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-13 19:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-13 19:43:43 --> Form Validation Class Initialized
INFO - 2023-10-13 19:43:43 --> Upload Class Initialized
INFO - 2023-10-13 19:43:43 --> Model "M_auth" initialized
INFO - 2023-10-13 19:43:43 --> Model "M_user" initialized
INFO - 2023-10-13 19:43:43 --> Model "M_produk" initialized
INFO - 2023-10-13 19:43:43 --> Controller Class Initialized
INFO - 2023-10-13 19:43:43 --> Model "M_pelanggan" initialized
INFO - 2023-10-13 19:43:43 --> Model "M_produk" initialized
DEBUG - 2023-10-13 19:43:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-13 19:43:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-13 19:43:43 --> Model "M_transaksi" initialized
INFO - 2023-10-13 19:43:43 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_transaksi_all.php
INFO - 2023-10-13 19:43:43 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-13 19:43:43 --> Final output sent to browser
DEBUG - 2023-10-13 19:43:43 --> Total execution time: 0.0272
