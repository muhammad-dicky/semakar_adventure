<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-06 01:27:41 --> Config Class Initialized
INFO - 2023-09-06 01:27:41 --> Hooks Class Initialized
DEBUG - 2023-09-06 01:27:41 --> UTF-8 Support Enabled
INFO - 2023-09-06 01:27:41 --> Utf8 Class Initialized
INFO - 2023-09-06 01:27:41 --> URI Class Initialized
DEBUG - 2023-09-06 01:27:41 --> No URI present. Default controller set.
INFO - 2023-09-06 01:27:41 --> Router Class Initialized
INFO - 2023-09-06 01:27:41 --> Output Class Initialized
INFO - 2023-09-06 01:27:41 --> Security Class Initialized
DEBUG - 2023-09-06 01:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 01:27:41 --> Input Class Initialized
INFO - 2023-09-06 01:27:41 --> Language Class Initialized
INFO - 2023-09-06 01:27:41 --> Loader Class Initialized
INFO - 2023-09-06 01:27:41 --> Helper loaded: url_helper
INFO - 2023-09-06 01:27:41 --> Helper loaded: form_helper
INFO - 2023-09-06 01:27:41 --> Helper loaded: file_helper
INFO - 2023-09-06 01:27:41 --> Database Driver Class Initialized
DEBUG - 2023-09-06 01:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 01:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 01:27:42 --> Form Validation Class Initialized
INFO - 2023-09-06 01:27:42 --> Upload Class Initialized
INFO - 2023-09-06 01:27:42 --> Model "M_auth" initialized
INFO - 2023-09-06 01:27:42 --> Model "M_user" initialized
INFO - 2023-09-06 01:27:42 --> Model "M_produk" initialized
INFO - 2023-09-06 01:27:42 --> Controller Class Initialized
INFO - 2023-09-06 01:27:42 --> Model "M_pelanggan" initialized
INFO - 2023-09-06 01:27:42 --> Model "M_produk" initialized
DEBUG - 2023-09-06 01:27:42 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:27:42 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-09-06 01:27:42 --> Model "M_transaksi" initialized
INFO - 2023-09-06 01:27:42 --> Model "M_bank" initialized
INFO - 2023-09-06 01:27:42 --> Model "M_pesan" initialized
INFO - 2023-09-06 01:27:42 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-09-06 01:27:42 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-09-06 01:27:42 --> Final output sent to browser
DEBUG - 2023-09-06 01:27:42 --> Total execution time: 0.8376
INFO - 2023-09-06 01:28:44 --> Config Class Initialized
INFO - 2023-09-06 01:28:44 --> Hooks Class Initialized
DEBUG - 2023-09-06 01:28:44 --> UTF-8 Support Enabled
INFO - 2023-09-06 01:28:44 --> Utf8 Class Initialized
INFO - 2023-09-06 01:28:44 --> URI Class Initialized
DEBUG - 2023-09-06 01:28:44 --> No URI present. Default controller set.
INFO - 2023-09-06 01:28:44 --> Router Class Initialized
INFO - 2023-09-06 01:28:44 --> Output Class Initialized
INFO - 2023-09-06 01:28:44 --> Security Class Initialized
DEBUG - 2023-09-06 01:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 01:28:44 --> Input Class Initialized
INFO - 2023-09-06 01:28:44 --> Language Class Initialized
INFO - 2023-09-06 01:28:44 --> Loader Class Initialized
INFO - 2023-09-06 01:28:44 --> Helper loaded: url_helper
INFO - 2023-09-06 01:28:44 --> Helper loaded: form_helper
INFO - 2023-09-06 01:28:44 --> Helper loaded: file_helper
INFO - 2023-09-06 01:28:44 --> Database Driver Class Initialized
DEBUG - 2023-09-06 01:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 01:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 01:28:44 --> Form Validation Class Initialized
INFO - 2023-09-06 01:28:44 --> Upload Class Initialized
INFO - 2023-09-06 01:28:44 --> Model "M_auth" initialized
INFO - 2023-09-06 01:28:44 --> Model "M_user" initialized
INFO - 2023-09-06 01:28:44 --> Model "M_produk" initialized
INFO - 2023-09-06 01:28:44 --> Controller Class Initialized
INFO - 2023-09-06 01:28:44 --> Model "M_pelanggan" initialized
INFO - 2023-09-06 01:28:44 --> Model "M_produk" initialized
DEBUG - 2023-09-06 01:28:44 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:28:44 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-09-06 01:28:44 --> Model "M_transaksi" initialized
INFO - 2023-09-06 01:28:44 --> Model "M_bank" initialized
INFO - 2023-09-06 01:28:44 --> Model "M_pesan" initialized
INFO - 2023-09-06 01:28:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-06 01:28:44 --> Config Class Initialized
INFO - 2023-09-06 01:28:44 --> Hooks Class Initialized
DEBUG - 2023-09-06 01:28:44 --> UTF-8 Support Enabled
INFO - 2023-09-06 01:28:44 --> Utf8 Class Initialized
INFO - 2023-09-06 01:28:44 --> URI Class Initialized
DEBUG - 2023-09-06 01:28:44 --> No URI present. Default controller set.
INFO - 2023-09-06 01:28:44 --> Router Class Initialized
INFO - 2023-09-06 01:28:44 --> Output Class Initialized
INFO - 2023-09-06 01:28:44 --> Security Class Initialized
DEBUG - 2023-09-06 01:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 01:28:44 --> Input Class Initialized
INFO - 2023-09-06 01:28:44 --> Language Class Initialized
INFO - 2023-09-06 01:28:44 --> Loader Class Initialized
INFO - 2023-09-06 01:28:44 --> Helper loaded: url_helper
INFO - 2023-09-06 01:28:44 --> Helper loaded: form_helper
INFO - 2023-09-06 01:28:44 --> Helper loaded: file_helper
INFO - 2023-09-06 01:28:44 --> Database Driver Class Initialized
DEBUG - 2023-09-06 01:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 01:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 01:28:44 --> Form Validation Class Initialized
INFO - 2023-09-06 01:28:44 --> Upload Class Initialized
INFO - 2023-09-06 01:28:44 --> Model "M_auth" initialized
INFO - 2023-09-06 01:28:44 --> Model "M_user" initialized
INFO - 2023-09-06 01:28:44 --> Model "M_produk" initialized
INFO - 2023-09-06 01:28:44 --> Controller Class Initialized
INFO - 2023-09-06 01:28:44 --> Model "M_pelanggan" initialized
INFO - 2023-09-06 01:28:44 --> Model "M_produk" initialized
DEBUG - 2023-09-06 01:28:44 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 01:28:44 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-09-06 01:28:44 --> Model "M_transaksi" initialized
INFO - 2023-09-06 01:28:44 --> Model "M_bank" initialized
INFO - 2023-09-06 01:28:44 --> Model "M_pesan" initialized
INFO - 2023-09-06 01:28:44 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-09-06 01:28:44 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-09-06 01:28:44 --> Final output sent to browser
DEBUG - 2023-09-06 01:28:44 --> Total execution time: 0.1248
INFO - 2023-09-06 22:53:55 --> Config Class Initialized
INFO - 2023-09-06 22:53:55 --> Hooks Class Initialized
DEBUG - 2023-09-06 22:53:56 --> UTF-8 Support Enabled
INFO - 2023-09-06 22:53:56 --> Utf8 Class Initialized
INFO - 2023-09-06 22:53:56 --> URI Class Initialized
DEBUG - 2023-09-06 22:53:56 --> No URI present. Default controller set.
INFO - 2023-09-06 22:53:56 --> Router Class Initialized
INFO - 2023-09-06 22:53:57 --> Output Class Initialized
INFO - 2023-09-06 22:53:57 --> Security Class Initialized
DEBUG - 2023-09-06 22:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 22:53:57 --> Input Class Initialized
INFO - 2023-09-06 22:53:57 --> Language Class Initialized
INFO - 2023-09-06 22:53:57 --> Loader Class Initialized
INFO - 2023-09-06 22:53:57 --> Helper loaded: url_helper
INFO - 2023-09-06 22:53:57 --> Helper loaded: form_helper
INFO - 2023-09-06 22:53:58 --> Helper loaded: file_helper
INFO - 2023-09-06 22:53:58 --> Database Driver Class Initialized
DEBUG - 2023-09-06 22:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 22:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 22:53:59 --> Form Validation Class Initialized
INFO - 2023-09-06 22:53:59 --> Upload Class Initialized
INFO - 2023-09-06 22:53:59 --> Model "M_auth" initialized
INFO - 2023-09-06 22:53:59 --> Model "M_user" initialized
INFO - 2023-09-06 22:53:59 --> Model "M_produk" initialized
INFO - 2023-09-06 22:53:59 --> Controller Class Initialized
INFO - 2023-09-06 22:53:59 --> Model "M_pelanggan" initialized
INFO - 2023-09-06 22:53:59 --> Model "M_produk" initialized
DEBUG - 2023-09-06 22:53:59 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 22:53:59 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-09-06 22:53:59 --> Model "M_transaksi" initialized
INFO - 2023-09-06 22:53:59 --> Model "M_bank" initialized
INFO - 2023-09-06 22:53:59 --> Model "M_pesan" initialized
INFO - 2023-09-06 22:54:00 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-09-06 22:54:00 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-09-06 22:54:00 --> Final output sent to browser
DEBUG - 2023-09-06 22:54:00 --> Total execution time: 5.3291
INFO - 2023-09-06 22:55:14 --> Config Class Initialized
INFO - 2023-09-06 22:55:14 --> Hooks Class Initialized
DEBUG - 2023-09-06 22:55:14 --> UTF-8 Support Enabled
INFO - 2023-09-06 22:55:14 --> Utf8 Class Initialized
INFO - 2023-09-06 22:55:14 --> URI Class Initialized
DEBUG - 2023-09-06 22:55:14 --> No URI present. Default controller set.
INFO - 2023-09-06 22:55:14 --> Router Class Initialized
INFO - 2023-09-06 22:55:14 --> Output Class Initialized
INFO - 2023-09-06 22:55:14 --> Security Class Initialized
DEBUG - 2023-09-06 22:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 22:55:14 --> Input Class Initialized
INFO - 2023-09-06 22:55:14 --> Language Class Initialized
INFO - 2023-09-06 22:55:14 --> Loader Class Initialized
INFO - 2023-09-06 22:55:14 --> Helper loaded: url_helper
INFO - 2023-09-06 22:55:14 --> Helper loaded: form_helper
INFO - 2023-09-06 22:55:14 --> Helper loaded: file_helper
INFO - 2023-09-06 22:55:14 --> Database Driver Class Initialized
DEBUG - 2023-09-06 22:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 22:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 22:55:14 --> Form Validation Class Initialized
INFO - 2023-09-06 22:55:14 --> Upload Class Initialized
INFO - 2023-09-06 22:55:14 --> Model "M_auth" initialized
INFO - 2023-09-06 22:55:14 --> Model "M_user" initialized
INFO - 2023-09-06 22:55:14 --> Model "M_produk" initialized
INFO - 2023-09-06 22:55:14 --> Controller Class Initialized
INFO - 2023-09-06 22:55:14 --> Model "M_pelanggan" initialized
INFO - 2023-09-06 22:55:14 --> Model "M_produk" initialized
DEBUG - 2023-09-06 22:55:14 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 22:55:14 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-09-06 22:55:14 --> Model "M_transaksi" initialized
INFO - 2023-09-06 22:55:14 --> Model "M_bank" initialized
INFO - 2023-09-06 22:55:14 --> Model "M_pesan" initialized
INFO - 2023-09-06 22:55:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-06 22:55:14 --> Config Class Initialized
INFO - 2023-09-06 22:55:14 --> Hooks Class Initialized
DEBUG - 2023-09-06 22:55:14 --> UTF-8 Support Enabled
INFO - 2023-09-06 22:55:14 --> Utf8 Class Initialized
INFO - 2023-09-06 22:55:14 --> URI Class Initialized
DEBUG - 2023-09-06 22:55:14 --> No URI present. Default controller set.
INFO - 2023-09-06 22:55:14 --> Router Class Initialized
INFO - 2023-09-06 22:55:14 --> Output Class Initialized
INFO - 2023-09-06 22:55:14 --> Security Class Initialized
DEBUG - 2023-09-06 22:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 22:55:14 --> Input Class Initialized
INFO - 2023-09-06 22:55:14 --> Language Class Initialized
INFO - 2023-09-06 22:55:14 --> Loader Class Initialized
INFO - 2023-09-06 22:55:14 --> Helper loaded: url_helper
INFO - 2023-09-06 22:55:14 --> Helper loaded: form_helper
INFO - 2023-09-06 22:55:14 --> Helper loaded: file_helper
INFO - 2023-09-06 22:55:14 --> Database Driver Class Initialized
DEBUG - 2023-09-06 22:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 22:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 22:55:14 --> Form Validation Class Initialized
INFO - 2023-09-06 22:55:14 --> Upload Class Initialized
INFO - 2023-09-06 22:55:14 --> Model "M_auth" initialized
INFO - 2023-09-06 22:55:14 --> Model "M_user" initialized
INFO - 2023-09-06 22:55:14 --> Model "M_produk" initialized
INFO - 2023-09-06 22:55:14 --> Controller Class Initialized
INFO - 2023-09-06 22:55:14 --> Model "M_pelanggan" initialized
INFO - 2023-09-06 22:55:14 --> Model "M_produk" initialized
DEBUG - 2023-09-06 22:55:14 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 22:55:14 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-09-06 22:55:14 --> Model "M_transaksi" initialized
INFO - 2023-09-06 22:55:14 --> Model "M_bank" initialized
INFO - 2023-09-06 22:55:14 --> Model "M_pesan" initialized
INFO - 2023-09-06 22:55:14 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-09-06 22:55:14 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-09-06 22:55:14 --> Final output sent to browser
DEBUG - 2023-09-06 22:55:14 --> Total execution time: 0.1477
INFO - 2023-09-06 22:55:29 --> Config Class Initialized
INFO - 2023-09-06 22:55:29 --> Hooks Class Initialized
DEBUG - 2023-09-06 22:55:29 --> UTF-8 Support Enabled
INFO - 2023-09-06 22:55:29 --> Utf8 Class Initialized
INFO - 2023-09-06 22:55:29 --> URI Class Initialized
DEBUG - 2023-09-06 22:55:29 --> No URI present. Default controller set.
INFO - 2023-09-06 22:55:29 --> Router Class Initialized
INFO - 2023-09-06 22:55:29 --> Output Class Initialized
INFO - 2023-09-06 22:55:29 --> Security Class Initialized
DEBUG - 2023-09-06 22:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 22:55:29 --> Input Class Initialized
INFO - 2023-09-06 22:55:29 --> Language Class Initialized
INFO - 2023-09-06 22:55:29 --> Loader Class Initialized
INFO - 2023-09-06 22:55:29 --> Helper loaded: url_helper
INFO - 2023-09-06 22:55:29 --> Helper loaded: form_helper
INFO - 2023-09-06 22:55:29 --> Helper loaded: file_helper
INFO - 2023-09-06 22:55:29 --> Database Driver Class Initialized
DEBUG - 2023-09-06 22:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 22:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 22:55:29 --> Form Validation Class Initialized
INFO - 2023-09-06 22:55:29 --> Upload Class Initialized
INFO - 2023-09-06 22:55:29 --> Model "M_auth" initialized
INFO - 2023-09-06 22:55:29 --> Model "M_user" initialized
INFO - 2023-09-06 22:55:29 --> Model "M_produk" initialized
INFO - 2023-09-06 22:55:29 --> Controller Class Initialized
INFO - 2023-09-06 22:55:29 --> Model "M_pelanggan" initialized
INFO - 2023-09-06 22:55:29 --> Model "M_produk" initialized
DEBUG - 2023-09-06 22:55:29 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 22:55:29 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-09-06 22:55:29 --> Model "M_transaksi" initialized
INFO - 2023-09-06 22:55:29 --> Model "M_bank" initialized
INFO - 2023-09-06 22:55:29 --> Model "M_pesan" initialized
INFO - 2023-09-06 22:55:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-06 22:55:29 --> Config Class Initialized
INFO - 2023-09-06 22:55:29 --> Hooks Class Initialized
DEBUG - 2023-09-06 22:55:29 --> UTF-8 Support Enabled
INFO - 2023-09-06 22:55:29 --> Utf8 Class Initialized
INFO - 2023-09-06 22:55:29 --> URI Class Initialized
DEBUG - 2023-09-06 22:55:29 --> No URI present. Default controller set.
INFO - 2023-09-06 22:55:29 --> Router Class Initialized
INFO - 2023-09-06 22:55:29 --> Output Class Initialized
INFO - 2023-09-06 22:55:29 --> Security Class Initialized
DEBUG - 2023-09-06 22:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 22:55:29 --> Input Class Initialized
INFO - 2023-09-06 22:55:29 --> Language Class Initialized
INFO - 2023-09-06 22:55:29 --> Loader Class Initialized
INFO - 2023-09-06 22:55:29 --> Helper loaded: url_helper
INFO - 2023-09-06 22:55:29 --> Helper loaded: form_helper
INFO - 2023-09-06 22:55:29 --> Helper loaded: file_helper
INFO - 2023-09-06 22:55:29 --> Database Driver Class Initialized
DEBUG - 2023-09-06 22:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 22:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 22:55:29 --> Form Validation Class Initialized
INFO - 2023-09-06 22:55:29 --> Upload Class Initialized
INFO - 2023-09-06 22:55:29 --> Model "M_auth" initialized
INFO - 2023-09-06 22:55:29 --> Model "M_user" initialized
INFO - 2023-09-06 22:55:29 --> Model "M_produk" initialized
INFO - 2023-09-06 22:55:29 --> Controller Class Initialized
INFO - 2023-09-06 22:55:29 --> Model "M_pelanggan" initialized
INFO - 2023-09-06 22:55:29 --> Model "M_produk" initialized
DEBUG - 2023-09-06 22:55:29 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 22:55:29 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-09-06 22:55:29 --> Model "M_transaksi" initialized
INFO - 2023-09-06 22:55:29 --> Model "M_bank" initialized
INFO - 2023-09-06 22:55:29 --> Model "M_pesan" initialized
INFO - 2023-09-06 22:55:29 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-09-06 22:55:29 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-09-06 22:55:29 --> Final output sent to browser
DEBUG - 2023-09-06 22:55:29 --> Total execution time: 0.1491
INFO - 2023-09-06 22:57:28 --> Config Class Initialized
INFO - 2023-09-06 22:57:28 --> Hooks Class Initialized
DEBUG - 2023-09-06 22:57:28 --> UTF-8 Support Enabled
INFO - 2023-09-06 22:57:28 --> Utf8 Class Initialized
INFO - 2023-09-06 22:57:28 --> URI Class Initialized
DEBUG - 2023-09-06 22:57:28 --> No URI present. Default controller set.
INFO - 2023-09-06 22:57:28 --> Router Class Initialized
INFO - 2023-09-06 22:57:28 --> Output Class Initialized
INFO - 2023-09-06 22:57:28 --> Security Class Initialized
DEBUG - 2023-09-06 22:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 22:57:28 --> Input Class Initialized
INFO - 2023-09-06 22:57:28 --> Language Class Initialized
INFO - 2023-09-06 22:57:28 --> Loader Class Initialized
INFO - 2023-09-06 22:57:28 --> Helper loaded: url_helper
INFO - 2023-09-06 22:57:28 --> Helper loaded: form_helper
INFO - 2023-09-06 22:57:28 --> Helper loaded: file_helper
INFO - 2023-09-06 22:57:28 --> Database Driver Class Initialized
DEBUG - 2023-09-06 22:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 22:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 22:57:28 --> Form Validation Class Initialized
INFO - 2023-09-06 22:57:28 --> Upload Class Initialized
INFO - 2023-09-06 22:57:28 --> Model "M_auth" initialized
INFO - 2023-09-06 22:57:28 --> Model "M_user" initialized
INFO - 2023-09-06 22:57:28 --> Model "M_produk" initialized
INFO - 2023-09-06 22:57:28 --> Controller Class Initialized
INFO - 2023-09-06 22:57:28 --> Model "M_pelanggan" initialized
INFO - 2023-09-06 22:57:28 --> Model "M_produk" initialized
DEBUG - 2023-09-06 22:57:28 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 22:57:28 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-09-06 22:57:28 --> Model "M_transaksi" initialized
INFO - 2023-09-06 22:57:28 --> Model "M_bank" initialized
INFO - 2023-09-06 22:57:28 --> Model "M_pesan" initialized
INFO - 2023-09-06 22:57:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-06 22:57:28 --> Config Class Initialized
INFO - 2023-09-06 22:57:28 --> Hooks Class Initialized
DEBUG - 2023-09-06 22:57:28 --> UTF-8 Support Enabled
INFO - 2023-09-06 22:57:28 --> Utf8 Class Initialized
INFO - 2023-09-06 22:57:28 --> URI Class Initialized
DEBUG - 2023-09-06 22:57:28 --> No URI present. Default controller set.
INFO - 2023-09-06 22:57:28 --> Router Class Initialized
INFO - 2023-09-06 22:57:28 --> Output Class Initialized
INFO - 2023-09-06 22:57:28 --> Security Class Initialized
DEBUG - 2023-09-06 22:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 22:57:28 --> Input Class Initialized
INFO - 2023-09-06 22:57:28 --> Language Class Initialized
INFO - 2023-09-06 22:57:28 --> Loader Class Initialized
INFO - 2023-09-06 22:57:28 --> Helper loaded: url_helper
INFO - 2023-09-06 22:57:28 --> Helper loaded: form_helper
INFO - 2023-09-06 22:57:28 --> Helper loaded: file_helper
INFO - 2023-09-06 22:57:28 --> Database Driver Class Initialized
DEBUG - 2023-09-06 22:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 22:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 22:57:28 --> Form Validation Class Initialized
INFO - 2023-09-06 22:57:28 --> Upload Class Initialized
INFO - 2023-09-06 22:57:28 --> Model "M_auth" initialized
INFO - 2023-09-06 22:57:28 --> Model "M_user" initialized
INFO - 2023-09-06 22:57:28 --> Model "M_produk" initialized
INFO - 2023-09-06 22:57:28 --> Controller Class Initialized
INFO - 2023-09-06 22:57:28 --> Model "M_pelanggan" initialized
INFO - 2023-09-06 22:57:28 --> Model "M_produk" initialized
DEBUG - 2023-09-06 22:57:28 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 22:57:28 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-09-06 22:57:28 --> Model "M_transaksi" initialized
INFO - 2023-09-06 22:57:28 --> Model "M_bank" initialized
INFO - 2023-09-06 22:57:28 --> Model "M_pesan" initialized
INFO - 2023-09-06 22:57:28 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-09-06 22:57:28 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-09-06 22:57:28 --> Final output sent to browser
DEBUG - 2023-09-06 22:57:28 --> Total execution time: 0.1488
INFO - 2023-09-06 22:57:43 --> Config Class Initialized
INFO - 2023-09-06 22:57:43 --> Hooks Class Initialized
DEBUG - 2023-09-06 22:57:43 --> UTF-8 Support Enabled
INFO - 2023-09-06 22:57:43 --> Utf8 Class Initialized
INFO - 2023-09-06 22:57:43 --> URI Class Initialized
DEBUG - 2023-09-06 22:57:43 --> No URI present. Default controller set.
INFO - 2023-09-06 22:57:43 --> Router Class Initialized
INFO - 2023-09-06 22:57:43 --> Output Class Initialized
INFO - 2023-09-06 22:57:43 --> Security Class Initialized
DEBUG - 2023-09-06 22:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 22:57:43 --> Input Class Initialized
INFO - 2023-09-06 22:57:43 --> Language Class Initialized
INFO - 2023-09-06 22:57:43 --> Loader Class Initialized
INFO - 2023-09-06 22:57:43 --> Helper loaded: url_helper
INFO - 2023-09-06 22:57:43 --> Helper loaded: form_helper
INFO - 2023-09-06 22:57:43 --> Helper loaded: file_helper
INFO - 2023-09-06 22:57:43 --> Database Driver Class Initialized
DEBUG - 2023-09-06 22:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 22:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 22:57:43 --> Form Validation Class Initialized
INFO - 2023-09-06 22:57:43 --> Upload Class Initialized
INFO - 2023-09-06 22:57:43 --> Model "M_auth" initialized
INFO - 2023-09-06 22:57:43 --> Model "M_user" initialized
INFO - 2023-09-06 22:57:43 --> Model "M_produk" initialized
INFO - 2023-09-06 22:57:43 --> Controller Class Initialized
INFO - 2023-09-06 22:57:43 --> Model "M_pelanggan" initialized
INFO - 2023-09-06 22:57:43 --> Model "M_produk" initialized
DEBUG - 2023-09-06 22:57:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 22:57:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-09-06 22:57:43 --> Model "M_transaksi" initialized
INFO - 2023-09-06 22:57:43 --> Model "M_bank" initialized
INFO - 2023-09-06 22:57:43 --> Model "M_pesan" initialized
INFO - 2023-09-06 22:57:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-06 22:57:43 --> Config Class Initialized
INFO - 2023-09-06 22:57:43 --> Hooks Class Initialized
DEBUG - 2023-09-06 22:57:43 --> UTF-8 Support Enabled
INFO - 2023-09-06 22:57:43 --> Utf8 Class Initialized
INFO - 2023-09-06 22:57:43 --> URI Class Initialized
DEBUG - 2023-09-06 22:57:43 --> No URI present. Default controller set.
INFO - 2023-09-06 22:57:43 --> Router Class Initialized
INFO - 2023-09-06 22:57:43 --> Output Class Initialized
INFO - 2023-09-06 22:57:43 --> Security Class Initialized
DEBUG - 2023-09-06 22:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 22:57:43 --> Input Class Initialized
INFO - 2023-09-06 22:57:43 --> Language Class Initialized
INFO - 2023-09-06 22:57:43 --> Loader Class Initialized
INFO - 2023-09-06 22:57:43 --> Helper loaded: url_helper
INFO - 2023-09-06 22:57:43 --> Helper loaded: form_helper
INFO - 2023-09-06 22:57:43 --> Helper loaded: file_helper
INFO - 2023-09-06 22:57:43 --> Database Driver Class Initialized
DEBUG - 2023-09-06 22:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 22:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 22:57:43 --> Form Validation Class Initialized
INFO - 2023-09-06 22:57:43 --> Upload Class Initialized
INFO - 2023-09-06 22:57:43 --> Model "M_auth" initialized
INFO - 2023-09-06 22:57:43 --> Model "M_user" initialized
INFO - 2023-09-06 22:57:43 --> Model "M_produk" initialized
INFO - 2023-09-06 22:57:43 --> Controller Class Initialized
INFO - 2023-09-06 22:57:43 --> Model "M_pelanggan" initialized
INFO - 2023-09-06 22:57:43 --> Model "M_produk" initialized
DEBUG - 2023-09-06 22:57:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 22:57:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-09-06 22:57:43 --> Model "M_transaksi" initialized
INFO - 2023-09-06 22:57:43 --> Model "M_bank" initialized
INFO - 2023-09-06 22:57:43 --> Model "M_pesan" initialized
INFO - 2023-09-06 22:57:43 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-09-06 22:57:43 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-09-06 22:57:43 --> Final output sent to browser
DEBUG - 2023-09-06 22:57:43 --> Total execution time: 0.1878
INFO - 2023-09-06 22:59:10 --> Config Class Initialized
INFO - 2023-09-06 22:59:10 --> Hooks Class Initialized
DEBUG - 2023-09-06 22:59:10 --> UTF-8 Support Enabled
INFO - 2023-09-06 22:59:10 --> Utf8 Class Initialized
INFO - 2023-09-06 22:59:10 --> URI Class Initialized
DEBUG - 2023-09-06 22:59:10 --> No URI present. Default controller set.
INFO - 2023-09-06 22:59:10 --> Router Class Initialized
INFO - 2023-09-06 22:59:10 --> Output Class Initialized
INFO - 2023-09-06 22:59:10 --> Security Class Initialized
DEBUG - 2023-09-06 22:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 22:59:10 --> Input Class Initialized
INFO - 2023-09-06 22:59:10 --> Language Class Initialized
INFO - 2023-09-06 22:59:10 --> Loader Class Initialized
INFO - 2023-09-06 22:59:10 --> Helper loaded: url_helper
INFO - 2023-09-06 22:59:10 --> Helper loaded: form_helper
INFO - 2023-09-06 22:59:10 --> Helper loaded: file_helper
INFO - 2023-09-06 22:59:10 --> Database Driver Class Initialized
DEBUG - 2023-09-06 22:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 22:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 22:59:10 --> Form Validation Class Initialized
INFO - 2023-09-06 22:59:10 --> Upload Class Initialized
INFO - 2023-09-06 22:59:10 --> Model "M_auth" initialized
INFO - 2023-09-06 22:59:10 --> Model "M_user" initialized
INFO - 2023-09-06 22:59:10 --> Model "M_produk" initialized
INFO - 2023-09-06 22:59:10 --> Controller Class Initialized
INFO - 2023-09-06 22:59:10 --> Model "M_pelanggan" initialized
INFO - 2023-09-06 22:59:10 --> Model "M_produk" initialized
DEBUG - 2023-09-06 22:59:10 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 22:59:10 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-09-06 22:59:10 --> Model "M_transaksi" initialized
INFO - 2023-09-06 22:59:10 --> Model "M_bank" initialized
INFO - 2023-09-06 22:59:10 --> Model "M_pesan" initialized
INFO - 2023-09-06 22:59:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-06 22:59:10 --> Config Class Initialized
INFO - 2023-09-06 22:59:10 --> Hooks Class Initialized
DEBUG - 2023-09-06 22:59:10 --> UTF-8 Support Enabled
INFO - 2023-09-06 22:59:10 --> Utf8 Class Initialized
INFO - 2023-09-06 22:59:10 --> URI Class Initialized
DEBUG - 2023-09-06 22:59:10 --> No URI present. Default controller set.
INFO - 2023-09-06 22:59:10 --> Router Class Initialized
INFO - 2023-09-06 22:59:10 --> Output Class Initialized
INFO - 2023-09-06 22:59:10 --> Security Class Initialized
DEBUG - 2023-09-06 22:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 22:59:10 --> Input Class Initialized
INFO - 2023-09-06 22:59:10 --> Language Class Initialized
INFO - 2023-09-06 22:59:10 --> Loader Class Initialized
INFO - 2023-09-06 22:59:10 --> Helper loaded: url_helper
INFO - 2023-09-06 22:59:10 --> Helper loaded: form_helper
INFO - 2023-09-06 22:59:10 --> Helper loaded: file_helper
INFO - 2023-09-06 22:59:10 --> Database Driver Class Initialized
DEBUG - 2023-09-06 22:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 22:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 22:59:10 --> Form Validation Class Initialized
INFO - 2023-09-06 22:59:10 --> Upload Class Initialized
INFO - 2023-09-06 22:59:10 --> Model "M_auth" initialized
INFO - 2023-09-06 22:59:10 --> Model "M_user" initialized
INFO - 2023-09-06 22:59:10 --> Model "M_produk" initialized
INFO - 2023-09-06 22:59:10 --> Controller Class Initialized
INFO - 2023-09-06 22:59:10 --> Model "M_pelanggan" initialized
INFO - 2023-09-06 22:59:10 --> Model "M_produk" initialized
DEBUG - 2023-09-06 22:59:10 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 22:59:10 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-09-06 22:59:10 --> Model "M_transaksi" initialized
INFO - 2023-09-06 22:59:10 --> Model "M_bank" initialized
INFO - 2023-09-06 22:59:10 --> Model "M_pesan" initialized
INFO - 2023-09-06 22:59:10 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-09-06 22:59:10 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-09-06 22:59:10 --> Final output sent to browser
DEBUG - 2023-09-06 22:59:10 --> Total execution time: 0.2066
INFO - 2023-09-06 22:59:21 --> Config Class Initialized
INFO - 2023-09-06 22:59:21 --> Hooks Class Initialized
DEBUG - 2023-09-06 22:59:21 --> UTF-8 Support Enabled
INFO - 2023-09-06 22:59:21 --> Utf8 Class Initialized
INFO - 2023-09-06 22:59:21 --> URI Class Initialized
INFO - 2023-09-06 22:59:21 --> Router Class Initialized
INFO - 2023-09-06 22:59:21 --> Output Class Initialized
INFO - 2023-09-06 22:59:21 --> Security Class Initialized
DEBUG - 2023-09-06 22:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 22:59:21 --> Input Class Initialized
INFO - 2023-09-06 22:59:21 --> Language Class Initialized
INFO - 2023-09-06 22:59:21 --> Loader Class Initialized
INFO - 2023-09-06 22:59:21 --> Helper loaded: url_helper
INFO - 2023-09-06 22:59:21 --> Helper loaded: form_helper
INFO - 2023-09-06 22:59:21 --> Helper loaded: file_helper
INFO - 2023-09-06 22:59:21 --> Database Driver Class Initialized
DEBUG - 2023-09-06 22:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 22:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 22:59:21 --> Form Validation Class Initialized
INFO - 2023-09-06 22:59:21 --> Upload Class Initialized
INFO - 2023-09-06 22:59:21 --> Model "M_auth" initialized
INFO - 2023-09-06 22:59:21 --> Model "M_user" initialized
INFO - 2023-09-06 22:59:21 --> Model "M_produk" initialized
INFO - 2023-09-06 22:59:21 --> Controller Class Initialized
INFO - 2023-09-06 22:59:21 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-09-06 22:59:21 --> Final output sent to browser
DEBUG - 2023-09-06 22:59:21 --> Total execution time: 0.3933
INFO - 2023-09-06 22:59:33 --> Config Class Initialized
INFO - 2023-09-06 22:59:33 --> Hooks Class Initialized
DEBUG - 2023-09-06 22:59:33 --> UTF-8 Support Enabled
INFO - 2023-09-06 22:59:33 --> Utf8 Class Initialized
INFO - 2023-09-06 22:59:33 --> URI Class Initialized
INFO - 2023-09-06 22:59:33 --> Router Class Initialized
INFO - 2023-09-06 22:59:33 --> Output Class Initialized
INFO - 2023-09-06 22:59:33 --> Security Class Initialized
DEBUG - 2023-09-06 22:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 22:59:33 --> Input Class Initialized
INFO - 2023-09-06 22:59:33 --> Language Class Initialized
INFO - 2023-09-06 22:59:33 --> Loader Class Initialized
INFO - 2023-09-06 22:59:33 --> Helper loaded: url_helper
INFO - 2023-09-06 22:59:33 --> Helper loaded: form_helper
INFO - 2023-09-06 22:59:33 --> Helper loaded: file_helper
INFO - 2023-09-06 22:59:33 --> Database Driver Class Initialized
DEBUG - 2023-09-06 22:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 22:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 22:59:33 --> Form Validation Class Initialized
INFO - 2023-09-06 22:59:33 --> Upload Class Initialized
INFO - 2023-09-06 22:59:33 --> Model "M_auth" initialized
INFO - 2023-09-06 22:59:33 --> Model "M_user" initialized
INFO - 2023-09-06 22:59:33 --> Model "M_produk" initialized
INFO - 2023-09-06 22:59:33 --> Controller Class Initialized
INFO - 2023-09-06 22:59:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-06 22:59:33 --> Config Class Initialized
INFO - 2023-09-06 22:59:33 --> Hooks Class Initialized
DEBUG - 2023-09-06 22:59:33 --> UTF-8 Support Enabled
INFO - 2023-09-06 22:59:33 --> Utf8 Class Initialized
INFO - 2023-09-06 22:59:33 --> URI Class Initialized
INFO - 2023-09-06 22:59:33 --> Router Class Initialized
INFO - 2023-09-06 22:59:33 --> Output Class Initialized
INFO - 2023-09-06 22:59:33 --> Security Class Initialized
DEBUG - 2023-09-06 22:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 22:59:33 --> Input Class Initialized
INFO - 2023-09-06 22:59:33 --> Language Class Initialized
INFO - 2023-09-06 22:59:33 --> Loader Class Initialized
INFO - 2023-09-06 22:59:33 --> Helper loaded: url_helper
INFO - 2023-09-06 22:59:33 --> Helper loaded: form_helper
INFO - 2023-09-06 22:59:33 --> Helper loaded: file_helper
INFO - 2023-09-06 22:59:33 --> Database Driver Class Initialized
DEBUG - 2023-09-06 22:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 22:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 22:59:33 --> Form Validation Class Initialized
INFO - 2023-09-06 22:59:33 --> Upload Class Initialized
INFO - 2023-09-06 22:59:33 --> Model "M_auth" initialized
INFO - 2023-09-06 22:59:33 --> Model "M_user" initialized
INFO - 2023-09-06 22:59:33 --> Model "M_produk" initialized
INFO - 2023-09-06 22:59:33 --> Controller Class Initialized
INFO - 2023-09-06 22:59:33 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-09-06 22:59:33 --> Final output sent to browser
DEBUG - 2023-09-06 22:59:33 --> Total execution time: 0.1234
INFO - 2023-09-06 22:59:39 --> Config Class Initialized
INFO - 2023-09-06 22:59:39 --> Hooks Class Initialized
DEBUG - 2023-09-06 22:59:39 --> UTF-8 Support Enabled
INFO - 2023-09-06 22:59:39 --> Utf8 Class Initialized
INFO - 2023-09-06 22:59:39 --> URI Class Initialized
INFO - 2023-09-06 22:59:39 --> Router Class Initialized
INFO - 2023-09-06 22:59:39 --> Output Class Initialized
INFO - 2023-09-06 22:59:39 --> Security Class Initialized
DEBUG - 2023-09-06 22:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 22:59:39 --> Input Class Initialized
INFO - 2023-09-06 22:59:39 --> Language Class Initialized
INFO - 2023-09-06 22:59:39 --> Loader Class Initialized
INFO - 2023-09-06 22:59:39 --> Helper loaded: url_helper
INFO - 2023-09-06 22:59:39 --> Helper loaded: form_helper
INFO - 2023-09-06 22:59:39 --> Helper loaded: file_helper
INFO - 2023-09-06 22:59:39 --> Database Driver Class Initialized
DEBUG - 2023-09-06 22:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 22:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 22:59:39 --> Form Validation Class Initialized
INFO - 2023-09-06 22:59:39 --> Upload Class Initialized
INFO - 2023-09-06 22:59:39 --> Model "M_auth" initialized
INFO - 2023-09-06 22:59:39 --> Model "M_user" initialized
INFO - 2023-09-06 22:59:39 --> Model "M_produk" initialized
INFO - 2023-09-06 22:59:39 --> Controller Class Initialized
INFO - 2023-09-06 22:59:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-06 22:59:39 --> Config Class Initialized
INFO - 2023-09-06 22:59:39 --> Hooks Class Initialized
DEBUG - 2023-09-06 22:59:39 --> UTF-8 Support Enabled
INFO - 2023-09-06 22:59:39 --> Utf8 Class Initialized
INFO - 2023-09-06 22:59:39 --> URI Class Initialized
INFO - 2023-09-06 22:59:39 --> Router Class Initialized
INFO - 2023-09-06 22:59:39 --> Output Class Initialized
INFO - 2023-09-06 22:59:39 --> Security Class Initialized
DEBUG - 2023-09-06 22:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 22:59:39 --> Input Class Initialized
INFO - 2023-09-06 22:59:39 --> Language Class Initialized
INFO - 2023-09-06 22:59:39 --> Loader Class Initialized
INFO - 2023-09-06 22:59:39 --> Helper loaded: url_helper
INFO - 2023-09-06 22:59:39 --> Helper loaded: form_helper
INFO - 2023-09-06 22:59:39 --> Helper loaded: file_helper
INFO - 2023-09-06 22:59:40 --> Database Driver Class Initialized
DEBUG - 2023-09-06 22:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 22:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 22:59:40 --> Form Validation Class Initialized
INFO - 2023-09-06 22:59:40 --> Upload Class Initialized
INFO - 2023-09-06 22:59:40 --> Model "M_auth" initialized
INFO - 2023-09-06 22:59:40 --> Model "M_user" initialized
INFO - 2023-09-06 22:59:40 --> Model "M_produk" initialized
INFO - 2023-09-06 22:59:40 --> Controller Class Initialized
INFO - 2023-09-06 22:59:40 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-09-06 22:59:40 --> Final output sent to browser
DEBUG - 2023-09-06 22:59:40 --> Total execution time: 0.1337
INFO - 2023-09-06 23:00:03 --> Config Class Initialized
INFO - 2023-09-06 23:00:03 --> Hooks Class Initialized
DEBUG - 2023-09-06 23:00:03 --> UTF-8 Support Enabled
INFO - 2023-09-06 23:00:03 --> Utf8 Class Initialized
INFO - 2023-09-06 23:00:03 --> URI Class Initialized
INFO - 2023-09-06 23:00:03 --> Router Class Initialized
INFO - 2023-09-06 23:00:03 --> Output Class Initialized
INFO - 2023-09-06 23:00:03 --> Security Class Initialized
DEBUG - 2023-09-06 23:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 23:00:03 --> Input Class Initialized
INFO - 2023-09-06 23:00:03 --> Language Class Initialized
INFO - 2023-09-06 23:00:03 --> Loader Class Initialized
INFO - 2023-09-06 23:00:03 --> Helper loaded: url_helper
INFO - 2023-09-06 23:00:03 --> Helper loaded: form_helper
INFO - 2023-09-06 23:00:03 --> Helper loaded: file_helper
INFO - 2023-09-06 23:00:03 --> Database Driver Class Initialized
DEBUG - 2023-09-06 23:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 23:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 23:00:03 --> Form Validation Class Initialized
INFO - 2023-09-06 23:00:03 --> Upload Class Initialized
INFO - 2023-09-06 23:00:03 --> Model "M_auth" initialized
INFO - 2023-09-06 23:00:03 --> Model "M_user" initialized
INFO - 2023-09-06 23:00:03 --> Model "M_produk" initialized
INFO - 2023-09-06 23:00:03 --> Controller Class Initialized
INFO - 2023-09-06 23:00:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-06 23:00:04 --> Config Class Initialized
INFO - 2023-09-06 23:00:04 --> Hooks Class Initialized
DEBUG - 2023-09-06 23:00:04 --> UTF-8 Support Enabled
INFO - 2023-09-06 23:00:04 --> Utf8 Class Initialized
INFO - 2023-09-06 23:00:04 --> URI Class Initialized
INFO - 2023-09-06 23:00:04 --> Router Class Initialized
INFO - 2023-09-06 23:00:04 --> Output Class Initialized
INFO - 2023-09-06 23:00:04 --> Security Class Initialized
DEBUG - 2023-09-06 23:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 23:00:04 --> Input Class Initialized
INFO - 2023-09-06 23:00:04 --> Language Class Initialized
INFO - 2023-09-06 23:00:04 --> Loader Class Initialized
INFO - 2023-09-06 23:00:04 --> Helper loaded: url_helper
INFO - 2023-09-06 23:00:04 --> Helper loaded: form_helper
INFO - 2023-09-06 23:00:04 --> Helper loaded: file_helper
INFO - 2023-09-06 23:00:04 --> Database Driver Class Initialized
DEBUG - 2023-09-06 23:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 23:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 23:00:04 --> Form Validation Class Initialized
INFO - 2023-09-06 23:00:04 --> Upload Class Initialized
INFO - 2023-09-06 23:00:04 --> Model "M_auth" initialized
INFO - 2023-09-06 23:00:04 --> Model "M_user" initialized
INFO - 2023-09-06 23:00:04 --> Model "M_produk" initialized
INFO - 2023-09-06 23:00:04 --> Controller Class Initialized
INFO - 2023-09-06 23:00:04 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-09-06 23:00:04 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-09-06 23:00:04 --> Final output sent to browser
DEBUG - 2023-09-06 23:00:04 --> Total execution time: 0.6114
INFO - 2023-09-06 23:00:13 --> Config Class Initialized
INFO - 2023-09-06 23:00:13 --> Hooks Class Initialized
DEBUG - 2023-09-06 23:00:14 --> UTF-8 Support Enabled
INFO - 2023-09-06 23:00:14 --> Utf8 Class Initialized
INFO - 2023-09-06 23:00:14 --> URI Class Initialized
INFO - 2023-09-06 23:00:14 --> Router Class Initialized
INFO - 2023-09-06 23:00:14 --> Output Class Initialized
INFO - 2023-09-06 23:00:14 --> Security Class Initialized
DEBUG - 2023-09-06 23:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 23:00:14 --> Input Class Initialized
INFO - 2023-09-06 23:00:14 --> Language Class Initialized
INFO - 2023-09-06 23:00:14 --> Loader Class Initialized
INFO - 2023-09-06 23:00:14 --> Helper loaded: url_helper
INFO - 2023-09-06 23:00:14 --> Helper loaded: form_helper
INFO - 2023-09-06 23:00:14 --> Helper loaded: file_helper
INFO - 2023-09-06 23:00:14 --> Database Driver Class Initialized
DEBUG - 2023-09-06 23:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 23:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 23:00:14 --> Form Validation Class Initialized
INFO - 2023-09-06 23:00:14 --> Upload Class Initialized
INFO - 2023-09-06 23:00:14 --> Model "M_auth" initialized
INFO - 2023-09-06 23:00:14 --> Model "M_user" initialized
INFO - 2023-09-06 23:00:14 --> Model "M_produk" initialized
INFO - 2023-09-06 23:00:14 --> Controller Class Initialized
INFO - 2023-09-06 23:00:14 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_user_profile.php
INFO - 2023-09-06 23:00:14 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-09-06 23:00:14 --> Final output sent to browser
DEBUG - 2023-09-06 23:00:14 --> Total execution time: 0.4952
INFO - 2023-09-06 23:00:33 --> Config Class Initialized
INFO - 2023-09-06 23:00:33 --> Hooks Class Initialized
DEBUG - 2023-09-06 23:00:34 --> UTF-8 Support Enabled
INFO - 2023-09-06 23:00:34 --> Utf8 Class Initialized
INFO - 2023-09-06 23:00:34 --> URI Class Initialized
INFO - 2023-09-06 23:00:34 --> Router Class Initialized
INFO - 2023-09-06 23:00:34 --> Output Class Initialized
INFO - 2023-09-06 23:00:34 --> Security Class Initialized
DEBUG - 2023-09-06 23:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 23:00:34 --> Input Class Initialized
INFO - 2023-09-06 23:00:34 --> Language Class Initialized
INFO - 2023-09-06 23:00:34 --> Loader Class Initialized
INFO - 2023-09-06 23:00:34 --> Helper loaded: url_helper
INFO - 2023-09-06 23:00:34 --> Helper loaded: form_helper
INFO - 2023-09-06 23:00:34 --> Helper loaded: file_helper
INFO - 2023-09-06 23:00:34 --> Database Driver Class Initialized
DEBUG - 2023-09-06 23:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 23:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 23:00:34 --> Form Validation Class Initialized
INFO - 2023-09-06 23:00:34 --> Upload Class Initialized
INFO - 2023-09-06 23:00:34 --> Model "M_auth" initialized
INFO - 2023-09-06 23:00:34 --> Model "M_user" initialized
INFO - 2023-09-06 23:00:34 --> Model "M_produk" initialized
INFO - 2023-09-06 23:00:34 --> Controller Class Initialized
INFO - 2023-09-06 23:00:34 --> Model "M_pelanggan" initialized
INFO - 2023-09-06 23:00:34 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_pelanggan.php
INFO - 2023-09-06 23:00:34 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-09-06 23:00:34 --> Final output sent to browser
DEBUG - 2023-09-06 23:00:34 --> Total execution time: 0.4317
INFO - 2023-09-06 23:00:49 --> Config Class Initialized
INFO - 2023-09-06 23:00:49 --> Hooks Class Initialized
DEBUG - 2023-09-06 23:00:49 --> UTF-8 Support Enabled
INFO - 2023-09-06 23:00:49 --> Utf8 Class Initialized
INFO - 2023-09-06 23:00:49 --> URI Class Initialized
INFO - 2023-09-06 23:00:49 --> Router Class Initialized
INFO - 2023-09-06 23:00:49 --> Output Class Initialized
INFO - 2023-09-06 23:00:49 --> Security Class Initialized
DEBUG - 2023-09-06 23:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 23:00:49 --> Input Class Initialized
INFO - 2023-09-06 23:00:49 --> Language Class Initialized
INFO - 2023-09-06 23:00:49 --> Loader Class Initialized
INFO - 2023-09-06 23:00:49 --> Helper loaded: url_helper
INFO - 2023-09-06 23:00:49 --> Helper loaded: form_helper
INFO - 2023-09-06 23:00:49 --> Helper loaded: file_helper
INFO - 2023-09-06 23:00:49 --> Database Driver Class Initialized
DEBUG - 2023-09-06 23:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 23:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 23:00:49 --> Form Validation Class Initialized
INFO - 2023-09-06 23:00:49 --> Upload Class Initialized
INFO - 2023-09-06 23:00:49 --> Model "M_auth" initialized
INFO - 2023-09-06 23:00:49 --> Model "M_user" initialized
INFO - 2023-09-06 23:00:49 --> Model "M_produk" initialized
INFO - 2023-09-06 23:00:49 --> Controller Class Initialized
INFO - 2023-09-06 23:00:49 --> Model "M_pelanggan" initialized
INFO - 2023-09-06 23:00:49 --> Model "M_produk" initialized
DEBUG - 2023-09-06 23:00:49 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 23:00:49 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-09-06 23:00:49 --> Model "M_transaksi" initialized
INFO - 2023-09-06 23:00:49 --> Model "M_bank" initialized
INFO - 2023-09-06 23:00:50 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_all_bank.php
INFO - 2023-09-06 23:00:50 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-09-06 23:00:50 --> Final output sent to browser
DEBUG - 2023-09-06 23:00:50 --> Total execution time: 0.4675
INFO - 2023-09-06 23:00:54 --> Config Class Initialized
INFO - 2023-09-06 23:00:54 --> Hooks Class Initialized
DEBUG - 2023-09-06 23:00:54 --> UTF-8 Support Enabled
INFO - 2023-09-06 23:00:54 --> Utf8 Class Initialized
INFO - 2023-09-06 23:00:54 --> URI Class Initialized
INFO - 2023-09-06 23:00:54 --> Router Class Initialized
INFO - 2023-09-06 23:00:54 --> Output Class Initialized
INFO - 2023-09-06 23:00:54 --> Security Class Initialized
DEBUG - 2023-09-06 23:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 23:00:54 --> Input Class Initialized
INFO - 2023-09-06 23:00:54 --> Language Class Initialized
INFO - 2023-09-06 23:00:54 --> Loader Class Initialized
INFO - 2023-09-06 23:00:54 --> Helper loaded: url_helper
INFO - 2023-09-06 23:00:54 --> Helper loaded: form_helper
INFO - 2023-09-06 23:00:54 --> Helper loaded: file_helper
INFO - 2023-09-06 23:00:54 --> Database Driver Class Initialized
DEBUG - 2023-09-06 23:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 23:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 23:00:54 --> Form Validation Class Initialized
INFO - 2023-09-06 23:00:54 --> Upload Class Initialized
INFO - 2023-09-06 23:00:54 --> Model "M_auth" initialized
INFO - 2023-09-06 23:00:54 --> Model "M_user" initialized
INFO - 2023-09-06 23:00:54 --> Model "M_produk" initialized
INFO - 2023-09-06 23:00:54 --> Controller Class Initialized
INFO - 2023-09-06 23:00:54 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_user_profile.php
INFO - 2023-09-06 23:00:54 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-09-06 23:00:54 --> Final output sent to browser
DEBUG - 2023-09-06 23:00:54 --> Total execution time: 0.1408
INFO - 2023-09-06 23:00:58 --> Config Class Initialized
INFO - 2023-09-06 23:00:58 --> Hooks Class Initialized
DEBUG - 2023-09-06 23:00:58 --> UTF-8 Support Enabled
INFO - 2023-09-06 23:00:58 --> Utf8 Class Initialized
INFO - 2023-09-06 23:00:58 --> URI Class Initialized
INFO - 2023-09-06 23:00:58 --> Router Class Initialized
INFO - 2023-09-06 23:00:58 --> Output Class Initialized
INFO - 2023-09-06 23:00:58 --> Security Class Initialized
DEBUG - 2023-09-06 23:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 23:00:58 --> Input Class Initialized
INFO - 2023-09-06 23:00:58 --> Language Class Initialized
INFO - 2023-09-06 23:00:58 --> Loader Class Initialized
INFO - 2023-09-06 23:00:58 --> Helper loaded: url_helper
INFO - 2023-09-06 23:00:58 --> Helper loaded: form_helper
INFO - 2023-09-06 23:00:58 --> Helper loaded: file_helper
INFO - 2023-09-06 23:00:58 --> Database Driver Class Initialized
DEBUG - 2023-09-06 23:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 23:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 23:00:58 --> Form Validation Class Initialized
INFO - 2023-09-06 23:00:58 --> Upload Class Initialized
INFO - 2023-09-06 23:00:58 --> Model "M_auth" initialized
INFO - 2023-09-06 23:00:58 --> Model "M_user" initialized
INFO - 2023-09-06 23:00:58 --> Model "M_produk" initialized
INFO - 2023-09-06 23:00:58 --> Controller Class Initialized
INFO - 2023-09-06 23:00:59 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_user.php
INFO - 2023-09-06 23:00:59 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-09-06 23:00:59 --> Final output sent to browser
DEBUG - 2023-09-06 23:00:59 --> Total execution time: 0.3685
INFO - 2023-09-06 23:01:07 --> Config Class Initialized
INFO - 2023-09-06 23:01:07 --> Hooks Class Initialized
DEBUG - 2023-09-06 23:01:07 --> UTF-8 Support Enabled
INFO - 2023-09-06 23:01:07 --> Utf8 Class Initialized
INFO - 2023-09-06 23:01:07 --> URI Class Initialized
INFO - 2023-09-06 23:01:07 --> Router Class Initialized
INFO - 2023-09-06 23:01:07 --> Output Class Initialized
INFO - 2023-09-06 23:01:07 --> Security Class Initialized
DEBUG - 2023-09-06 23:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 23:01:07 --> Input Class Initialized
INFO - 2023-09-06 23:01:07 --> Language Class Initialized
INFO - 2023-09-06 23:01:07 --> Loader Class Initialized
INFO - 2023-09-06 23:01:07 --> Helper loaded: url_helper
INFO - 2023-09-06 23:01:07 --> Helper loaded: form_helper
INFO - 2023-09-06 23:01:07 --> Helper loaded: file_helper
INFO - 2023-09-06 23:01:07 --> Database Driver Class Initialized
DEBUG - 2023-09-06 23:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 23:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 23:01:07 --> Form Validation Class Initialized
INFO - 2023-09-06 23:01:07 --> Upload Class Initialized
INFO - 2023-09-06 23:01:07 --> Model "M_auth" initialized
INFO - 2023-09-06 23:01:07 --> Model "M_user" initialized
INFO - 2023-09-06 23:01:07 --> Model "M_produk" initialized
INFO - 2023-09-06 23:01:07 --> Controller Class Initialized
INFO - 2023-09-06 23:01:07 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_ganti_password.php
INFO - 2023-09-06 23:01:07 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-09-06 23:01:07 --> Final output sent to browser
DEBUG - 2023-09-06 23:01:07 --> Total execution time: 0.2878
INFO - 2023-09-06 23:01:23 --> Config Class Initialized
INFO - 2023-09-06 23:01:23 --> Hooks Class Initialized
DEBUG - 2023-09-06 23:01:23 --> UTF-8 Support Enabled
INFO - 2023-09-06 23:01:23 --> Utf8 Class Initialized
INFO - 2023-09-06 23:01:23 --> URI Class Initialized
INFO - 2023-09-06 23:01:23 --> Router Class Initialized
INFO - 2023-09-06 23:01:23 --> Output Class Initialized
INFO - 2023-09-06 23:01:23 --> Security Class Initialized
DEBUG - 2023-09-06 23:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 23:01:23 --> Input Class Initialized
INFO - 2023-09-06 23:01:23 --> Language Class Initialized
INFO - 2023-09-06 23:01:23 --> Loader Class Initialized
INFO - 2023-09-06 23:01:23 --> Helper loaded: url_helper
INFO - 2023-09-06 23:01:23 --> Helper loaded: form_helper
INFO - 2023-09-06 23:01:23 --> Helper loaded: file_helper
INFO - 2023-09-06 23:01:23 --> Database Driver Class Initialized
DEBUG - 2023-09-06 23:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 23:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 23:01:24 --> Form Validation Class Initialized
INFO - 2023-09-06 23:01:24 --> Upload Class Initialized
INFO - 2023-09-06 23:01:24 --> Model "M_auth" initialized
INFO - 2023-09-06 23:01:24 --> Model "M_user" initialized
INFO - 2023-09-06 23:01:24 --> Model "M_produk" initialized
INFO - 2023-09-06 23:01:24 --> Controller Class Initialized
INFO - 2023-09-06 23:01:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-06 23:01:24 --> Config Class Initialized
INFO - 2023-09-06 23:01:24 --> Hooks Class Initialized
DEBUG - 2023-09-06 23:01:24 --> UTF-8 Support Enabled
INFO - 2023-09-06 23:01:24 --> Utf8 Class Initialized
INFO - 2023-09-06 23:01:24 --> URI Class Initialized
INFO - 2023-09-06 23:01:24 --> Router Class Initialized
INFO - 2023-09-06 23:01:24 --> Output Class Initialized
INFO - 2023-09-06 23:01:24 --> Security Class Initialized
DEBUG - 2023-09-06 23:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 23:01:24 --> Input Class Initialized
INFO - 2023-09-06 23:01:24 --> Language Class Initialized
INFO - 2023-09-06 23:01:24 --> Loader Class Initialized
INFO - 2023-09-06 23:01:24 --> Helper loaded: url_helper
INFO - 2023-09-06 23:01:24 --> Helper loaded: form_helper
INFO - 2023-09-06 23:01:24 --> Helper loaded: file_helper
INFO - 2023-09-06 23:01:24 --> Database Driver Class Initialized
DEBUG - 2023-09-06 23:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 23:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 23:01:24 --> Form Validation Class Initialized
INFO - 2023-09-06 23:01:24 --> Upload Class Initialized
INFO - 2023-09-06 23:01:24 --> Model "M_auth" initialized
INFO - 2023-09-06 23:01:24 --> Model "M_user" initialized
INFO - 2023-09-06 23:01:24 --> Model "M_produk" initialized
INFO - 2023-09-06 23:01:24 --> Controller Class Initialized
INFO - 2023-09-06 23:01:24 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_user_profile.php
INFO - 2023-09-06 23:01:24 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-09-06 23:01:24 --> Final output sent to browser
DEBUG - 2023-09-06 23:01:24 --> Total execution time: 0.1588
INFO - 2023-09-06 23:01:33 --> Config Class Initialized
INFO - 2023-09-06 23:01:33 --> Hooks Class Initialized
DEBUG - 2023-09-06 23:01:33 --> UTF-8 Support Enabled
INFO - 2023-09-06 23:01:33 --> Utf8 Class Initialized
INFO - 2023-09-06 23:01:33 --> URI Class Initialized
INFO - 2023-09-06 23:01:33 --> Router Class Initialized
INFO - 2023-09-06 23:01:33 --> Output Class Initialized
INFO - 2023-09-06 23:01:33 --> Security Class Initialized
DEBUG - 2023-09-06 23:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 23:01:33 --> Input Class Initialized
INFO - 2023-09-06 23:01:33 --> Language Class Initialized
INFO - 2023-09-06 23:01:33 --> Loader Class Initialized
INFO - 2023-09-06 23:01:33 --> Helper loaded: url_helper
INFO - 2023-09-06 23:01:33 --> Helper loaded: form_helper
INFO - 2023-09-06 23:01:33 --> Helper loaded: file_helper
INFO - 2023-09-06 23:01:33 --> Database Driver Class Initialized
DEBUG - 2023-09-06 23:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 23:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 23:01:33 --> Form Validation Class Initialized
INFO - 2023-09-06 23:01:33 --> Upload Class Initialized
INFO - 2023-09-06 23:01:33 --> Model "M_auth" initialized
INFO - 2023-09-06 23:01:33 --> Model "M_user" initialized
INFO - 2023-09-06 23:01:33 --> Model "M_produk" initialized
INFO - 2023-09-06 23:01:33 --> Controller Class Initialized
INFO - 2023-09-06 23:01:33 --> Config Class Initialized
INFO - 2023-09-06 23:01:33 --> Hooks Class Initialized
DEBUG - 2023-09-06 23:01:33 --> UTF-8 Support Enabled
INFO - 2023-09-06 23:01:33 --> Utf8 Class Initialized
INFO - 2023-09-06 23:01:33 --> URI Class Initialized
INFO - 2023-09-06 23:01:33 --> Router Class Initialized
INFO - 2023-09-06 23:01:33 --> Output Class Initialized
INFO - 2023-09-06 23:01:33 --> Security Class Initialized
DEBUG - 2023-09-06 23:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 23:01:34 --> Input Class Initialized
INFO - 2023-09-06 23:01:34 --> Language Class Initialized
INFO - 2023-09-06 23:01:34 --> Loader Class Initialized
INFO - 2023-09-06 23:01:34 --> Helper loaded: url_helper
INFO - 2023-09-06 23:01:34 --> Helper loaded: form_helper
INFO - 2023-09-06 23:01:34 --> Helper loaded: file_helper
INFO - 2023-09-06 23:01:34 --> Database Driver Class Initialized
DEBUG - 2023-09-06 23:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 23:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 23:01:34 --> Form Validation Class Initialized
INFO - 2023-09-06 23:01:34 --> Upload Class Initialized
INFO - 2023-09-06 23:01:34 --> Model "M_auth" initialized
INFO - 2023-09-06 23:01:34 --> Model "M_user" initialized
INFO - 2023-09-06 23:01:34 --> Model "M_produk" initialized
INFO - 2023-09-06 23:01:34 --> Controller Class Initialized
INFO - 2023-09-06 23:01:34 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-09-06 23:01:34 --> Final output sent to browser
DEBUG - 2023-09-06 23:01:34 --> Total execution time: 0.1196
INFO - 2023-09-06 23:01:41 --> Config Class Initialized
INFO - 2023-09-06 23:01:41 --> Hooks Class Initialized
DEBUG - 2023-09-06 23:01:41 --> UTF-8 Support Enabled
INFO - 2023-09-06 23:01:41 --> Utf8 Class Initialized
INFO - 2023-09-06 23:01:41 --> URI Class Initialized
INFO - 2023-09-06 23:01:41 --> Router Class Initialized
INFO - 2023-09-06 23:01:41 --> Output Class Initialized
INFO - 2023-09-06 23:01:41 --> Security Class Initialized
DEBUG - 2023-09-06 23:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 23:01:41 --> Input Class Initialized
INFO - 2023-09-06 23:01:41 --> Language Class Initialized
INFO - 2023-09-06 23:01:41 --> Loader Class Initialized
INFO - 2023-09-06 23:01:41 --> Helper loaded: url_helper
INFO - 2023-09-06 23:01:41 --> Helper loaded: form_helper
INFO - 2023-09-06 23:01:41 --> Helper loaded: file_helper
INFO - 2023-09-06 23:01:41 --> Database Driver Class Initialized
DEBUG - 2023-09-06 23:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 23:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 23:01:41 --> Form Validation Class Initialized
INFO - 2023-09-06 23:01:41 --> Upload Class Initialized
INFO - 2023-09-06 23:01:41 --> Model "M_auth" initialized
INFO - 2023-09-06 23:01:41 --> Model "M_user" initialized
INFO - 2023-09-06 23:01:41 --> Model "M_produk" initialized
INFO - 2023-09-06 23:01:41 --> Controller Class Initialized
INFO - 2023-09-06 23:01:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-06 23:01:41 --> Config Class Initialized
INFO - 2023-09-06 23:01:41 --> Hooks Class Initialized
DEBUG - 2023-09-06 23:01:41 --> UTF-8 Support Enabled
INFO - 2023-09-06 23:01:41 --> Utf8 Class Initialized
INFO - 2023-09-06 23:01:41 --> URI Class Initialized
INFO - 2023-09-06 23:01:41 --> Router Class Initialized
INFO - 2023-09-06 23:01:41 --> Output Class Initialized
INFO - 2023-09-06 23:01:41 --> Security Class Initialized
DEBUG - 2023-09-06 23:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 23:01:41 --> Input Class Initialized
INFO - 2023-09-06 23:01:41 --> Language Class Initialized
INFO - 2023-09-06 23:01:41 --> Loader Class Initialized
INFO - 2023-09-06 23:01:41 --> Helper loaded: url_helper
INFO - 2023-09-06 23:01:41 --> Helper loaded: form_helper
INFO - 2023-09-06 23:01:41 --> Helper loaded: file_helper
INFO - 2023-09-06 23:01:41 --> Database Driver Class Initialized
DEBUG - 2023-09-06 23:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 23:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 23:01:41 --> Form Validation Class Initialized
INFO - 2023-09-06 23:01:41 --> Upload Class Initialized
INFO - 2023-09-06 23:01:41 --> Model "M_auth" initialized
INFO - 2023-09-06 23:01:41 --> Model "M_user" initialized
INFO - 2023-09-06 23:01:41 --> Model "M_produk" initialized
INFO - 2023-09-06 23:01:41 --> Controller Class Initialized
INFO - 2023-09-06 23:01:41 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-09-06 23:01:41 --> Final output sent to browser
DEBUG - 2023-09-06 23:01:41 --> Total execution time: 0.1259
INFO - 2023-09-06 23:01:48 --> Config Class Initialized
INFO - 2023-09-06 23:01:48 --> Hooks Class Initialized
DEBUG - 2023-09-06 23:01:48 --> UTF-8 Support Enabled
INFO - 2023-09-06 23:01:48 --> Utf8 Class Initialized
INFO - 2023-09-06 23:01:48 --> URI Class Initialized
INFO - 2023-09-06 23:01:48 --> Router Class Initialized
INFO - 2023-09-06 23:01:48 --> Output Class Initialized
INFO - 2023-09-06 23:01:48 --> Security Class Initialized
DEBUG - 2023-09-06 23:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 23:01:48 --> Input Class Initialized
INFO - 2023-09-06 23:01:48 --> Language Class Initialized
INFO - 2023-09-06 23:01:48 --> Loader Class Initialized
INFO - 2023-09-06 23:01:48 --> Helper loaded: url_helper
INFO - 2023-09-06 23:01:48 --> Helper loaded: form_helper
INFO - 2023-09-06 23:01:48 --> Helper loaded: file_helper
INFO - 2023-09-06 23:01:48 --> Database Driver Class Initialized
DEBUG - 2023-09-06 23:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 23:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 23:01:48 --> Form Validation Class Initialized
INFO - 2023-09-06 23:01:48 --> Upload Class Initialized
INFO - 2023-09-06 23:01:48 --> Model "M_auth" initialized
INFO - 2023-09-06 23:01:48 --> Model "M_user" initialized
INFO - 2023-09-06 23:01:48 --> Model "M_produk" initialized
INFO - 2023-09-06 23:01:48 --> Controller Class Initialized
INFO - 2023-09-06 23:01:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-06 23:01:48 --> Config Class Initialized
INFO - 2023-09-06 23:01:48 --> Hooks Class Initialized
DEBUG - 2023-09-06 23:01:48 --> UTF-8 Support Enabled
INFO - 2023-09-06 23:01:48 --> Utf8 Class Initialized
INFO - 2023-09-06 23:01:48 --> URI Class Initialized
INFO - 2023-09-06 23:01:48 --> Router Class Initialized
INFO - 2023-09-06 23:01:48 --> Output Class Initialized
INFO - 2023-09-06 23:01:48 --> Security Class Initialized
DEBUG - 2023-09-06 23:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 23:01:48 --> Input Class Initialized
INFO - 2023-09-06 23:01:48 --> Language Class Initialized
INFO - 2023-09-06 23:01:48 --> Loader Class Initialized
INFO - 2023-09-06 23:01:48 --> Helper loaded: url_helper
INFO - 2023-09-06 23:01:48 --> Helper loaded: form_helper
INFO - 2023-09-06 23:01:48 --> Helper loaded: file_helper
INFO - 2023-09-06 23:01:49 --> Database Driver Class Initialized
DEBUG - 2023-09-06 23:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 23:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 23:01:49 --> Form Validation Class Initialized
INFO - 2023-09-06 23:01:49 --> Upload Class Initialized
INFO - 2023-09-06 23:01:49 --> Model "M_auth" initialized
INFO - 2023-09-06 23:01:49 --> Model "M_user" initialized
INFO - 2023-09-06 23:01:49 --> Model "M_produk" initialized
INFO - 2023-09-06 23:01:49 --> Controller Class Initialized
INFO - 2023-09-06 23:01:49 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-09-06 23:01:49 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-09-06 23:01:49 --> Final output sent to browser
DEBUG - 2023-09-06 23:01:49 --> Total execution time: 0.1957
INFO - 2023-09-06 23:02:02 --> Config Class Initialized
INFO - 2023-09-06 23:02:02 --> Hooks Class Initialized
DEBUG - 2023-09-06 23:02:02 --> UTF-8 Support Enabled
INFO - 2023-09-06 23:02:02 --> Utf8 Class Initialized
INFO - 2023-09-06 23:02:02 --> URI Class Initialized
INFO - 2023-09-06 23:02:02 --> Router Class Initialized
INFO - 2023-09-06 23:02:02 --> Output Class Initialized
INFO - 2023-09-06 23:02:02 --> Security Class Initialized
DEBUG - 2023-09-06 23:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 23:02:02 --> Input Class Initialized
INFO - 2023-09-06 23:02:02 --> Language Class Initialized
INFO - 2023-09-06 23:02:02 --> Loader Class Initialized
INFO - 2023-09-06 23:02:02 --> Helper loaded: url_helper
INFO - 2023-09-06 23:02:02 --> Helper loaded: form_helper
INFO - 2023-09-06 23:02:02 --> Helper loaded: file_helper
INFO - 2023-09-06 23:02:02 --> Database Driver Class Initialized
DEBUG - 2023-09-06 23:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 23:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 23:02:02 --> Form Validation Class Initialized
INFO - 2023-09-06 23:02:02 --> Upload Class Initialized
INFO - 2023-09-06 23:02:02 --> Model "M_auth" initialized
INFO - 2023-09-06 23:02:02 --> Model "M_user" initialized
INFO - 2023-09-06 23:02:02 --> Model "M_produk" initialized
INFO - 2023-09-06 23:02:02 --> Controller Class Initialized
INFO - 2023-09-06 23:02:02 --> Model "M_produk" initialized
INFO - 2023-09-06 23:02:02 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-09-06 23:02:02 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-09-06 23:02:02 --> Final output sent to browser
DEBUG - 2023-09-06 23:02:02 --> Total execution time: 0.4604
INFO - 2023-09-06 23:02:09 --> Config Class Initialized
INFO - 2023-09-06 23:02:09 --> Hooks Class Initialized
DEBUG - 2023-09-06 23:02:09 --> UTF-8 Support Enabled
INFO - 2023-09-06 23:02:09 --> Utf8 Class Initialized
INFO - 2023-09-06 23:02:09 --> URI Class Initialized
INFO - 2023-09-06 23:02:09 --> Router Class Initialized
INFO - 2023-09-06 23:02:09 --> Output Class Initialized
INFO - 2023-09-06 23:02:09 --> Security Class Initialized
DEBUG - 2023-09-06 23:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 23:02:09 --> Input Class Initialized
INFO - 2023-09-06 23:02:09 --> Language Class Initialized
INFO - 2023-09-06 23:02:09 --> Loader Class Initialized
INFO - 2023-09-06 23:02:09 --> Helper loaded: url_helper
INFO - 2023-09-06 23:02:09 --> Helper loaded: form_helper
INFO - 2023-09-06 23:02:09 --> Helper loaded: file_helper
INFO - 2023-09-06 23:02:09 --> Database Driver Class Initialized
DEBUG - 2023-09-06 23:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 23:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 23:02:09 --> Form Validation Class Initialized
INFO - 2023-09-06 23:02:09 --> Upload Class Initialized
INFO - 2023-09-06 23:02:09 --> Model "M_auth" initialized
INFO - 2023-09-06 23:02:09 --> Model "M_user" initialized
INFO - 2023-09-06 23:02:09 --> Model "M_produk" initialized
INFO - 2023-09-06 23:02:09 --> Controller Class Initialized
INFO - 2023-09-06 23:02:09 --> Model "M_pelanggan" initialized
INFO - 2023-09-06 23:02:09 --> Model "M_produk" initialized
DEBUG - 2023-09-06 23:02:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 23:02:09 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-09-06 23:02:09 --> Model "M_transaksi" initialized
INFO - 2023-09-06 23:02:10 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_transaksi_all.php
INFO - 2023-09-06 23:02:10 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-09-06 23:02:10 --> Final output sent to browser
DEBUG - 2023-09-06 23:02:10 --> Total execution time: 0.6120
INFO - 2023-09-06 23:02:13 --> Config Class Initialized
INFO - 2023-09-06 23:02:13 --> Hooks Class Initialized
DEBUG - 2023-09-06 23:02:13 --> UTF-8 Support Enabled
INFO - 2023-09-06 23:02:13 --> Utf8 Class Initialized
INFO - 2023-09-06 23:02:13 --> URI Class Initialized
INFO - 2023-09-06 23:02:13 --> Router Class Initialized
INFO - 2023-09-06 23:02:13 --> Output Class Initialized
INFO - 2023-09-06 23:02:13 --> Security Class Initialized
DEBUG - 2023-09-06 23:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 23:02:13 --> Input Class Initialized
INFO - 2023-09-06 23:02:13 --> Language Class Initialized
INFO - 2023-09-06 23:02:13 --> Loader Class Initialized
INFO - 2023-09-06 23:02:13 --> Helper loaded: url_helper
INFO - 2023-09-06 23:02:13 --> Helper loaded: form_helper
INFO - 2023-09-06 23:02:13 --> Helper loaded: file_helper
INFO - 2023-09-06 23:02:13 --> Database Driver Class Initialized
DEBUG - 2023-09-06 23:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 23:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 23:02:13 --> Form Validation Class Initialized
INFO - 2023-09-06 23:02:13 --> Upload Class Initialized
INFO - 2023-09-06 23:02:13 --> Model "M_auth" initialized
INFO - 2023-09-06 23:02:13 --> Model "M_user" initialized
INFO - 2023-09-06 23:02:13 --> Model "M_produk" initialized
INFO - 2023-09-06 23:02:13 --> Controller Class Initialized
INFO - 2023-09-06 23:02:13 --> Model "M_pelanggan" initialized
INFO - 2023-09-06 23:02:13 --> Model "M_produk" initialized
DEBUG - 2023-09-06 23:02:13 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 23:02:13 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-09-06 23:02:13 --> Model "M_transaksi" initialized
INFO - 2023-09-06 23:02:13 --> Model "M_bank" initialized
INFO - 2023-09-06 23:02:13 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_all_bank.php
INFO - 2023-09-06 23:02:13 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-09-06 23:02:13 --> Final output sent to browser
DEBUG - 2023-09-06 23:02:13 --> Total execution time: 0.1711
INFO - 2023-09-06 23:02:16 --> Config Class Initialized
INFO - 2023-09-06 23:02:16 --> Hooks Class Initialized
DEBUG - 2023-09-06 23:02:16 --> UTF-8 Support Enabled
INFO - 2023-09-06 23:02:16 --> Utf8 Class Initialized
INFO - 2023-09-06 23:02:16 --> URI Class Initialized
INFO - 2023-09-06 23:02:16 --> Router Class Initialized
INFO - 2023-09-06 23:02:16 --> Output Class Initialized
INFO - 2023-09-06 23:02:16 --> Security Class Initialized
DEBUG - 2023-09-06 23:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 23:02:16 --> Input Class Initialized
INFO - 2023-09-06 23:02:16 --> Language Class Initialized
INFO - 2023-09-06 23:02:16 --> Loader Class Initialized
INFO - 2023-09-06 23:02:16 --> Helper loaded: url_helper
INFO - 2023-09-06 23:02:16 --> Helper loaded: form_helper
INFO - 2023-09-06 23:02:16 --> Helper loaded: file_helper
INFO - 2023-09-06 23:02:16 --> Database Driver Class Initialized
DEBUG - 2023-09-06 23:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 23:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 23:02:16 --> Form Validation Class Initialized
INFO - 2023-09-06 23:02:16 --> Upload Class Initialized
INFO - 2023-09-06 23:02:16 --> Model "M_auth" initialized
INFO - 2023-09-06 23:02:16 --> Model "M_user" initialized
INFO - 2023-09-06 23:02:16 --> Model "M_produk" initialized
INFO - 2023-09-06 23:02:16 --> Controller Class Initialized
INFO - 2023-09-06 23:02:16 --> Model "M_pelanggan" initialized
INFO - 2023-09-06 23:02:16 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_pelanggan.php
INFO - 2023-09-06 23:02:16 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-09-06 23:02:16 --> Final output sent to browser
DEBUG - 2023-09-06 23:02:16 --> Total execution time: 0.2027
INFO - 2023-09-06 23:02:19 --> Config Class Initialized
INFO - 2023-09-06 23:02:19 --> Hooks Class Initialized
DEBUG - 2023-09-06 23:02:19 --> UTF-8 Support Enabled
INFO - 2023-09-06 23:02:19 --> Utf8 Class Initialized
INFO - 2023-09-06 23:02:19 --> URI Class Initialized
INFO - 2023-09-06 23:02:19 --> Router Class Initialized
INFO - 2023-09-06 23:02:19 --> Output Class Initialized
INFO - 2023-09-06 23:02:19 --> Security Class Initialized
DEBUG - 2023-09-06 23:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-06 23:02:19 --> Input Class Initialized
INFO - 2023-09-06 23:02:19 --> Language Class Initialized
INFO - 2023-09-06 23:02:19 --> Loader Class Initialized
INFO - 2023-09-06 23:02:19 --> Helper loaded: url_helper
INFO - 2023-09-06 23:02:19 --> Helper loaded: form_helper
INFO - 2023-09-06 23:02:19 --> Helper loaded: file_helper
INFO - 2023-09-06 23:02:19 --> Database Driver Class Initialized
DEBUG - 2023-09-06 23:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-06 23:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-06 23:02:19 --> Form Validation Class Initialized
INFO - 2023-09-06 23:02:19 --> Upload Class Initialized
INFO - 2023-09-06 23:02:19 --> Model "M_auth" initialized
INFO - 2023-09-06 23:02:19 --> Model "M_user" initialized
INFO - 2023-09-06 23:02:19 --> Model "M_produk" initialized
INFO - 2023-09-06 23:02:19 --> Controller Class Initialized
INFO - 2023-09-06 23:02:19 --> Model "M_pesan" initialized
INFO - 2023-09-06 23:02:19 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_pengaduan.php
INFO - 2023-09-06 23:02:19 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-09-06 23:02:19 --> Final output sent to browser
DEBUG - 2023-09-06 23:02:19 --> Total execution time: 0.4346
