<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-30 14:48:05 --> Config Class Initialized
INFO - 2023-05-30 14:48:05 --> Hooks Class Initialized
DEBUG - 2023-05-30 14:48:05 --> UTF-8 Support Enabled
INFO - 2023-05-30 14:48:05 --> Utf8 Class Initialized
INFO - 2023-05-30 14:48:05 --> URI Class Initialized
INFO - 2023-05-30 14:48:05 --> Router Class Initialized
INFO - 2023-05-30 14:48:05 --> Output Class Initialized
INFO - 2023-05-30 14:48:05 --> Security Class Initialized
DEBUG - 2023-05-30 14:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-30 14:48:05 --> Input Class Initialized
INFO - 2023-05-30 14:48:05 --> Language Class Initialized
INFO - 2023-05-30 14:48:06 --> Loader Class Initialized
INFO - 2023-05-30 14:48:06 --> Helper loaded: url_helper
INFO - 2023-05-30 14:48:06 --> Helper loaded: form_helper
INFO - 2023-05-30 14:48:06 --> Helper loaded: file_helper
INFO - 2023-05-30 14:48:06 --> Database Driver Class Initialized
DEBUG - 2023-05-30 14:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-30 14:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-30 14:48:06 --> Form Validation Class Initialized
INFO - 2023-05-30 14:48:06 --> Upload Class Initialized
INFO - 2023-05-30 14:48:06 --> Model "M_auth" initialized
INFO - 2023-05-30 14:48:06 --> Model "M_user" initialized
INFO - 2023-05-30 14:48:06 --> Model "M_produk" initialized
INFO - 2023-05-30 14:48:06 --> Controller Class Initialized
INFO - 2023-05-30 14:48:06 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-05-30 14:48:06 --> Final output sent to browser
DEBUG - 2023-05-30 14:48:06 --> Total execution time: 1.3411
INFO - 2023-05-30 14:48:12 --> Config Class Initialized
INFO - 2023-05-30 14:48:12 --> Hooks Class Initialized
DEBUG - 2023-05-30 14:48:12 --> UTF-8 Support Enabled
INFO - 2023-05-30 14:48:12 --> Utf8 Class Initialized
INFO - 2023-05-30 14:48:12 --> URI Class Initialized
DEBUG - 2023-05-30 14:48:12 --> No URI present. Default controller set.
INFO - 2023-05-30 14:48:12 --> Router Class Initialized
INFO - 2023-05-30 14:48:12 --> Output Class Initialized
INFO - 2023-05-30 14:48:12 --> Security Class Initialized
DEBUG - 2023-05-30 14:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-30 14:48:12 --> Input Class Initialized
INFO - 2023-05-30 14:48:12 --> Language Class Initialized
INFO - 2023-05-30 14:48:12 --> Loader Class Initialized
INFO - 2023-05-30 14:48:12 --> Helper loaded: url_helper
INFO - 2023-05-30 14:48:12 --> Helper loaded: form_helper
INFO - 2023-05-30 14:48:12 --> Helper loaded: file_helper
INFO - 2023-05-30 14:48:12 --> Database Driver Class Initialized
DEBUG - 2023-05-30 14:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-30 14:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-30 14:48:12 --> Form Validation Class Initialized
INFO - 2023-05-30 14:48:12 --> Upload Class Initialized
INFO - 2023-05-30 14:48:12 --> Model "M_auth" initialized
INFO - 2023-05-30 14:48:12 --> Model "M_user" initialized
INFO - 2023-05-30 14:48:12 --> Model "M_produk" initialized
INFO - 2023-05-30 14:48:12 --> Controller Class Initialized
INFO - 2023-05-30 14:48:12 --> Model "M_pelanggan" initialized
INFO - 2023-05-30 14:48:12 --> Model "M_produk" initialized
DEBUG - 2023-05-30 14:48:12 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-30 14:48:12 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-30 14:48:12 --> Model "M_transaksi" initialized
INFO - 2023-05-30 14:48:12 --> Model "M_bank" initialized
INFO - 2023-05-30 14:48:12 --> Model "M_pesan" initialized
INFO - 2023-05-30 14:48:13 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-05-30 14:48:13 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-05-30 14:48:13 --> Final output sent to browser
DEBUG - 2023-05-30 14:48:13 --> Total execution time: 0.4239
INFO - 2023-05-30 15:00:02 --> Config Class Initialized
INFO - 2023-05-30 15:00:02 --> Hooks Class Initialized
DEBUG - 2023-05-30 15:00:02 --> UTF-8 Support Enabled
INFO - 2023-05-30 15:00:02 --> Utf8 Class Initialized
INFO - 2023-05-30 15:00:02 --> URI Class Initialized
INFO - 2023-05-30 15:00:02 --> Router Class Initialized
INFO - 2023-05-30 15:00:02 --> Output Class Initialized
INFO - 2023-05-30 15:00:02 --> Security Class Initialized
DEBUG - 2023-05-30 15:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-30 15:00:02 --> Input Class Initialized
INFO - 2023-05-30 15:00:02 --> Language Class Initialized
INFO - 2023-05-30 15:00:03 --> Loader Class Initialized
INFO - 2023-05-30 15:00:03 --> Helper loaded: url_helper
INFO - 2023-05-30 15:00:03 --> Helper loaded: form_helper
INFO - 2023-05-30 15:00:03 --> Helper loaded: file_helper
INFO - 2023-05-30 15:00:03 --> Database Driver Class Initialized
DEBUG - 2023-05-30 15:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-30 15:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-30 15:00:03 --> Form Validation Class Initialized
INFO - 2023-05-30 15:00:03 --> Upload Class Initialized
INFO - 2023-05-30 15:00:03 --> Model "M_auth" initialized
INFO - 2023-05-30 15:00:03 --> Model "M_user" initialized
INFO - 2023-05-30 15:00:03 --> Model "M_produk" initialized
INFO - 2023-05-30 15:00:03 --> Controller Class Initialized
INFO - 2023-05-30 15:00:03 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-05-30 15:00:03 --> Final output sent to browser
DEBUG - 2023-05-30 15:00:03 --> Total execution time: 0.1606
INFO - 2023-05-30 15:00:08 --> Config Class Initialized
INFO - 2023-05-30 15:00:08 --> Hooks Class Initialized
DEBUG - 2023-05-30 15:00:08 --> UTF-8 Support Enabled
INFO - 2023-05-30 15:00:08 --> Utf8 Class Initialized
INFO - 2023-05-30 15:00:08 --> URI Class Initialized
INFO - 2023-05-30 15:00:08 --> Router Class Initialized
INFO - 2023-05-30 15:00:08 --> Output Class Initialized
INFO - 2023-05-30 15:00:08 --> Security Class Initialized
DEBUG - 2023-05-30 15:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-30 15:00:08 --> Input Class Initialized
INFO - 2023-05-30 15:00:08 --> Language Class Initialized
INFO - 2023-05-30 15:00:08 --> Loader Class Initialized
INFO - 2023-05-30 15:00:08 --> Helper loaded: url_helper
INFO - 2023-05-30 15:00:08 --> Helper loaded: form_helper
INFO - 2023-05-30 15:00:08 --> Helper loaded: file_helper
INFO - 2023-05-30 15:00:08 --> Database Driver Class Initialized
DEBUG - 2023-05-30 15:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-30 15:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-30 15:00:08 --> Form Validation Class Initialized
INFO - 2023-05-30 15:00:08 --> Upload Class Initialized
INFO - 2023-05-30 15:00:08 --> Model "M_auth" initialized
INFO - 2023-05-30 15:00:08 --> Model "M_user" initialized
INFO - 2023-05-30 15:00:08 --> Model "M_produk" initialized
INFO - 2023-05-30 15:00:08 --> Controller Class Initialized
INFO - 2023-05-30 15:00:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-05-30 15:00:08 --> Config Class Initialized
INFO - 2023-05-30 15:00:08 --> Hooks Class Initialized
DEBUG - 2023-05-30 15:00:08 --> UTF-8 Support Enabled
INFO - 2023-05-30 15:00:08 --> Utf8 Class Initialized
INFO - 2023-05-30 15:00:08 --> URI Class Initialized
INFO - 2023-05-30 15:00:08 --> Router Class Initialized
INFO - 2023-05-30 15:00:08 --> Output Class Initialized
INFO - 2023-05-30 15:00:08 --> Security Class Initialized
DEBUG - 2023-05-30 15:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-30 15:00:08 --> Input Class Initialized
INFO - 2023-05-30 15:00:08 --> Language Class Initialized
INFO - 2023-05-30 15:00:08 --> Loader Class Initialized
INFO - 2023-05-30 15:00:08 --> Helper loaded: url_helper
INFO - 2023-05-30 15:00:08 --> Helper loaded: form_helper
INFO - 2023-05-30 15:00:08 --> Helper loaded: file_helper
INFO - 2023-05-30 15:00:08 --> Database Driver Class Initialized
DEBUG - 2023-05-30 15:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-30 15:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-30 15:00:08 --> Form Validation Class Initialized
INFO - 2023-05-30 15:00:08 --> Upload Class Initialized
INFO - 2023-05-30 15:00:08 --> Model "M_auth" initialized
INFO - 2023-05-30 15:00:08 --> Model "M_user" initialized
INFO - 2023-05-30 15:00:08 --> Model "M_produk" initialized
INFO - 2023-05-30 15:00:08 --> Controller Class Initialized
INFO - 2023-05-30 15:00:08 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-05-30 15:00:08 --> Final output sent to browser
DEBUG - 2023-05-30 15:00:08 --> Total execution time: 0.0835
INFO - 2023-05-30 15:00:17 --> Config Class Initialized
INFO - 2023-05-30 15:00:17 --> Hooks Class Initialized
DEBUG - 2023-05-30 15:00:17 --> UTF-8 Support Enabled
INFO - 2023-05-30 15:00:17 --> Utf8 Class Initialized
INFO - 2023-05-30 15:00:17 --> URI Class Initialized
INFO - 2023-05-30 15:00:17 --> Router Class Initialized
INFO - 2023-05-30 15:00:17 --> Output Class Initialized
INFO - 2023-05-30 15:00:17 --> Security Class Initialized
DEBUG - 2023-05-30 15:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-30 15:00:17 --> Input Class Initialized
INFO - 2023-05-30 15:00:17 --> Language Class Initialized
INFO - 2023-05-30 15:00:17 --> Loader Class Initialized
INFO - 2023-05-30 15:00:17 --> Helper loaded: url_helper
INFO - 2023-05-30 15:00:17 --> Helper loaded: form_helper
INFO - 2023-05-30 15:00:17 --> Helper loaded: file_helper
INFO - 2023-05-30 15:00:17 --> Database Driver Class Initialized
DEBUG - 2023-05-30 15:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-30 15:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-30 15:00:17 --> Form Validation Class Initialized
INFO - 2023-05-30 15:00:17 --> Upload Class Initialized
INFO - 2023-05-30 15:00:17 --> Model "M_auth" initialized
INFO - 2023-05-30 15:00:17 --> Model "M_user" initialized
INFO - 2023-05-30 15:00:17 --> Model "M_produk" initialized
INFO - 2023-05-30 15:00:17 --> Controller Class Initialized
INFO - 2023-05-30 15:00:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-05-30 15:00:17 --> Config Class Initialized
INFO - 2023-05-30 15:00:17 --> Hooks Class Initialized
DEBUG - 2023-05-30 15:00:17 --> UTF-8 Support Enabled
INFO - 2023-05-30 15:00:17 --> Utf8 Class Initialized
INFO - 2023-05-30 15:00:17 --> URI Class Initialized
INFO - 2023-05-30 15:00:17 --> Router Class Initialized
INFO - 2023-05-30 15:00:17 --> Output Class Initialized
INFO - 2023-05-30 15:00:17 --> Security Class Initialized
DEBUG - 2023-05-30 15:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-30 15:00:17 --> Input Class Initialized
INFO - 2023-05-30 15:00:17 --> Language Class Initialized
INFO - 2023-05-30 15:00:17 --> Loader Class Initialized
INFO - 2023-05-30 15:00:17 --> Helper loaded: url_helper
INFO - 2023-05-30 15:00:17 --> Helper loaded: form_helper
INFO - 2023-05-30 15:00:17 --> Helper loaded: file_helper
INFO - 2023-05-30 15:00:17 --> Database Driver Class Initialized
DEBUG - 2023-05-30 15:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-30 15:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-30 15:00:17 --> Form Validation Class Initialized
INFO - 2023-05-30 15:00:17 --> Upload Class Initialized
INFO - 2023-05-30 15:00:17 --> Model "M_auth" initialized
INFO - 2023-05-30 15:00:17 --> Model "M_user" initialized
INFO - 2023-05-30 15:00:17 --> Model "M_produk" initialized
INFO - 2023-05-30 15:00:17 --> Controller Class Initialized
INFO - 2023-05-30 15:00:17 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-05-30 15:00:17 --> Final output sent to browser
DEBUG - 2023-05-30 15:00:17 --> Total execution time: 0.0864
INFO - 2023-05-30 15:02:00 --> Config Class Initialized
INFO - 2023-05-30 15:02:00 --> Hooks Class Initialized
DEBUG - 2023-05-30 15:02:00 --> UTF-8 Support Enabled
INFO - 2023-05-30 15:02:00 --> Utf8 Class Initialized
INFO - 2023-05-30 15:02:00 --> URI Class Initialized
INFO - 2023-05-30 15:02:00 --> Router Class Initialized
INFO - 2023-05-30 15:02:00 --> Output Class Initialized
INFO - 2023-05-30 15:02:00 --> Security Class Initialized
DEBUG - 2023-05-30 15:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-30 15:02:00 --> Input Class Initialized
INFO - 2023-05-30 15:02:00 --> Language Class Initialized
INFO - 2023-05-30 15:02:00 --> Loader Class Initialized
INFO - 2023-05-30 15:02:00 --> Helper loaded: url_helper
INFO - 2023-05-30 15:02:00 --> Helper loaded: form_helper
INFO - 2023-05-30 15:02:00 --> Helper loaded: file_helper
INFO - 2023-05-30 15:02:00 --> Database Driver Class Initialized
DEBUG - 2023-05-30 15:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-30 15:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-30 15:02:00 --> Form Validation Class Initialized
INFO - 2023-05-30 15:02:00 --> Upload Class Initialized
INFO - 2023-05-30 15:02:00 --> Model "M_auth" initialized
INFO - 2023-05-30 15:02:00 --> Model "M_user" initialized
INFO - 2023-05-30 15:02:00 --> Model "M_produk" initialized
INFO - 2023-05-30 15:02:00 --> Controller Class Initialized
INFO - 2023-05-30 15:02:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-05-30 15:02:00 --> Config Class Initialized
INFO - 2023-05-30 15:02:00 --> Hooks Class Initialized
DEBUG - 2023-05-30 15:02:00 --> UTF-8 Support Enabled
INFO - 2023-05-30 15:02:00 --> Utf8 Class Initialized
INFO - 2023-05-30 15:02:00 --> URI Class Initialized
INFO - 2023-05-30 15:02:00 --> Router Class Initialized
INFO - 2023-05-30 15:02:00 --> Output Class Initialized
INFO - 2023-05-30 15:02:00 --> Security Class Initialized
DEBUG - 2023-05-30 15:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-30 15:02:00 --> Input Class Initialized
INFO - 2023-05-30 15:02:00 --> Language Class Initialized
INFO - 2023-05-30 15:02:00 --> Loader Class Initialized
INFO - 2023-05-30 15:02:00 --> Helper loaded: url_helper
INFO - 2023-05-30 15:02:00 --> Helper loaded: form_helper
INFO - 2023-05-30 15:02:00 --> Helper loaded: file_helper
INFO - 2023-05-30 15:02:00 --> Database Driver Class Initialized
DEBUG - 2023-05-30 15:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-30 15:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-30 15:02:00 --> Form Validation Class Initialized
INFO - 2023-05-30 15:02:00 --> Upload Class Initialized
INFO - 2023-05-30 15:02:00 --> Model "M_auth" initialized
INFO - 2023-05-30 15:02:00 --> Model "M_user" initialized
INFO - 2023-05-30 15:02:00 --> Model "M_produk" initialized
INFO - 2023-05-30 15:02:00 --> Controller Class Initialized
INFO - 2023-05-30 15:02:00 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-05-30 15:02:00 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-05-30 15:02:00 --> Final output sent to browser
DEBUG - 2023-05-30 15:02:00 --> Total execution time: 0.2503
INFO - 2023-05-30 15:02:19 --> Config Class Initialized
INFO - 2023-05-30 15:02:19 --> Hooks Class Initialized
DEBUG - 2023-05-30 15:02:19 --> UTF-8 Support Enabled
INFO - 2023-05-30 15:02:19 --> Utf8 Class Initialized
INFO - 2023-05-30 15:02:20 --> URI Class Initialized
INFO - 2023-05-30 15:02:20 --> Router Class Initialized
INFO - 2023-05-30 15:02:20 --> Output Class Initialized
INFO - 2023-05-30 15:02:20 --> Security Class Initialized
DEBUG - 2023-05-30 15:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-30 15:02:20 --> Input Class Initialized
INFO - 2023-05-30 15:02:20 --> Language Class Initialized
INFO - 2023-05-30 15:02:20 --> Loader Class Initialized
INFO - 2023-05-30 15:02:20 --> Helper loaded: url_helper
INFO - 2023-05-30 15:02:20 --> Helper loaded: form_helper
INFO - 2023-05-30 15:02:20 --> Helper loaded: file_helper
INFO - 2023-05-30 15:02:20 --> Database Driver Class Initialized
DEBUG - 2023-05-30 15:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-30 15:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-30 15:02:20 --> Form Validation Class Initialized
INFO - 2023-05-30 15:02:20 --> Upload Class Initialized
INFO - 2023-05-30 15:02:20 --> Model "M_auth" initialized
INFO - 2023-05-30 15:02:20 --> Model "M_user" initialized
INFO - 2023-05-30 15:02:20 --> Model "M_produk" initialized
INFO - 2023-05-30 15:02:20 --> Controller Class Initialized
INFO - 2023-05-30 15:02:20 --> Config Class Initialized
INFO - 2023-05-30 15:02:20 --> Hooks Class Initialized
DEBUG - 2023-05-30 15:02:20 --> UTF-8 Support Enabled
INFO - 2023-05-30 15:02:20 --> Utf8 Class Initialized
INFO - 2023-05-30 15:02:20 --> URI Class Initialized
INFO - 2023-05-30 15:02:20 --> Router Class Initialized
INFO - 2023-05-30 15:02:20 --> Output Class Initialized
INFO - 2023-05-30 15:02:20 --> Security Class Initialized
DEBUG - 2023-05-30 15:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-30 15:02:20 --> Input Class Initialized
INFO - 2023-05-30 15:02:20 --> Language Class Initialized
INFO - 2023-05-30 15:02:20 --> Loader Class Initialized
INFO - 2023-05-30 15:02:20 --> Helper loaded: url_helper
INFO - 2023-05-30 15:02:20 --> Helper loaded: form_helper
INFO - 2023-05-30 15:02:20 --> Helper loaded: file_helper
INFO - 2023-05-30 15:02:20 --> Database Driver Class Initialized
DEBUG - 2023-05-30 15:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-30 15:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-30 15:02:20 --> Form Validation Class Initialized
INFO - 2023-05-30 15:02:20 --> Upload Class Initialized
INFO - 2023-05-30 15:02:20 --> Model "M_auth" initialized
INFO - 2023-05-30 15:02:20 --> Model "M_user" initialized
INFO - 2023-05-30 15:02:20 --> Model "M_produk" initialized
INFO - 2023-05-30 15:02:20 --> Controller Class Initialized
INFO - 2023-05-30 15:02:20 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-05-30 15:02:20 --> Final output sent to browser
DEBUG - 2023-05-30 15:02:20 --> Total execution time: 0.0996
INFO - 2023-05-30 15:02:23 --> Config Class Initialized
INFO - 2023-05-30 15:02:23 --> Hooks Class Initialized
DEBUG - 2023-05-30 15:02:23 --> UTF-8 Support Enabled
INFO - 2023-05-30 15:02:23 --> Utf8 Class Initialized
INFO - 2023-05-30 15:02:23 --> URI Class Initialized
DEBUG - 2023-05-30 15:02:23 --> No URI present. Default controller set.
INFO - 2023-05-30 15:02:23 --> Router Class Initialized
INFO - 2023-05-30 15:02:23 --> Output Class Initialized
INFO - 2023-05-30 15:02:23 --> Security Class Initialized
DEBUG - 2023-05-30 15:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-30 15:02:23 --> Input Class Initialized
INFO - 2023-05-30 15:02:23 --> Language Class Initialized
INFO - 2023-05-30 15:02:23 --> Loader Class Initialized
INFO - 2023-05-30 15:02:23 --> Helper loaded: url_helper
INFO - 2023-05-30 15:02:23 --> Helper loaded: form_helper
INFO - 2023-05-30 15:02:23 --> Helper loaded: file_helper
INFO - 2023-05-30 15:02:23 --> Database Driver Class Initialized
DEBUG - 2023-05-30 15:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-30 15:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-30 15:02:23 --> Form Validation Class Initialized
INFO - 2023-05-30 15:02:23 --> Upload Class Initialized
INFO - 2023-05-30 15:02:23 --> Model "M_auth" initialized
INFO - 2023-05-30 15:02:23 --> Model "M_user" initialized
INFO - 2023-05-30 15:02:23 --> Model "M_produk" initialized
INFO - 2023-05-30 15:02:23 --> Controller Class Initialized
INFO - 2023-05-30 15:02:23 --> Model "M_pelanggan" initialized
INFO - 2023-05-30 15:02:23 --> Model "M_produk" initialized
DEBUG - 2023-05-30 15:02:23 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-30 15:02:23 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-30 15:02:23 --> Model "M_transaksi" initialized
INFO - 2023-05-30 15:02:23 --> Model "M_bank" initialized
INFO - 2023-05-30 15:02:23 --> Model "M_pesan" initialized
INFO - 2023-05-30 15:02:23 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-05-30 15:02:23 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-05-30 15:02:23 --> Final output sent to browser
DEBUG - 2023-05-30 15:02:23 --> Total execution time: 0.1315
INFO - 2023-05-30 15:02:32 --> Config Class Initialized
INFO - 2023-05-30 15:02:32 --> Hooks Class Initialized
DEBUG - 2023-05-30 15:02:32 --> UTF-8 Support Enabled
INFO - 2023-05-30 15:02:32 --> Utf8 Class Initialized
INFO - 2023-05-30 15:02:32 --> URI Class Initialized
DEBUG - 2023-05-30 15:02:32 --> No URI present. Default controller set.
INFO - 2023-05-30 15:02:32 --> Router Class Initialized
INFO - 2023-05-30 15:02:32 --> Output Class Initialized
INFO - 2023-05-30 15:02:32 --> Security Class Initialized
DEBUG - 2023-05-30 15:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-30 15:02:32 --> Input Class Initialized
INFO - 2023-05-30 15:02:32 --> Language Class Initialized
INFO - 2023-05-30 15:02:32 --> Loader Class Initialized
INFO - 2023-05-30 15:02:32 --> Helper loaded: url_helper
INFO - 2023-05-30 15:02:32 --> Helper loaded: form_helper
INFO - 2023-05-30 15:02:32 --> Helper loaded: file_helper
INFO - 2023-05-30 15:02:32 --> Database Driver Class Initialized
DEBUG - 2023-05-30 15:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-30 15:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-30 15:02:32 --> Form Validation Class Initialized
INFO - 2023-05-30 15:02:32 --> Upload Class Initialized
INFO - 2023-05-30 15:02:32 --> Model "M_auth" initialized
INFO - 2023-05-30 15:02:32 --> Model "M_user" initialized
INFO - 2023-05-30 15:02:32 --> Model "M_produk" initialized
INFO - 2023-05-30 15:02:32 --> Controller Class Initialized
INFO - 2023-05-30 15:02:32 --> Model "M_pelanggan" initialized
INFO - 2023-05-30 15:02:32 --> Model "M_produk" initialized
DEBUG - 2023-05-30 15:02:32 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-30 15:02:32 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-30 15:02:32 --> Model "M_transaksi" initialized
INFO - 2023-05-30 15:02:32 --> Model "M_bank" initialized
INFO - 2023-05-30 15:02:32 --> Model "M_pesan" initialized
INFO - 2023-05-30 15:02:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-05-30 15:02:32 --> Email Class Initialized
INFO - 2023-05-30 15:02:34 --> Language file loaded: language/english/email_lang.php
INFO - 2023-05-30 15:02:38 --> Config Class Initialized
INFO - 2023-05-30 15:02:38 --> Hooks Class Initialized
DEBUG - 2023-05-30 15:02:38 --> UTF-8 Support Enabled
INFO - 2023-05-30 15:02:38 --> Utf8 Class Initialized
INFO - 2023-05-30 15:02:38 --> URI Class Initialized
DEBUG - 2023-05-30 15:02:38 --> No URI present. Default controller set.
INFO - 2023-05-30 15:02:38 --> Router Class Initialized
INFO - 2023-05-30 15:02:38 --> Output Class Initialized
INFO - 2023-05-30 15:02:38 --> Security Class Initialized
DEBUG - 2023-05-30 15:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-30 15:02:38 --> Input Class Initialized
INFO - 2023-05-30 15:02:38 --> Language Class Initialized
INFO - 2023-05-30 15:02:38 --> Loader Class Initialized
INFO - 2023-05-30 15:02:38 --> Helper loaded: url_helper
INFO - 2023-05-30 15:02:38 --> Helper loaded: form_helper
INFO - 2023-05-30 15:02:38 --> Helper loaded: file_helper
INFO - 2023-05-30 15:02:38 --> Database Driver Class Initialized
DEBUG - 2023-05-30 15:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-30 15:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-30 15:02:38 --> Form Validation Class Initialized
INFO - 2023-05-30 15:02:38 --> Upload Class Initialized
INFO - 2023-05-30 15:02:38 --> Model "M_auth" initialized
INFO - 2023-05-30 15:02:38 --> Model "M_user" initialized
INFO - 2023-05-30 15:02:38 --> Model "M_produk" initialized
INFO - 2023-05-30 15:02:38 --> Controller Class Initialized
INFO - 2023-05-30 15:02:38 --> Model "M_pelanggan" initialized
INFO - 2023-05-30 15:02:38 --> Model "M_produk" initialized
DEBUG - 2023-05-30 15:02:38 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-30 15:02:38 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-30 15:02:38 --> Model "M_transaksi" initialized
INFO - 2023-05-30 15:02:38 --> Model "M_bank" initialized
INFO - 2023-05-30 15:02:38 --> Model "M_pesan" initialized
INFO - 2023-05-30 15:02:38 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-05-30 15:02:38 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-05-30 15:02:38 --> Final output sent to browser
DEBUG - 2023-05-30 15:02:38 --> Total execution time: 0.1332
INFO - 2023-05-30 15:02:42 --> Config Class Initialized
INFO - 2023-05-30 15:02:42 --> Hooks Class Initialized
DEBUG - 2023-05-30 15:02:43 --> UTF-8 Support Enabled
INFO - 2023-05-30 15:02:43 --> Utf8 Class Initialized
INFO - 2023-05-30 15:02:43 --> URI Class Initialized
INFO - 2023-05-30 15:02:43 --> Router Class Initialized
INFO - 2023-05-30 15:02:43 --> Output Class Initialized
INFO - 2023-05-30 15:02:43 --> Security Class Initialized
DEBUG - 2023-05-30 15:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-30 15:02:43 --> Input Class Initialized
INFO - 2023-05-30 15:02:43 --> Language Class Initialized
INFO - 2023-05-30 15:02:43 --> Loader Class Initialized
INFO - 2023-05-30 15:02:43 --> Helper loaded: url_helper
INFO - 2023-05-30 15:02:43 --> Helper loaded: form_helper
INFO - 2023-05-30 15:02:43 --> Helper loaded: file_helper
INFO - 2023-05-30 15:02:43 --> Database Driver Class Initialized
DEBUG - 2023-05-30 15:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-30 15:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-30 15:02:43 --> Form Validation Class Initialized
INFO - 2023-05-30 15:02:43 --> Upload Class Initialized
INFO - 2023-05-30 15:02:43 --> Model "M_auth" initialized
INFO - 2023-05-30 15:02:43 --> Model "M_user" initialized
INFO - 2023-05-30 15:02:43 --> Model "M_produk" initialized
INFO - 2023-05-30 15:02:43 --> Controller Class Initialized
INFO - 2023-05-30 15:02:43 --> Model "M_pelanggan" initialized
INFO - 2023-05-30 15:02:43 --> Model "M_produk" initialized
DEBUG - 2023-05-30 15:02:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-30 15:02:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-30 15:02:43 --> Model "M_transaksi" initialized
INFO - 2023-05-30 15:02:43 --> Model "M_bank" initialized
INFO - 2023-05-30 15:02:43 --> Model "M_pesan" initialized
INFO - 2023-05-30 15:02:43 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-05-30 15:02:43 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/v_edit_profile_pelanggan.php
INFO - 2023-05-30 15:02:43 --> Final output sent to browser
DEBUG - 2023-05-30 15:02:43 --> Total execution time: 0.1744
INFO - 2023-05-30 15:02:45 --> Config Class Initialized
INFO - 2023-05-30 15:02:45 --> Hooks Class Initialized
DEBUG - 2023-05-30 15:02:45 --> UTF-8 Support Enabled
INFO - 2023-05-30 15:02:45 --> Utf8 Class Initialized
INFO - 2023-05-30 15:02:45 --> URI Class Initialized
INFO - 2023-05-30 15:02:45 --> Router Class Initialized
INFO - 2023-05-30 15:02:45 --> Output Class Initialized
INFO - 2023-05-30 15:02:45 --> Security Class Initialized
DEBUG - 2023-05-30 15:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-30 15:02:45 --> Input Class Initialized
INFO - 2023-05-30 15:02:45 --> Language Class Initialized
INFO - 2023-05-30 15:02:45 --> Loader Class Initialized
INFO - 2023-05-30 15:02:45 --> Helper loaded: url_helper
INFO - 2023-05-30 15:02:45 --> Helper loaded: form_helper
INFO - 2023-05-30 15:02:45 --> Helper loaded: file_helper
INFO - 2023-05-30 15:02:45 --> Database Driver Class Initialized
DEBUG - 2023-05-30 15:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-30 15:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-30 15:02:45 --> Form Validation Class Initialized
INFO - 2023-05-30 15:02:45 --> Upload Class Initialized
INFO - 2023-05-30 15:02:45 --> Model "M_auth" initialized
INFO - 2023-05-30 15:02:45 --> Model "M_user" initialized
INFO - 2023-05-30 15:02:45 --> Model "M_produk" initialized
INFO - 2023-05-30 15:02:45 --> Controller Class Initialized
INFO - 2023-05-30 15:02:45 --> Model "M_pelanggan" initialized
INFO - 2023-05-30 15:02:45 --> Model "M_produk" initialized
DEBUG - 2023-05-30 15:02:45 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-05-30 15:02:45 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-05-30 15:02:45 --> Model "M_transaksi" initialized
INFO - 2023-05-30 15:02:45 --> Model "M_bank" initialized
INFO - 2023-05-30 15:02:45 --> Model "M_pesan" initialized
INFO - 2023-05-30 15:02:45 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-05-30 15:02:45 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-05-30 15:02:45 --> Final output sent to browser
DEBUG - 2023-05-30 15:02:45 --> Total execution time: 0.2088
