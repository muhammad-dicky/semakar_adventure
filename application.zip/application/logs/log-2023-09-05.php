<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-05 03:03:41 --> Config Class Initialized
INFO - 2023-09-05 03:03:41 --> Hooks Class Initialized
DEBUG - 2023-09-05 03:03:41 --> UTF-8 Support Enabled
INFO - 2023-09-05 03:03:41 --> Utf8 Class Initialized
INFO - 2023-09-05 03:03:41 --> URI Class Initialized
DEBUG - 2023-09-05 03:03:41 --> No URI present. Default controller set.
INFO - 2023-09-05 03:03:41 --> Router Class Initialized
INFO - 2023-09-05 03:03:42 --> Output Class Initialized
INFO - 2023-09-05 03:03:42 --> Security Class Initialized
DEBUG - 2023-09-05 03:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 03:03:42 --> Input Class Initialized
INFO - 2023-09-05 03:03:42 --> Language Class Initialized
INFO - 2023-09-05 03:03:42 --> Loader Class Initialized
INFO - 2023-09-05 03:03:42 --> Helper loaded: url_helper
INFO - 2023-09-05 03:03:42 --> Helper loaded: form_helper
INFO - 2023-09-05 03:03:42 --> Helper loaded: file_helper
INFO - 2023-09-05 03:03:42 --> Database Driver Class Initialized
DEBUG - 2023-09-05 03:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 03:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 03:03:42 --> Form Validation Class Initialized
INFO - 2023-09-05 03:03:42 --> Upload Class Initialized
INFO - 2023-09-05 03:03:42 --> Model "M_auth" initialized
INFO - 2023-09-05 03:03:42 --> Model "M_user" initialized
INFO - 2023-09-05 03:03:43 --> Model "M_produk" initialized
INFO - 2023-09-05 03:03:43 --> Controller Class Initialized
INFO - 2023-09-05 03:03:43 --> Model "M_pelanggan" initialized
INFO - 2023-09-05 03:03:43 --> Model "M_produk" initialized
DEBUG - 2023-09-05 03:03:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 03:03:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-09-05 03:03:43 --> Model "M_transaksi" initialized
INFO - 2023-09-05 03:03:43 --> Model "M_bank" initialized
INFO - 2023-09-05 03:03:43 --> Model "M_pesan" initialized
INFO - 2023-09-05 03:03:43 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-09-05 03:03:43 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-09-05 03:03:43 --> Final output sent to browser
DEBUG - 2023-09-05 03:03:43 --> Total execution time: 1.9041
INFO - 2023-09-05 05:40:18 --> Config Class Initialized
INFO - 2023-09-05 05:40:18 --> Hooks Class Initialized
DEBUG - 2023-09-05 05:40:18 --> UTF-8 Support Enabled
INFO - 2023-09-05 05:40:18 --> Utf8 Class Initialized
INFO - 2023-09-05 05:40:18 --> URI Class Initialized
DEBUG - 2023-09-05 05:40:18 --> No URI present. Default controller set.
INFO - 2023-09-05 05:40:18 --> Router Class Initialized
INFO - 2023-09-05 05:40:18 --> Output Class Initialized
INFO - 2023-09-05 05:40:18 --> Security Class Initialized
DEBUG - 2023-09-05 05:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 05:40:18 --> Input Class Initialized
INFO - 2023-09-05 05:40:18 --> Language Class Initialized
INFO - 2023-09-05 05:40:18 --> Loader Class Initialized
INFO - 2023-09-05 05:40:18 --> Helper loaded: url_helper
INFO - 2023-09-05 05:40:18 --> Helper loaded: form_helper
INFO - 2023-09-05 05:40:18 --> Helper loaded: file_helper
INFO - 2023-09-05 05:40:18 --> Database Driver Class Initialized
DEBUG - 2023-09-05 05:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 05:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 05:40:18 --> Form Validation Class Initialized
INFO - 2023-09-05 05:40:18 --> Upload Class Initialized
INFO - 2023-09-05 05:40:18 --> Model "M_auth" initialized
INFO - 2023-09-05 05:40:18 --> Model "M_user" initialized
INFO - 2023-09-05 05:40:18 --> Model "M_produk" initialized
INFO - 2023-09-05 05:40:18 --> Controller Class Initialized
INFO - 2023-09-05 05:40:18 --> Model "M_pelanggan" initialized
INFO - 2023-09-05 05:40:18 --> Model "M_produk" initialized
DEBUG - 2023-09-05 05:40:18 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 05:40:18 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-09-05 05:40:18 --> Model "M_transaksi" initialized
INFO - 2023-09-05 05:40:18 --> Model "M_bank" initialized
INFO - 2023-09-05 05:40:18 --> Model "M_pesan" initialized
INFO - 2023-09-05 05:40:18 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-09-05 05:40:18 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-09-05 05:40:18 --> Final output sent to browser
DEBUG - 2023-09-05 05:40:18 --> Total execution time: 0.1600
INFO - 2023-09-05 08:05:07 --> Config Class Initialized
INFO - 2023-09-05 08:05:07 --> Hooks Class Initialized
DEBUG - 2023-09-05 08:05:07 --> UTF-8 Support Enabled
INFO - 2023-09-05 08:05:07 --> Utf8 Class Initialized
INFO - 2023-09-05 08:05:08 --> URI Class Initialized
DEBUG - 2023-09-05 08:05:08 --> No URI present. Default controller set.
INFO - 2023-09-05 08:05:08 --> Router Class Initialized
INFO - 2023-09-05 08:05:08 --> Output Class Initialized
INFO - 2023-09-05 08:05:08 --> Security Class Initialized
DEBUG - 2023-09-05 08:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 08:05:08 --> Input Class Initialized
INFO - 2023-09-05 08:05:08 --> Language Class Initialized
INFO - 2023-09-05 08:05:08 --> Loader Class Initialized
INFO - 2023-09-05 08:05:08 --> Helper loaded: url_helper
INFO - 2023-09-05 08:05:08 --> Helper loaded: form_helper
INFO - 2023-09-05 08:05:08 --> Helper loaded: file_helper
INFO - 2023-09-05 08:05:08 --> Database Driver Class Initialized
DEBUG - 2023-09-05 08:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 08:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 08:05:09 --> Form Validation Class Initialized
INFO - 2023-09-05 08:05:09 --> Upload Class Initialized
INFO - 2023-09-05 08:05:09 --> Model "M_auth" initialized
INFO - 2023-09-05 08:05:09 --> Model "M_user" initialized
INFO - 2023-09-05 08:05:09 --> Model "M_produk" initialized
INFO - 2023-09-05 08:05:09 --> Controller Class Initialized
INFO - 2023-09-05 08:05:09 --> Model "M_pelanggan" initialized
INFO - 2023-09-05 08:05:09 --> Model "M_produk" initialized
DEBUG - 2023-09-05 08:05:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:05:09 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-09-05 08:05:09 --> Model "M_transaksi" initialized
INFO - 2023-09-05 08:05:09 --> Model "M_bank" initialized
INFO - 2023-09-05 08:05:09 --> Model "M_pesan" initialized
INFO - 2023-09-05 08:05:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-09-05 08:05:09 --> Config Class Initialized
INFO - 2023-09-05 08:05:09 --> Hooks Class Initialized
DEBUG - 2023-09-05 08:05:09 --> UTF-8 Support Enabled
INFO - 2023-09-05 08:05:09 --> Utf8 Class Initialized
INFO - 2023-09-05 08:05:09 --> URI Class Initialized
DEBUG - 2023-09-05 08:05:09 --> No URI present. Default controller set.
INFO - 2023-09-05 08:05:09 --> Router Class Initialized
INFO - 2023-09-05 08:05:09 --> Output Class Initialized
INFO - 2023-09-05 08:05:09 --> Security Class Initialized
DEBUG - 2023-09-05 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 08:05:09 --> Input Class Initialized
INFO - 2023-09-05 08:05:09 --> Language Class Initialized
INFO - 2023-09-05 08:05:09 --> Loader Class Initialized
INFO - 2023-09-05 08:05:09 --> Helper loaded: url_helper
INFO - 2023-09-05 08:05:09 --> Helper loaded: form_helper
INFO - 2023-09-05 08:05:09 --> Helper loaded: file_helper
INFO - 2023-09-05 08:05:09 --> Database Driver Class Initialized
DEBUG - 2023-09-05 08:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 08:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 08:05:09 --> Form Validation Class Initialized
INFO - 2023-09-05 08:05:09 --> Upload Class Initialized
INFO - 2023-09-05 08:05:09 --> Model "M_auth" initialized
INFO - 2023-09-05 08:05:09 --> Model "M_user" initialized
INFO - 2023-09-05 08:05:09 --> Model "M_produk" initialized
INFO - 2023-09-05 08:05:09 --> Controller Class Initialized
INFO - 2023-09-05 08:05:09 --> Model "M_pelanggan" initialized
INFO - 2023-09-05 08:05:09 --> Model "M_produk" initialized
DEBUG - 2023-09-05 08:05:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 08:05:09 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-09-05 08:05:09 --> Model "M_transaksi" initialized
INFO - 2023-09-05 08:05:09 --> Model "M_bank" initialized
INFO - 2023-09-05 08:05:09 --> Model "M_pesan" initialized
INFO - 2023-09-05 08:05:09 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-09-05 08:05:09 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-09-05 08:05:09 --> Final output sent to browser
DEBUG - 2023-09-05 08:05:09 --> Total execution time: 0.2290
INFO - 2023-09-05 11:23:50 --> Config Class Initialized
INFO - 2023-09-05 11:23:50 --> Hooks Class Initialized
DEBUG - 2023-09-05 11:23:50 --> UTF-8 Support Enabled
INFO - 2023-09-05 11:23:50 --> Utf8 Class Initialized
INFO - 2023-09-05 11:23:50 --> URI Class Initialized
DEBUG - 2023-09-05 11:23:50 --> No URI present. Default controller set.
INFO - 2023-09-05 11:23:50 --> Router Class Initialized
INFO - 2023-09-05 11:23:50 --> Output Class Initialized
INFO - 2023-09-05 11:23:50 --> Security Class Initialized
DEBUG - 2023-09-05 11:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 11:23:50 --> Input Class Initialized
INFO - 2023-09-05 11:23:50 --> Language Class Initialized
INFO - 2023-09-05 11:23:50 --> Loader Class Initialized
INFO - 2023-09-05 11:23:50 --> Helper loaded: url_helper
INFO - 2023-09-05 11:23:50 --> Helper loaded: form_helper
INFO - 2023-09-05 11:23:50 --> Helper loaded: file_helper
INFO - 2023-09-05 11:23:50 --> Database Driver Class Initialized
DEBUG - 2023-09-05 11:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-09-05 11:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 11:23:51 --> Form Validation Class Initialized
INFO - 2023-09-05 11:23:51 --> Upload Class Initialized
INFO - 2023-09-05 11:23:51 --> Model "M_auth" initialized
INFO - 2023-09-05 11:23:51 --> Model "M_user" initialized
INFO - 2023-09-05 11:23:51 --> Model "M_produk" initialized
INFO - 2023-09-05 11:23:51 --> Controller Class Initialized
INFO - 2023-09-05 11:23:51 --> Model "M_pelanggan" initialized
INFO - 2023-09-05 11:23:51 --> Model "M_produk" initialized
DEBUG - 2023-09-05 11:23:51 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-09-05 11:23:51 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-09-05 11:23:51 --> Model "M_transaksi" initialized
INFO - 2023-09-05 11:23:51 --> Model "M_bank" initialized
INFO - 2023-09-05 11:23:51 --> Model "M_pesan" initialized
INFO - 2023-09-05 11:23:51 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-09-05 11:23:51 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-09-05 11:23:51 --> Final output sent to browser
DEBUG - 2023-09-05 11:23:51 --> Total execution time: 0.1840
