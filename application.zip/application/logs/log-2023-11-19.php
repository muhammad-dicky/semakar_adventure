<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-19 01:03:42 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-19 01:03:42 --> Config Class Initialized
INFO - 2023-11-19 01:03:42 --> Hooks Class Initialized
DEBUG - 2023-11-19 01:03:42 --> UTF-8 Support Enabled
INFO - 2023-11-19 01:03:42 --> Utf8 Class Initialized
INFO - 2023-11-19 01:03:42 --> URI Class Initialized
DEBUG - 2023-11-19 01:03:42 --> No URI present. Default controller set.
INFO - 2023-11-19 01:03:42 --> Router Class Initialized
INFO - 2023-11-19 01:03:42 --> Output Class Initialized
INFO - 2023-11-19 01:03:42 --> Security Class Initialized
DEBUG - 2023-11-19 01:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 01:03:42 --> Input Class Initialized
INFO - 2023-11-19 01:03:42 --> Language Class Initialized
INFO - 2023-11-19 01:03:42 --> Loader Class Initialized
INFO - 2023-11-19 01:03:42 --> Helper loaded: url_helper
INFO - 2023-11-19 01:03:42 --> Helper loaded: form_helper
INFO - 2023-11-19 01:03:42 --> Helper loaded: file_helper
INFO - 2023-11-19 01:03:42 --> Database Driver Class Initialized
DEBUG - 2023-11-19 01:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 01:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 01:03:42 --> Form Validation Class Initialized
INFO - 2023-11-19 01:03:42 --> Upload Class Initialized
INFO - 2023-11-19 01:03:42 --> Model "M_auth" initialized
INFO - 2023-11-19 01:03:42 --> Model "M_user" initialized
INFO - 2023-11-19 01:03:42 --> Model "M_produk" initialized
INFO - 2023-11-19 01:03:42 --> Controller Class Initialized
INFO - 2023-11-19 01:03:42 --> Model "M_pelanggan" initialized
INFO - 2023-11-19 01:03:42 --> Model "M_produk" initialized
DEBUG - 2023-11-19 01:03:42 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-19 01:03:42 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-19 01:03:42 --> Model "M_transaksi" initialized
INFO - 2023-11-19 01:03:42 --> Model "M_bank" initialized
INFO - 2023-11-19 01:03:42 --> Model "M_pesan" initialized
DEBUG - 2023-11-19 01:03:42 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-19 01:03:42 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-19 01:03:42 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-19 01:03:42 --> Final output sent to browser
DEBUG - 2023-11-19 01:03:42 --> Total execution time: 0.0351
ERROR - 2023-11-19 01:33:27 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-19 01:33:27 --> Config Class Initialized
INFO - 2023-11-19 01:33:27 --> Hooks Class Initialized
DEBUG - 2023-11-19 01:33:27 --> UTF-8 Support Enabled
INFO - 2023-11-19 01:33:27 --> Utf8 Class Initialized
INFO - 2023-11-19 01:33:27 --> URI Class Initialized
DEBUG - 2023-11-19 01:33:27 --> No URI present. Default controller set.
INFO - 2023-11-19 01:33:27 --> Router Class Initialized
INFO - 2023-11-19 01:33:27 --> Output Class Initialized
INFO - 2023-11-19 01:33:27 --> Security Class Initialized
DEBUG - 2023-11-19 01:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 01:33:27 --> Input Class Initialized
INFO - 2023-11-19 01:33:27 --> Language Class Initialized
INFO - 2023-11-19 01:33:27 --> Loader Class Initialized
INFO - 2023-11-19 01:33:27 --> Helper loaded: url_helper
INFO - 2023-11-19 01:33:27 --> Helper loaded: form_helper
INFO - 2023-11-19 01:33:27 --> Helper loaded: file_helper
INFO - 2023-11-19 01:33:27 --> Database Driver Class Initialized
DEBUG - 2023-11-19 01:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 01:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 01:33:27 --> Form Validation Class Initialized
INFO - 2023-11-19 01:33:27 --> Upload Class Initialized
INFO - 2023-11-19 01:33:27 --> Model "M_auth" initialized
INFO - 2023-11-19 01:33:27 --> Model "M_user" initialized
INFO - 2023-11-19 01:33:27 --> Model "M_produk" initialized
INFO - 2023-11-19 01:33:27 --> Controller Class Initialized
INFO - 2023-11-19 01:33:27 --> Model "M_pelanggan" initialized
INFO - 2023-11-19 01:33:27 --> Model "M_produk" initialized
DEBUG - 2023-11-19 01:33:27 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-19 01:33:27 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-19 01:33:27 --> Model "M_transaksi" initialized
INFO - 2023-11-19 01:33:27 --> Model "M_bank" initialized
INFO - 2023-11-19 01:33:27 --> Model "M_pesan" initialized
DEBUG - 2023-11-19 01:33:27 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-19 01:33:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-19 01:33:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-19 01:33:27 --> Final output sent to browser
DEBUG - 2023-11-19 01:33:27 --> Total execution time: 0.0343
ERROR - 2023-11-19 02:55:15 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-19 02:55:15 --> Config Class Initialized
INFO - 2023-11-19 02:55:15 --> Hooks Class Initialized
DEBUG - 2023-11-19 02:55:15 --> UTF-8 Support Enabled
INFO - 2023-11-19 02:55:15 --> Utf8 Class Initialized
INFO - 2023-11-19 02:55:15 --> URI Class Initialized
INFO - 2023-11-19 02:55:15 --> Router Class Initialized
INFO - 2023-11-19 02:55:15 --> Output Class Initialized
INFO - 2023-11-19 02:55:15 --> Security Class Initialized
DEBUG - 2023-11-19 02:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 02:55:15 --> Input Class Initialized
INFO - 2023-11-19 02:55:15 --> Language Class Initialized
INFO - 2023-11-19 02:55:15 --> Loader Class Initialized
INFO - 2023-11-19 02:55:15 --> Helper loaded: url_helper
INFO - 2023-11-19 02:55:15 --> Helper loaded: form_helper
INFO - 2023-11-19 02:55:15 --> Helper loaded: file_helper
INFO - 2023-11-19 02:55:15 --> Database Driver Class Initialized
DEBUG - 2023-11-19 02:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 02:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 02:55:15 --> Form Validation Class Initialized
INFO - 2023-11-19 02:55:15 --> Upload Class Initialized
INFO - 2023-11-19 02:55:15 --> Model "M_auth" initialized
INFO - 2023-11-19 02:55:15 --> Model "M_user" initialized
INFO - 2023-11-19 02:55:15 --> Model "M_produk" initialized
INFO - 2023-11-19 02:55:15 --> Controller Class Initialized
INFO - 2023-11-19 02:55:15 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-19 02:55:15 --> Final output sent to browser
DEBUG - 2023-11-19 02:55:15 --> Total execution time: 0.0316
ERROR - 2023-11-19 02:55:15 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-19 02:55:15 --> Config Class Initialized
INFO - 2023-11-19 02:55:15 --> Hooks Class Initialized
DEBUG - 2023-11-19 02:55:15 --> UTF-8 Support Enabled
INFO - 2023-11-19 02:55:15 --> Utf8 Class Initialized
INFO - 2023-11-19 02:55:15 --> URI Class Initialized
INFO - 2023-11-19 02:55:15 --> Router Class Initialized
INFO - 2023-11-19 02:55:15 --> Output Class Initialized
INFO - 2023-11-19 02:55:15 --> Security Class Initialized
DEBUG - 2023-11-19 02:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 02:55:15 --> Input Class Initialized
INFO - 2023-11-19 02:55:15 --> Language Class Initialized
INFO - 2023-11-19 02:55:15 --> Loader Class Initialized
INFO - 2023-11-19 02:55:15 --> Helper loaded: url_helper
INFO - 2023-11-19 02:55:15 --> Helper loaded: form_helper
INFO - 2023-11-19 02:55:15 --> Helper loaded: file_helper
INFO - 2023-11-19 02:55:15 --> Database Driver Class Initialized
DEBUG - 2023-11-19 02:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 02:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 02:55:15 --> Form Validation Class Initialized
INFO - 2023-11-19 02:55:15 --> Upload Class Initialized
INFO - 2023-11-19 02:55:15 --> Model "M_auth" initialized
INFO - 2023-11-19 02:55:15 --> Model "M_user" initialized
INFO - 2023-11-19 02:55:15 --> Model "M_produk" initialized
INFO - 2023-11-19 02:55:15 --> Controller Class Initialized
INFO - 2023-11-19 02:55:15 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-19 02:55:15 --> Final output sent to browser
DEBUG - 2023-11-19 02:55:15 --> Total execution time: 0.0020
ERROR - 2023-11-19 03:22:27 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-19 03:22:27 --> Config Class Initialized
INFO - 2023-11-19 03:22:27 --> Hooks Class Initialized
DEBUG - 2023-11-19 03:22:27 --> UTF-8 Support Enabled
INFO - 2023-11-19 03:22:27 --> Utf8 Class Initialized
INFO - 2023-11-19 03:22:27 --> URI Class Initialized
DEBUG - 2023-11-19 03:22:27 --> No URI present. Default controller set.
INFO - 2023-11-19 03:22:27 --> Router Class Initialized
INFO - 2023-11-19 03:22:27 --> Output Class Initialized
INFO - 2023-11-19 03:22:27 --> Security Class Initialized
DEBUG - 2023-11-19 03:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 03:22:27 --> Input Class Initialized
INFO - 2023-11-19 03:22:27 --> Language Class Initialized
INFO - 2023-11-19 03:22:27 --> Loader Class Initialized
INFO - 2023-11-19 03:22:27 --> Helper loaded: url_helper
INFO - 2023-11-19 03:22:27 --> Helper loaded: form_helper
INFO - 2023-11-19 03:22:27 --> Helper loaded: file_helper
INFO - 2023-11-19 03:22:27 --> Database Driver Class Initialized
DEBUG - 2023-11-19 03:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 03:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 03:22:27 --> Form Validation Class Initialized
INFO - 2023-11-19 03:22:27 --> Upload Class Initialized
INFO - 2023-11-19 03:22:27 --> Model "M_auth" initialized
INFO - 2023-11-19 03:22:27 --> Model "M_user" initialized
INFO - 2023-11-19 03:22:27 --> Model "M_produk" initialized
INFO - 2023-11-19 03:22:27 --> Controller Class Initialized
INFO - 2023-11-19 03:22:27 --> Model "M_pelanggan" initialized
INFO - 2023-11-19 03:22:27 --> Model "M_produk" initialized
DEBUG - 2023-11-19 03:22:27 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-19 03:22:27 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-19 03:22:27 --> Model "M_transaksi" initialized
INFO - 2023-11-19 03:22:27 --> Model "M_bank" initialized
INFO - 2023-11-19 03:22:27 --> Model "M_pesan" initialized
DEBUG - 2023-11-19 03:22:27 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-19 03:22:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-19 03:22:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-19 03:22:27 --> Final output sent to browser
DEBUG - 2023-11-19 03:22:27 --> Total execution time: 0.0319
ERROR - 2023-11-19 06:29:37 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-19 06:29:37 --> Config Class Initialized
INFO - 2023-11-19 06:29:37 --> Hooks Class Initialized
DEBUG - 2023-11-19 06:29:37 --> UTF-8 Support Enabled
INFO - 2023-11-19 06:29:37 --> Utf8 Class Initialized
INFO - 2023-11-19 06:29:37 --> URI Class Initialized
INFO - 2023-11-19 06:29:37 --> Router Class Initialized
INFO - 2023-11-19 06:29:37 --> Output Class Initialized
INFO - 2023-11-19 06:29:37 --> Security Class Initialized
DEBUG - 2023-11-19 06:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 06:29:37 --> Input Class Initialized
INFO - 2023-11-19 06:29:37 --> Language Class Initialized
INFO - 2023-11-19 06:29:37 --> Loader Class Initialized
INFO - 2023-11-19 06:29:37 --> Helper loaded: url_helper
INFO - 2023-11-19 06:29:37 --> Helper loaded: form_helper
INFO - 2023-11-19 06:29:37 --> Helper loaded: file_helper
INFO - 2023-11-19 06:29:37 --> Database Driver Class Initialized
DEBUG - 2023-11-19 06:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 06:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 06:29:37 --> Form Validation Class Initialized
INFO - 2023-11-19 06:29:37 --> Upload Class Initialized
INFO - 2023-11-19 06:29:37 --> Model "M_auth" initialized
INFO - 2023-11-19 06:29:37 --> Model "M_user" initialized
INFO - 2023-11-19 06:29:37 --> Model "M_produk" initialized
INFO - 2023-11-19 06:29:37 --> Controller Class Initialized
INFO - 2023-11-19 06:29:37 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-19 06:29:37 --> Final output sent to browser
DEBUG - 2023-11-19 06:29:37 --> Total execution time: 0.0296
ERROR - 2023-11-19 06:29:39 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-19 06:29:39 --> Config Class Initialized
INFO - 2023-11-19 06:29:39 --> Hooks Class Initialized
DEBUG - 2023-11-19 06:29:39 --> UTF-8 Support Enabled
INFO - 2023-11-19 06:29:39 --> Utf8 Class Initialized
INFO - 2023-11-19 06:29:39 --> URI Class Initialized
DEBUG - 2023-11-19 06:29:39 --> No URI present. Default controller set.
INFO - 2023-11-19 06:29:39 --> Router Class Initialized
INFO - 2023-11-19 06:29:39 --> Output Class Initialized
INFO - 2023-11-19 06:29:39 --> Security Class Initialized
DEBUG - 2023-11-19 06:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 06:29:39 --> Input Class Initialized
INFO - 2023-11-19 06:29:39 --> Language Class Initialized
INFO - 2023-11-19 06:29:39 --> Loader Class Initialized
INFO - 2023-11-19 06:29:39 --> Helper loaded: url_helper
INFO - 2023-11-19 06:29:39 --> Helper loaded: form_helper
INFO - 2023-11-19 06:29:39 --> Helper loaded: file_helper
INFO - 2023-11-19 06:29:39 --> Database Driver Class Initialized
DEBUG - 2023-11-19 06:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 06:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 06:29:39 --> Form Validation Class Initialized
INFO - 2023-11-19 06:29:39 --> Upload Class Initialized
INFO - 2023-11-19 06:29:39 --> Model "M_auth" initialized
INFO - 2023-11-19 06:29:39 --> Model "M_user" initialized
INFO - 2023-11-19 06:29:39 --> Model "M_produk" initialized
INFO - 2023-11-19 06:29:39 --> Controller Class Initialized
INFO - 2023-11-19 06:29:39 --> Model "M_pelanggan" initialized
INFO - 2023-11-19 06:29:39 --> Model "M_produk" initialized
DEBUG - 2023-11-19 06:29:39 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-19 06:29:39 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-19 06:29:39 --> Model "M_transaksi" initialized
INFO - 2023-11-19 06:29:39 --> Model "M_bank" initialized
INFO - 2023-11-19 06:29:39 --> Model "M_pesan" initialized
DEBUG - 2023-11-19 06:29:39 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-19 06:29:39 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-19 06:29:39 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-19 06:29:39 --> Final output sent to browser
DEBUG - 2023-11-19 06:29:39 --> Total execution time: 0.0101
ERROR - 2023-11-19 07:03:09 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-19 07:03:09 --> Config Class Initialized
INFO - 2023-11-19 07:03:09 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:03:09 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:03:09 --> Utf8 Class Initialized
INFO - 2023-11-19 07:03:09 --> URI Class Initialized
INFO - 2023-11-19 07:03:09 --> Router Class Initialized
INFO - 2023-11-19 07:03:09 --> Output Class Initialized
INFO - 2023-11-19 07:03:09 --> Security Class Initialized
DEBUG - 2023-11-19 07:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:03:09 --> Input Class Initialized
INFO - 2023-11-19 07:03:09 --> Language Class Initialized
INFO - 2023-11-19 07:03:09 --> Loader Class Initialized
INFO - 2023-11-19 07:03:09 --> Helper loaded: url_helper
INFO - 2023-11-19 07:03:09 --> Helper loaded: form_helper
INFO - 2023-11-19 07:03:09 --> Helper loaded: file_helper
INFO - 2023-11-19 07:03:09 --> Database Driver Class Initialized
DEBUG - 2023-11-19 07:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 07:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 07:03:09 --> Form Validation Class Initialized
INFO - 2023-11-19 07:03:09 --> Upload Class Initialized
INFO - 2023-11-19 07:03:09 --> Model "M_auth" initialized
INFO - 2023-11-19 07:03:09 --> Model "M_user" initialized
INFO - 2023-11-19 07:03:09 --> Model "M_produk" initialized
INFO - 2023-11-19 07:03:09 --> Controller Class Initialized
INFO - 2023-11-19 07:03:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-19 07:03:09 --> Final output sent to browser
DEBUG - 2023-11-19 07:03:09 --> Total execution time: 0.0304
ERROR - 2023-11-19 07:03:09 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-19 07:03:09 --> Config Class Initialized
INFO - 2023-11-19 07:03:09 --> Hooks Class Initialized
DEBUG - 2023-11-19 07:03:09 --> UTF-8 Support Enabled
INFO - 2023-11-19 07:03:09 --> Utf8 Class Initialized
INFO - 2023-11-19 07:03:09 --> URI Class Initialized
INFO - 2023-11-19 07:03:09 --> Router Class Initialized
INFO - 2023-11-19 07:03:09 --> Output Class Initialized
INFO - 2023-11-19 07:03:09 --> Security Class Initialized
DEBUG - 2023-11-19 07:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 07:03:09 --> Input Class Initialized
INFO - 2023-11-19 07:03:09 --> Language Class Initialized
INFO - 2023-11-19 07:03:09 --> Loader Class Initialized
INFO - 2023-11-19 07:03:09 --> Helper loaded: url_helper
INFO - 2023-11-19 07:03:09 --> Helper loaded: form_helper
INFO - 2023-11-19 07:03:09 --> Helper loaded: file_helper
INFO - 2023-11-19 07:03:09 --> Database Driver Class Initialized
DEBUG - 2023-11-19 07:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 07:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 07:03:09 --> Form Validation Class Initialized
INFO - 2023-11-19 07:03:09 --> Upload Class Initialized
INFO - 2023-11-19 07:03:09 --> Model "M_auth" initialized
INFO - 2023-11-19 07:03:09 --> Model "M_user" initialized
INFO - 2023-11-19 07:03:09 --> Model "M_produk" initialized
INFO - 2023-11-19 07:03:09 --> Controller Class Initialized
INFO - 2023-11-19 07:03:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-19 07:03:09 --> Final output sent to browser
DEBUG - 2023-11-19 07:03:09 --> Total execution time: 0.0025
ERROR - 2023-11-19 09:40:41 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-19 09:40:41 --> Config Class Initialized
INFO - 2023-11-19 09:40:41 --> Hooks Class Initialized
DEBUG - 2023-11-19 09:40:41 --> UTF-8 Support Enabled
INFO - 2023-11-19 09:40:41 --> Utf8 Class Initialized
INFO - 2023-11-19 09:40:41 --> URI Class Initialized
DEBUG - 2023-11-19 09:40:41 --> No URI present. Default controller set.
INFO - 2023-11-19 09:40:41 --> Router Class Initialized
INFO - 2023-11-19 09:40:41 --> Output Class Initialized
INFO - 2023-11-19 09:40:41 --> Security Class Initialized
DEBUG - 2023-11-19 09:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 09:40:41 --> Input Class Initialized
INFO - 2023-11-19 09:40:41 --> Language Class Initialized
INFO - 2023-11-19 09:40:41 --> Loader Class Initialized
INFO - 2023-11-19 09:40:41 --> Helper loaded: url_helper
INFO - 2023-11-19 09:40:41 --> Helper loaded: form_helper
INFO - 2023-11-19 09:40:41 --> Helper loaded: file_helper
INFO - 2023-11-19 09:40:41 --> Database Driver Class Initialized
DEBUG - 2023-11-19 09:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 09:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 09:40:41 --> Form Validation Class Initialized
INFO - 2023-11-19 09:40:41 --> Upload Class Initialized
INFO - 2023-11-19 09:40:41 --> Model "M_auth" initialized
INFO - 2023-11-19 09:40:41 --> Model "M_user" initialized
INFO - 2023-11-19 09:40:41 --> Model "M_produk" initialized
INFO - 2023-11-19 09:40:41 --> Controller Class Initialized
INFO - 2023-11-19 09:40:41 --> Model "M_pelanggan" initialized
INFO - 2023-11-19 09:40:41 --> Model "M_produk" initialized
DEBUG - 2023-11-19 09:40:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-19 09:40:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-19 09:40:41 --> Model "M_transaksi" initialized
INFO - 2023-11-19 09:40:41 --> Model "M_bank" initialized
INFO - 2023-11-19 09:40:41 --> Model "M_pesan" initialized
DEBUG - 2023-11-19 09:40:41 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-19 09:40:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-19 09:40:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-19 09:40:41 --> Final output sent to browser
DEBUG - 2023-11-19 09:40:41 --> Total execution time: 0.0350
ERROR - 2023-11-19 10:56:49 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-19 10:56:49 --> Config Class Initialized
INFO - 2023-11-19 10:56:49 --> Hooks Class Initialized
DEBUG - 2023-11-19 10:56:49 --> UTF-8 Support Enabled
INFO - 2023-11-19 10:56:49 --> Utf8 Class Initialized
INFO - 2023-11-19 10:56:49 --> URI Class Initialized
INFO - 2023-11-19 10:56:49 --> Router Class Initialized
INFO - 2023-11-19 10:56:49 --> Output Class Initialized
INFO - 2023-11-19 10:56:49 --> Security Class Initialized
DEBUG - 2023-11-19 10:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 10:56:49 --> Input Class Initialized
INFO - 2023-11-19 10:56:49 --> Language Class Initialized
INFO - 2023-11-19 10:56:49 --> Loader Class Initialized
INFO - 2023-11-19 10:56:49 --> Helper loaded: url_helper
INFO - 2023-11-19 10:56:49 --> Helper loaded: form_helper
INFO - 2023-11-19 10:56:49 --> Helper loaded: file_helper
INFO - 2023-11-19 10:56:49 --> Database Driver Class Initialized
DEBUG - 2023-11-19 10:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 10:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 10:56:49 --> Form Validation Class Initialized
INFO - 2023-11-19 10:56:49 --> Upload Class Initialized
INFO - 2023-11-19 10:56:49 --> Model "M_auth" initialized
INFO - 2023-11-19 10:56:49 --> Model "M_user" initialized
INFO - 2023-11-19 10:56:49 --> Model "M_produk" initialized
INFO - 2023-11-19 10:56:49 --> Controller Class Initialized
INFO - 2023-11-19 10:56:49 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-19 10:56:49 --> Final output sent to browser
DEBUG - 2023-11-19 10:56:49 --> Total execution time: 0.0258
ERROR - 2023-11-19 10:56:50 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-19 10:56:50 --> Config Class Initialized
INFO - 2023-11-19 10:56:50 --> Hooks Class Initialized
DEBUG - 2023-11-19 10:56:50 --> UTF-8 Support Enabled
INFO - 2023-11-19 10:56:50 --> Utf8 Class Initialized
INFO - 2023-11-19 10:56:50 --> URI Class Initialized
DEBUG - 2023-11-19 10:56:50 --> No URI present. Default controller set.
INFO - 2023-11-19 10:56:50 --> Router Class Initialized
INFO - 2023-11-19 10:56:50 --> Output Class Initialized
INFO - 2023-11-19 10:56:50 --> Security Class Initialized
DEBUG - 2023-11-19 10:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 10:56:50 --> Input Class Initialized
INFO - 2023-11-19 10:56:50 --> Language Class Initialized
INFO - 2023-11-19 10:56:50 --> Loader Class Initialized
INFO - 2023-11-19 10:56:50 --> Helper loaded: url_helper
INFO - 2023-11-19 10:56:50 --> Helper loaded: form_helper
INFO - 2023-11-19 10:56:50 --> Helper loaded: file_helper
INFO - 2023-11-19 10:56:50 --> Database Driver Class Initialized
DEBUG - 2023-11-19 10:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 10:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 10:56:50 --> Form Validation Class Initialized
INFO - 2023-11-19 10:56:50 --> Upload Class Initialized
INFO - 2023-11-19 10:56:50 --> Model "M_auth" initialized
INFO - 2023-11-19 10:56:50 --> Model "M_user" initialized
INFO - 2023-11-19 10:56:50 --> Model "M_produk" initialized
INFO - 2023-11-19 10:56:50 --> Controller Class Initialized
INFO - 2023-11-19 10:56:50 --> Model "M_pelanggan" initialized
INFO - 2023-11-19 10:56:50 --> Model "M_produk" initialized
DEBUG - 2023-11-19 10:56:50 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-19 10:56:50 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-19 10:56:50 --> Model "M_transaksi" initialized
INFO - 2023-11-19 10:56:50 --> Model "M_bank" initialized
INFO - 2023-11-19 10:56:50 --> Model "M_pesan" initialized
DEBUG - 2023-11-19 10:56:50 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-19 10:56:50 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-19 10:56:50 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-19 10:56:50 --> Final output sent to browser
DEBUG - 2023-11-19 10:56:50 --> Total execution time: 0.0082
ERROR - 2023-11-19 10:56:50 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-19 10:56:50 --> Config Class Initialized
INFO - 2023-11-19 10:56:50 --> Hooks Class Initialized
DEBUG - 2023-11-19 10:56:50 --> UTF-8 Support Enabled
INFO - 2023-11-19 10:56:50 --> Utf8 Class Initialized
INFO - 2023-11-19 10:56:50 --> URI Class Initialized
DEBUG - 2023-11-19 10:56:50 --> No URI present. Default controller set.
INFO - 2023-11-19 10:56:50 --> Router Class Initialized
INFO - 2023-11-19 10:56:50 --> Output Class Initialized
INFO - 2023-11-19 10:56:50 --> Security Class Initialized
DEBUG - 2023-11-19 10:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 10:56:50 --> Input Class Initialized
INFO - 2023-11-19 10:56:50 --> Language Class Initialized
INFO - 2023-11-19 10:56:50 --> Loader Class Initialized
INFO - 2023-11-19 10:56:50 --> Helper loaded: url_helper
INFO - 2023-11-19 10:56:50 --> Helper loaded: form_helper
INFO - 2023-11-19 10:56:50 --> Helper loaded: file_helper
INFO - 2023-11-19 10:56:50 --> Database Driver Class Initialized
DEBUG - 2023-11-19 10:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 10:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 10:56:50 --> Form Validation Class Initialized
INFO - 2023-11-19 10:56:50 --> Upload Class Initialized
INFO - 2023-11-19 10:56:50 --> Model "M_auth" initialized
INFO - 2023-11-19 10:56:50 --> Model "M_user" initialized
INFO - 2023-11-19 10:56:50 --> Model "M_produk" initialized
INFO - 2023-11-19 10:56:50 --> Controller Class Initialized
INFO - 2023-11-19 10:56:50 --> Model "M_pelanggan" initialized
INFO - 2023-11-19 10:56:50 --> Model "M_produk" initialized
DEBUG - 2023-11-19 10:56:50 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-19 10:56:50 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-19 10:56:50 --> Model "M_transaksi" initialized
INFO - 2023-11-19 10:56:50 --> Model "M_bank" initialized
INFO - 2023-11-19 10:56:50 --> Model "M_pesan" initialized
DEBUG - 2023-11-19 10:56:50 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-19 10:56:50 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-19 10:56:50 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-19 10:56:50 --> Final output sent to browser
DEBUG - 2023-11-19 10:56:50 --> Total execution time: 0.0039
ERROR - 2023-11-19 12:39:59 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-19 12:39:59 --> Config Class Initialized
INFO - 2023-11-19 12:39:59 --> Hooks Class Initialized
DEBUG - 2023-11-19 12:39:59 --> UTF-8 Support Enabled
INFO - 2023-11-19 12:39:59 --> Utf8 Class Initialized
INFO - 2023-11-19 12:39:59 --> URI Class Initialized
INFO - 2023-11-19 12:39:59 --> Router Class Initialized
INFO - 2023-11-19 12:39:59 --> Output Class Initialized
INFO - 2023-11-19 12:39:59 --> Security Class Initialized
DEBUG - 2023-11-19 12:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 12:39:59 --> Input Class Initialized
INFO - 2023-11-19 12:39:59 --> Language Class Initialized
INFO - 2023-11-19 12:39:59 --> Loader Class Initialized
INFO - 2023-11-19 12:39:59 --> Helper loaded: url_helper
INFO - 2023-11-19 12:39:59 --> Helper loaded: form_helper
INFO - 2023-11-19 12:39:59 --> Helper loaded: file_helper
INFO - 2023-11-19 12:39:59 --> Database Driver Class Initialized
DEBUG - 2023-11-19 12:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 12:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 12:39:59 --> Form Validation Class Initialized
INFO - 2023-11-19 12:39:59 --> Upload Class Initialized
INFO - 2023-11-19 12:39:59 --> Model "M_auth" initialized
INFO - 2023-11-19 12:39:59 --> Model "M_user" initialized
INFO - 2023-11-19 12:39:59 --> Model "M_produk" initialized
INFO - 2023-11-19 12:39:59 --> Controller Class Initialized
INFO - 2023-11-19 12:39:59 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-19 12:39:59 --> Final output sent to browser
DEBUG - 2023-11-19 12:39:59 --> Total execution time: 0.0275
ERROR - 2023-11-19 12:39:59 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-19 12:39:59 --> Config Class Initialized
INFO - 2023-11-19 12:39:59 --> Hooks Class Initialized
DEBUG - 2023-11-19 12:39:59 --> UTF-8 Support Enabled
INFO - 2023-11-19 12:39:59 --> Utf8 Class Initialized
INFO - 2023-11-19 12:39:59 --> URI Class Initialized
DEBUG - 2023-11-19 12:39:59 --> No URI present. Default controller set.
INFO - 2023-11-19 12:39:59 --> Router Class Initialized
INFO - 2023-11-19 12:39:59 --> Output Class Initialized
INFO - 2023-11-19 12:39:59 --> Security Class Initialized
DEBUG - 2023-11-19 12:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 12:39:59 --> Input Class Initialized
INFO - 2023-11-19 12:39:59 --> Language Class Initialized
INFO - 2023-11-19 12:39:59 --> Loader Class Initialized
INFO - 2023-11-19 12:39:59 --> Helper loaded: url_helper
INFO - 2023-11-19 12:39:59 --> Helper loaded: form_helper
INFO - 2023-11-19 12:39:59 --> Helper loaded: file_helper
INFO - 2023-11-19 12:39:59 --> Database Driver Class Initialized
DEBUG - 2023-11-19 12:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 12:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 12:39:59 --> Form Validation Class Initialized
INFO - 2023-11-19 12:39:59 --> Upload Class Initialized
INFO - 2023-11-19 12:39:59 --> Model "M_auth" initialized
INFO - 2023-11-19 12:39:59 --> Model "M_user" initialized
INFO - 2023-11-19 12:39:59 --> Model "M_produk" initialized
INFO - 2023-11-19 12:39:59 --> Controller Class Initialized
INFO - 2023-11-19 12:39:59 --> Model "M_pelanggan" initialized
INFO - 2023-11-19 12:39:59 --> Model "M_produk" initialized
DEBUG - 2023-11-19 12:39:59 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-19 12:39:59 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-19 12:39:59 --> Model "M_transaksi" initialized
INFO - 2023-11-19 12:39:59 --> Model "M_bank" initialized
INFO - 2023-11-19 12:39:59 --> Model "M_pesan" initialized
DEBUG - 2023-11-19 12:39:59 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-19 12:39:59 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-19 12:39:59 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-19 12:39:59 --> Final output sent to browser
DEBUG - 2023-11-19 12:39:59 --> Total execution time: 0.0088
ERROR - 2023-11-19 15:28:22 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-19 15:28:22 --> Config Class Initialized
INFO - 2023-11-19 15:28:22 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:28:22 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:28:22 --> Utf8 Class Initialized
INFO - 2023-11-19 15:28:22 --> URI Class Initialized
INFO - 2023-11-19 15:28:22 --> Router Class Initialized
INFO - 2023-11-19 15:28:22 --> Output Class Initialized
INFO - 2023-11-19 15:28:22 --> Security Class Initialized
DEBUG - 2023-11-19 15:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:28:22 --> Input Class Initialized
INFO - 2023-11-19 15:28:22 --> Language Class Initialized
INFO - 2023-11-19 15:28:22 --> Loader Class Initialized
INFO - 2023-11-19 15:28:22 --> Helper loaded: url_helper
INFO - 2023-11-19 15:28:22 --> Helper loaded: form_helper
INFO - 2023-11-19 15:28:22 --> Helper loaded: file_helper
INFO - 2023-11-19 15:28:22 --> Database Driver Class Initialized
DEBUG - 2023-11-19 15:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 15:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 15:28:22 --> Form Validation Class Initialized
INFO - 2023-11-19 15:28:22 --> Upload Class Initialized
INFO - 2023-11-19 15:28:22 --> Model "M_auth" initialized
INFO - 2023-11-19 15:28:22 --> Model "M_user" initialized
INFO - 2023-11-19 15:28:22 --> Model "M_produk" initialized
INFO - 2023-11-19 15:28:22 --> Controller Class Initialized
INFO - 2023-11-19 15:28:22 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-19 15:28:22 --> Final output sent to browser
DEBUG - 2023-11-19 15:28:22 --> Total execution time: 0.0249
ERROR - 2023-11-19 15:28:23 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-19 15:28:23 --> Config Class Initialized
INFO - 2023-11-19 15:28:23 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:28:23 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:28:23 --> Utf8 Class Initialized
INFO - 2023-11-19 15:28:23 --> URI Class Initialized
DEBUG - 2023-11-19 15:28:23 --> No URI present. Default controller set.
INFO - 2023-11-19 15:28:23 --> Router Class Initialized
INFO - 2023-11-19 15:28:23 --> Output Class Initialized
INFO - 2023-11-19 15:28:23 --> Security Class Initialized
DEBUG - 2023-11-19 15:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:28:23 --> Input Class Initialized
INFO - 2023-11-19 15:28:23 --> Language Class Initialized
INFO - 2023-11-19 15:28:23 --> Loader Class Initialized
INFO - 2023-11-19 15:28:23 --> Helper loaded: url_helper
INFO - 2023-11-19 15:28:23 --> Helper loaded: form_helper
INFO - 2023-11-19 15:28:23 --> Helper loaded: file_helper
INFO - 2023-11-19 15:28:23 --> Database Driver Class Initialized
DEBUG - 2023-11-19 15:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 15:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 15:28:23 --> Form Validation Class Initialized
INFO - 2023-11-19 15:28:23 --> Upload Class Initialized
INFO - 2023-11-19 15:28:23 --> Model "M_auth" initialized
INFO - 2023-11-19 15:28:23 --> Model "M_user" initialized
INFO - 2023-11-19 15:28:23 --> Model "M_produk" initialized
INFO - 2023-11-19 15:28:23 --> Controller Class Initialized
INFO - 2023-11-19 15:28:23 --> Model "M_pelanggan" initialized
INFO - 2023-11-19 15:28:23 --> Model "M_produk" initialized
DEBUG - 2023-11-19 15:28:23 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-19 15:28:23 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-19 15:28:23 --> Model "M_transaksi" initialized
INFO - 2023-11-19 15:28:23 --> Model "M_bank" initialized
INFO - 2023-11-19 15:28:23 --> Model "M_pesan" initialized
DEBUG - 2023-11-19 15:28:23 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-19 15:28:23 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-19 15:28:23 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-19 15:28:23 --> Final output sent to browser
DEBUG - 2023-11-19 15:28:23 --> Total execution time: 0.0085
ERROR - 2023-11-19 15:59:52 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-19 15:59:52 --> Config Class Initialized
INFO - 2023-11-19 15:59:52 --> Hooks Class Initialized
DEBUG - 2023-11-19 15:59:52 --> UTF-8 Support Enabled
INFO - 2023-11-19 15:59:52 --> Utf8 Class Initialized
INFO - 2023-11-19 15:59:52 --> URI Class Initialized
DEBUG - 2023-11-19 15:59:52 --> No URI present. Default controller set.
INFO - 2023-11-19 15:59:52 --> Router Class Initialized
INFO - 2023-11-19 15:59:52 --> Output Class Initialized
INFO - 2023-11-19 15:59:52 --> Security Class Initialized
DEBUG - 2023-11-19 15:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 15:59:52 --> Input Class Initialized
INFO - 2023-11-19 15:59:52 --> Language Class Initialized
INFO - 2023-11-19 15:59:52 --> Loader Class Initialized
INFO - 2023-11-19 15:59:52 --> Helper loaded: url_helper
INFO - 2023-11-19 15:59:52 --> Helper loaded: form_helper
INFO - 2023-11-19 15:59:52 --> Helper loaded: file_helper
INFO - 2023-11-19 15:59:52 --> Database Driver Class Initialized
DEBUG - 2023-11-19 15:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 15:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 15:59:52 --> Form Validation Class Initialized
INFO - 2023-11-19 15:59:52 --> Upload Class Initialized
INFO - 2023-11-19 15:59:52 --> Model "M_auth" initialized
INFO - 2023-11-19 15:59:52 --> Model "M_user" initialized
INFO - 2023-11-19 15:59:52 --> Model "M_produk" initialized
INFO - 2023-11-19 15:59:52 --> Controller Class Initialized
INFO - 2023-11-19 15:59:52 --> Model "M_pelanggan" initialized
INFO - 2023-11-19 15:59:52 --> Model "M_produk" initialized
DEBUG - 2023-11-19 15:59:52 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-19 15:59:52 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-19 15:59:52 --> Model "M_transaksi" initialized
INFO - 2023-11-19 15:59:52 --> Model "M_bank" initialized
INFO - 2023-11-19 15:59:52 --> Model "M_pesan" initialized
DEBUG - 2023-11-19 15:59:52 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-19 15:59:52 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-19 15:59:52 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-19 15:59:52 --> Final output sent to browser
DEBUG - 2023-11-19 15:59:52 --> Total execution time: 0.0322
ERROR - 2023-11-19 16:24:24 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-19 16:24:24 --> Config Class Initialized
INFO - 2023-11-19 16:24:24 --> Hooks Class Initialized
DEBUG - 2023-11-19 16:24:24 --> UTF-8 Support Enabled
INFO - 2023-11-19 16:24:24 --> Utf8 Class Initialized
INFO - 2023-11-19 16:24:24 --> URI Class Initialized
DEBUG - 2023-11-19 16:24:24 --> No URI present. Default controller set.
INFO - 2023-11-19 16:24:24 --> Router Class Initialized
INFO - 2023-11-19 16:24:24 --> Output Class Initialized
INFO - 2023-11-19 16:24:24 --> Security Class Initialized
DEBUG - 2023-11-19 16:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 16:24:24 --> Input Class Initialized
INFO - 2023-11-19 16:24:24 --> Language Class Initialized
INFO - 2023-11-19 16:24:24 --> Loader Class Initialized
INFO - 2023-11-19 16:24:24 --> Helper loaded: url_helper
INFO - 2023-11-19 16:24:24 --> Helper loaded: form_helper
INFO - 2023-11-19 16:24:24 --> Helper loaded: file_helper
INFO - 2023-11-19 16:24:24 --> Database Driver Class Initialized
DEBUG - 2023-11-19 16:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 16:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 16:24:24 --> Form Validation Class Initialized
INFO - 2023-11-19 16:24:24 --> Upload Class Initialized
INFO - 2023-11-19 16:24:24 --> Model "M_auth" initialized
INFO - 2023-11-19 16:24:24 --> Model "M_user" initialized
INFO - 2023-11-19 16:24:24 --> Model "M_produk" initialized
INFO - 2023-11-19 16:24:24 --> Controller Class Initialized
INFO - 2023-11-19 16:24:24 --> Model "M_pelanggan" initialized
INFO - 2023-11-19 16:24:24 --> Model "M_produk" initialized
DEBUG - 2023-11-19 16:24:24 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-19 16:24:24 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-19 16:24:24 --> Model "M_transaksi" initialized
INFO - 2023-11-19 16:24:24 --> Model "M_bank" initialized
INFO - 2023-11-19 16:24:24 --> Model "M_pesan" initialized
DEBUG - 2023-11-19 16:24:24 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-19 16:24:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-19 16:24:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-19 16:24:24 --> Final output sent to browser
DEBUG - 2023-11-19 16:24:24 --> Total execution time: 0.0416
ERROR - 2023-11-19 18:37:06 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-19 18:37:06 --> Config Class Initialized
INFO - 2023-11-19 18:37:06 --> Hooks Class Initialized
DEBUG - 2023-11-19 18:37:06 --> UTF-8 Support Enabled
INFO - 2023-11-19 18:37:06 --> Utf8 Class Initialized
INFO - 2023-11-19 18:37:06 --> URI Class Initialized
DEBUG - 2023-11-19 18:37:06 --> No URI present. Default controller set.
INFO - 2023-11-19 18:37:06 --> Router Class Initialized
INFO - 2023-11-19 18:37:06 --> Output Class Initialized
INFO - 2023-11-19 18:37:06 --> Security Class Initialized
DEBUG - 2023-11-19 18:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 18:37:06 --> Input Class Initialized
INFO - 2023-11-19 18:37:06 --> Language Class Initialized
INFO - 2023-11-19 18:37:06 --> Loader Class Initialized
INFO - 2023-11-19 18:37:06 --> Helper loaded: url_helper
INFO - 2023-11-19 18:37:06 --> Helper loaded: form_helper
INFO - 2023-11-19 18:37:06 --> Helper loaded: file_helper
INFO - 2023-11-19 18:37:06 --> Database Driver Class Initialized
DEBUG - 2023-11-19 18:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 18:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 18:37:06 --> Form Validation Class Initialized
INFO - 2023-11-19 18:37:06 --> Upload Class Initialized
INFO - 2023-11-19 18:37:06 --> Model "M_auth" initialized
INFO - 2023-11-19 18:37:06 --> Model "M_user" initialized
INFO - 2023-11-19 18:37:06 --> Model "M_produk" initialized
INFO - 2023-11-19 18:37:06 --> Controller Class Initialized
INFO - 2023-11-19 18:37:06 --> Model "M_pelanggan" initialized
INFO - 2023-11-19 18:37:06 --> Model "M_produk" initialized
DEBUG - 2023-11-19 18:37:06 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-19 18:37:06 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-19 18:37:06 --> Model "M_transaksi" initialized
INFO - 2023-11-19 18:37:06 --> Model "M_bank" initialized
INFO - 2023-11-19 18:37:06 --> Model "M_pesan" initialized
DEBUG - 2023-11-19 18:37:06 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-19 18:37:06 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-19 18:37:06 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-19 18:37:06 --> Final output sent to browser
DEBUG - 2023-11-19 18:37:06 --> Total execution time: 0.0368
ERROR - 2023-11-19 19:14:22 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-19 19:14:22 --> Config Class Initialized
INFO - 2023-11-19 19:14:22 --> Hooks Class Initialized
DEBUG - 2023-11-19 19:14:22 --> UTF-8 Support Enabled
INFO - 2023-11-19 19:14:22 --> Utf8 Class Initialized
INFO - 2023-11-19 19:14:22 --> URI Class Initialized
DEBUG - 2023-11-19 19:14:22 --> No URI present. Default controller set.
INFO - 2023-11-19 19:14:22 --> Router Class Initialized
INFO - 2023-11-19 19:14:22 --> Output Class Initialized
INFO - 2023-11-19 19:14:22 --> Security Class Initialized
DEBUG - 2023-11-19 19:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 19:14:22 --> Input Class Initialized
INFO - 2023-11-19 19:14:22 --> Language Class Initialized
INFO - 2023-11-19 19:14:22 --> Loader Class Initialized
INFO - 2023-11-19 19:14:22 --> Helper loaded: url_helper
INFO - 2023-11-19 19:14:22 --> Helper loaded: form_helper
INFO - 2023-11-19 19:14:22 --> Helper loaded: file_helper
INFO - 2023-11-19 19:14:22 --> Database Driver Class Initialized
DEBUG - 2023-11-19 19:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 19:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 19:14:22 --> Form Validation Class Initialized
INFO - 2023-11-19 19:14:22 --> Upload Class Initialized
INFO - 2023-11-19 19:14:22 --> Model "M_auth" initialized
INFO - 2023-11-19 19:14:22 --> Model "M_user" initialized
INFO - 2023-11-19 19:14:22 --> Model "M_produk" initialized
INFO - 2023-11-19 19:14:22 --> Controller Class Initialized
INFO - 2023-11-19 19:14:22 --> Model "M_pelanggan" initialized
INFO - 2023-11-19 19:14:22 --> Model "M_produk" initialized
DEBUG - 2023-11-19 19:14:22 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-19 19:14:22 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-19 19:14:22 --> Model "M_transaksi" initialized
INFO - 2023-11-19 19:14:22 --> Model "M_bank" initialized
INFO - 2023-11-19 19:14:22 --> Model "M_pesan" initialized
DEBUG - 2023-11-19 19:14:22 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-19 19:14:22 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-19 19:14:22 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-19 19:14:22 --> Final output sent to browser
DEBUG - 2023-11-19 19:14:22 --> Total execution time: 0.0346
ERROR - 2023-11-19 21:01:18 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-19 21:01:18 --> Config Class Initialized
INFO - 2023-11-19 21:01:18 --> Hooks Class Initialized
DEBUG - 2023-11-19 21:01:18 --> UTF-8 Support Enabled
INFO - 2023-11-19 21:01:18 --> Utf8 Class Initialized
INFO - 2023-11-19 21:01:18 --> URI Class Initialized
INFO - 2023-11-19 21:01:18 --> Router Class Initialized
INFO - 2023-11-19 21:01:18 --> Output Class Initialized
INFO - 2023-11-19 21:01:18 --> Security Class Initialized
DEBUG - 2023-11-19 21:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 21:01:18 --> Input Class Initialized
INFO - 2023-11-19 21:01:18 --> Language Class Initialized
INFO - 2023-11-19 21:01:18 --> Loader Class Initialized
INFO - 2023-11-19 21:01:18 --> Helper loaded: url_helper
INFO - 2023-11-19 21:01:18 --> Helper loaded: form_helper
INFO - 2023-11-19 21:01:18 --> Helper loaded: file_helper
INFO - 2023-11-19 21:01:18 --> Database Driver Class Initialized
DEBUG - 2023-11-19 21:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 21:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 21:01:18 --> Form Validation Class Initialized
INFO - 2023-11-19 21:01:18 --> Upload Class Initialized
INFO - 2023-11-19 21:01:18 --> Model "M_auth" initialized
INFO - 2023-11-19 21:01:18 --> Model "M_user" initialized
INFO - 2023-11-19 21:01:18 --> Model "M_produk" initialized
INFO - 2023-11-19 21:01:18 --> Controller Class Initialized
INFO - 2023-11-19 21:01:18 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-19 21:01:18 --> Final output sent to browser
DEBUG - 2023-11-19 21:01:18 --> Total execution time: 0.0247
ERROR - 2023-11-19 21:36:30 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-19 21:36:30 --> Config Class Initialized
INFO - 2023-11-19 21:36:30 --> Hooks Class Initialized
DEBUG - 2023-11-19 21:36:30 --> UTF-8 Support Enabled
INFO - 2023-11-19 21:36:30 --> Utf8 Class Initialized
INFO - 2023-11-19 21:36:30 --> URI Class Initialized
INFO - 2023-11-19 21:36:30 --> Router Class Initialized
INFO - 2023-11-19 21:36:30 --> Output Class Initialized
INFO - 2023-11-19 21:36:30 --> Security Class Initialized
DEBUG - 2023-11-19 21:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 21:36:30 --> Input Class Initialized
INFO - 2023-11-19 21:36:30 --> Language Class Initialized
INFO - 2023-11-19 21:36:30 --> Loader Class Initialized
INFO - 2023-11-19 21:36:30 --> Helper loaded: url_helper
INFO - 2023-11-19 21:36:30 --> Helper loaded: form_helper
INFO - 2023-11-19 21:36:30 --> Helper loaded: file_helper
INFO - 2023-11-19 21:36:30 --> Database Driver Class Initialized
DEBUG - 2023-11-19 21:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 21:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 21:36:30 --> Form Validation Class Initialized
INFO - 2023-11-19 21:36:30 --> Upload Class Initialized
INFO - 2023-11-19 21:36:30 --> Model "M_auth" initialized
INFO - 2023-11-19 21:36:30 --> Model "M_user" initialized
INFO - 2023-11-19 21:36:30 --> Model "M_produk" initialized
INFO - 2023-11-19 21:36:30 --> Controller Class Initialized
INFO - 2023-11-19 21:36:30 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-19 21:36:30 --> Final output sent to browser
DEBUG - 2023-11-19 21:36:30 --> Total execution time: 0.0286
ERROR - 2023-11-19 21:36:30 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-19 21:36:30 --> Config Class Initialized
INFO - 2023-11-19 21:36:30 --> Hooks Class Initialized
DEBUG - 2023-11-19 21:36:30 --> UTF-8 Support Enabled
INFO - 2023-11-19 21:36:30 --> Utf8 Class Initialized
INFO - 2023-11-19 21:36:30 --> URI Class Initialized
INFO - 2023-11-19 21:36:30 --> Router Class Initialized
INFO - 2023-11-19 21:36:30 --> Output Class Initialized
INFO - 2023-11-19 21:36:30 --> Security Class Initialized
DEBUG - 2023-11-19 21:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 21:36:30 --> Input Class Initialized
INFO - 2023-11-19 21:36:30 --> Language Class Initialized
INFO - 2023-11-19 21:36:30 --> Loader Class Initialized
INFO - 2023-11-19 21:36:30 --> Helper loaded: url_helper
INFO - 2023-11-19 21:36:30 --> Helper loaded: form_helper
INFO - 2023-11-19 21:36:30 --> Helper loaded: file_helper
INFO - 2023-11-19 21:36:30 --> Database Driver Class Initialized
DEBUG - 2023-11-19 21:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 21:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 21:36:30 --> Form Validation Class Initialized
INFO - 2023-11-19 21:36:30 --> Upload Class Initialized
INFO - 2023-11-19 21:36:30 --> Model "M_auth" initialized
INFO - 2023-11-19 21:36:30 --> Model "M_user" initialized
INFO - 2023-11-19 21:36:30 --> Model "M_produk" initialized
INFO - 2023-11-19 21:36:30 --> Controller Class Initialized
INFO - 2023-11-19 21:36:30 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-19 21:36:30 --> Final output sent to browser
DEBUG - 2023-11-19 21:36:30 --> Total execution time: 0.0028
ERROR - 2023-11-19 23:52:25 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-19 23:52:25 --> Config Class Initialized
INFO - 2023-11-19 23:52:25 --> Hooks Class Initialized
DEBUG - 2023-11-19 23:52:25 --> UTF-8 Support Enabled
INFO - 2023-11-19 23:52:25 --> Utf8 Class Initialized
INFO - 2023-11-19 23:52:25 --> URI Class Initialized
DEBUG - 2023-11-19 23:52:25 --> No URI present. Default controller set.
INFO - 2023-11-19 23:52:25 --> Router Class Initialized
INFO - 2023-11-19 23:52:25 --> Output Class Initialized
INFO - 2023-11-19 23:52:25 --> Security Class Initialized
DEBUG - 2023-11-19 23:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-19 23:52:25 --> Input Class Initialized
INFO - 2023-11-19 23:52:25 --> Language Class Initialized
INFO - 2023-11-19 23:52:25 --> Loader Class Initialized
INFO - 2023-11-19 23:52:25 --> Helper loaded: url_helper
INFO - 2023-11-19 23:52:25 --> Helper loaded: form_helper
INFO - 2023-11-19 23:52:25 --> Helper loaded: file_helper
INFO - 2023-11-19 23:52:25 --> Database Driver Class Initialized
DEBUG - 2023-11-19 23:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-19 23:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-19 23:52:25 --> Form Validation Class Initialized
INFO - 2023-11-19 23:52:25 --> Upload Class Initialized
INFO - 2023-11-19 23:52:25 --> Model "M_auth" initialized
INFO - 2023-11-19 23:52:25 --> Model "M_user" initialized
INFO - 2023-11-19 23:52:25 --> Model "M_produk" initialized
INFO - 2023-11-19 23:52:25 --> Controller Class Initialized
INFO - 2023-11-19 23:52:25 --> Model "M_pelanggan" initialized
INFO - 2023-11-19 23:52:25 --> Model "M_produk" initialized
DEBUG - 2023-11-19 23:52:25 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-19 23:52:25 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-19 23:52:25 --> Model "M_transaksi" initialized
INFO - 2023-11-19 23:52:25 --> Model "M_bank" initialized
INFO - 2023-11-19 23:52:25 --> Model "M_pesan" initialized
DEBUG - 2023-11-19 23:52:25 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-19 23:52:25 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-19 23:52:25 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-19 23:52:25 --> Final output sent to browser
DEBUG - 2023-11-19 23:52:25 --> Total execution time: 0.0326
