<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-04 00:06:08 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-04 00:06:08 --> Config Class Initialized
INFO - 2023-12-04 00:06:08 --> Hooks Class Initialized
DEBUG - 2023-12-04 00:06:09 --> UTF-8 Support Enabled
INFO - 2023-12-04 00:06:09 --> Utf8 Class Initialized
INFO - 2023-12-04 00:06:09 --> URI Class Initialized
DEBUG - 2023-12-04 00:06:09 --> No URI present. Default controller set.
INFO - 2023-12-04 00:06:09 --> Router Class Initialized
INFO - 2023-12-04 00:06:09 --> Output Class Initialized
INFO - 2023-12-04 00:06:09 --> Security Class Initialized
DEBUG - 2023-12-04 00:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 00:06:09 --> Input Class Initialized
INFO - 2023-12-04 00:06:09 --> Language Class Initialized
INFO - 2023-12-04 00:06:09 --> Loader Class Initialized
INFO - 2023-12-04 00:06:09 --> Helper loaded: url_helper
INFO - 2023-12-04 00:06:09 --> Helper loaded: form_helper
INFO - 2023-12-04 00:06:09 --> Helper loaded: file_helper
INFO - 2023-12-04 00:06:09 --> Database Driver Class Initialized
DEBUG - 2023-12-04 00:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 00:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 00:06:09 --> Form Validation Class Initialized
INFO - 2023-12-04 00:06:09 --> Upload Class Initialized
INFO - 2023-12-04 00:06:09 --> Model "M_auth" initialized
INFO - 2023-12-04 00:06:09 --> Model "M_user" initialized
INFO - 2023-12-04 00:06:09 --> Model "M_produk" initialized
INFO - 2023-12-04 00:06:09 --> Controller Class Initialized
INFO - 2023-12-04 00:06:09 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 00:06:09 --> Model "M_produk" initialized
DEBUG - 2023-12-04 00:06:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 00:06:09 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 00:06:09 --> Model "M_transaksi" initialized
INFO - 2023-12-04 00:06:09 --> Model "M_bank" initialized
INFO - 2023-12-04 00:06:09 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 00:06:09 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-04 00:06:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-04 00:06:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-04 00:06:09 --> Final output sent to browser
DEBUG - 2023-12-04 00:06:09 --> Total execution time: 0.0332
ERROR - 2023-12-04 03:25:49 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-04 03:25:49 --> Config Class Initialized
INFO - 2023-12-04 03:25:49 --> Hooks Class Initialized
DEBUG - 2023-12-04 03:25:49 --> UTF-8 Support Enabled
INFO - 2023-12-04 03:25:49 --> Utf8 Class Initialized
INFO - 2023-12-04 03:25:49 --> URI Class Initialized
DEBUG - 2023-12-04 03:25:49 --> No URI present. Default controller set.
INFO - 2023-12-04 03:25:49 --> Router Class Initialized
INFO - 2023-12-04 03:25:49 --> Output Class Initialized
INFO - 2023-12-04 03:25:49 --> Security Class Initialized
DEBUG - 2023-12-04 03:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 03:25:49 --> Input Class Initialized
INFO - 2023-12-04 03:25:49 --> Language Class Initialized
INFO - 2023-12-04 03:25:49 --> Loader Class Initialized
INFO - 2023-12-04 03:25:49 --> Helper loaded: url_helper
INFO - 2023-12-04 03:25:49 --> Helper loaded: form_helper
INFO - 2023-12-04 03:25:49 --> Helper loaded: file_helper
INFO - 2023-12-04 03:25:49 --> Database Driver Class Initialized
DEBUG - 2023-12-04 03:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 03:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 03:25:49 --> Form Validation Class Initialized
INFO - 2023-12-04 03:25:49 --> Upload Class Initialized
INFO - 2023-12-04 03:25:49 --> Model "M_auth" initialized
INFO - 2023-12-04 03:25:49 --> Model "M_user" initialized
INFO - 2023-12-04 03:25:49 --> Model "M_produk" initialized
INFO - 2023-12-04 03:25:49 --> Controller Class Initialized
INFO - 2023-12-04 03:25:49 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 03:25:49 --> Model "M_produk" initialized
DEBUG - 2023-12-04 03:25:49 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 03:25:49 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 03:25:49 --> Model "M_transaksi" initialized
INFO - 2023-12-04 03:25:49 --> Model "M_bank" initialized
INFO - 2023-12-04 03:25:49 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 03:25:49 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-04 03:25:49 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-04 03:25:49 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-04 03:25:49 --> Final output sent to browser
DEBUG - 2023-12-04 03:25:49 --> Total execution time: 0.0314
ERROR - 2023-12-04 03:35:10 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-04 03:35:10 --> Config Class Initialized
INFO - 2023-12-04 03:35:10 --> Hooks Class Initialized
DEBUG - 2023-12-04 03:35:10 --> UTF-8 Support Enabled
INFO - 2023-12-04 03:35:10 --> Utf8 Class Initialized
INFO - 2023-12-04 03:35:10 --> URI Class Initialized
DEBUG - 2023-12-04 03:35:10 --> No URI present. Default controller set.
INFO - 2023-12-04 03:35:10 --> Router Class Initialized
INFO - 2023-12-04 03:35:10 --> Output Class Initialized
INFO - 2023-12-04 03:35:10 --> Security Class Initialized
DEBUG - 2023-12-04 03:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 03:35:10 --> Input Class Initialized
INFO - 2023-12-04 03:35:10 --> Language Class Initialized
INFO - 2023-12-04 03:35:10 --> Loader Class Initialized
INFO - 2023-12-04 03:35:10 --> Helper loaded: url_helper
INFO - 2023-12-04 03:35:10 --> Helper loaded: form_helper
INFO - 2023-12-04 03:35:10 --> Helper loaded: file_helper
INFO - 2023-12-04 03:35:10 --> Database Driver Class Initialized
DEBUG - 2023-12-04 03:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 03:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 03:35:10 --> Form Validation Class Initialized
INFO - 2023-12-04 03:35:10 --> Upload Class Initialized
INFO - 2023-12-04 03:35:10 --> Model "M_auth" initialized
INFO - 2023-12-04 03:35:10 --> Model "M_user" initialized
INFO - 2023-12-04 03:35:10 --> Model "M_produk" initialized
INFO - 2023-12-04 03:35:10 --> Controller Class Initialized
INFO - 2023-12-04 03:35:10 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 03:35:10 --> Model "M_produk" initialized
DEBUG - 2023-12-04 03:35:10 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 03:35:10 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 03:35:10 --> Model "M_transaksi" initialized
INFO - 2023-12-04 03:35:10 --> Model "M_bank" initialized
INFO - 2023-12-04 03:35:10 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 03:35:10 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-04 03:35:10 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-04 03:35:10 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-04 03:35:10 --> Final output sent to browser
DEBUG - 2023-12-04 03:35:10 --> Total execution time: 0.0362
ERROR - 2023-12-04 03:37:28 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-04 03:37:28 --> Config Class Initialized
INFO - 2023-12-04 03:37:28 --> Hooks Class Initialized
DEBUG - 2023-12-04 03:37:28 --> UTF-8 Support Enabled
INFO - 2023-12-04 03:37:28 --> Utf8 Class Initialized
INFO - 2023-12-04 03:37:28 --> URI Class Initialized
DEBUG - 2023-12-04 03:37:28 --> No URI present. Default controller set.
INFO - 2023-12-04 03:37:28 --> Router Class Initialized
INFO - 2023-12-04 03:37:28 --> Output Class Initialized
INFO - 2023-12-04 03:37:28 --> Security Class Initialized
DEBUG - 2023-12-04 03:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 03:37:28 --> Input Class Initialized
INFO - 2023-12-04 03:37:28 --> Language Class Initialized
INFO - 2023-12-04 03:37:28 --> Loader Class Initialized
INFO - 2023-12-04 03:37:28 --> Helper loaded: url_helper
INFO - 2023-12-04 03:37:28 --> Helper loaded: form_helper
INFO - 2023-12-04 03:37:28 --> Helper loaded: file_helper
INFO - 2023-12-04 03:37:28 --> Database Driver Class Initialized
DEBUG - 2023-12-04 03:37:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 03:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 03:37:28 --> Form Validation Class Initialized
INFO - 2023-12-04 03:37:28 --> Upload Class Initialized
INFO - 2023-12-04 03:37:28 --> Model "M_auth" initialized
INFO - 2023-12-04 03:37:28 --> Model "M_user" initialized
INFO - 2023-12-04 03:37:28 --> Model "M_produk" initialized
INFO - 2023-12-04 03:37:28 --> Controller Class Initialized
INFO - 2023-12-04 03:37:28 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 03:37:28 --> Model "M_produk" initialized
DEBUG - 2023-12-04 03:37:28 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 03:37:28 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 03:37:28 --> Model "M_transaksi" initialized
INFO - 2023-12-04 03:37:28 --> Model "M_bank" initialized
INFO - 2023-12-04 03:37:28 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 03:37:28 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-04 03:37:28 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-04 03:37:28 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-04 03:37:28 --> Final output sent to browser
DEBUG - 2023-12-04 03:37:28 --> Total execution time: 0.0041
ERROR - 2023-12-04 03:41:19 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-04 03:41:19 --> Config Class Initialized
INFO - 2023-12-04 03:41:19 --> Hooks Class Initialized
DEBUG - 2023-12-04 03:41:19 --> UTF-8 Support Enabled
INFO - 2023-12-04 03:41:19 --> Utf8 Class Initialized
INFO - 2023-12-04 03:41:19 --> URI Class Initialized
DEBUG - 2023-12-04 03:41:19 --> No URI present. Default controller set.
INFO - 2023-12-04 03:41:19 --> Router Class Initialized
INFO - 2023-12-04 03:41:19 --> Output Class Initialized
INFO - 2023-12-04 03:41:19 --> Security Class Initialized
DEBUG - 2023-12-04 03:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 03:41:19 --> Input Class Initialized
INFO - 2023-12-04 03:41:19 --> Language Class Initialized
INFO - 2023-12-04 03:41:19 --> Loader Class Initialized
INFO - 2023-12-04 03:41:19 --> Helper loaded: url_helper
INFO - 2023-12-04 03:41:19 --> Helper loaded: form_helper
INFO - 2023-12-04 03:41:19 --> Helper loaded: file_helper
INFO - 2023-12-04 03:41:19 --> Database Driver Class Initialized
DEBUG - 2023-12-04 03:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 03:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 03:41:19 --> Form Validation Class Initialized
INFO - 2023-12-04 03:41:19 --> Upload Class Initialized
INFO - 2023-12-04 03:41:19 --> Model "M_auth" initialized
INFO - 2023-12-04 03:41:19 --> Model "M_user" initialized
INFO - 2023-12-04 03:41:19 --> Model "M_produk" initialized
INFO - 2023-12-04 03:41:19 --> Controller Class Initialized
INFO - 2023-12-04 03:41:19 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 03:41:19 --> Model "M_produk" initialized
DEBUG - 2023-12-04 03:41:19 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 03:41:19 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 03:41:19 --> Model "M_transaksi" initialized
INFO - 2023-12-04 03:41:19 --> Model "M_bank" initialized
INFO - 2023-12-04 03:41:19 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 03:41:19 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-04 03:41:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-04 03:41:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-04 03:41:19 --> Final output sent to browser
DEBUG - 2023-12-04 03:41:19 --> Total execution time: 0.0045
ERROR - 2023-12-04 03:41:19 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-04 03:41:19 --> Config Class Initialized
INFO - 2023-12-04 03:41:19 --> Hooks Class Initialized
DEBUG - 2023-12-04 03:41:19 --> UTF-8 Support Enabled
INFO - 2023-12-04 03:41:19 --> Utf8 Class Initialized
INFO - 2023-12-04 03:41:19 --> URI Class Initialized
DEBUG - 2023-12-04 03:41:19 --> No URI present. Default controller set.
INFO - 2023-12-04 03:41:19 --> Router Class Initialized
INFO - 2023-12-04 03:41:19 --> Output Class Initialized
INFO - 2023-12-04 03:41:19 --> Security Class Initialized
DEBUG - 2023-12-04 03:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 03:41:19 --> Input Class Initialized
INFO - 2023-12-04 03:41:19 --> Language Class Initialized
INFO - 2023-12-04 03:41:19 --> Loader Class Initialized
INFO - 2023-12-04 03:41:19 --> Helper loaded: url_helper
INFO - 2023-12-04 03:41:19 --> Helper loaded: form_helper
INFO - 2023-12-04 03:41:19 --> Helper loaded: file_helper
INFO - 2023-12-04 03:41:19 --> Database Driver Class Initialized
DEBUG - 2023-12-04 03:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 03:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 03:41:19 --> Form Validation Class Initialized
INFO - 2023-12-04 03:41:19 --> Upload Class Initialized
INFO - 2023-12-04 03:41:19 --> Model "M_auth" initialized
INFO - 2023-12-04 03:41:19 --> Model "M_user" initialized
INFO - 2023-12-04 03:41:19 --> Model "M_produk" initialized
INFO - 2023-12-04 03:41:19 --> Controller Class Initialized
INFO - 2023-12-04 03:41:19 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 03:41:19 --> Model "M_produk" initialized
DEBUG - 2023-12-04 03:41:19 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 03:41:19 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 03:41:19 --> Model "M_transaksi" initialized
INFO - 2023-12-04 03:41:19 --> Model "M_bank" initialized
INFO - 2023-12-04 03:41:19 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 03:41:19 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-04 03:41:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-04 03:41:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-04 03:41:19 --> Final output sent to browser
DEBUG - 2023-12-04 03:41:19 --> Total execution time: 0.0033
ERROR - 2023-12-04 03:41:21 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-04 03:41:21 --> Config Class Initialized
INFO - 2023-12-04 03:41:21 --> Hooks Class Initialized
DEBUG - 2023-12-04 03:41:21 --> UTF-8 Support Enabled
INFO - 2023-12-04 03:41:21 --> Utf8 Class Initialized
INFO - 2023-12-04 03:41:21 --> URI Class Initialized
INFO - 2023-12-04 03:41:21 --> Router Class Initialized
INFO - 2023-12-04 03:41:21 --> Output Class Initialized
INFO - 2023-12-04 03:41:21 --> Security Class Initialized
DEBUG - 2023-12-04 03:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 03:41:21 --> Input Class Initialized
INFO - 2023-12-04 03:41:21 --> Language Class Initialized
INFO - 2023-12-04 03:41:21 --> Loader Class Initialized
INFO - 2023-12-04 03:41:21 --> Helper loaded: url_helper
INFO - 2023-12-04 03:41:21 --> Helper loaded: form_helper
INFO - 2023-12-04 03:41:21 --> Helper loaded: file_helper
INFO - 2023-12-04 03:41:21 --> Database Driver Class Initialized
DEBUG - 2023-12-04 03:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 03:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 03:41:21 --> Form Validation Class Initialized
INFO - 2023-12-04 03:41:21 --> Upload Class Initialized
INFO - 2023-12-04 03:41:21 --> Model "M_auth" initialized
INFO - 2023-12-04 03:41:21 --> Model "M_user" initialized
INFO - 2023-12-04 03:41:21 --> Model "M_produk" initialized
INFO - 2023-12-04 03:41:21 --> Controller Class Initialized
INFO - 2023-12-04 03:41:21 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-04 03:41:21 --> Final output sent to browser
DEBUG - 2023-12-04 03:41:21 --> Total execution time: 0.0033
ERROR - 2023-12-04 03:41:21 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-04 03:41:21 --> Config Class Initialized
INFO - 2023-12-04 03:41:21 --> Hooks Class Initialized
DEBUG - 2023-12-04 03:41:21 --> UTF-8 Support Enabled
INFO - 2023-12-04 03:41:21 --> Utf8 Class Initialized
INFO - 2023-12-04 03:41:21 --> URI Class Initialized
INFO - 2023-12-04 03:41:21 --> Router Class Initialized
INFO - 2023-12-04 03:41:21 --> Output Class Initialized
INFO - 2023-12-04 03:41:21 --> Security Class Initialized
DEBUG - 2023-12-04 03:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 03:41:21 --> Input Class Initialized
INFO - 2023-12-04 03:41:21 --> Language Class Initialized
INFO - 2023-12-04 03:41:21 --> Loader Class Initialized
INFO - 2023-12-04 03:41:21 --> Helper loaded: url_helper
INFO - 2023-12-04 03:41:21 --> Helper loaded: form_helper
INFO - 2023-12-04 03:41:21 --> Helper loaded: file_helper
INFO - 2023-12-04 03:41:21 --> Database Driver Class Initialized
DEBUG - 2023-12-04 03:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 03:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 03:41:21 --> Form Validation Class Initialized
INFO - 2023-12-04 03:41:21 --> Upload Class Initialized
INFO - 2023-12-04 03:41:21 --> Model "M_auth" initialized
INFO - 2023-12-04 03:41:21 --> Model "M_user" initialized
INFO - 2023-12-04 03:41:21 --> Model "M_produk" initialized
INFO - 2023-12-04 03:41:21 --> Controller Class Initialized
INFO - 2023-12-04 03:41:21 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-04 03:41:21 --> Final output sent to browser
DEBUG - 2023-12-04 03:41:21 --> Total execution time: 0.0026
ERROR - 2023-12-04 03:41:23 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-04 03:41:23 --> Config Class Initialized
INFO - 2023-12-04 03:41:23 --> Hooks Class Initialized
DEBUG - 2023-12-04 03:41:23 --> UTF-8 Support Enabled
INFO - 2023-12-04 03:41:23 --> Utf8 Class Initialized
INFO - 2023-12-04 03:41:23 --> URI Class Initialized
INFO - 2023-12-04 03:41:23 --> Router Class Initialized
INFO - 2023-12-04 03:41:23 --> Output Class Initialized
INFO - 2023-12-04 03:41:23 --> Security Class Initialized
DEBUG - 2023-12-04 03:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 03:41:23 --> Input Class Initialized
INFO - 2023-12-04 03:41:23 --> Language Class Initialized
INFO - 2023-12-04 03:41:23 --> Loader Class Initialized
INFO - 2023-12-04 03:41:23 --> Helper loaded: url_helper
INFO - 2023-12-04 03:41:23 --> Helper loaded: form_helper
INFO - 2023-12-04 03:41:23 --> Helper loaded: file_helper
INFO - 2023-12-04 03:41:23 --> Database Driver Class Initialized
DEBUG - 2023-12-04 03:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 03:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 03:41:23 --> Form Validation Class Initialized
INFO - 2023-12-04 03:41:23 --> Upload Class Initialized
INFO - 2023-12-04 03:41:23 --> Model "M_auth" initialized
INFO - 2023-12-04 03:41:23 --> Model "M_user" initialized
INFO - 2023-12-04 03:41:23 --> Model "M_produk" initialized
INFO - 2023-12-04 03:41:23 --> Controller Class Initialized
INFO - 2023-12-04 03:41:23 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-04 03:41:23 --> Final output sent to browser
DEBUG - 2023-12-04 03:41:23 --> Total execution time: 0.0031
ERROR - 2023-12-04 03:41:23 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-04 03:41:23 --> Config Class Initialized
INFO - 2023-12-04 03:41:23 --> Hooks Class Initialized
DEBUG - 2023-12-04 03:41:23 --> UTF-8 Support Enabled
INFO - 2023-12-04 03:41:23 --> Utf8 Class Initialized
INFO - 2023-12-04 03:41:23 --> URI Class Initialized
INFO - 2023-12-04 03:41:23 --> Router Class Initialized
INFO - 2023-12-04 03:41:23 --> Output Class Initialized
INFO - 2023-12-04 03:41:23 --> Security Class Initialized
DEBUG - 2023-12-04 03:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 03:41:23 --> Input Class Initialized
INFO - 2023-12-04 03:41:23 --> Language Class Initialized
INFO - 2023-12-04 03:41:23 --> Loader Class Initialized
INFO - 2023-12-04 03:41:23 --> Helper loaded: url_helper
INFO - 2023-12-04 03:41:23 --> Helper loaded: form_helper
INFO - 2023-12-04 03:41:23 --> Helper loaded: file_helper
INFO - 2023-12-04 03:41:23 --> Database Driver Class Initialized
DEBUG - 2023-12-04 03:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 03:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 03:41:23 --> Form Validation Class Initialized
INFO - 2023-12-04 03:41:23 --> Upload Class Initialized
INFO - 2023-12-04 03:41:23 --> Model "M_auth" initialized
INFO - 2023-12-04 03:41:23 --> Model "M_user" initialized
INFO - 2023-12-04 03:41:23 --> Model "M_produk" initialized
INFO - 2023-12-04 03:41:23 --> Controller Class Initialized
INFO - 2023-12-04 03:41:23 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-04 03:41:23 --> Final output sent to browser
DEBUG - 2023-12-04 03:41:23 --> Total execution time: 0.0024
ERROR - 2023-12-04 03:45:07 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-04 03:45:07 --> Config Class Initialized
INFO - 2023-12-04 03:45:07 --> Hooks Class Initialized
DEBUG - 2023-12-04 03:45:07 --> UTF-8 Support Enabled
INFO - 2023-12-04 03:45:07 --> Utf8 Class Initialized
INFO - 2023-12-04 03:45:07 --> URI Class Initialized
INFO - 2023-12-04 03:45:07 --> Router Class Initialized
INFO - 2023-12-04 03:45:07 --> Output Class Initialized
INFO - 2023-12-04 03:45:07 --> Security Class Initialized
DEBUG - 2023-12-04 03:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 03:45:07 --> Input Class Initialized
INFO - 2023-12-04 03:45:07 --> Language Class Initialized
INFO - 2023-12-04 03:45:07 --> Loader Class Initialized
INFO - 2023-12-04 03:45:07 --> Helper loaded: url_helper
INFO - 2023-12-04 03:45:07 --> Helper loaded: form_helper
INFO - 2023-12-04 03:45:07 --> Helper loaded: file_helper
INFO - 2023-12-04 03:45:07 --> Database Driver Class Initialized
DEBUG - 2023-12-04 03:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 03:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 03:45:07 --> Form Validation Class Initialized
INFO - 2023-12-04 03:45:07 --> Upload Class Initialized
INFO - 2023-12-04 03:45:07 --> Model "M_auth" initialized
INFO - 2023-12-04 03:45:07 --> Model "M_user" initialized
INFO - 2023-12-04 03:45:07 --> Model "M_produk" initialized
INFO - 2023-12-04 03:45:07 --> Controller Class Initialized
INFO - 2023-12-04 03:45:07 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 03:45:07 --> Model "M_produk" initialized
DEBUG - 2023-12-04 03:45:07 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 03:45:07 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 03:45:07 --> Model "M_transaksi" initialized
INFO - 2023-12-04 03:45:07 --> Model "M_bank" initialized
INFO - 2023-12-04 03:45:07 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 03:45:07 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-04 03:45:07 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-04 03:45:07 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-12-04 03:45:07 --> Final output sent to browser
DEBUG - 2023-12-04 03:45:07 --> Total execution time: 0.0069
ERROR - 2023-12-04 03:46:33 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-04 03:46:33 --> Config Class Initialized
INFO - 2023-12-04 03:46:33 --> Hooks Class Initialized
DEBUG - 2023-12-04 03:46:33 --> UTF-8 Support Enabled
INFO - 2023-12-04 03:46:33 --> Utf8 Class Initialized
INFO - 2023-12-04 03:46:33 --> URI Class Initialized
INFO - 2023-12-04 03:46:33 --> Router Class Initialized
INFO - 2023-12-04 03:46:33 --> Output Class Initialized
INFO - 2023-12-04 03:46:33 --> Security Class Initialized
DEBUG - 2023-12-04 03:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 03:46:33 --> Input Class Initialized
INFO - 2023-12-04 03:46:33 --> Language Class Initialized
INFO - 2023-12-04 03:46:33 --> Loader Class Initialized
INFO - 2023-12-04 03:46:33 --> Helper loaded: url_helper
INFO - 2023-12-04 03:46:33 --> Helper loaded: form_helper
INFO - 2023-12-04 03:46:33 --> Helper loaded: file_helper
INFO - 2023-12-04 03:46:33 --> Database Driver Class Initialized
DEBUG - 2023-12-04 03:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 03:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 03:46:33 --> Form Validation Class Initialized
INFO - 2023-12-04 03:46:33 --> Upload Class Initialized
INFO - 2023-12-04 03:46:33 --> Model "M_auth" initialized
INFO - 2023-12-04 03:46:33 --> Model "M_user" initialized
INFO - 2023-12-04 03:46:33 --> Model "M_produk" initialized
INFO - 2023-12-04 03:46:33 --> Controller Class Initialized
INFO - 2023-12-04 03:46:33 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-04 03:46:33 --> Final output sent to browser
DEBUG - 2023-12-04 03:46:33 --> Total execution time: 0.0028
ERROR - 2023-12-04 03:46:34 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-04 03:46:34 --> Config Class Initialized
INFO - 2023-12-04 03:46:34 --> Hooks Class Initialized
DEBUG - 2023-12-04 03:46:34 --> UTF-8 Support Enabled
INFO - 2023-12-04 03:46:34 --> Utf8 Class Initialized
INFO - 2023-12-04 03:46:34 --> URI Class Initialized
INFO - 2023-12-04 03:46:34 --> Router Class Initialized
INFO - 2023-12-04 03:46:34 --> Output Class Initialized
INFO - 2023-12-04 03:46:34 --> Security Class Initialized
DEBUG - 2023-12-04 03:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 03:46:34 --> Input Class Initialized
INFO - 2023-12-04 03:46:34 --> Language Class Initialized
INFO - 2023-12-04 03:46:34 --> Loader Class Initialized
INFO - 2023-12-04 03:46:34 --> Helper loaded: url_helper
INFO - 2023-12-04 03:46:34 --> Helper loaded: form_helper
INFO - 2023-12-04 03:46:34 --> Helper loaded: file_helper
INFO - 2023-12-04 03:46:34 --> Database Driver Class Initialized
DEBUG - 2023-12-04 03:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 03:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 03:46:34 --> Form Validation Class Initialized
INFO - 2023-12-04 03:46:34 --> Upload Class Initialized
INFO - 2023-12-04 03:46:34 --> Model "M_auth" initialized
INFO - 2023-12-04 03:46:34 --> Model "M_user" initialized
INFO - 2023-12-04 03:46:34 --> Model "M_produk" initialized
INFO - 2023-12-04 03:46:34 --> Controller Class Initialized
INFO - 2023-12-04 03:46:34 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-04 03:46:34 --> Final output sent to browser
DEBUG - 2023-12-04 03:46:34 --> Total execution time: 0.0018
ERROR - 2023-12-04 03:46:35 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-04 03:46:35 --> Config Class Initialized
INFO - 2023-12-04 03:46:35 --> Hooks Class Initialized
DEBUG - 2023-12-04 03:46:35 --> UTF-8 Support Enabled
INFO - 2023-12-04 03:46:35 --> Utf8 Class Initialized
INFO - 2023-12-04 03:46:35 --> URI Class Initialized
INFO - 2023-12-04 03:46:35 --> Router Class Initialized
INFO - 2023-12-04 03:46:35 --> Output Class Initialized
INFO - 2023-12-04 03:46:35 --> Security Class Initialized
DEBUG - 2023-12-04 03:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 03:46:35 --> Input Class Initialized
INFO - 2023-12-04 03:46:35 --> Language Class Initialized
INFO - 2023-12-04 03:46:35 --> Loader Class Initialized
INFO - 2023-12-04 03:46:35 --> Helper loaded: url_helper
INFO - 2023-12-04 03:46:35 --> Helper loaded: form_helper
INFO - 2023-12-04 03:46:35 --> Helper loaded: file_helper
INFO - 2023-12-04 03:46:35 --> Database Driver Class Initialized
DEBUG - 2023-12-04 03:46:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 03:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 03:46:35 --> Form Validation Class Initialized
INFO - 2023-12-04 03:46:35 --> Upload Class Initialized
INFO - 2023-12-04 03:46:35 --> Model "M_auth" initialized
INFO - 2023-12-04 03:46:35 --> Model "M_user" initialized
INFO - 2023-12-04 03:46:35 --> Model "M_produk" initialized
INFO - 2023-12-04 03:46:35 --> Controller Class Initialized
INFO - 2023-12-04 03:46:35 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-04 03:46:35 --> Final output sent to browser
DEBUG - 2023-12-04 03:46:35 --> Total execution time: 0.0023
ERROR - 2023-12-04 03:46:36 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-04 03:46:36 --> Config Class Initialized
INFO - 2023-12-04 03:46:36 --> Hooks Class Initialized
DEBUG - 2023-12-04 03:46:36 --> UTF-8 Support Enabled
INFO - 2023-12-04 03:46:36 --> Utf8 Class Initialized
INFO - 2023-12-04 03:46:36 --> URI Class Initialized
DEBUG - 2023-12-04 03:46:36 --> No URI present. Default controller set.
INFO - 2023-12-04 03:46:36 --> Router Class Initialized
INFO - 2023-12-04 03:46:36 --> Output Class Initialized
INFO - 2023-12-04 03:46:36 --> Security Class Initialized
DEBUG - 2023-12-04 03:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 03:46:36 --> Input Class Initialized
INFO - 2023-12-04 03:46:36 --> Language Class Initialized
INFO - 2023-12-04 03:46:36 --> Loader Class Initialized
INFO - 2023-12-04 03:46:36 --> Helper loaded: url_helper
INFO - 2023-12-04 03:46:36 --> Helper loaded: form_helper
INFO - 2023-12-04 03:46:36 --> Helper loaded: file_helper
INFO - 2023-12-04 03:46:36 --> Database Driver Class Initialized
DEBUG - 2023-12-04 03:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 03:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 03:46:36 --> Form Validation Class Initialized
INFO - 2023-12-04 03:46:36 --> Upload Class Initialized
INFO - 2023-12-04 03:46:36 --> Model "M_auth" initialized
INFO - 2023-12-04 03:46:36 --> Model "M_user" initialized
INFO - 2023-12-04 03:46:36 --> Model "M_produk" initialized
INFO - 2023-12-04 03:46:36 --> Controller Class Initialized
INFO - 2023-12-04 03:46:36 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 03:46:36 --> Model "M_produk" initialized
DEBUG - 2023-12-04 03:46:36 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 03:46:36 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 03:46:36 --> Model "M_transaksi" initialized
INFO - 2023-12-04 03:46:36 --> Model "M_bank" initialized
INFO - 2023-12-04 03:46:36 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 03:46:36 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-04 03:46:36 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-04 03:46:36 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-04 03:46:36 --> Final output sent to browser
DEBUG - 2023-12-04 03:46:36 --> Total execution time: 0.0032
ERROR - 2023-12-04 04:18:34 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-04 04:18:34 --> Config Class Initialized
INFO - 2023-12-04 04:18:34 --> Hooks Class Initialized
DEBUG - 2023-12-04 04:18:34 --> UTF-8 Support Enabled
INFO - 2023-12-04 04:18:34 --> Utf8 Class Initialized
INFO - 2023-12-04 04:18:34 --> URI Class Initialized
DEBUG - 2023-12-04 04:18:34 --> No URI present. Default controller set.
INFO - 2023-12-04 04:18:34 --> Router Class Initialized
INFO - 2023-12-04 04:18:34 --> Output Class Initialized
INFO - 2023-12-04 04:18:34 --> Security Class Initialized
DEBUG - 2023-12-04 04:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 04:18:34 --> Input Class Initialized
INFO - 2023-12-04 04:18:34 --> Language Class Initialized
INFO - 2023-12-04 04:18:34 --> Loader Class Initialized
INFO - 2023-12-04 04:18:34 --> Helper loaded: url_helper
INFO - 2023-12-04 04:18:34 --> Helper loaded: form_helper
INFO - 2023-12-04 04:18:34 --> Helper loaded: file_helper
INFO - 2023-12-04 04:18:34 --> Database Driver Class Initialized
DEBUG - 2023-12-04 04:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 04:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 04:18:34 --> Form Validation Class Initialized
INFO - 2023-12-04 04:18:34 --> Upload Class Initialized
INFO - 2023-12-04 04:18:34 --> Model "M_auth" initialized
INFO - 2023-12-04 04:18:34 --> Model "M_user" initialized
INFO - 2023-12-04 04:18:34 --> Model "M_produk" initialized
INFO - 2023-12-04 04:18:34 --> Controller Class Initialized
INFO - 2023-12-04 04:18:34 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 04:18:34 --> Model "M_produk" initialized
DEBUG - 2023-12-04 04:18:34 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 04:18:34 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 04:18:34 --> Model "M_transaksi" initialized
INFO - 2023-12-04 04:18:34 --> Model "M_bank" initialized
INFO - 2023-12-04 04:18:34 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 04:18:34 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-04 04:18:34 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-04 04:18:34 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-04 04:18:34 --> Final output sent to browser
DEBUG - 2023-12-04 04:18:34 --> Total execution time: 0.0329
ERROR - 2023-12-04 04:33:46 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-04 04:33:46 --> Config Class Initialized
INFO - 2023-12-04 04:33:46 --> Hooks Class Initialized
DEBUG - 2023-12-04 04:33:46 --> UTF-8 Support Enabled
INFO - 2023-12-04 04:33:46 --> Utf8 Class Initialized
INFO - 2023-12-04 04:33:46 --> URI Class Initialized
DEBUG - 2023-12-04 04:33:46 --> No URI present. Default controller set.
INFO - 2023-12-04 04:33:46 --> Router Class Initialized
INFO - 2023-12-04 04:33:46 --> Output Class Initialized
INFO - 2023-12-04 04:33:46 --> Security Class Initialized
DEBUG - 2023-12-04 04:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 04:33:46 --> Input Class Initialized
INFO - 2023-12-04 04:33:46 --> Language Class Initialized
INFO - 2023-12-04 04:33:46 --> Loader Class Initialized
INFO - 2023-12-04 04:33:46 --> Helper loaded: url_helper
INFO - 2023-12-04 04:33:46 --> Helper loaded: form_helper
INFO - 2023-12-04 04:33:46 --> Helper loaded: file_helper
INFO - 2023-12-04 04:33:46 --> Database Driver Class Initialized
DEBUG - 2023-12-04 04:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 04:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 04:33:46 --> Form Validation Class Initialized
INFO - 2023-12-04 04:33:46 --> Upload Class Initialized
INFO - 2023-12-04 04:33:46 --> Model "M_auth" initialized
INFO - 2023-12-04 04:33:46 --> Model "M_user" initialized
INFO - 2023-12-04 04:33:46 --> Model "M_produk" initialized
INFO - 2023-12-04 04:33:46 --> Controller Class Initialized
INFO - 2023-12-04 04:33:46 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 04:33:46 --> Model "M_produk" initialized
DEBUG - 2023-12-04 04:33:46 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 04:33:46 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 04:33:46 --> Model "M_transaksi" initialized
INFO - 2023-12-04 04:33:46 --> Model "M_bank" initialized
INFO - 2023-12-04 04:33:46 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 04:33:46 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-04 04:33:46 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-04 04:33:46 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-04 04:33:46 --> Final output sent to browser
DEBUG - 2023-12-04 04:33:46 --> Total execution time: 0.0312
ERROR - 2023-12-04 04:33:48 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-04 04:33:48 --> Config Class Initialized
INFO - 2023-12-04 04:33:48 --> Hooks Class Initialized
DEBUG - 2023-12-04 04:33:48 --> UTF-8 Support Enabled
INFO - 2023-12-04 04:33:48 --> Utf8 Class Initialized
INFO - 2023-12-04 04:33:48 --> URI Class Initialized
INFO - 2023-12-04 04:33:48 --> Router Class Initialized
INFO - 2023-12-04 04:33:48 --> Output Class Initialized
INFO - 2023-12-04 04:33:48 --> Security Class Initialized
DEBUG - 2023-12-04 04:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 04:33:48 --> Input Class Initialized
INFO - 2023-12-04 04:33:48 --> Language Class Initialized
INFO - 2023-12-04 04:33:48 --> Loader Class Initialized
INFO - 2023-12-04 04:33:48 --> Helper loaded: url_helper
INFO - 2023-12-04 04:33:48 --> Helper loaded: form_helper
INFO - 2023-12-04 04:33:48 --> Helper loaded: file_helper
INFO - 2023-12-04 04:33:48 --> Database Driver Class Initialized
DEBUG - 2023-12-04 04:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 04:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 04:33:48 --> Form Validation Class Initialized
INFO - 2023-12-04 04:33:48 --> Upload Class Initialized
INFO - 2023-12-04 04:33:48 --> Model "M_auth" initialized
INFO - 2023-12-04 04:33:48 --> Model "M_user" initialized
INFO - 2023-12-04 04:33:48 --> Model "M_produk" initialized
INFO - 2023-12-04 04:33:48 --> Controller Class Initialized
INFO - 2023-12-04 04:33:48 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-04 04:33:48 --> Final output sent to browser
DEBUG - 2023-12-04 04:33:48 --> Total execution time: 0.0029
ERROR - 2023-12-04 04:33:50 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-04 04:33:50 --> Config Class Initialized
INFO - 2023-12-04 04:33:50 --> Hooks Class Initialized
DEBUG - 2023-12-04 04:33:50 --> UTF-8 Support Enabled
INFO - 2023-12-04 04:33:50 --> Utf8 Class Initialized
INFO - 2023-12-04 04:33:50 --> URI Class Initialized
INFO - 2023-12-04 04:33:50 --> Router Class Initialized
INFO - 2023-12-04 04:33:50 --> Output Class Initialized
INFO - 2023-12-04 04:33:50 --> Security Class Initialized
DEBUG - 2023-12-04 04:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 04:33:50 --> Input Class Initialized
INFO - 2023-12-04 04:33:50 --> Language Class Initialized
INFO - 2023-12-04 04:33:50 --> Loader Class Initialized
INFO - 2023-12-04 04:33:50 --> Helper loaded: url_helper
INFO - 2023-12-04 04:33:50 --> Helper loaded: form_helper
INFO - 2023-12-04 04:33:50 --> Helper loaded: file_helper
INFO - 2023-12-04 04:33:50 --> Database Driver Class Initialized
DEBUG - 2023-12-04 04:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 04:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 04:33:50 --> Form Validation Class Initialized
INFO - 2023-12-04 04:33:50 --> Upload Class Initialized
INFO - 2023-12-04 04:33:50 --> Model "M_auth" initialized
INFO - 2023-12-04 04:33:50 --> Model "M_user" initialized
INFO - 2023-12-04 04:33:50 --> Model "M_produk" initialized
INFO - 2023-12-04 04:33:50 --> Controller Class Initialized
INFO - 2023-12-04 04:33:50 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-04 04:33:50 --> Final output sent to browser
DEBUG - 2023-12-04 04:33:50 --> Total execution time: 0.0028
ERROR - 2023-12-04 04:34:02 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-04 04:34:02 --> Config Class Initialized
INFO - 2023-12-04 04:34:02 --> Hooks Class Initialized
DEBUG - 2023-12-04 04:34:02 --> UTF-8 Support Enabled
INFO - 2023-12-04 04:34:02 --> Utf8 Class Initialized
INFO - 2023-12-04 04:34:02 --> URI Class Initialized
DEBUG - 2023-12-04 04:34:02 --> No URI present. Default controller set.
INFO - 2023-12-04 04:34:02 --> Router Class Initialized
INFO - 2023-12-04 04:34:02 --> Output Class Initialized
INFO - 2023-12-04 04:34:02 --> Security Class Initialized
DEBUG - 2023-12-04 04:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 04:34:02 --> Input Class Initialized
INFO - 2023-12-04 04:34:02 --> Language Class Initialized
INFO - 2023-12-04 04:34:02 --> Loader Class Initialized
INFO - 2023-12-04 04:34:02 --> Helper loaded: url_helper
INFO - 2023-12-04 04:34:02 --> Helper loaded: form_helper
INFO - 2023-12-04 04:34:02 --> Helper loaded: file_helper
INFO - 2023-12-04 04:34:02 --> Database Driver Class Initialized
DEBUG - 2023-12-04 04:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 04:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 04:34:02 --> Form Validation Class Initialized
INFO - 2023-12-04 04:34:02 --> Upload Class Initialized
INFO - 2023-12-04 04:34:02 --> Model "M_auth" initialized
INFO - 2023-12-04 04:34:02 --> Model "M_user" initialized
INFO - 2023-12-04 04:34:02 --> Model "M_produk" initialized
INFO - 2023-12-04 04:34:02 --> Controller Class Initialized
INFO - 2023-12-04 04:34:02 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 04:34:02 --> Model "M_produk" initialized
DEBUG - 2023-12-04 04:34:02 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 04:34:02 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 04:34:02 --> Model "M_transaksi" initialized
INFO - 2023-12-04 04:34:02 --> Model "M_bank" initialized
INFO - 2023-12-04 04:34:02 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 04:34:02 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-04 04:34:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-04 04:34:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-04 04:34:02 --> Final output sent to browser
DEBUG - 2023-12-04 04:34:02 --> Total execution time: 0.0053
ERROR - 2023-12-04 04:34:02 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-04 04:34:02 --> Config Class Initialized
INFO - 2023-12-04 04:34:02 --> Hooks Class Initialized
DEBUG - 2023-12-04 04:34:02 --> UTF-8 Support Enabled
INFO - 2023-12-04 04:34:02 --> Utf8 Class Initialized
INFO - 2023-12-04 04:34:02 --> URI Class Initialized
INFO - 2023-12-04 04:34:02 --> Router Class Initialized
INFO - 2023-12-04 04:34:02 --> Output Class Initialized
INFO - 2023-12-04 04:34:02 --> Security Class Initialized
DEBUG - 2023-12-04 04:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 04:34:02 --> Input Class Initialized
INFO - 2023-12-04 04:34:02 --> Language Class Initialized
INFO - 2023-12-04 04:34:02 --> Loader Class Initialized
INFO - 2023-12-04 04:34:02 --> Helper loaded: url_helper
INFO - 2023-12-04 04:34:02 --> Helper loaded: form_helper
INFO - 2023-12-04 04:34:02 --> Helper loaded: file_helper
INFO - 2023-12-04 04:34:02 --> Database Driver Class Initialized
DEBUG - 2023-12-04 04:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 04:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 04:34:02 --> Form Validation Class Initialized
INFO - 2023-12-04 04:34:02 --> Upload Class Initialized
INFO - 2023-12-04 04:34:02 --> Model "M_auth" initialized
INFO - 2023-12-04 04:34:02 --> Model "M_user" initialized
INFO - 2023-12-04 04:34:02 --> Model "M_produk" initialized
INFO - 2023-12-04 04:34:02 --> Controller Class Initialized
INFO - 2023-12-04 04:34:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-04 04:34:02 --> Final output sent to browser
DEBUG - 2023-12-04 04:34:02 --> Total execution time: 0.0028
ERROR - 2023-12-04 04:42:50 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-04 04:42:50 --> Config Class Initialized
INFO - 2023-12-04 04:42:50 --> Hooks Class Initialized
DEBUG - 2023-12-04 04:42:50 --> UTF-8 Support Enabled
INFO - 2023-12-04 04:42:50 --> Utf8 Class Initialized
INFO - 2023-12-04 04:42:50 --> URI Class Initialized
DEBUG - 2023-12-04 04:42:50 --> No URI present. Default controller set.
INFO - 2023-12-04 04:42:50 --> Router Class Initialized
INFO - 2023-12-04 04:42:50 --> Output Class Initialized
INFO - 2023-12-04 04:42:50 --> Security Class Initialized
DEBUG - 2023-12-04 04:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 04:42:50 --> Input Class Initialized
INFO - 2023-12-04 04:42:50 --> Language Class Initialized
INFO - 2023-12-04 04:42:50 --> Loader Class Initialized
INFO - 2023-12-04 04:42:50 --> Helper loaded: url_helper
INFO - 2023-12-04 04:42:50 --> Helper loaded: form_helper
INFO - 2023-12-04 04:42:50 --> Helper loaded: file_helper
INFO - 2023-12-04 04:42:50 --> Database Driver Class Initialized
DEBUG - 2023-12-04 04:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 04:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 04:42:50 --> Form Validation Class Initialized
INFO - 2023-12-04 04:42:50 --> Upload Class Initialized
INFO - 2023-12-04 04:42:50 --> Model "M_auth" initialized
INFO - 2023-12-04 04:42:50 --> Model "M_user" initialized
INFO - 2023-12-04 04:42:50 --> Model "M_produk" initialized
INFO - 2023-12-04 04:42:50 --> Controller Class Initialized
INFO - 2023-12-04 04:42:50 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 04:42:50 --> Model "M_produk" initialized
DEBUG - 2023-12-04 04:42:50 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 04:42:50 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 04:42:50 --> Model "M_transaksi" initialized
INFO - 2023-12-04 04:42:50 --> Model "M_bank" initialized
INFO - 2023-12-04 04:42:50 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 04:42:50 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-04 04:42:50 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-04 04:42:50 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-04 04:42:50 --> Final output sent to browser
DEBUG - 2023-12-04 04:42:50 --> Total execution time: 0.0338
ERROR - 2023-12-04 04:47:25 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-04 04:47:25 --> Config Class Initialized
INFO - 2023-12-04 04:47:25 --> Hooks Class Initialized
DEBUG - 2023-12-04 04:47:25 --> UTF-8 Support Enabled
INFO - 2023-12-04 04:47:25 --> Utf8 Class Initialized
INFO - 2023-12-04 04:47:25 --> URI Class Initialized
DEBUG - 2023-12-04 04:47:25 --> No URI present. Default controller set.
INFO - 2023-12-04 04:47:25 --> Router Class Initialized
INFO - 2023-12-04 04:47:25 --> Output Class Initialized
INFO - 2023-12-04 04:47:25 --> Security Class Initialized
DEBUG - 2023-12-04 04:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 04:47:25 --> Input Class Initialized
INFO - 2023-12-04 04:47:25 --> Language Class Initialized
INFO - 2023-12-04 04:47:25 --> Loader Class Initialized
INFO - 2023-12-04 04:47:25 --> Helper loaded: url_helper
INFO - 2023-12-04 04:47:25 --> Helper loaded: form_helper
INFO - 2023-12-04 04:47:25 --> Helper loaded: file_helper
INFO - 2023-12-04 04:47:25 --> Database Driver Class Initialized
DEBUG - 2023-12-04 04:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 04:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 04:47:25 --> Form Validation Class Initialized
INFO - 2023-12-04 04:47:25 --> Upload Class Initialized
INFO - 2023-12-04 04:47:25 --> Model "M_auth" initialized
INFO - 2023-12-04 04:47:25 --> Model "M_user" initialized
INFO - 2023-12-04 04:47:25 --> Model "M_produk" initialized
INFO - 2023-12-04 04:47:25 --> Controller Class Initialized
INFO - 2023-12-04 04:47:25 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 04:47:25 --> Model "M_produk" initialized
DEBUG - 2023-12-04 04:47:25 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 04:47:25 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 04:47:25 --> Model "M_transaksi" initialized
INFO - 2023-12-04 04:47:25 --> Model "M_bank" initialized
INFO - 2023-12-04 04:47:25 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 04:47:25 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-04 04:47:25 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-04 04:47:25 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-04 04:47:25 --> Final output sent to browser
DEBUG - 2023-12-04 04:47:25 --> Total execution time: 0.0042
ERROR - 2023-12-04 04:51:00 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-04 04:51:00 --> Config Class Initialized
INFO - 2023-12-04 04:51:00 --> Hooks Class Initialized
DEBUG - 2023-12-04 04:51:00 --> UTF-8 Support Enabled
INFO - 2023-12-04 04:51:00 --> Utf8 Class Initialized
INFO - 2023-12-04 04:51:00 --> URI Class Initialized
DEBUG - 2023-12-04 04:51:00 --> No URI present. Default controller set.
INFO - 2023-12-04 04:51:00 --> Router Class Initialized
INFO - 2023-12-04 04:51:00 --> Output Class Initialized
INFO - 2023-12-04 04:51:00 --> Security Class Initialized
DEBUG - 2023-12-04 04:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 04:51:00 --> Input Class Initialized
INFO - 2023-12-04 04:51:00 --> Language Class Initialized
INFO - 2023-12-04 04:51:00 --> Loader Class Initialized
INFO - 2023-12-04 04:51:00 --> Helper loaded: url_helper
INFO - 2023-12-04 04:51:00 --> Helper loaded: form_helper
INFO - 2023-12-04 04:51:00 --> Helper loaded: file_helper
INFO - 2023-12-04 04:51:00 --> Database Driver Class Initialized
DEBUG - 2023-12-04 04:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 04:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 04:51:00 --> Form Validation Class Initialized
INFO - 2023-12-04 04:51:00 --> Upload Class Initialized
INFO - 2023-12-04 04:51:00 --> Model "M_auth" initialized
INFO - 2023-12-04 04:51:00 --> Model "M_user" initialized
INFO - 2023-12-04 04:51:00 --> Model "M_produk" initialized
INFO - 2023-12-04 04:51:00 --> Controller Class Initialized
INFO - 2023-12-04 04:51:00 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 04:51:00 --> Model "M_produk" initialized
DEBUG - 2023-12-04 04:51:00 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 04:51:00 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 04:51:00 --> Model "M_transaksi" initialized
INFO - 2023-12-04 04:51:00 --> Model "M_bank" initialized
INFO - 2023-12-04 04:51:00 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 04:51:00 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-04 04:51:00 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-04 04:51:00 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-04 04:51:00 --> Final output sent to browser
DEBUG - 2023-12-04 04:51:00 --> Total execution time: 0.0042
ERROR - 2023-12-04 04:56:15 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-04 04:56:15 --> Config Class Initialized
INFO - 2023-12-04 04:56:15 --> Hooks Class Initialized
DEBUG - 2023-12-04 04:56:15 --> UTF-8 Support Enabled
INFO - 2023-12-04 04:56:15 --> Utf8 Class Initialized
INFO - 2023-12-04 04:56:15 --> URI Class Initialized
DEBUG - 2023-12-04 04:56:15 --> No URI present. Default controller set.
INFO - 2023-12-04 04:56:15 --> Router Class Initialized
INFO - 2023-12-04 04:56:15 --> Output Class Initialized
INFO - 2023-12-04 04:56:15 --> Security Class Initialized
DEBUG - 2023-12-04 04:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 04:56:15 --> Input Class Initialized
INFO - 2023-12-04 04:56:15 --> Language Class Initialized
INFO - 2023-12-04 04:56:15 --> Loader Class Initialized
INFO - 2023-12-04 04:56:15 --> Helper loaded: url_helper
INFO - 2023-12-04 04:56:15 --> Helper loaded: form_helper
INFO - 2023-12-04 04:56:15 --> Helper loaded: file_helper
INFO - 2023-12-04 04:56:15 --> Database Driver Class Initialized
DEBUG - 2023-12-04 04:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 04:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 04:56:15 --> Form Validation Class Initialized
INFO - 2023-12-04 04:56:15 --> Upload Class Initialized
INFO - 2023-12-04 04:56:15 --> Model "M_auth" initialized
INFO - 2023-12-04 04:56:15 --> Model "M_user" initialized
INFO - 2023-12-04 04:56:15 --> Model "M_produk" initialized
INFO - 2023-12-04 04:56:15 --> Controller Class Initialized
INFO - 2023-12-04 04:56:15 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 04:56:15 --> Model "M_produk" initialized
DEBUG - 2023-12-04 04:56:15 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 04:56:15 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 04:56:15 --> Model "M_transaksi" initialized
INFO - 2023-12-04 04:56:15 --> Model "M_bank" initialized
INFO - 2023-12-04 04:56:15 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 04:56:15 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-04 04:56:15 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-04 04:56:15 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-04 04:56:15 --> Final output sent to browser
DEBUG - 2023-12-04 04:56:15 --> Total execution time: 0.0041
ERROR - 2023-12-04 05:13:00 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-04 05:13:00 --> Config Class Initialized
INFO - 2023-12-04 05:13:00 --> Hooks Class Initialized
DEBUG - 2023-12-04 05:13:00 --> UTF-8 Support Enabled
INFO - 2023-12-04 05:13:00 --> Utf8 Class Initialized
INFO - 2023-12-04 05:13:00 --> URI Class Initialized
DEBUG - 2023-12-04 05:13:00 --> No URI present. Default controller set.
INFO - 2023-12-04 05:13:00 --> Router Class Initialized
INFO - 2023-12-04 05:13:00 --> Output Class Initialized
INFO - 2023-12-04 05:13:00 --> Security Class Initialized
DEBUG - 2023-12-04 05:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 05:13:00 --> Input Class Initialized
INFO - 2023-12-04 05:13:00 --> Language Class Initialized
INFO - 2023-12-04 05:13:00 --> Loader Class Initialized
INFO - 2023-12-04 05:13:00 --> Helper loaded: url_helper
INFO - 2023-12-04 05:13:00 --> Helper loaded: form_helper
INFO - 2023-12-04 05:13:00 --> Helper loaded: file_helper
INFO - 2023-12-04 05:13:00 --> Database Driver Class Initialized
DEBUG - 2023-12-04 05:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 05:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 05:13:00 --> Form Validation Class Initialized
INFO - 2023-12-04 05:13:00 --> Upload Class Initialized
INFO - 2023-12-04 05:13:00 --> Model "M_auth" initialized
INFO - 2023-12-04 05:13:00 --> Model "M_user" initialized
INFO - 2023-12-04 05:13:00 --> Model "M_produk" initialized
INFO - 2023-12-04 05:13:00 --> Controller Class Initialized
INFO - 2023-12-04 05:13:00 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 05:13:00 --> Model "M_produk" initialized
DEBUG - 2023-12-04 05:13:00 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 05:13:00 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 05:13:00 --> Model "M_transaksi" initialized
INFO - 2023-12-04 05:13:00 --> Model "M_bank" initialized
INFO - 2023-12-04 05:13:00 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 05:13:00 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-04 05:13:00 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-04 05:13:00 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-04 05:13:00 --> Final output sent to browser
DEBUG - 2023-12-04 05:13:00 --> Total execution time: 0.0324
ERROR - 2023-12-04 15:43:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-04 15:43:00 --> Config Class Initialized
INFO - 2023-12-04 15:43:00 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:43:00 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:43:00 --> Utf8 Class Initialized
INFO - 2023-12-04 15:43:00 --> URI Class Initialized
DEBUG - 2023-12-04 15:43:00 --> No URI present. Default controller set.
INFO - 2023-12-04 15:43:00 --> Router Class Initialized
INFO - 2023-12-04 15:43:00 --> Output Class Initialized
INFO - 2023-12-04 15:43:00 --> Security Class Initialized
DEBUG - 2023-12-04 15:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:43:00 --> Input Class Initialized
INFO - 2023-12-04 15:43:00 --> Language Class Initialized
INFO - 2023-12-04 15:43:00 --> Loader Class Initialized
INFO - 2023-12-04 15:43:00 --> Helper loaded: url_helper
INFO - 2023-12-04 15:43:00 --> Helper loaded: form_helper
INFO - 2023-12-04 15:43:00 --> Helper loaded: file_helper
INFO - 2023-12-04 15:43:00 --> Database Driver Class Initialized
ERROR - 2023-12-04 15:43:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'u967005227_rootsemakar'@'localhost' (using password: YES) C:\xampp\htdocs\semakar_adventure_new\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-04 15:43:00 --> Unable to connect to the database
INFO - 2023-12-04 15:43:00 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-12-04 15:43:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-04 15:43:02 --> Config Class Initialized
INFO - 2023-12-04 15:43:02 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:43:02 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:43:02 --> Utf8 Class Initialized
INFO - 2023-12-04 15:43:02 --> URI Class Initialized
DEBUG - 2023-12-04 15:43:02 --> No URI present. Default controller set.
INFO - 2023-12-04 15:43:02 --> Router Class Initialized
INFO - 2023-12-04 15:43:02 --> Output Class Initialized
INFO - 2023-12-04 15:43:02 --> Security Class Initialized
DEBUG - 2023-12-04 15:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:43:02 --> Input Class Initialized
INFO - 2023-12-04 15:43:02 --> Language Class Initialized
INFO - 2023-12-04 15:43:02 --> Loader Class Initialized
INFO - 2023-12-04 15:43:02 --> Helper loaded: url_helper
INFO - 2023-12-04 15:43:02 --> Helper loaded: form_helper
INFO - 2023-12-04 15:43:02 --> Helper loaded: file_helper
INFO - 2023-12-04 15:43:02 --> Database Driver Class Initialized
ERROR - 2023-12-04 15:43:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'u967005227_rootsemakar'@'localhost' (using password: YES) C:\xampp\htdocs\semakar_adventure_new\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-04 15:43:02 --> Unable to connect to the database
INFO - 2023-12-04 15:43:02 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-12-04 15:43:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-04 15:43:02 --> Config Class Initialized
INFO - 2023-12-04 15:43:02 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:43:02 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:43:02 --> Utf8 Class Initialized
INFO - 2023-12-04 15:43:02 --> URI Class Initialized
DEBUG - 2023-12-04 15:43:02 --> No URI present. Default controller set.
INFO - 2023-12-04 15:43:02 --> Router Class Initialized
INFO - 2023-12-04 15:43:02 --> Output Class Initialized
INFO - 2023-12-04 15:43:02 --> Security Class Initialized
DEBUG - 2023-12-04 15:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:43:02 --> Input Class Initialized
INFO - 2023-12-04 15:43:02 --> Language Class Initialized
INFO - 2023-12-04 15:43:02 --> Loader Class Initialized
INFO - 2023-12-04 15:43:02 --> Helper loaded: url_helper
INFO - 2023-12-04 15:43:02 --> Helper loaded: form_helper
INFO - 2023-12-04 15:43:02 --> Helper loaded: file_helper
INFO - 2023-12-04 15:43:02 --> Database Driver Class Initialized
ERROR - 2023-12-04 15:43:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'u967005227_rootsemakar'@'localhost' (using password: YES) C:\xampp\htdocs\semakar_adventure_new\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-04 15:43:02 --> Unable to connect to the database
INFO - 2023-12-04 15:43:02 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-12-04 15:43:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-04 15:43:02 --> Config Class Initialized
INFO - 2023-12-04 15:43:02 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:43:02 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:43:02 --> Utf8 Class Initialized
INFO - 2023-12-04 15:43:02 --> URI Class Initialized
DEBUG - 2023-12-04 15:43:02 --> No URI present. Default controller set.
INFO - 2023-12-04 15:43:02 --> Router Class Initialized
INFO - 2023-12-04 15:43:02 --> Output Class Initialized
INFO - 2023-12-04 15:43:02 --> Security Class Initialized
DEBUG - 2023-12-04 15:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:43:02 --> Input Class Initialized
INFO - 2023-12-04 15:43:02 --> Language Class Initialized
INFO - 2023-12-04 15:43:02 --> Loader Class Initialized
INFO - 2023-12-04 15:43:02 --> Helper loaded: url_helper
INFO - 2023-12-04 15:43:02 --> Helper loaded: form_helper
INFO - 2023-12-04 15:43:02 --> Helper loaded: file_helper
INFO - 2023-12-04 15:43:02 --> Database Driver Class Initialized
ERROR - 2023-12-04 15:43:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'u967005227_rootsemakar'@'localhost' (using password: YES) C:\xampp\htdocs\semakar_adventure_new\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-12-04 15:43:02 --> Unable to connect to the database
INFO - 2023-12-04 15:43:02 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-12-04 15:44:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-04 15:44:34 --> Config Class Initialized
INFO - 2023-12-04 15:44:34 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:44:34 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:44:34 --> Utf8 Class Initialized
INFO - 2023-12-04 15:44:34 --> URI Class Initialized
DEBUG - 2023-12-04 15:44:34 --> No URI present. Default controller set.
INFO - 2023-12-04 15:44:34 --> Router Class Initialized
INFO - 2023-12-04 15:44:34 --> Output Class Initialized
INFO - 2023-12-04 15:44:34 --> Security Class Initialized
DEBUG - 2023-12-04 15:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:44:34 --> Input Class Initialized
INFO - 2023-12-04 15:44:34 --> Language Class Initialized
INFO - 2023-12-04 15:44:34 --> Loader Class Initialized
INFO - 2023-12-04 15:44:34 --> Helper loaded: url_helper
INFO - 2023-12-04 15:44:34 --> Helper loaded: form_helper
INFO - 2023-12-04 15:44:34 --> Helper loaded: file_helper
INFO - 2023-12-04 15:44:34 --> Database Driver Class Initialized
DEBUG - 2023-12-04 15:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 15:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:44:34 --> Form Validation Class Initialized
INFO - 2023-12-04 15:44:34 --> Upload Class Initialized
INFO - 2023-12-04 15:44:34 --> Model "M_auth" initialized
INFO - 2023-12-04 15:44:34 --> Model "M_user" initialized
INFO - 2023-12-04 15:44:34 --> Model "M_produk" initialized
INFO - 2023-12-04 15:44:34 --> Controller Class Initialized
INFO - 2023-12-04 15:44:34 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 15:44:34 --> Model "M_produk" initialized
DEBUG - 2023-12-04 15:44:34 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 15:44:34 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 15:44:34 --> Model "M_transaksi" initialized
INFO - 2023-12-04 15:44:34 --> Model "M_bank" initialized
INFO - 2023-12-04 15:44:34 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 15:44:34 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-04 15:44:34 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-04 15:44:34 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/index.php
INFO - 2023-12-04 15:44:34 --> Final output sent to browser
DEBUG - 2023-12-04 15:44:34 --> Total execution time: 0.5384
ERROR - 2023-12-04 15:44:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-04 15:44:45 --> Config Class Initialized
INFO - 2023-12-04 15:44:45 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:44:45 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:44:45 --> Utf8 Class Initialized
INFO - 2023-12-04 15:44:45 --> URI Class Initialized
DEBUG - 2023-12-04 15:44:45 --> No URI present. Default controller set.
INFO - 2023-12-04 15:44:45 --> Router Class Initialized
INFO - 2023-12-04 15:44:45 --> Output Class Initialized
INFO - 2023-12-04 15:44:45 --> Security Class Initialized
DEBUG - 2023-12-04 15:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:44:45 --> Input Class Initialized
INFO - 2023-12-04 15:44:45 --> Language Class Initialized
INFO - 2023-12-04 15:44:45 --> Loader Class Initialized
INFO - 2023-12-04 15:44:45 --> Helper loaded: url_helper
INFO - 2023-12-04 15:44:45 --> Helper loaded: form_helper
INFO - 2023-12-04 15:44:45 --> Helper loaded: file_helper
INFO - 2023-12-04 15:44:45 --> Database Driver Class Initialized
DEBUG - 2023-12-04 15:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 15:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:44:45 --> Form Validation Class Initialized
INFO - 2023-12-04 15:44:45 --> Upload Class Initialized
INFO - 2023-12-04 15:44:45 --> Model "M_auth" initialized
INFO - 2023-12-04 15:44:45 --> Model "M_user" initialized
INFO - 2023-12-04 15:44:45 --> Model "M_produk" initialized
INFO - 2023-12-04 15:44:45 --> Controller Class Initialized
INFO - 2023-12-04 15:44:45 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 15:44:45 --> Model "M_produk" initialized
DEBUG - 2023-12-04 15:44:45 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 15:44:45 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 15:44:45 --> Model "M_transaksi" initialized
INFO - 2023-12-04 15:44:45 --> Model "M_bank" initialized
INFO - 2023-12-04 15:44:45 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 15:44:45 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-04 15:44:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-12-04 15:44:45 --> Email Class Initialized
INFO - 2023-12-04 15:44:47 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-12-04 15:44:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-04 15:44:50 --> Config Class Initialized
INFO - 2023-12-04 15:44:50 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:44:50 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:44:50 --> Utf8 Class Initialized
INFO - 2023-12-04 15:44:50 --> URI Class Initialized
DEBUG - 2023-12-04 15:44:50 --> No URI present. Default controller set.
INFO - 2023-12-04 15:44:50 --> Router Class Initialized
INFO - 2023-12-04 15:44:50 --> Output Class Initialized
INFO - 2023-12-04 15:44:50 --> Security Class Initialized
DEBUG - 2023-12-04 15:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:44:50 --> Input Class Initialized
INFO - 2023-12-04 15:44:50 --> Language Class Initialized
INFO - 2023-12-04 15:44:50 --> Loader Class Initialized
INFO - 2023-12-04 15:44:50 --> Helper loaded: url_helper
INFO - 2023-12-04 15:44:50 --> Helper loaded: form_helper
INFO - 2023-12-04 15:44:50 --> Helper loaded: file_helper
INFO - 2023-12-04 15:44:50 --> Database Driver Class Initialized
DEBUG - 2023-12-04 15:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 15:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:44:50 --> Form Validation Class Initialized
INFO - 2023-12-04 15:44:50 --> Upload Class Initialized
INFO - 2023-12-04 15:44:50 --> Model "M_auth" initialized
INFO - 2023-12-04 15:44:50 --> Model "M_user" initialized
INFO - 2023-12-04 15:44:50 --> Model "M_produk" initialized
INFO - 2023-12-04 15:44:50 --> Controller Class Initialized
INFO - 2023-12-04 15:44:50 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 15:44:50 --> Model "M_produk" initialized
DEBUG - 2023-12-04 15:44:50 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 15:44:50 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 15:44:50 --> Model "M_transaksi" initialized
INFO - 2023-12-04 15:44:50 --> Model "M_bank" initialized
INFO - 2023-12-04 15:44:50 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 15:44:50 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-04 15:44:50 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-04 15:44:50 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/index.php
INFO - 2023-12-04 15:44:50 --> Final output sent to browser
DEBUG - 2023-12-04 15:44:50 --> Total execution time: 0.0895
ERROR - 2023-12-04 15:45:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-04 15:45:05 --> Config Class Initialized
INFO - 2023-12-04 15:45:05 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:45:05 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:45:05 --> Utf8 Class Initialized
INFO - 2023-12-04 15:45:05 --> URI Class Initialized
INFO - 2023-12-04 15:45:05 --> Router Class Initialized
INFO - 2023-12-04 15:45:05 --> Output Class Initialized
INFO - 2023-12-04 15:45:05 --> Security Class Initialized
DEBUG - 2023-12-04 15:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:45:05 --> Input Class Initialized
INFO - 2023-12-04 15:45:05 --> Language Class Initialized
INFO - 2023-12-04 15:45:05 --> Loader Class Initialized
INFO - 2023-12-04 15:45:05 --> Helper loaded: url_helper
INFO - 2023-12-04 15:45:05 --> Helper loaded: form_helper
INFO - 2023-12-04 15:45:05 --> Helper loaded: file_helper
INFO - 2023-12-04 15:45:05 --> Database Driver Class Initialized
DEBUG - 2023-12-04 15:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 15:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:45:05 --> Form Validation Class Initialized
INFO - 2023-12-04 15:45:05 --> Upload Class Initialized
INFO - 2023-12-04 15:45:05 --> Model "M_auth" initialized
INFO - 2023-12-04 15:45:05 --> Model "M_user" initialized
INFO - 2023-12-04 15:45:05 --> Model "M_produk" initialized
INFO - 2023-12-04 15:45:05 --> Controller Class Initialized
INFO - 2023-12-04 15:45:05 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 15:45:05 --> Model "M_produk" initialized
DEBUG - 2023-12-04 15:45:05 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 15:45:05 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 15:45:05 --> Model "M_transaksi" initialized
INFO - 2023-12-04 15:45:05 --> Model "M_bank" initialized
INFO - 2023-12-04 15:45:05 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 15:45:05 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-04 15:45:05 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-04 15:45:05 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_produk_detail.php
INFO - 2023-12-04 15:45:05 --> Final output sent to browser
DEBUG - 2023-12-04 15:45:05 --> Total execution time: 0.0694
ERROR - 2023-12-04 15:45:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-04 15:45:05 --> Config Class Initialized
INFO - 2023-12-04 15:45:05 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:45:05 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:45:05 --> Utf8 Class Initialized
INFO - 2023-12-04 15:45:05 --> URI Class Initialized
INFO - 2023-12-04 15:45:05 --> Router Class Initialized
INFO - 2023-12-04 15:45:05 --> Output Class Initialized
INFO - 2023-12-04 15:45:05 --> Security Class Initialized
DEBUG - 2023-12-04 15:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:45:05 --> Input Class Initialized
INFO - 2023-12-04 15:45:05 --> Language Class Initialized
INFO - 2023-12-04 15:45:05 --> Loader Class Initialized
INFO - 2023-12-04 15:45:05 --> Helper loaded: url_helper
INFO - 2023-12-04 15:45:05 --> Helper loaded: form_helper
INFO - 2023-12-04 15:45:05 --> Helper loaded: file_helper
INFO - 2023-12-04 15:45:05 --> Database Driver Class Initialized
DEBUG - 2023-12-04 15:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 15:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:45:05 --> Form Validation Class Initialized
INFO - 2023-12-04 15:45:05 --> Upload Class Initialized
INFO - 2023-12-04 15:45:05 --> Model "M_auth" initialized
INFO - 2023-12-04 15:45:05 --> Model "M_user" initialized
INFO - 2023-12-04 15:45:05 --> Model "M_produk" initialized
INFO - 2023-12-04 15:45:05 --> Controller Class Initialized
INFO - 2023-12-04 15:45:05 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-04 15:45:05 --> Final output sent to browser
DEBUG - 2023-12-04 15:45:05 --> Total execution time: 0.0880
ERROR - 2023-12-04 15:45:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-04 15:45:13 --> Config Class Initialized
INFO - 2023-12-04 15:45:13 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:45:13 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:45:13 --> Utf8 Class Initialized
INFO - 2023-12-04 15:45:13 --> URI Class Initialized
INFO - 2023-12-04 15:45:13 --> Router Class Initialized
INFO - 2023-12-04 15:45:13 --> Output Class Initialized
INFO - 2023-12-04 15:45:13 --> Security Class Initialized
DEBUG - 2023-12-04 15:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:45:13 --> Input Class Initialized
INFO - 2023-12-04 15:45:13 --> Language Class Initialized
INFO - 2023-12-04 15:45:13 --> Loader Class Initialized
INFO - 2023-12-04 15:45:13 --> Helper loaded: url_helper
INFO - 2023-12-04 15:45:13 --> Helper loaded: form_helper
INFO - 2023-12-04 15:45:13 --> Helper loaded: file_helper
INFO - 2023-12-04 15:45:13 --> Database Driver Class Initialized
DEBUG - 2023-12-04 15:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 15:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:45:13 --> Form Validation Class Initialized
INFO - 2023-12-04 15:45:13 --> Upload Class Initialized
INFO - 2023-12-04 15:45:13 --> Model "M_auth" initialized
INFO - 2023-12-04 15:45:13 --> Model "M_user" initialized
INFO - 2023-12-04 15:45:13 --> Model "M_produk" initialized
INFO - 2023-12-04 15:45:13 --> Controller Class Initialized
INFO - 2023-12-04 15:45:13 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 15:45:13 --> Model "M_produk" initialized
DEBUG - 2023-12-04 15:45:13 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 15:45:13 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 15:45:13 --> Model "M_transaksi" initialized
INFO - 2023-12-04 15:45:13 --> Model "M_bank" initialized
INFO - 2023-12-04 15:45:13 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 15:45:13 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-04 15:45:13 --> Email Class Initialized
INFO - 2023-12-04 15:45:15 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-12-04 15:45:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-04 15:45:18 --> Config Class Initialized
INFO - 2023-12-04 15:45:18 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:45:18 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:45:18 --> Utf8 Class Initialized
INFO - 2023-12-04 15:45:18 --> URI Class Initialized
INFO - 2023-12-04 15:45:18 --> Router Class Initialized
INFO - 2023-12-04 15:45:18 --> Output Class Initialized
INFO - 2023-12-04 15:45:18 --> Security Class Initialized
DEBUG - 2023-12-04 15:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:45:18 --> Input Class Initialized
INFO - 2023-12-04 15:45:18 --> Language Class Initialized
INFO - 2023-12-04 15:45:18 --> Loader Class Initialized
INFO - 2023-12-04 15:45:18 --> Helper loaded: url_helper
INFO - 2023-12-04 15:45:18 --> Helper loaded: form_helper
INFO - 2023-12-04 15:45:18 --> Helper loaded: file_helper
INFO - 2023-12-04 15:45:18 --> Database Driver Class Initialized
DEBUG - 2023-12-04 15:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 15:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:45:18 --> Form Validation Class Initialized
INFO - 2023-12-04 15:45:18 --> Upload Class Initialized
INFO - 2023-12-04 15:45:18 --> Model "M_auth" initialized
INFO - 2023-12-04 15:45:18 --> Model "M_user" initialized
INFO - 2023-12-04 15:45:18 --> Model "M_produk" initialized
INFO - 2023-12-04 15:45:18 --> Controller Class Initialized
INFO - 2023-12-04 15:45:18 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 15:45:18 --> Model "M_produk" initialized
DEBUG - 2023-12-04 15:45:18 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 15:45:18 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 15:45:18 --> Model "M_transaksi" initialized
INFO - 2023-12-04 15:45:18 --> Model "M_bank" initialized
INFO - 2023-12-04 15:45:18 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 15:45:18 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-04 15:45:20 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-04 15:45:20 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-04 15:45:20 --> Final output sent to browser
DEBUG - 2023-12-04 15:45:20 --> Total execution time: 2.0927
ERROR - 2023-12-04 15:47:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-04 15:47:15 --> Config Class Initialized
INFO - 2023-12-04 15:47:15 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:47:15 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:47:15 --> Utf8 Class Initialized
INFO - 2023-12-04 15:47:15 --> URI Class Initialized
DEBUG - 2023-12-04 15:47:15 --> No URI present. Default controller set.
INFO - 2023-12-04 15:47:15 --> Router Class Initialized
INFO - 2023-12-04 15:47:15 --> Output Class Initialized
INFO - 2023-12-04 15:47:15 --> Security Class Initialized
DEBUG - 2023-12-04 15:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:47:15 --> Input Class Initialized
INFO - 2023-12-04 15:47:15 --> Language Class Initialized
INFO - 2023-12-04 15:47:15 --> Loader Class Initialized
INFO - 2023-12-04 15:47:15 --> Helper loaded: url_helper
INFO - 2023-12-04 15:47:15 --> Helper loaded: form_helper
INFO - 2023-12-04 15:47:15 --> Helper loaded: file_helper
INFO - 2023-12-04 15:47:15 --> Database Driver Class Initialized
DEBUG - 2023-12-04 15:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 15:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:47:15 --> Form Validation Class Initialized
INFO - 2023-12-04 15:47:15 --> Upload Class Initialized
INFO - 2023-12-04 15:47:15 --> Model "M_auth" initialized
INFO - 2023-12-04 15:47:15 --> Model "M_user" initialized
INFO - 2023-12-04 15:47:15 --> Model "M_produk" initialized
INFO - 2023-12-04 15:47:15 --> Controller Class Initialized
INFO - 2023-12-04 15:47:15 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 15:47:15 --> Model "M_produk" initialized
DEBUG - 2023-12-04 15:47:15 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 15:47:15 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 15:47:15 --> Model "M_transaksi" initialized
INFO - 2023-12-04 15:47:15 --> Model "M_bank" initialized
INFO - 2023-12-04 15:47:15 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 15:47:15 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-04 15:47:15 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-04 15:47:15 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/index.php
INFO - 2023-12-04 15:47:15 --> Final output sent to browser
DEBUG - 2023-12-04 15:47:15 --> Total execution time: 0.0387
ERROR - 2023-12-04 15:47:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-04 15:47:19 --> Config Class Initialized
INFO - 2023-12-04 15:47:19 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:47:19 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:47:19 --> Utf8 Class Initialized
INFO - 2023-12-04 15:47:19 --> URI Class Initialized
INFO - 2023-12-04 15:47:19 --> Router Class Initialized
INFO - 2023-12-04 15:47:19 --> Output Class Initialized
INFO - 2023-12-04 15:47:19 --> Security Class Initialized
DEBUG - 2023-12-04 15:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:47:19 --> Input Class Initialized
INFO - 2023-12-04 15:47:19 --> Language Class Initialized
INFO - 2023-12-04 15:47:19 --> Loader Class Initialized
INFO - 2023-12-04 15:47:19 --> Helper loaded: url_helper
INFO - 2023-12-04 15:47:19 --> Helper loaded: form_helper
INFO - 2023-12-04 15:47:19 --> Helper loaded: file_helper
INFO - 2023-12-04 15:47:19 --> Database Driver Class Initialized
DEBUG - 2023-12-04 15:47:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 15:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:47:19 --> Form Validation Class Initialized
INFO - 2023-12-04 15:47:19 --> Upload Class Initialized
INFO - 2023-12-04 15:47:19 --> Model "M_auth" initialized
INFO - 2023-12-04 15:47:19 --> Model "M_user" initialized
INFO - 2023-12-04 15:47:19 --> Model "M_produk" initialized
INFO - 2023-12-04 15:47:19 --> Controller Class Initialized
INFO - 2023-12-04 15:47:19 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 15:47:19 --> Model "M_produk" initialized
DEBUG - 2023-12-04 15:47:19 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 15:47:19 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 15:47:19 --> Model "M_transaksi" initialized
INFO - 2023-12-04 15:47:19 --> Model "M_bank" initialized
INFO - 2023-12-04 15:47:19 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 15:47:19 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-04 15:47:21 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-04 15:47:21 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-04 15:47:21 --> Final output sent to browser
DEBUG - 2023-12-04 15:47:21 --> Total execution time: 1.5816
ERROR - 2023-12-04 16:11:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-04 16:11:38 --> Config Class Initialized
INFO - 2023-12-04 16:11:38 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:11:38 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:11:38 --> Utf8 Class Initialized
INFO - 2023-12-04 16:11:38 --> URI Class Initialized
INFO - 2023-12-04 16:11:38 --> Router Class Initialized
INFO - 2023-12-04 16:11:38 --> Output Class Initialized
INFO - 2023-12-04 16:11:38 --> Security Class Initialized
DEBUG - 2023-12-04 16:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:11:38 --> Input Class Initialized
INFO - 2023-12-04 16:11:38 --> Language Class Initialized
INFO - 2023-12-04 16:11:38 --> Loader Class Initialized
INFO - 2023-12-04 16:11:38 --> Helper loaded: url_helper
INFO - 2023-12-04 16:11:38 --> Helper loaded: form_helper
INFO - 2023-12-04 16:11:38 --> Helper loaded: file_helper
INFO - 2023-12-04 16:11:38 --> Database Driver Class Initialized
DEBUG - 2023-12-04 16:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 16:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:11:38 --> Form Validation Class Initialized
INFO - 2023-12-04 16:11:38 --> Upload Class Initialized
INFO - 2023-12-04 16:11:38 --> Model "M_auth" initialized
INFO - 2023-12-04 16:11:38 --> Model "M_user" initialized
INFO - 2023-12-04 16:11:38 --> Model "M_produk" initialized
INFO - 2023-12-04 16:11:38 --> Controller Class Initialized
INFO - 2023-12-04 16:11:38 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 16:11:38 --> Model "M_produk" initialized
DEBUG - 2023-12-04 16:11:38 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 16:11:38 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 16:11:38 --> Model "M_transaksi" initialized
INFO - 2023-12-04 16:11:38 --> Model "M_bank" initialized
INFO - 2023-12-04 16:11:38 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 16:11:38 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-04 16:11:39 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-04 16:11:39 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-04 16:11:39 --> Final output sent to browser
DEBUG - 2023-12-04 16:11:39 --> Total execution time: 0.7292
ERROR - 2023-12-04 16:17:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-04 16:17:17 --> Config Class Initialized
INFO - 2023-12-04 16:17:17 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:17:17 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:17:17 --> Utf8 Class Initialized
INFO - 2023-12-04 16:17:17 --> URI Class Initialized
INFO - 2023-12-04 16:17:17 --> Router Class Initialized
INFO - 2023-12-04 16:17:17 --> Output Class Initialized
INFO - 2023-12-04 16:17:17 --> Security Class Initialized
DEBUG - 2023-12-04 16:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:17:17 --> Input Class Initialized
INFO - 2023-12-04 16:17:17 --> Language Class Initialized
INFO - 2023-12-04 16:17:17 --> Loader Class Initialized
INFO - 2023-12-04 16:17:17 --> Helper loaded: url_helper
INFO - 2023-12-04 16:17:17 --> Helper loaded: form_helper
INFO - 2023-12-04 16:17:17 --> Helper loaded: file_helper
INFO - 2023-12-04 16:17:17 --> Database Driver Class Initialized
DEBUG - 2023-12-04 16:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 16:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:17:17 --> Form Validation Class Initialized
INFO - 2023-12-04 16:17:17 --> Upload Class Initialized
INFO - 2023-12-04 16:17:17 --> Model "M_auth" initialized
INFO - 2023-12-04 16:17:17 --> Model "M_user" initialized
INFO - 2023-12-04 16:17:17 --> Model "M_produk" initialized
INFO - 2023-12-04 16:17:17 --> Controller Class Initialized
INFO - 2023-12-04 16:17:17 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 16:17:17 --> Model "M_produk" initialized
DEBUG - 2023-12-04 16:17:17 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 16:17:17 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 16:17:17 --> Model "M_transaksi" initialized
INFO - 2023-12-04 16:17:17 --> Model "M_bank" initialized
INFO - 2023-12-04 16:17:17 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 16:17:17 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-04 16:17:17 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-04 16:17:17 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-04 16:17:17 --> Final output sent to browser
DEBUG - 2023-12-04 16:17:17 --> Total execution time: 0.6476
ERROR - 2023-12-04 16:18:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-04 16:18:04 --> Config Class Initialized
INFO - 2023-12-04 16:18:04 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:18:04 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:18:04 --> Utf8 Class Initialized
INFO - 2023-12-04 16:18:04 --> URI Class Initialized
INFO - 2023-12-04 16:18:04 --> Router Class Initialized
INFO - 2023-12-04 16:18:04 --> Output Class Initialized
INFO - 2023-12-04 16:18:04 --> Security Class Initialized
DEBUG - 2023-12-04 16:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:18:04 --> Input Class Initialized
INFO - 2023-12-04 16:18:04 --> Language Class Initialized
INFO - 2023-12-04 16:18:04 --> Loader Class Initialized
INFO - 2023-12-04 16:18:04 --> Helper loaded: url_helper
INFO - 2023-12-04 16:18:04 --> Helper loaded: form_helper
INFO - 2023-12-04 16:18:04 --> Helper loaded: file_helper
INFO - 2023-12-04 16:18:04 --> Database Driver Class Initialized
DEBUG - 2023-12-04 16:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 16:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:18:04 --> Form Validation Class Initialized
INFO - 2023-12-04 16:18:04 --> Upload Class Initialized
INFO - 2023-12-04 16:18:04 --> Model "M_auth" initialized
INFO - 2023-12-04 16:18:04 --> Model "M_user" initialized
INFO - 2023-12-04 16:18:04 --> Model "M_produk" initialized
INFO - 2023-12-04 16:18:04 --> Controller Class Initialized
INFO - 2023-12-04 16:18:04 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 16:18:04 --> Model "M_produk" initialized
DEBUG - 2023-12-04 16:18:04 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 16:18:04 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 16:18:04 --> Model "M_transaksi" initialized
INFO - 2023-12-04 16:18:04 --> Model "M_bank" initialized
INFO - 2023-12-04 16:18:04 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 16:18:04 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-04 16:18:05 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-04 16:18:05 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-04 16:18:05 --> Final output sent to browser
DEBUG - 2023-12-04 16:18:05 --> Total execution time: 0.6590
ERROR - 2023-12-04 16:19:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-04 16:19:24 --> Config Class Initialized
INFO - 2023-12-04 16:19:24 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:19:24 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:19:24 --> Utf8 Class Initialized
INFO - 2023-12-04 16:19:24 --> URI Class Initialized
INFO - 2023-12-04 16:19:24 --> Router Class Initialized
INFO - 2023-12-04 16:19:24 --> Output Class Initialized
INFO - 2023-12-04 16:19:24 --> Security Class Initialized
DEBUG - 2023-12-04 16:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:19:24 --> Input Class Initialized
INFO - 2023-12-04 16:19:24 --> Language Class Initialized
INFO - 2023-12-04 16:19:24 --> Loader Class Initialized
INFO - 2023-12-04 16:19:24 --> Helper loaded: url_helper
INFO - 2023-12-04 16:19:24 --> Helper loaded: form_helper
INFO - 2023-12-04 16:19:24 --> Helper loaded: file_helper
INFO - 2023-12-04 16:19:24 --> Database Driver Class Initialized
DEBUG - 2023-12-04 16:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 16:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:19:24 --> Form Validation Class Initialized
INFO - 2023-12-04 16:19:24 --> Upload Class Initialized
INFO - 2023-12-04 16:19:24 --> Model "M_auth" initialized
INFO - 2023-12-04 16:19:24 --> Model "M_user" initialized
INFO - 2023-12-04 16:19:24 --> Model "M_produk" initialized
INFO - 2023-12-04 16:19:24 --> Controller Class Initialized
INFO - 2023-12-04 16:19:24 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 16:19:24 --> Model "M_produk" initialized
DEBUG - 2023-12-04 16:19:24 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 16:19:24 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 16:19:24 --> Model "M_transaksi" initialized
INFO - 2023-12-04 16:19:24 --> Model "M_bank" initialized
INFO - 2023-12-04 16:19:24 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 16:19:24 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-04 16:19:25 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-04 16:19:25 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-04 16:19:25 --> Final output sent to browser
DEBUG - 2023-12-04 16:19:25 --> Total execution time: 0.8784
ERROR - 2023-12-04 16:20:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-04 16:20:39 --> Config Class Initialized
INFO - 2023-12-04 16:20:39 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:20:39 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:20:39 --> Utf8 Class Initialized
INFO - 2023-12-04 16:20:39 --> URI Class Initialized
INFO - 2023-12-04 16:20:39 --> Router Class Initialized
INFO - 2023-12-04 16:20:39 --> Output Class Initialized
INFO - 2023-12-04 16:20:39 --> Security Class Initialized
DEBUG - 2023-12-04 16:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:20:39 --> Input Class Initialized
INFO - 2023-12-04 16:20:39 --> Language Class Initialized
INFO - 2023-12-04 16:20:39 --> Loader Class Initialized
INFO - 2023-12-04 16:20:39 --> Helper loaded: url_helper
INFO - 2023-12-04 16:20:39 --> Helper loaded: form_helper
INFO - 2023-12-04 16:20:39 --> Helper loaded: file_helper
INFO - 2023-12-04 16:20:39 --> Database Driver Class Initialized
DEBUG - 2023-12-04 16:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 16:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:20:39 --> Form Validation Class Initialized
INFO - 2023-12-04 16:20:39 --> Upload Class Initialized
INFO - 2023-12-04 16:20:39 --> Model "M_auth" initialized
INFO - 2023-12-04 16:20:39 --> Model "M_user" initialized
INFO - 2023-12-04 16:20:39 --> Model "M_produk" initialized
INFO - 2023-12-04 16:20:39 --> Controller Class Initialized
INFO - 2023-12-04 16:20:39 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 16:20:39 --> Model "M_produk" initialized
DEBUG - 2023-12-04 16:20:39 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 16:20:39 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 16:20:39 --> Model "M_transaksi" initialized
INFO - 2023-12-04 16:20:39 --> Model "M_bank" initialized
INFO - 2023-12-04 16:20:39 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 16:20:39 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-04 16:20:39 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-04 16:20:39 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-04 16:20:39 --> Final output sent to browser
DEBUG - 2023-12-04 16:20:39 --> Total execution time: 0.6450
ERROR - 2023-12-04 16:22:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-04 16:22:16 --> Config Class Initialized
INFO - 2023-12-04 16:22:16 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:22:16 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:22:16 --> Utf8 Class Initialized
INFO - 2023-12-04 16:22:16 --> URI Class Initialized
INFO - 2023-12-04 16:22:16 --> Router Class Initialized
INFO - 2023-12-04 16:22:16 --> Output Class Initialized
INFO - 2023-12-04 16:22:16 --> Security Class Initialized
DEBUG - 2023-12-04 16:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:22:16 --> Input Class Initialized
INFO - 2023-12-04 16:22:16 --> Language Class Initialized
INFO - 2023-12-04 16:22:16 --> Loader Class Initialized
INFO - 2023-12-04 16:22:16 --> Helper loaded: url_helper
INFO - 2023-12-04 16:22:16 --> Helper loaded: form_helper
INFO - 2023-12-04 16:22:16 --> Helper loaded: file_helper
INFO - 2023-12-04 16:22:16 --> Database Driver Class Initialized
DEBUG - 2023-12-04 16:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 16:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:22:16 --> Form Validation Class Initialized
INFO - 2023-12-04 16:22:16 --> Upload Class Initialized
INFO - 2023-12-04 16:22:16 --> Model "M_auth" initialized
INFO - 2023-12-04 16:22:16 --> Model "M_user" initialized
INFO - 2023-12-04 16:22:16 --> Model "M_produk" initialized
INFO - 2023-12-04 16:22:16 --> Controller Class Initialized
INFO - 2023-12-04 16:22:16 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 16:22:16 --> Model "M_produk" initialized
DEBUG - 2023-12-04 16:22:16 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 16:22:16 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 16:22:16 --> Model "M_transaksi" initialized
INFO - 2023-12-04 16:22:16 --> Model "M_bank" initialized
INFO - 2023-12-04 16:22:16 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 16:22:16 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-04 16:22:16 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-04 16:22:16 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-04 16:22:16 --> Final output sent to browser
DEBUG - 2023-12-04 16:22:16 --> Total execution time: 0.8583
ERROR - 2023-12-04 16:26:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-04 16:26:47 --> Config Class Initialized
INFO - 2023-12-04 16:26:47 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:26:47 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:26:47 --> Utf8 Class Initialized
INFO - 2023-12-04 16:26:47 --> URI Class Initialized
INFO - 2023-12-04 16:26:47 --> Router Class Initialized
INFO - 2023-12-04 16:26:47 --> Output Class Initialized
INFO - 2023-12-04 16:26:47 --> Security Class Initialized
DEBUG - 2023-12-04 16:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:26:47 --> Input Class Initialized
INFO - 2023-12-04 16:26:47 --> Language Class Initialized
INFO - 2023-12-04 16:26:47 --> Loader Class Initialized
INFO - 2023-12-04 16:26:47 --> Helper loaded: url_helper
INFO - 2023-12-04 16:26:47 --> Helper loaded: form_helper
INFO - 2023-12-04 16:26:47 --> Helper loaded: file_helper
INFO - 2023-12-04 16:26:47 --> Database Driver Class Initialized
DEBUG - 2023-12-04 16:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 16:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:26:47 --> Form Validation Class Initialized
INFO - 2023-12-04 16:26:47 --> Upload Class Initialized
INFO - 2023-12-04 16:26:47 --> Model "M_auth" initialized
INFO - 2023-12-04 16:26:47 --> Model "M_user" initialized
INFO - 2023-12-04 16:26:47 --> Model "M_produk" initialized
INFO - 2023-12-04 16:26:47 --> Controller Class Initialized
INFO - 2023-12-04 16:26:47 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 16:26:47 --> Model "M_produk" initialized
DEBUG - 2023-12-04 16:26:47 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 16:26:47 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 16:26:47 --> Model "M_transaksi" initialized
INFO - 2023-12-04 16:26:47 --> Model "M_bank" initialized
INFO - 2023-12-04 16:26:47 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 16:26:47 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-04 16:26:48 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-04 16:26:48 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-04 16:26:48 --> Final output sent to browser
DEBUG - 2023-12-04 16:26:48 --> Total execution time: 0.8403
ERROR - 2023-12-04 16:44:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-04 16:44:17 --> Config Class Initialized
INFO - 2023-12-04 16:44:17 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:44:17 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:44:17 --> Utf8 Class Initialized
INFO - 2023-12-04 16:44:17 --> URI Class Initialized
INFO - 2023-12-04 16:44:17 --> Router Class Initialized
INFO - 2023-12-04 16:44:17 --> Output Class Initialized
INFO - 2023-12-04 16:44:17 --> Security Class Initialized
DEBUG - 2023-12-04 16:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:44:17 --> Input Class Initialized
INFO - 2023-12-04 16:44:17 --> Language Class Initialized
INFO - 2023-12-04 16:44:17 --> Loader Class Initialized
INFO - 2023-12-04 16:44:17 --> Helper loaded: url_helper
INFO - 2023-12-04 16:44:17 --> Helper loaded: form_helper
INFO - 2023-12-04 16:44:17 --> Helper loaded: file_helper
INFO - 2023-12-04 16:44:17 --> Database Driver Class Initialized
DEBUG - 2023-12-04 16:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 16:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:44:17 --> Form Validation Class Initialized
INFO - 2023-12-04 16:44:17 --> Upload Class Initialized
INFO - 2023-12-04 16:44:17 --> Model "M_auth" initialized
INFO - 2023-12-04 16:44:17 --> Model "M_user" initialized
INFO - 2023-12-04 16:44:17 --> Model "M_produk" initialized
INFO - 2023-12-04 16:44:17 --> Controller Class Initialized
INFO - 2023-12-04 16:44:17 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 16:44:17 --> Model "M_produk" initialized
DEBUG - 2023-12-04 16:44:17 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 16:44:17 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 16:44:17 --> Model "M_transaksi" initialized
INFO - 2023-12-04 16:44:17 --> Model "M_bank" initialized
INFO - 2023-12-04 16:44:17 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 16:44:17 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-04 16:44:18 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-04 16:44:18 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-04 16:44:18 --> Final output sent to browser
DEBUG - 2023-12-04 16:44:18 --> Total execution time: 0.8683
ERROR - 2023-12-04 16:47:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-04 16:47:10 --> Config Class Initialized
INFO - 2023-12-04 16:47:10 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:47:10 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:47:10 --> Utf8 Class Initialized
INFO - 2023-12-04 16:47:10 --> URI Class Initialized
INFO - 2023-12-04 16:47:10 --> Router Class Initialized
INFO - 2023-12-04 16:47:10 --> Output Class Initialized
INFO - 2023-12-04 16:47:10 --> Security Class Initialized
DEBUG - 2023-12-04 16:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:47:10 --> Input Class Initialized
INFO - 2023-12-04 16:47:10 --> Language Class Initialized
INFO - 2023-12-04 16:47:10 --> Loader Class Initialized
INFO - 2023-12-04 16:47:10 --> Helper loaded: url_helper
INFO - 2023-12-04 16:47:10 --> Helper loaded: form_helper
INFO - 2023-12-04 16:47:10 --> Helper loaded: file_helper
INFO - 2023-12-04 16:47:10 --> Database Driver Class Initialized
DEBUG - 2023-12-04 16:47:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 16:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:47:10 --> Form Validation Class Initialized
INFO - 2023-12-04 16:47:10 --> Upload Class Initialized
INFO - 2023-12-04 16:47:10 --> Model "M_auth" initialized
INFO - 2023-12-04 16:47:10 --> Model "M_user" initialized
INFO - 2023-12-04 16:47:10 --> Model "M_produk" initialized
INFO - 2023-12-04 16:47:10 --> Controller Class Initialized
INFO - 2023-12-04 16:47:10 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-04 16:47:10 --> Final output sent to browser
DEBUG - 2023-12-04 16:47:10 --> Total execution time: 0.0369
ERROR - 2023-12-04 16:49:05 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-04 16:49:05 --> Config Class Initialized
INFO - 2023-12-04 16:49:05 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:49:05 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:49:05 --> Utf8 Class Initialized
INFO - 2023-12-04 16:49:05 --> URI Class Initialized
INFO - 2023-12-04 16:49:05 --> Router Class Initialized
INFO - 2023-12-04 16:49:05 --> Output Class Initialized
INFO - 2023-12-04 16:49:05 --> Security Class Initialized
DEBUG - 2023-12-04 16:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:49:06 --> Input Class Initialized
INFO - 2023-12-04 16:49:06 --> Language Class Initialized
INFO - 2023-12-04 16:49:06 --> Loader Class Initialized
INFO - 2023-12-04 16:49:06 --> Helper loaded: url_helper
INFO - 2023-12-04 16:49:06 --> Helper loaded: form_helper
INFO - 2023-12-04 16:49:06 --> Helper loaded: file_helper
INFO - 2023-12-04 16:49:06 --> Database Driver Class Initialized
DEBUG - 2023-12-04 16:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 16:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:49:06 --> Form Validation Class Initialized
INFO - 2023-12-04 16:49:06 --> Upload Class Initialized
INFO - 2023-12-04 16:49:06 --> Model "M_auth" initialized
INFO - 2023-12-04 16:49:06 --> Model "M_user" initialized
INFO - 2023-12-04 16:49:06 --> Model "M_produk" initialized
INFO - 2023-12-04 16:49:06 --> Controller Class Initialized
INFO - 2023-12-04 16:49:06 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 16:49:06 --> Model "M_produk" initialized
DEBUG - 2023-12-04 16:49:06 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 16:49:06 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 16:49:06 --> Model "M_transaksi" initialized
INFO - 2023-12-04 16:49:06 --> Model "M_bank" initialized
INFO - 2023-12-04 16:49:06 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 16:49:06 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
ERROR - 2023-12-04 16:49:06 --> Error generating Snap Token: Midtrans API is returning API error. HTTP status code: 400 API response: {"error_messages":["transaction_details.order_id sudah digunakan"]}
INFO - 2023-12-04 16:49:06 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-04 16:49:06 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-04 16:49:06 --> Final output sent to browser
DEBUG - 2023-12-04 16:49:06 --> Total execution time: 0.6847
ERROR - 2023-12-04 16:49:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-04 16:49:07 --> Config Class Initialized
INFO - 2023-12-04 16:49:07 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:49:07 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:49:07 --> Utf8 Class Initialized
INFO - 2023-12-04 16:49:07 --> URI Class Initialized
INFO - 2023-12-04 16:49:07 --> Router Class Initialized
INFO - 2023-12-04 16:49:07 --> Output Class Initialized
INFO - 2023-12-04 16:49:07 --> Security Class Initialized
DEBUG - 2023-12-04 16:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:49:07 --> Input Class Initialized
INFO - 2023-12-04 16:49:07 --> Language Class Initialized
INFO - 2023-12-04 16:49:07 --> Loader Class Initialized
INFO - 2023-12-04 16:49:07 --> Helper loaded: url_helper
INFO - 2023-12-04 16:49:07 --> Helper loaded: form_helper
INFO - 2023-12-04 16:49:07 --> Helper loaded: file_helper
INFO - 2023-12-04 16:49:07 --> Database Driver Class Initialized
DEBUG - 2023-12-04 16:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 16:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:49:07 --> Form Validation Class Initialized
INFO - 2023-12-04 16:49:07 --> Upload Class Initialized
INFO - 2023-12-04 16:49:07 --> Model "M_auth" initialized
INFO - 2023-12-04 16:49:07 --> Model "M_user" initialized
INFO - 2023-12-04 16:49:07 --> Model "M_produk" initialized
INFO - 2023-12-04 16:49:07 --> Controller Class Initialized
INFO - 2023-12-04 16:49:07 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-04 16:49:07 --> Final output sent to browser
DEBUG - 2023-12-04 16:49:07 --> Total execution time: 0.0274
ERROR - 2023-12-04 16:52:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-04 16:52:03 --> Config Class Initialized
INFO - 2023-12-04 16:52:03 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:52:03 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:52:03 --> Utf8 Class Initialized
INFO - 2023-12-04 16:52:03 --> URI Class Initialized
INFO - 2023-12-04 16:52:03 --> Router Class Initialized
INFO - 2023-12-04 16:52:03 --> Output Class Initialized
INFO - 2023-12-04 16:52:03 --> Security Class Initialized
DEBUG - 2023-12-04 16:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:52:03 --> Input Class Initialized
INFO - 2023-12-04 16:52:03 --> Language Class Initialized
INFO - 2023-12-04 16:52:03 --> Loader Class Initialized
INFO - 2023-12-04 16:52:03 --> Helper loaded: url_helper
INFO - 2023-12-04 16:52:03 --> Helper loaded: form_helper
INFO - 2023-12-04 16:52:03 --> Helper loaded: file_helper
INFO - 2023-12-04 16:52:03 --> Database Driver Class Initialized
DEBUG - 2023-12-04 16:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 16:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:52:03 --> Form Validation Class Initialized
INFO - 2023-12-04 16:52:03 --> Upload Class Initialized
INFO - 2023-12-04 16:52:03 --> Model "M_auth" initialized
INFO - 2023-12-04 16:52:03 --> Model "M_user" initialized
INFO - 2023-12-04 16:52:03 --> Model "M_produk" initialized
INFO - 2023-12-04 16:52:03 --> Controller Class Initialized
INFO - 2023-12-04 16:52:03 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 16:52:03 --> Model "M_produk" initialized
DEBUG - 2023-12-04 16:52:03 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 16:52:03 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 16:52:03 --> Model "M_transaksi" initialized
INFO - 2023-12-04 16:52:03 --> Model "M_bank" initialized
INFO - 2023-12-04 16:52:03 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 16:52:03 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
ERROR - 2023-12-04 16:52:04 --> Error generating Snap Token: Midtrans API is returning API error. HTTP status code: 400 API response: {"error_messages":["transaction_details.order_id sudah digunakan"]}
INFO - 2023-12-04 16:52:04 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-04 16:52:04 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-04 16:52:04 --> Final output sent to browser
DEBUG - 2023-12-04 16:52:04 --> Total execution time: 0.6897
ERROR - 2023-12-04 16:52:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-04 16:52:04 --> Config Class Initialized
INFO - 2023-12-04 16:52:04 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:52:04 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:52:04 --> Utf8 Class Initialized
INFO - 2023-12-04 16:52:04 --> URI Class Initialized
INFO - 2023-12-04 16:52:04 --> Router Class Initialized
INFO - 2023-12-04 16:52:04 --> Output Class Initialized
INFO - 2023-12-04 16:52:04 --> Security Class Initialized
DEBUG - 2023-12-04 16:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:52:04 --> Input Class Initialized
INFO - 2023-12-04 16:52:04 --> Language Class Initialized
INFO - 2023-12-04 16:52:04 --> Loader Class Initialized
INFO - 2023-12-04 16:52:04 --> Helper loaded: url_helper
INFO - 2023-12-04 16:52:04 --> Helper loaded: form_helper
INFO - 2023-12-04 16:52:04 --> Helper loaded: file_helper
INFO - 2023-12-04 16:52:04 --> Database Driver Class Initialized
DEBUG - 2023-12-04 16:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 16:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:52:04 --> Form Validation Class Initialized
INFO - 2023-12-04 16:52:04 --> Upload Class Initialized
INFO - 2023-12-04 16:52:04 --> Model "M_auth" initialized
INFO - 2023-12-04 16:52:04 --> Model "M_user" initialized
INFO - 2023-12-04 16:52:04 --> Model "M_produk" initialized
INFO - 2023-12-04 16:52:04 --> Controller Class Initialized
INFO - 2023-12-04 16:52:04 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-04 16:52:04 --> Final output sent to browser
DEBUG - 2023-12-04 16:52:04 --> Total execution time: 0.0302
ERROR - 2023-12-04 16:52:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-04 16:52:20 --> Config Class Initialized
INFO - 2023-12-04 16:52:20 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:52:20 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:52:20 --> Utf8 Class Initialized
INFO - 2023-12-04 16:52:20 --> URI Class Initialized
INFO - 2023-12-04 16:52:20 --> Router Class Initialized
INFO - 2023-12-04 16:52:20 --> Output Class Initialized
INFO - 2023-12-04 16:52:20 --> Security Class Initialized
DEBUG - 2023-12-04 16:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:52:20 --> Input Class Initialized
INFO - 2023-12-04 16:52:20 --> Language Class Initialized
INFO - 2023-12-04 16:52:20 --> Loader Class Initialized
INFO - 2023-12-04 16:52:20 --> Helper loaded: url_helper
INFO - 2023-12-04 16:52:20 --> Helper loaded: form_helper
INFO - 2023-12-04 16:52:20 --> Helper loaded: file_helper
INFO - 2023-12-04 16:52:20 --> Database Driver Class Initialized
DEBUG - 2023-12-04 16:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 16:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:52:20 --> Form Validation Class Initialized
INFO - 2023-12-04 16:52:20 --> Upload Class Initialized
INFO - 2023-12-04 16:52:20 --> Model "M_auth" initialized
INFO - 2023-12-04 16:52:20 --> Model "M_user" initialized
INFO - 2023-12-04 16:52:20 --> Model "M_produk" initialized
INFO - 2023-12-04 16:52:20 --> Controller Class Initialized
INFO - 2023-12-04 16:52:20 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 16:52:20 --> Model "M_produk" initialized
DEBUG - 2023-12-04 16:52:20 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 16:52:20 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 16:52:20 --> Model "M_transaksi" initialized
INFO - 2023-12-04 16:52:20 --> Model "M_bank" initialized
INFO - 2023-12-04 16:52:20 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 16:52:20 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
ERROR - 2023-12-04 16:52:20 --> Error generating Snap Token: Midtrans API is returning API error. HTTP status code: 400 API response: {"error_messages":["transaction_details.order_id sudah digunakan"]}
INFO - 2023-12-04 16:52:20 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-04 16:52:20 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-04 16:52:20 --> Final output sent to browser
DEBUG - 2023-12-04 16:52:20 --> Total execution time: 0.5332
ERROR - 2023-12-04 16:52:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-04 16:52:21 --> Config Class Initialized
INFO - 2023-12-04 16:52:21 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:52:21 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:52:21 --> Utf8 Class Initialized
INFO - 2023-12-04 16:52:21 --> URI Class Initialized
INFO - 2023-12-04 16:52:21 --> Router Class Initialized
INFO - 2023-12-04 16:52:21 --> Output Class Initialized
INFO - 2023-12-04 16:52:21 --> Security Class Initialized
DEBUG - 2023-12-04 16:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:52:21 --> Input Class Initialized
INFO - 2023-12-04 16:52:21 --> Language Class Initialized
INFO - 2023-12-04 16:52:21 --> Loader Class Initialized
INFO - 2023-12-04 16:52:21 --> Helper loaded: url_helper
INFO - 2023-12-04 16:52:21 --> Helper loaded: form_helper
INFO - 2023-12-04 16:52:21 --> Helper loaded: file_helper
INFO - 2023-12-04 16:52:21 --> Database Driver Class Initialized
DEBUG - 2023-12-04 16:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 16:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:52:21 --> Form Validation Class Initialized
INFO - 2023-12-04 16:52:21 --> Upload Class Initialized
INFO - 2023-12-04 16:52:21 --> Model "M_auth" initialized
INFO - 2023-12-04 16:52:21 --> Model "M_user" initialized
INFO - 2023-12-04 16:52:21 --> Model "M_produk" initialized
INFO - 2023-12-04 16:52:21 --> Controller Class Initialized
INFO - 2023-12-04 16:52:21 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-04 16:52:21 --> Final output sent to browser
DEBUG - 2023-12-04 16:52:21 --> Total execution time: 0.0300
ERROR - 2023-12-04 16:52:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-04 16:52:47 --> Config Class Initialized
INFO - 2023-12-04 16:52:47 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:52:47 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:52:47 --> Utf8 Class Initialized
INFO - 2023-12-04 16:52:47 --> URI Class Initialized
INFO - 2023-12-04 16:52:47 --> Router Class Initialized
INFO - 2023-12-04 16:52:47 --> Output Class Initialized
INFO - 2023-12-04 16:52:47 --> Security Class Initialized
DEBUG - 2023-12-04 16:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:52:47 --> Input Class Initialized
INFO - 2023-12-04 16:52:47 --> Language Class Initialized
INFO - 2023-12-04 16:52:47 --> Loader Class Initialized
INFO - 2023-12-04 16:52:47 --> Helper loaded: url_helper
INFO - 2023-12-04 16:52:47 --> Helper loaded: form_helper
INFO - 2023-12-04 16:52:47 --> Helper loaded: file_helper
INFO - 2023-12-04 16:52:47 --> Database Driver Class Initialized
DEBUG - 2023-12-04 16:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 16:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:52:47 --> Form Validation Class Initialized
INFO - 2023-12-04 16:52:47 --> Upload Class Initialized
INFO - 2023-12-04 16:52:47 --> Model "M_auth" initialized
INFO - 2023-12-04 16:52:47 --> Model "M_user" initialized
INFO - 2023-12-04 16:52:47 --> Model "M_produk" initialized
INFO - 2023-12-04 16:52:47 --> Controller Class Initialized
INFO - 2023-12-04 16:52:47 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 16:52:47 --> Model "M_produk" initialized
DEBUG - 2023-12-04 16:52:47 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 16:52:47 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 16:52:47 --> Model "M_transaksi" initialized
INFO - 2023-12-04 16:52:47 --> Model "M_bank" initialized
INFO - 2023-12-04 16:52:47 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 16:52:47 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
ERROR - 2023-12-04 16:52:47 --> Error generating Snap Token: Midtrans API is returning API error. HTTP status code: 400 API response: {"error_messages":["transaction_details.order_id sudah digunakan"]}
INFO - 2023-12-04 16:52:47 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-04 16:52:47 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-04 16:52:47 --> Final output sent to browser
DEBUG - 2023-12-04 16:52:47 --> Total execution time: 0.6596
ERROR - 2023-12-04 16:52:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-04 16:52:48 --> Config Class Initialized
INFO - 2023-12-04 16:52:48 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:52:48 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:52:48 --> Utf8 Class Initialized
INFO - 2023-12-04 16:52:48 --> URI Class Initialized
INFO - 2023-12-04 16:52:48 --> Router Class Initialized
INFO - 2023-12-04 16:52:48 --> Output Class Initialized
INFO - 2023-12-04 16:52:48 --> Security Class Initialized
DEBUG - 2023-12-04 16:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:52:48 --> Input Class Initialized
INFO - 2023-12-04 16:52:48 --> Language Class Initialized
INFO - 2023-12-04 16:52:48 --> Loader Class Initialized
INFO - 2023-12-04 16:52:48 --> Helper loaded: url_helper
INFO - 2023-12-04 16:52:48 --> Helper loaded: form_helper
INFO - 2023-12-04 16:52:48 --> Helper loaded: file_helper
INFO - 2023-12-04 16:52:48 --> Database Driver Class Initialized
DEBUG - 2023-12-04 16:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 16:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:52:48 --> Form Validation Class Initialized
INFO - 2023-12-04 16:52:48 --> Upload Class Initialized
INFO - 2023-12-04 16:52:48 --> Model "M_auth" initialized
INFO - 2023-12-04 16:52:48 --> Model "M_user" initialized
INFO - 2023-12-04 16:52:48 --> Model "M_produk" initialized
INFO - 2023-12-04 16:52:48 --> Controller Class Initialized
INFO - 2023-12-04 16:52:48 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-04 16:52:48 --> Final output sent to browser
DEBUG - 2023-12-04 16:52:48 --> Total execution time: 0.0331
ERROR - 2023-12-04 16:55:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-04 16:55:26 --> Config Class Initialized
INFO - 2023-12-04 16:55:26 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:55:26 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:55:26 --> Utf8 Class Initialized
INFO - 2023-12-04 16:55:26 --> URI Class Initialized
INFO - 2023-12-04 16:55:26 --> Router Class Initialized
INFO - 2023-12-04 16:55:26 --> Output Class Initialized
INFO - 2023-12-04 16:55:26 --> Security Class Initialized
DEBUG - 2023-12-04 16:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:55:26 --> Input Class Initialized
INFO - 2023-12-04 16:55:26 --> Language Class Initialized
INFO - 2023-12-04 16:55:26 --> Loader Class Initialized
INFO - 2023-12-04 16:55:26 --> Helper loaded: url_helper
INFO - 2023-12-04 16:55:26 --> Helper loaded: form_helper
INFO - 2023-12-04 16:55:26 --> Helper loaded: file_helper
INFO - 2023-12-04 16:55:26 --> Database Driver Class Initialized
DEBUG - 2023-12-04 16:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 16:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:55:26 --> Form Validation Class Initialized
INFO - 2023-12-04 16:55:26 --> Upload Class Initialized
INFO - 2023-12-04 16:55:26 --> Model "M_auth" initialized
INFO - 2023-12-04 16:55:26 --> Model "M_user" initialized
INFO - 2023-12-04 16:55:26 --> Model "M_produk" initialized
INFO - 2023-12-04 16:55:26 --> Controller Class Initialized
INFO - 2023-12-04 16:55:26 --> Model "M_pelanggan" initialized
INFO - 2023-12-04 16:55:26 --> Model "M_produk" initialized
DEBUG - 2023-12-04 16:55:26 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-04 16:55:26 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-04 16:55:26 --> Model "M_transaksi" initialized
INFO - 2023-12-04 16:55:26 --> Model "M_bank" initialized
INFO - 2023-12-04 16:55:26 --> Model "M_pesan" initialized
DEBUG - 2023-12-04 16:55:26 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-04 16:55:27 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-04 16:55:27 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-04 16:55:27 --> Final output sent to browser
DEBUG - 2023-12-04 16:55:27 --> Total execution time: 1.2096
ERROR - 2023-12-04 16:55:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-04 16:55:27 --> Config Class Initialized
INFO - 2023-12-04 16:55:27 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:55:27 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:55:27 --> Utf8 Class Initialized
INFO - 2023-12-04 16:55:27 --> URI Class Initialized
INFO - 2023-12-04 16:55:27 --> Router Class Initialized
INFO - 2023-12-04 16:55:27 --> Output Class Initialized
INFO - 2023-12-04 16:55:27 --> Security Class Initialized
DEBUG - 2023-12-04 16:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:55:27 --> Input Class Initialized
INFO - 2023-12-04 16:55:27 --> Language Class Initialized
INFO - 2023-12-04 16:55:27 --> Loader Class Initialized
INFO - 2023-12-04 16:55:27 --> Helper loaded: url_helper
INFO - 2023-12-04 16:55:27 --> Helper loaded: form_helper
INFO - 2023-12-04 16:55:27 --> Helper loaded: file_helper
INFO - 2023-12-04 16:55:27 --> Database Driver Class Initialized
DEBUG - 2023-12-04 16:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-04 16:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:55:27 --> Form Validation Class Initialized
INFO - 2023-12-04 16:55:27 --> Upload Class Initialized
INFO - 2023-12-04 16:55:27 --> Model "M_auth" initialized
INFO - 2023-12-04 16:55:27 --> Model "M_user" initialized
INFO - 2023-12-04 16:55:27 --> Model "M_produk" initialized
INFO - 2023-12-04 16:55:27 --> Controller Class Initialized
INFO - 2023-12-04 16:55:27 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-04 16:55:27 --> Final output sent to browser
DEBUG - 2023-12-04 16:55:27 --> Total execution time: 0.0258
