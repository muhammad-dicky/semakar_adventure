<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-03 00:06:13 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-03 00:06:13 --> Config Class Initialized
INFO - 2023-11-03 00:06:13 --> Hooks Class Initialized
DEBUG - 2023-11-03 00:06:13 --> UTF-8 Support Enabled
INFO - 2023-11-03 00:06:13 --> Utf8 Class Initialized
INFO - 2023-11-03 00:06:13 --> URI Class Initialized
DEBUG - 2023-11-03 00:06:13 --> No URI present. Default controller set.
INFO - 2023-11-03 00:06:13 --> Router Class Initialized
INFO - 2023-11-03 00:06:13 --> Output Class Initialized
INFO - 2023-11-03 00:06:13 --> Security Class Initialized
DEBUG - 2023-11-03 00:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-03 00:06:13 --> Input Class Initialized
INFO - 2023-11-03 00:06:13 --> Language Class Initialized
INFO - 2023-11-03 00:06:13 --> Loader Class Initialized
INFO - 2023-11-03 00:06:13 --> Helper loaded: url_helper
INFO - 2023-11-03 00:06:13 --> Helper loaded: form_helper
INFO - 2023-11-03 00:06:13 --> Helper loaded: file_helper
INFO - 2023-11-03 00:06:13 --> Database Driver Class Initialized
DEBUG - 2023-11-03 00:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-03 00:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-03 00:06:13 --> Form Validation Class Initialized
INFO - 2023-11-03 00:06:13 --> Upload Class Initialized
INFO - 2023-11-03 00:06:13 --> Model "M_auth" initialized
INFO - 2023-11-03 00:06:13 --> Model "M_user" initialized
INFO - 2023-11-03 00:06:13 --> Model "M_produk" initialized
INFO - 2023-11-03 00:06:13 --> Controller Class Initialized
INFO - 2023-11-03 00:06:13 --> Model "M_pelanggan" initialized
INFO - 2023-11-03 00:06:13 --> Model "M_produk" initialized
DEBUG - 2023-11-03 00:06:13 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-03 00:06:13 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-03 00:06:13 --> Model "M_transaksi" initialized
INFO - 2023-11-03 00:06:13 --> Model "M_bank" initialized
INFO - 2023-11-03 00:06:13 --> Model "M_pesan" initialized
DEBUG - 2023-11-03 00:06:13 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-03 00:06:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-03 00:06:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-03 00:06:13 --> Final output sent to browser
DEBUG - 2023-11-03 00:06:13 --> Total execution time: 0.0532
ERROR - 2023-11-03 00:51:36 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-03 00:51:36 --> Config Class Initialized
INFO - 2023-11-03 00:51:36 --> Hooks Class Initialized
DEBUG - 2023-11-03 00:51:36 --> UTF-8 Support Enabled
INFO - 2023-11-03 00:51:36 --> Utf8 Class Initialized
INFO - 2023-11-03 00:51:36 --> URI Class Initialized
INFO - 2023-11-03 00:51:36 --> Router Class Initialized
INFO - 2023-11-03 00:51:36 --> Output Class Initialized
INFO - 2023-11-03 00:51:36 --> Security Class Initialized
DEBUG - 2023-11-03 00:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-03 00:51:36 --> Input Class Initialized
INFO - 2023-11-03 00:51:36 --> Language Class Initialized
INFO - 2023-11-03 00:51:36 --> Loader Class Initialized
INFO - 2023-11-03 00:51:36 --> Helper loaded: url_helper
INFO - 2023-11-03 00:51:36 --> Helper loaded: form_helper
INFO - 2023-11-03 00:51:36 --> Helper loaded: file_helper
INFO - 2023-11-03 00:51:36 --> Database Driver Class Initialized
DEBUG - 2023-11-03 00:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-03 00:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-03 00:51:36 --> Form Validation Class Initialized
INFO - 2023-11-03 00:51:36 --> Upload Class Initialized
INFO - 2023-11-03 00:51:36 --> Model "M_auth" initialized
INFO - 2023-11-03 00:51:36 --> Model "M_user" initialized
INFO - 2023-11-03 00:51:36 --> Model "M_produk" initialized
INFO - 2023-11-03 00:51:36 --> Controller Class Initialized
INFO - 2023-11-03 00:51:36 --> Model "M_pelanggan" initialized
INFO - 2023-11-03 00:51:36 --> Model "M_produk" initialized
DEBUG - 2023-11-03 00:51:36 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-03 00:51:36 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-03 00:51:36 --> Model "M_transaksi" initialized
INFO - 2023-11-03 00:51:36 --> Model "M_bank" initialized
INFO - 2023-11-03 00:51:36 --> Model "M_pesan" initialized
DEBUG - 2023-11-03 00:51:36 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-03 00:51:36 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-03 00:51:36 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-03 00:51:36 --> Final output sent to browser
DEBUG - 2023-11-03 00:51:36 --> Total execution time: 0.0420
ERROR - 2023-11-03 03:20:10 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-03 03:20:10 --> Config Class Initialized
INFO - 2023-11-03 03:20:10 --> Hooks Class Initialized
DEBUG - 2023-11-03 03:20:10 --> UTF-8 Support Enabled
INFO - 2023-11-03 03:20:10 --> Utf8 Class Initialized
INFO - 2023-11-03 03:20:10 --> URI Class Initialized
DEBUG - 2023-11-03 03:20:10 --> No URI present. Default controller set.
INFO - 2023-11-03 03:20:10 --> Router Class Initialized
INFO - 2023-11-03 03:20:10 --> Output Class Initialized
INFO - 2023-11-03 03:20:10 --> Security Class Initialized
DEBUG - 2023-11-03 03:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-03 03:20:10 --> Input Class Initialized
INFO - 2023-11-03 03:20:10 --> Language Class Initialized
INFO - 2023-11-03 03:20:10 --> Loader Class Initialized
INFO - 2023-11-03 03:20:10 --> Helper loaded: url_helper
INFO - 2023-11-03 03:20:10 --> Helper loaded: form_helper
INFO - 2023-11-03 03:20:10 --> Helper loaded: file_helper
INFO - 2023-11-03 03:20:10 --> Database Driver Class Initialized
DEBUG - 2023-11-03 03:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-03 03:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-03 03:20:10 --> Form Validation Class Initialized
INFO - 2023-11-03 03:20:10 --> Upload Class Initialized
INFO - 2023-11-03 03:20:10 --> Model "M_auth" initialized
INFO - 2023-11-03 03:20:10 --> Model "M_user" initialized
INFO - 2023-11-03 03:20:10 --> Model "M_produk" initialized
INFO - 2023-11-03 03:20:10 --> Controller Class Initialized
INFO - 2023-11-03 03:20:10 --> Model "M_pelanggan" initialized
INFO - 2023-11-03 03:20:10 --> Model "M_produk" initialized
DEBUG - 2023-11-03 03:20:10 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-03 03:20:10 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-03 03:20:10 --> Model "M_transaksi" initialized
INFO - 2023-11-03 03:20:10 --> Model "M_bank" initialized
INFO - 2023-11-03 03:20:10 --> Model "M_pesan" initialized
DEBUG - 2023-11-03 03:20:10 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-03 03:20:10 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-03 03:20:10 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-03 03:20:10 --> Final output sent to browser
DEBUG - 2023-11-03 03:20:10 --> Total execution time: 0.0455
ERROR - 2023-11-03 03:31:35 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-03 03:31:35 --> Config Class Initialized
INFO - 2023-11-03 03:31:35 --> Hooks Class Initialized
DEBUG - 2023-11-03 03:31:35 --> UTF-8 Support Enabled
INFO - 2023-11-03 03:31:35 --> Utf8 Class Initialized
INFO - 2023-11-03 03:31:35 --> URI Class Initialized
INFO - 2023-11-03 03:31:35 --> Router Class Initialized
INFO - 2023-11-03 03:31:35 --> Output Class Initialized
INFO - 2023-11-03 03:31:35 --> Security Class Initialized
DEBUG - 2023-11-03 03:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-03 03:31:35 --> Input Class Initialized
INFO - 2023-11-03 03:31:35 --> Language Class Initialized
INFO - 2023-11-03 03:31:35 --> Loader Class Initialized
INFO - 2023-11-03 03:31:35 --> Helper loaded: url_helper
INFO - 2023-11-03 03:31:35 --> Helper loaded: form_helper
INFO - 2023-11-03 03:31:35 --> Helper loaded: file_helper
INFO - 2023-11-03 03:31:35 --> Database Driver Class Initialized
DEBUG - 2023-11-03 03:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-03 03:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-03 03:31:35 --> Form Validation Class Initialized
INFO - 2023-11-03 03:31:35 --> Upload Class Initialized
INFO - 2023-11-03 03:31:35 --> Model "M_auth" initialized
INFO - 2023-11-03 03:31:35 --> Model "M_user" initialized
INFO - 2023-11-03 03:31:35 --> Model "M_produk" initialized
INFO - 2023-11-03 03:31:35 --> Controller Class Initialized
INFO - 2023-11-03 03:31:35 --> Model "M_pelanggan" initialized
INFO - 2023-11-03 03:31:35 --> Model "M_produk" initialized
DEBUG - 2023-11-03 03:31:35 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-03 03:31:35 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-03 03:31:35 --> Model "M_transaksi" initialized
INFO - 2023-11-03 03:31:35 --> Model "M_bank" initialized
INFO - 2023-11-03 03:31:35 --> Model "M_pesan" initialized
DEBUG - 2023-11-03 03:31:35 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-03 03:31:35 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-03 03:31:35 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_kategori_detail.php
INFO - 2023-11-03 03:31:35 --> Final output sent to browser
DEBUG - 2023-11-03 03:31:35 --> Total execution time: 0.0332
ERROR - 2023-11-03 04:15:47 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-03 04:15:47 --> Config Class Initialized
INFO - 2023-11-03 04:15:47 --> Hooks Class Initialized
DEBUG - 2023-11-03 04:15:47 --> UTF-8 Support Enabled
INFO - 2023-11-03 04:15:47 --> Utf8 Class Initialized
INFO - 2023-11-03 04:15:47 --> URI Class Initialized
INFO - 2023-11-03 04:15:47 --> Router Class Initialized
INFO - 2023-11-03 04:15:47 --> Output Class Initialized
INFO - 2023-11-03 04:15:47 --> Security Class Initialized
DEBUG - 2023-11-03 04:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-03 04:15:47 --> Input Class Initialized
INFO - 2023-11-03 04:15:47 --> Language Class Initialized
INFO - 2023-11-03 04:15:47 --> Loader Class Initialized
INFO - 2023-11-03 04:15:47 --> Helper loaded: url_helper
INFO - 2023-11-03 04:15:47 --> Helper loaded: form_helper
INFO - 2023-11-03 04:15:47 --> Helper loaded: file_helper
INFO - 2023-11-03 04:15:47 --> Database Driver Class Initialized
DEBUG - 2023-11-03 04:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-03 04:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-03 04:15:47 --> Form Validation Class Initialized
INFO - 2023-11-03 04:15:47 --> Upload Class Initialized
INFO - 2023-11-03 04:15:47 --> Model "M_auth" initialized
INFO - 2023-11-03 04:15:47 --> Model "M_user" initialized
INFO - 2023-11-03 04:15:47 --> Model "M_produk" initialized
INFO - 2023-11-03 04:15:47 --> Controller Class Initialized
INFO - 2023-11-03 04:15:47 --> Model "M_pelanggan" initialized
INFO - 2023-11-03 04:15:47 --> Model "M_produk" initialized
DEBUG - 2023-11-03 04:15:47 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-03 04:15:47 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-03 04:15:47 --> Model "M_transaksi" initialized
INFO - 2023-11-03 04:15:47 --> Model "M_bank" initialized
INFO - 2023-11-03 04:15:47 --> Model "M_pesan" initialized
DEBUG - 2023-11-03 04:15:47 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
ERROR - 2023-11-03 04:15:47 --> Severity: Warning --> Attempt to read property "nama_merek" on null /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_kategori_detail.php 112
INFO - 2023-11-03 04:15:47 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-03 04:15:47 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_kategori_detail.php
INFO - 2023-11-03 04:15:47 --> Final output sent to browser
DEBUG - 2023-11-03 04:15:47 --> Total execution time: 0.0407
ERROR - 2023-11-03 09:07:16 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-03 09:07:16 --> Config Class Initialized
INFO - 2023-11-03 09:07:16 --> Hooks Class Initialized
DEBUG - 2023-11-03 09:07:16 --> UTF-8 Support Enabled
INFO - 2023-11-03 09:07:16 --> Utf8 Class Initialized
INFO - 2023-11-03 09:07:16 --> URI Class Initialized
DEBUG - 2023-11-03 09:07:16 --> No URI present. Default controller set.
INFO - 2023-11-03 09:07:16 --> Router Class Initialized
INFO - 2023-11-03 09:07:16 --> Output Class Initialized
INFO - 2023-11-03 09:07:16 --> Security Class Initialized
DEBUG - 2023-11-03 09:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-03 09:07:16 --> Input Class Initialized
INFO - 2023-11-03 09:07:16 --> Language Class Initialized
INFO - 2023-11-03 09:07:16 --> Loader Class Initialized
INFO - 2023-11-03 09:07:16 --> Helper loaded: url_helper
INFO - 2023-11-03 09:07:16 --> Helper loaded: form_helper
INFO - 2023-11-03 09:07:16 --> Helper loaded: file_helper
INFO - 2023-11-03 09:07:16 --> Database Driver Class Initialized
DEBUG - 2023-11-03 09:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-03 09:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-03 09:07:16 --> Form Validation Class Initialized
INFO - 2023-11-03 09:07:16 --> Upload Class Initialized
INFO - 2023-11-03 09:07:16 --> Model "M_auth" initialized
INFO - 2023-11-03 09:07:16 --> Model "M_user" initialized
INFO - 2023-11-03 09:07:16 --> Model "M_produk" initialized
INFO - 2023-11-03 09:07:16 --> Controller Class Initialized
INFO - 2023-11-03 09:07:16 --> Model "M_pelanggan" initialized
INFO - 2023-11-03 09:07:16 --> Model "M_produk" initialized
DEBUG - 2023-11-03 09:07:16 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-03 09:07:16 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-03 09:07:16 --> Model "M_transaksi" initialized
INFO - 2023-11-03 09:07:16 --> Model "M_bank" initialized
INFO - 2023-11-03 09:07:16 --> Model "M_pesan" initialized
DEBUG - 2023-11-03 09:07:16 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-03 09:07:16 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-03 09:07:16 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-03 09:07:16 --> Final output sent to browser
DEBUG - 2023-11-03 09:07:16 --> Total execution time: 0.0457
ERROR - 2023-11-03 09:43:27 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-03 09:43:27 --> Config Class Initialized
INFO - 2023-11-03 09:43:27 --> Hooks Class Initialized
DEBUG - 2023-11-03 09:43:27 --> UTF-8 Support Enabled
INFO - 2023-11-03 09:43:27 --> Utf8 Class Initialized
INFO - 2023-11-03 09:43:27 --> URI Class Initialized
DEBUG - 2023-11-03 09:43:27 --> No URI present. Default controller set.
INFO - 2023-11-03 09:43:27 --> Router Class Initialized
INFO - 2023-11-03 09:43:27 --> Output Class Initialized
INFO - 2023-11-03 09:43:27 --> Security Class Initialized
DEBUG - 2023-11-03 09:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-03 09:43:27 --> Input Class Initialized
INFO - 2023-11-03 09:43:27 --> Language Class Initialized
INFO - 2023-11-03 09:43:27 --> Loader Class Initialized
INFO - 2023-11-03 09:43:27 --> Helper loaded: url_helper
INFO - 2023-11-03 09:43:27 --> Helper loaded: form_helper
INFO - 2023-11-03 09:43:27 --> Helper loaded: file_helper
INFO - 2023-11-03 09:43:27 --> Database Driver Class Initialized
DEBUG - 2023-11-03 09:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-03 09:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-03 09:43:27 --> Form Validation Class Initialized
INFO - 2023-11-03 09:43:27 --> Upload Class Initialized
INFO - 2023-11-03 09:43:27 --> Model "M_auth" initialized
INFO - 2023-11-03 09:43:27 --> Model "M_user" initialized
INFO - 2023-11-03 09:43:27 --> Model "M_produk" initialized
INFO - 2023-11-03 09:43:27 --> Controller Class Initialized
INFO - 2023-11-03 09:43:27 --> Model "M_pelanggan" initialized
INFO - 2023-11-03 09:43:27 --> Model "M_produk" initialized
DEBUG - 2023-11-03 09:43:27 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-03 09:43:27 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-03 09:43:27 --> Model "M_transaksi" initialized
INFO - 2023-11-03 09:43:27 --> Model "M_bank" initialized
INFO - 2023-11-03 09:43:27 --> Model "M_pesan" initialized
DEBUG - 2023-11-03 09:43:27 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-03 09:43:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-03 09:43:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-03 09:43:27 --> Final output sent to browser
DEBUG - 2023-11-03 09:43:27 --> Total execution time: 0.0455
ERROR - 2023-11-03 10:17:58 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-03 10:17:58 --> Config Class Initialized
INFO - 2023-11-03 10:17:58 --> Hooks Class Initialized
DEBUG - 2023-11-03 10:17:58 --> UTF-8 Support Enabled
INFO - 2023-11-03 10:17:58 --> Utf8 Class Initialized
INFO - 2023-11-03 10:17:58 --> URI Class Initialized
INFO - 2023-11-03 10:17:58 --> Router Class Initialized
INFO - 2023-11-03 10:17:58 --> Output Class Initialized
INFO - 2023-11-03 10:17:58 --> Security Class Initialized
DEBUG - 2023-11-03 10:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-03 10:17:58 --> Input Class Initialized
INFO - 2023-11-03 10:17:58 --> Language Class Initialized
INFO - 2023-11-03 10:17:58 --> Loader Class Initialized
INFO - 2023-11-03 10:17:58 --> Helper loaded: url_helper
INFO - 2023-11-03 10:17:58 --> Helper loaded: form_helper
INFO - 2023-11-03 10:17:58 --> Helper loaded: file_helper
INFO - 2023-11-03 10:17:58 --> Database Driver Class Initialized
DEBUG - 2023-11-03 10:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-03 10:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-03 10:17:58 --> Form Validation Class Initialized
INFO - 2023-11-03 10:17:58 --> Upload Class Initialized
INFO - 2023-11-03 10:17:58 --> Model "M_auth" initialized
INFO - 2023-11-03 10:17:58 --> Model "M_user" initialized
INFO - 2023-11-03 10:17:58 --> Model "M_produk" initialized
INFO - 2023-11-03 10:17:58 --> Controller Class Initialized
INFO - 2023-11-03 10:17:58 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-03 10:17:58 --> Final output sent to browser
DEBUG - 2023-11-03 10:17:58 --> Total execution time: 0.0330
ERROR - 2023-11-03 12:13:49 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-03 12:13:49 --> Config Class Initialized
INFO - 2023-11-03 12:13:49 --> Hooks Class Initialized
DEBUG - 2023-11-03 12:13:49 --> UTF-8 Support Enabled
INFO - 2023-11-03 12:13:49 --> Utf8 Class Initialized
INFO - 2023-11-03 12:13:49 --> URI Class Initialized
DEBUG - 2023-11-03 12:13:49 --> No URI present. Default controller set.
INFO - 2023-11-03 12:13:49 --> Router Class Initialized
INFO - 2023-11-03 12:13:49 --> Output Class Initialized
INFO - 2023-11-03 12:13:49 --> Security Class Initialized
DEBUG - 2023-11-03 12:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-03 12:13:49 --> Input Class Initialized
INFO - 2023-11-03 12:13:49 --> Language Class Initialized
INFO - 2023-11-03 12:13:49 --> Loader Class Initialized
INFO - 2023-11-03 12:13:49 --> Helper loaded: url_helper
INFO - 2023-11-03 12:13:49 --> Helper loaded: form_helper
INFO - 2023-11-03 12:13:49 --> Helper loaded: file_helper
INFO - 2023-11-03 12:13:49 --> Database Driver Class Initialized
DEBUG - 2023-11-03 12:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-03 12:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-03 12:13:49 --> Form Validation Class Initialized
INFO - 2023-11-03 12:13:49 --> Upload Class Initialized
INFO - 2023-11-03 12:13:49 --> Model "M_auth" initialized
INFO - 2023-11-03 12:13:49 --> Model "M_user" initialized
INFO - 2023-11-03 12:13:49 --> Model "M_produk" initialized
INFO - 2023-11-03 12:13:49 --> Controller Class Initialized
INFO - 2023-11-03 12:13:49 --> Model "M_pelanggan" initialized
INFO - 2023-11-03 12:13:49 --> Model "M_produk" initialized
DEBUG - 2023-11-03 12:13:49 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-03 12:13:49 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-03 12:13:49 --> Model "M_transaksi" initialized
INFO - 2023-11-03 12:13:49 --> Model "M_bank" initialized
INFO - 2023-11-03 12:13:49 --> Model "M_pesan" initialized
DEBUG - 2023-11-03 12:13:49 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-03 12:13:49 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-03 12:13:49 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-03 12:13:49 --> Final output sent to browser
DEBUG - 2023-11-03 12:13:49 --> Total execution time: 0.0488
ERROR - 2023-11-03 15:28:50 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-03 15:28:50 --> Config Class Initialized
INFO - 2023-11-03 15:28:50 --> Hooks Class Initialized
DEBUG - 2023-11-03 15:28:50 --> UTF-8 Support Enabled
INFO - 2023-11-03 15:28:50 --> Utf8 Class Initialized
INFO - 2023-11-03 15:28:50 --> URI Class Initialized
DEBUG - 2023-11-03 15:28:50 --> No URI present. Default controller set.
INFO - 2023-11-03 15:28:50 --> Router Class Initialized
INFO - 2023-11-03 15:28:50 --> Output Class Initialized
INFO - 2023-11-03 15:28:50 --> Security Class Initialized
DEBUG - 2023-11-03 15:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-03 15:28:50 --> Input Class Initialized
INFO - 2023-11-03 15:28:50 --> Language Class Initialized
INFO - 2023-11-03 15:28:50 --> Loader Class Initialized
INFO - 2023-11-03 15:28:50 --> Helper loaded: url_helper
INFO - 2023-11-03 15:28:50 --> Helper loaded: form_helper
INFO - 2023-11-03 15:28:50 --> Helper loaded: file_helper
INFO - 2023-11-03 15:28:50 --> Database Driver Class Initialized
DEBUG - 2023-11-03 15:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-03 15:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-03 15:28:50 --> Form Validation Class Initialized
INFO - 2023-11-03 15:28:50 --> Upload Class Initialized
INFO - 2023-11-03 15:28:50 --> Model "M_auth" initialized
INFO - 2023-11-03 15:28:50 --> Model "M_user" initialized
INFO - 2023-11-03 15:28:50 --> Model "M_produk" initialized
INFO - 2023-11-03 15:28:50 --> Controller Class Initialized
INFO - 2023-11-03 15:28:50 --> Model "M_pelanggan" initialized
INFO - 2023-11-03 15:28:50 --> Model "M_produk" initialized
DEBUG - 2023-11-03 15:28:50 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-03 15:28:50 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-03 15:28:50 --> Model "M_transaksi" initialized
INFO - 2023-11-03 15:28:50 --> Model "M_bank" initialized
INFO - 2023-11-03 15:28:50 --> Model "M_pesan" initialized
DEBUG - 2023-11-03 15:28:50 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-03 15:28:50 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-03 15:28:50 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-03 15:28:50 --> Final output sent to browser
DEBUG - 2023-11-03 15:28:50 --> Total execution time: 0.0515
ERROR - 2023-11-03 16:35:47 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-03 16:35:47 --> Config Class Initialized
INFO - 2023-11-03 16:35:47 --> Hooks Class Initialized
DEBUG - 2023-11-03 16:35:47 --> UTF-8 Support Enabled
INFO - 2023-11-03 16:35:47 --> Utf8 Class Initialized
INFO - 2023-11-03 16:35:47 --> URI Class Initialized
DEBUG - 2023-11-03 16:35:47 --> No URI present. Default controller set.
INFO - 2023-11-03 16:35:47 --> Router Class Initialized
INFO - 2023-11-03 16:35:47 --> Output Class Initialized
INFO - 2023-11-03 16:35:47 --> Security Class Initialized
DEBUG - 2023-11-03 16:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-03 16:35:47 --> Input Class Initialized
INFO - 2023-11-03 16:35:47 --> Language Class Initialized
INFO - 2023-11-03 16:35:47 --> Loader Class Initialized
INFO - 2023-11-03 16:35:47 --> Helper loaded: url_helper
INFO - 2023-11-03 16:35:47 --> Helper loaded: form_helper
INFO - 2023-11-03 16:35:47 --> Helper loaded: file_helper
INFO - 2023-11-03 16:35:47 --> Database Driver Class Initialized
DEBUG - 2023-11-03 16:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-03 16:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-03 16:35:47 --> Form Validation Class Initialized
INFO - 2023-11-03 16:35:47 --> Upload Class Initialized
INFO - 2023-11-03 16:35:47 --> Model "M_auth" initialized
INFO - 2023-11-03 16:35:47 --> Model "M_user" initialized
INFO - 2023-11-03 16:35:47 --> Model "M_produk" initialized
INFO - 2023-11-03 16:35:47 --> Controller Class Initialized
INFO - 2023-11-03 16:35:47 --> Model "M_pelanggan" initialized
INFO - 2023-11-03 16:35:47 --> Model "M_produk" initialized
DEBUG - 2023-11-03 16:35:47 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-03 16:35:47 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-03 16:35:47 --> Model "M_transaksi" initialized
INFO - 2023-11-03 16:35:47 --> Model "M_bank" initialized
INFO - 2023-11-03 16:35:47 --> Model "M_pesan" initialized
DEBUG - 2023-11-03 16:35:47 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-03 16:35:47 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-03 16:35:47 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-03 16:35:47 --> Final output sent to browser
DEBUG - 2023-11-03 16:35:47 --> Total execution time: 0.0473
ERROR - 2023-11-03 16:35:48 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-03 16:35:48 --> Config Class Initialized
INFO - 2023-11-03 16:35:48 --> Hooks Class Initialized
DEBUG - 2023-11-03 16:35:48 --> UTF-8 Support Enabled
INFO - 2023-11-03 16:35:48 --> Utf8 Class Initialized
INFO - 2023-11-03 16:35:48 --> URI Class Initialized
DEBUG - 2023-11-03 16:35:48 --> No URI present. Default controller set.
INFO - 2023-11-03 16:35:48 --> Router Class Initialized
INFO - 2023-11-03 16:35:48 --> Output Class Initialized
INFO - 2023-11-03 16:35:48 --> Security Class Initialized
DEBUG - 2023-11-03 16:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-03 16:35:48 --> Input Class Initialized
INFO - 2023-11-03 16:35:48 --> Language Class Initialized
INFO - 2023-11-03 16:35:48 --> Loader Class Initialized
INFO - 2023-11-03 16:35:48 --> Helper loaded: url_helper
INFO - 2023-11-03 16:35:48 --> Helper loaded: form_helper
INFO - 2023-11-03 16:35:48 --> Helper loaded: file_helper
INFO - 2023-11-03 16:35:48 --> Database Driver Class Initialized
DEBUG - 2023-11-03 16:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-03 16:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-03 16:35:48 --> Form Validation Class Initialized
INFO - 2023-11-03 16:35:48 --> Upload Class Initialized
INFO - 2023-11-03 16:35:48 --> Model "M_auth" initialized
INFO - 2023-11-03 16:35:48 --> Model "M_user" initialized
INFO - 2023-11-03 16:35:48 --> Model "M_produk" initialized
INFO - 2023-11-03 16:35:48 --> Controller Class Initialized
INFO - 2023-11-03 16:35:48 --> Model "M_pelanggan" initialized
INFO - 2023-11-03 16:35:48 --> Model "M_produk" initialized
DEBUG - 2023-11-03 16:35:48 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-03 16:35:48 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-03 16:35:48 --> Model "M_transaksi" initialized
INFO - 2023-11-03 16:35:48 --> Model "M_bank" initialized
INFO - 2023-11-03 16:35:48 --> Model "M_pesan" initialized
DEBUG - 2023-11-03 16:35:48 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-03 16:35:48 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-03 16:35:48 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-03 16:35:48 --> Final output sent to browser
DEBUG - 2023-11-03 16:35:48 --> Total execution time: 0.0030
ERROR - 2023-11-03 19:12:04 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-03 19:12:04 --> Config Class Initialized
INFO - 2023-11-03 19:12:04 --> Hooks Class Initialized
DEBUG - 2023-11-03 19:12:04 --> UTF-8 Support Enabled
INFO - 2023-11-03 19:12:04 --> Utf8 Class Initialized
INFO - 2023-11-03 19:12:04 --> URI Class Initialized
DEBUG - 2023-11-03 19:12:04 --> No URI present. Default controller set.
INFO - 2023-11-03 19:12:04 --> Router Class Initialized
INFO - 2023-11-03 19:12:04 --> Output Class Initialized
INFO - 2023-11-03 19:12:04 --> Security Class Initialized
DEBUG - 2023-11-03 19:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-03 19:12:04 --> Input Class Initialized
INFO - 2023-11-03 19:12:04 --> Language Class Initialized
INFO - 2023-11-03 19:12:04 --> Loader Class Initialized
INFO - 2023-11-03 19:12:04 --> Helper loaded: url_helper
INFO - 2023-11-03 19:12:04 --> Helper loaded: form_helper
INFO - 2023-11-03 19:12:04 --> Helper loaded: file_helper
INFO - 2023-11-03 19:12:04 --> Database Driver Class Initialized
DEBUG - 2023-11-03 19:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-03 19:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-03 19:12:04 --> Form Validation Class Initialized
INFO - 2023-11-03 19:12:04 --> Upload Class Initialized
INFO - 2023-11-03 19:12:04 --> Model "M_auth" initialized
INFO - 2023-11-03 19:12:04 --> Model "M_user" initialized
INFO - 2023-11-03 19:12:04 --> Model "M_produk" initialized
INFO - 2023-11-03 19:12:04 --> Controller Class Initialized
INFO - 2023-11-03 19:12:04 --> Model "M_pelanggan" initialized
INFO - 2023-11-03 19:12:04 --> Model "M_produk" initialized
DEBUG - 2023-11-03 19:12:04 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-03 19:12:04 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-03 19:12:04 --> Model "M_transaksi" initialized
INFO - 2023-11-03 19:12:04 --> Model "M_bank" initialized
INFO - 2023-11-03 19:12:04 --> Model "M_pesan" initialized
DEBUG - 2023-11-03 19:12:04 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-03 19:12:04 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-03 19:12:04 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-03 19:12:04 --> Final output sent to browser
DEBUG - 2023-11-03 19:12:04 --> Total execution time: 0.0447
ERROR - 2023-11-03 21:58:12 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-03 21:58:12 --> Config Class Initialized
INFO - 2023-11-03 21:58:12 --> Hooks Class Initialized
DEBUG - 2023-11-03 21:58:12 --> UTF-8 Support Enabled
INFO - 2023-11-03 21:58:12 --> Utf8 Class Initialized
INFO - 2023-11-03 21:58:12 --> URI Class Initialized
INFO - 2023-11-03 21:58:12 --> Router Class Initialized
INFO - 2023-11-03 21:58:12 --> Output Class Initialized
INFO - 2023-11-03 21:58:12 --> Security Class Initialized
DEBUG - 2023-11-03 21:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-03 21:58:12 --> Input Class Initialized
INFO - 2023-11-03 21:58:12 --> Language Class Initialized
INFO - 2023-11-03 21:58:12 --> Loader Class Initialized
INFO - 2023-11-03 21:58:12 --> Helper loaded: url_helper
INFO - 2023-11-03 21:58:12 --> Helper loaded: form_helper
INFO - 2023-11-03 21:58:12 --> Helper loaded: file_helper
INFO - 2023-11-03 21:58:12 --> Database Driver Class Initialized
DEBUG - 2023-11-03 21:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-03 21:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-03 21:58:12 --> Form Validation Class Initialized
INFO - 2023-11-03 21:58:12 --> Upload Class Initialized
INFO - 2023-11-03 21:58:12 --> Model "M_auth" initialized
INFO - 2023-11-03 21:58:12 --> Model "M_user" initialized
INFO - 2023-11-03 21:58:12 --> Model "M_produk" initialized
INFO - 2023-11-03 21:58:12 --> Controller Class Initialized
INFO - 2023-11-03 21:58:12 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-03 21:58:12 --> Final output sent to browser
DEBUG - 2023-11-03 21:58:12 --> Total execution time: 0.0390
ERROR - 2023-11-03 21:58:12 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-03 21:58:12 --> Config Class Initialized
INFO - 2023-11-03 21:58:12 --> Hooks Class Initialized
DEBUG - 2023-11-03 21:58:12 --> UTF-8 Support Enabled
INFO - 2023-11-03 21:58:12 --> Utf8 Class Initialized
INFO - 2023-11-03 21:58:12 --> URI Class Initialized
DEBUG - 2023-11-03 21:58:12 --> No URI present. Default controller set.
INFO - 2023-11-03 21:58:12 --> Router Class Initialized
INFO - 2023-11-03 21:58:12 --> Output Class Initialized
INFO - 2023-11-03 21:58:12 --> Security Class Initialized
DEBUG - 2023-11-03 21:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-03 21:58:12 --> Input Class Initialized
INFO - 2023-11-03 21:58:12 --> Language Class Initialized
INFO - 2023-11-03 21:58:12 --> Loader Class Initialized
INFO - 2023-11-03 21:58:12 --> Helper loaded: url_helper
INFO - 2023-11-03 21:58:12 --> Helper loaded: form_helper
INFO - 2023-11-03 21:58:12 --> Helper loaded: file_helper
INFO - 2023-11-03 21:58:12 --> Database Driver Class Initialized
DEBUG - 2023-11-03 21:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-03 21:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-03 21:58:12 --> Form Validation Class Initialized
INFO - 2023-11-03 21:58:12 --> Upload Class Initialized
INFO - 2023-11-03 21:58:12 --> Model "M_auth" initialized
INFO - 2023-11-03 21:58:12 --> Model "M_user" initialized
INFO - 2023-11-03 21:58:12 --> Model "M_produk" initialized
INFO - 2023-11-03 21:58:12 --> Controller Class Initialized
INFO - 2023-11-03 21:58:12 --> Model "M_pelanggan" initialized
INFO - 2023-11-03 21:58:12 --> Model "M_produk" initialized
DEBUG - 2023-11-03 21:58:12 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-03 21:58:12 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-03 21:58:12 --> Model "M_transaksi" initialized
INFO - 2023-11-03 21:58:12 --> Model "M_bank" initialized
INFO - 2023-11-03 21:58:12 --> Model "M_pesan" initialized
DEBUG - 2023-11-03 21:58:12 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-03 21:58:12 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-03 21:58:12 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-03 21:58:12 --> Final output sent to browser
DEBUG - 2023-11-03 21:58:12 --> Total execution time: 0.0130
ERROR - 2023-11-03 22:11:54 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-03 22:11:54 --> Config Class Initialized
INFO - 2023-11-03 22:11:54 --> Hooks Class Initialized
DEBUG - 2023-11-03 22:11:54 --> UTF-8 Support Enabled
INFO - 2023-11-03 22:11:54 --> Utf8 Class Initialized
INFO - 2023-11-03 22:11:54 --> URI Class Initialized
DEBUG - 2023-11-03 22:11:54 --> No URI present. Default controller set.
INFO - 2023-11-03 22:11:54 --> Router Class Initialized
INFO - 2023-11-03 22:11:54 --> Output Class Initialized
INFO - 2023-11-03 22:11:54 --> Security Class Initialized
DEBUG - 2023-11-03 22:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-03 22:11:54 --> Input Class Initialized
INFO - 2023-11-03 22:11:54 --> Language Class Initialized
INFO - 2023-11-03 22:11:54 --> Loader Class Initialized
INFO - 2023-11-03 22:11:54 --> Helper loaded: url_helper
INFO - 2023-11-03 22:11:54 --> Helper loaded: form_helper
INFO - 2023-11-03 22:11:54 --> Helper loaded: file_helper
INFO - 2023-11-03 22:11:54 --> Database Driver Class Initialized
DEBUG - 2023-11-03 22:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-03 22:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-03 22:11:54 --> Form Validation Class Initialized
INFO - 2023-11-03 22:11:54 --> Upload Class Initialized
INFO - 2023-11-03 22:11:54 --> Model "M_auth" initialized
INFO - 2023-11-03 22:11:54 --> Model "M_user" initialized
INFO - 2023-11-03 22:11:54 --> Model "M_produk" initialized
INFO - 2023-11-03 22:11:54 --> Controller Class Initialized
INFO - 2023-11-03 22:11:54 --> Model "M_pelanggan" initialized
INFO - 2023-11-03 22:11:54 --> Model "M_produk" initialized
DEBUG - 2023-11-03 22:11:54 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-03 22:11:54 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-03 22:11:54 --> Model "M_transaksi" initialized
INFO - 2023-11-03 22:11:54 --> Model "M_bank" initialized
INFO - 2023-11-03 22:11:54 --> Model "M_pesan" initialized
DEBUG - 2023-11-03 22:11:54 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-03 22:11:54 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-03 22:11:54 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-03 22:11:54 --> Final output sent to browser
DEBUG - 2023-11-03 22:11:54 --> Total execution time: 0.0392
ERROR - 2023-11-03 23:11:48 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-03 23:11:48 --> Config Class Initialized
INFO - 2023-11-03 23:11:48 --> Hooks Class Initialized
DEBUG - 2023-11-03 23:11:48 --> UTF-8 Support Enabled
INFO - 2023-11-03 23:11:48 --> Utf8 Class Initialized
INFO - 2023-11-03 23:11:48 --> URI Class Initialized
INFO - 2023-11-03 23:11:48 --> Router Class Initialized
INFO - 2023-11-03 23:11:48 --> Output Class Initialized
INFO - 2023-11-03 23:11:48 --> Security Class Initialized
DEBUG - 2023-11-03 23:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-03 23:11:48 --> Input Class Initialized
INFO - 2023-11-03 23:11:48 --> Language Class Initialized
INFO - 2023-11-03 23:11:48 --> Loader Class Initialized
INFO - 2023-11-03 23:11:48 --> Helper loaded: url_helper
INFO - 2023-11-03 23:11:48 --> Helper loaded: form_helper
INFO - 2023-11-03 23:11:48 --> Helper loaded: file_helper
INFO - 2023-11-03 23:11:48 --> Database Driver Class Initialized
DEBUG - 2023-11-03 23:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-03 23:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-03 23:11:48 --> Form Validation Class Initialized
INFO - 2023-11-03 23:11:48 --> Upload Class Initialized
INFO - 2023-11-03 23:11:48 --> Model "M_auth" initialized
INFO - 2023-11-03 23:11:48 --> Model "M_user" initialized
INFO - 2023-11-03 23:11:48 --> Model "M_produk" initialized
INFO - 2023-11-03 23:11:48 --> Controller Class Initialized
INFO - 2023-11-03 23:11:48 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-03 23:11:48 --> Final output sent to browser
DEBUG - 2023-11-03 23:11:48 --> Total execution time: 0.0362
ERROR - 2023-11-03 23:11:50 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-03 23:11:50 --> Config Class Initialized
INFO - 2023-11-03 23:11:50 --> Hooks Class Initialized
DEBUG - 2023-11-03 23:11:50 --> UTF-8 Support Enabled
INFO - 2023-11-03 23:11:50 --> Utf8 Class Initialized
INFO - 2023-11-03 23:11:50 --> URI Class Initialized
DEBUG - 2023-11-03 23:11:50 --> No URI present. Default controller set.
INFO - 2023-11-03 23:11:50 --> Router Class Initialized
INFO - 2023-11-03 23:11:50 --> Output Class Initialized
INFO - 2023-11-03 23:11:50 --> Security Class Initialized
DEBUG - 2023-11-03 23:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-03 23:11:50 --> Input Class Initialized
INFO - 2023-11-03 23:11:50 --> Language Class Initialized
INFO - 2023-11-03 23:11:50 --> Loader Class Initialized
INFO - 2023-11-03 23:11:50 --> Helper loaded: url_helper
INFO - 2023-11-03 23:11:50 --> Helper loaded: form_helper
INFO - 2023-11-03 23:11:50 --> Helper loaded: file_helper
INFO - 2023-11-03 23:11:50 --> Database Driver Class Initialized
DEBUG - 2023-11-03 23:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-03 23:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-03 23:11:50 --> Form Validation Class Initialized
INFO - 2023-11-03 23:11:50 --> Upload Class Initialized
INFO - 2023-11-03 23:11:50 --> Model "M_auth" initialized
INFO - 2023-11-03 23:11:50 --> Model "M_user" initialized
INFO - 2023-11-03 23:11:50 --> Model "M_produk" initialized
INFO - 2023-11-03 23:11:50 --> Controller Class Initialized
INFO - 2023-11-03 23:11:50 --> Model "M_pelanggan" initialized
INFO - 2023-11-03 23:11:50 --> Model "M_produk" initialized
DEBUG - 2023-11-03 23:11:50 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-03 23:11:50 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-03 23:11:50 --> Model "M_transaksi" initialized
INFO - 2023-11-03 23:11:50 --> Model "M_bank" initialized
INFO - 2023-11-03 23:11:50 --> Model "M_pesan" initialized
DEBUG - 2023-11-03 23:11:50 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-03 23:11:50 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-03 23:11:50 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-03 23:11:50 --> Final output sent to browser
DEBUG - 2023-11-03 23:11:50 --> Total execution time: 0.0131
ERROR - 2023-11-03 23:53:41 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-03 23:53:41 --> Config Class Initialized
INFO - 2023-11-03 23:53:41 --> Hooks Class Initialized
DEBUG - 2023-11-03 23:53:41 --> UTF-8 Support Enabled
INFO - 2023-11-03 23:53:41 --> Utf8 Class Initialized
INFO - 2023-11-03 23:53:41 --> URI Class Initialized
INFO - 2023-11-03 23:53:41 --> Router Class Initialized
INFO - 2023-11-03 23:53:41 --> Output Class Initialized
INFO - 2023-11-03 23:53:41 --> Security Class Initialized
DEBUG - 2023-11-03 23:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-03 23:53:41 --> Input Class Initialized
INFO - 2023-11-03 23:53:41 --> Language Class Initialized
INFO - 2023-11-03 23:53:41 --> Loader Class Initialized
INFO - 2023-11-03 23:53:41 --> Helper loaded: url_helper
INFO - 2023-11-03 23:53:41 --> Helper loaded: form_helper
INFO - 2023-11-03 23:53:41 --> Helper loaded: file_helper
INFO - 2023-11-03 23:53:41 --> Database Driver Class Initialized
DEBUG - 2023-11-03 23:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-03 23:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-03 23:53:41 --> Form Validation Class Initialized
INFO - 2023-11-03 23:53:41 --> Upload Class Initialized
INFO - 2023-11-03 23:53:41 --> Model "M_auth" initialized
INFO - 2023-11-03 23:53:41 --> Model "M_user" initialized
INFO - 2023-11-03 23:53:41 --> Model "M_produk" initialized
INFO - 2023-11-03 23:53:41 --> Controller Class Initialized
INFO - 2023-11-03 23:53:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-03 23:53:41 --> Final output sent to browser
DEBUG - 2023-11-03 23:53:41 --> Total execution time: 0.0326
ERROR - 2023-11-03 23:53:43 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-03 23:53:43 --> Config Class Initialized
INFO - 2023-11-03 23:53:43 --> Hooks Class Initialized
DEBUG - 2023-11-03 23:53:43 --> UTF-8 Support Enabled
INFO - 2023-11-03 23:53:43 --> Utf8 Class Initialized
INFO - 2023-11-03 23:53:43 --> URI Class Initialized
DEBUG - 2023-11-03 23:53:43 --> No URI present. Default controller set.
INFO - 2023-11-03 23:53:43 --> Router Class Initialized
INFO - 2023-11-03 23:53:43 --> Output Class Initialized
INFO - 2023-11-03 23:53:43 --> Security Class Initialized
DEBUG - 2023-11-03 23:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-03 23:53:43 --> Input Class Initialized
INFO - 2023-11-03 23:53:43 --> Language Class Initialized
INFO - 2023-11-03 23:53:43 --> Loader Class Initialized
INFO - 2023-11-03 23:53:43 --> Helper loaded: url_helper
INFO - 2023-11-03 23:53:43 --> Helper loaded: form_helper
INFO - 2023-11-03 23:53:43 --> Helper loaded: file_helper
INFO - 2023-11-03 23:53:43 --> Database Driver Class Initialized
DEBUG - 2023-11-03 23:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-03 23:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-03 23:53:43 --> Form Validation Class Initialized
INFO - 2023-11-03 23:53:43 --> Upload Class Initialized
INFO - 2023-11-03 23:53:43 --> Model "M_auth" initialized
INFO - 2023-11-03 23:53:43 --> Model "M_user" initialized
INFO - 2023-11-03 23:53:43 --> Model "M_produk" initialized
INFO - 2023-11-03 23:53:43 --> Controller Class Initialized
INFO - 2023-11-03 23:53:43 --> Model "M_pelanggan" initialized
INFO - 2023-11-03 23:53:43 --> Model "M_produk" initialized
DEBUG - 2023-11-03 23:53:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-03 23:53:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-03 23:53:43 --> Model "M_transaksi" initialized
INFO - 2023-11-03 23:53:43 --> Model "M_bank" initialized
INFO - 2023-11-03 23:53:43 --> Model "M_pesan" initialized
DEBUG - 2023-11-03 23:53:43 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-03 23:53:43 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-03 23:53:43 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-03 23:53:43 --> Final output sent to browser
DEBUG - 2023-11-03 23:53:43 --> Total execution time: 0.0100
