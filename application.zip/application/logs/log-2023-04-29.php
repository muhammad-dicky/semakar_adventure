<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-04-29 14:23:14 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 14:23:21 --> Config Class Initialized
INFO - 2023-04-29 14:23:21 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:23:21 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:23:21 --> Utf8 Class Initialized
INFO - 2023-04-29 14:23:21 --> URI Class Initialized
INFO - 2023-04-29 14:23:21 --> Router Class Initialized
INFO - 2023-04-29 14:23:21 --> Output Class Initialized
INFO - 2023-04-29 14:23:21 --> Security Class Initialized
DEBUG - 2023-04-29 14:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:23:21 --> Input Class Initialized
INFO - 2023-04-29 14:23:21 --> Language Class Initialized
INFO - 2023-04-29 14:23:21 --> Loader Class Initialized
INFO - 2023-04-29 14:23:21 --> Helper loaded: url_helper
INFO - 2023-04-29 14:23:21 --> Helper loaded: form_helper
INFO - 2023-04-29 14:23:21 --> Helper loaded: file_helper
INFO - 2023-04-29 14:23:21 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:23:21 --> Form Validation Class Initialized
INFO - 2023-04-29 14:23:21 --> Upload Class Initialized
INFO - 2023-04-29 14:23:21 --> Model "M_auth" initialized
INFO - 2023-04-29 14:23:21 --> Model "M_user" initialized
INFO - 2023-04-29 14:23:21 --> Model "M_produk" initialized
INFO - 2023-04-29 14:23:21 --> Controller Class Initialized
INFO - 2023-04-29 14:23:21 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 14:23:21 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:23:21 --> Final output sent to browser
DEBUG - 2023-04-29 14:23:21 --> Total execution time: 0.1579
INFO - 2023-04-29 14:23:23 --> Config Class Initialized
INFO - 2023-04-29 14:23:23 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:23:23 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:23:23 --> Utf8 Class Initialized
INFO - 2023-04-29 14:23:23 --> URI Class Initialized
INFO - 2023-04-29 14:23:23 --> Router Class Initialized
INFO - 2023-04-29 14:23:23 --> Output Class Initialized
INFO - 2023-04-29 14:23:23 --> Security Class Initialized
DEBUG - 2023-04-29 14:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:23:23 --> Input Class Initialized
INFO - 2023-04-29 14:23:23 --> Language Class Initialized
INFO - 2023-04-29 14:23:23 --> Loader Class Initialized
INFO - 2023-04-29 14:23:23 --> Helper loaded: url_helper
INFO - 2023-04-29 14:23:23 --> Helper loaded: form_helper
INFO - 2023-04-29 14:23:23 --> Helper loaded: file_helper
INFO - 2023-04-29 14:23:23 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:23:23 --> Form Validation Class Initialized
INFO - 2023-04-29 14:23:23 --> Upload Class Initialized
INFO - 2023-04-29 14:23:23 --> Model "M_auth" initialized
INFO - 2023-04-29 14:23:23 --> Model "M_user" initialized
INFO - 2023-04-29 14:23:23 --> Model "M_produk" initialized
INFO - 2023-04-29 14:23:23 --> Controller Class Initialized
INFO - 2023-04-29 14:23:23 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 14:23:23 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:23:23 --> Final output sent to browser
DEBUG - 2023-04-29 14:23:23 --> Total execution time: 0.1320
INFO - 2023-04-29 14:23:26 --> Config Class Initialized
INFO - 2023-04-29 14:23:26 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:23:26 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:23:26 --> Utf8 Class Initialized
INFO - 2023-04-29 14:23:26 --> URI Class Initialized
INFO - 2023-04-29 14:23:26 --> Router Class Initialized
INFO - 2023-04-29 14:23:26 --> Output Class Initialized
INFO - 2023-04-29 14:23:26 --> Security Class Initialized
DEBUG - 2023-04-29 14:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:23:26 --> Input Class Initialized
INFO - 2023-04-29 14:23:26 --> Language Class Initialized
INFO - 2023-04-29 14:23:26 --> Loader Class Initialized
INFO - 2023-04-29 14:23:26 --> Helper loaded: url_helper
INFO - 2023-04-29 14:23:26 --> Helper loaded: form_helper
INFO - 2023-04-29 14:23:26 --> Helper loaded: file_helper
INFO - 2023-04-29 14:23:26 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:23:26 --> Form Validation Class Initialized
INFO - 2023-04-29 14:23:26 --> Upload Class Initialized
INFO - 2023-04-29 14:23:26 --> Model "M_auth" initialized
INFO - 2023-04-29 14:23:26 --> Model "M_user" initialized
INFO - 2023-04-29 14:23:26 --> Model "M_produk" initialized
INFO - 2023-04-29 14:23:26 --> Controller Class Initialized
INFO - 2023-04-29 14:23:26 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_user_profile.php
INFO - 2023-04-29 14:23:26 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:23:26 --> Final output sent to browser
DEBUG - 2023-04-29 14:23:26 --> Total execution time: 0.1033
INFO - 2023-04-29 14:23:28 --> Config Class Initialized
INFO - 2023-04-29 14:23:28 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:23:28 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:23:28 --> Utf8 Class Initialized
INFO - 2023-04-29 14:23:28 --> URI Class Initialized
INFO - 2023-04-29 14:23:28 --> Router Class Initialized
INFO - 2023-04-29 14:23:28 --> Output Class Initialized
INFO - 2023-04-29 14:23:28 --> Security Class Initialized
DEBUG - 2023-04-29 14:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:23:28 --> Input Class Initialized
INFO - 2023-04-29 14:23:28 --> Language Class Initialized
INFO - 2023-04-29 14:23:28 --> Loader Class Initialized
INFO - 2023-04-29 14:23:28 --> Helper loaded: url_helper
INFO - 2023-04-29 14:23:28 --> Helper loaded: form_helper
INFO - 2023-04-29 14:23:28 --> Helper loaded: file_helper
INFO - 2023-04-29 14:23:28 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:23:28 --> Form Validation Class Initialized
INFO - 2023-04-29 14:23:28 --> Upload Class Initialized
INFO - 2023-04-29 14:23:28 --> Model "M_auth" initialized
INFO - 2023-04-29 14:23:28 --> Model "M_user" initialized
INFO - 2023-04-29 14:23:28 --> Model "M_produk" initialized
INFO - 2023-04-29 14:23:28 --> Controller Class Initialized
INFO - 2023-04-29 14:23:28 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:23:28 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:23:28 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:23:28 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:23:28 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:23:28 --> Model "M_bank" initialized
INFO - 2023-04-29 14:23:28 --> Model "M_pesan" initialized
ERROR - 2023-04-29 14:23:28 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 14:23:28 --> Config Class Initialized
INFO - 2023-04-29 14:23:28 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:23:28 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:23:28 --> Utf8 Class Initialized
INFO - 2023-04-29 14:23:28 --> URI Class Initialized
INFO - 2023-04-29 14:23:28 --> Router Class Initialized
INFO - 2023-04-29 14:23:28 --> Output Class Initialized
INFO - 2023-04-29 14:23:28 --> Security Class Initialized
DEBUG - 2023-04-29 14:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:23:28 --> Input Class Initialized
INFO - 2023-04-29 14:23:28 --> Language Class Initialized
INFO - 2023-04-29 14:23:28 --> Loader Class Initialized
INFO - 2023-04-29 14:23:28 --> Helper loaded: url_helper
INFO - 2023-04-29 14:23:28 --> Helper loaded: form_helper
INFO - 2023-04-29 14:23:28 --> Helper loaded: file_helper
INFO - 2023-04-29 14:23:28 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:23:28 --> Form Validation Class Initialized
INFO - 2023-04-29 14:23:28 --> Upload Class Initialized
INFO - 2023-04-29 14:23:28 --> Model "M_auth" initialized
INFO - 2023-04-29 14:23:28 --> Model "M_user" initialized
INFO - 2023-04-29 14:23:28 --> Model "M_produk" initialized
INFO - 2023-04-29 14:23:28 --> Controller Class Initialized
INFO - 2023-04-29 14:23:28 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/not_found.php
INFO - 2023-04-29 14:23:28 --> Final output sent to browser
DEBUG - 2023-04-29 14:23:28 --> Total execution time: 0.1527
INFO - 2023-04-29 14:23:49 --> Config Class Initialized
INFO - 2023-04-29 14:23:49 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:23:49 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:23:49 --> Utf8 Class Initialized
INFO - 2023-04-29 14:23:49 --> URI Class Initialized
INFO - 2023-04-29 14:23:49 --> Router Class Initialized
INFO - 2023-04-29 14:23:49 --> Output Class Initialized
INFO - 2023-04-29 14:23:49 --> Security Class Initialized
DEBUG - 2023-04-29 14:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:23:49 --> Input Class Initialized
INFO - 2023-04-29 14:23:49 --> Language Class Initialized
INFO - 2023-04-29 14:23:49 --> Loader Class Initialized
INFO - 2023-04-29 14:23:49 --> Helper loaded: url_helper
INFO - 2023-04-29 14:23:49 --> Helper loaded: form_helper
INFO - 2023-04-29 14:23:49 --> Helper loaded: file_helper
INFO - 2023-04-29 14:23:49 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:23:49 --> Form Validation Class Initialized
INFO - 2023-04-29 14:23:49 --> Upload Class Initialized
INFO - 2023-04-29 14:23:49 --> Model "M_auth" initialized
INFO - 2023-04-29 14:23:49 --> Model "M_user" initialized
INFO - 2023-04-29 14:23:49 --> Model "M_produk" initialized
INFO - 2023-04-29 14:23:49 --> Controller Class Initialized
INFO - 2023-04-29 14:23:49 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_user_profile.php
INFO - 2023-04-29 14:23:49 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:23:49 --> Final output sent to browser
DEBUG - 2023-04-29 14:23:49 --> Total execution time: 0.1194
INFO - 2023-04-29 14:23:57 --> Config Class Initialized
INFO - 2023-04-29 14:23:57 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:23:57 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:23:57 --> Utf8 Class Initialized
INFO - 2023-04-29 14:23:57 --> URI Class Initialized
INFO - 2023-04-29 14:23:57 --> Router Class Initialized
INFO - 2023-04-29 14:23:57 --> Output Class Initialized
INFO - 2023-04-29 14:23:57 --> Security Class Initialized
DEBUG - 2023-04-29 14:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:23:57 --> Input Class Initialized
INFO - 2023-04-29 14:23:57 --> Language Class Initialized
INFO - 2023-04-29 14:23:57 --> Loader Class Initialized
INFO - 2023-04-29 14:23:57 --> Helper loaded: url_helper
INFO - 2023-04-29 14:23:57 --> Helper loaded: form_helper
INFO - 2023-04-29 14:23:57 --> Helper loaded: file_helper
INFO - 2023-04-29 14:23:57 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:23:57 --> Form Validation Class Initialized
INFO - 2023-04-29 14:23:57 --> Upload Class Initialized
INFO - 2023-04-29 14:23:57 --> Model "M_auth" initialized
INFO - 2023-04-29 14:23:57 --> Model "M_user" initialized
INFO - 2023-04-29 14:23:57 --> Model "M_produk" initialized
INFO - 2023-04-29 14:23:57 --> Controller Class Initialized
INFO - 2023-04-29 14:23:57 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:23:57 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:23:57 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:23:57 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:23:57 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:23:57 --> Model "M_bank" initialized
INFO - 2023-04-29 14:23:57 --> Model "M_pesan" initialized
ERROR - 2023-04-29 14:23:57 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 14:23:57 --> Config Class Initialized
INFO - 2023-04-29 14:23:57 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:23:57 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:23:57 --> Utf8 Class Initialized
INFO - 2023-04-29 14:23:57 --> URI Class Initialized
INFO - 2023-04-29 14:23:57 --> Router Class Initialized
INFO - 2023-04-29 14:23:57 --> Output Class Initialized
INFO - 2023-04-29 14:23:57 --> Security Class Initialized
DEBUG - 2023-04-29 14:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:23:57 --> Input Class Initialized
INFO - 2023-04-29 14:23:57 --> Language Class Initialized
INFO - 2023-04-29 14:23:57 --> Loader Class Initialized
INFO - 2023-04-29 14:23:57 --> Helper loaded: url_helper
INFO - 2023-04-29 14:23:57 --> Helper loaded: form_helper
INFO - 2023-04-29 14:23:57 --> Helper loaded: file_helper
INFO - 2023-04-29 14:23:57 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:23:57 --> Form Validation Class Initialized
INFO - 2023-04-29 14:23:57 --> Upload Class Initialized
INFO - 2023-04-29 14:23:57 --> Model "M_auth" initialized
INFO - 2023-04-29 14:23:57 --> Model "M_user" initialized
INFO - 2023-04-29 14:23:57 --> Model "M_produk" initialized
INFO - 2023-04-29 14:23:57 --> Controller Class Initialized
INFO - 2023-04-29 14:23:57 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/not_found.php
INFO - 2023-04-29 14:23:57 --> Final output sent to browser
DEBUG - 2023-04-29 14:23:57 --> Total execution time: 0.1002
INFO - 2023-04-29 14:24:30 --> Config Class Initialized
INFO - 2023-04-29 14:24:30 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:24:30 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:24:30 --> Utf8 Class Initialized
INFO - 2023-04-29 14:24:30 --> URI Class Initialized
INFO - 2023-04-29 14:24:30 --> Router Class Initialized
INFO - 2023-04-29 14:24:30 --> Output Class Initialized
INFO - 2023-04-29 14:24:30 --> Security Class Initialized
DEBUG - 2023-04-29 14:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:24:30 --> Input Class Initialized
INFO - 2023-04-29 14:24:30 --> Language Class Initialized
INFO - 2023-04-29 14:24:30 --> Loader Class Initialized
INFO - 2023-04-29 14:24:30 --> Helper loaded: url_helper
INFO - 2023-04-29 14:24:30 --> Helper loaded: form_helper
INFO - 2023-04-29 14:24:30 --> Helper loaded: file_helper
INFO - 2023-04-29 14:24:30 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:24:30 --> Form Validation Class Initialized
INFO - 2023-04-29 14:24:30 --> Upload Class Initialized
INFO - 2023-04-29 14:24:30 --> Model "M_auth" initialized
INFO - 2023-04-29 14:24:30 --> Model "M_user" initialized
INFO - 2023-04-29 14:24:30 --> Model "M_produk" initialized
INFO - 2023-04-29 14:24:30 --> Controller Class Initialized
INFO - 2023-04-29 14:24:30 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_user_profile.php
INFO - 2023-04-29 14:24:30 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:24:30 --> Final output sent to browser
DEBUG - 2023-04-29 14:24:30 --> Total execution time: 0.1349
INFO - 2023-04-29 14:24:36 --> Config Class Initialized
INFO - 2023-04-29 14:24:36 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:24:36 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:24:36 --> Utf8 Class Initialized
INFO - 2023-04-29 14:24:36 --> URI Class Initialized
INFO - 2023-04-29 14:24:36 --> Router Class Initialized
INFO - 2023-04-29 14:24:36 --> Output Class Initialized
INFO - 2023-04-29 14:24:36 --> Security Class Initialized
DEBUG - 2023-04-29 14:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:24:36 --> Input Class Initialized
INFO - 2023-04-29 14:24:36 --> Language Class Initialized
INFO - 2023-04-29 14:24:36 --> Loader Class Initialized
INFO - 2023-04-29 14:24:36 --> Helper loaded: url_helper
INFO - 2023-04-29 14:24:36 --> Helper loaded: form_helper
INFO - 2023-04-29 14:24:36 --> Helper loaded: file_helper
INFO - 2023-04-29 14:24:36 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:24:36 --> Form Validation Class Initialized
INFO - 2023-04-29 14:24:36 --> Upload Class Initialized
INFO - 2023-04-29 14:24:36 --> Model "M_auth" initialized
INFO - 2023-04-29 14:24:36 --> Model "M_user" initialized
INFO - 2023-04-29 14:24:36 --> Model "M_produk" initialized
INFO - 2023-04-29 14:24:36 --> Controller Class Initialized
INFO - 2023-04-29 14:24:36 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_ganti_password.php
INFO - 2023-04-29 14:24:36 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:24:36 --> Final output sent to browser
DEBUG - 2023-04-29 14:24:36 --> Total execution time: 0.1219
INFO - 2023-04-29 14:24:51 --> Config Class Initialized
INFO - 2023-04-29 14:24:51 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:24:51 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:24:51 --> Utf8 Class Initialized
INFO - 2023-04-29 14:24:51 --> URI Class Initialized
INFO - 2023-04-29 14:24:51 --> Router Class Initialized
INFO - 2023-04-29 14:24:51 --> Output Class Initialized
INFO - 2023-04-29 14:24:51 --> Security Class Initialized
DEBUG - 2023-04-29 14:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:24:51 --> Input Class Initialized
INFO - 2023-04-29 14:24:51 --> Language Class Initialized
INFO - 2023-04-29 14:24:51 --> Loader Class Initialized
INFO - 2023-04-29 14:24:51 --> Helper loaded: url_helper
INFO - 2023-04-29 14:24:51 --> Helper loaded: form_helper
INFO - 2023-04-29 14:24:51 --> Helper loaded: file_helper
INFO - 2023-04-29 14:24:51 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:24:51 --> Form Validation Class Initialized
INFO - 2023-04-29 14:24:51 --> Upload Class Initialized
INFO - 2023-04-29 14:24:51 --> Model "M_auth" initialized
INFO - 2023-04-29 14:24:51 --> Model "M_user" initialized
INFO - 2023-04-29 14:24:51 --> Model "M_produk" initialized
INFO - 2023-04-29 14:24:51 --> Controller Class Initialized
INFO - 2023-04-29 14:24:51 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:24:51 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_pelanggan.php
INFO - 2023-04-29 14:24:51 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:24:51 --> Final output sent to browser
DEBUG - 2023-04-29 14:24:51 --> Total execution time: 0.1128
INFO - 2023-04-29 14:24:55 --> Config Class Initialized
INFO - 2023-04-29 14:24:55 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:24:55 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:24:55 --> Utf8 Class Initialized
INFO - 2023-04-29 14:24:55 --> URI Class Initialized
INFO - 2023-04-29 14:24:55 --> Router Class Initialized
INFO - 2023-04-29 14:24:55 --> Output Class Initialized
INFO - 2023-04-29 14:24:55 --> Security Class Initialized
DEBUG - 2023-04-29 14:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:24:55 --> Input Class Initialized
INFO - 2023-04-29 14:24:55 --> Language Class Initialized
INFO - 2023-04-29 14:24:55 --> Loader Class Initialized
INFO - 2023-04-29 14:24:55 --> Helper loaded: url_helper
INFO - 2023-04-29 14:24:55 --> Helper loaded: form_helper
INFO - 2023-04-29 14:24:55 --> Helper loaded: file_helper
INFO - 2023-04-29 14:24:55 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:24:55 --> Form Validation Class Initialized
INFO - 2023-04-29 14:24:55 --> Upload Class Initialized
INFO - 2023-04-29 14:24:55 --> Model "M_auth" initialized
INFO - 2023-04-29 14:24:55 --> Model "M_user" initialized
INFO - 2023-04-29 14:24:55 --> Model "M_produk" initialized
INFO - 2023-04-29 14:24:55 --> Controller Class Initialized
INFO - 2023-04-29 14:24:55 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_ganti_password.php
INFO - 2023-04-29 14:24:55 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:24:55 --> Final output sent to browser
DEBUG - 2023-04-29 14:24:55 --> Total execution time: 0.1240
INFO - 2023-04-29 14:25:08 --> Config Class Initialized
INFO - 2023-04-29 14:25:08 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:25:08 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:25:08 --> Utf8 Class Initialized
INFO - 2023-04-29 14:25:08 --> URI Class Initialized
INFO - 2023-04-29 14:25:08 --> Router Class Initialized
INFO - 2023-04-29 14:25:08 --> Output Class Initialized
INFO - 2023-04-29 14:25:08 --> Security Class Initialized
DEBUG - 2023-04-29 14:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:25:08 --> Input Class Initialized
INFO - 2023-04-29 14:25:08 --> Language Class Initialized
INFO - 2023-04-29 14:25:08 --> Loader Class Initialized
INFO - 2023-04-29 14:25:08 --> Helper loaded: url_helper
INFO - 2023-04-29 14:25:08 --> Helper loaded: form_helper
INFO - 2023-04-29 14:25:08 --> Helper loaded: file_helper
INFO - 2023-04-29 14:25:08 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:25:08 --> Form Validation Class Initialized
INFO - 2023-04-29 14:25:08 --> Upload Class Initialized
INFO - 2023-04-29 14:25:08 --> Model "M_auth" initialized
INFO - 2023-04-29 14:25:08 --> Model "M_user" initialized
INFO - 2023-04-29 14:25:08 --> Model "M_produk" initialized
INFO - 2023-04-29 14:25:08 --> Controller Class Initialized
INFO - 2023-04-29 14:25:08 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_user.php
INFO - 2023-04-29 14:25:08 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:25:08 --> Final output sent to browser
DEBUG - 2023-04-29 14:25:08 --> Total execution time: 0.1108
INFO - 2023-04-29 14:25:17 --> Config Class Initialized
INFO - 2023-04-29 14:25:17 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:25:17 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:25:17 --> Utf8 Class Initialized
INFO - 2023-04-29 14:25:17 --> URI Class Initialized
INFO - 2023-04-29 14:25:17 --> Router Class Initialized
INFO - 2023-04-29 14:25:17 --> Output Class Initialized
INFO - 2023-04-29 14:25:17 --> Security Class Initialized
DEBUG - 2023-04-29 14:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:25:17 --> Input Class Initialized
INFO - 2023-04-29 14:25:17 --> Language Class Initialized
INFO - 2023-04-29 14:25:17 --> Loader Class Initialized
INFO - 2023-04-29 14:25:17 --> Helper loaded: url_helper
INFO - 2023-04-29 14:25:17 --> Helper loaded: form_helper
INFO - 2023-04-29 14:25:17 --> Helper loaded: file_helper
INFO - 2023-04-29 14:25:17 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:25:17 --> Form Validation Class Initialized
INFO - 2023-04-29 14:25:17 --> Upload Class Initialized
INFO - 2023-04-29 14:25:17 --> Model "M_auth" initialized
INFO - 2023-04-29 14:25:17 --> Model "M_user" initialized
INFO - 2023-04-29 14:25:17 --> Model "M_produk" initialized
INFO - 2023-04-29 14:25:17 --> Controller Class Initialized
INFO - 2023-04-29 14:25:17 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:25:17 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:25:17 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:25:17 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:25:17 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:25:17 --> Model "M_bank" initialized
INFO - 2023-04-29 14:25:17 --> Model "M_pesan" initialized
ERROR - 2023-04-29 14:25:17 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 14:25:17 --> Config Class Initialized
INFO - 2023-04-29 14:25:17 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:25:17 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:25:17 --> Utf8 Class Initialized
INFO - 2023-04-29 14:25:17 --> URI Class Initialized
INFO - 2023-04-29 14:25:17 --> Router Class Initialized
INFO - 2023-04-29 14:25:17 --> Output Class Initialized
INFO - 2023-04-29 14:25:17 --> Security Class Initialized
DEBUG - 2023-04-29 14:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:25:17 --> Input Class Initialized
INFO - 2023-04-29 14:25:17 --> Language Class Initialized
INFO - 2023-04-29 14:25:17 --> Loader Class Initialized
INFO - 2023-04-29 14:25:17 --> Helper loaded: url_helper
INFO - 2023-04-29 14:25:17 --> Helper loaded: form_helper
INFO - 2023-04-29 14:25:17 --> Helper loaded: file_helper
INFO - 2023-04-29 14:25:17 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:25:17 --> Form Validation Class Initialized
INFO - 2023-04-29 14:25:17 --> Upload Class Initialized
INFO - 2023-04-29 14:25:17 --> Model "M_auth" initialized
INFO - 2023-04-29 14:25:17 --> Model "M_user" initialized
INFO - 2023-04-29 14:25:17 --> Model "M_produk" initialized
INFO - 2023-04-29 14:25:17 --> Controller Class Initialized
INFO - 2023-04-29 14:25:17 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/not_found.php
INFO - 2023-04-29 14:25:17 --> Final output sent to browser
DEBUG - 2023-04-29 14:25:17 --> Total execution time: 0.0976
INFO - 2023-04-29 14:25:49 --> Config Class Initialized
INFO - 2023-04-29 14:25:49 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:25:49 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:25:49 --> Utf8 Class Initialized
INFO - 2023-04-29 14:25:49 --> URI Class Initialized
INFO - 2023-04-29 14:25:49 --> Router Class Initialized
INFO - 2023-04-29 14:25:49 --> Output Class Initialized
INFO - 2023-04-29 14:25:49 --> Security Class Initialized
DEBUG - 2023-04-29 14:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:25:49 --> Input Class Initialized
INFO - 2023-04-29 14:25:49 --> Language Class Initialized
INFO - 2023-04-29 14:25:49 --> Loader Class Initialized
INFO - 2023-04-29 14:25:49 --> Helper loaded: url_helper
INFO - 2023-04-29 14:25:49 --> Helper loaded: form_helper
INFO - 2023-04-29 14:25:49 --> Helper loaded: file_helper
INFO - 2023-04-29 14:25:49 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:25:49 --> Form Validation Class Initialized
INFO - 2023-04-29 14:25:49 --> Upload Class Initialized
INFO - 2023-04-29 14:25:49 --> Model "M_auth" initialized
INFO - 2023-04-29 14:25:50 --> Model "M_user" initialized
INFO - 2023-04-29 14:25:50 --> Model "M_produk" initialized
INFO - 2023-04-29 14:25:50 --> Controller Class Initialized
INFO - 2023-04-29 14:25:50 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_user.php
INFO - 2023-04-29 14:25:50 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:25:50 --> Final output sent to browser
DEBUG - 2023-04-29 14:25:50 --> Total execution time: 0.1959
INFO - 2023-04-29 14:28:15 --> Config Class Initialized
INFO - 2023-04-29 14:28:15 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:28:15 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:28:15 --> Utf8 Class Initialized
INFO - 2023-04-29 14:28:15 --> URI Class Initialized
INFO - 2023-04-29 14:28:15 --> Router Class Initialized
INFO - 2023-04-29 14:28:15 --> Output Class Initialized
INFO - 2023-04-29 14:28:15 --> Security Class Initialized
DEBUG - 2023-04-29 14:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:28:15 --> Input Class Initialized
INFO - 2023-04-29 14:28:15 --> Language Class Initialized
INFO - 2023-04-29 14:28:15 --> Loader Class Initialized
INFO - 2023-04-29 14:28:15 --> Helper loaded: url_helper
INFO - 2023-04-29 14:28:15 --> Helper loaded: form_helper
INFO - 2023-04-29 14:28:15 --> Helper loaded: file_helper
INFO - 2023-04-29 14:28:15 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:28:15 --> Form Validation Class Initialized
INFO - 2023-04-29 14:28:16 --> Upload Class Initialized
INFO - 2023-04-29 14:28:16 --> Model "M_auth" initialized
INFO - 2023-04-29 14:28:16 --> Model "M_user" initialized
INFO - 2023-04-29 14:28:16 --> Model "M_produk" initialized
INFO - 2023-04-29 14:28:16 --> Controller Class Initialized
INFO - 2023-04-29 14:28:16 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:28:16 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:28:16 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:28:16 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:28:16 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:28:16 --> Model "M_bank" initialized
INFO - 2023-04-29 14:28:16 --> Model "M_pesan" initialized
ERROR - 2023-04-29 14:28:16 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 14:28:16 --> Config Class Initialized
INFO - 2023-04-29 14:28:16 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:28:16 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:28:16 --> Utf8 Class Initialized
INFO - 2023-04-29 14:28:16 --> URI Class Initialized
INFO - 2023-04-29 14:28:16 --> Router Class Initialized
INFO - 2023-04-29 14:28:16 --> Output Class Initialized
INFO - 2023-04-29 14:28:16 --> Security Class Initialized
DEBUG - 2023-04-29 14:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:28:16 --> Input Class Initialized
INFO - 2023-04-29 14:28:16 --> Language Class Initialized
INFO - 2023-04-29 14:28:16 --> Loader Class Initialized
INFO - 2023-04-29 14:28:16 --> Helper loaded: url_helper
INFO - 2023-04-29 14:28:16 --> Helper loaded: form_helper
INFO - 2023-04-29 14:28:16 --> Helper loaded: file_helper
INFO - 2023-04-29 14:28:16 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:28:16 --> Form Validation Class Initialized
INFO - 2023-04-29 14:28:16 --> Upload Class Initialized
INFO - 2023-04-29 14:28:16 --> Model "M_auth" initialized
INFO - 2023-04-29 14:28:16 --> Model "M_user" initialized
INFO - 2023-04-29 14:28:16 --> Model "M_produk" initialized
INFO - 2023-04-29 14:28:16 --> Controller Class Initialized
INFO - 2023-04-29 14:28:16 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/not_found.php
INFO - 2023-04-29 14:28:16 --> Final output sent to browser
DEBUG - 2023-04-29 14:28:16 --> Total execution time: 0.1181
INFO - 2023-04-29 14:28:18 --> Config Class Initialized
INFO - 2023-04-29 14:28:18 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:28:18 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:28:18 --> Utf8 Class Initialized
INFO - 2023-04-29 14:28:18 --> URI Class Initialized
INFO - 2023-04-29 14:28:18 --> Router Class Initialized
INFO - 2023-04-29 14:28:18 --> Output Class Initialized
INFO - 2023-04-29 14:28:18 --> Security Class Initialized
DEBUG - 2023-04-29 14:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:28:18 --> Input Class Initialized
INFO - 2023-04-29 14:28:18 --> Language Class Initialized
INFO - 2023-04-29 14:28:18 --> Loader Class Initialized
INFO - 2023-04-29 14:28:18 --> Helper loaded: url_helper
INFO - 2023-04-29 14:28:18 --> Helper loaded: form_helper
INFO - 2023-04-29 14:28:18 --> Helper loaded: file_helper
INFO - 2023-04-29 14:28:18 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:28:18 --> Form Validation Class Initialized
INFO - 2023-04-29 14:28:18 --> Upload Class Initialized
INFO - 2023-04-29 14:28:18 --> Model "M_auth" initialized
INFO - 2023-04-29 14:28:18 --> Model "M_user" initialized
INFO - 2023-04-29 14:28:18 --> Model "M_produk" initialized
INFO - 2023-04-29 14:28:18 --> Controller Class Initialized
INFO - 2023-04-29 14:28:18 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_user.php
INFO - 2023-04-29 14:28:18 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:28:18 --> Final output sent to browser
DEBUG - 2023-04-29 14:28:18 --> Total execution time: 0.1726
INFO - 2023-04-29 14:28:22 --> Config Class Initialized
INFO - 2023-04-29 14:28:22 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:28:22 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:28:22 --> Utf8 Class Initialized
INFO - 2023-04-29 14:28:22 --> URI Class Initialized
INFO - 2023-04-29 14:28:22 --> Router Class Initialized
INFO - 2023-04-29 14:28:22 --> Output Class Initialized
INFO - 2023-04-29 14:28:22 --> Security Class Initialized
DEBUG - 2023-04-29 14:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:28:22 --> Input Class Initialized
INFO - 2023-04-29 14:28:22 --> Language Class Initialized
INFO - 2023-04-29 14:28:22 --> Loader Class Initialized
INFO - 2023-04-29 14:28:22 --> Helper loaded: url_helper
INFO - 2023-04-29 14:28:22 --> Helper loaded: form_helper
INFO - 2023-04-29 14:28:22 --> Helper loaded: file_helper
INFO - 2023-04-29 14:28:22 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:28:22 --> Form Validation Class Initialized
INFO - 2023-04-29 14:28:22 --> Upload Class Initialized
INFO - 2023-04-29 14:28:22 --> Model "M_auth" initialized
INFO - 2023-04-29 14:28:22 --> Model "M_user" initialized
INFO - 2023-04-29 14:28:22 --> Model "M_produk" initialized
INFO - 2023-04-29 14:28:22 --> Controller Class Initialized
INFO - 2023-04-29 14:28:22 --> Config Class Initialized
INFO - 2023-04-29 14:28:22 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:28:22 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:28:22 --> Utf8 Class Initialized
INFO - 2023-04-29 14:28:22 --> URI Class Initialized
INFO - 2023-04-29 14:28:22 --> Router Class Initialized
INFO - 2023-04-29 14:28:22 --> Output Class Initialized
INFO - 2023-04-29 14:28:22 --> Security Class Initialized
DEBUG - 2023-04-29 14:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:28:22 --> Input Class Initialized
INFO - 2023-04-29 14:28:22 --> Language Class Initialized
INFO - 2023-04-29 14:28:22 --> Loader Class Initialized
INFO - 2023-04-29 14:28:22 --> Helper loaded: url_helper
INFO - 2023-04-29 14:28:22 --> Helper loaded: form_helper
INFO - 2023-04-29 14:28:22 --> Helper loaded: file_helper
INFO - 2023-04-29 14:28:22 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:28:22 --> Form Validation Class Initialized
INFO - 2023-04-29 14:28:22 --> Upload Class Initialized
INFO - 2023-04-29 14:28:22 --> Model "M_auth" initialized
INFO - 2023-04-29 14:28:22 --> Model "M_user" initialized
INFO - 2023-04-29 14:28:22 --> Model "M_produk" initialized
INFO - 2023-04-29 14:28:22 --> Controller Class Initialized
INFO - 2023-04-29 14:28:22 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_login.php
INFO - 2023-04-29 14:28:22 --> Final output sent to browser
DEBUG - 2023-04-29 14:28:22 --> Total execution time: 0.1009
INFO - 2023-04-29 14:28:26 --> Config Class Initialized
INFO - 2023-04-29 14:28:26 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:28:26 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:28:26 --> Utf8 Class Initialized
INFO - 2023-04-29 14:28:26 --> URI Class Initialized
DEBUG - 2023-04-29 14:28:26 --> No URI present. Default controller set.
INFO - 2023-04-29 14:28:26 --> Router Class Initialized
INFO - 2023-04-29 14:28:26 --> Output Class Initialized
INFO - 2023-04-29 14:28:26 --> Security Class Initialized
DEBUG - 2023-04-29 14:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:28:26 --> Input Class Initialized
INFO - 2023-04-29 14:28:26 --> Language Class Initialized
INFO - 2023-04-29 14:28:26 --> Loader Class Initialized
INFO - 2023-04-29 14:28:26 --> Helper loaded: url_helper
INFO - 2023-04-29 14:28:26 --> Helper loaded: form_helper
INFO - 2023-04-29 14:28:26 --> Helper loaded: file_helper
INFO - 2023-04-29 14:28:26 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:28:26 --> Form Validation Class Initialized
INFO - 2023-04-29 14:28:26 --> Upload Class Initialized
INFO - 2023-04-29 14:28:26 --> Model "M_auth" initialized
INFO - 2023-04-29 14:28:26 --> Model "M_user" initialized
INFO - 2023-04-29 14:28:26 --> Model "M_produk" initialized
INFO - 2023-04-29 14:28:26 --> Controller Class Initialized
INFO - 2023-04-29 14:28:26 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:28:26 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:28:26 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:28:26 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:28:26 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:28:26 --> Model "M_bank" initialized
INFO - 2023-04-29 14:28:26 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:28:26 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:28:26 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/index.php
INFO - 2023-04-29 14:28:26 --> Final output sent to browser
DEBUG - 2023-04-29 14:28:26 --> Total execution time: 0.1522
INFO - 2023-04-29 14:28:33 --> Config Class Initialized
INFO - 2023-04-29 14:28:33 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:28:33 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:28:33 --> Utf8 Class Initialized
INFO - 2023-04-29 14:28:33 --> URI Class Initialized
DEBUG - 2023-04-29 14:28:33 --> No URI present. Default controller set.
INFO - 2023-04-29 14:28:33 --> Router Class Initialized
INFO - 2023-04-29 14:28:33 --> Output Class Initialized
INFO - 2023-04-29 14:28:33 --> Security Class Initialized
DEBUG - 2023-04-29 14:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:28:33 --> Input Class Initialized
INFO - 2023-04-29 14:28:33 --> Language Class Initialized
INFO - 2023-04-29 14:28:33 --> Loader Class Initialized
INFO - 2023-04-29 14:28:33 --> Helper loaded: url_helper
INFO - 2023-04-29 14:28:33 --> Helper loaded: form_helper
INFO - 2023-04-29 14:28:33 --> Helper loaded: file_helper
INFO - 2023-04-29 14:28:33 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:28:33 --> Form Validation Class Initialized
INFO - 2023-04-29 14:28:33 --> Upload Class Initialized
INFO - 2023-04-29 14:28:33 --> Model "M_auth" initialized
INFO - 2023-04-29 14:28:33 --> Model "M_user" initialized
INFO - 2023-04-29 14:28:33 --> Model "M_produk" initialized
INFO - 2023-04-29 14:28:33 --> Controller Class Initialized
INFO - 2023-04-29 14:28:33 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:28:33 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:28:33 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:28:33 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:28:33 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:28:33 --> Model "M_bank" initialized
INFO - 2023-04-29 14:28:33 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:28:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-04-29 14:28:33 --> Email Class Initialized
ERROR - 2023-04-29 14:28:39 --> Severity: Warning --> fsockopen(): Unable to connect to ssl://smtp.googlemail.com:465 (A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond) C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\system\libraries\Email.php 2070
INFO - 2023-04-29 14:28:39 --> Language file loaded: language/english/email_lang.php
INFO - 2023-04-29 14:28:39 --> Config Class Initialized
INFO - 2023-04-29 14:28:39 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:28:39 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:28:39 --> Utf8 Class Initialized
INFO - 2023-04-29 14:28:39 --> URI Class Initialized
DEBUG - 2023-04-29 14:28:39 --> No URI present. Default controller set.
INFO - 2023-04-29 14:28:39 --> Router Class Initialized
INFO - 2023-04-29 14:28:39 --> Output Class Initialized
INFO - 2023-04-29 14:28:39 --> Security Class Initialized
DEBUG - 2023-04-29 14:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:28:39 --> Input Class Initialized
INFO - 2023-04-29 14:28:39 --> Language Class Initialized
INFO - 2023-04-29 14:28:39 --> Loader Class Initialized
INFO - 2023-04-29 14:28:39 --> Helper loaded: url_helper
INFO - 2023-04-29 14:28:39 --> Helper loaded: form_helper
INFO - 2023-04-29 14:28:39 --> Helper loaded: file_helper
INFO - 2023-04-29 14:28:39 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:28:39 --> Form Validation Class Initialized
INFO - 2023-04-29 14:28:39 --> Upload Class Initialized
INFO - 2023-04-29 14:28:39 --> Model "M_auth" initialized
INFO - 2023-04-29 14:28:39 --> Model "M_user" initialized
INFO - 2023-04-29 14:28:39 --> Model "M_produk" initialized
INFO - 2023-04-29 14:28:39 --> Controller Class Initialized
INFO - 2023-04-29 14:28:39 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:28:39 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:28:39 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:28:39 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:28:39 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:28:39 --> Model "M_bank" initialized
INFO - 2023-04-29 14:28:39 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:28:39 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:28:39 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/index.php
INFO - 2023-04-29 14:28:39 --> Final output sent to browser
DEBUG - 2023-04-29 14:28:39 --> Total execution time: 0.1277
INFO - 2023-04-29 14:28:47 --> Config Class Initialized
INFO - 2023-04-29 14:28:47 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:28:47 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:28:47 --> Utf8 Class Initialized
INFO - 2023-04-29 14:28:47 --> URI Class Initialized
INFO - 2023-04-29 14:28:47 --> Router Class Initialized
INFO - 2023-04-29 14:28:47 --> Output Class Initialized
INFO - 2023-04-29 14:28:47 --> Security Class Initialized
DEBUG - 2023-04-29 14:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:28:47 --> Input Class Initialized
INFO - 2023-04-29 14:28:47 --> Language Class Initialized
INFO - 2023-04-29 14:28:47 --> Loader Class Initialized
INFO - 2023-04-29 14:28:47 --> Helper loaded: url_helper
INFO - 2023-04-29 14:28:47 --> Helper loaded: form_helper
INFO - 2023-04-29 14:28:47 --> Helper loaded: file_helper
INFO - 2023-04-29 14:28:47 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:28:47 --> Form Validation Class Initialized
INFO - 2023-04-29 14:28:47 --> Upload Class Initialized
INFO - 2023-04-29 14:28:47 --> Model "M_auth" initialized
INFO - 2023-04-29 14:28:47 --> Model "M_user" initialized
INFO - 2023-04-29 14:28:47 --> Model "M_produk" initialized
INFO - 2023-04-29 14:28:47 --> Controller Class Initialized
INFO - 2023-04-29 14:28:47 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/not_found.php
INFO - 2023-04-29 14:28:47 --> Final output sent to browser
DEBUG - 2023-04-29 14:28:47 --> Total execution time: 0.1255
INFO - 2023-04-29 14:28:52 --> Config Class Initialized
INFO - 2023-04-29 14:28:52 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:28:52 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:28:52 --> Utf8 Class Initialized
INFO - 2023-04-29 14:28:52 --> URI Class Initialized
INFO - 2023-04-29 14:28:52 --> Router Class Initialized
INFO - 2023-04-29 14:28:52 --> Output Class Initialized
INFO - 2023-04-29 14:28:52 --> Security Class Initialized
DEBUG - 2023-04-29 14:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:28:52 --> Input Class Initialized
INFO - 2023-04-29 14:28:52 --> Language Class Initialized
INFO - 2023-04-29 14:28:52 --> Loader Class Initialized
INFO - 2023-04-29 14:28:52 --> Helper loaded: url_helper
INFO - 2023-04-29 14:28:52 --> Helper loaded: form_helper
INFO - 2023-04-29 14:28:52 --> Helper loaded: file_helper
INFO - 2023-04-29 14:28:52 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:28:52 --> Form Validation Class Initialized
INFO - 2023-04-29 14:28:52 --> Upload Class Initialized
INFO - 2023-04-29 14:28:52 --> Model "M_auth" initialized
INFO - 2023-04-29 14:28:52 --> Model "M_user" initialized
INFO - 2023-04-29 14:28:52 --> Model "M_produk" initialized
INFO - 2023-04-29 14:28:52 --> Controller Class Initialized
INFO - 2023-04-29 14:28:52 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/not_found.php
INFO - 2023-04-29 14:28:52 --> Final output sent to browser
DEBUG - 2023-04-29 14:28:53 --> Total execution time: 0.1329
INFO - 2023-04-29 14:28:55 --> Config Class Initialized
INFO - 2023-04-29 14:28:55 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:28:55 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:28:55 --> Utf8 Class Initialized
INFO - 2023-04-29 14:28:55 --> URI Class Initialized
DEBUG - 2023-04-29 14:28:55 --> No URI present. Default controller set.
INFO - 2023-04-29 14:28:55 --> Router Class Initialized
INFO - 2023-04-29 14:28:55 --> Output Class Initialized
INFO - 2023-04-29 14:28:55 --> Security Class Initialized
DEBUG - 2023-04-29 14:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:28:55 --> Input Class Initialized
INFO - 2023-04-29 14:28:55 --> Language Class Initialized
INFO - 2023-04-29 14:28:55 --> Loader Class Initialized
INFO - 2023-04-29 14:28:55 --> Helper loaded: url_helper
INFO - 2023-04-29 14:28:55 --> Helper loaded: form_helper
INFO - 2023-04-29 14:28:55 --> Helper loaded: file_helper
INFO - 2023-04-29 14:28:55 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:28:55 --> Form Validation Class Initialized
INFO - 2023-04-29 14:28:55 --> Upload Class Initialized
INFO - 2023-04-29 14:28:55 --> Model "M_auth" initialized
INFO - 2023-04-29 14:28:55 --> Model "M_user" initialized
INFO - 2023-04-29 14:28:55 --> Model "M_produk" initialized
INFO - 2023-04-29 14:28:55 --> Controller Class Initialized
INFO - 2023-04-29 14:28:55 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:28:55 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:28:55 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:28:55 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:28:55 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:28:55 --> Model "M_bank" initialized
INFO - 2023-04-29 14:28:55 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:28:55 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:28:55 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/index.php
INFO - 2023-04-29 14:28:55 --> Final output sent to browser
DEBUG - 2023-04-29 14:28:55 --> Total execution time: 0.1767
INFO - 2023-04-29 14:28:58 --> Config Class Initialized
INFO - 2023-04-29 14:28:58 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:28:58 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:28:58 --> Utf8 Class Initialized
INFO - 2023-04-29 14:28:58 --> URI Class Initialized
INFO - 2023-04-29 14:28:58 --> Router Class Initialized
INFO - 2023-04-29 14:28:58 --> Output Class Initialized
INFO - 2023-04-29 14:28:58 --> Security Class Initialized
DEBUG - 2023-04-29 14:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:28:58 --> Input Class Initialized
INFO - 2023-04-29 14:28:58 --> Language Class Initialized
INFO - 2023-04-29 14:28:58 --> Loader Class Initialized
INFO - 2023-04-29 14:28:58 --> Helper loaded: url_helper
INFO - 2023-04-29 14:28:58 --> Helper loaded: form_helper
INFO - 2023-04-29 14:28:58 --> Helper loaded: file_helper
INFO - 2023-04-29 14:28:58 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:28:58 --> Form Validation Class Initialized
INFO - 2023-04-29 14:28:58 --> Upload Class Initialized
INFO - 2023-04-29 14:28:58 --> Model "M_auth" initialized
INFO - 2023-04-29 14:28:58 --> Model "M_user" initialized
INFO - 2023-04-29 14:28:58 --> Model "M_produk" initialized
INFO - 2023-04-29 14:28:58 --> Controller Class Initialized
INFO - 2023-04-29 14:28:58 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/not_found.php
INFO - 2023-04-29 14:28:58 --> Final output sent to browser
DEBUG - 2023-04-29 14:28:58 --> Total execution time: 0.1310
INFO - 2023-04-29 14:29:01 --> Config Class Initialized
INFO - 2023-04-29 14:29:01 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:29:01 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:29:01 --> Utf8 Class Initialized
INFO - 2023-04-29 14:29:01 --> URI Class Initialized
DEBUG - 2023-04-29 14:29:01 --> No URI present. Default controller set.
INFO - 2023-04-29 14:29:01 --> Router Class Initialized
INFO - 2023-04-29 14:29:01 --> Output Class Initialized
INFO - 2023-04-29 14:29:01 --> Security Class Initialized
DEBUG - 2023-04-29 14:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:29:01 --> Input Class Initialized
INFO - 2023-04-29 14:29:01 --> Language Class Initialized
INFO - 2023-04-29 14:29:01 --> Loader Class Initialized
INFO - 2023-04-29 14:29:01 --> Helper loaded: url_helper
INFO - 2023-04-29 14:29:01 --> Helper loaded: form_helper
INFO - 2023-04-29 14:29:01 --> Helper loaded: file_helper
INFO - 2023-04-29 14:29:01 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:29:01 --> Form Validation Class Initialized
INFO - 2023-04-29 14:29:01 --> Upload Class Initialized
INFO - 2023-04-29 14:29:01 --> Model "M_auth" initialized
INFO - 2023-04-29 14:29:01 --> Model "M_user" initialized
INFO - 2023-04-29 14:29:01 --> Model "M_produk" initialized
INFO - 2023-04-29 14:29:01 --> Controller Class Initialized
INFO - 2023-04-29 14:29:01 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:29:01 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:29:01 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:29:01 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:29:01 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:29:01 --> Model "M_bank" initialized
INFO - 2023-04-29 14:29:01 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:29:01 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:29:01 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/index.php
INFO - 2023-04-29 14:29:01 --> Final output sent to browser
DEBUG - 2023-04-29 14:29:02 --> Total execution time: 0.1581
INFO - 2023-04-29 14:29:13 --> Config Class Initialized
INFO - 2023-04-29 14:29:13 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:29:13 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:29:13 --> Utf8 Class Initialized
INFO - 2023-04-29 14:29:13 --> URI Class Initialized
INFO - 2023-04-29 14:29:13 --> Router Class Initialized
INFO - 2023-04-29 14:29:13 --> Output Class Initialized
INFO - 2023-04-29 14:29:13 --> Security Class Initialized
DEBUG - 2023-04-29 14:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:29:13 --> Input Class Initialized
INFO - 2023-04-29 14:29:13 --> Language Class Initialized
INFO - 2023-04-29 14:29:13 --> Loader Class Initialized
INFO - 2023-04-29 14:29:13 --> Helper loaded: url_helper
INFO - 2023-04-29 14:29:13 --> Helper loaded: form_helper
INFO - 2023-04-29 14:29:13 --> Helper loaded: file_helper
INFO - 2023-04-29 14:29:13 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:29:13 --> Form Validation Class Initialized
INFO - 2023-04-29 14:29:13 --> Upload Class Initialized
INFO - 2023-04-29 14:29:13 --> Model "M_auth" initialized
INFO - 2023-04-29 14:29:13 --> Model "M_user" initialized
INFO - 2023-04-29 14:29:13 --> Model "M_produk" initialized
INFO - 2023-04-29 14:29:13 --> Controller Class Initialized
INFO - 2023-04-29 14:29:13 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:29:13 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:29:13 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:29:13 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:29:13 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:29:13 --> Model "M_bank" initialized
INFO - 2023-04-29 14:29:13 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:29:13 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:29:13 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/v_produk_detail.php
INFO - 2023-04-29 14:29:13 --> Final output sent to browser
DEBUG - 2023-04-29 14:29:13 --> Total execution time: 0.1272
INFO - 2023-04-29 14:29:25 --> Config Class Initialized
INFO - 2023-04-29 14:29:25 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:29:25 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:29:25 --> Utf8 Class Initialized
INFO - 2023-04-29 14:29:25 --> URI Class Initialized
INFO - 2023-04-29 14:29:25 --> Router Class Initialized
INFO - 2023-04-29 14:29:25 --> Output Class Initialized
INFO - 2023-04-29 14:29:25 --> Security Class Initialized
DEBUG - 2023-04-29 14:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:29:25 --> Input Class Initialized
INFO - 2023-04-29 14:29:25 --> Language Class Initialized
INFO - 2023-04-29 14:29:25 --> Loader Class Initialized
INFO - 2023-04-29 14:29:25 --> Helper loaded: url_helper
INFO - 2023-04-29 14:29:25 --> Helper loaded: form_helper
INFO - 2023-04-29 14:29:25 --> Helper loaded: file_helper
INFO - 2023-04-29 14:29:25 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:29:25 --> Form Validation Class Initialized
INFO - 2023-04-29 14:29:25 --> Upload Class Initialized
INFO - 2023-04-29 14:29:25 --> Model "M_auth" initialized
INFO - 2023-04-29 14:29:25 --> Model "M_user" initialized
INFO - 2023-04-29 14:29:25 --> Model "M_produk" initialized
INFO - 2023-04-29 14:29:25 --> Controller Class Initialized
INFO - 2023-04-29 14:29:25 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:29:25 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:29:25 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:29:25 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:29:25 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:29:25 --> Model "M_bank" initialized
INFO - 2023-04-29 14:29:25 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:29:25 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:29:25 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/v_edit_profile_pelanggan.php
INFO - 2023-04-29 14:29:25 --> Final output sent to browser
DEBUG - 2023-04-29 14:29:25 --> Total execution time: 0.1356
INFO - 2023-04-29 14:29:27 --> Config Class Initialized
INFO - 2023-04-29 14:29:27 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:29:27 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:29:27 --> Utf8 Class Initialized
INFO - 2023-04-29 14:29:27 --> URI Class Initialized
INFO - 2023-04-29 14:29:27 --> Router Class Initialized
INFO - 2023-04-29 14:29:27 --> Output Class Initialized
INFO - 2023-04-29 14:29:27 --> Security Class Initialized
DEBUG - 2023-04-29 14:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:29:27 --> Input Class Initialized
INFO - 2023-04-29 14:29:27 --> Language Class Initialized
INFO - 2023-04-29 14:29:27 --> Loader Class Initialized
INFO - 2023-04-29 14:29:27 --> Helper loaded: url_helper
INFO - 2023-04-29 14:29:27 --> Helper loaded: form_helper
INFO - 2023-04-29 14:29:27 --> Helper loaded: file_helper
INFO - 2023-04-29 14:29:27 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:29:27 --> Form Validation Class Initialized
INFO - 2023-04-29 14:29:27 --> Upload Class Initialized
INFO - 2023-04-29 14:29:27 --> Model "M_auth" initialized
INFO - 2023-04-29 14:29:27 --> Model "M_user" initialized
INFO - 2023-04-29 14:29:27 --> Model "M_produk" initialized
INFO - 2023-04-29 14:29:27 --> Controller Class Initialized
INFO - 2023-04-29 14:29:27 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:29:27 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:29:27 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:29:27 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:29:27 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:29:27 --> Model "M_bank" initialized
INFO - 2023-04-29 14:29:27 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:29:27 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:29:27 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/v_booking_saya.php
INFO - 2023-04-29 14:29:27 --> Final output sent to browser
DEBUG - 2023-04-29 14:29:27 --> Total execution time: 0.1505
INFO - 2023-04-29 14:29:29 --> Config Class Initialized
INFO - 2023-04-29 14:29:29 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:29:29 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:29:29 --> Utf8 Class Initialized
INFO - 2023-04-29 14:29:29 --> URI Class Initialized
INFO - 2023-04-29 14:29:29 --> Router Class Initialized
INFO - 2023-04-29 14:29:29 --> Output Class Initialized
INFO - 2023-04-29 14:29:29 --> Security Class Initialized
DEBUG - 2023-04-29 14:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:29:29 --> Input Class Initialized
INFO - 2023-04-29 14:29:29 --> Language Class Initialized
INFO - 2023-04-29 14:29:29 --> Loader Class Initialized
INFO - 2023-04-29 14:29:29 --> Helper loaded: url_helper
INFO - 2023-04-29 14:29:29 --> Helper loaded: form_helper
INFO - 2023-04-29 14:29:29 --> Helper loaded: file_helper
INFO - 2023-04-29 14:29:29 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:29:29 --> Form Validation Class Initialized
INFO - 2023-04-29 14:29:29 --> Upload Class Initialized
INFO - 2023-04-29 14:29:29 --> Model "M_auth" initialized
INFO - 2023-04-29 14:29:29 --> Model "M_user" initialized
INFO - 2023-04-29 14:29:29 --> Model "M_produk" initialized
INFO - 2023-04-29 14:29:29 --> Controller Class Initialized
INFO - 2023-04-29 14:29:29 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:29:29 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:29:29 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:29:29 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:29:29 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:29:29 --> Model "M_bank" initialized
INFO - 2023-04-29 14:29:29 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:29:29 --> Config Class Initialized
INFO - 2023-04-29 14:29:29 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:29:29 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:29:29 --> Utf8 Class Initialized
INFO - 2023-04-29 14:29:29 --> URI Class Initialized
DEBUG - 2023-04-29 14:29:29 --> No URI present. Default controller set.
INFO - 2023-04-29 14:29:29 --> Router Class Initialized
INFO - 2023-04-29 14:29:29 --> Output Class Initialized
INFO - 2023-04-29 14:29:29 --> Security Class Initialized
DEBUG - 2023-04-29 14:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:29:29 --> Input Class Initialized
INFO - 2023-04-29 14:29:29 --> Language Class Initialized
INFO - 2023-04-29 14:29:29 --> Loader Class Initialized
INFO - 2023-04-29 14:29:29 --> Helper loaded: url_helper
INFO - 2023-04-29 14:29:29 --> Helper loaded: form_helper
INFO - 2023-04-29 14:29:29 --> Helper loaded: file_helper
INFO - 2023-04-29 14:29:29 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:29:29 --> Form Validation Class Initialized
INFO - 2023-04-29 14:29:29 --> Upload Class Initialized
INFO - 2023-04-29 14:29:29 --> Model "M_auth" initialized
INFO - 2023-04-29 14:29:29 --> Model "M_user" initialized
INFO - 2023-04-29 14:29:29 --> Model "M_produk" initialized
INFO - 2023-04-29 14:29:29 --> Controller Class Initialized
INFO - 2023-04-29 14:29:29 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:29:29 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:29:29 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:29:29 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:29:29 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:29:29 --> Model "M_bank" initialized
INFO - 2023-04-29 14:29:29 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:29:29 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:29:29 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/index.php
INFO - 2023-04-29 14:29:29 --> Final output sent to browser
DEBUG - 2023-04-29 14:29:29 --> Total execution time: 0.1597
INFO - 2023-04-29 14:29:33 --> Config Class Initialized
INFO - 2023-04-29 14:29:33 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:29:33 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:29:33 --> Utf8 Class Initialized
INFO - 2023-04-29 14:29:33 --> URI Class Initialized
INFO - 2023-04-29 14:29:33 --> Router Class Initialized
INFO - 2023-04-29 14:29:33 --> Output Class Initialized
INFO - 2023-04-29 14:29:33 --> Security Class Initialized
DEBUG - 2023-04-29 14:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:29:33 --> Input Class Initialized
INFO - 2023-04-29 14:29:33 --> Language Class Initialized
INFO - 2023-04-29 14:29:33 --> Loader Class Initialized
INFO - 2023-04-29 14:29:33 --> Helper loaded: url_helper
INFO - 2023-04-29 14:29:33 --> Helper loaded: form_helper
INFO - 2023-04-29 14:29:33 --> Helper loaded: file_helper
INFO - 2023-04-29 14:29:33 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:29:33 --> Form Validation Class Initialized
INFO - 2023-04-29 14:29:33 --> Upload Class Initialized
INFO - 2023-04-29 14:29:33 --> Model "M_auth" initialized
INFO - 2023-04-29 14:29:33 --> Model "M_user" initialized
INFO - 2023-04-29 14:29:33 --> Model "M_produk" initialized
INFO - 2023-04-29 14:29:33 --> Controller Class Initialized
INFO - 2023-04-29 14:29:33 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_login.php
INFO - 2023-04-29 14:29:33 --> Final output sent to browser
DEBUG - 2023-04-29 14:29:33 --> Total execution time: 0.1321
INFO - 2023-04-29 14:29:36 --> Config Class Initialized
INFO - 2023-04-29 14:29:36 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:29:36 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:29:36 --> Utf8 Class Initialized
INFO - 2023-04-29 14:29:36 --> URI Class Initialized
DEBUG - 2023-04-29 14:29:36 --> No URI present. Default controller set.
INFO - 2023-04-29 14:29:36 --> Router Class Initialized
INFO - 2023-04-29 14:29:36 --> Output Class Initialized
INFO - 2023-04-29 14:29:36 --> Security Class Initialized
DEBUG - 2023-04-29 14:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:29:36 --> Input Class Initialized
INFO - 2023-04-29 14:29:36 --> Language Class Initialized
INFO - 2023-04-29 14:29:36 --> Loader Class Initialized
INFO - 2023-04-29 14:29:36 --> Helper loaded: url_helper
INFO - 2023-04-29 14:29:36 --> Helper loaded: form_helper
INFO - 2023-04-29 14:29:36 --> Helper loaded: file_helper
INFO - 2023-04-29 14:29:36 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:29:36 --> Form Validation Class Initialized
INFO - 2023-04-29 14:29:36 --> Upload Class Initialized
INFO - 2023-04-29 14:29:36 --> Model "M_auth" initialized
INFO - 2023-04-29 14:29:36 --> Model "M_user" initialized
INFO - 2023-04-29 14:29:36 --> Model "M_produk" initialized
INFO - 2023-04-29 14:29:36 --> Controller Class Initialized
INFO - 2023-04-29 14:29:36 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:29:36 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:29:36 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:29:36 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:29:36 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:29:36 --> Model "M_bank" initialized
INFO - 2023-04-29 14:29:36 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:29:36 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:29:36 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/index.php
INFO - 2023-04-29 14:29:36 --> Final output sent to browser
DEBUG - 2023-04-29 14:29:36 --> Total execution time: 0.1338
INFO - 2023-04-29 14:29:44 --> Config Class Initialized
INFO - 2023-04-29 14:29:44 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:29:44 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:29:44 --> Utf8 Class Initialized
INFO - 2023-04-29 14:29:44 --> URI Class Initialized
INFO - 2023-04-29 14:29:44 --> Router Class Initialized
INFO - 2023-04-29 14:29:44 --> Output Class Initialized
INFO - 2023-04-29 14:29:44 --> Security Class Initialized
DEBUG - 2023-04-29 14:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:29:44 --> Input Class Initialized
INFO - 2023-04-29 14:29:44 --> Language Class Initialized
INFO - 2023-04-29 14:29:44 --> Loader Class Initialized
INFO - 2023-04-29 14:29:44 --> Helper loaded: url_helper
INFO - 2023-04-29 14:29:44 --> Helper loaded: form_helper
INFO - 2023-04-29 14:29:44 --> Helper loaded: file_helper
INFO - 2023-04-29 14:29:44 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:29:44 --> Form Validation Class Initialized
INFO - 2023-04-29 14:29:44 --> Upload Class Initialized
INFO - 2023-04-29 14:29:44 --> Model "M_auth" initialized
INFO - 2023-04-29 14:29:44 --> Model "M_user" initialized
INFO - 2023-04-29 14:29:44 --> Model "M_produk" initialized
INFO - 2023-04-29 14:29:44 --> Controller Class Initialized
INFO - 2023-04-29 14:29:44 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:29:44 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:29:44 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:29:44 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:29:44 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:29:44 --> Model "M_bank" initialized
INFO - 2023-04-29 14:29:44 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:29:44 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:29:44 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/v_produk_detail.php
INFO - 2023-04-29 14:29:44 --> Final output sent to browser
DEBUG - 2023-04-29 14:29:44 --> Total execution time: 0.1499
INFO - 2023-04-29 14:29:46 --> Config Class Initialized
INFO - 2023-04-29 14:29:46 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:29:46 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:29:46 --> Utf8 Class Initialized
INFO - 2023-04-29 14:29:46 --> URI Class Initialized
INFO - 2023-04-29 14:29:46 --> Router Class Initialized
INFO - 2023-04-29 14:29:46 --> Output Class Initialized
INFO - 2023-04-29 14:29:46 --> Security Class Initialized
DEBUG - 2023-04-29 14:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:29:46 --> Input Class Initialized
INFO - 2023-04-29 14:29:46 --> Language Class Initialized
INFO - 2023-04-29 14:29:46 --> Loader Class Initialized
INFO - 2023-04-29 14:29:46 --> Helper loaded: url_helper
INFO - 2023-04-29 14:29:46 --> Helper loaded: form_helper
INFO - 2023-04-29 14:29:46 --> Helper loaded: file_helper
INFO - 2023-04-29 14:29:46 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:29:46 --> Form Validation Class Initialized
INFO - 2023-04-29 14:29:46 --> Upload Class Initialized
INFO - 2023-04-29 14:29:46 --> Model "M_auth" initialized
INFO - 2023-04-29 14:29:46 --> Model "M_user" initialized
INFO - 2023-04-29 14:29:46 --> Model "M_produk" initialized
INFO - 2023-04-29 14:29:46 --> Controller Class Initialized
INFO - 2023-04-29 14:29:46 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:29:46 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:29:46 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:29:46 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:29:46 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:29:46 --> Model "M_bank" initialized
INFO - 2023-04-29 14:29:46 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:29:46 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:29:46 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/v_produk_detail.php
INFO - 2023-04-29 14:29:46 --> Final output sent to browser
DEBUG - 2023-04-29 14:29:46 --> Total execution time: 0.1486
INFO - 2023-04-29 14:29:50 --> Config Class Initialized
INFO - 2023-04-29 14:29:50 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:29:50 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:29:50 --> Utf8 Class Initialized
INFO - 2023-04-29 14:29:50 --> URI Class Initialized
INFO - 2023-04-29 14:29:50 --> Router Class Initialized
INFO - 2023-04-29 14:29:50 --> Output Class Initialized
INFO - 2023-04-29 14:29:50 --> Security Class Initialized
DEBUG - 2023-04-29 14:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:29:50 --> Input Class Initialized
INFO - 2023-04-29 14:29:50 --> Language Class Initialized
INFO - 2023-04-29 14:29:50 --> Loader Class Initialized
INFO - 2023-04-29 14:29:50 --> Helper loaded: url_helper
INFO - 2023-04-29 14:29:50 --> Helper loaded: form_helper
INFO - 2023-04-29 14:29:50 --> Helper loaded: file_helper
INFO - 2023-04-29 14:29:50 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:29:50 --> Form Validation Class Initialized
INFO - 2023-04-29 14:29:50 --> Upload Class Initialized
INFO - 2023-04-29 14:29:50 --> Model "M_auth" initialized
INFO - 2023-04-29 14:29:50 --> Model "M_user" initialized
INFO - 2023-04-29 14:29:50 --> Model "M_produk" initialized
INFO - 2023-04-29 14:29:50 --> Controller Class Initialized
INFO - 2023-04-29 14:29:50 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:29:50 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:29:50 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:29:50 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:29:50 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:29:50 --> Model "M_bank" initialized
INFO - 2023-04-29 14:29:50 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:29:50 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:29:50 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/v_kategori_detail.php
INFO - 2023-04-29 14:29:50 --> Final output sent to browser
DEBUG - 2023-04-29 14:29:50 --> Total execution time: 0.1411
INFO - 2023-04-29 14:30:00 --> Config Class Initialized
INFO - 2023-04-29 14:30:00 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:30:00 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:30:00 --> Utf8 Class Initialized
INFO - 2023-04-29 14:30:00 --> URI Class Initialized
INFO - 2023-04-29 14:30:00 --> Router Class Initialized
INFO - 2023-04-29 14:30:00 --> Output Class Initialized
INFO - 2023-04-29 14:30:00 --> Security Class Initialized
DEBUG - 2023-04-29 14:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:30:00 --> Input Class Initialized
INFO - 2023-04-29 14:30:00 --> Language Class Initialized
INFO - 2023-04-29 14:30:00 --> Loader Class Initialized
INFO - 2023-04-29 14:30:00 --> Helper loaded: url_helper
INFO - 2023-04-29 14:30:00 --> Helper loaded: form_helper
INFO - 2023-04-29 14:30:00 --> Helper loaded: file_helper
INFO - 2023-04-29 14:30:00 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:30:00 --> Form Validation Class Initialized
INFO - 2023-04-29 14:30:00 --> Upload Class Initialized
INFO - 2023-04-29 14:30:00 --> Model "M_auth" initialized
INFO - 2023-04-29 14:30:00 --> Model "M_user" initialized
INFO - 2023-04-29 14:30:00 --> Model "M_produk" initialized
INFO - 2023-04-29 14:30:00 --> Controller Class Initialized
INFO - 2023-04-29 14:30:00 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_login.php
INFO - 2023-04-29 14:30:00 --> Final output sent to browser
DEBUG - 2023-04-29 14:30:00 --> Total execution time: 0.1355
INFO - 2023-04-29 14:30:06 --> Config Class Initialized
INFO - 2023-04-29 14:30:06 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:30:06 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:30:06 --> Utf8 Class Initialized
INFO - 2023-04-29 14:30:06 --> URI Class Initialized
INFO - 2023-04-29 14:30:06 --> Router Class Initialized
INFO - 2023-04-29 14:30:06 --> Output Class Initialized
INFO - 2023-04-29 14:30:06 --> Security Class Initialized
DEBUG - 2023-04-29 14:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:30:06 --> Input Class Initialized
INFO - 2023-04-29 14:30:06 --> Language Class Initialized
INFO - 2023-04-29 14:30:06 --> Loader Class Initialized
INFO - 2023-04-29 14:30:06 --> Helper loaded: url_helper
INFO - 2023-04-29 14:30:06 --> Helper loaded: form_helper
INFO - 2023-04-29 14:30:06 --> Helper loaded: file_helper
INFO - 2023-04-29 14:30:06 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:30:06 --> Form Validation Class Initialized
INFO - 2023-04-29 14:30:06 --> Upload Class Initialized
INFO - 2023-04-29 14:30:06 --> Model "M_auth" initialized
INFO - 2023-04-29 14:30:06 --> Model "M_user" initialized
INFO - 2023-04-29 14:30:06 --> Model "M_produk" initialized
INFO - 2023-04-29 14:30:06 --> Controller Class Initialized
INFO - 2023-04-29 14:30:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-04-29 14:30:06 --> Config Class Initialized
INFO - 2023-04-29 14:30:06 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:30:06 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:30:06 --> Utf8 Class Initialized
INFO - 2023-04-29 14:30:06 --> URI Class Initialized
INFO - 2023-04-29 14:30:06 --> Router Class Initialized
INFO - 2023-04-29 14:30:06 --> Output Class Initialized
INFO - 2023-04-29 14:30:06 --> Security Class Initialized
DEBUG - 2023-04-29 14:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:30:06 --> Input Class Initialized
INFO - 2023-04-29 14:30:06 --> Language Class Initialized
INFO - 2023-04-29 14:30:06 --> Loader Class Initialized
INFO - 2023-04-29 14:30:06 --> Helper loaded: url_helper
INFO - 2023-04-29 14:30:06 --> Helper loaded: form_helper
INFO - 2023-04-29 14:30:06 --> Helper loaded: file_helper
INFO - 2023-04-29 14:30:06 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:30:06 --> Form Validation Class Initialized
INFO - 2023-04-29 14:30:06 --> Upload Class Initialized
INFO - 2023-04-29 14:30:06 --> Model "M_auth" initialized
INFO - 2023-04-29 14:30:06 --> Model "M_user" initialized
INFO - 2023-04-29 14:30:06 --> Model "M_produk" initialized
INFO - 2023-04-29 14:30:06 --> Controller Class Initialized
INFO - 2023-04-29 14:30:06 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 14:30:06 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:30:06 --> Final output sent to browser
DEBUG - 2023-04-29 14:30:06 --> Total execution time: 0.1172
INFO - 2023-04-29 14:30:11 --> Config Class Initialized
INFO - 2023-04-29 14:30:11 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:30:11 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:30:11 --> Utf8 Class Initialized
INFO - 2023-04-29 14:30:11 --> URI Class Initialized
INFO - 2023-04-29 14:30:11 --> Router Class Initialized
INFO - 2023-04-29 14:30:11 --> Output Class Initialized
INFO - 2023-04-29 14:30:11 --> Security Class Initialized
DEBUG - 2023-04-29 14:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:30:11 --> Input Class Initialized
INFO - 2023-04-29 14:30:11 --> Language Class Initialized
INFO - 2023-04-29 14:30:11 --> Loader Class Initialized
INFO - 2023-04-29 14:30:11 --> Helper loaded: url_helper
INFO - 2023-04-29 14:30:11 --> Helper loaded: form_helper
INFO - 2023-04-29 14:30:11 --> Helper loaded: file_helper
INFO - 2023-04-29 14:30:11 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:30:11 --> Form Validation Class Initialized
INFO - 2023-04-29 14:30:11 --> Upload Class Initialized
INFO - 2023-04-29 14:30:11 --> Model "M_auth" initialized
INFO - 2023-04-29 14:30:11 --> Model "M_user" initialized
INFO - 2023-04-29 14:30:11 --> Model "M_produk" initialized
INFO - 2023-04-29 14:30:11 --> Controller Class Initialized
INFO - 2023-04-29 14:30:11 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_user_profile.php
INFO - 2023-04-29 14:30:11 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:30:11 --> Final output sent to browser
DEBUG - 2023-04-29 14:30:11 --> Total execution time: 0.1236
INFO - 2023-04-29 14:30:14 --> Config Class Initialized
INFO - 2023-04-29 14:30:14 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:30:14 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:30:14 --> Utf8 Class Initialized
INFO - 2023-04-29 14:30:14 --> URI Class Initialized
INFO - 2023-04-29 14:30:14 --> Router Class Initialized
INFO - 2023-04-29 14:30:14 --> Output Class Initialized
INFO - 2023-04-29 14:30:14 --> Security Class Initialized
DEBUG - 2023-04-29 14:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:30:14 --> Input Class Initialized
INFO - 2023-04-29 14:30:14 --> Language Class Initialized
INFO - 2023-04-29 14:30:14 --> Loader Class Initialized
INFO - 2023-04-29 14:30:14 --> Helper loaded: url_helper
INFO - 2023-04-29 14:30:14 --> Helper loaded: form_helper
INFO - 2023-04-29 14:30:14 --> Helper loaded: file_helper
INFO - 2023-04-29 14:30:14 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:30:14 --> Form Validation Class Initialized
INFO - 2023-04-29 14:30:14 --> Upload Class Initialized
INFO - 2023-04-29 14:30:14 --> Model "M_auth" initialized
INFO - 2023-04-29 14:30:14 --> Model "M_user" initialized
INFO - 2023-04-29 14:30:14 --> Model "M_produk" initialized
INFO - 2023-04-29 14:30:14 --> Controller Class Initialized
INFO - 2023-04-29 14:30:14 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_user_profile.php
INFO - 2023-04-29 14:30:14 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:30:14 --> Final output sent to browser
DEBUG - 2023-04-29 14:30:14 --> Total execution time: 0.1123
INFO - 2023-04-29 14:30:16 --> Config Class Initialized
INFO - 2023-04-29 14:30:16 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:30:16 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:30:16 --> Utf8 Class Initialized
INFO - 2023-04-29 14:30:16 --> URI Class Initialized
INFO - 2023-04-29 14:30:16 --> Router Class Initialized
INFO - 2023-04-29 14:30:16 --> Output Class Initialized
INFO - 2023-04-29 14:30:16 --> Security Class Initialized
DEBUG - 2023-04-29 14:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:30:16 --> Input Class Initialized
INFO - 2023-04-29 14:30:16 --> Language Class Initialized
INFO - 2023-04-29 14:30:16 --> Loader Class Initialized
INFO - 2023-04-29 14:30:16 --> Helper loaded: url_helper
INFO - 2023-04-29 14:30:16 --> Helper loaded: form_helper
INFO - 2023-04-29 14:30:16 --> Helper loaded: file_helper
INFO - 2023-04-29 14:30:16 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:30:16 --> Form Validation Class Initialized
INFO - 2023-04-29 14:30:16 --> Upload Class Initialized
INFO - 2023-04-29 14:30:16 --> Model "M_auth" initialized
INFO - 2023-04-29 14:30:16 --> Model "M_user" initialized
INFO - 2023-04-29 14:30:16 --> Model "M_produk" initialized
INFO - 2023-04-29 14:30:16 --> Controller Class Initialized
INFO - 2023-04-29 14:30:16 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:30:16 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:30:16 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:30:16 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:30:16 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:30:16 --> Model "M_bank" initialized
INFO - 2023-04-29 14:30:16 --> Model "M_pesan" initialized
ERROR - 2023-04-29 14:30:16 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 14:30:16 --> Config Class Initialized
INFO - 2023-04-29 14:30:16 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:30:16 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:30:16 --> Utf8 Class Initialized
INFO - 2023-04-29 14:30:16 --> URI Class Initialized
INFO - 2023-04-29 14:30:16 --> Router Class Initialized
INFO - 2023-04-29 14:30:16 --> Output Class Initialized
INFO - 2023-04-29 14:30:16 --> Security Class Initialized
DEBUG - 2023-04-29 14:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:30:16 --> Input Class Initialized
INFO - 2023-04-29 14:30:16 --> Language Class Initialized
INFO - 2023-04-29 14:30:16 --> Loader Class Initialized
INFO - 2023-04-29 14:30:16 --> Helper loaded: url_helper
INFO - 2023-04-29 14:30:16 --> Helper loaded: form_helper
INFO - 2023-04-29 14:30:16 --> Helper loaded: file_helper
INFO - 2023-04-29 14:30:16 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:30:16 --> Form Validation Class Initialized
INFO - 2023-04-29 14:30:16 --> Upload Class Initialized
INFO - 2023-04-29 14:30:16 --> Model "M_auth" initialized
INFO - 2023-04-29 14:30:16 --> Model "M_user" initialized
INFO - 2023-04-29 14:30:16 --> Model "M_produk" initialized
INFO - 2023-04-29 14:30:16 --> Controller Class Initialized
INFO - 2023-04-29 14:30:16 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/not_found.php
INFO - 2023-04-29 14:30:16 --> Final output sent to browser
DEBUG - 2023-04-29 14:30:16 --> Total execution time: 0.0921
INFO - 2023-04-29 14:30:18 --> Config Class Initialized
INFO - 2023-04-29 14:30:18 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:30:18 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:30:18 --> Utf8 Class Initialized
INFO - 2023-04-29 14:30:18 --> URI Class Initialized
INFO - 2023-04-29 14:30:18 --> Router Class Initialized
INFO - 2023-04-29 14:30:18 --> Output Class Initialized
INFO - 2023-04-29 14:30:18 --> Security Class Initialized
DEBUG - 2023-04-29 14:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:30:18 --> Input Class Initialized
INFO - 2023-04-29 14:30:18 --> Language Class Initialized
INFO - 2023-04-29 14:30:18 --> Loader Class Initialized
INFO - 2023-04-29 14:30:18 --> Helper loaded: url_helper
INFO - 2023-04-29 14:30:18 --> Helper loaded: form_helper
INFO - 2023-04-29 14:30:18 --> Helper loaded: file_helper
INFO - 2023-04-29 14:30:18 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:30:18 --> Form Validation Class Initialized
INFO - 2023-04-29 14:30:18 --> Upload Class Initialized
INFO - 2023-04-29 14:30:18 --> Model "M_auth" initialized
INFO - 2023-04-29 14:30:18 --> Model "M_user" initialized
INFO - 2023-04-29 14:30:18 --> Model "M_produk" initialized
INFO - 2023-04-29 14:30:18 --> Controller Class Initialized
INFO - 2023-04-29 14:30:18 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_user_profile.php
INFO - 2023-04-29 14:30:18 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:30:18 --> Final output sent to browser
DEBUG - 2023-04-29 14:30:18 --> Total execution time: 0.1352
INFO - 2023-04-29 14:30:22 --> Config Class Initialized
INFO - 2023-04-29 14:30:22 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:30:22 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:30:22 --> Utf8 Class Initialized
INFO - 2023-04-29 14:30:22 --> URI Class Initialized
INFO - 2023-04-29 14:30:22 --> Router Class Initialized
INFO - 2023-04-29 14:30:22 --> Output Class Initialized
INFO - 2023-04-29 14:30:22 --> Security Class Initialized
DEBUG - 2023-04-29 14:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:30:22 --> Input Class Initialized
INFO - 2023-04-29 14:30:22 --> Language Class Initialized
INFO - 2023-04-29 14:30:22 --> Loader Class Initialized
INFO - 2023-04-29 14:30:22 --> Helper loaded: url_helper
INFO - 2023-04-29 14:30:22 --> Helper loaded: form_helper
INFO - 2023-04-29 14:30:22 --> Helper loaded: file_helper
INFO - 2023-04-29 14:30:22 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:30:22 --> Form Validation Class Initialized
INFO - 2023-04-29 14:30:22 --> Upload Class Initialized
INFO - 2023-04-29 14:30:22 --> Model "M_auth" initialized
INFO - 2023-04-29 14:30:22 --> Model "M_user" initialized
INFO - 2023-04-29 14:30:22 --> Model "M_produk" initialized
INFO - 2023-04-29 14:30:22 --> Controller Class Initialized
INFO - 2023-04-29 14:30:22 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:30:22 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:30:22 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:30:22 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:30:22 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:30:22 --> Model "M_bank" initialized
INFO - 2023-04-29 14:30:22 --> Model "M_pesan" initialized
ERROR - 2023-04-29 14:30:22 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 14:30:22 --> Config Class Initialized
INFO - 2023-04-29 14:30:22 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:30:22 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:30:22 --> Utf8 Class Initialized
INFO - 2023-04-29 14:30:22 --> URI Class Initialized
INFO - 2023-04-29 14:30:22 --> Router Class Initialized
INFO - 2023-04-29 14:30:22 --> Output Class Initialized
INFO - 2023-04-29 14:30:22 --> Security Class Initialized
DEBUG - 2023-04-29 14:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:30:22 --> Input Class Initialized
INFO - 2023-04-29 14:30:22 --> Language Class Initialized
INFO - 2023-04-29 14:30:22 --> Loader Class Initialized
INFO - 2023-04-29 14:30:22 --> Helper loaded: url_helper
INFO - 2023-04-29 14:30:22 --> Helper loaded: form_helper
INFO - 2023-04-29 14:30:22 --> Helper loaded: file_helper
INFO - 2023-04-29 14:30:22 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:30:22 --> Form Validation Class Initialized
INFO - 2023-04-29 14:30:22 --> Upload Class Initialized
INFO - 2023-04-29 14:30:22 --> Model "M_auth" initialized
INFO - 2023-04-29 14:30:22 --> Model "M_user" initialized
INFO - 2023-04-29 14:30:22 --> Model "M_produk" initialized
INFO - 2023-04-29 14:30:22 --> Controller Class Initialized
INFO - 2023-04-29 14:30:22 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/not_found.php
INFO - 2023-04-29 14:30:22 --> Final output sent to browser
DEBUG - 2023-04-29 14:30:22 --> Total execution time: 0.0998
INFO - 2023-04-29 14:30:24 --> Config Class Initialized
INFO - 2023-04-29 14:30:24 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:30:24 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:30:24 --> Utf8 Class Initialized
INFO - 2023-04-29 14:30:24 --> URI Class Initialized
INFO - 2023-04-29 14:30:24 --> Router Class Initialized
INFO - 2023-04-29 14:30:24 --> Output Class Initialized
INFO - 2023-04-29 14:30:24 --> Security Class Initialized
DEBUG - 2023-04-29 14:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:30:24 --> Input Class Initialized
INFO - 2023-04-29 14:30:24 --> Language Class Initialized
INFO - 2023-04-29 14:30:24 --> Loader Class Initialized
INFO - 2023-04-29 14:30:24 --> Helper loaded: url_helper
INFO - 2023-04-29 14:30:24 --> Helper loaded: form_helper
INFO - 2023-04-29 14:30:24 --> Helper loaded: file_helper
INFO - 2023-04-29 14:30:24 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:30:24 --> Form Validation Class Initialized
INFO - 2023-04-29 14:30:24 --> Upload Class Initialized
INFO - 2023-04-29 14:30:24 --> Model "M_auth" initialized
INFO - 2023-04-29 14:30:24 --> Model "M_user" initialized
INFO - 2023-04-29 14:30:24 --> Model "M_produk" initialized
INFO - 2023-04-29 14:30:24 --> Controller Class Initialized
INFO - 2023-04-29 14:30:24 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_user_profile.php
INFO - 2023-04-29 14:30:24 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:30:24 --> Final output sent to browser
DEBUG - 2023-04-29 14:30:24 --> Total execution time: 0.1519
INFO - 2023-04-29 14:30:41 --> Config Class Initialized
INFO - 2023-04-29 14:30:41 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:30:41 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:30:41 --> Utf8 Class Initialized
INFO - 2023-04-29 14:30:41 --> URI Class Initialized
INFO - 2023-04-29 14:30:41 --> Router Class Initialized
INFO - 2023-04-29 14:30:41 --> Output Class Initialized
INFO - 2023-04-29 14:30:41 --> Security Class Initialized
DEBUG - 2023-04-29 14:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:30:41 --> Input Class Initialized
INFO - 2023-04-29 14:30:41 --> Language Class Initialized
INFO - 2023-04-29 14:30:41 --> Loader Class Initialized
INFO - 2023-04-29 14:30:41 --> Helper loaded: url_helper
INFO - 2023-04-29 14:30:41 --> Helper loaded: form_helper
INFO - 2023-04-29 14:30:42 --> Helper loaded: file_helper
INFO - 2023-04-29 14:30:42 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:30:42 --> Form Validation Class Initialized
INFO - 2023-04-29 14:30:42 --> Upload Class Initialized
INFO - 2023-04-29 14:30:42 --> Model "M_auth" initialized
INFO - 2023-04-29 14:30:42 --> Model "M_user" initialized
INFO - 2023-04-29 14:30:42 --> Model "M_produk" initialized
INFO - 2023-04-29 14:30:42 --> Controller Class Initialized
INFO - 2023-04-29 14:30:42 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_user_profile.php
INFO - 2023-04-29 14:30:42 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:30:42 --> Final output sent to browser
DEBUG - 2023-04-29 14:30:42 --> Total execution time: 0.1466
INFO - 2023-04-29 14:30:44 --> Config Class Initialized
INFO - 2023-04-29 14:30:44 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:30:44 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:30:44 --> Utf8 Class Initialized
INFO - 2023-04-29 14:30:44 --> URI Class Initialized
INFO - 2023-04-29 14:30:44 --> Router Class Initialized
INFO - 2023-04-29 14:30:44 --> Output Class Initialized
INFO - 2023-04-29 14:30:44 --> Security Class Initialized
DEBUG - 2023-04-29 14:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:30:44 --> Input Class Initialized
INFO - 2023-04-29 14:30:44 --> Language Class Initialized
INFO - 2023-04-29 14:30:44 --> Loader Class Initialized
INFO - 2023-04-29 14:30:44 --> Helper loaded: url_helper
INFO - 2023-04-29 14:30:44 --> Helper loaded: form_helper
INFO - 2023-04-29 14:30:44 --> Helper loaded: file_helper
INFO - 2023-04-29 14:30:44 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:30:44 --> Form Validation Class Initialized
INFO - 2023-04-29 14:30:44 --> Upload Class Initialized
INFO - 2023-04-29 14:30:44 --> Model "M_auth" initialized
INFO - 2023-04-29 14:30:44 --> Model "M_user" initialized
INFO - 2023-04-29 14:30:44 --> Model "M_produk" initialized
INFO - 2023-04-29 14:30:44 --> Controller Class Initialized
INFO - 2023-04-29 14:30:44 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:30:44 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:30:44 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:30:44 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:30:44 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:30:44 --> Model "M_bank" initialized
INFO - 2023-04-29 14:30:44 --> Model "M_pesan" initialized
ERROR - 2023-04-29 14:30:44 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 14:30:44 --> Config Class Initialized
INFO - 2023-04-29 14:30:44 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:30:44 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:30:44 --> Utf8 Class Initialized
INFO - 2023-04-29 14:30:44 --> URI Class Initialized
DEBUG - 2023-04-29 14:30:44 --> No URI present. Default controller set.
INFO - 2023-04-29 14:30:44 --> Router Class Initialized
INFO - 2023-04-29 14:30:44 --> Output Class Initialized
INFO - 2023-04-29 14:30:44 --> Security Class Initialized
DEBUG - 2023-04-29 14:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:30:44 --> Input Class Initialized
INFO - 2023-04-29 14:30:44 --> Language Class Initialized
INFO - 2023-04-29 14:30:44 --> Loader Class Initialized
INFO - 2023-04-29 14:30:44 --> Helper loaded: url_helper
INFO - 2023-04-29 14:30:44 --> Helper loaded: form_helper
INFO - 2023-04-29 14:30:44 --> Helper loaded: file_helper
INFO - 2023-04-29 14:30:44 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:30:44 --> Form Validation Class Initialized
INFO - 2023-04-29 14:30:44 --> Upload Class Initialized
INFO - 2023-04-29 14:30:44 --> Model "M_auth" initialized
INFO - 2023-04-29 14:30:44 --> Model "M_user" initialized
INFO - 2023-04-29 14:30:44 --> Model "M_produk" initialized
INFO - 2023-04-29 14:30:44 --> Controller Class Initialized
INFO - 2023-04-29 14:30:44 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:30:44 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:30:44 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:30:44 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:30:44 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:30:44 --> Model "M_bank" initialized
INFO - 2023-04-29 14:30:44 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:30:44 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:30:44 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/index.php
INFO - 2023-04-29 14:30:44 --> Final output sent to browser
DEBUG - 2023-04-29 14:30:44 --> Total execution time: 0.1144
INFO - 2023-04-29 14:30:54 --> Config Class Initialized
INFO - 2023-04-29 14:30:54 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:30:54 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:30:54 --> Utf8 Class Initialized
INFO - 2023-04-29 14:30:54 --> URI Class Initialized
INFO - 2023-04-29 14:30:54 --> Router Class Initialized
INFO - 2023-04-29 14:30:54 --> Output Class Initialized
INFO - 2023-04-29 14:30:54 --> Security Class Initialized
DEBUG - 2023-04-29 14:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:30:54 --> Input Class Initialized
INFO - 2023-04-29 14:30:54 --> Language Class Initialized
INFO - 2023-04-29 14:30:54 --> Loader Class Initialized
INFO - 2023-04-29 14:30:54 --> Helper loaded: url_helper
INFO - 2023-04-29 14:30:54 --> Helper loaded: form_helper
INFO - 2023-04-29 14:30:54 --> Helper loaded: file_helper
INFO - 2023-04-29 14:30:54 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:30:54 --> Form Validation Class Initialized
INFO - 2023-04-29 14:30:54 --> Upload Class Initialized
INFO - 2023-04-29 14:30:54 --> Model "M_auth" initialized
INFO - 2023-04-29 14:30:54 --> Model "M_user" initialized
INFO - 2023-04-29 14:30:54 --> Model "M_produk" initialized
INFO - 2023-04-29 14:30:54 --> Controller Class Initialized
INFO - 2023-04-29 14:30:54 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_user_profile.php
INFO - 2023-04-29 14:30:54 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:30:54 --> Final output sent to browser
DEBUG - 2023-04-29 14:30:54 --> Total execution time: 0.1333
INFO - 2023-04-29 14:30:59 --> Config Class Initialized
INFO - 2023-04-29 14:30:59 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:30:59 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:30:59 --> Utf8 Class Initialized
INFO - 2023-04-29 14:30:59 --> URI Class Initialized
INFO - 2023-04-29 14:30:59 --> Router Class Initialized
INFO - 2023-04-29 14:30:59 --> Output Class Initialized
INFO - 2023-04-29 14:30:59 --> Security Class Initialized
DEBUG - 2023-04-29 14:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:30:59 --> Input Class Initialized
INFO - 2023-04-29 14:30:59 --> Language Class Initialized
INFO - 2023-04-29 14:30:59 --> Loader Class Initialized
INFO - 2023-04-29 14:30:59 --> Helper loaded: url_helper
INFO - 2023-04-29 14:30:59 --> Helper loaded: form_helper
INFO - 2023-04-29 14:30:59 --> Helper loaded: file_helper
INFO - 2023-04-29 14:31:00 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:31:00 --> Form Validation Class Initialized
INFO - 2023-04-29 14:31:00 --> Upload Class Initialized
INFO - 2023-04-29 14:31:00 --> Model "M_auth" initialized
INFO - 2023-04-29 14:31:00 --> Model "M_user" initialized
INFO - 2023-04-29 14:31:00 --> Model "M_produk" initialized
INFO - 2023-04-29 14:31:00 --> Controller Class Initialized
INFO - 2023-04-29 14:31:00 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_user_profile.php
INFO - 2023-04-29 14:31:00 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:31:00 --> Final output sent to browser
DEBUG - 2023-04-29 14:31:00 --> Total execution time: 0.1467
INFO - 2023-04-29 14:31:02 --> Config Class Initialized
INFO - 2023-04-29 14:31:02 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:31:02 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:31:02 --> Utf8 Class Initialized
INFO - 2023-04-29 14:31:02 --> URI Class Initialized
INFO - 2023-04-29 14:31:02 --> Router Class Initialized
INFO - 2023-04-29 14:31:02 --> Output Class Initialized
INFO - 2023-04-29 14:31:02 --> Security Class Initialized
DEBUG - 2023-04-29 14:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:31:02 --> Input Class Initialized
INFO - 2023-04-29 14:31:02 --> Language Class Initialized
INFO - 2023-04-29 14:31:02 --> Loader Class Initialized
INFO - 2023-04-29 14:31:02 --> Helper loaded: url_helper
INFO - 2023-04-29 14:31:02 --> Helper loaded: form_helper
INFO - 2023-04-29 14:31:02 --> Helper loaded: file_helper
INFO - 2023-04-29 14:31:02 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:31:02 --> Form Validation Class Initialized
INFO - 2023-04-29 14:31:02 --> Upload Class Initialized
INFO - 2023-04-29 14:31:02 --> Model "M_auth" initialized
INFO - 2023-04-29 14:31:02 --> Model "M_user" initialized
INFO - 2023-04-29 14:31:02 --> Model "M_produk" initialized
INFO - 2023-04-29 14:31:02 --> Controller Class Initialized
INFO - 2023-04-29 14:31:02 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:31:02 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:31:02 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:31:02 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:31:02 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:31:02 --> Model "M_bank" initialized
INFO - 2023-04-29 14:31:02 --> Model "M_pesan" initialized
ERROR - 2023-04-29 14:31:02 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 14:31:02 --> Config Class Initialized
INFO - 2023-04-29 14:31:02 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:31:02 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:31:02 --> Utf8 Class Initialized
INFO - 2023-04-29 14:31:02 --> URI Class Initialized
INFO - 2023-04-29 14:31:02 --> Router Class Initialized
INFO - 2023-04-29 14:31:02 --> Output Class Initialized
INFO - 2023-04-29 14:31:02 --> Security Class Initialized
DEBUG - 2023-04-29 14:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:31:02 --> Input Class Initialized
INFO - 2023-04-29 14:31:02 --> Language Class Initialized
ERROR - 2023-04-29 14:31:02 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 14:31:05 --> Config Class Initialized
INFO - 2023-04-29 14:31:05 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:31:05 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:31:05 --> Utf8 Class Initialized
INFO - 2023-04-29 14:31:05 --> URI Class Initialized
INFO - 2023-04-29 14:31:05 --> Router Class Initialized
INFO - 2023-04-29 14:31:05 --> Output Class Initialized
INFO - 2023-04-29 14:31:05 --> Security Class Initialized
DEBUG - 2023-04-29 14:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:31:05 --> Input Class Initialized
INFO - 2023-04-29 14:31:05 --> Language Class Initialized
INFO - 2023-04-29 14:31:05 --> Loader Class Initialized
INFO - 2023-04-29 14:31:05 --> Helper loaded: url_helper
INFO - 2023-04-29 14:31:05 --> Helper loaded: form_helper
INFO - 2023-04-29 14:31:05 --> Helper loaded: file_helper
INFO - 2023-04-29 14:31:05 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:31:05 --> Form Validation Class Initialized
INFO - 2023-04-29 14:31:05 --> Upload Class Initialized
INFO - 2023-04-29 14:31:05 --> Model "M_auth" initialized
INFO - 2023-04-29 14:31:05 --> Model "M_user" initialized
INFO - 2023-04-29 14:31:05 --> Model "M_produk" initialized
INFO - 2023-04-29 14:31:05 --> Controller Class Initialized
INFO - 2023-04-29 14:31:05 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_user_profile.php
INFO - 2023-04-29 14:31:05 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:31:05 --> Final output sent to browser
DEBUG - 2023-04-29 14:31:05 --> Total execution time: 0.1215
INFO - 2023-04-29 14:31:09 --> Config Class Initialized
INFO - 2023-04-29 14:31:09 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:31:09 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:31:09 --> Utf8 Class Initialized
INFO - 2023-04-29 14:31:09 --> URI Class Initialized
INFO - 2023-04-29 14:31:09 --> Router Class Initialized
INFO - 2023-04-29 14:31:09 --> Output Class Initialized
INFO - 2023-04-29 14:31:09 --> Security Class Initialized
DEBUG - 2023-04-29 14:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:31:09 --> Input Class Initialized
INFO - 2023-04-29 14:31:09 --> Language Class Initialized
INFO - 2023-04-29 14:31:09 --> Loader Class Initialized
INFO - 2023-04-29 14:31:09 --> Helper loaded: url_helper
INFO - 2023-04-29 14:31:09 --> Helper loaded: form_helper
INFO - 2023-04-29 14:31:09 --> Helper loaded: file_helper
INFO - 2023-04-29 14:31:09 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:31:09 --> Form Validation Class Initialized
INFO - 2023-04-29 14:31:09 --> Upload Class Initialized
INFO - 2023-04-29 14:31:09 --> Model "M_auth" initialized
INFO - 2023-04-29 14:31:09 --> Model "M_user" initialized
INFO - 2023-04-29 14:31:09 --> Model "M_produk" initialized
INFO - 2023-04-29 14:31:09 --> Controller Class Initialized
INFO - 2023-04-29 14:31:09 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:31:09 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:31:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:31:09 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:31:09 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:31:09 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_transaksi_all.php
INFO - 2023-04-29 14:31:09 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:31:09 --> Final output sent to browser
DEBUG - 2023-04-29 14:31:09 --> Total execution time: 0.1323
INFO - 2023-04-29 14:31:11 --> Config Class Initialized
INFO - 2023-04-29 14:31:11 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:31:11 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:31:11 --> Utf8 Class Initialized
INFO - 2023-04-29 14:31:11 --> URI Class Initialized
INFO - 2023-04-29 14:31:11 --> Router Class Initialized
INFO - 2023-04-29 14:31:11 --> Output Class Initialized
INFO - 2023-04-29 14:31:11 --> Security Class Initialized
DEBUG - 2023-04-29 14:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:31:11 --> Input Class Initialized
INFO - 2023-04-29 14:31:11 --> Language Class Initialized
INFO - 2023-04-29 14:31:11 --> Loader Class Initialized
INFO - 2023-04-29 14:31:11 --> Helper loaded: url_helper
INFO - 2023-04-29 14:31:11 --> Helper loaded: form_helper
INFO - 2023-04-29 14:31:11 --> Helper loaded: file_helper
INFO - 2023-04-29 14:31:11 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:31:11 --> Form Validation Class Initialized
INFO - 2023-04-29 14:31:11 --> Upload Class Initialized
INFO - 2023-04-29 14:31:11 --> Model "M_auth" initialized
INFO - 2023-04-29 14:31:11 --> Model "M_user" initialized
INFO - 2023-04-29 14:31:11 --> Model "M_produk" initialized
INFO - 2023-04-29 14:31:11 --> Controller Class Initialized
INFO - 2023-04-29 14:31:11 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:31:11 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:31:11 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:31:11 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:31:11 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:31:11 --> Model "M_bank" initialized
INFO - 2023-04-29 14:31:11 --> Model "M_pesan" initialized
ERROR - 2023-04-29 14:31:11 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 14:31:11 --> Config Class Initialized
INFO - 2023-04-29 14:31:11 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:31:11 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:31:11 --> Utf8 Class Initialized
INFO - 2023-04-29 14:31:11 --> URI Class Initialized
INFO - 2023-04-29 14:31:11 --> Router Class Initialized
INFO - 2023-04-29 14:31:11 --> Output Class Initialized
INFO - 2023-04-29 14:31:11 --> Security Class Initialized
DEBUG - 2023-04-29 14:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:31:11 --> Input Class Initialized
INFO - 2023-04-29 14:31:11 --> Language Class Initialized
ERROR - 2023-04-29 14:31:11 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 14:31:22 --> Config Class Initialized
INFO - 2023-04-29 14:31:22 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:31:22 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:31:22 --> Utf8 Class Initialized
INFO - 2023-04-29 14:31:22 --> URI Class Initialized
INFO - 2023-04-29 14:31:22 --> Router Class Initialized
INFO - 2023-04-29 14:31:22 --> Output Class Initialized
INFO - 2023-04-29 14:31:22 --> Security Class Initialized
DEBUG - 2023-04-29 14:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:31:22 --> Input Class Initialized
INFO - 2023-04-29 14:31:22 --> Language Class Initialized
INFO - 2023-04-29 14:31:22 --> Loader Class Initialized
INFO - 2023-04-29 14:31:22 --> Helper loaded: url_helper
INFO - 2023-04-29 14:31:22 --> Helper loaded: form_helper
INFO - 2023-04-29 14:31:22 --> Helper loaded: file_helper
INFO - 2023-04-29 14:31:22 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:31:22 --> Form Validation Class Initialized
INFO - 2023-04-29 14:31:22 --> Upload Class Initialized
INFO - 2023-04-29 14:31:22 --> Model "M_auth" initialized
INFO - 2023-04-29 14:31:22 --> Model "M_user" initialized
INFO - 2023-04-29 14:31:22 --> Model "M_produk" initialized
INFO - 2023-04-29 14:31:22 --> Controller Class Initialized
INFO - 2023-04-29 14:31:22 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:31:22 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:31:22 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:31:22 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:31:22 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:31:22 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_transaksi_all.php
INFO - 2023-04-29 14:31:22 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:31:22 --> Final output sent to browser
DEBUG - 2023-04-29 14:31:22 --> Total execution time: 0.1358
INFO - 2023-04-29 14:31:48 --> Config Class Initialized
INFO - 2023-04-29 14:31:48 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:31:48 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:31:48 --> Utf8 Class Initialized
INFO - 2023-04-29 14:31:48 --> URI Class Initialized
INFO - 2023-04-29 14:31:48 --> Router Class Initialized
INFO - 2023-04-29 14:31:48 --> Output Class Initialized
INFO - 2023-04-29 14:31:48 --> Security Class Initialized
DEBUG - 2023-04-29 14:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:31:48 --> Input Class Initialized
INFO - 2023-04-29 14:31:48 --> Language Class Initialized
INFO - 2023-04-29 14:31:48 --> Loader Class Initialized
INFO - 2023-04-29 14:31:48 --> Helper loaded: url_helper
INFO - 2023-04-29 14:31:48 --> Helper loaded: form_helper
INFO - 2023-04-29 14:31:48 --> Helper loaded: file_helper
INFO - 2023-04-29 14:31:48 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:31:49 --> Form Validation Class Initialized
INFO - 2023-04-29 14:31:49 --> Upload Class Initialized
INFO - 2023-04-29 14:31:49 --> Model "M_auth" initialized
INFO - 2023-04-29 14:31:49 --> Model "M_user" initialized
INFO - 2023-04-29 14:31:49 --> Model "M_produk" initialized
INFO - 2023-04-29 14:31:49 --> Controller Class Initialized
INFO - 2023-04-29 14:31:49 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:31:49 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:31:49 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:31:49 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:31:49 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:31:49 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_transaksi_all.php
INFO - 2023-04-29 14:31:49 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:31:49 --> Final output sent to browser
DEBUG - 2023-04-29 14:31:49 --> Total execution time: 0.1606
INFO - 2023-04-29 14:31:50 --> Config Class Initialized
INFO - 2023-04-29 14:31:50 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:31:50 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:31:50 --> Utf8 Class Initialized
INFO - 2023-04-29 14:31:50 --> URI Class Initialized
INFO - 2023-04-29 14:31:50 --> Router Class Initialized
INFO - 2023-04-29 14:31:50 --> Output Class Initialized
INFO - 2023-04-29 14:31:50 --> Security Class Initialized
DEBUG - 2023-04-29 14:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:31:50 --> Input Class Initialized
INFO - 2023-04-29 14:31:50 --> Language Class Initialized
INFO - 2023-04-29 14:31:50 --> Loader Class Initialized
INFO - 2023-04-29 14:31:50 --> Helper loaded: url_helper
INFO - 2023-04-29 14:31:50 --> Helper loaded: form_helper
INFO - 2023-04-29 14:31:50 --> Helper loaded: file_helper
INFO - 2023-04-29 14:31:50 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:31:50 --> Form Validation Class Initialized
INFO - 2023-04-29 14:31:50 --> Upload Class Initialized
INFO - 2023-04-29 14:31:50 --> Model "M_auth" initialized
INFO - 2023-04-29 14:31:50 --> Model "M_user" initialized
INFO - 2023-04-29 14:31:50 --> Model "M_produk" initialized
INFO - 2023-04-29 14:31:50 --> Controller Class Initialized
INFO - 2023-04-29 14:31:50 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 14:31:50 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:31:50 --> Final output sent to browser
DEBUG - 2023-04-29 14:31:50 --> Total execution time: 0.1161
INFO - 2023-04-29 14:31:52 --> Config Class Initialized
INFO - 2023-04-29 14:31:52 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:31:52 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:31:52 --> Utf8 Class Initialized
INFO - 2023-04-29 14:31:52 --> URI Class Initialized
INFO - 2023-04-29 14:31:52 --> Router Class Initialized
INFO - 2023-04-29 14:31:52 --> Output Class Initialized
INFO - 2023-04-29 14:31:52 --> Security Class Initialized
DEBUG - 2023-04-29 14:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:31:52 --> Input Class Initialized
INFO - 2023-04-29 14:31:52 --> Language Class Initialized
INFO - 2023-04-29 14:31:52 --> Loader Class Initialized
INFO - 2023-04-29 14:31:52 --> Helper loaded: url_helper
INFO - 2023-04-29 14:31:52 --> Helper loaded: form_helper
INFO - 2023-04-29 14:31:52 --> Helper loaded: file_helper
INFO - 2023-04-29 14:31:52 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:31:52 --> Form Validation Class Initialized
INFO - 2023-04-29 14:31:52 --> Upload Class Initialized
INFO - 2023-04-29 14:31:52 --> Model "M_auth" initialized
INFO - 2023-04-29 14:31:52 --> Model "M_user" initialized
INFO - 2023-04-29 14:31:52 --> Model "M_produk" initialized
INFO - 2023-04-29 14:31:52 --> Controller Class Initialized
INFO - 2023-04-29 14:31:52 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_user_profile.php
INFO - 2023-04-29 14:31:52 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:31:52 --> Final output sent to browser
DEBUG - 2023-04-29 14:31:52 --> Total execution time: 0.1112
INFO - 2023-04-29 14:31:55 --> Config Class Initialized
INFO - 2023-04-29 14:31:55 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:31:55 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:31:55 --> Utf8 Class Initialized
INFO - 2023-04-29 14:31:55 --> URI Class Initialized
INFO - 2023-04-29 14:31:55 --> Router Class Initialized
INFO - 2023-04-29 14:31:55 --> Output Class Initialized
INFO - 2023-04-29 14:31:55 --> Security Class Initialized
DEBUG - 2023-04-29 14:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:31:55 --> Input Class Initialized
INFO - 2023-04-29 14:31:55 --> Language Class Initialized
ERROR - 2023-04-29 14:31:55 --> 404 Page Not Found: Home/produk
INFO - 2023-04-29 14:31:59 --> Config Class Initialized
INFO - 2023-04-29 14:31:59 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:31:59 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:31:59 --> Utf8 Class Initialized
INFO - 2023-04-29 14:31:59 --> URI Class Initialized
INFO - 2023-04-29 14:31:59 --> Router Class Initialized
INFO - 2023-04-29 14:31:59 --> Output Class Initialized
INFO - 2023-04-29 14:31:59 --> Security Class Initialized
DEBUG - 2023-04-29 14:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:31:59 --> Input Class Initialized
INFO - 2023-04-29 14:31:59 --> Language Class Initialized
INFO - 2023-04-29 14:31:59 --> Loader Class Initialized
INFO - 2023-04-29 14:31:59 --> Helper loaded: url_helper
INFO - 2023-04-29 14:31:59 --> Helper loaded: form_helper
INFO - 2023-04-29 14:31:59 --> Helper loaded: file_helper
INFO - 2023-04-29 14:31:59 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:31:59 --> Form Validation Class Initialized
INFO - 2023-04-29 14:31:59 --> Upload Class Initialized
INFO - 2023-04-29 14:31:59 --> Model "M_auth" initialized
INFO - 2023-04-29 14:31:59 --> Model "M_user" initialized
INFO - 2023-04-29 14:31:59 --> Model "M_produk" initialized
INFO - 2023-04-29 14:31:59 --> Controller Class Initialized
INFO - 2023-04-29 14:31:59 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_user_profile.php
INFO - 2023-04-29 14:31:59 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:31:59 --> Final output sent to browser
DEBUG - 2023-04-29 14:31:59 --> Total execution time: 0.1176
INFO - 2023-04-29 14:32:02 --> Config Class Initialized
INFO - 2023-04-29 14:32:02 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:32:02 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:32:02 --> Utf8 Class Initialized
INFO - 2023-04-29 14:32:02 --> URI Class Initialized
INFO - 2023-04-29 14:32:02 --> Router Class Initialized
INFO - 2023-04-29 14:32:02 --> Output Class Initialized
INFO - 2023-04-29 14:32:02 --> Security Class Initialized
DEBUG - 2023-04-29 14:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:32:02 --> Input Class Initialized
INFO - 2023-04-29 14:32:02 --> Language Class Initialized
INFO - 2023-04-29 14:32:02 --> Loader Class Initialized
INFO - 2023-04-29 14:32:02 --> Helper loaded: url_helper
INFO - 2023-04-29 14:32:02 --> Helper loaded: form_helper
INFO - 2023-04-29 14:32:02 --> Helper loaded: file_helper
INFO - 2023-04-29 14:32:02 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:32:02 --> Form Validation Class Initialized
INFO - 2023-04-29 14:32:02 --> Upload Class Initialized
INFO - 2023-04-29 14:32:02 --> Model "M_auth" initialized
INFO - 2023-04-29 14:32:02 --> Model "M_user" initialized
INFO - 2023-04-29 14:32:02 --> Model "M_produk" initialized
INFO - 2023-04-29 14:32:02 --> Controller Class Initialized
INFO - 2023-04-29 14:32:02 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_user_profile.php
INFO - 2023-04-29 14:32:02 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:32:02 --> Final output sent to browser
DEBUG - 2023-04-29 14:32:02 --> Total execution time: 0.1374
INFO - 2023-04-29 14:32:05 --> Config Class Initialized
INFO - 2023-04-29 14:32:05 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:32:05 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:32:05 --> Utf8 Class Initialized
INFO - 2023-04-29 14:32:05 --> URI Class Initialized
INFO - 2023-04-29 14:32:05 --> Router Class Initialized
INFO - 2023-04-29 14:32:05 --> Output Class Initialized
INFO - 2023-04-29 14:32:05 --> Security Class Initialized
DEBUG - 2023-04-29 14:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:32:05 --> Input Class Initialized
INFO - 2023-04-29 14:32:05 --> Language Class Initialized
INFO - 2023-04-29 14:32:05 --> Loader Class Initialized
INFO - 2023-04-29 14:32:05 --> Helper loaded: url_helper
INFO - 2023-04-29 14:32:05 --> Helper loaded: form_helper
INFO - 2023-04-29 14:32:05 --> Helper loaded: file_helper
INFO - 2023-04-29 14:32:05 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:32:05 --> Form Validation Class Initialized
INFO - 2023-04-29 14:32:05 --> Upload Class Initialized
INFO - 2023-04-29 14:32:05 --> Model "M_auth" initialized
INFO - 2023-04-29 14:32:05 --> Model "M_user" initialized
INFO - 2023-04-29 14:32:05 --> Model "M_produk" initialized
INFO - 2023-04-29 14:32:05 --> Controller Class Initialized
INFO - 2023-04-29 14:32:05 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:32:05 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:32:05 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:32:05 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:32:05 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:32:05 --> Model "M_bank" initialized
INFO - 2023-04-29 14:32:05 --> Model "M_pesan" initialized
ERROR - 2023-04-29 14:32:05 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 14:32:05 --> Config Class Initialized
INFO - 2023-04-29 14:32:05 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:32:05 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:32:05 --> Utf8 Class Initialized
INFO - 2023-04-29 14:32:05 --> URI Class Initialized
INFO - 2023-04-29 14:32:05 --> Router Class Initialized
INFO - 2023-04-29 14:32:05 --> Output Class Initialized
INFO - 2023-04-29 14:32:05 --> Security Class Initialized
DEBUG - 2023-04-29 14:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:32:05 --> Input Class Initialized
INFO - 2023-04-29 14:32:05 --> Language Class Initialized
ERROR - 2023-04-29 14:32:05 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 14:32:07 --> Config Class Initialized
INFO - 2023-04-29 14:32:07 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:32:07 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:32:07 --> Utf8 Class Initialized
INFO - 2023-04-29 14:32:07 --> URI Class Initialized
INFO - 2023-04-29 14:32:07 --> Router Class Initialized
INFO - 2023-04-29 14:32:07 --> Output Class Initialized
INFO - 2023-04-29 14:32:07 --> Security Class Initialized
DEBUG - 2023-04-29 14:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:32:07 --> Input Class Initialized
INFO - 2023-04-29 14:32:07 --> Language Class Initialized
INFO - 2023-04-29 14:32:07 --> Loader Class Initialized
INFO - 2023-04-29 14:32:07 --> Helper loaded: url_helper
INFO - 2023-04-29 14:32:07 --> Helper loaded: form_helper
INFO - 2023-04-29 14:32:07 --> Helper loaded: file_helper
INFO - 2023-04-29 14:32:07 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:32:07 --> Form Validation Class Initialized
INFO - 2023-04-29 14:32:07 --> Upload Class Initialized
INFO - 2023-04-29 14:32:07 --> Model "M_auth" initialized
INFO - 2023-04-29 14:32:07 --> Model "M_user" initialized
INFO - 2023-04-29 14:32:07 --> Model "M_produk" initialized
INFO - 2023-04-29 14:32:07 --> Controller Class Initialized
INFO - 2023-04-29 14:32:07 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_user_profile.php
INFO - 2023-04-29 14:32:07 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:32:07 --> Final output sent to browser
DEBUG - 2023-04-29 14:32:07 --> Total execution time: 0.1345
INFO - 2023-04-29 14:34:50 --> Config Class Initialized
INFO - 2023-04-29 14:34:50 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:34:50 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:34:50 --> Utf8 Class Initialized
INFO - 2023-04-29 14:34:50 --> URI Class Initialized
INFO - 2023-04-29 14:34:50 --> Router Class Initialized
INFO - 2023-04-29 14:34:50 --> Output Class Initialized
INFO - 2023-04-29 14:34:50 --> Security Class Initialized
DEBUG - 2023-04-29 14:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:34:50 --> Input Class Initialized
INFO - 2023-04-29 14:34:50 --> Language Class Initialized
INFO - 2023-04-29 14:34:50 --> Loader Class Initialized
INFO - 2023-04-29 14:34:50 --> Helper loaded: url_helper
INFO - 2023-04-29 14:34:50 --> Helper loaded: form_helper
INFO - 2023-04-29 14:34:50 --> Helper loaded: file_helper
INFO - 2023-04-29 14:34:50 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:34:50 --> Form Validation Class Initialized
INFO - 2023-04-29 14:34:50 --> Upload Class Initialized
INFO - 2023-04-29 14:34:50 --> Model "M_auth" initialized
INFO - 2023-04-29 14:34:50 --> Model "M_user" initialized
INFO - 2023-04-29 14:34:50 --> Model "M_produk" initialized
INFO - 2023-04-29 14:34:50 --> Controller Class Initialized
INFO - 2023-04-29 14:34:50 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_user_profile.php
INFO - 2023-04-29 14:34:50 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:34:50 --> Final output sent to browser
DEBUG - 2023-04-29 14:34:50 --> Total execution time: 0.1396
INFO - 2023-04-29 14:34:54 --> Config Class Initialized
INFO - 2023-04-29 14:34:54 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:34:54 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:34:54 --> Utf8 Class Initialized
INFO - 2023-04-29 14:34:54 --> URI Class Initialized
INFO - 2023-04-29 14:34:54 --> Router Class Initialized
INFO - 2023-04-29 14:34:54 --> Output Class Initialized
INFO - 2023-04-29 14:34:54 --> Security Class Initialized
DEBUG - 2023-04-29 14:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:34:54 --> Input Class Initialized
INFO - 2023-04-29 14:34:54 --> Language Class Initialized
INFO - 2023-04-29 14:34:54 --> Loader Class Initialized
INFO - 2023-04-29 14:34:54 --> Helper loaded: url_helper
INFO - 2023-04-29 14:34:54 --> Helper loaded: form_helper
INFO - 2023-04-29 14:34:54 --> Helper loaded: file_helper
INFO - 2023-04-29 14:34:54 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:34:54 --> Form Validation Class Initialized
INFO - 2023-04-29 14:34:54 --> Upload Class Initialized
INFO - 2023-04-29 14:34:54 --> Model "M_auth" initialized
INFO - 2023-04-29 14:34:54 --> Model "M_user" initialized
INFO - 2023-04-29 14:34:54 --> Model "M_produk" initialized
INFO - 2023-04-29 14:34:54 --> Controller Class Initialized
INFO - 2023-04-29 14:34:54 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_user_profile.php
INFO - 2023-04-29 14:34:54 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:34:54 --> Final output sent to browser
DEBUG - 2023-04-29 14:34:54 --> Total execution time: 0.1257
INFO - 2023-04-29 14:34:57 --> Config Class Initialized
INFO - 2023-04-29 14:34:57 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:34:57 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:34:57 --> Utf8 Class Initialized
INFO - 2023-04-29 14:34:57 --> URI Class Initialized
INFO - 2023-04-29 14:34:57 --> Router Class Initialized
INFO - 2023-04-29 14:34:57 --> Output Class Initialized
INFO - 2023-04-29 14:34:57 --> Security Class Initialized
DEBUG - 2023-04-29 14:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:34:57 --> Input Class Initialized
INFO - 2023-04-29 14:34:57 --> Language Class Initialized
INFO - 2023-04-29 14:34:57 --> Loader Class Initialized
INFO - 2023-04-29 14:34:57 --> Helper loaded: url_helper
INFO - 2023-04-29 14:34:57 --> Helper loaded: form_helper
INFO - 2023-04-29 14:34:57 --> Helper loaded: file_helper
INFO - 2023-04-29 14:34:57 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:34:57 --> Form Validation Class Initialized
INFO - 2023-04-29 14:34:57 --> Upload Class Initialized
INFO - 2023-04-29 14:34:57 --> Model "M_auth" initialized
INFO - 2023-04-29 14:34:57 --> Model "M_user" initialized
INFO - 2023-04-29 14:34:57 --> Model "M_produk" initialized
INFO - 2023-04-29 14:34:57 --> Controller Class Initialized
INFO - 2023-04-29 14:34:57 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_ganti_password.php
INFO - 2023-04-29 14:34:57 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:34:57 --> Final output sent to browser
DEBUG - 2023-04-29 14:34:57 --> Total execution time: 0.1070
INFO - 2023-04-29 14:34:59 --> Config Class Initialized
INFO - 2023-04-29 14:34:59 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:34:59 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:34:59 --> Utf8 Class Initialized
INFO - 2023-04-29 14:34:59 --> URI Class Initialized
INFO - 2023-04-29 14:34:59 --> Router Class Initialized
INFO - 2023-04-29 14:34:59 --> Output Class Initialized
INFO - 2023-04-29 14:34:59 --> Security Class Initialized
DEBUG - 2023-04-29 14:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:34:59 --> Input Class Initialized
INFO - 2023-04-29 14:34:59 --> Language Class Initialized
INFO - 2023-04-29 14:34:59 --> Loader Class Initialized
INFO - 2023-04-29 14:34:59 --> Helper loaded: url_helper
INFO - 2023-04-29 14:34:59 --> Helper loaded: form_helper
INFO - 2023-04-29 14:34:59 --> Helper loaded: file_helper
INFO - 2023-04-29 14:34:59 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:34:59 --> Form Validation Class Initialized
INFO - 2023-04-29 14:34:59 --> Upload Class Initialized
INFO - 2023-04-29 14:34:59 --> Model "M_auth" initialized
INFO - 2023-04-29 14:34:59 --> Model "M_user" initialized
INFO - 2023-04-29 14:34:59 --> Model "M_produk" initialized
INFO - 2023-04-29 14:34:59 --> Controller Class Initialized
INFO - 2023-04-29 14:34:59 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:34:59 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:34:59 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:34:59 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:34:59 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:34:59 --> Model "M_bank" initialized
INFO - 2023-04-29 14:34:59 --> Model "M_pesan" initialized
ERROR - 2023-04-29 14:34:59 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 14:34:59 --> Config Class Initialized
INFO - 2023-04-29 14:34:59 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:34:59 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:34:59 --> Utf8 Class Initialized
INFO - 2023-04-29 14:34:59 --> URI Class Initialized
INFO - 2023-04-29 14:34:59 --> Router Class Initialized
INFO - 2023-04-29 14:34:59 --> Output Class Initialized
INFO - 2023-04-29 14:34:59 --> Security Class Initialized
DEBUG - 2023-04-29 14:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:34:59 --> Input Class Initialized
INFO - 2023-04-29 14:34:59 --> Language Class Initialized
ERROR - 2023-04-29 14:34:59 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 14:35:02 --> Config Class Initialized
INFO - 2023-04-29 14:35:02 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:35:02 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:35:02 --> Utf8 Class Initialized
INFO - 2023-04-29 14:35:02 --> URI Class Initialized
INFO - 2023-04-29 14:35:02 --> Router Class Initialized
INFO - 2023-04-29 14:35:02 --> Output Class Initialized
INFO - 2023-04-29 14:35:02 --> Security Class Initialized
DEBUG - 2023-04-29 14:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:35:02 --> Input Class Initialized
INFO - 2023-04-29 14:35:02 --> Language Class Initialized
INFO - 2023-04-29 14:35:02 --> Loader Class Initialized
INFO - 2023-04-29 14:35:02 --> Helper loaded: url_helper
INFO - 2023-04-29 14:35:02 --> Helper loaded: form_helper
INFO - 2023-04-29 14:35:02 --> Helper loaded: file_helper
INFO - 2023-04-29 14:35:02 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:35:02 --> Form Validation Class Initialized
INFO - 2023-04-29 14:35:02 --> Upload Class Initialized
INFO - 2023-04-29 14:35:02 --> Model "M_auth" initialized
INFO - 2023-04-29 14:35:02 --> Model "M_user" initialized
INFO - 2023-04-29 14:35:02 --> Model "M_produk" initialized
INFO - 2023-04-29 14:35:02 --> Controller Class Initialized
INFO - 2023-04-29 14:35:02 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_ganti_password.php
INFO - 2023-04-29 14:35:02 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:35:02 --> Final output sent to browser
DEBUG - 2023-04-29 14:35:02 --> Total execution time: 0.1152
INFO - 2023-04-29 14:36:04 --> Config Class Initialized
INFO - 2023-04-29 14:36:04 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:36:04 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:36:04 --> Utf8 Class Initialized
INFO - 2023-04-29 14:36:04 --> URI Class Initialized
INFO - 2023-04-29 14:36:04 --> Router Class Initialized
INFO - 2023-04-29 14:36:04 --> Output Class Initialized
INFO - 2023-04-29 14:36:04 --> Security Class Initialized
DEBUG - 2023-04-29 14:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:36:04 --> Input Class Initialized
INFO - 2023-04-29 14:36:04 --> Language Class Initialized
INFO - 2023-04-29 14:36:04 --> Loader Class Initialized
INFO - 2023-04-29 14:36:04 --> Helper loaded: url_helper
INFO - 2023-04-29 14:36:04 --> Helper loaded: form_helper
INFO - 2023-04-29 14:36:04 --> Helper loaded: file_helper
INFO - 2023-04-29 14:36:04 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:36:04 --> Form Validation Class Initialized
INFO - 2023-04-29 14:36:05 --> Upload Class Initialized
INFO - 2023-04-29 14:36:05 --> Model "M_auth" initialized
INFO - 2023-04-29 14:36:05 --> Model "M_user" initialized
INFO - 2023-04-29 14:36:05 --> Model "M_produk" initialized
INFO - 2023-04-29 14:36:05 --> Controller Class Initialized
INFO - 2023-04-29 14:36:05 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_ganti_password.php
INFO - 2023-04-29 14:36:05 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:36:05 --> Final output sent to browser
DEBUG - 2023-04-29 14:36:05 --> Total execution time: 0.1281
INFO - 2023-04-29 14:36:06 --> Config Class Initialized
INFO - 2023-04-29 14:36:06 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:36:06 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:36:06 --> Utf8 Class Initialized
INFO - 2023-04-29 14:36:06 --> URI Class Initialized
INFO - 2023-04-29 14:36:06 --> Router Class Initialized
INFO - 2023-04-29 14:36:06 --> Output Class Initialized
INFO - 2023-04-29 14:36:06 --> Security Class Initialized
DEBUG - 2023-04-29 14:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:36:06 --> Input Class Initialized
INFO - 2023-04-29 14:36:06 --> Language Class Initialized
INFO - 2023-04-29 14:36:06 --> Loader Class Initialized
INFO - 2023-04-29 14:36:06 --> Helper loaded: url_helper
INFO - 2023-04-29 14:36:06 --> Helper loaded: form_helper
INFO - 2023-04-29 14:36:06 --> Helper loaded: file_helper
INFO - 2023-04-29 14:36:06 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:36:06 --> Form Validation Class Initialized
INFO - 2023-04-29 14:36:06 --> Upload Class Initialized
INFO - 2023-04-29 14:36:06 --> Model "M_auth" initialized
INFO - 2023-04-29 14:36:06 --> Model "M_user" initialized
INFO - 2023-04-29 14:36:06 --> Model "M_produk" initialized
INFO - 2023-04-29 14:36:06 --> Controller Class Initialized
INFO - 2023-04-29 14:36:06 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 14:36:06 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:36:06 --> Final output sent to browser
DEBUG - 2023-04-29 14:36:06 --> Total execution time: 0.1046
INFO - 2023-04-29 14:36:08 --> Config Class Initialized
INFO - 2023-04-29 14:36:08 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:36:08 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:36:08 --> Utf8 Class Initialized
INFO - 2023-04-29 14:36:08 --> URI Class Initialized
INFO - 2023-04-29 14:36:08 --> Router Class Initialized
INFO - 2023-04-29 14:36:08 --> Output Class Initialized
INFO - 2023-04-29 14:36:08 --> Security Class Initialized
DEBUG - 2023-04-29 14:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:36:08 --> Input Class Initialized
INFO - 2023-04-29 14:36:08 --> Language Class Initialized
INFO - 2023-04-29 14:36:08 --> Loader Class Initialized
INFO - 2023-04-29 14:36:08 --> Helper loaded: url_helper
INFO - 2023-04-29 14:36:08 --> Helper loaded: form_helper
INFO - 2023-04-29 14:36:08 --> Helper loaded: file_helper
INFO - 2023-04-29 14:36:08 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:36:08 --> Form Validation Class Initialized
INFO - 2023-04-29 14:36:08 --> Upload Class Initialized
INFO - 2023-04-29 14:36:08 --> Model "M_auth" initialized
INFO - 2023-04-29 14:36:08 --> Model "M_user" initialized
INFO - 2023-04-29 14:36:08 --> Model "M_produk" initialized
INFO - 2023-04-29 14:36:08 --> Controller Class Initialized
INFO - 2023-04-29 14:36:08 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:36:08 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:36:08 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:36:08 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:36:08 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:36:08 --> Model "M_bank" initialized
INFO - 2023-04-29 14:36:08 --> Model "M_pesan" initialized
ERROR - 2023-04-29 14:36:08 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 14:36:08 --> Config Class Initialized
INFO - 2023-04-29 14:36:08 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:36:08 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:36:08 --> Utf8 Class Initialized
INFO - 2023-04-29 14:36:08 --> URI Class Initialized
INFO - 2023-04-29 14:36:08 --> Router Class Initialized
INFO - 2023-04-29 14:36:08 --> Output Class Initialized
INFO - 2023-04-29 14:36:08 --> Security Class Initialized
DEBUG - 2023-04-29 14:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:36:08 --> Input Class Initialized
INFO - 2023-04-29 14:36:08 --> Language Class Initialized
ERROR - 2023-04-29 14:36:08 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 14:36:10 --> Config Class Initialized
INFO - 2023-04-29 14:36:10 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:36:10 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:36:10 --> Utf8 Class Initialized
INFO - 2023-04-29 14:36:10 --> URI Class Initialized
INFO - 2023-04-29 14:36:10 --> Router Class Initialized
INFO - 2023-04-29 14:36:10 --> Output Class Initialized
INFO - 2023-04-29 14:36:10 --> Security Class Initialized
DEBUG - 2023-04-29 14:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:36:10 --> Input Class Initialized
INFO - 2023-04-29 14:36:10 --> Language Class Initialized
INFO - 2023-04-29 14:36:10 --> Loader Class Initialized
INFO - 2023-04-29 14:36:10 --> Helper loaded: url_helper
INFO - 2023-04-29 14:36:10 --> Helper loaded: form_helper
INFO - 2023-04-29 14:36:10 --> Helper loaded: file_helper
INFO - 2023-04-29 14:36:10 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:36:10 --> Form Validation Class Initialized
INFO - 2023-04-29 14:36:10 --> Upload Class Initialized
INFO - 2023-04-29 14:36:10 --> Model "M_auth" initialized
INFO - 2023-04-29 14:36:10 --> Model "M_user" initialized
INFO - 2023-04-29 14:36:10 --> Model "M_produk" initialized
INFO - 2023-04-29 14:36:10 --> Controller Class Initialized
INFO - 2023-04-29 14:36:10 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 14:36:10 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:36:10 --> Final output sent to browser
DEBUG - 2023-04-29 14:36:10 --> Total execution time: 0.1282
INFO - 2023-04-29 14:36:14 --> Config Class Initialized
INFO - 2023-04-29 14:36:14 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:36:14 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:36:14 --> Utf8 Class Initialized
INFO - 2023-04-29 14:36:15 --> URI Class Initialized
DEBUG - 2023-04-29 14:36:15 --> No URI present. Default controller set.
INFO - 2023-04-29 14:36:15 --> Router Class Initialized
INFO - 2023-04-29 14:36:15 --> Output Class Initialized
INFO - 2023-04-29 14:36:15 --> Security Class Initialized
DEBUG - 2023-04-29 14:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:36:15 --> Input Class Initialized
INFO - 2023-04-29 14:36:15 --> Language Class Initialized
INFO - 2023-04-29 14:36:15 --> Loader Class Initialized
INFO - 2023-04-29 14:36:15 --> Helper loaded: url_helper
INFO - 2023-04-29 14:36:15 --> Helper loaded: form_helper
INFO - 2023-04-29 14:36:15 --> Helper loaded: file_helper
INFO - 2023-04-29 14:36:15 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:36:15 --> Form Validation Class Initialized
INFO - 2023-04-29 14:36:15 --> Upload Class Initialized
INFO - 2023-04-29 14:36:15 --> Model "M_auth" initialized
INFO - 2023-04-29 14:36:15 --> Model "M_user" initialized
INFO - 2023-04-29 14:36:15 --> Model "M_produk" initialized
INFO - 2023-04-29 14:36:15 --> Controller Class Initialized
INFO - 2023-04-29 14:36:15 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:36:15 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:36:15 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:36:15 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:36:15 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:36:15 --> Model "M_bank" initialized
INFO - 2023-04-29 14:36:15 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:36:15 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:36:15 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/index.php
INFO - 2023-04-29 14:36:15 --> Final output sent to browser
DEBUG - 2023-04-29 14:36:15 --> Total execution time: 0.1331
INFO - 2023-04-29 14:36:23 --> Config Class Initialized
INFO - 2023-04-29 14:36:23 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:36:23 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:36:23 --> Utf8 Class Initialized
INFO - 2023-04-29 14:36:23 --> URI Class Initialized
INFO - 2023-04-29 14:36:23 --> Router Class Initialized
INFO - 2023-04-29 14:36:23 --> Output Class Initialized
INFO - 2023-04-29 14:36:23 --> Security Class Initialized
DEBUG - 2023-04-29 14:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:36:23 --> Input Class Initialized
INFO - 2023-04-29 14:36:23 --> Language Class Initialized
ERROR - 2023-04-29 14:36:23 --> 404 Page Not Found: Skripsi4(an)/semakar-adventure
INFO - 2023-04-29 14:36:30 --> Config Class Initialized
INFO - 2023-04-29 14:36:30 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:36:30 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:36:30 --> Utf8 Class Initialized
INFO - 2023-04-29 14:36:30 --> URI Class Initialized
DEBUG - 2023-04-29 14:36:30 --> No URI present. Default controller set.
INFO - 2023-04-29 14:36:30 --> Router Class Initialized
INFO - 2023-04-29 14:36:30 --> Output Class Initialized
INFO - 2023-04-29 14:36:30 --> Security Class Initialized
DEBUG - 2023-04-29 14:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:36:30 --> Input Class Initialized
INFO - 2023-04-29 14:36:30 --> Language Class Initialized
INFO - 2023-04-29 14:36:30 --> Loader Class Initialized
INFO - 2023-04-29 14:36:30 --> Helper loaded: url_helper
INFO - 2023-04-29 14:36:30 --> Helper loaded: form_helper
INFO - 2023-04-29 14:36:30 --> Helper loaded: file_helper
INFO - 2023-04-29 14:36:30 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:36:30 --> Form Validation Class Initialized
INFO - 2023-04-29 14:36:30 --> Upload Class Initialized
INFO - 2023-04-29 14:36:30 --> Model "M_auth" initialized
INFO - 2023-04-29 14:36:30 --> Model "M_user" initialized
INFO - 2023-04-29 14:36:30 --> Model "M_produk" initialized
INFO - 2023-04-29 14:36:30 --> Controller Class Initialized
INFO - 2023-04-29 14:36:30 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:36:30 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:36:30 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:36:30 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:36:30 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:36:30 --> Model "M_bank" initialized
INFO - 2023-04-29 14:36:30 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:36:30 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:36:30 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/index.php
INFO - 2023-04-29 14:36:30 --> Final output sent to browser
DEBUG - 2023-04-29 14:36:30 --> Total execution time: 0.1272
INFO - 2023-04-29 14:36:33 --> Config Class Initialized
INFO - 2023-04-29 14:36:33 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:36:33 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:36:33 --> Utf8 Class Initialized
INFO - 2023-04-29 14:36:33 --> URI Class Initialized
INFO - 2023-04-29 14:36:33 --> Router Class Initialized
INFO - 2023-04-29 14:36:33 --> Output Class Initialized
INFO - 2023-04-29 14:36:33 --> Security Class Initialized
DEBUG - 2023-04-29 14:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:36:33 --> Input Class Initialized
INFO - 2023-04-29 14:36:33 --> Language Class Initialized
ERROR - 2023-04-29 14:36:33 --> 404 Page Not Found: Skripsi4(an)/semakar-adventure
INFO - 2023-04-29 14:36:35 --> Config Class Initialized
INFO - 2023-04-29 14:36:35 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:36:35 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:36:35 --> Utf8 Class Initialized
INFO - 2023-04-29 14:36:35 --> URI Class Initialized
DEBUG - 2023-04-29 14:36:35 --> No URI present. Default controller set.
INFO - 2023-04-29 14:36:35 --> Router Class Initialized
INFO - 2023-04-29 14:36:35 --> Output Class Initialized
INFO - 2023-04-29 14:36:35 --> Security Class Initialized
DEBUG - 2023-04-29 14:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:36:35 --> Input Class Initialized
INFO - 2023-04-29 14:36:35 --> Language Class Initialized
INFO - 2023-04-29 14:36:35 --> Loader Class Initialized
INFO - 2023-04-29 14:36:35 --> Helper loaded: url_helper
INFO - 2023-04-29 14:36:35 --> Helper loaded: form_helper
INFO - 2023-04-29 14:36:35 --> Helper loaded: file_helper
INFO - 2023-04-29 14:36:35 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:36:35 --> Form Validation Class Initialized
INFO - 2023-04-29 14:36:35 --> Upload Class Initialized
INFO - 2023-04-29 14:36:35 --> Model "M_auth" initialized
INFO - 2023-04-29 14:36:35 --> Model "M_user" initialized
INFO - 2023-04-29 14:36:35 --> Model "M_produk" initialized
INFO - 2023-04-29 14:36:35 --> Controller Class Initialized
INFO - 2023-04-29 14:36:35 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:36:35 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:36:35 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:36:35 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:36:35 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:36:35 --> Model "M_bank" initialized
INFO - 2023-04-29 14:36:35 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:36:35 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:36:35 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/index.php
INFO - 2023-04-29 14:36:35 --> Final output sent to browser
DEBUG - 2023-04-29 14:36:35 --> Total execution time: 0.1237
INFO - 2023-04-29 14:36:38 --> Config Class Initialized
INFO - 2023-04-29 14:36:38 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:36:38 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:36:38 --> Utf8 Class Initialized
INFO - 2023-04-29 14:36:38 --> URI Class Initialized
INFO - 2023-04-29 14:36:38 --> Router Class Initialized
INFO - 2023-04-29 14:36:38 --> Output Class Initialized
INFO - 2023-04-29 14:36:38 --> Security Class Initialized
DEBUG - 2023-04-29 14:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:36:38 --> Input Class Initialized
INFO - 2023-04-29 14:36:38 --> Language Class Initialized
ERROR - 2023-04-29 14:36:38 --> 404 Page Not Found: Skripsi4(an)/semakar-adventure
INFO - 2023-04-29 14:36:41 --> Config Class Initialized
INFO - 2023-04-29 14:36:41 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:36:41 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:36:41 --> Utf8 Class Initialized
INFO - 2023-04-29 14:36:41 --> URI Class Initialized
INFO - 2023-04-29 14:36:41 --> Router Class Initialized
INFO - 2023-04-29 14:36:41 --> Output Class Initialized
INFO - 2023-04-29 14:36:41 --> Security Class Initialized
DEBUG - 2023-04-29 14:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:36:41 --> Input Class Initialized
INFO - 2023-04-29 14:36:41 --> Language Class Initialized
ERROR - 2023-04-29 14:36:41 --> 404 Page Not Found: Skripsi4(an)/semakar-adventure
INFO - 2023-04-29 14:36:41 --> Config Class Initialized
INFO - 2023-04-29 14:36:41 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:36:41 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:36:41 --> Utf8 Class Initialized
INFO - 2023-04-29 14:36:41 --> URI Class Initialized
INFO - 2023-04-29 14:36:41 --> Router Class Initialized
INFO - 2023-04-29 14:36:41 --> Output Class Initialized
INFO - 2023-04-29 14:36:41 --> Security Class Initialized
DEBUG - 2023-04-29 14:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:36:41 --> Input Class Initialized
INFO - 2023-04-29 14:36:41 --> Language Class Initialized
ERROR - 2023-04-29 14:36:41 --> 404 Page Not Found: Skripsi4(an)/semakar-adventure
INFO - 2023-04-29 14:36:42 --> Config Class Initialized
INFO - 2023-04-29 14:36:42 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:36:42 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:36:42 --> Utf8 Class Initialized
INFO - 2023-04-29 14:36:42 --> URI Class Initialized
INFO - 2023-04-29 14:36:42 --> Router Class Initialized
INFO - 2023-04-29 14:36:42 --> Output Class Initialized
INFO - 2023-04-29 14:36:42 --> Security Class Initialized
DEBUG - 2023-04-29 14:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:36:42 --> Input Class Initialized
INFO - 2023-04-29 14:36:42 --> Language Class Initialized
ERROR - 2023-04-29 14:36:42 --> 404 Page Not Found: Skripsi4(an)/semakar-adventure
INFO - 2023-04-29 14:36:42 --> Config Class Initialized
INFO - 2023-04-29 14:36:42 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:36:42 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:36:42 --> Utf8 Class Initialized
INFO - 2023-04-29 14:36:42 --> URI Class Initialized
INFO - 2023-04-29 14:36:42 --> Router Class Initialized
INFO - 2023-04-29 14:36:42 --> Output Class Initialized
INFO - 2023-04-29 14:36:42 --> Security Class Initialized
DEBUG - 2023-04-29 14:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:36:42 --> Input Class Initialized
INFO - 2023-04-29 14:36:42 --> Language Class Initialized
ERROR - 2023-04-29 14:36:42 --> 404 Page Not Found: Skripsi4(an)/semakar-adventure
INFO - 2023-04-29 14:36:42 --> Config Class Initialized
INFO - 2023-04-29 14:36:42 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:36:42 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:36:42 --> Utf8 Class Initialized
INFO - 2023-04-29 14:36:42 --> URI Class Initialized
INFO - 2023-04-29 14:36:42 --> Router Class Initialized
INFO - 2023-04-29 14:36:42 --> Output Class Initialized
INFO - 2023-04-29 14:36:42 --> Security Class Initialized
DEBUG - 2023-04-29 14:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:36:42 --> Input Class Initialized
INFO - 2023-04-29 14:36:42 --> Language Class Initialized
ERROR - 2023-04-29 14:36:42 --> 404 Page Not Found: Skripsi4(an)/semakar-adventure
INFO - 2023-04-29 14:36:42 --> Config Class Initialized
INFO - 2023-04-29 14:36:42 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:36:42 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:36:42 --> Utf8 Class Initialized
INFO - 2023-04-29 14:36:42 --> URI Class Initialized
INFO - 2023-04-29 14:36:42 --> Router Class Initialized
INFO - 2023-04-29 14:36:42 --> Output Class Initialized
INFO - 2023-04-29 14:36:42 --> Security Class Initialized
DEBUG - 2023-04-29 14:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:36:42 --> Input Class Initialized
INFO - 2023-04-29 14:36:42 --> Language Class Initialized
ERROR - 2023-04-29 14:36:42 --> 404 Page Not Found: Skripsi4(an)/semakar-adventure
INFO - 2023-04-29 14:36:43 --> Config Class Initialized
INFO - 2023-04-29 14:36:43 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:36:43 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:36:43 --> Utf8 Class Initialized
INFO - 2023-04-29 14:36:43 --> URI Class Initialized
INFO - 2023-04-29 14:36:43 --> Router Class Initialized
INFO - 2023-04-29 14:36:43 --> Output Class Initialized
INFO - 2023-04-29 14:36:43 --> Security Class Initialized
DEBUG - 2023-04-29 14:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:36:43 --> Input Class Initialized
INFO - 2023-04-29 14:36:43 --> Language Class Initialized
ERROR - 2023-04-29 14:36:43 --> 404 Page Not Found: Skripsi4(an)/semakar-adventure
INFO - 2023-04-29 14:36:43 --> Config Class Initialized
INFO - 2023-04-29 14:36:43 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:36:43 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:36:43 --> Utf8 Class Initialized
INFO - 2023-04-29 14:36:43 --> URI Class Initialized
INFO - 2023-04-29 14:36:43 --> Router Class Initialized
INFO - 2023-04-29 14:36:43 --> Output Class Initialized
INFO - 2023-04-29 14:36:43 --> Security Class Initialized
DEBUG - 2023-04-29 14:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:36:43 --> Input Class Initialized
INFO - 2023-04-29 14:36:43 --> Language Class Initialized
ERROR - 2023-04-29 14:36:43 --> 404 Page Not Found: Skripsi4(an)/semakar-adventure
INFO - 2023-04-29 14:36:43 --> Config Class Initialized
INFO - 2023-04-29 14:36:43 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:36:43 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:36:43 --> Utf8 Class Initialized
INFO - 2023-04-29 14:36:43 --> URI Class Initialized
INFO - 2023-04-29 14:36:43 --> Router Class Initialized
INFO - 2023-04-29 14:36:43 --> Output Class Initialized
INFO - 2023-04-29 14:36:43 --> Security Class Initialized
DEBUG - 2023-04-29 14:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:36:43 --> Input Class Initialized
INFO - 2023-04-29 14:36:43 --> Language Class Initialized
ERROR - 2023-04-29 14:36:43 --> 404 Page Not Found: Skripsi4(an)/semakar-adventure
INFO - 2023-04-29 14:36:48 --> Config Class Initialized
INFO - 2023-04-29 14:36:48 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:36:48 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:36:48 --> Utf8 Class Initialized
INFO - 2023-04-29 14:36:48 --> URI Class Initialized
DEBUG - 2023-04-29 14:36:48 --> No URI present. Default controller set.
INFO - 2023-04-29 14:36:48 --> Router Class Initialized
INFO - 2023-04-29 14:36:48 --> Output Class Initialized
INFO - 2023-04-29 14:36:48 --> Security Class Initialized
DEBUG - 2023-04-29 14:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:36:48 --> Input Class Initialized
INFO - 2023-04-29 14:36:48 --> Language Class Initialized
INFO - 2023-04-29 14:36:48 --> Loader Class Initialized
INFO - 2023-04-29 14:36:48 --> Helper loaded: url_helper
INFO - 2023-04-29 14:36:48 --> Helper loaded: form_helper
INFO - 2023-04-29 14:36:48 --> Helper loaded: file_helper
INFO - 2023-04-29 14:36:48 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:36:48 --> Form Validation Class Initialized
INFO - 2023-04-29 14:36:48 --> Upload Class Initialized
INFO - 2023-04-29 14:36:48 --> Model "M_auth" initialized
INFO - 2023-04-29 14:36:48 --> Model "M_user" initialized
INFO - 2023-04-29 14:36:48 --> Model "M_produk" initialized
INFO - 2023-04-29 14:36:48 --> Controller Class Initialized
INFO - 2023-04-29 14:36:48 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:36:48 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:36:48 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:36:48 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:36:48 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:36:48 --> Model "M_bank" initialized
INFO - 2023-04-29 14:36:48 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:36:48 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:36:48 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/index.php
INFO - 2023-04-29 14:36:48 --> Final output sent to browser
DEBUG - 2023-04-29 14:36:48 --> Total execution time: 0.1350
INFO - 2023-04-29 14:37:03 --> Config Class Initialized
INFO - 2023-04-29 14:37:03 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:37:03 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:37:03 --> Utf8 Class Initialized
INFO - 2023-04-29 14:37:03 --> URI Class Initialized
DEBUG - 2023-04-29 14:37:03 --> No URI present. Default controller set.
INFO - 2023-04-29 14:37:03 --> Router Class Initialized
INFO - 2023-04-29 14:37:03 --> Output Class Initialized
INFO - 2023-04-29 14:37:03 --> Security Class Initialized
DEBUG - 2023-04-29 14:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:37:03 --> Input Class Initialized
INFO - 2023-04-29 14:37:03 --> Language Class Initialized
INFO - 2023-04-29 14:37:03 --> Loader Class Initialized
INFO - 2023-04-29 14:37:03 --> Helper loaded: url_helper
INFO - 2023-04-29 14:37:03 --> Helper loaded: form_helper
INFO - 2023-04-29 14:37:03 --> Helper loaded: file_helper
INFO - 2023-04-29 14:37:03 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:37:03 --> Form Validation Class Initialized
INFO - 2023-04-29 14:37:03 --> Upload Class Initialized
INFO - 2023-04-29 14:37:03 --> Model "M_auth" initialized
INFO - 2023-04-29 14:37:03 --> Model "M_user" initialized
INFO - 2023-04-29 14:37:04 --> Model "M_produk" initialized
INFO - 2023-04-29 14:37:04 --> Controller Class Initialized
INFO - 2023-04-29 14:37:04 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:37:04 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:37:04 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:37:04 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:37:04 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:37:04 --> Model "M_bank" initialized
INFO - 2023-04-29 14:37:04 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:37:04 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:37:04 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/index.php
INFO - 2023-04-29 14:37:04 --> Final output sent to browser
DEBUG - 2023-04-29 14:37:04 --> Total execution time: 0.1814
INFO - 2023-04-29 14:37:07 --> Config Class Initialized
INFO - 2023-04-29 14:37:07 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:37:07 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:37:07 --> Utf8 Class Initialized
INFO - 2023-04-29 14:37:07 --> URI Class Initialized
INFO - 2023-04-29 14:37:07 --> Router Class Initialized
INFO - 2023-04-29 14:37:07 --> Output Class Initialized
INFO - 2023-04-29 14:37:07 --> Security Class Initialized
DEBUG - 2023-04-29 14:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:37:07 --> Input Class Initialized
INFO - 2023-04-29 14:37:07 --> Language Class Initialized
ERROR - 2023-04-29 14:37:07 --> 404 Page Not Found: Skripsi4(an)/semakar-adventure
INFO - 2023-04-29 14:37:09 --> Config Class Initialized
INFO - 2023-04-29 14:37:09 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:37:09 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:37:09 --> Utf8 Class Initialized
INFO - 2023-04-29 14:37:09 --> URI Class Initialized
DEBUG - 2023-04-29 14:37:09 --> No URI present. Default controller set.
INFO - 2023-04-29 14:37:09 --> Router Class Initialized
INFO - 2023-04-29 14:37:09 --> Output Class Initialized
INFO - 2023-04-29 14:37:09 --> Security Class Initialized
DEBUG - 2023-04-29 14:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:37:09 --> Input Class Initialized
INFO - 2023-04-29 14:37:09 --> Language Class Initialized
INFO - 2023-04-29 14:37:09 --> Loader Class Initialized
INFO - 2023-04-29 14:37:09 --> Helper loaded: url_helper
INFO - 2023-04-29 14:37:09 --> Helper loaded: form_helper
INFO - 2023-04-29 14:37:09 --> Helper loaded: file_helper
INFO - 2023-04-29 14:37:09 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:37:09 --> Form Validation Class Initialized
INFO - 2023-04-29 14:37:09 --> Upload Class Initialized
INFO - 2023-04-29 14:37:09 --> Model "M_auth" initialized
INFO - 2023-04-29 14:37:09 --> Model "M_user" initialized
INFO - 2023-04-29 14:37:09 --> Model "M_produk" initialized
INFO - 2023-04-29 14:37:09 --> Controller Class Initialized
INFO - 2023-04-29 14:37:09 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:37:09 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:37:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:37:09 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:37:09 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:37:09 --> Model "M_bank" initialized
INFO - 2023-04-29 14:37:09 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:37:09 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:37:09 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/index.php
INFO - 2023-04-29 14:37:09 --> Final output sent to browser
DEBUG - 2023-04-29 14:37:09 --> Total execution time: 0.1340
INFO - 2023-04-29 14:37:19 --> Config Class Initialized
INFO - 2023-04-29 14:37:19 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:37:19 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:37:19 --> Utf8 Class Initialized
INFO - 2023-04-29 14:37:19 --> URI Class Initialized
DEBUG - 2023-04-29 14:37:19 --> No URI present. Default controller set.
INFO - 2023-04-29 14:37:19 --> Router Class Initialized
INFO - 2023-04-29 14:37:19 --> Output Class Initialized
INFO - 2023-04-29 14:37:19 --> Security Class Initialized
DEBUG - 2023-04-29 14:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:37:19 --> Input Class Initialized
INFO - 2023-04-29 14:37:19 --> Language Class Initialized
INFO - 2023-04-29 14:37:19 --> Loader Class Initialized
INFO - 2023-04-29 14:37:19 --> Helper loaded: url_helper
INFO - 2023-04-29 14:37:19 --> Helper loaded: form_helper
INFO - 2023-04-29 14:37:19 --> Helper loaded: file_helper
INFO - 2023-04-29 14:37:19 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:37:19 --> Form Validation Class Initialized
INFO - 2023-04-29 14:37:19 --> Upload Class Initialized
INFO - 2023-04-29 14:37:19 --> Model "M_auth" initialized
INFO - 2023-04-29 14:37:19 --> Model "M_user" initialized
INFO - 2023-04-29 14:37:19 --> Model "M_produk" initialized
INFO - 2023-04-29 14:37:19 --> Controller Class Initialized
INFO - 2023-04-29 14:37:19 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:37:19 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:37:19 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:37:19 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:37:19 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:37:19 --> Model "M_bank" initialized
INFO - 2023-04-29 14:37:19 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:37:19 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:37:19 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/index.php
INFO - 2023-04-29 14:37:19 --> Final output sent to browser
DEBUG - 2023-04-29 14:37:19 --> Total execution time: 0.1639
INFO - 2023-04-29 14:37:41 --> Config Class Initialized
INFO - 2023-04-29 14:37:41 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:37:41 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:37:42 --> Utf8 Class Initialized
INFO - 2023-04-29 14:37:42 --> URI Class Initialized
DEBUG - 2023-04-29 14:37:42 --> No URI present. Default controller set.
INFO - 2023-04-29 14:37:42 --> Router Class Initialized
INFO - 2023-04-29 14:37:42 --> Output Class Initialized
INFO - 2023-04-29 14:37:42 --> Security Class Initialized
DEBUG - 2023-04-29 14:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:37:42 --> Input Class Initialized
INFO - 2023-04-29 14:37:42 --> Language Class Initialized
INFO - 2023-04-29 14:37:42 --> Loader Class Initialized
INFO - 2023-04-29 14:37:42 --> Helper loaded: url_helper
INFO - 2023-04-29 14:37:42 --> Helper loaded: form_helper
INFO - 2023-04-29 14:37:42 --> Helper loaded: file_helper
INFO - 2023-04-29 14:37:42 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:37:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:37:42 --> Form Validation Class Initialized
INFO - 2023-04-29 14:37:42 --> Upload Class Initialized
INFO - 2023-04-29 14:37:42 --> Model "M_auth" initialized
INFO - 2023-04-29 14:37:42 --> Model "M_user" initialized
INFO - 2023-04-29 14:37:42 --> Model "M_produk" initialized
INFO - 2023-04-29 14:37:42 --> Controller Class Initialized
INFO - 2023-04-29 14:37:42 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:37:42 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:37:42 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:37:42 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:37:42 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:37:42 --> Model "M_bank" initialized
INFO - 2023-04-29 14:37:42 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:37:42 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:37:42 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/index.php
INFO - 2023-04-29 14:37:42 --> Final output sent to browser
DEBUG - 2023-04-29 14:37:42 --> Total execution time: 0.1247
INFO - 2023-04-29 14:37:51 --> Config Class Initialized
INFO - 2023-04-29 14:37:51 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:37:51 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:37:51 --> Utf8 Class Initialized
INFO - 2023-04-29 14:37:51 --> URI Class Initialized
INFO - 2023-04-29 14:37:51 --> Router Class Initialized
INFO - 2023-04-29 14:37:51 --> Output Class Initialized
INFO - 2023-04-29 14:37:51 --> Security Class Initialized
DEBUG - 2023-04-29 14:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:37:51 --> Input Class Initialized
INFO - 2023-04-29 14:37:51 --> Language Class Initialized
ERROR - 2023-04-29 14:37:51 --> 404 Page Not Found: Skripsi4(an)/semakar-adventure
INFO - 2023-04-29 14:37:53 --> Config Class Initialized
INFO - 2023-04-29 14:37:53 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:37:53 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:37:53 --> Utf8 Class Initialized
INFO - 2023-04-29 14:37:53 --> URI Class Initialized
DEBUG - 2023-04-29 14:37:53 --> No URI present. Default controller set.
INFO - 2023-04-29 14:37:53 --> Router Class Initialized
INFO - 2023-04-29 14:37:53 --> Output Class Initialized
INFO - 2023-04-29 14:37:53 --> Security Class Initialized
DEBUG - 2023-04-29 14:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:37:53 --> Input Class Initialized
INFO - 2023-04-29 14:37:53 --> Language Class Initialized
INFO - 2023-04-29 14:37:53 --> Loader Class Initialized
INFO - 2023-04-29 14:37:53 --> Helper loaded: url_helper
INFO - 2023-04-29 14:37:53 --> Helper loaded: form_helper
INFO - 2023-04-29 14:37:53 --> Helper loaded: file_helper
INFO - 2023-04-29 14:37:53 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:37:53 --> Form Validation Class Initialized
INFO - 2023-04-29 14:37:53 --> Upload Class Initialized
INFO - 2023-04-29 14:37:53 --> Model "M_auth" initialized
INFO - 2023-04-29 14:37:53 --> Model "M_user" initialized
INFO - 2023-04-29 14:37:53 --> Model "M_produk" initialized
INFO - 2023-04-29 14:37:53 --> Controller Class Initialized
INFO - 2023-04-29 14:37:53 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:37:53 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:37:53 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:37:53 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:37:53 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:37:53 --> Model "M_bank" initialized
INFO - 2023-04-29 14:37:53 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:37:53 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:37:53 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/index.php
INFO - 2023-04-29 14:37:53 --> Final output sent to browser
DEBUG - 2023-04-29 14:37:53 --> Total execution time: 0.1416
INFO - 2023-04-29 14:37:55 --> Config Class Initialized
INFO - 2023-04-29 14:37:55 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:37:55 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:37:55 --> Utf8 Class Initialized
INFO - 2023-04-29 14:37:55 --> URI Class Initialized
INFO - 2023-04-29 14:37:55 --> Router Class Initialized
INFO - 2023-04-29 14:37:55 --> Output Class Initialized
INFO - 2023-04-29 14:37:55 --> Security Class Initialized
DEBUG - 2023-04-29 14:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:37:55 --> Input Class Initialized
INFO - 2023-04-29 14:37:55 --> Language Class Initialized
INFO - 2023-04-29 14:37:55 --> Loader Class Initialized
INFO - 2023-04-29 14:37:55 --> Helper loaded: url_helper
INFO - 2023-04-29 14:37:55 --> Helper loaded: form_helper
INFO - 2023-04-29 14:37:55 --> Helper loaded: file_helper
INFO - 2023-04-29 14:37:55 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:37:55 --> Form Validation Class Initialized
INFO - 2023-04-29 14:37:55 --> Upload Class Initialized
INFO - 2023-04-29 14:37:55 --> Model "M_auth" initialized
INFO - 2023-04-29 14:37:55 --> Model "M_user" initialized
INFO - 2023-04-29 14:37:55 --> Model "M_produk" initialized
INFO - 2023-04-29 14:37:55 --> Controller Class Initialized
INFO - 2023-04-29 14:37:55 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_login.php
INFO - 2023-04-29 14:37:55 --> Final output sent to browser
DEBUG - 2023-04-29 14:37:55 --> Total execution time: 0.1346
INFO - 2023-04-29 14:38:05 --> Config Class Initialized
INFO - 2023-04-29 14:38:05 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:38:05 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:38:05 --> Utf8 Class Initialized
INFO - 2023-04-29 14:38:05 --> URI Class Initialized
INFO - 2023-04-29 14:38:05 --> Router Class Initialized
INFO - 2023-04-29 14:38:06 --> Output Class Initialized
INFO - 2023-04-29 14:38:06 --> Security Class Initialized
DEBUG - 2023-04-29 14:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:38:06 --> Input Class Initialized
INFO - 2023-04-29 14:38:06 --> Language Class Initialized
INFO - 2023-04-29 14:38:06 --> Loader Class Initialized
INFO - 2023-04-29 14:38:06 --> Helper loaded: url_helper
INFO - 2023-04-29 14:38:06 --> Helper loaded: form_helper
INFO - 2023-04-29 14:38:06 --> Helper loaded: file_helper
INFO - 2023-04-29 14:38:06 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:38:06 --> Form Validation Class Initialized
INFO - 2023-04-29 14:38:06 --> Upload Class Initialized
INFO - 2023-04-29 14:38:06 --> Model "M_auth" initialized
INFO - 2023-04-29 14:38:06 --> Model "M_user" initialized
INFO - 2023-04-29 14:38:06 --> Model "M_produk" initialized
INFO - 2023-04-29 14:38:06 --> Controller Class Initialized
INFO - 2023-04-29 14:38:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-04-29 14:38:06 --> Config Class Initialized
INFO - 2023-04-29 14:38:06 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:38:06 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:38:06 --> Utf8 Class Initialized
INFO - 2023-04-29 14:38:06 --> URI Class Initialized
INFO - 2023-04-29 14:38:06 --> Router Class Initialized
INFO - 2023-04-29 14:38:06 --> Output Class Initialized
INFO - 2023-04-29 14:38:06 --> Security Class Initialized
DEBUG - 2023-04-29 14:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:38:06 --> Input Class Initialized
INFO - 2023-04-29 14:38:06 --> Language Class Initialized
INFO - 2023-04-29 14:38:06 --> Loader Class Initialized
INFO - 2023-04-29 14:38:06 --> Helper loaded: url_helper
INFO - 2023-04-29 14:38:06 --> Helper loaded: form_helper
INFO - 2023-04-29 14:38:06 --> Helper loaded: file_helper
INFO - 2023-04-29 14:38:06 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:38:06 --> Form Validation Class Initialized
INFO - 2023-04-29 14:38:06 --> Upload Class Initialized
INFO - 2023-04-29 14:38:06 --> Model "M_auth" initialized
INFO - 2023-04-29 14:38:06 --> Model "M_user" initialized
INFO - 2023-04-29 14:38:06 --> Model "M_produk" initialized
INFO - 2023-04-29 14:38:06 --> Controller Class Initialized
INFO - 2023-04-29 14:38:06 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 14:38:06 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:38:06 --> Final output sent to browser
DEBUG - 2023-04-29 14:38:06 --> Total execution time: 0.1005
INFO - 2023-04-29 14:38:08 --> Config Class Initialized
INFO - 2023-04-29 14:38:08 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:38:09 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:38:09 --> Utf8 Class Initialized
INFO - 2023-04-29 14:38:09 --> URI Class Initialized
INFO - 2023-04-29 14:38:09 --> Router Class Initialized
INFO - 2023-04-29 14:38:09 --> Output Class Initialized
INFO - 2023-04-29 14:38:09 --> Security Class Initialized
DEBUG - 2023-04-29 14:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:38:09 --> Input Class Initialized
INFO - 2023-04-29 14:38:09 --> Language Class Initialized
INFO - 2023-04-29 14:38:09 --> Loader Class Initialized
INFO - 2023-04-29 14:38:09 --> Helper loaded: url_helper
INFO - 2023-04-29 14:38:09 --> Helper loaded: form_helper
INFO - 2023-04-29 14:38:09 --> Helper loaded: file_helper
INFO - 2023-04-29 14:38:09 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:38:09 --> Form Validation Class Initialized
INFO - 2023-04-29 14:38:09 --> Upload Class Initialized
INFO - 2023-04-29 14:38:09 --> Model "M_auth" initialized
INFO - 2023-04-29 14:38:09 --> Model "M_user" initialized
INFO - 2023-04-29 14:38:09 --> Model "M_produk" initialized
INFO - 2023-04-29 14:38:09 --> Controller Class Initialized
INFO - 2023-04-29 14:38:09 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_user.php
INFO - 2023-04-29 14:38:09 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:38:09 --> Final output sent to browser
DEBUG - 2023-04-29 14:38:09 --> Total execution time: 0.1161
INFO - 2023-04-29 14:38:11 --> Config Class Initialized
INFO - 2023-04-29 14:38:11 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:38:11 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:38:11 --> Utf8 Class Initialized
INFO - 2023-04-29 14:38:11 --> URI Class Initialized
INFO - 2023-04-29 14:38:11 --> Router Class Initialized
INFO - 2023-04-29 14:38:11 --> Output Class Initialized
INFO - 2023-04-29 14:38:11 --> Security Class Initialized
DEBUG - 2023-04-29 14:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:38:11 --> Input Class Initialized
INFO - 2023-04-29 14:38:11 --> Language Class Initialized
INFO - 2023-04-29 14:38:11 --> Loader Class Initialized
INFO - 2023-04-29 14:38:11 --> Helper loaded: url_helper
INFO - 2023-04-29 14:38:11 --> Helper loaded: form_helper
INFO - 2023-04-29 14:38:11 --> Helper loaded: file_helper
INFO - 2023-04-29 14:38:11 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:38:11 --> Form Validation Class Initialized
INFO - 2023-04-29 14:38:11 --> Upload Class Initialized
INFO - 2023-04-29 14:38:11 --> Model "M_auth" initialized
INFO - 2023-04-29 14:38:11 --> Model "M_user" initialized
INFO - 2023-04-29 14:38:11 --> Model "M_produk" initialized
INFO - 2023-04-29 14:38:11 --> Controller Class Initialized
INFO - 2023-04-29 14:38:11 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:38:11 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:38:11 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:38:11 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:38:11 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:38:11 --> Model "M_bank" initialized
INFO - 2023-04-29 14:38:11 --> Model "M_pesan" initialized
ERROR - 2023-04-29 14:38:11 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 14:38:11 --> Config Class Initialized
INFO - 2023-04-29 14:38:11 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:38:11 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:38:11 --> Utf8 Class Initialized
INFO - 2023-04-29 14:38:11 --> URI Class Initialized
INFO - 2023-04-29 14:38:11 --> Router Class Initialized
INFO - 2023-04-29 14:38:11 --> Output Class Initialized
INFO - 2023-04-29 14:38:11 --> Security Class Initialized
DEBUG - 2023-04-29 14:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:38:11 --> Input Class Initialized
INFO - 2023-04-29 14:38:11 --> Language Class Initialized
ERROR - 2023-04-29 14:38:11 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 14:38:14 --> Config Class Initialized
INFO - 2023-04-29 14:38:14 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:38:14 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:38:14 --> Utf8 Class Initialized
INFO - 2023-04-29 14:38:14 --> URI Class Initialized
DEBUG - 2023-04-29 14:38:14 --> No URI present. Default controller set.
INFO - 2023-04-29 14:38:14 --> Router Class Initialized
INFO - 2023-04-29 14:38:14 --> Output Class Initialized
INFO - 2023-04-29 14:38:14 --> Security Class Initialized
DEBUG - 2023-04-29 14:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:38:14 --> Input Class Initialized
INFO - 2023-04-29 14:38:14 --> Language Class Initialized
INFO - 2023-04-29 14:38:14 --> Loader Class Initialized
INFO - 2023-04-29 14:38:14 --> Helper loaded: url_helper
INFO - 2023-04-29 14:38:14 --> Helper loaded: form_helper
INFO - 2023-04-29 14:38:14 --> Helper loaded: file_helper
INFO - 2023-04-29 14:38:14 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:38:14 --> Form Validation Class Initialized
INFO - 2023-04-29 14:38:14 --> Upload Class Initialized
INFO - 2023-04-29 14:38:14 --> Model "M_auth" initialized
INFO - 2023-04-29 14:38:14 --> Model "M_user" initialized
INFO - 2023-04-29 14:38:14 --> Model "M_produk" initialized
INFO - 2023-04-29 14:38:14 --> Controller Class Initialized
INFO - 2023-04-29 14:38:14 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:38:14 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:38:14 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:38:14 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:38:14 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:38:14 --> Model "M_bank" initialized
INFO - 2023-04-29 14:38:14 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:38:14 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:38:14 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/index.php
INFO - 2023-04-29 14:38:14 --> Final output sent to browser
DEBUG - 2023-04-29 14:38:14 --> Total execution time: 0.1331
INFO - 2023-04-29 14:38:19 --> Config Class Initialized
INFO - 2023-04-29 14:38:19 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:38:19 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:38:19 --> Utf8 Class Initialized
INFO - 2023-04-29 14:38:19 --> URI Class Initialized
INFO - 2023-04-29 14:38:19 --> Router Class Initialized
INFO - 2023-04-29 14:38:19 --> Output Class Initialized
INFO - 2023-04-29 14:38:19 --> Security Class Initialized
DEBUG - 2023-04-29 14:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:38:19 --> Input Class Initialized
INFO - 2023-04-29 14:38:19 --> Language Class Initialized
INFO - 2023-04-29 14:38:19 --> Loader Class Initialized
INFO - 2023-04-29 14:38:19 --> Helper loaded: url_helper
INFO - 2023-04-29 14:38:19 --> Helper loaded: form_helper
INFO - 2023-04-29 14:38:19 --> Helper loaded: file_helper
INFO - 2023-04-29 14:38:19 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:38:19 --> Form Validation Class Initialized
INFO - 2023-04-29 14:38:19 --> Upload Class Initialized
INFO - 2023-04-29 14:38:19 --> Model "M_auth" initialized
INFO - 2023-04-29 14:38:19 --> Model "M_user" initialized
INFO - 2023-04-29 14:38:19 --> Model "M_produk" initialized
INFO - 2023-04-29 14:38:19 --> Controller Class Initialized
INFO - 2023-04-29 14:38:19 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:38:19 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:38:19 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:38:19 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:38:19 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:38:19 --> Model "M_bank" initialized
INFO - 2023-04-29 14:38:19 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:38:19 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:38:19 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/v_produk_detail.php
INFO - 2023-04-29 14:38:19 --> Final output sent to browser
DEBUG - 2023-04-29 14:38:19 --> Total execution time: 0.1455
INFO - 2023-04-29 14:38:52 --> Config Class Initialized
INFO - 2023-04-29 14:38:52 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:38:52 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:38:52 --> Utf8 Class Initialized
INFO - 2023-04-29 14:38:52 --> URI Class Initialized
INFO - 2023-04-29 14:38:52 --> Router Class Initialized
INFO - 2023-04-29 14:38:52 --> Output Class Initialized
INFO - 2023-04-29 14:38:52 --> Security Class Initialized
DEBUG - 2023-04-29 14:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:38:52 --> Input Class Initialized
INFO - 2023-04-29 14:38:52 --> Language Class Initialized
INFO - 2023-04-29 14:38:52 --> Loader Class Initialized
INFO - 2023-04-29 14:38:52 --> Helper loaded: url_helper
INFO - 2023-04-29 14:38:52 --> Helper loaded: form_helper
INFO - 2023-04-29 14:38:52 --> Helper loaded: file_helper
INFO - 2023-04-29 14:38:52 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:38:52 --> Form Validation Class Initialized
INFO - 2023-04-29 14:38:52 --> Upload Class Initialized
INFO - 2023-04-29 14:38:52 --> Model "M_auth" initialized
INFO - 2023-04-29 14:38:52 --> Model "M_user" initialized
INFO - 2023-04-29 14:38:52 --> Model "M_produk" initialized
INFO - 2023-04-29 14:38:52 --> Controller Class Initialized
INFO - 2023-04-29 14:38:52 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:38:52 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:38:52 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:38:52 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:38:52 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:38:52 --> Model "M_bank" initialized
INFO - 2023-04-29 14:38:52 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:38:52 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:38:52 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/v_kategori_detail.php
INFO - 2023-04-29 14:38:52 --> Final output sent to browser
DEBUG - 2023-04-29 14:38:52 --> Total execution time: 0.1790
INFO - 2023-04-29 14:38:56 --> Config Class Initialized
INFO - 2023-04-29 14:38:56 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:38:56 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:38:56 --> Utf8 Class Initialized
INFO - 2023-04-29 14:38:56 --> URI Class Initialized
INFO - 2023-04-29 14:38:56 --> Router Class Initialized
INFO - 2023-04-29 14:38:56 --> Output Class Initialized
INFO - 2023-04-29 14:38:56 --> Security Class Initialized
DEBUG - 2023-04-29 14:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:38:56 --> Input Class Initialized
INFO - 2023-04-29 14:38:56 --> Language Class Initialized
INFO - 2023-04-29 14:38:56 --> Loader Class Initialized
INFO - 2023-04-29 14:38:56 --> Helper loaded: url_helper
INFO - 2023-04-29 14:38:56 --> Helper loaded: form_helper
INFO - 2023-04-29 14:38:56 --> Helper loaded: file_helper
INFO - 2023-04-29 14:38:56 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:38:56 --> Form Validation Class Initialized
INFO - 2023-04-29 14:38:56 --> Upload Class Initialized
INFO - 2023-04-29 14:38:56 --> Model "M_auth" initialized
INFO - 2023-04-29 14:38:56 --> Model "M_user" initialized
INFO - 2023-04-29 14:38:56 --> Model "M_produk" initialized
INFO - 2023-04-29 14:38:56 --> Controller Class Initialized
INFO - 2023-04-29 14:38:56 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:38:56 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:38:56 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:38:56 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:38:56 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:38:56 --> Model "M_bank" initialized
INFO - 2023-04-29 14:38:56 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:38:56 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:38:56 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/v_produk_detail.php
INFO - 2023-04-29 14:38:56 --> Final output sent to browser
DEBUG - 2023-04-29 14:38:56 --> Total execution time: 0.1561
INFO - 2023-04-29 14:39:04 --> Config Class Initialized
INFO - 2023-04-29 14:39:04 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:39:04 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:39:04 --> Utf8 Class Initialized
INFO - 2023-04-29 14:39:04 --> URI Class Initialized
INFO - 2023-04-29 14:39:04 --> Router Class Initialized
INFO - 2023-04-29 14:39:04 --> Output Class Initialized
INFO - 2023-04-29 14:39:04 --> Security Class Initialized
DEBUG - 2023-04-29 14:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:39:04 --> Input Class Initialized
INFO - 2023-04-29 14:39:04 --> Language Class Initialized
INFO - 2023-04-29 14:39:04 --> Loader Class Initialized
INFO - 2023-04-29 14:39:04 --> Helper loaded: url_helper
INFO - 2023-04-29 14:39:04 --> Helper loaded: form_helper
INFO - 2023-04-29 14:39:04 --> Helper loaded: file_helper
INFO - 2023-04-29 14:39:04 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:39:04 --> Form Validation Class Initialized
INFO - 2023-04-29 14:39:04 --> Upload Class Initialized
INFO - 2023-04-29 14:39:04 --> Model "M_auth" initialized
INFO - 2023-04-29 14:39:04 --> Model "M_user" initialized
INFO - 2023-04-29 14:39:04 --> Model "M_produk" initialized
INFO - 2023-04-29 14:39:04 --> Controller Class Initialized
INFO - 2023-04-29 14:39:04 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_login.php
INFO - 2023-04-29 14:39:04 --> Final output sent to browser
DEBUG - 2023-04-29 14:39:04 --> Total execution time: 0.1287
INFO - 2023-04-29 14:39:07 --> Config Class Initialized
INFO - 2023-04-29 14:39:07 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:39:07 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:39:07 --> Utf8 Class Initialized
INFO - 2023-04-29 14:39:07 --> URI Class Initialized
INFO - 2023-04-29 14:39:07 --> Router Class Initialized
INFO - 2023-04-29 14:39:07 --> Output Class Initialized
INFO - 2023-04-29 14:39:07 --> Security Class Initialized
DEBUG - 2023-04-29 14:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:39:07 --> Input Class Initialized
INFO - 2023-04-29 14:39:07 --> Language Class Initialized
INFO - 2023-04-29 14:39:07 --> Loader Class Initialized
INFO - 2023-04-29 14:39:07 --> Helper loaded: url_helper
INFO - 2023-04-29 14:39:07 --> Helper loaded: form_helper
INFO - 2023-04-29 14:39:07 --> Helper loaded: file_helper
INFO - 2023-04-29 14:39:07 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:39:07 --> Form Validation Class Initialized
INFO - 2023-04-29 14:39:07 --> Upload Class Initialized
INFO - 2023-04-29 14:39:07 --> Model "M_auth" initialized
INFO - 2023-04-29 14:39:07 --> Model "M_user" initialized
INFO - 2023-04-29 14:39:07 --> Model "M_produk" initialized
INFO - 2023-04-29 14:39:07 --> Controller Class Initialized
INFO - 2023-04-29 14:39:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-04-29 14:39:07 --> Config Class Initialized
INFO - 2023-04-29 14:39:07 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:39:07 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:39:07 --> Utf8 Class Initialized
INFO - 2023-04-29 14:39:07 --> URI Class Initialized
INFO - 2023-04-29 14:39:07 --> Router Class Initialized
INFO - 2023-04-29 14:39:07 --> Output Class Initialized
INFO - 2023-04-29 14:39:07 --> Security Class Initialized
DEBUG - 2023-04-29 14:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:39:07 --> Input Class Initialized
INFO - 2023-04-29 14:39:07 --> Language Class Initialized
INFO - 2023-04-29 14:39:07 --> Loader Class Initialized
INFO - 2023-04-29 14:39:07 --> Helper loaded: url_helper
INFO - 2023-04-29 14:39:07 --> Helper loaded: form_helper
INFO - 2023-04-29 14:39:07 --> Helper loaded: file_helper
INFO - 2023-04-29 14:39:07 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:39:07 --> Form Validation Class Initialized
INFO - 2023-04-29 14:39:07 --> Upload Class Initialized
INFO - 2023-04-29 14:39:07 --> Model "M_auth" initialized
INFO - 2023-04-29 14:39:07 --> Model "M_user" initialized
INFO - 2023-04-29 14:39:07 --> Model "M_produk" initialized
INFO - 2023-04-29 14:39:07 --> Controller Class Initialized
INFO - 2023-04-29 14:39:07 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_login.php
INFO - 2023-04-29 14:39:07 --> Final output sent to browser
DEBUG - 2023-04-29 14:39:07 --> Total execution time: 0.1068
INFO - 2023-04-29 14:39:15 --> Config Class Initialized
INFO - 2023-04-29 14:39:15 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:39:15 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:39:15 --> Utf8 Class Initialized
INFO - 2023-04-29 14:39:15 --> URI Class Initialized
INFO - 2023-04-29 14:39:15 --> Router Class Initialized
INFO - 2023-04-29 14:39:15 --> Output Class Initialized
INFO - 2023-04-29 14:39:15 --> Security Class Initialized
DEBUG - 2023-04-29 14:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:39:15 --> Input Class Initialized
INFO - 2023-04-29 14:39:15 --> Language Class Initialized
INFO - 2023-04-29 14:39:15 --> Loader Class Initialized
INFO - 2023-04-29 14:39:15 --> Helper loaded: url_helper
INFO - 2023-04-29 14:39:15 --> Helper loaded: form_helper
INFO - 2023-04-29 14:39:15 --> Helper loaded: file_helper
INFO - 2023-04-29 14:39:15 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:39:15 --> Form Validation Class Initialized
INFO - 2023-04-29 14:39:15 --> Upload Class Initialized
INFO - 2023-04-29 14:39:15 --> Model "M_auth" initialized
INFO - 2023-04-29 14:39:15 --> Model "M_user" initialized
INFO - 2023-04-29 14:39:15 --> Model "M_produk" initialized
INFO - 2023-04-29 14:39:15 --> Controller Class Initialized
INFO - 2023-04-29 14:39:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-04-29 14:39:15 --> Config Class Initialized
INFO - 2023-04-29 14:39:15 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:39:15 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:39:15 --> Utf8 Class Initialized
INFO - 2023-04-29 14:39:15 --> URI Class Initialized
INFO - 2023-04-29 14:39:15 --> Router Class Initialized
INFO - 2023-04-29 14:39:15 --> Output Class Initialized
INFO - 2023-04-29 14:39:15 --> Security Class Initialized
DEBUG - 2023-04-29 14:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:39:15 --> Input Class Initialized
INFO - 2023-04-29 14:39:15 --> Language Class Initialized
INFO - 2023-04-29 14:39:15 --> Loader Class Initialized
INFO - 2023-04-29 14:39:15 --> Helper loaded: url_helper
INFO - 2023-04-29 14:39:15 --> Helper loaded: form_helper
INFO - 2023-04-29 14:39:15 --> Helper loaded: file_helper
INFO - 2023-04-29 14:39:15 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:39:15 --> Form Validation Class Initialized
INFO - 2023-04-29 14:39:15 --> Upload Class Initialized
INFO - 2023-04-29 14:39:15 --> Model "M_auth" initialized
INFO - 2023-04-29 14:39:15 --> Model "M_user" initialized
INFO - 2023-04-29 14:39:15 --> Model "M_produk" initialized
INFO - 2023-04-29 14:39:15 --> Controller Class Initialized
INFO - 2023-04-29 14:39:15 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 14:39:15 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:39:15 --> Final output sent to browser
DEBUG - 2023-04-29 14:39:15 --> Total execution time: 0.1214
INFO - 2023-04-29 14:39:17 --> Config Class Initialized
INFO - 2023-04-29 14:39:17 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:39:17 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:39:17 --> Utf8 Class Initialized
INFO - 2023-04-29 14:39:17 --> URI Class Initialized
INFO - 2023-04-29 14:39:17 --> Router Class Initialized
INFO - 2023-04-29 14:39:17 --> Output Class Initialized
INFO - 2023-04-29 14:39:17 --> Security Class Initialized
DEBUG - 2023-04-29 14:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:39:17 --> Input Class Initialized
INFO - 2023-04-29 14:39:17 --> Language Class Initialized
INFO - 2023-04-29 14:39:17 --> Loader Class Initialized
INFO - 2023-04-29 14:39:17 --> Helper loaded: url_helper
INFO - 2023-04-29 14:39:17 --> Helper loaded: form_helper
INFO - 2023-04-29 14:39:17 --> Helper loaded: file_helper
INFO - 2023-04-29 14:39:17 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:39:17 --> Form Validation Class Initialized
INFO - 2023-04-29 14:39:17 --> Upload Class Initialized
INFO - 2023-04-29 14:39:17 --> Model "M_auth" initialized
INFO - 2023-04-29 14:39:17 --> Model "M_user" initialized
INFO - 2023-04-29 14:39:17 --> Model "M_produk" initialized
INFO - 2023-04-29 14:39:17 --> Controller Class Initialized
INFO - 2023-04-29 14:39:17 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_ganti_password.php
INFO - 2023-04-29 14:39:17 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:39:18 --> Final output sent to browser
DEBUG - 2023-04-29 14:39:18 --> Total execution time: 0.1182
INFO - 2023-04-29 14:39:19 --> Config Class Initialized
INFO - 2023-04-29 14:39:19 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:39:19 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:39:19 --> Utf8 Class Initialized
INFO - 2023-04-29 14:39:19 --> URI Class Initialized
INFO - 2023-04-29 14:39:19 --> Router Class Initialized
INFO - 2023-04-29 14:39:19 --> Output Class Initialized
INFO - 2023-04-29 14:39:19 --> Security Class Initialized
DEBUG - 2023-04-29 14:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:39:19 --> Input Class Initialized
INFO - 2023-04-29 14:39:19 --> Language Class Initialized
INFO - 2023-04-29 14:39:19 --> Loader Class Initialized
INFO - 2023-04-29 14:39:19 --> Helper loaded: url_helper
INFO - 2023-04-29 14:39:19 --> Helper loaded: form_helper
INFO - 2023-04-29 14:39:19 --> Helper loaded: file_helper
INFO - 2023-04-29 14:39:19 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:39:19 --> Form Validation Class Initialized
INFO - 2023-04-29 14:39:19 --> Upload Class Initialized
INFO - 2023-04-29 14:39:19 --> Model "M_auth" initialized
INFO - 2023-04-29 14:39:19 --> Model "M_user" initialized
INFO - 2023-04-29 14:39:19 --> Model "M_produk" initialized
INFO - 2023-04-29 14:39:19 --> Controller Class Initialized
INFO - 2023-04-29 14:39:19 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_user.php
INFO - 2023-04-29 14:39:19 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:39:19 --> Final output sent to browser
DEBUG - 2023-04-29 14:39:19 --> Total execution time: 0.1364
INFO - 2023-04-29 14:39:22 --> Config Class Initialized
INFO - 2023-04-29 14:39:22 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:39:22 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:39:22 --> Utf8 Class Initialized
INFO - 2023-04-29 14:39:22 --> URI Class Initialized
INFO - 2023-04-29 14:39:22 --> Router Class Initialized
INFO - 2023-04-29 14:39:22 --> Output Class Initialized
INFO - 2023-04-29 14:39:22 --> Security Class Initialized
DEBUG - 2023-04-29 14:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:39:22 --> Input Class Initialized
INFO - 2023-04-29 14:39:22 --> Language Class Initialized
INFO - 2023-04-29 14:39:22 --> Loader Class Initialized
INFO - 2023-04-29 14:39:22 --> Helper loaded: url_helper
INFO - 2023-04-29 14:39:22 --> Helper loaded: form_helper
INFO - 2023-04-29 14:39:22 --> Helper loaded: file_helper
INFO - 2023-04-29 14:39:22 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:39:22 --> Form Validation Class Initialized
INFO - 2023-04-29 14:39:22 --> Upload Class Initialized
INFO - 2023-04-29 14:39:22 --> Model "M_auth" initialized
INFO - 2023-04-29 14:39:22 --> Model "M_user" initialized
INFO - 2023-04-29 14:39:22 --> Model "M_produk" initialized
INFO - 2023-04-29 14:39:22 --> Controller Class Initialized
INFO - 2023-04-29 14:39:22 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:39:22 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:39:22 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:39:22 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:39:22 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:39:22 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_transaksi_all.php
INFO - 2023-04-29 14:39:22 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:39:22 --> Final output sent to browser
DEBUG - 2023-04-29 14:39:22 --> Total execution time: 0.1287
INFO - 2023-04-29 14:39:25 --> Config Class Initialized
INFO - 2023-04-29 14:39:25 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:39:25 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:39:25 --> Utf8 Class Initialized
INFO - 2023-04-29 14:39:25 --> URI Class Initialized
INFO - 2023-04-29 14:39:25 --> Router Class Initialized
INFO - 2023-04-29 14:39:25 --> Output Class Initialized
INFO - 2023-04-29 14:39:25 --> Security Class Initialized
DEBUG - 2023-04-29 14:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:39:25 --> Input Class Initialized
INFO - 2023-04-29 14:39:25 --> Language Class Initialized
INFO - 2023-04-29 14:39:25 --> Loader Class Initialized
INFO - 2023-04-29 14:39:25 --> Helper loaded: url_helper
INFO - 2023-04-29 14:39:25 --> Helper loaded: form_helper
INFO - 2023-04-29 14:39:25 --> Helper loaded: file_helper
INFO - 2023-04-29 14:39:25 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:39:25 --> Form Validation Class Initialized
INFO - 2023-04-29 14:39:25 --> Upload Class Initialized
INFO - 2023-04-29 14:39:25 --> Model "M_auth" initialized
INFO - 2023-04-29 14:39:25 --> Model "M_user" initialized
INFO - 2023-04-29 14:39:25 --> Model "M_produk" initialized
INFO - 2023-04-29 14:39:25 --> Controller Class Initialized
INFO - 2023-04-29 14:39:25 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:39:25 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:39:25 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:39:25 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:39:25 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:39:25 --> Model "M_bank" initialized
INFO - 2023-04-29 14:39:25 --> Model "M_pesan" initialized
ERROR - 2023-04-29 14:39:25 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 14:39:25 --> Config Class Initialized
INFO - 2023-04-29 14:39:25 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:39:25 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:39:25 --> Utf8 Class Initialized
INFO - 2023-04-29 14:39:25 --> URI Class Initialized
INFO - 2023-04-29 14:39:25 --> Router Class Initialized
INFO - 2023-04-29 14:39:25 --> Output Class Initialized
INFO - 2023-04-29 14:39:25 --> Security Class Initialized
DEBUG - 2023-04-29 14:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:39:25 --> Input Class Initialized
INFO - 2023-04-29 14:39:25 --> Language Class Initialized
ERROR - 2023-04-29 14:39:25 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 14:39:26 --> Config Class Initialized
INFO - 2023-04-29 14:39:26 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:39:26 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:39:26 --> Utf8 Class Initialized
INFO - 2023-04-29 14:39:26 --> URI Class Initialized
INFO - 2023-04-29 14:39:26 --> Router Class Initialized
INFO - 2023-04-29 14:39:26 --> Output Class Initialized
INFO - 2023-04-29 14:39:26 --> Security Class Initialized
DEBUG - 2023-04-29 14:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:39:26 --> Input Class Initialized
INFO - 2023-04-29 14:39:26 --> Language Class Initialized
INFO - 2023-04-29 14:39:26 --> Loader Class Initialized
INFO - 2023-04-29 14:39:26 --> Helper loaded: url_helper
INFO - 2023-04-29 14:39:26 --> Helper loaded: form_helper
INFO - 2023-04-29 14:39:26 --> Helper loaded: file_helper
INFO - 2023-04-29 14:39:26 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:39:26 --> Form Validation Class Initialized
INFO - 2023-04-29 14:39:26 --> Upload Class Initialized
INFO - 2023-04-29 14:39:26 --> Model "M_auth" initialized
INFO - 2023-04-29 14:39:26 --> Model "M_user" initialized
INFO - 2023-04-29 14:39:26 --> Model "M_produk" initialized
INFO - 2023-04-29 14:39:26 --> Controller Class Initialized
INFO - 2023-04-29 14:39:26 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:39:26 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:39:26 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:39:26 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:39:26 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:39:26 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_transaksi_all.php
INFO - 2023-04-29 14:39:26 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:39:26 --> Final output sent to browser
DEBUG - 2023-04-29 14:39:26 --> Total execution time: 0.1426
INFO - 2023-04-29 14:39:28 --> Config Class Initialized
INFO - 2023-04-29 14:39:28 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:39:28 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:39:28 --> Utf8 Class Initialized
INFO - 2023-04-29 14:39:28 --> URI Class Initialized
INFO - 2023-04-29 14:39:28 --> Router Class Initialized
INFO - 2023-04-29 14:39:28 --> Output Class Initialized
INFO - 2023-04-29 14:39:28 --> Security Class Initialized
DEBUG - 2023-04-29 14:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:39:28 --> Input Class Initialized
INFO - 2023-04-29 14:39:28 --> Language Class Initialized
INFO - 2023-04-29 14:39:28 --> Loader Class Initialized
INFO - 2023-04-29 14:39:28 --> Helper loaded: url_helper
INFO - 2023-04-29 14:39:28 --> Helper loaded: form_helper
INFO - 2023-04-29 14:39:28 --> Helper loaded: file_helper
INFO - 2023-04-29 14:39:28 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:39:28 --> Form Validation Class Initialized
INFO - 2023-04-29 14:39:28 --> Upload Class Initialized
INFO - 2023-04-29 14:39:28 --> Model "M_auth" initialized
INFO - 2023-04-29 14:39:28 --> Model "M_user" initialized
INFO - 2023-04-29 14:39:28 --> Model "M_produk" initialized
INFO - 2023-04-29 14:39:28 --> Controller Class Initialized
INFO - 2023-04-29 14:39:28 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:39:28 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:39:28 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:39:28 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:39:28 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:39:28 --> Model "M_bank" initialized
INFO - 2023-04-29 14:39:28 --> Model "M_pesan" initialized
ERROR - 2023-04-29 14:39:28 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 14:39:28 --> Config Class Initialized
INFO - 2023-04-29 14:39:28 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:39:28 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:39:28 --> Utf8 Class Initialized
INFO - 2023-04-29 14:39:28 --> URI Class Initialized
INFO - 2023-04-29 14:39:28 --> Router Class Initialized
INFO - 2023-04-29 14:39:28 --> Output Class Initialized
INFO - 2023-04-29 14:39:28 --> Security Class Initialized
DEBUG - 2023-04-29 14:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:39:28 --> Input Class Initialized
INFO - 2023-04-29 14:39:28 --> Language Class Initialized
ERROR - 2023-04-29 14:39:28 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 14:39:31 --> Config Class Initialized
INFO - 2023-04-29 14:39:31 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:39:31 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:39:31 --> Utf8 Class Initialized
INFO - 2023-04-29 14:39:31 --> URI Class Initialized
INFO - 2023-04-29 14:39:31 --> Router Class Initialized
INFO - 2023-04-29 14:39:31 --> Output Class Initialized
INFO - 2023-04-29 14:39:31 --> Security Class Initialized
DEBUG - 2023-04-29 14:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:39:31 --> Input Class Initialized
INFO - 2023-04-29 14:39:31 --> Language Class Initialized
INFO - 2023-04-29 14:39:31 --> Loader Class Initialized
INFO - 2023-04-29 14:39:31 --> Helper loaded: url_helper
INFO - 2023-04-29 14:39:31 --> Helper loaded: form_helper
INFO - 2023-04-29 14:39:31 --> Helper loaded: file_helper
INFO - 2023-04-29 14:39:31 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:39:31 --> Form Validation Class Initialized
INFO - 2023-04-29 14:39:31 --> Upload Class Initialized
INFO - 2023-04-29 14:39:31 --> Model "M_auth" initialized
INFO - 2023-04-29 14:39:31 --> Model "M_user" initialized
INFO - 2023-04-29 14:39:31 --> Model "M_produk" initialized
INFO - 2023-04-29 14:39:31 --> Controller Class Initialized
INFO - 2023-04-29 14:39:31 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:39:31 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:39:31 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:39:31 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:39:31 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:39:31 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_transaksi_all.php
INFO - 2023-04-29 14:39:31 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:39:31 --> Final output sent to browser
DEBUG - 2023-04-29 14:39:31 --> Total execution time: 0.1237
INFO - 2023-04-29 14:39:53 --> Config Class Initialized
INFO - 2023-04-29 14:39:53 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:39:53 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:39:53 --> Utf8 Class Initialized
INFO - 2023-04-29 14:39:53 --> URI Class Initialized
INFO - 2023-04-29 14:39:53 --> Router Class Initialized
INFO - 2023-04-29 14:39:53 --> Output Class Initialized
INFO - 2023-04-29 14:39:53 --> Security Class Initialized
DEBUG - 2023-04-29 14:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:39:53 --> Input Class Initialized
INFO - 2023-04-29 14:39:53 --> Language Class Initialized
INFO - 2023-04-29 14:39:53 --> Loader Class Initialized
INFO - 2023-04-29 14:39:53 --> Helper loaded: url_helper
INFO - 2023-04-29 14:39:53 --> Helper loaded: form_helper
INFO - 2023-04-29 14:39:53 --> Helper loaded: file_helper
INFO - 2023-04-29 14:39:53 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:39:53 --> Form Validation Class Initialized
INFO - 2023-04-29 14:39:53 --> Upload Class Initialized
INFO - 2023-04-29 14:39:53 --> Model "M_auth" initialized
INFO - 2023-04-29 14:39:53 --> Model "M_user" initialized
INFO - 2023-04-29 14:39:53 --> Model "M_produk" initialized
INFO - 2023-04-29 14:39:53 --> Controller Class Initialized
INFO - 2023-04-29 14:39:53 --> Config Class Initialized
INFO - 2023-04-29 14:39:53 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:39:53 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:39:53 --> Utf8 Class Initialized
INFO - 2023-04-29 14:39:53 --> URI Class Initialized
INFO - 2023-04-29 14:39:53 --> Router Class Initialized
INFO - 2023-04-29 14:39:53 --> Output Class Initialized
INFO - 2023-04-29 14:39:53 --> Security Class Initialized
DEBUG - 2023-04-29 14:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:39:53 --> Input Class Initialized
INFO - 2023-04-29 14:39:53 --> Language Class Initialized
INFO - 2023-04-29 14:39:53 --> Loader Class Initialized
INFO - 2023-04-29 14:39:53 --> Helper loaded: url_helper
INFO - 2023-04-29 14:39:53 --> Helper loaded: form_helper
INFO - 2023-04-29 14:39:53 --> Helper loaded: file_helper
INFO - 2023-04-29 14:39:53 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:39:53 --> Form Validation Class Initialized
INFO - 2023-04-29 14:39:53 --> Upload Class Initialized
INFO - 2023-04-29 14:39:53 --> Model "M_auth" initialized
INFO - 2023-04-29 14:39:53 --> Model "M_user" initialized
INFO - 2023-04-29 14:39:53 --> Model "M_produk" initialized
INFO - 2023-04-29 14:39:53 --> Controller Class Initialized
INFO - 2023-04-29 14:39:53 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\back/v_login.php
INFO - 2023-04-29 14:39:53 --> Final output sent to browser
DEBUG - 2023-04-29 14:39:53 --> Total execution time: 0.0996
INFO - 2023-04-29 14:39:55 --> Config Class Initialized
INFO - 2023-04-29 14:39:55 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:39:55 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:39:55 --> Utf8 Class Initialized
INFO - 2023-04-29 14:39:55 --> URI Class Initialized
DEBUG - 2023-04-29 14:39:55 --> No URI present. Default controller set.
INFO - 2023-04-29 14:39:55 --> Router Class Initialized
INFO - 2023-04-29 14:39:55 --> Output Class Initialized
INFO - 2023-04-29 14:39:55 --> Security Class Initialized
DEBUG - 2023-04-29 14:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:39:55 --> Input Class Initialized
INFO - 2023-04-29 14:39:55 --> Language Class Initialized
INFO - 2023-04-29 14:39:55 --> Loader Class Initialized
INFO - 2023-04-29 14:39:55 --> Helper loaded: url_helper
INFO - 2023-04-29 14:39:55 --> Helper loaded: form_helper
INFO - 2023-04-29 14:39:55 --> Helper loaded: file_helper
INFO - 2023-04-29 14:39:55 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:39:55 --> Form Validation Class Initialized
INFO - 2023-04-29 14:39:55 --> Upload Class Initialized
INFO - 2023-04-29 14:39:55 --> Model "M_auth" initialized
INFO - 2023-04-29 14:39:55 --> Model "M_user" initialized
INFO - 2023-04-29 14:39:55 --> Model "M_produk" initialized
INFO - 2023-04-29 14:39:55 --> Controller Class Initialized
INFO - 2023-04-29 14:39:55 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:39:55 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:39:55 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:39:55 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:39:55 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:39:55 --> Model "M_bank" initialized
INFO - 2023-04-29 14:39:55 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:39:55 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:39:55 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/index.php
INFO - 2023-04-29 14:39:55 --> Final output sent to browser
DEBUG - 2023-04-29 14:39:55 --> Total execution time: 0.1283
INFO - 2023-04-29 14:39:59 --> Config Class Initialized
INFO - 2023-04-29 14:39:59 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:39:59 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:39:59 --> Utf8 Class Initialized
INFO - 2023-04-29 14:39:59 --> URI Class Initialized
INFO - 2023-04-29 14:39:59 --> Router Class Initialized
INFO - 2023-04-29 14:39:59 --> Output Class Initialized
INFO - 2023-04-29 14:39:59 --> Security Class Initialized
DEBUG - 2023-04-29 14:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:39:59 --> Input Class Initialized
INFO - 2023-04-29 14:39:59 --> Language Class Initialized
ERROR - 2023-04-29 14:39:59 --> 404 Page Not Found: Skripsi4(an)/semakar-adventure
INFO - 2023-04-29 14:40:04 --> Config Class Initialized
INFO - 2023-04-29 14:40:04 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:40:04 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:40:04 --> Utf8 Class Initialized
INFO - 2023-04-29 14:40:04 --> URI Class Initialized
INFO - 2023-04-29 14:40:04 --> Router Class Initialized
INFO - 2023-04-29 14:40:04 --> Output Class Initialized
INFO - 2023-04-29 14:40:04 --> Security Class Initialized
DEBUG - 2023-04-29 14:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:40:04 --> Input Class Initialized
INFO - 2023-04-29 14:40:04 --> Language Class Initialized
ERROR - 2023-04-29 14:40:04 --> 404 Page Not Found: Skripsi4(an)/semakar-adventure
INFO - 2023-04-29 14:40:04 --> Config Class Initialized
INFO - 2023-04-29 14:40:04 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:40:04 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:40:04 --> Utf8 Class Initialized
INFO - 2023-04-29 14:40:04 --> URI Class Initialized
INFO - 2023-04-29 14:40:04 --> Router Class Initialized
INFO - 2023-04-29 14:40:04 --> Output Class Initialized
INFO - 2023-04-29 14:40:04 --> Security Class Initialized
DEBUG - 2023-04-29 14:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:40:04 --> Input Class Initialized
INFO - 2023-04-29 14:40:04 --> Language Class Initialized
ERROR - 2023-04-29 14:40:04 --> 404 Page Not Found: Skripsi4(an)/semakar-adventure
INFO - 2023-04-29 14:40:04 --> Config Class Initialized
INFO - 2023-04-29 14:40:04 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:40:04 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:40:04 --> Utf8 Class Initialized
INFO - 2023-04-29 14:40:04 --> URI Class Initialized
INFO - 2023-04-29 14:40:04 --> Router Class Initialized
INFO - 2023-04-29 14:40:04 --> Output Class Initialized
INFO - 2023-04-29 14:40:04 --> Security Class Initialized
DEBUG - 2023-04-29 14:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:40:04 --> Input Class Initialized
INFO - 2023-04-29 14:40:04 --> Language Class Initialized
ERROR - 2023-04-29 14:40:04 --> 404 Page Not Found: Skripsi4(an)/semakar-adventure
INFO - 2023-04-29 14:40:05 --> Config Class Initialized
INFO - 2023-04-29 14:40:05 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:40:05 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:40:05 --> Utf8 Class Initialized
INFO - 2023-04-29 14:40:05 --> URI Class Initialized
INFO - 2023-04-29 14:40:05 --> Router Class Initialized
INFO - 2023-04-29 14:40:05 --> Output Class Initialized
INFO - 2023-04-29 14:40:05 --> Security Class Initialized
DEBUG - 2023-04-29 14:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:40:05 --> Input Class Initialized
INFO - 2023-04-29 14:40:05 --> Language Class Initialized
ERROR - 2023-04-29 14:40:05 --> 404 Page Not Found: Skripsi4(an)/semakar-adventure
INFO - 2023-04-29 14:40:05 --> Config Class Initialized
INFO - 2023-04-29 14:40:05 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:40:05 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:40:05 --> Utf8 Class Initialized
INFO - 2023-04-29 14:40:05 --> URI Class Initialized
INFO - 2023-04-29 14:40:05 --> Router Class Initialized
INFO - 2023-04-29 14:40:05 --> Output Class Initialized
INFO - 2023-04-29 14:40:05 --> Security Class Initialized
DEBUG - 2023-04-29 14:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:40:05 --> Input Class Initialized
INFO - 2023-04-29 14:40:05 --> Language Class Initialized
ERROR - 2023-04-29 14:40:05 --> 404 Page Not Found: Skripsi4(an)/semakar-adventure
INFO - 2023-04-29 14:40:05 --> Config Class Initialized
INFO - 2023-04-29 14:40:05 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:40:05 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:40:05 --> Utf8 Class Initialized
INFO - 2023-04-29 14:40:05 --> URI Class Initialized
INFO - 2023-04-29 14:40:05 --> Router Class Initialized
INFO - 2023-04-29 14:40:05 --> Output Class Initialized
INFO - 2023-04-29 14:40:05 --> Security Class Initialized
DEBUG - 2023-04-29 14:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:40:05 --> Input Class Initialized
INFO - 2023-04-29 14:40:05 --> Language Class Initialized
ERROR - 2023-04-29 14:40:05 --> 404 Page Not Found: Skripsi4(an)/semakar-adventure
INFO - 2023-04-29 14:40:05 --> Config Class Initialized
INFO - 2023-04-29 14:40:05 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:40:06 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:40:06 --> Utf8 Class Initialized
INFO - 2023-04-29 14:40:06 --> URI Class Initialized
DEBUG - 2023-04-29 14:40:06 --> No URI present. Default controller set.
INFO - 2023-04-29 14:40:06 --> Router Class Initialized
INFO - 2023-04-29 14:40:06 --> Output Class Initialized
INFO - 2023-04-29 14:40:06 --> Security Class Initialized
DEBUG - 2023-04-29 14:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:40:06 --> Input Class Initialized
INFO - 2023-04-29 14:40:06 --> Language Class Initialized
INFO - 2023-04-29 14:40:06 --> Loader Class Initialized
INFO - 2023-04-29 14:40:06 --> Helper loaded: url_helper
INFO - 2023-04-29 14:40:06 --> Helper loaded: form_helper
INFO - 2023-04-29 14:40:06 --> Helper loaded: file_helper
INFO - 2023-04-29 14:40:06 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:40:06 --> Form Validation Class Initialized
INFO - 2023-04-29 14:40:06 --> Upload Class Initialized
INFO - 2023-04-29 14:40:06 --> Model "M_auth" initialized
INFO - 2023-04-29 14:40:06 --> Model "M_user" initialized
INFO - 2023-04-29 14:40:06 --> Model "M_produk" initialized
INFO - 2023-04-29 14:40:06 --> Controller Class Initialized
INFO - 2023-04-29 14:40:06 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:40:06 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:40:06 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:40:06 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:40:06 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:40:06 --> Model "M_bank" initialized
INFO - 2023-04-29 14:40:06 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:40:06 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:40:06 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/index.php
INFO - 2023-04-29 14:40:06 --> Final output sent to browser
DEBUG - 2023-04-29 14:40:06 --> Total execution time: 0.1712
INFO - 2023-04-29 14:40:08 --> Config Class Initialized
INFO - 2023-04-29 14:40:08 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:40:08 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:40:08 --> Utf8 Class Initialized
INFO - 2023-04-29 14:40:08 --> URI Class Initialized
INFO - 2023-04-29 14:40:08 --> Router Class Initialized
INFO - 2023-04-29 14:40:08 --> Output Class Initialized
INFO - 2023-04-29 14:40:08 --> Security Class Initialized
DEBUG - 2023-04-29 14:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:40:08 --> Input Class Initialized
INFO - 2023-04-29 14:40:08 --> Language Class Initialized
ERROR - 2023-04-29 14:40:08 --> 404 Page Not Found: Skripsi4(an)/semakar-adventure
INFO - 2023-04-29 14:40:09 --> Config Class Initialized
INFO - 2023-04-29 14:40:09 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:40:09 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:40:09 --> Utf8 Class Initialized
INFO - 2023-04-29 14:40:09 --> URI Class Initialized
DEBUG - 2023-04-29 14:40:09 --> No URI present. Default controller set.
INFO - 2023-04-29 14:40:09 --> Router Class Initialized
INFO - 2023-04-29 14:40:09 --> Output Class Initialized
INFO - 2023-04-29 14:40:09 --> Security Class Initialized
DEBUG - 2023-04-29 14:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:40:09 --> Input Class Initialized
INFO - 2023-04-29 14:40:09 --> Language Class Initialized
INFO - 2023-04-29 14:40:09 --> Loader Class Initialized
INFO - 2023-04-29 14:40:09 --> Helper loaded: url_helper
INFO - 2023-04-29 14:40:09 --> Helper loaded: form_helper
INFO - 2023-04-29 14:40:09 --> Helper loaded: file_helper
INFO - 2023-04-29 14:40:09 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:40:09 --> Form Validation Class Initialized
INFO - 2023-04-29 14:40:09 --> Upload Class Initialized
INFO - 2023-04-29 14:40:09 --> Model "M_auth" initialized
INFO - 2023-04-29 14:40:09 --> Model "M_user" initialized
INFO - 2023-04-29 14:40:09 --> Model "M_produk" initialized
INFO - 2023-04-29 14:40:09 --> Controller Class Initialized
INFO - 2023-04-29 14:40:09 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:40:09 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:40:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:40:09 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:40:09 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:40:09 --> Model "M_bank" initialized
INFO - 2023-04-29 14:40:09 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:40:09 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:40:09 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/index.php
INFO - 2023-04-29 14:40:09 --> Final output sent to browser
DEBUG - 2023-04-29 14:40:09 --> Total execution time: 0.1274
INFO - 2023-04-29 14:40:11 --> Config Class Initialized
INFO - 2023-04-29 14:40:11 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:40:11 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:40:11 --> Utf8 Class Initialized
INFO - 2023-04-29 14:40:11 --> URI Class Initialized
INFO - 2023-04-29 14:40:11 --> Router Class Initialized
INFO - 2023-04-29 14:40:11 --> Output Class Initialized
INFO - 2023-04-29 14:40:11 --> Security Class Initialized
DEBUG - 2023-04-29 14:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:40:11 --> Input Class Initialized
INFO - 2023-04-29 14:40:11 --> Language Class Initialized
ERROR - 2023-04-29 14:40:11 --> 404 Page Not Found: Skripsi4(an)/semakar-adventure
INFO - 2023-04-29 14:40:13 --> Config Class Initialized
INFO - 2023-04-29 14:40:13 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:40:13 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:40:13 --> Utf8 Class Initialized
INFO - 2023-04-29 14:40:13 --> URI Class Initialized
DEBUG - 2023-04-29 14:40:13 --> No URI present. Default controller set.
INFO - 2023-04-29 14:40:13 --> Router Class Initialized
INFO - 2023-04-29 14:40:13 --> Output Class Initialized
INFO - 2023-04-29 14:40:13 --> Security Class Initialized
DEBUG - 2023-04-29 14:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:40:13 --> Input Class Initialized
INFO - 2023-04-29 14:40:13 --> Language Class Initialized
INFO - 2023-04-29 14:40:13 --> Loader Class Initialized
INFO - 2023-04-29 14:40:13 --> Helper loaded: url_helper
INFO - 2023-04-29 14:40:13 --> Helper loaded: form_helper
INFO - 2023-04-29 14:40:13 --> Helper loaded: file_helper
INFO - 2023-04-29 14:40:13 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:40:13 --> Form Validation Class Initialized
INFO - 2023-04-29 14:40:13 --> Upload Class Initialized
INFO - 2023-04-29 14:40:13 --> Model "M_auth" initialized
INFO - 2023-04-29 14:40:13 --> Model "M_user" initialized
INFO - 2023-04-29 14:40:13 --> Model "M_produk" initialized
INFO - 2023-04-29 14:40:13 --> Controller Class Initialized
INFO - 2023-04-29 14:40:13 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:40:13 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:40:13 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:40:13 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:40:13 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:40:13 --> Model "M_bank" initialized
INFO - 2023-04-29 14:40:13 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:40:13 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:40:13 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/index.php
INFO - 2023-04-29 14:40:13 --> Final output sent to browser
DEBUG - 2023-04-29 14:40:13 --> Total execution time: 0.1299
INFO - 2023-04-29 14:40:15 --> Config Class Initialized
INFO - 2023-04-29 14:40:15 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:40:15 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:40:15 --> Utf8 Class Initialized
INFO - 2023-04-29 14:40:15 --> URI Class Initialized
INFO - 2023-04-29 14:40:15 --> Router Class Initialized
INFO - 2023-04-29 14:40:15 --> Output Class Initialized
INFO - 2023-04-29 14:40:15 --> Security Class Initialized
DEBUG - 2023-04-29 14:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:40:15 --> Input Class Initialized
INFO - 2023-04-29 14:40:15 --> Language Class Initialized
ERROR - 2023-04-29 14:40:15 --> 404 Page Not Found: Skripsi4(an)/semakar-adventure
INFO - 2023-04-29 14:40:16 --> Config Class Initialized
INFO - 2023-04-29 14:40:16 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:40:16 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:40:16 --> Utf8 Class Initialized
INFO - 2023-04-29 14:40:16 --> URI Class Initialized
DEBUG - 2023-04-29 14:40:16 --> No URI present. Default controller set.
INFO - 2023-04-29 14:40:16 --> Router Class Initialized
INFO - 2023-04-29 14:40:16 --> Output Class Initialized
INFO - 2023-04-29 14:40:16 --> Security Class Initialized
DEBUG - 2023-04-29 14:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:40:16 --> Input Class Initialized
INFO - 2023-04-29 14:40:16 --> Language Class Initialized
INFO - 2023-04-29 14:40:16 --> Loader Class Initialized
INFO - 2023-04-29 14:40:16 --> Helper loaded: url_helper
INFO - 2023-04-29 14:40:16 --> Helper loaded: form_helper
INFO - 2023-04-29 14:40:16 --> Helper loaded: file_helper
INFO - 2023-04-29 14:40:16 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:40:16 --> Form Validation Class Initialized
INFO - 2023-04-29 14:40:16 --> Upload Class Initialized
INFO - 2023-04-29 14:40:16 --> Model "M_auth" initialized
INFO - 2023-04-29 14:40:16 --> Model "M_user" initialized
INFO - 2023-04-29 14:40:16 --> Model "M_produk" initialized
INFO - 2023-04-29 14:40:16 --> Controller Class Initialized
INFO - 2023-04-29 14:40:16 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:40:16 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:40:16 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:40:16 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:40:16 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:40:16 --> Model "M_bank" initialized
INFO - 2023-04-29 14:40:16 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:40:16 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:40:16 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/index.php
INFO - 2023-04-29 14:40:16 --> Final output sent to browser
DEBUG - 2023-04-29 14:40:16 --> Total execution time: 0.1291
INFO - 2023-04-29 14:40:22 --> Config Class Initialized
INFO - 2023-04-29 14:40:22 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:40:22 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:40:22 --> Utf8 Class Initialized
INFO - 2023-04-29 14:40:22 --> URI Class Initialized
DEBUG - 2023-04-29 14:40:22 --> No URI present. Default controller set.
INFO - 2023-04-29 14:40:22 --> Router Class Initialized
INFO - 2023-04-29 14:40:22 --> Output Class Initialized
INFO - 2023-04-29 14:40:22 --> Security Class Initialized
DEBUG - 2023-04-29 14:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:40:22 --> Input Class Initialized
INFO - 2023-04-29 14:40:22 --> Language Class Initialized
INFO - 2023-04-29 14:40:22 --> Loader Class Initialized
INFO - 2023-04-29 14:40:22 --> Helper loaded: url_helper
INFO - 2023-04-29 14:40:22 --> Helper loaded: form_helper
INFO - 2023-04-29 14:40:22 --> Helper loaded: file_helper
INFO - 2023-04-29 14:40:22 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:40:22 --> Form Validation Class Initialized
INFO - 2023-04-29 14:40:22 --> Upload Class Initialized
INFO - 2023-04-29 14:40:22 --> Model "M_auth" initialized
INFO - 2023-04-29 14:40:22 --> Model "M_user" initialized
INFO - 2023-04-29 14:40:22 --> Model "M_produk" initialized
INFO - 2023-04-29 14:40:22 --> Controller Class Initialized
INFO - 2023-04-29 14:40:22 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:40:22 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:40:22 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:40:22 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:40:22 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:40:22 --> Model "M_bank" initialized
INFO - 2023-04-29 14:40:22 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:40:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-04-29 14:40:22 --> Email Class Initialized
ERROR - 2023-04-29 14:40:27 --> Severity: Warning --> fsockopen(): Unable to connect to ssl://smtp.googlemail.com:465 (A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond) C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\system\libraries\Email.php 2070
INFO - 2023-04-29 14:40:27 --> Language file loaded: language/english/email_lang.php
INFO - 2023-04-29 14:40:27 --> Config Class Initialized
INFO - 2023-04-29 14:40:27 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:40:27 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:40:27 --> Utf8 Class Initialized
INFO - 2023-04-29 14:40:27 --> URI Class Initialized
DEBUG - 2023-04-29 14:40:27 --> No URI present. Default controller set.
INFO - 2023-04-29 14:40:27 --> Router Class Initialized
INFO - 2023-04-29 14:40:27 --> Output Class Initialized
INFO - 2023-04-29 14:40:27 --> Security Class Initialized
DEBUG - 2023-04-29 14:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:40:27 --> Input Class Initialized
INFO - 2023-04-29 14:40:27 --> Language Class Initialized
INFO - 2023-04-29 14:40:27 --> Loader Class Initialized
INFO - 2023-04-29 14:40:27 --> Helper loaded: url_helper
INFO - 2023-04-29 14:40:27 --> Helper loaded: form_helper
INFO - 2023-04-29 14:40:27 --> Helper loaded: file_helper
INFO - 2023-04-29 14:40:27 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:40:27 --> Form Validation Class Initialized
INFO - 2023-04-29 14:40:27 --> Upload Class Initialized
INFO - 2023-04-29 14:40:27 --> Model "M_auth" initialized
INFO - 2023-04-29 14:40:27 --> Model "M_user" initialized
INFO - 2023-04-29 14:40:27 --> Model "M_produk" initialized
INFO - 2023-04-29 14:40:27 --> Controller Class Initialized
INFO - 2023-04-29 14:40:27 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:40:27 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:40:27 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:40:27 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:40:27 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:40:27 --> Model "M_bank" initialized
INFO - 2023-04-29 14:40:27 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:40:27 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:40:27 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/index.php
INFO - 2023-04-29 14:40:27 --> Final output sent to browser
DEBUG - 2023-04-29 14:40:27 --> Total execution time: 0.1276
INFO - 2023-04-29 14:40:31 --> Config Class Initialized
INFO - 2023-04-29 14:40:31 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:40:31 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:40:31 --> Utf8 Class Initialized
INFO - 2023-04-29 14:40:31 --> URI Class Initialized
INFO - 2023-04-29 14:40:31 --> Router Class Initialized
INFO - 2023-04-29 14:40:31 --> Output Class Initialized
INFO - 2023-04-29 14:40:31 --> Security Class Initialized
DEBUG - 2023-04-29 14:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:40:31 --> Input Class Initialized
INFO - 2023-04-29 14:40:31 --> Language Class Initialized
ERROR - 2023-04-29 14:40:31 --> 404 Page Not Found: Skripsi4(an)/semakar-adventure
INFO - 2023-04-29 14:40:36 --> Config Class Initialized
INFO - 2023-04-29 14:40:36 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:40:36 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:40:36 --> Utf8 Class Initialized
INFO - 2023-04-29 14:40:36 --> URI Class Initialized
DEBUG - 2023-04-29 14:40:36 --> No URI present. Default controller set.
INFO - 2023-04-29 14:40:36 --> Router Class Initialized
INFO - 2023-04-29 14:40:36 --> Output Class Initialized
INFO - 2023-04-29 14:40:36 --> Security Class Initialized
DEBUG - 2023-04-29 14:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:40:36 --> Input Class Initialized
INFO - 2023-04-29 14:40:36 --> Language Class Initialized
INFO - 2023-04-29 14:40:36 --> Loader Class Initialized
INFO - 2023-04-29 14:40:36 --> Helper loaded: url_helper
INFO - 2023-04-29 14:40:36 --> Helper loaded: form_helper
INFO - 2023-04-29 14:40:36 --> Helper loaded: file_helper
INFO - 2023-04-29 14:40:36 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:40:36 --> Form Validation Class Initialized
INFO - 2023-04-29 14:40:36 --> Upload Class Initialized
INFO - 2023-04-29 14:40:36 --> Model "M_auth" initialized
INFO - 2023-04-29 14:40:36 --> Model "M_user" initialized
INFO - 2023-04-29 14:40:36 --> Model "M_produk" initialized
INFO - 2023-04-29 14:40:36 --> Controller Class Initialized
INFO - 2023-04-29 14:40:36 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:40:36 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:40:36 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:40:36 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:40:36 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:40:36 --> Model "M_bank" initialized
INFO - 2023-04-29 14:40:36 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:40:36 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:40:36 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/index.php
INFO - 2023-04-29 14:40:36 --> Final output sent to browser
DEBUG - 2023-04-29 14:40:36 --> Total execution time: 0.1285
INFO - 2023-04-29 14:40:42 --> Config Class Initialized
INFO - 2023-04-29 14:40:42 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:40:42 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:40:42 --> Utf8 Class Initialized
INFO - 2023-04-29 14:40:42 --> URI Class Initialized
INFO - 2023-04-29 14:40:42 --> Router Class Initialized
INFO - 2023-04-29 14:40:42 --> Output Class Initialized
INFO - 2023-04-29 14:40:42 --> Security Class Initialized
DEBUG - 2023-04-29 14:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:40:42 --> Input Class Initialized
INFO - 2023-04-29 14:40:42 --> Language Class Initialized
ERROR - 2023-04-29 14:40:42 --> 404 Page Not Found: Skripsi4(an)/semakar-adventure
INFO - 2023-04-29 14:40:43 --> Config Class Initialized
INFO - 2023-04-29 14:40:43 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:40:43 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:40:43 --> Utf8 Class Initialized
INFO - 2023-04-29 14:40:43 --> URI Class Initialized
DEBUG - 2023-04-29 14:40:43 --> No URI present. Default controller set.
INFO - 2023-04-29 14:40:43 --> Router Class Initialized
INFO - 2023-04-29 14:40:43 --> Output Class Initialized
INFO - 2023-04-29 14:40:43 --> Security Class Initialized
DEBUG - 2023-04-29 14:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:40:43 --> Input Class Initialized
INFO - 2023-04-29 14:40:43 --> Language Class Initialized
INFO - 2023-04-29 14:40:43 --> Loader Class Initialized
INFO - 2023-04-29 14:40:43 --> Helper loaded: url_helper
INFO - 2023-04-29 14:40:43 --> Helper loaded: form_helper
INFO - 2023-04-29 14:40:43 --> Helper loaded: file_helper
INFO - 2023-04-29 14:40:43 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:40:43 --> Form Validation Class Initialized
INFO - 2023-04-29 14:40:43 --> Upload Class Initialized
INFO - 2023-04-29 14:40:43 --> Model "M_auth" initialized
INFO - 2023-04-29 14:40:43 --> Model "M_user" initialized
INFO - 2023-04-29 14:40:43 --> Model "M_produk" initialized
INFO - 2023-04-29 14:40:43 --> Controller Class Initialized
INFO - 2023-04-29 14:40:43 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:40:43 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:40:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:40:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:40:43 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:40:43 --> Model "M_bank" initialized
INFO - 2023-04-29 14:40:43 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:40:43 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:40:43 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/index.php
INFO - 2023-04-29 14:40:43 --> Final output sent to browser
DEBUG - 2023-04-29 14:40:43 --> Total execution time: 0.1330
INFO - 2023-04-29 14:40:57 --> Config Class Initialized
INFO - 2023-04-29 14:40:57 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:40:57 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:40:57 --> Utf8 Class Initialized
INFO - 2023-04-29 14:40:57 --> URI Class Initialized
INFO - 2023-04-29 14:40:57 --> Router Class Initialized
INFO - 2023-04-29 14:40:57 --> Output Class Initialized
INFO - 2023-04-29 14:40:57 --> Security Class Initialized
DEBUG - 2023-04-29 14:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:40:57 --> Input Class Initialized
INFO - 2023-04-29 14:40:57 --> Language Class Initialized
ERROR - 2023-04-29 14:40:57 --> 404 Page Not Found: Skripsi4(an)/semakar-adventure
INFO - 2023-04-29 14:40:59 --> Config Class Initialized
INFO - 2023-04-29 14:40:59 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:40:59 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:40:59 --> Utf8 Class Initialized
INFO - 2023-04-29 14:40:59 --> URI Class Initialized
DEBUG - 2023-04-29 14:40:59 --> No URI present. Default controller set.
INFO - 2023-04-29 14:40:59 --> Router Class Initialized
INFO - 2023-04-29 14:40:59 --> Output Class Initialized
INFO - 2023-04-29 14:40:59 --> Security Class Initialized
DEBUG - 2023-04-29 14:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:40:59 --> Input Class Initialized
INFO - 2023-04-29 14:40:59 --> Language Class Initialized
INFO - 2023-04-29 14:40:59 --> Loader Class Initialized
INFO - 2023-04-29 14:40:59 --> Helper loaded: url_helper
INFO - 2023-04-29 14:40:59 --> Helper loaded: form_helper
INFO - 2023-04-29 14:40:59 --> Helper loaded: file_helper
INFO - 2023-04-29 14:40:59 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:40:59 --> Form Validation Class Initialized
INFO - 2023-04-29 14:40:59 --> Upload Class Initialized
INFO - 2023-04-29 14:40:59 --> Model "M_auth" initialized
INFO - 2023-04-29 14:40:59 --> Model "M_user" initialized
INFO - 2023-04-29 14:40:59 --> Model "M_produk" initialized
INFO - 2023-04-29 14:40:59 --> Controller Class Initialized
INFO - 2023-04-29 14:40:59 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:40:59 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:40:59 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:40:59 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:40:59 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:40:59 --> Model "M_bank" initialized
INFO - 2023-04-29 14:40:59 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:40:59 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/footer.php
INFO - 2023-04-29 14:40:59 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar-adventure\application\views\front/index.php
INFO - 2023-04-29 14:40:59 --> Final output sent to browser
DEBUG - 2023-04-29 14:40:59 --> Total execution time: 0.1295
INFO - 2023-04-29 14:44:11 --> Config Class Initialized
INFO - 2023-04-29 14:44:11 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:44:11 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:44:11 --> Utf8 Class Initialized
INFO - 2023-04-29 14:44:11 --> URI Class Initialized
DEBUG - 2023-04-29 14:44:11 --> No URI present. Default controller set.
INFO - 2023-04-29 14:44:11 --> Router Class Initialized
INFO - 2023-04-29 14:44:11 --> Output Class Initialized
INFO - 2023-04-29 14:44:11 --> Security Class Initialized
DEBUG - 2023-04-29 14:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:44:11 --> Input Class Initialized
INFO - 2023-04-29 14:44:11 --> Language Class Initialized
INFO - 2023-04-29 14:44:11 --> Loader Class Initialized
INFO - 2023-04-29 14:44:11 --> Helper loaded: url_helper
INFO - 2023-04-29 14:44:11 --> Helper loaded: form_helper
INFO - 2023-04-29 14:44:11 --> Helper loaded: file_helper
INFO - 2023-04-29 14:44:11 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:44:11 --> Form Validation Class Initialized
INFO - 2023-04-29 14:44:11 --> Upload Class Initialized
INFO - 2023-04-29 14:44:11 --> Model "M_auth" initialized
INFO - 2023-04-29 14:44:11 --> Model "M_user" initialized
INFO - 2023-04-29 14:44:11 --> Model "M_produk" initialized
INFO - 2023-04-29 14:44:11 --> Controller Class Initialized
INFO - 2023-04-29 14:44:11 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:44:11 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:44:11 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:44:11 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:44:11 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:44:11 --> Model "M_bank" initialized
INFO - 2023-04-29 14:44:11 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:44:11 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-29 14:44:11 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar_adventure\application\views\front/index.php
INFO - 2023-04-29 14:44:11 --> Final output sent to browser
DEBUG - 2023-04-29 14:44:11 --> Total execution time: 0.1535
INFO - 2023-04-29 14:44:17 --> Config Class Initialized
INFO - 2023-04-29 14:44:17 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:44:17 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:44:17 --> Utf8 Class Initialized
INFO - 2023-04-29 14:44:17 --> URI Class Initialized
INFO - 2023-04-29 14:44:17 --> Router Class Initialized
INFO - 2023-04-29 14:44:17 --> Output Class Initialized
INFO - 2023-04-29 14:44:17 --> Security Class Initialized
DEBUG - 2023-04-29 14:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:44:17 --> Input Class Initialized
INFO - 2023-04-29 14:44:17 --> Language Class Initialized
ERROR - 2023-04-29 14:44:17 --> 404 Page Not Found: Skripsi4(an)/semakar_adventure
INFO - 2023-04-29 14:44:24 --> Config Class Initialized
INFO - 2023-04-29 14:44:24 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:44:24 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:44:24 --> Utf8 Class Initialized
INFO - 2023-04-29 14:44:24 --> URI Class Initialized
DEBUG - 2023-04-29 14:44:24 --> No URI present. Default controller set.
INFO - 2023-04-29 14:44:24 --> Router Class Initialized
INFO - 2023-04-29 14:44:24 --> Output Class Initialized
INFO - 2023-04-29 14:44:24 --> Security Class Initialized
DEBUG - 2023-04-29 14:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:44:24 --> Input Class Initialized
INFO - 2023-04-29 14:44:24 --> Language Class Initialized
INFO - 2023-04-29 14:44:24 --> Loader Class Initialized
INFO - 2023-04-29 14:44:24 --> Helper loaded: url_helper
INFO - 2023-04-29 14:44:24 --> Helper loaded: form_helper
INFO - 2023-04-29 14:44:24 --> Helper loaded: file_helper
INFO - 2023-04-29 14:44:24 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:44:24 --> Form Validation Class Initialized
INFO - 2023-04-29 14:44:24 --> Upload Class Initialized
INFO - 2023-04-29 14:44:24 --> Model "M_auth" initialized
INFO - 2023-04-29 14:44:24 --> Model "M_user" initialized
INFO - 2023-04-29 14:44:24 --> Model "M_produk" initialized
INFO - 2023-04-29 14:44:24 --> Controller Class Initialized
INFO - 2023-04-29 14:44:24 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:44:24 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:44:24 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:44:24 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:44:24 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:44:24 --> Model "M_bank" initialized
INFO - 2023-04-29 14:44:24 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:44:24 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-29 14:44:24 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar_adventure\application\views\front/index.php
INFO - 2023-04-29 14:44:24 --> Final output sent to browser
DEBUG - 2023-04-29 14:44:24 --> Total execution time: 0.1298
INFO - 2023-04-29 14:44:29 --> Config Class Initialized
INFO - 2023-04-29 14:44:29 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:44:29 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:44:29 --> Utf8 Class Initialized
INFO - 2023-04-29 14:44:29 --> URI Class Initialized
INFO - 2023-04-29 14:44:29 --> Router Class Initialized
INFO - 2023-04-29 14:44:29 --> Output Class Initialized
INFO - 2023-04-29 14:44:29 --> Security Class Initialized
DEBUG - 2023-04-29 14:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:44:29 --> Input Class Initialized
INFO - 2023-04-29 14:44:29 --> Language Class Initialized
ERROR - 2023-04-29 14:44:29 --> 404 Page Not Found: Skripsi4(an)/semakar_adventure
INFO - 2023-04-29 14:44:33 --> Config Class Initialized
INFO - 2023-04-29 14:44:33 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:44:33 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:44:33 --> Utf8 Class Initialized
INFO - 2023-04-29 14:44:33 --> URI Class Initialized
DEBUG - 2023-04-29 14:44:33 --> No URI present. Default controller set.
INFO - 2023-04-29 14:44:33 --> Router Class Initialized
INFO - 2023-04-29 14:44:33 --> Output Class Initialized
INFO - 2023-04-29 14:44:33 --> Security Class Initialized
DEBUG - 2023-04-29 14:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:44:33 --> Input Class Initialized
INFO - 2023-04-29 14:44:33 --> Language Class Initialized
INFO - 2023-04-29 14:44:33 --> Loader Class Initialized
INFO - 2023-04-29 14:44:33 --> Helper loaded: url_helper
INFO - 2023-04-29 14:44:33 --> Helper loaded: form_helper
INFO - 2023-04-29 14:44:33 --> Helper loaded: file_helper
INFO - 2023-04-29 14:44:33 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:44:33 --> Form Validation Class Initialized
INFO - 2023-04-29 14:44:33 --> Upload Class Initialized
INFO - 2023-04-29 14:44:33 --> Model "M_auth" initialized
INFO - 2023-04-29 14:44:33 --> Model "M_user" initialized
INFO - 2023-04-29 14:44:33 --> Model "M_produk" initialized
INFO - 2023-04-29 14:44:33 --> Controller Class Initialized
INFO - 2023-04-29 14:44:33 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:44:33 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:44:33 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:44:33 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:44:33 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:44:33 --> Model "M_bank" initialized
INFO - 2023-04-29 14:44:33 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:44:33 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-29 14:44:33 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar_adventure\application\views\front/index.php
INFO - 2023-04-29 14:44:33 --> Final output sent to browser
DEBUG - 2023-04-29 14:44:33 --> Total execution time: 0.1303
INFO - 2023-04-29 14:44:36 --> Config Class Initialized
INFO - 2023-04-29 14:44:36 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:44:36 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:44:36 --> Utf8 Class Initialized
INFO - 2023-04-29 14:44:36 --> URI Class Initialized
INFO - 2023-04-29 14:44:36 --> Router Class Initialized
INFO - 2023-04-29 14:44:36 --> Output Class Initialized
INFO - 2023-04-29 14:44:36 --> Security Class Initialized
DEBUG - 2023-04-29 14:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:44:36 --> Input Class Initialized
INFO - 2023-04-29 14:44:36 --> Language Class Initialized
ERROR - 2023-04-29 14:44:36 --> 404 Page Not Found: Skripsi4(an)/semakar_adventure
INFO - 2023-04-29 14:44:53 --> Config Class Initialized
INFO - 2023-04-29 14:44:53 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:44:53 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:44:53 --> Utf8 Class Initialized
INFO - 2023-04-29 14:44:53 --> URI Class Initialized
DEBUG - 2023-04-29 14:44:53 --> No URI present. Default controller set.
INFO - 2023-04-29 14:44:53 --> Router Class Initialized
INFO - 2023-04-29 14:44:53 --> Output Class Initialized
INFO - 2023-04-29 14:44:53 --> Security Class Initialized
DEBUG - 2023-04-29 14:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:44:53 --> Input Class Initialized
INFO - 2023-04-29 14:44:53 --> Language Class Initialized
INFO - 2023-04-29 14:44:53 --> Loader Class Initialized
INFO - 2023-04-29 14:44:53 --> Helper loaded: url_helper
INFO - 2023-04-29 14:44:53 --> Helper loaded: form_helper
INFO - 2023-04-29 14:44:53 --> Helper loaded: file_helper
INFO - 2023-04-29 14:44:53 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:44:53 --> Form Validation Class Initialized
INFO - 2023-04-29 14:44:53 --> Upload Class Initialized
INFO - 2023-04-29 14:44:53 --> Model "M_auth" initialized
INFO - 2023-04-29 14:44:53 --> Model "M_user" initialized
INFO - 2023-04-29 14:44:53 --> Model "M_produk" initialized
INFO - 2023-04-29 14:44:53 --> Controller Class Initialized
INFO - 2023-04-29 14:44:53 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:44:53 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:44:53 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:44:53 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:44:53 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:44:53 --> Model "M_bank" initialized
INFO - 2023-04-29 14:44:53 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:44:53 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-29 14:44:53 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar_adventure\application\views\front/index.php
INFO - 2023-04-29 14:44:53 --> Final output sent to browser
DEBUG - 2023-04-29 14:44:53 --> Total execution time: 0.1367
INFO - 2023-04-29 14:44:56 --> Config Class Initialized
INFO - 2023-04-29 14:44:56 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:44:56 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:44:56 --> Utf8 Class Initialized
INFO - 2023-04-29 14:44:56 --> URI Class Initialized
INFO - 2023-04-29 14:44:56 --> Router Class Initialized
INFO - 2023-04-29 14:44:56 --> Output Class Initialized
INFO - 2023-04-29 14:44:56 --> Security Class Initialized
DEBUG - 2023-04-29 14:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:44:56 --> Input Class Initialized
INFO - 2023-04-29 14:44:56 --> Language Class Initialized
ERROR - 2023-04-29 14:44:56 --> 404 Page Not Found: Skripsi4(an)/semakar_adventure
INFO - 2023-04-29 14:45:01 --> Config Class Initialized
INFO - 2023-04-29 14:45:01 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:45:01 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:45:01 --> Utf8 Class Initialized
INFO - 2023-04-29 14:45:01 --> URI Class Initialized
INFO - 2023-04-29 14:45:01 --> Router Class Initialized
INFO - 2023-04-29 14:45:01 --> Output Class Initialized
INFO - 2023-04-29 14:45:01 --> Security Class Initialized
DEBUG - 2023-04-29 14:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:45:01 --> Input Class Initialized
INFO - 2023-04-29 14:45:01 --> Language Class Initialized
ERROR - 2023-04-29 14:45:01 --> 404 Page Not Found: Skripsi4(an)/semakar_adventure
INFO - 2023-04-29 14:45:27 --> Config Class Initialized
INFO - 2023-04-29 14:45:27 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:45:27 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:45:27 --> Utf8 Class Initialized
INFO - 2023-04-29 14:45:27 --> URI Class Initialized
DEBUG - 2023-04-29 14:45:27 --> No URI present. Default controller set.
INFO - 2023-04-29 14:45:27 --> Router Class Initialized
INFO - 2023-04-29 14:45:27 --> Output Class Initialized
INFO - 2023-04-29 14:45:27 --> Security Class Initialized
DEBUG - 2023-04-29 14:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:45:27 --> Input Class Initialized
INFO - 2023-04-29 14:45:27 --> Language Class Initialized
INFO - 2023-04-29 14:45:27 --> Loader Class Initialized
INFO - 2023-04-29 14:45:27 --> Helper loaded: url_helper
INFO - 2023-04-29 14:45:27 --> Helper loaded: form_helper
INFO - 2023-04-29 14:45:27 --> Helper loaded: file_helper
INFO - 2023-04-29 14:45:27 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:45:27 --> Form Validation Class Initialized
INFO - 2023-04-29 14:45:27 --> Upload Class Initialized
INFO - 2023-04-29 14:45:27 --> Model "M_auth" initialized
INFO - 2023-04-29 14:45:27 --> Model "M_user" initialized
INFO - 2023-04-29 14:45:27 --> Model "M_produk" initialized
INFO - 2023-04-29 14:45:27 --> Controller Class Initialized
INFO - 2023-04-29 14:45:27 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:45:27 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:45:27 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:45:27 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:45:27 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:45:27 --> Model "M_bank" initialized
INFO - 2023-04-29 14:45:27 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:45:27 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-29 14:45:27 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar_adventure\application\views\front/index.php
INFO - 2023-04-29 14:45:27 --> Final output sent to browser
DEBUG - 2023-04-29 14:45:27 --> Total execution time: 0.1164
INFO - 2023-04-29 14:45:28 --> Config Class Initialized
INFO - 2023-04-29 14:45:28 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:45:28 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:45:28 --> Utf8 Class Initialized
INFO - 2023-04-29 14:45:28 --> URI Class Initialized
INFO - 2023-04-29 14:45:28 --> Router Class Initialized
INFO - 2023-04-29 14:45:28 --> Output Class Initialized
INFO - 2023-04-29 14:45:28 --> Security Class Initialized
DEBUG - 2023-04-29 14:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:45:28 --> Input Class Initialized
INFO - 2023-04-29 14:45:28 --> Language Class Initialized
ERROR - 2023-04-29 14:45:28 --> 404 Page Not Found: Skripsi4(an)/semakar_adventure
INFO - 2023-04-29 14:45:31 --> Config Class Initialized
INFO - 2023-04-29 14:45:31 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:45:31 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:45:31 --> Utf8 Class Initialized
INFO - 2023-04-29 14:45:31 --> URI Class Initialized
INFO - 2023-04-29 14:45:31 --> Router Class Initialized
INFO - 2023-04-29 14:45:31 --> Output Class Initialized
INFO - 2023-04-29 14:45:31 --> Security Class Initialized
DEBUG - 2023-04-29 14:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:45:31 --> Input Class Initialized
INFO - 2023-04-29 14:45:31 --> Language Class Initialized
ERROR - 2023-04-29 14:45:31 --> 404 Page Not Found: Skripsi4(an)/semakar_adventure
INFO - 2023-04-29 14:45:58 --> Config Class Initialized
INFO - 2023-04-29 14:45:58 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:45:58 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:45:58 --> Utf8 Class Initialized
INFO - 2023-04-29 14:45:58 --> URI Class Initialized
INFO - 2023-04-29 14:45:58 --> Router Class Initialized
INFO - 2023-04-29 14:45:58 --> Output Class Initialized
INFO - 2023-04-29 14:45:58 --> Security Class Initialized
DEBUG - 2023-04-29 14:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:45:58 --> Input Class Initialized
INFO - 2023-04-29 14:45:58 --> Language Class Initialized
ERROR - 2023-04-29 14:45:58 --> 404 Page Not Found: Skripsi4(an)/semakar_adventure
INFO - 2023-04-29 14:46:08 --> Config Class Initialized
INFO - 2023-04-29 14:46:08 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:46:08 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:46:08 --> Utf8 Class Initialized
INFO - 2023-04-29 14:46:08 --> URI Class Initialized
DEBUG - 2023-04-29 14:46:08 --> No URI present. Default controller set.
INFO - 2023-04-29 14:46:08 --> Router Class Initialized
INFO - 2023-04-29 14:46:08 --> Output Class Initialized
INFO - 2023-04-29 14:46:08 --> Security Class Initialized
DEBUG - 2023-04-29 14:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:46:08 --> Input Class Initialized
INFO - 2023-04-29 14:46:08 --> Language Class Initialized
INFO - 2023-04-29 14:46:08 --> Loader Class Initialized
INFO - 2023-04-29 14:46:08 --> Helper loaded: url_helper
INFO - 2023-04-29 14:46:08 --> Helper loaded: form_helper
INFO - 2023-04-29 14:46:08 --> Helper loaded: file_helper
INFO - 2023-04-29 14:46:08 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:46:08 --> Form Validation Class Initialized
INFO - 2023-04-29 14:46:08 --> Upload Class Initialized
INFO - 2023-04-29 14:46:08 --> Model "M_auth" initialized
INFO - 2023-04-29 14:46:08 --> Model "M_user" initialized
INFO - 2023-04-29 14:46:08 --> Model "M_produk" initialized
INFO - 2023-04-29 14:46:08 --> Controller Class Initialized
INFO - 2023-04-29 14:46:08 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:46:08 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:46:08 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:46:08 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:46:08 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:46:08 --> Model "M_bank" initialized
INFO - 2023-04-29 14:46:08 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:46:08 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-29 14:46:08 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar_adventure\application\views\front/index.php
INFO - 2023-04-29 14:46:08 --> Final output sent to browser
DEBUG - 2023-04-29 14:46:08 --> Total execution time: 0.1836
INFO - 2023-04-29 14:46:10 --> Config Class Initialized
INFO - 2023-04-29 14:46:10 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:46:10 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:46:10 --> Utf8 Class Initialized
INFO - 2023-04-29 14:46:10 --> URI Class Initialized
INFO - 2023-04-29 14:46:10 --> Router Class Initialized
INFO - 2023-04-29 14:46:10 --> Output Class Initialized
INFO - 2023-04-29 14:46:10 --> Security Class Initialized
DEBUG - 2023-04-29 14:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:46:10 --> Input Class Initialized
INFO - 2023-04-29 14:46:10 --> Language Class Initialized
ERROR - 2023-04-29 14:46:10 --> 404 Page Not Found: Skripsi4(an)/semakar_adventure
INFO - 2023-04-29 14:46:24 --> Config Class Initialized
INFO - 2023-04-29 14:46:24 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:46:24 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:46:24 --> Utf8 Class Initialized
INFO - 2023-04-29 14:46:24 --> URI Class Initialized
DEBUG - 2023-04-29 14:46:24 --> No URI present. Default controller set.
INFO - 2023-04-29 14:46:24 --> Router Class Initialized
INFO - 2023-04-29 14:46:24 --> Output Class Initialized
INFO - 2023-04-29 14:46:24 --> Security Class Initialized
DEBUG - 2023-04-29 14:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:46:24 --> Input Class Initialized
INFO - 2023-04-29 14:46:24 --> Language Class Initialized
INFO - 2023-04-29 14:46:24 --> Loader Class Initialized
INFO - 2023-04-29 14:46:24 --> Helper loaded: url_helper
INFO - 2023-04-29 14:46:24 --> Helper loaded: form_helper
INFO - 2023-04-29 14:46:24 --> Helper loaded: file_helper
INFO - 2023-04-29 14:46:24 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:46:24 --> Form Validation Class Initialized
INFO - 2023-04-29 14:46:24 --> Upload Class Initialized
INFO - 2023-04-29 14:46:24 --> Model "M_auth" initialized
INFO - 2023-04-29 14:46:24 --> Model "M_user" initialized
INFO - 2023-04-29 14:46:24 --> Model "M_produk" initialized
INFO - 2023-04-29 14:46:24 --> Controller Class Initialized
INFO - 2023-04-29 14:46:24 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:46:24 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:46:24 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:46:24 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:46:24 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:46:24 --> Model "M_bank" initialized
INFO - 2023-04-29 14:46:24 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:46:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-04-29 14:46:24 --> Email Class Initialized
ERROR - 2023-04-29 14:46:29 --> Severity: Warning --> fsockopen(): Unable to connect to ssl://smtp.googlemail.com:465 (A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond) C:\xampp\htdocs\SKRIPSI4(an)\semakar_adventure\system\libraries\Email.php 2070
INFO - 2023-04-29 14:46:29 --> Language file loaded: language/english/email_lang.php
INFO - 2023-04-29 14:46:29 --> Config Class Initialized
INFO - 2023-04-29 14:46:29 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:46:29 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:46:29 --> Utf8 Class Initialized
INFO - 2023-04-29 14:46:29 --> URI Class Initialized
DEBUG - 2023-04-29 14:46:29 --> No URI present. Default controller set.
INFO - 2023-04-29 14:46:29 --> Router Class Initialized
INFO - 2023-04-29 14:46:29 --> Output Class Initialized
INFO - 2023-04-29 14:46:29 --> Security Class Initialized
DEBUG - 2023-04-29 14:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:46:29 --> Input Class Initialized
INFO - 2023-04-29 14:46:29 --> Language Class Initialized
INFO - 2023-04-29 14:46:29 --> Loader Class Initialized
INFO - 2023-04-29 14:46:29 --> Helper loaded: url_helper
INFO - 2023-04-29 14:46:29 --> Helper loaded: form_helper
INFO - 2023-04-29 14:46:29 --> Helper loaded: file_helper
INFO - 2023-04-29 14:46:29 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:46:29 --> Form Validation Class Initialized
INFO - 2023-04-29 14:46:29 --> Upload Class Initialized
INFO - 2023-04-29 14:46:29 --> Model "M_auth" initialized
INFO - 2023-04-29 14:46:29 --> Model "M_user" initialized
INFO - 2023-04-29 14:46:29 --> Model "M_produk" initialized
INFO - 2023-04-29 14:46:29 --> Controller Class Initialized
INFO - 2023-04-29 14:46:29 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:46:29 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:46:29 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:46:29 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:46:29 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:46:29 --> Model "M_bank" initialized
INFO - 2023-04-29 14:46:29 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:46:29 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-29 14:46:29 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar_adventure\application\views\front/index.php
INFO - 2023-04-29 14:46:29 --> Final output sent to browser
DEBUG - 2023-04-29 14:46:29 --> Total execution time: 0.1408
INFO - 2023-04-29 14:46:30 --> Config Class Initialized
INFO - 2023-04-29 14:46:30 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:46:30 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:46:30 --> Utf8 Class Initialized
INFO - 2023-04-29 14:46:30 --> URI Class Initialized
INFO - 2023-04-29 14:46:30 --> Router Class Initialized
INFO - 2023-04-29 14:46:30 --> Output Class Initialized
INFO - 2023-04-29 14:46:31 --> Security Class Initialized
DEBUG - 2023-04-29 14:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:46:31 --> Input Class Initialized
INFO - 2023-04-29 14:46:31 --> Language Class Initialized
ERROR - 2023-04-29 14:46:31 --> 404 Page Not Found: Skripsi4(an)/semakar_adventure
INFO - 2023-04-29 14:46:47 --> Config Class Initialized
INFO - 2023-04-29 14:46:47 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:46:47 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:46:47 --> Utf8 Class Initialized
INFO - 2023-04-29 14:46:47 --> URI Class Initialized
INFO - 2023-04-29 14:46:47 --> Router Class Initialized
INFO - 2023-04-29 14:46:47 --> Output Class Initialized
INFO - 2023-04-29 14:46:47 --> Security Class Initialized
DEBUG - 2023-04-29 14:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:46:47 --> Input Class Initialized
INFO - 2023-04-29 14:46:47 --> Language Class Initialized
ERROR - 2023-04-29 14:46:47 --> 404 Page Not Found: Skripsi4(an)/semakar_adventure
INFO - 2023-04-29 14:47:26 --> Config Class Initialized
INFO - 2023-04-29 14:47:26 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:47:26 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:47:26 --> Utf8 Class Initialized
INFO - 2023-04-29 14:47:26 --> URI Class Initialized
DEBUG - 2023-04-29 14:47:26 --> No URI present. Default controller set.
INFO - 2023-04-29 14:47:26 --> Router Class Initialized
INFO - 2023-04-29 14:47:26 --> Output Class Initialized
INFO - 2023-04-29 14:47:26 --> Security Class Initialized
DEBUG - 2023-04-29 14:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:47:26 --> Input Class Initialized
INFO - 2023-04-29 14:47:26 --> Language Class Initialized
INFO - 2023-04-29 14:47:26 --> Loader Class Initialized
INFO - 2023-04-29 14:47:26 --> Helper loaded: url_helper
INFO - 2023-04-29 14:47:26 --> Helper loaded: form_helper
INFO - 2023-04-29 14:47:26 --> Helper loaded: file_helper
INFO - 2023-04-29 14:47:26 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:47:26 --> Form Validation Class Initialized
INFO - 2023-04-29 14:47:26 --> Upload Class Initialized
INFO - 2023-04-29 14:47:26 --> Model "M_auth" initialized
INFO - 2023-04-29 14:47:26 --> Model "M_user" initialized
INFO - 2023-04-29 14:47:26 --> Model "M_produk" initialized
INFO - 2023-04-29 14:47:26 --> Controller Class Initialized
INFO - 2023-04-29 14:47:26 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:47:26 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:47:26 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:47:26 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:47:26 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:47:26 --> Model "M_bank" initialized
INFO - 2023-04-29 14:47:26 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:47:26 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-29 14:47:26 --> File loaded: C:\xampp\htdocs\SKRIPSI4(an)\semakar_adventure\application\views\front/index.php
INFO - 2023-04-29 14:47:26 --> Final output sent to browser
DEBUG - 2023-04-29 14:47:26 --> Total execution time: 0.1284
INFO - 2023-04-29 14:47:28 --> Config Class Initialized
INFO - 2023-04-29 14:47:28 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:47:28 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:47:28 --> Utf8 Class Initialized
INFO - 2023-04-29 14:47:28 --> URI Class Initialized
INFO - 2023-04-29 14:47:28 --> Router Class Initialized
INFO - 2023-04-29 14:47:28 --> Output Class Initialized
INFO - 2023-04-29 14:47:28 --> Security Class Initialized
DEBUG - 2023-04-29 14:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:47:28 --> Input Class Initialized
INFO - 2023-04-29 14:47:28 --> Language Class Initialized
ERROR - 2023-04-29 14:47:28 --> 404 Page Not Found: Skripsi4(an)/semakar_adventure
INFO - 2023-04-29 14:47:36 --> Config Class Initialized
INFO - 2023-04-29 14:47:36 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:47:36 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:47:36 --> Utf8 Class Initialized
INFO - 2023-04-29 14:47:36 --> URI Class Initialized
INFO - 2023-04-29 14:47:36 --> Router Class Initialized
INFO - 2023-04-29 14:47:36 --> Output Class Initialized
INFO - 2023-04-29 14:47:36 --> Security Class Initialized
DEBUG - 2023-04-29 14:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:47:36 --> Input Class Initialized
INFO - 2023-04-29 14:47:36 --> Language Class Initialized
ERROR - 2023-04-29 14:47:36 --> 404 Page Not Found: Skripsi4(an)/semakar_adventure
INFO - 2023-04-29 14:48:45 --> Config Class Initialized
INFO - 2023-04-29 14:48:45 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:48:45 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:48:45 --> Utf8 Class Initialized
INFO - 2023-04-29 14:48:45 --> URI Class Initialized
DEBUG - 2023-04-29 14:48:45 --> No URI present. Default controller set.
INFO - 2023-04-29 14:48:45 --> Router Class Initialized
INFO - 2023-04-29 14:48:45 --> Output Class Initialized
INFO - 2023-04-29 14:48:45 --> Security Class Initialized
DEBUG - 2023-04-29 14:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:48:45 --> Input Class Initialized
INFO - 2023-04-29 14:48:45 --> Language Class Initialized
INFO - 2023-04-29 14:48:45 --> Loader Class Initialized
INFO - 2023-04-29 14:48:45 --> Helper loaded: url_helper
INFO - 2023-04-29 14:48:45 --> Helper loaded: form_helper
INFO - 2023-04-29 14:48:45 --> Helper loaded: file_helper
INFO - 2023-04-29 14:48:45 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:48:45 --> Form Validation Class Initialized
INFO - 2023-04-29 14:48:45 --> Upload Class Initialized
INFO - 2023-04-29 14:48:45 --> Model "M_auth" initialized
INFO - 2023-04-29 14:48:45 --> Model "M_user" initialized
INFO - 2023-04-29 14:48:45 --> Model "M_produk" initialized
INFO - 2023-04-29 14:48:45 --> Controller Class Initialized
INFO - 2023-04-29 14:48:45 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:48:45 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:48:45 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:48:45 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:48:45 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:48:45 --> Model "M_bank" initialized
INFO - 2023-04-29 14:48:45 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:48:45 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-29 14:48:45 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-04-29 14:48:45 --> Final output sent to browser
DEBUG - 2023-04-29 14:48:45 --> Total execution time: 0.1091
INFO - 2023-04-29 14:48:50 --> Config Class Initialized
INFO - 2023-04-29 14:48:50 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:48:50 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:48:50 --> Utf8 Class Initialized
INFO - 2023-04-29 14:48:50 --> URI Class Initialized
INFO - 2023-04-29 14:48:50 --> Router Class Initialized
INFO - 2023-04-29 14:48:50 --> Output Class Initialized
INFO - 2023-04-29 14:48:50 --> Security Class Initialized
DEBUG - 2023-04-29 14:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:48:50 --> Input Class Initialized
INFO - 2023-04-29 14:48:50 --> Language Class Initialized
INFO - 2023-04-29 14:48:50 --> Loader Class Initialized
INFO - 2023-04-29 14:48:50 --> Helper loaded: url_helper
INFO - 2023-04-29 14:48:50 --> Helper loaded: form_helper
INFO - 2023-04-29 14:48:50 --> Helper loaded: file_helper
INFO - 2023-04-29 14:48:50 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:48:50 --> Form Validation Class Initialized
INFO - 2023-04-29 14:48:50 --> Upload Class Initialized
INFO - 2023-04-29 14:48:50 --> Model "M_auth" initialized
INFO - 2023-04-29 14:48:50 --> Model "M_user" initialized
INFO - 2023-04-29 14:48:50 --> Model "M_produk" initialized
INFO - 2023-04-29 14:48:50 --> Controller Class Initialized
INFO - 2023-04-29 14:48:50 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:48:50 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:48:50 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:48:50 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:48:50 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:48:50 --> Model "M_bank" initialized
INFO - 2023-04-29 14:48:50 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:48:50 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-29 14:48:50 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/v_produk_detail.php
INFO - 2023-04-29 14:48:50 --> Final output sent to browser
DEBUG - 2023-04-29 14:48:50 --> Total execution time: 0.1134
INFO - 2023-04-29 14:49:01 --> Config Class Initialized
INFO - 2023-04-29 14:49:01 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:49:01 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:49:01 --> Utf8 Class Initialized
INFO - 2023-04-29 14:49:01 --> URI Class Initialized
DEBUG - 2023-04-29 14:49:01 --> No URI present. Default controller set.
INFO - 2023-04-29 14:49:01 --> Router Class Initialized
INFO - 2023-04-29 14:49:01 --> Output Class Initialized
INFO - 2023-04-29 14:49:01 --> Security Class Initialized
DEBUG - 2023-04-29 14:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:49:01 --> Input Class Initialized
INFO - 2023-04-29 14:49:01 --> Language Class Initialized
INFO - 2023-04-29 14:49:01 --> Loader Class Initialized
INFO - 2023-04-29 14:49:01 --> Helper loaded: url_helper
INFO - 2023-04-29 14:49:01 --> Helper loaded: form_helper
INFO - 2023-04-29 14:49:01 --> Helper loaded: file_helper
INFO - 2023-04-29 14:49:02 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:49:02 --> Form Validation Class Initialized
INFO - 2023-04-29 14:49:02 --> Upload Class Initialized
INFO - 2023-04-29 14:49:02 --> Model "M_auth" initialized
INFO - 2023-04-29 14:49:02 --> Model "M_user" initialized
INFO - 2023-04-29 14:49:02 --> Model "M_produk" initialized
INFO - 2023-04-29 14:49:02 --> Controller Class Initialized
INFO - 2023-04-29 14:49:02 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:49:02 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:49:02 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:49:02 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:49:02 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:49:02 --> Model "M_bank" initialized
INFO - 2023-04-29 14:49:02 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:49:02 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-29 14:49:02 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-04-29 14:49:02 --> Final output sent to browser
DEBUG - 2023-04-29 14:49:02 --> Total execution time: 0.1375
INFO - 2023-04-29 14:49:04 --> Config Class Initialized
INFO - 2023-04-29 14:49:04 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:49:04 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:49:04 --> Utf8 Class Initialized
INFO - 2023-04-29 14:49:04 --> URI Class Initialized
INFO - 2023-04-29 14:49:04 --> Router Class Initialized
INFO - 2023-04-29 14:49:04 --> Output Class Initialized
INFO - 2023-04-29 14:49:04 --> Security Class Initialized
DEBUG - 2023-04-29 14:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:49:04 --> Input Class Initialized
INFO - 2023-04-29 14:49:04 --> Language Class Initialized
INFO - 2023-04-29 14:49:04 --> Loader Class Initialized
INFO - 2023-04-29 14:49:04 --> Helper loaded: url_helper
INFO - 2023-04-29 14:49:04 --> Helper loaded: form_helper
INFO - 2023-04-29 14:49:04 --> Helper loaded: file_helper
INFO - 2023-04-29 14:49:04 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:49:04 --> Form Validation Class Initialized
INFO - 2023-04-29 14:49:04 --> Upload Class Initialized
INFO - 2023-04-29 14:49:05 --> Model "M_auth" initialized
INFO - 2023-04-29 14:49:05 --> Model "M_user" initialized
INFO - 2023-04-29 14:49:05 --> Model "M_produk" initialized
INFO - 2023-04-29 14:49:05 --> Controller Class Initialized
INFO - 2023-04-29 14:49:05 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:49:05 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:49:05 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:49:05 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:49:05 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:49:05 --> Model "M_bank" initialized
INFO - 2023-04-29 14:49:05 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:49:05 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-29 14:49:05 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-04-29 14:49:05 --> Final output sent to browser
DEBUG - 2023-04-29 14:49:05 --> Total execution time: 0.1538
INFO - 2023-04-29 14:49:06 --> Config Class Initialized
INFO - 2023-04-29 14:49:06 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:49:06 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:49:06 --> Utf8 Class Initialized
INFO - 2023-04-29 14:49:06 --> URI Class Initialized
INFO - 2023-04-29 14:49:06 --> Router Class Initialized
INFO - 2023-04-29 14:49:06 --> Output Class Initialized
INFO - 2023-04-29 14:49:06 --> Security Class Initialized
DEBUG - 2023-04-29 14:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:49:06 --> Input Class Initialized
INFO - 2023-04-29 14:49:06 --> Language Class Initialized
INFO - 2023-04-29 14:49:06 --> Loader Class Initialized
INFO - 2023-04-29 14:49:06 --> Helper loaded: url_helper
INFO - 2023-04-29 14:49:06 --> Helper loaded: form_helper
INFO - 2023-04-29 14:49:06 --> Helper loaded: file_helper
INFO - 2023-04-29 14:49:06 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:49:06 --> Form Validation Class Initialized
INFO - 2023-04-29 14:49:06 --> Upload Class Initialized
INFO - 2023-04-29 14:49:06 --> Model "M_auth" initialized
INFO - 2023-04-29 14:49:06 --> Model "M_user" initialized
INFO - 2023-04-29 14:49:06 --> Model "M_produk" initialized
INFO - 2023-04-29 14:49:06 --> Controller Class Initialized
INFO - 2023-04-29 14:49:06 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:49:06 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:49:06 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:49:06 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:49:06 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:49:06 --> Model "M_bank" initialized
INFO - 2023-04-29 14:49:06 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:49:06 --> Config Class Initialized
INFO - 2023-04-29 14:49:06 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:49:06 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:49:06 --> Utf8 Class Initialized
INFO - 2023-04-29 14:49:06 --> URI Class Initialized
DEBUG - 2023-04-29 14:49:06 --> No URI present. Default controller set.
INFO - 2023-04-29 14:49:06 --> Router Class Initialized
INFO - 2023-04-29 14:49:06 --> Output Class Initialized
INFO - 2023-04-29 14:49:06 --> Security Class Initialized
DEBUG - 2023-04-29 14:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:49:07 --> Input Class Initialized
INFO - 2023-04-29 14:49:07 --> Language Class Initialized
INFO - 2023-04-29 14:49:07 --> Loader Class Initialized
INFO - 2023-04-29 14:49:07 --> Helper loaded: url_helper
INFO - 2023-04-29 14:49:07 --> Helper loaded: form_helper
INFO - 2023-04-29 14:49:07 --> Helper loaded: file_helper
INFO - 2023-04-29 14:49:07 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:49:07 --> Form Validation Class Initialized
INFO - 2023-04-29 14:49:07 --> Upload Class Initialized
INFO - 2023-04-29 14:49:07 --> Model "M_auth" initialized
INFO - 2023-04-29 14:49:07 --> Model "M_user" initialized
INFO - 2023-04-29 14:49:07 --> Model "M_produk" initialized
INFO - 2023-04-29 14:49:07 --> Controller Class Initialized
INFO - 2023-04-29 14:49:07 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:49:07 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:49:07 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:49:07 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:49:07 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:49:07 --> Model "M_bank" initialized
INFO - 2023-04-29 14:49:07 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:49:07 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-29 14:49:07 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-04-29 14:49:07 --> Final output sent to browser
DEBUG - 2023-04-29 14:49:07 --> Total execution time: 0.1446
INFO - 2023-04-29 14:49:10 --> Config Class Initialized
INFO - 2023-04-29 14:49:10 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:49:10 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:49:10 --> Utf8 Class Initialized
INFO - 2023-04-29 14:49:10 --> URI Class Initialized
INFO - 2023-04-29 14:49:10 --> Router Class Initialized
INFO - 2023-04-29 14:49:10 --> Output Class Initialized
INFO - 2023-04-29 14:49:10 --> Security Class Initialized
DEBUG - 2023-04-29 14:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:49:10 --> Input Class Initialized
INFO - 2023-04-29 14:49:10 --> Language Class Initialized
ERROR - 2023-04-29 14:49:10 --> 404 Page Not Found: A/index
INFO - 2023-04-29 14:49:15 --> Config Class Initialized
INFO - 2023-04-29 14:49:15 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:49:15 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:49:15 --> Utf8 Class Initialized
INFO - 2023-04-29 14:49:15 --> URI Class Initialized
INFO - 2023-04-29 14:49:15 --> Router Class Initialized
INFO - 2023-04-29 14:49:15 --> Output Class Initialized
INFO - 2023-04-29 14:49:15 --> Security Class Initialized
DEBUG - 2023-04-29 14:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:49:15 --> Input Class Initialized
INFO - 2023-04-29 14:49:15 --> Language Class Initialized
INFO - 2023-04-29 14:49:15 --> Loader Class Initialized
INFO - 2023-04-29 14:49:15 --> Helper loaded: url_helper
INFO - 2023-04-29 14:49:15 --> Helper loaded: form_helper
INFO - 2023-04-29 14:49:15 --> Helper loaded: file_helper
INFO - 2023-04-29 14:49:15 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:49:15 --> Form Validation Class Initialized
INFO - 2023-04-29 14:49:15 --> Upload Class Initialized
INFO - 2023-04-29 14:49:15 --> Model "M_auth" initialized
INFO - 2023-04-29 14:49:15 --> Model "M_user" initialized
INFO - 2023-04-29 14:49:15 --> Model "M_produk" initialized
INFO - 2023-04-29 14:49:15 --> Controller Class Initialized
INFO - 2023-04-29 14:49:15 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-04-29 14:49:15 --> Final output sent to browser
DEBUG - 2023-04-29 14:49:15 --> Total execution time: 0.1205
INFO - 2023-04-29 14:49:24 --> Config Class Initialized
INFO - 2023-04-29 14:49:24 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:49:24 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:49:24 --> Utf8 Class Initialized
INFO - 2023-04-29 14:49:24 --> URI Class Initialized
INFO - 2023-04-29 14:49:24 --> Router Class Initialized
INFO - 2023-04-29 14:49:24 --> Output Class Initialized
INFO - 2023-04-29 14:49:24 --> Security Class Initialized
DEBUG - 2023-04-29 14:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:49:24 --> Input Class Initialized
INFO - 2023-04-29 14:49:24 --> Language Class Initialized
INFO - 2023-04-29 14:49:24 --> Loader Class Initialized
INFO - 2023-04-29 14:49:24 --> Helper loaded: url_helper
INFO - 2023-04-29 14:49:24 --> Helper loaded: form_helper
INFO - 2023-04-29 14:49:24 --> Helper loaded: file_helper
INFO - 2023-04-29 14:49:24 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:49:24 --> Form Validation Class Initialized
INFO - 2023-04-29 14:49:24 --> Upload Class Initialized
INFO - 2023-04-29 14:49:24 --> Model "M_auth" initialized
INFO - 2023-04-29 14:49:24 --> Model "M_user" initialized
INFO - 2023-04-29 14:49:24 --> Model "M_produk" initialized
INFO - 2023-04-29 14:49:24 --> Controller Class Initialized
INFO - 2023-04-29 14:49:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-04-29 14:49:24 --> Config Class Initialized
INFO - 2023-04-29 14:49:24 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:49:24 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:49:24 --> Utf8 Class Initialized
INFO - 2023-04-29 14:49:24 --> URI Class Initialized
INFO - 2023-04-29 14:49:24 --> Router Class Initialized
INFO - 2023-04-29 14:49:24 --> Output Class Initialized
INFO - 2023-04-29 14:49:24 --> Security Class Initialized
DEBUG - 2023-04-29 14:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:49:24 --> Input Class Initialized
INFO - 2023-04-29 14:49:24 --> Language Class Initialized
INFO - 2023-04-29 14:49:24 --> Loader Class Initialized
INFO - 2023-04-29 14:49:24 --> Helper loaded: url_helper
INFO - 2023-04-29 14:49:24 --> Helper loaded: form_helper
INFO - 2023-04-29 14:49:24 --> Helper loaded: file_helper
INFO - 2023-04-29 14:49:24 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:49:24 --> Form Validation Class Initialized
INFO - 2023-04-29 14:49:24 --> Upload Class Initialized
INFO - 2023-04-29 14:49:24 --> Model "M_auth" initialized
INFO - 2023-04-29 14:49:24 --> Model "M_user" initialized
INFO - 2023-04-29 14:49:24 --> Model "M_produk" initialized
INFO - 2023-04-29 14:49:24 --> Controller Class Initialized
INFO - 2023-04-29 14:49:24 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 14:49:24 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:49:24 --> Final output sent to browser
DEBUG - 2023-04-29 14:49:24 --> Total execution time: 0.1053
INFO - 2023-04-29 14:49:26 --> Config Class Initialized
INFO - 2023-04-29 14:49:26 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:49:26 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:49:26 --> Utf8 Class Initialized
INFO - 2023-04-29 14:49:26 --> URI Class Initialized
INFO - 2023-04-29 14:49:26 --> Router Class Initialized
INFO - 2023-04-29 14:49:26 --> Output Class Initialized
INFO - 2023-04-29 14:49:26 --> Security Class Initialized
DEBUG - 2023-04-29 14:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:49:26 --> Input Class Initialized
INFO - 2023-04-29 14:49:26 --> Language Class Initialized
INFO - 2023-04-29 14:49:26 --> Loader Class Initialized
INFO - 2023-04-29 14:49:26 --> Helper loaded: url_helper
INFO - 2023-04-29 14:49:26 --> Helper loaded: form_helper
INFO - 2023-04-29 14:49:26 --> Helper loaded: file_helper
INFO - 2023-04-29 14:49:26 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:49:26 --> Form Validation Class Initialized
INFO - 2023-04-29 14:49:26 --> Upload Class Initialized
INFO - 2023-04-29 14:49:26 --> Model "M_auth" initialized
INFO - 2023-04-29 14:49:26 --> Model "M_user" initialized
INFO - 2023-04-29 14:49:26 --> Model "M_produk" initialized
INFO - 2023-04-29 14:49:26 --> Controller Class Initialized
INFO - 2023-04-29 14:49:26 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:49:26 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:49:26 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:49:26 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:49:26 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:49:26 --> Model "M_bank" initialized
INFO - 2023-04-29 14:49:26 --> Model "M_pesan" initialized
ERROR - 2023-04-29 14:49:26 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 14:49:26 --> Config Class Initialized
INFO - 2023-04-29 14:49:26 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:49:26 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:49:26 --> Utf8 Class Initialized
INFO - 2023-04-29 14:49:26 --> URI Class Initialized
INFO - 2023-04-29 14:49:26 --> Router Class Initialized
INFO - 2023-04-29 14:49:26 --> Output Class Initialized
INFO - 2023-04-29 14:49:26 --> Security Class Initialized
DEBUG - 2023-04-29 14:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:49:26 --> Input Class Initialized
INFO - 2023-04-29 14:49:26 --> Language Class Initialized
ERROR - 2023-04-29 14:49:26 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 14:49:28 --> Config Class Initialized
INFO - 2023-04-29 14:49:28 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:49:28 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:49:28 --> Utf8 Class Initialized
INFO - 2023-04-29 14:49:28 --> URI Class Initialized
INFO - 2023-04-29 14:49:28 --> Router Class Initialized
INFO - 2023-04-29 14:49:28 --> Output Class Initialized
INFO - 2023-04-29 14:49:28 --> Security Class Initialized
DEBUG - 2023-04-29 14:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:49:28 --> Input Class Initialized
INFO - 2023-04-29 14:49:28 --> Language Class Initialized
INFO - 2023-04-29 14:49:28 --> Loader Class Initialized
INFO - 2023-04-29 14:49:28 --> Helper loaded: url_helper
INFO - 2023-04-29 14:49:28 --> Helper loaded: form_helper
INFO - 2023-04-29 14:49:28 --> Helper loaded: file_helper
INFO - 2023-04-29 14:49:28 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:49:28 --> Form Validation Class Initialized
INFO - 2023-04-29 14:49:28 --> Upload Class Initialized
INFO - 2023-04-29 14:49:28 --> Model "M_auth" initialized
INFO - 2023-04-29 14:49:28 --> Model "M_user" initialized
INFO - 2023-04-29 14:49:28 --> Model "M_produk" initialized
INFO - 2023-04-29 14:49:28 --> Controller Class Initialized
INFO - 2023-04-29 14:49:28 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 14:49:28 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:49:28 --> Final output sent to browser
DEBUG - 2023-04-29 14:49:28 --> Total execution time: 0.1164
INFO - 2023-04-29 14:49:32 --> Config Class Initialized
INFO - 2023-04-29 14:49:32 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:49:32 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:49:32 --> Utf8 Class Initialized
INFO - 2023-04-29 14:49:32 --> URI Class Initialized
INFO - 2023-04-29 14:49:32 --> Router Class Initialized
INFO - 2023-04-29 14:49:32 --> Output Class Initialized
INFO - 2023-04-29 14:49:32 --> Security Class Initialized
DEBUG - 2023-04-29 14:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:49:32 --> Input Class Initialized
INFO - 2023-04-29 14:49:32 --> Language Class Initialized
INFO - 2023-04-29 14:49:32 --> Loader Class Initialized
INFO - 2023-04-29 14:49:32 --> Helper loaded: url_helper
INFO - 2023-04-29 14:49:32 --> Helper loaded: form_helper
INFO - 2023-04-29 14:49:32 --> Helper loaded: file_helper
INFO - 2023-04-29 14:49:32 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:49:32 --> Form Validation Class Initialized
INFO - 2023-04-29 14:49:32 --> Upload Class Initialized
INFO - 2023-04-29 14:49:32 --> Model "M_auth" initialized
INFO - 2023-04-29 14:49:32 --> Model "M_user" initialized
INFO - 2023-04-29 14:49:32 --> Model "M_produk" initialized
INFO - 2023-04-29 14:49:32 --> Controller Class Initialized
INFO - 2023-04-29 14:49:32 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:49:32 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:49:32 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:49:32 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:49:32 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:49:32 --> Model "M_bank" initialized
INFO - 2023-04-29 14:49:32 --> Model "M_pesan" initialized
ERROR - 2023-04-29 14:49:32 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 14:49:32 --> Config Class Initialized
INFO - 2023-04-29 14:49:32 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:49:32 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:49:32 --> Utf8 Class Initialized
INFO - 2023-04-29 14:49:32 --> URI Class Initialized
INFO - 2023-04-29 14:49:32 --> Router Class Initialized
INFO - 2023-04-29 14:49:32 --> Output Class Initialized
INFO - 2023-04-29 14:49:32 --> Security Class Initialized
DEBUG - 2023-04-29 14:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:49:32 --> Input Class Initialized
INFO - 2023-04-29 14:49:32 --> Language Class Initialized
ERROR - 2023-04-29 14:49:32 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 14:50:00 --> Config Class Initialized
INFO - 2023-04-29 14:50:00 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:50:00 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:50:00 --> Utf8 Class Initialized
INFO - 2023-04-29 14:50:00 --> URI Class Initialized
INFO - 2023-04-29 14:50:00 --> Router Class Initialized
INFO - 2023-04-29 14:50:00 --> Output Class Initialized
INFO - 2023-04-29 14:50:00 --> Security Class Initialized
DEBUG - 2023-04-29 14:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:50:00 --> Input Class Initialized
INFO - 2023-04-29 14:50:00 --> Language Class Initialized
ERROR - 2023-04-29 14:50:00 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 14:50:01 --> Config Class Initialized
INFO - 2023-04-29 14:50:01 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:50:01 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:50:01 --> Utf8 Class Initialized
INFO - 2023-04-29 14:50:01 --> URI Class Initialized
INFO - 2023-04-29 14:50:01 --> Router Class Initialized
INFO - 2023-04-29 14:50:01 --> Output Class Initialized
INFO - 2023-04-29 14:50:01 --> Security Class Initialized
DEBUG - 2023-04-29 14:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:50:01 --> Input Class Initialized
INFO - 2023-04-29 14:50:01 --> Language Class Initialized
INFO - 2023-04-29 14:50:01 --> Loader Class Initialized
INFO - 2023-04-29 14:50:01 --> Helper loaded: url_helper
INFO - 2023-04-29 14:50:01 --> Helper loaded: form_helper
INFO - 2023-04-29 14:50:01 --> Helper loaded: file_helper
INFO - 2023-04-29 14:50:01 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:50:01 --> Form Validation Class Initialized
INFO - 2023-04-29 14:50:01 --> Upload Class Initialized
INFO - 2023-04-29 14:50:01 --> Model "M_auth" initialized
INFO - 2023-04-29 14:50:01 --> Model "M_user" initialized
INFO - 2023-04-29 14:50:01 --> Model "M_produk" initialized
INFO - 2023-04-29 14:50:01 --> Controller Class Initialized
INFO - 2023-04-29 14:50:01 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 14:50:01 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:50:01 --> Final output sent to browser
DEBUG - 2023-04-29 14:50:01 --> Total execution time: 0.1379
INFO - 2023-04-29 14:50:21 --> Config Class Initialized
INFO - 2023-04-29 14:50:21 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:50:21 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:50:21 --> Utf8 Class Initialized
INFO - 2023-04-29 14:50:21 --> URI Class Initialized
DEBUG - 2023-04-29 14:50:21 --> No URI present. Default controller set.
INFO - 2023-04-29 14:50:21 --> Router Class Initialized
INFO - 2023-04-29 14:50:21 --> Output Class Initialized
INFO - 2023-04-29 14:50:21 --> Security Class Initialized
DEBUG - 2023-04-29 14:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:50:21 --> Input Class Initialized
INFO - 2023-04-29 14:50:21 --> Language Class Initialized
INFO - 2023-04-29 14:50:21 --> Loader Class Initialized
INFO - 2023-04-29 14:50:21 --> Helper loaded: url_helper
INFO - 2023-04-29 14:50:21 --> Helper loaded: form_helper
INFO - 2023-04-29 14:50:21 --> Helper loaded: file_helper
INFO - 2023-04-29 14:50:21 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:50:21 --> Form Validation Class Initialized
INFO - 2023-04-29 14:50:21 --> Upload Class Initialized
INFO - 2023-04-29 14:50:21 --> Model "M_auth" initialized
INFO - 2023-04-29 14:50:21 --> Model "M_user" initialized
INFO - 2023-04-29 14:50:21 --> Model "M_produk" initialized
INFO - 2023-04-29 14:50:21 --> Controller Class Initialized
INFO - 2023-04-29 14:50:21 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:50:21 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:50:21 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:50:21 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:50:21 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:50:21 --> Model "M_bank" initialized
INFO - 2023-04-29 14:50:21 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:50:21 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-29 14:50:21 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-04-29 14:50:21 --> Final output sent to browser
DEBUG - 2023-04-29 14:50:21 --> Total execution time: 0.1444
INFO - 2023-04-29 14:50:26 --> Config Class Initialized
INFO - 2023-04-29 14:50:26 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:50:26 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:50:26 --> Utf8 Class Initialized
INFO - 2023-04-29 14:50:26 --> URI Class Initialized
INFO - 2023-04-29 14:50:26 --> Router Class Initialized
INFO - 2023-04-29 14:50:26 --> Output Class Initialized
INFO - 2023-04-29 14:50:26 --> Security Class Initialized
DEBUG - 2023-04-29 14:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:50:26 --> Input Class Initialized
INFO - 2023-04-29 14:50:26 --> Language Class Initialized
INFO - 2023-04-29 14:50:26 --> Loader Class Initialized
INFO - 2023-04-29 14:50:26 --> Helper loaded: url_helper
INFO - 2023-04-29 14:50:26 --> Helper loaded: form_helper
INFO - 2023-04-29 14:50:26 --> Helper loaded: file_helper
INFO - 2023-04-29 14:50:26 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:50:26 --> Form Validation Class Initialized
INFO - 2023-04-29 14:50:26 --> Upload Class Initialized
INFO - 2023-04-29 14:50:26 --> Model "M_auth" initialized
INFO - 2023-04-29 14:50:26 --> Model "M_user" initialized
INFO - 2023-04-29 14:50:26 --> Model "M_produk" initialized
INFO - 2023-04-29 14:50:26 --> Controller Class Initialized
INFO - 2023-04-29 14:50:26 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:50:26 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:50:26 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:50:26 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:50:26 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:50:26 --> Model "M_bank" initialized
INFO - 2023-04-29 14:50:26 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:50:26 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-29 14:50:26 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/v_produk_detail.php
INFO - 2023-04-29 14:50:26 --> Final output sent to browser
DEBUG - 2023-04-29 14:50:26 --> Total execution time: 0.1257
INFO - 2023-04-29 14:50:29 --> Config Class Initialized
INFO - 2023-04-29 14:50:29 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:50:29 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:50:29 --> Utf8 Class Initialized
INFO - 2023-04-29 14:50:29 --> URI Class Initialized
DEBUG - 2023-04-29 14:50:29 --> No URI present. Default controller set.
INFO - 2023-04-29 14:50:29 --> Router Class Initialized
INFO - 2023-04-29 14:50:29 --> Output Class Initialized
INFO - 2023-04-29 14:50:29 --> Security Class Initialized
DEBUG - 2023-04-29 14:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:50:29 --> Input Class Initialized
INFO - 2023-04-29 14:50:29 --> Language Class Initialized
INFO - 2023-04-29 14:50:29 --> Loader Class Initialized
INFO - 2023-04-29 14:50:29 --> Helper loaded: url_helper
INFO - 2023-04-29 14:50:29 --> Helper loaded: form_helper
INFO - 2023-04-29 14:50:29 --> Helper loaded: file_helper
INFO - 2023-04-29 14:50:29 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:50:29 --> Form Validation Class Initialized
INFO - 2023-04-29 14:50:29 --> Upload Class Initialized
INFO - 2023-04-29 14:50:29 --> Model "M_auth" initialized
INFO - 2023-04-29 14:50:29 --> Model "M_user" initialized
INFO - 2023-04-29 14:50:29 --> Model "M_produk" initialized
INFO - 2023-04-29 14:50:29 --> Controller Class Initialized
INFO - 2023-04-29 14:50:29 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:50:29 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:50:29 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:50:29 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:50:29 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:50:29 --> Model "M_bank" initialized
INFO - 2023-04-29 14:50:29 --> Model "M_pesan" initialized
INFO - 2023-04-29 14:50:29 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-29 14:50:29 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-04-29 14:50:29 --> Final output sent to browser
DEBUG - 2023-04-29 14:50:29 --> Total execution time: 0.1623
INFO - 2023-04-29 14:50:34 --> Config Class Initialized
INFO - 2023-04-29 14:50:34 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:50:34 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:50:34 --> Utf8 Class Initialized
INFO - 2023-04-29 14:50:34 --> URI Class Initialized
INFO - 2023-04-29 14:50:34 --> Router Class Initialized
INFO - 2023-04-29 14:50:34 --> Output Class Initialized
INFO - 2023-04-29 14:50:34 --> Security Class Initialized
DEBUG - 2023-04-29 14:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:50:34 --> Input Class Initialized
INFO - 2023-04-29 14:50:34 --> Language Class Initialized
INFO - 2023-04-29 14:50:34 --> Loader Class Initialized
INFO - 2023-04-29 14:50:34 --> Helper loaded: url_helper
INFO - 2023-04-29 14:50:34 --> Helper loaded: form_helper
INFO - 2023-04-29 14:50:34 --> Helper loaded: file_helper
INFO - 2023-04-29 14:50:34 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:50:34 --> Form Validation Class Initialized
INFO - 2023-04-29 14:50:34 --> Upload Class Initialized
INFO - 2023-04-29 14:50:34 --> Model "M_auth" initialized
INFO - 2023-04-29 14:50:34 --> Model "M_user" initialized
INFO - 2023-04-29 14:50:34 --> Model "M_produk" initialized
INFO - 2023-04-29 14:50:34 --> Controller Class Initialized
INFO - 2023-04-29 14:50:34 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-04-29 14:50:34 --> Final output sent to browser
DEBUG - 2023-04-29 14:50:34 --> Total execution time: 0.1499
INFO - 2023-04-29 14:50:40 --> Config Class Initialized
INFO - 2023-04-29 14:50:40 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:50:40 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:50:40 --> Utf8 Class Initialized
INFO - 2023-04-29 14:50:40 --> URI Class Initialized
INFO - 2023-04-29 14:50:40 --> Router Class Initialized
INFO - 2023-04-29 14:50:40 --> Output Class Initialized
INFO - 2023-04-29 14:50:40 --> Security Class Initialized
DEBUG - 2023-04-29 14:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:50:40 --> Input Class Initialized
INFO - 2023-04-29 14:50:40 --> Language Class Initialized
INFO - 2023-04-29 14:50:40 --> Loader Class Initialized
INFO - 2023-04-29 14:50:40 --> Helper loaded: url_helper
INFO - 2023-04-29 14:50:40 --> Helper loaded: form_helper
INFO - 2023-04-29 14:50:40 --> Helper loaded: file_helper
INFO - 2023-04-29 14:50:40 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:50:40 --> Form Validation Class Initialized
INFO - 2023-04-29 14:50:40 --> Upload Class Initialized
INFO - 2023-04-29 14:50:40 --> Model "M_auth" initialized
INFO - 2023-04-29 14:50:40 --> Model "M_user" initialized
INFO - 2023-04-29 14:50:40 --> Model "M_produk" initialized
INFO - 2023-04-29 14:50:40 --> Controller Class Initialized
INFO - 2023-04-29 14:50:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-04-29 14:50:41 --> Config Class Initialized
INFO - 2023-04-29 14:50:41 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:50:41 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:50:41 --> Utf8 Class Initialized
INFO - 2023-04-29 14:50:41 --> URI Class Initialized
INFO - 2023-04-29 14:50:41 --> Router Class Initialized
INFO - 2023-04-29 14:50:41 --> Output Class Initialized
INFO - 2023-04-29 14:50:41 --> Security Class Initialized
DEBUG - 2023-04-29 14:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:50:41 --> Input Class Initialized
INFO - 2023-04-29 14:50:41 --> Language Class Initialized
INFO - 2023-04-29 14:50:41 --> Loader Class Initialized
INFO - 2023-04-29 14:50:41 --> Helper loaded: url_helper
INFO - 2023-04-29 14:50:41 --> Helper loaded: form_helper
INFO - 2023-04-29 14:50:41 --> Helper loaded: file_helper
INFO - 2023-04-29 14:50:41 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:50:41 --> Form Validation Class Initialized
INFO - 2023-04-29 14:50:41 --> Upload Class Initialized
INFO - 2023-04-29 14:50:41 --> Model "M_auth" initialized
INFO - 2023-04-29 14:50:41 --> Model "M_user" initialized
INFO - 2023-04-29 14:50:41 --> Model "M_produk" initialized
INFO - 2023-04-29 14:50:41 --> Controller Class Initialized
INFO - 2023-04-29 14:50:41 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 14:50:41 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:50:41 --> Final output sent to browser
DEBUG - 2023-04-29 14:50:41 --> Total execution time: 0.1028
INFO - 2023-04-29 14:50:47 --> Config Class Initialized
INFO - 2023-04-29 14:50:47 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:50:47 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:50:47 --> Utf8 Class Initialized
INFO - 2023-04-29 14:50:47 --> URI Class Initialized
INFO - 2023-04-29 14:50:47 --> Router Class Initialized
INFO - 2023-04-29 14:50:47 --> Output Class Initialized
INFO - 2023-04-29 14:50:47 --> Security Class Initialized
DEBUG - 2023-04-29 14:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:50:47 --> Input Class Initialized
INFO - 2023-04-29 14:50:47 --> Language Class Initialized
INFO - 2023-04-29 14:50:47 --> Loader Class Initialized
INFO - 2023-04-29 14:50:47 --> Helper loaded: url_helper
INFO - 2023-04-29 14:50:47 --> Helper loaded: form_helper
INFO - 2023-04-29 14:50:47 --> Helper loaded: file_helper
INFO - 2023-04-29 14:50:47 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:50:47 --> Form Validation Class Initialized
INFO - 2023-04-29 14:50:47 --> Upload Class Initialized
INFO - 2023-04-29 14:50:47 --> Model "M_auth" initialized
INFO - 2023-04-29 14:50:47 --> Model "M_user" initialized
INFO - 2023-04-29 14:50:47 --> Model "M_produk" initialized
INFO - 2023-04-29 14:50:47 --> Controller Class Initialized
INFO - 2023-04-29 14:50:47 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:50:47 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:50:47 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:50:47 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:50:47 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:50:47 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_transaksi_all.php
INFO - 2023-04-29 14:50:47 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:50:47 --> Final output sent to browser
DEBUG - 2023-04-29 14:50:47 --> Total execution time: 0.1352
INFO - 2023-04-29 14:50:49 --> Config Class Initialized
INFO - 2023-04-29 14:50:49 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:50:49 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:50:49 --> Utf8 Class Initialized
INFO - 2023-04-29 14:50:49 --> URI Class Initialized
INFO - 2023-04-29 14:50:49 --> Router Class Initialized
INFO - 2023-04-29 14:50:49 --> Output Class Initialized
INFO - 2023-04-29 14:50:49 --> Security Class Initialized
DEBUG - 2023-04-29 14:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:50:49 --> Input Class Initialized
INFO - 2023-04-29 14:50:49 --> Language Class Initialized
INFO - 2023-04-29 14:50:49 --> Loader Class Initialized
INFO - 2023-04-29 14:50:49 --> Helper loaded: url_helper
INFO - 2023-04-29 14:50:49 --> Helper loaded: form_helper
INFO - 2023-04-29 14:50:49 --> Helper loaded: file_helper
INFO - 2023-04-29 14:50:49 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:50:49 --> Form Validation Class Initialized
INFO - 2023-04-29 14:50:49 --> Upload Class Initialized
INFO - 2023-04-29 14:50:49 --> Model "M_auth" initialized
INFO - 2023-04-29 14:50:49 --> Model "M_user" initialized
INFO - 2023-04-29 14:50:49 --> Model "M_produk" initialized
INFO - 2023-04-29 14:50:49 --> Controller Class Initialized
INFO - 2023-04-29 14:50:49 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:50:49 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:50:49 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:50:49 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:50:49 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:50:49 --> Model "M_bank" initialized
INFO - 2023-04-29 14:50:49 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_all_bank.php
INFO - 2023-04-29 14:50:49 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:50:49 --> Final output sent to browser
DEBUG - 2023-04-29 14:50:49 --> Total execution time: 0.1863
INFO - 2023-04-29 14:50:53 --> Config Class Initialized
INFO - 2023-04-29 14:50:53 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:50:53 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:50:53 --> Utf8 Class Initialized
INFO - 2023-04-29 14:50:53 --> URI Class Initialized
INFO - 2023-04-29 14:50:53 --> Router Class Initialized
INFO - 2023-04-29 14:50:53 --> Output Class Initialized
INFO - 2023-04-29 14:50:53 --> Security Class Initialized
DEBUG - 2023-04-29 14:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:50:53 --> Input Class Initialized
INFO - 2023-04-29 14:50:53 --> Language Class Initialized
INFO - 2023-04-29 14:50:53 --> Loader Class Initialized
INFO - 2023-04-29 14:50:53 --> Helper loaded: url_helper
INFO - 2023-04-29 14:50:53 --> Helper loaded: form_helper
INFO - 2023-04-29 14:50:53 --> Helper loaded: file_helper
INFO - 2023-04-29 14:50:53 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:50:53 --> Form Validation Class Initialized
INFO - 2023-04-29 14:50:53 --> Upload Class Initialized
INFO - 2023-04-29 14:50:53 --> Model "M_auth" initialized
INFO - 2023-04-29 14:50:53 --> Model "M_user" initialized
INFO - 2023-04-29 14:50:53 --> Model "M_produk" initialized
INFO - 2023-04-29 14:50:53 --> Controller Class Initialized
INFO - 2023-04-29 14:50:53 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:50:53 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:50:53 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:50:53 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:50:53 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:50:53 --> Model "M_bank" initialized
INFO - 2023-04-29 14:50:53 --> Model "M_pesan" initialized
ERROR - 2023-04-29 14:50:53 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 14:50:53 --> Config Class Initialized
INFO - 2023-04-29 14:50:53 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:50:53 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:50:53 --> Utf8 Class Initialized
INFO - 2023-04-29 14:50:53 --> URI Class Initialized
INFO - 2023-04-29 14:50:53 --> Router Class Initialized
INFO - 2023-04-29 14:50:53 --> Output Class Initialized
INFO - 2023-04-29 14:50:53 --> Security Class Initialized
DEBUG - 2023-04-29 14:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:50:53 --> Input Class Initialized
INFO - 2023-04-29 14:50:53 --> Language Class Initialized
ERROR - 2023-04-29 14:50:53 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 14:51:36 --> Config Class Initialized
INFO - 2023-04-29 14:51:36 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:51:36 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:51:36 --> Utf8 Class Initialized
INFO - 2023-04-29 14:51:36 --> URI Class Initialized
INFO - 2023-04-29 14:51:36 --> Router Class Initialized
INFO - 2023-04-29 14:51:36 --> Output Class Initialized
INFO - 2023-04-29 14:51:36 --> Security Class Initialized
DEBUG - 2023-04-29 14:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:51:36 --> Input Class Initialized
INFO - 2023-04-29 14:51:36 --> Language Class Initialized
INFO - 2023-04-29 14:51:36 --> Loader Class Initialized
INFO - 2023-04-29 14:51:36 --> Helper loaded: url_helper
INFO - 2023-04-29 14:51:36 --> Helper loaded: form_helper
INFO - 2023-04-29 14:51:36 --> Helper loaded: file_helper
INFO - 2023-04-29 14:51:36 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:51:36 --> Form Validation Class Initialized
INFO - 2023-04-29 14:51:36 --> Upload Class Initialized
INFO - 2023-04-29 14:51:36 --> Model "M_auth" initialized
INFO - 2023-04-29 14:51:36 --> Model "M_user" initialized
INFO - 2023-04-29 14:51:36 --> Model "M_produk" initialized
INFO - 2023-04-29 14:51:36 --> Controller Class Initialized
INFO - 2023-04-29 14:51:36 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:51:36 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:51:36 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:51:36 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:51:36 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:51:36 --> Model "M_bank" initialized
INFO - 2023-04-29 14:51:36 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_all_bank.php
INFO - 2023-04-29 14:51:36 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:51:36 --> Final output sent to browser
DEBUG - 2023-04-29 14:51:36 --> Total execution time: 0.2253
INFO - 2023-04-29 14:58:34 --> Config Class Initialized
INFO - 2023-04-29 14:58:34 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:58:34 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:58:34 --> Utf8 Class Initialized
INFO - 2023-04-29 14:58:34 --> URI Class Initialized
INFO - 2023-04-29 14:58:34 --> Router Class Initialized
INFO - 2023-04-29 14:58:34 --> Output Class Initialized
INFO - 2023-04-29 14:58:34 --> Security Class Initialized
DEBUG - 2023-04-29 14:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:58:34 --> Input Class Initialized
INFO - 2023-04-29 14:58:34 --> Language Class Initialized
INFO - 2023-04-29 14:58:34 --> Loader Class Initialized
INFO - 2023-04-29 14:58:34 --> Helper loaded: url_helper
INFO - 2023-04-29 14:58:34 --> Helper loaded: form_helper
INFO - 2023-04-29 14:58:34 --> Helper loaded: file_helper
INFO - 2023-04-29 14:58:34 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:58:34 --> Form Validation Class Initialized
INFO - 2023-04-29 14:58:34 --> Upload Class Initialized
INFO - 2023-04-29 14:58:34 --> Model "M_auth" initialized
INFO - 2023-04-29 14:58:34 --> Model "M_user" initialized
INFO - 2023-04-29 14:58:34 --> Model "M_produk" initialized
INFO - 2023-04-29 14:58:34 --> Controller Class Initialized
INFO - 2023-04-29 14:58:34 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:58:34 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:58:34 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:58:34 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:58:34 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:58:34 --> Model "M_bank" initialized
INFO - 2023-04-29 14:58:34 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_all_bank.php
INFO - 2023-04-29 14:58:34 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:58:34 --> Final output sent to browser
DEBUG - 2023-04-29 14:58:34 --> Total execution time: 0.1608
INFO - 2023-04-29 14:58:36 --> Config Class Initialized
INFO - 2023-04-29 14:58:36 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:58:36 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:58:36 --> Utf8 Class Initialized
INFO - 2023-04-29 14:58:36 --> URI Class Initialized
INFO - 2023-04-29 14:58:36 --> Router Class Initialized
INFO - 2023-04-29 14:58:36 --> Output Class Initialized
INFO - 2023-04-29 14:58:36 --> Security Class Initialized
DEBUG - 2023-04-29 14:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:58:36 --> Input Class Initialized
INFO - 2023-04-29 14:58:36 --> Language Class Initialized
INFO - 2023-04-29 14:58:36 --> Loader Class Initialized
INFO - 2023-04-29 14:58:36 --> Helper loaded: url_helper
INFO - 2023-04-29 14:58:36 --> Helper loaded: form_helper
INFO - 2023-04-29 14:58:36 --> Helper loaded: file_helper
INFO - 2023-04-29 14:58:36 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:58:36 --> Form Validation Class Initialized
INFO - 2023-04-29 14:58:36 --> Upload Class Initialized
INFO - 2023-04-29 14:58:36 --> Model "M_auth" initialized
INFO - 2023-04-29 14:58:36 --> Model "M_user" initialized
INFO - 2023-04-29 14:58:37 --> Model "M_produk" initialized
INFO - 2023-04-29 14:58:37 --> Controller Class Initialized
INFO - 2023-04-29 14:58:37 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:58:37 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:58:37 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:58:37 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:58:37 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:58:37 --> Model "M_bank" initialized
INFO - 2023-04-29 14:58:37 --> Model "M_pesan" initialized
ERROR - 2023-04-29 14:58:37 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 14:58:37 --> Config Class Initialized
INFO - 2023-04-29 14:58:37 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:58:37 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:58:37 --> Utf8 Class Initialized
INFO - 2023-04-29 14:58:37 --> URI Class Initialized
INFO - 2023-04-29 14:58:37 --> Router Class Initialized
INFO - 2023-04-29 14:58:37 --> Output Class Initialized
INFO - 2023-04-29 14:58:37 --> Security Class Initialized
DEBUG - 2023-04-29 14:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:58:37 --> Input Class Initialized
INFO - 2023-04-29 14:58:37 --> Language Class Initialized
ERROR - 2023-04-29 14:58:37 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 14:58:38 --> Config Class Initialized
INFO - 2023-04-29 14:58:38 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:58:38 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:58:38 --> Utf8 Class Initialized
INFO - 2023-04-29 14:58:38 --> URI Class Initialized
INFO - 2023-04-29 14:58:38 --> Router Class Initialized
INFO - 2023-04-29 14:58:38 --> Output Class Initialized
INFO - 2023-04-29 14:58:38 --> Security Class Initialized
DEBUG - 2023-04-29 14:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:58:38 --> Input Class Initialized
INFO - 2023-04-29 14:58:38 --> Language Class Initialized
INFO - 2023-04-29 14:58:38 --> Loader Class Initialized
INFO - 2023-04-29 14:58:38 --> Helper loaded: url_helper
INFO - 2023-04-29 14:58:38 --> Helper loaded: form_helper
INFO - 2023-04-29 14:58:38 --> Helper loaded: file_helper
INFO - 2023-04-29 14:58:38 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:58:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:58:38 --> Form Validation Class Initialized
INFO - 2023-04-29 14:58:38 --> Upload Class Initialized
INFO - 2023-04-29 14:58:38 --> Model "M_auth" initialized
INFO - 2023-04-29 14:58:38 --> Model "M_user" initialized
INFO - 2023-04-29 14:58:38 --> Model "M_produk" initialized
INFO - 2023-04-29 14:58:38 --> Controller Class Initialized
INFO - 2023-04-29 14:58:38 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:58:38 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:58:38 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:58:38 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:58:38 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:58:38 --> Model "M_bank" initialized
INFO - 2023-04-29 14:58:38 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_all_bank.php
INFO - 2023-04-29 14:58:38 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:58:38 --> Final output sent to browser
DEBUG - 2023-04-29 14:58:38 --> Total execution time: 0.1405
INFO - 2023-04-29 14:58:51 --> Config Class Initialized
INFO - 2023-04-29 14:58:51 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:58:51 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:58:51 --> Utf8 Class Initialized
INFO - 2023-04-29 14:58:51 --> URI Class Initialized
INFO - 2023-04-29 14:58:51 --> Router Class Initialized
INFO - 2023-04-29 14:58:51 --> Output Class Initialized
INFO - 2023-04-29 14:58:51 --> Security Class Initialized
DEBUG - 2023-04-29 14:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:58:51 --> Input Class Initialized
INFO - 2023-04-29 14:58:51 --> Language Class Initialized
INFO - 2023-04-29 14:58:51 --> Loader Class Initialized
INFO - 2023-04-29 14:58:51 --> Helper loaded: url_helper
INFO - 2023-04-29 14:58:51 --> Helper loaded: form_helper
INFO - 2023-04-29 14:58:51 --> Helper loaded: file_helper
INFO - 2023-04-29 14:58:51 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:58:51 --> Form Validation Class Initialized
INFO - 2023-04-29 14:58:51 --> Upload Class Initialized
INFO - 2023-04-29 14:58:51 --> Model "M_auth" initialized
INFO - 2023-04-29 14:58:51 --> Model "M_user" initialized
INFO - 2023-04-29 14:58:51 --> Model "M_produk" initialized
INFO - 2023-04-29 14:58:51 --> Controller Class Initialized
INFO - 2023-04-29 14:58:51 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:58:51 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:58:51 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:58:51 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:58:51 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:58:51 --> Model "M_bank" initialized
INFO - 2023-04-29 14:58:51 --> Model "M_pesan" initialized
ERROR - 2023-04-29 14:58:51 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 14:58:51 --> Config Class Initialized
INFO - 2023-04-29 14:58:51 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:58:51 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:58:51 --> Utf8 Class Initialized
INFO - 2023-04-29 14:58:51 --> URI Class Initialized
INFO - 2023-04-29 14:58:51 --> Router Class Initialized
INFO - 2023-04-29 14:58:51 --> Output Class Initialized
INFO - 2023-04-29 14:58:51 --> Security Class Initialized
DEBUG - 2023-04-29 14:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:58:51 --> Input Class Initialized
INFO - 2023-04-29 14:58:51 --> Language Class Initialized
ERROR - 2023-04-29 14:58:51 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 14:58:54 --> Config Class Initialized
INFO - 2023-04-29 14:58:54 --> Hooks Class Initialized
DEBUG - 2023-04-29 14:58:54 --> UTF-8 Support Enabled
INFO - 2023-04-29 14:58:54 --> Utf8 Class Initialized
INFO - 2023-04-29 14:58:54 --> URI Class Initialized
INFO - 2023-04-29 14:58:54 --> Router Class Initialized
INFO - 2023-04-29 14:58:54 --> Output Class Initialized
INFO - 2023-04-29 14:58:54 --> Security Class Initialized
DEBUG - 2023-04-29 14:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 14:58:54 --> Input Class Initialized
INFO - 2023-04-29 14:58:54 --> Language Class Initialized
INFO - 2023-04-29 14:58:54 --> Loader Class Initialized
INFO - 2023-04-29 14:58:54 --> Helper loaded: url_helper
INFO - 2023-04-29 14:58:54 --> Helper loaded: form_helper
INFO - 2023-04-29 14:58:54 --> Helper loaded: file_helper
INFO - 2023-04-29 14:58:54 --> Database Driver Class Initialized
DEBUG - 2023-04-29 14:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 14:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 14:58:54 --> Form Validation Class Initialized
INFO - 2023-04-29 14:58:54 --> Upload Class Initialized
INFO - 2023-04-29 14:58:54 --> Model "M_auth" initialized
INFO - 2023-04-29 14:58:54 --> Model "M_user" initialized
INFO - 2023-04-29 14:58:54 --> Model "M_produk" initialized
INFO - 2023-04-29 14:58:54 --> Controller Class Initialized
INFO - 2023-04-29 14:58:54 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 14:58:54 --> Model "M_produk" initialized
DEBUG - 2023-04-29 14:58:54 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 14:58:54 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 14:58:54 --> Model "M_transaksi" initialized
INFO - 2023-04-29 14:58:54 --> Model "M_bank" initialized
INFO - 2023-04-29 14:58:54 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_all_bank.php
INFO - 2023-04-29 14:58:54 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 14:58:54 --> Final output sent to browser
DEBUG - 2023-04-29 14:58:54 --> Total execution time: 0.1256
INFO - 2023-04-29 15:02:27 --> Config Class Initialized
INFO - 2023-04-29 15:02:27 --> Hooks Class Initialized
DEBUG - 2023-04-29 15:02:27 --> UTF-8 Support Enabled
INFO - 2023-04-29 15:02:27 --> Utf8 Class Initialized
INFO - 2023-04-29 15:02:27 --> URI Class Initialized
INFO - 2023-04-29 15:02:27 --> Router Class Initialized
INFO - 2023-04-29 15:02:27 --> Output Class Initialized
INFO - 2023-04-29 15:02:27 --> Security Class Initialized
DEBUG - 2023-04-29 15:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 15:02:27 --> Input Class Initialized
INFO - 2023-04-29 15:02:27 --> Language Class Initialized
INFO - 2023-04-29 15:02:27 --> Loader Class Initialized
INFO - 2023-04-29 15:02:27 --> Helper loaded: url_helper
INFO - 2023-04-29 15:02:27 --> Helper loaded: form_helper
INFO - 2023-04-29 15:02:27 --> Helper loaded: file_helper
INFO - 2023-04-29 15:02:27 --> Database Driver Class Initialized
DEBUG - 2023-04-29 15:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 15:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 15:02:27 --> Form Validation Class Initialized
INFO - 2023-04-29 15:02:27 --> Upload Class Initialized
INFO - 2023-04-29 15:02:27 --> Model "M_auth" initialized
INFO - 2023-04-29 15:02:27 --> Model "M_user" initialized
INFO - 2023-04-29 15:02:27 --> Model "M_produk" initialized
INFO - 2023-04-29 15:02:27 --> Controller Class Initialized
INFO - 2023-04-29 15:02:27 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 15:02:27 --> Model "M_produk" initialized
DEBUG - 2023-04-29 15:02:27 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 15:02:27 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 15:02:27 --> Model "M_transaksi" initialized
INFO - 2023-04-29 15:02:27 --> Model "M_bank" initialized
INFO - 2023-04-29 15:02:27 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_all_bank.php
INFO - 2023-04-29 15:02:27 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 15:02:27 --> Final output sent to browser
DEBUG - 2023-04-29 15:02:27 --> Total execution time: 0.1293
INFO - 2023-04-29 15:02:31 --> Config Class Initialized
INFO - 2023-04-29 15:02:31 --> Hooks Class Initialized
DEBUG - 2023-04-29 15:02:31 --> UTF-8 Support Enabled
INFO - 2023-04-29 15:02:31 --> Utf8 Class Initialized
INFO - 2023-04-29 15:02:31 --> URI Class Initialized
INFO - 2023-04-29 15:02:31 --> Router Class Initialized
INFO - 2023-04-29 15:02:31 --> Output Class Initialized
INFO - 2023-04-29 15:02:31 --> Security Class Initialized
DEBUG - 2023-04-29 15:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 15:02:31 --> Input Class Initialized
INFO - 2023-04-29 15:02:31 --> Language Class Initialized
INFO - 2023-04-29 15:02:31 --> Loader Class Initialized
INFO - 2023-04-29 15:02:31 --> Helper loaded: url_helper
INFO - 2023-04-29 15:02:31 --> Helper loaded: form_helper
INFO - 2023-04-29 15:02:31 --> Helper loaded: file_helper
INFO - 2023-04-29 15:02:31 --> Database Driver Class Initialized
DEBUG - 2023-04-29 15:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 15:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 15:02:31 --> Form Validation Class Initialized
INFO - 2023-04-29 15:02:31 --> Upload Class Initialized
INFO - 2023-04-29 15:02:31 --> Model "M_auth" initialized
INFO - 2023-04-29 15:02:31 --> Model "M_user" initialized
INFO - 2023-04-29 15:02:31 --> Model "M_produk" initialized
INFO - 2023-04-29 15:02:31 --> Controller Class Initialized
INFO - 2023-04-29 15:02:31 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 15:02:31 --> Model "M_produk" initialized
DEBUG - 2023-04-29 15:02:31 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 15:02:31 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 15:02:31 --> Model "M_transaksi" initialized
INFO - 2023-04-29 15:02:31 --> Model "M_bank" initialized
INFO - 2023-04-29 15:02:31 --> Model "M_pesan" initialized
ERROR - 2023-04-29 15:02:31 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 15:02:31 --> Config Class Initialized
INFO - 2023-04-29 15:02:31 --> Hooks Class Initialized
DEBUG - 2023-04-29 15:02:31 --> UTF-8 Support Enabled
INFO - 2023-04-29 15:02:31 --> Utf8 Class Initialized
INFO - 2023-04-29 15:02:31 --> URI Class Initialized
INFO - 2023-04-29 15:02:32 --> Router Class Initialized
INFO - 2023-04-29 15:02:32 --> Output Class Initialized
INFO - 2023-04-29 15:02:32 --> Security Class Initialized
DEBUG - 2023-04-29 15:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 15:02:32 --> Input Class Initialized
INFO - 2023-04-29 15:02:32 --> Language Class Initialized
ERROR - 2023-04-29 15:02:32 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 15:02:33 --> Config Class Initialized
INFO - 2023-04-29 15:02:33 --> Hooks Class Initialized
DEBUG - 2023-04-29 15:02:33 --> UTF-8 Support Enabled
INFO - 2023-04-29 15:02:33 --> Utf8 Class Initialized
INFO - 2023-04-29 15:02:33 --> URI Class Initialized
INFO - 2023-04-29 15:02:33 --> Router Class Initialized
INFO - 2023-04-29 15:02:33 --> Output Class Initialized
INFO - 2023-04-29 15:02:33 --> Security Class Initialized
DEBUG - 2023-04-29 15:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 15:02:33 --> Input Class Initialized
INFO - 2023-04-29 15:02:33 --> Language Class Initialized
INFO - 2023-04-29 15:02:33 --> Loader Class Initialized
INFO - 2023-04-29 15:02:33 --> Helper loaded: url_helper
INFO - 2023-04-29 15:02:33 --> Helper loaded: form_helper
INFO - 2023-04-29 15:02:33 --> Helper loaded: file_helper
INFO - 2023-04-29 15:02:33 --> Database Driver Class Initialized
DEBUG - 2023-04-29 15:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 15:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 15:02:33 --> Form Validation Class Initialized
INFO - 2023-04-29 15:02:33 --> Upload Class Initialized
INFO - 2023-04-29 15:02:33 --> Model "M_auth" initialized
INFO - 2023-04-29 15:02:33 --> Model "M_user" initialized
INFO - 2023-04-29 15:02:33 --> Model "M_produk" initialized
INFO - 2023-04-29 15:02:33 --> Controller Class Initialized
INFO - 2023-04-29 15:02:33 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 15:02:33 --> Model "M_produk" initialized
DEBUG - 2023-04-29 15:02:33 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 15:02:33 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 15:02:33 --> Model "M_transaksi" initialized
INFO - 2023-04-29 15:02:33 --> Model "M_bank" initialized
INFO - 2023-04-29 15:02:33 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_all_bank.php
INFO - 2023-04-29 15:02:33 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 15:02:33 --> Final output sent to browser
DEBUG - 2023-04-29 15:02:33 --> Total execution time: 0.1796
INFO - 2023-04-29 15:03:37 --> Config Class Initialized
INFO - 2023-04-29 15:03:37 --> Hooks Class Initialized
DEBUG - 2023-04-29 15:03:37 --> UTF-8 Support Enabled
INFO - 2023-04-29 15:03:37 --> Utf8 Class Initialized
INFO - 2023-04-29 15:03:37 --> URI Class Initialized
INFO - 2023-04-29 15:03:37 --> Router Class Initialized
INFO - 2023-04-29 15:03:37 --> Output Class Initialized
INFO - 2023-04-29 15:03:37 --> Security Class Initialized
DEBUG - 2023-04-29 15:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 15:03:37 --> Input Class Initialized
INFO - 2023-04-29 15:03:37 --> Language Class Initialized
INFO - 2023-04-29 15:03:38 --> Loader Class Initialized
INFO - 2023-04-29 15:03:38 --> Helper loaded: url_helper
INFO - 2023-04-29 15:03:38 --> Helper loaded: form_helper
INFO - 2023-04-29 15:03:38 --> Helper loaded: file_helper
INFO - 2023-04-29 15:03:38 --> Database Driver Class Initialized
DEBUG - 2023-04-29 15:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 15:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 15:03:38 --> Form Validation Class Initialized
INFO - 2023-04-29 15:03:38 --> Upload Class Initialized
INFO - 2023-04-29 15:03:38 --> Model "M_auth" initialized
INFO - 2023-04-29 15:03:38 --> Model "M_user" initialized
INFO - 2023-04-29 15:03:38 --> Model "M_produk" initialized
INFO - 2023-04-29 15:03:38 --> Controller Class Initialized
INFO - 2023-04-29 15:03:38 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 15:03:38 --> Model "M_produk" initialized
DEBUG - 2023-04-29 15:03:38 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 15:03:38 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 15:03:38 --> Model "M_transaksi" initialized
INFO - 2023-04-29 15:03:38 --> Model "M_bank" initialized
INFO - 2023-04-29 15:03:38 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_all_bank.php
INFO - 2023-04-29 15:03:38 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 15:03:38 --> Final output sent to browser
DEBUG - 2023-04-29 15:03:38 --> Total execution time: 0.1470
INFO - 2023-04-29 15:03:41 --> Config Class Initialized
INFO - 2023-04-29 15:03:41 --> Hooks Class Initialized
DEBUG - 2023-04-29 15:03:41 --> UTF-8 Support Enabled
INFO - 2023-04-29 15:03:41 --> Utf8 Class Initialized
INFO - 2023-04-29 15:03:41 --> URI Class Initialized
INFO - 2023-04-29 15:03:41 --> Router Class Initialized
INFO - 2023-04-29 15:03:41 --> Output Class Initialized
INFO - 2023-04-29 15:03:41 --> Security Class Initialized
DEBUG - 2023-04-29 15:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 15:03:41 --> Input Class Initialized
INFO - 2023-04-29 15:03:41 --> Language Class Initialized
INFO - 2023-04-29 15:03:41 --> Loader Class Initialized
INFO - 2023-04-29 15:03:41 --> Helper loaded: url_helper
INFO - 2023-04-29 15:03:41 --> Helper loaded: form_helper
INFO - 2023-04-29 15:03:41 --> Helper loaded: file_helper
INFO - 2023-04-29 15:03:41 --> Database Driver Class Initialized
DEBUG - 2023-04-29 15:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 15:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 15:03:41 --> Form Validation Class Initialized
INFO - 2023-04-29 15:03:41 --> Upload Class Initialized
INFO - 2023-04-29 15:03:41 --> Model "M_auth" initialized
INFO - 2023-04-29 15:03:41 --> Model "M_user" initialized
INFO - 2023-04-29 15:03:41 --> Model "M_produk" initialized
INFO - 2023-04-29 15:03:41 --> Controller Class Initialized
INFO - 2023-04-29 15:03:41 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 15:03:41 --> Model "M_produk" initialized
DEBUG - 2023-04-29 15:03:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 15:03:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 15:03:41 --> Model "M_transaksi" initialized
INFO - 2023-04-29 15:03:41 --> Model "M_bank" initialized
INFO - 2023-04-29 15:03:41 --> Model "M_pesan" initialized
ERROR - 2023-04-29 15:03:41 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 15:03:41 --> Config Class Initialized
INFO - 2023-04-29 15:03:41 --> Hooks Class Initialized
DEBUG - 2023-04-29 15:03:41 --> UTF-8 Support Enabled
INFO - 2023-04-29 15:03:41 --> Utf8 Class Initialized
INFO - 2023-04-29 15:03:41 --> URI Class Initialized
INFO - 2023-04-29 15:03:41 --> Router Class Initialized
INFO - 2023-04-29 15:03:41 --> Output Class Initialized
INFO - 2023-04-29 15:03:41 --> Security Class Initialized
DEBUG - 2023-04-29 15:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 15:03:41 --> Input Class Initialized
INFO - 2023-04-29 15:03:41 --> Language Class Initialized
ERROR - 2023-04-29 15:03:41 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 15:03:45 --> Config Class Initialized
INFO - 2023-04-29 15:03:45 --> Hooks Class Initialized
DEBUG - 2023-04-29 15:03:45 --> UTF-8 Support Enabled
INFO - 2023-04-29 15:03:45 --> Utf8 Class Initialized
INFO - 2023-04-29 15:03:45 --> URI Class Initialized
INFO - 2023-04-29 15:03:45 --> Router Class Initialized
INFO - 2023-04-29 15:03:45 --> Output Class Initialized
INFO - 2023-04-29 15:03:45 --> Security Class Initialized
DEBUG - 2023-04-29 15:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 15:03:45 --> Input Class Initialized
INFO - 2023-04-29 15:03:45 --> Language Class Initialized
INFO - 2023-04-29 15:03:45 --> Loader Class Initialized
INFO - 2023-04-29 15:03:45 --> Helper loaded: url_helper
INFO - 2023-04-29 15:03:45 --> Helper loaded: form_helper
INFO - 2023-04-29 15:03:45 --> Helper loaded: file_helper
INFO - 2023-04-29 15:03:45 --> Database Driver Class Initialized
DEBUG - 2023-04-29 15:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 15:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 15:03:45 --> Form Validation Class Initialized
INFO - 2023-04-29 15:03:45 --> Upload Class Initialized
INFO - 2023-04-29 15:03:45 --> Model "M_auth" initialized
INFO - 2023-04-29 15:03:45 --> Model "M_user" initialized
INFO - 2023-04-29 15:03:45 --> Model "M_produk" initialized
INFO - 2023-04-29 15:03:45 --> Controller Class Initialized
INFO - 2023-04-29 15:03:45 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 15:03:45 --> Model "M_produk" initialized
DEBUG - 2023-04-29 15:03:45 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 15:03:45 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 15:03:45 --> Model "M_transaksi" initialized
INFO - 2023-04-29 15:03:45 --> Model "M_bank" initialized
INFO - 2023-04-29 15:03:45 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_all_bank.php
INFO - 2023-04-29 15:03:45 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 15:03:45 --> Final output sent to browser
DEBUG - 2023-04-29 15:03:45 --> Total execution time: 0.1261
INFO - 2023-04-29 16:16:43 --> Config Class Initialized
INFO - 2023-04-29 16:16:43 --> Hooks Class Initialized
DEBUG - 2023-04-29 16:16:43 --> UTF-8 Support Enabled
INFO - 2023-04-29 16:16:43 --> Utf8 Class Initialized
INFO - 2023-04-29 16:16:43 --> URI Class Initialized
INFO - 2023-04-29 16:16:43 --> Router Class Initialized
INFO - 2023-04-29 16:16:43 --> Output Class Initialized
INFO - 2023-04-29 16:16:43 --> Security Class Initialized
DEBUG - 2023-04-29 16:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 16:16:43 --> Input Class Initialized
INFO - 2023-04-29 16:16:43 --> Language Class Initialized
INFO - 2023-04-29 16:16:43 --> Loader Class Initialized
INFO - 2023-04-29 16:16:43 --> Helper loaded: url_helper
INFO - 2023-04-29 16:16:43 --> Helper loaded: form_helper
INFO - 2023-04-29 16:16:43 --> Helper loaded: file_helper
INFO - 2023-04-29 16:16:43 --> Database Driver Class Initialized
DEBUG - 2023-04-29 16:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 16:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 16:16:43 --> Form Validation Class Initialized
INFO - 2023-04-29 16:16:43 --> Upload Class Initialized
INFO - 2023-04-29 16:16:43 --> Model "M_auth" initialized
INFO - 2023-04-29 16:16:43 --> Model "M_user" initialized
INFO - 2023-04-29 16:16:43 --> Model "M_produk" initialized
INFO - 2023-04-29 16:16:43 --> Controller Class Initialized
INFO - 2023-04-29 16:16:43 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 16:16:43 --> Model "M_produk" initialized
DEBUG - 2023-04-29 16:16:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 16:16:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 16:16:43 --> Model "M_transaksi" initialized
INFO - 2023-04-29 16:16:43 --> Model "M_bank" initialized
INFO - 2023-04-29 16:16:43 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_all_bank.php
INFO - 2023-04-29 16:16:43 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 16:16:43 --> Final output sent to browser
DEBUG - 2023-04-29 16:16:43 --> Total execution time: 0.1459
INFO - 2023-04-29 16:16:46 --> Config Class Initialized
INFO - 2023-04-29 16:16:46 --> Hooks Class Initialized
DEBUG - 2023-04-29 16:16:46 --> UTF-8 Support Enabled
INFO - 2023-04-29 16:16:46 --> Utf8 Class Initialized
INFO - 2023-04-29 16:16:46 --> URI Class Initialized
INFO - 2023-04-29 16:16:46 --> Router Class Initialized
INFO - 2023-04-29 16:16:46 --> Output Class Initialized
INFO - 2023-04-29 16:16:46 --> Security Class Initialized
DEBUG - 2023-04-29 16:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 16:16:46 --> Input Class Initialized
INFO - 2023-04-29 16:16:46 --> Language Class Initialized
INFO - 2023-04-29 16:16:46 --> Loader Class Initialized
INFO - 2023-04-29 16:16:46 --> Helper loaded: url_helper
INFO - 2023-04-29 16:16:46 --> Helper loaded: form_helper
INFO - 2023-04-29 16:16:46 --> Helper loaded: file_helper
INFO - 2023-04-29 16:16:46 --> Database Driver Class Initialized
DEBUG - 2023-04-29 16:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 16:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 16:16:46 --> Form Validation Class Initialized
INFO - 2023-04-29 16:16:46 --> Upload Class Initialized
INFO - 2023-04-29 16:16:46 --> Model "M_auth" initialized
INFO - 2023-04-29 16:16:46 --> Model "M_user" initialized
INFO - 2023-04-29 16:16:46 --> Model "M_produk" initialized
INFO - 2023-04-29 16:16:46 --> Controller Class Initialized
INFO - 2023-04-29 16:16:46 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 16:16:46 --> Model "M_produk" initialized
DEBUG - 2023-04-29 16:16:46 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 16:16:46 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 16:16:46 --> Model "M_transaksi" initialized
INFO - 2023-04-29 16:16:46 --> Model "M_bank" initialized
INFO - 2023-04-29 16:16:46 --> Model "M_pesan" initialized
ERROR - 2023-04-29 16:16:46 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 16:16:47 --> Config Class Initialized
INFO - 2023-04-29 16:16:47 --> Hooks Class Initialized
DEBUG - 2023-04-29 16:16:47 --> UTF-8 Support Enabled
INFO - 2023-04-29 16:16:47 --> Utf8 Class Initialized
INFO - 2023-04-29 16:16:47 --> URI Class Initialized
INFO - 2023-04-29 16:16:47 --> Router Class Initialized
INFO - 2023-04-29 16:16:47 --> Output Class Initialized
INFO - 2023-04-29 16:16:47 --> Security Class Initialized
DEBUG - 2023-04-29 16:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 16:16:47 --> Input Class Initialized
INFO - 2023-04-29 16:16:47 --> Language Class Initialized
ERROR - 2023-04-29 16:16:47 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 16:16:48 --> Config Class Initialized
INFO - 2023-04-29 16:16:48 --> Hooks Class Initialized
DEBUG - 2023-04-29 16:16:48 --> UTF-8 Support Enabled
INFO - 2023-04-29 16:16:48 --> Utf8 Class Initialized
INFO - 2023-04-29 16:16:48 --> URI Class Initialized
INFO - 2023-04-29 16:16:48 --> Router Class Initialized
INFO - 2023-04-29 16:16:48 --> Output Class Initialized
INFO - 2023-04-29 16:16:48 --> Security Class Initialized
DEBUG - 2023-04-29 16:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 16:16:48 --> Input Class Initialized
INFO - 2023-04-29 16:16:48 --> Language Class Initialized
INFO - 2023-04-29 16:16:48 --> Loader Class Initialized
INFO - 2023-04-29 16:16:48 --> Helper loaded: url_helper
INFO - 2023-04-29 16:16:48 --> Helper loaded: form_helper
INFO - 2023-04-29 16:16:48 --> Helper loaded: file_helper
INFO - 2023-04-29 16:16:48 --> Database Driver Class Initialized
DEBUG - 2023-04-29 16:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 16:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 16:16:48 --> Form Validation Class Initialized
INFO - 2023-04-29 16:16:48 --> Upload Class Initialized
INFO - 2023-04-29 16:16:48 --> Model "M_auth" initialized
INFO - 2023-04-29 16:16:48 --> Model "M_user" initialized
INFO - 2023-04-29 16:16:48 --> Model "M_produk" initialized
INFO - 2023-04-29 16:16:48 --> Controller Class Initialized
INFO - 2023-04-29 16:16:48 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 16:16:48 --> Model "M_produk" initialized
DEBUG - 2023-04-29 16:16:48 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 16:16:48 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 16:16:48 --> Model "M_transaksi" initialized
INFO - 2023-04-29 16:16:48 --> Model "M_bank" initialized
INFO - 2023-04-29 16:16:48 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_all_bank.php
INFO - 2023-04-29 16:16:48 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 16:16:48 --> Final output sent to browser
DEBUG - 2023-04-29 16:16:48 --> Total execution time: 0.1472
INFO - 2023-04-29 21:19:42 --> Config Class Initialized
INFO - 2023-04-29 21:19:42 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:19:43 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:19:43 --> Utf8 Class Initialized
INFO - 2023-04-29 21:19:43 --> URI Class Initialized
DEBUG - 2023-04-29 21:19:43 --> No URI present. Default controller set.
INFO - 2023-04-29 21:19:43 --> Router Class Initialized
INFO - 2023-04-29 21:19:43 --> Output Class Initialized
INFO - 2023-04-29 21:19:43 --> Security Class Initialized
DEBUG - 2023-04-29 21:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:19:43 --> Input Class Initialized
INFO - 2023-04-29 21:19:43 --> Language Class Initialized
INFO - 2023-04-29 21:19:43 --> Loader Class Initialized
INFO - 2023-04-29 21:19:43 --> Helper loaded: url_helper
INFO - 2023-04-29 21:19:43 --> Helper loaded: form_helper
INFO - 2023-04-29 21:19:43 --> Helper loaded: file_helper
INFO - 2023-04-29 21:19:43 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:19:43 --> Form Validation Class Initialized
INFO - 2023-04-29 21:19:43 --> Upload Class Initialized
INFO - 2023-04-29 21:19:43 --> Model "M_auth" initialized
INFO - 2023-04-29 21:19:43 --> Model "M_user" initialized
INFO - 2023-04-29 21:19:43 --> Model "M_produk" initialized
INFO - 2023-04-29 21:19:43 --> Controller Class Initialized
INFO - 2023-04-29 21:19:43 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 21:19:43 --> Model "M_produk" initialized
DEBUG - 2023-04-29 21:19:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 21:19:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 21:19:43 --> Model "M_transaksi" initialized
INFO - 2023-04-29 21:19:43 --> Model "M_bank" initialized
INFO - 2023-04-29 21:19:43 --> Model "M_pesan" initialized
INFO - 2023-04-29 21:19:43 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-29 21:19:43 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-04-29 21:19:43 --> Final output sent to browser
DEBUG - 2023-04-29 21:19:43 --> Total execution time: 0.1319
INFO - 2023-04-29 21:19:45 --> Config Class Initialized
INFO - 2023-04-29 21:19:45 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:19:45 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:19:45 --> Utf8 Class Initialized
INFO - 2023-04-29 21:19:45 --> URI Class Initialized
INFO - 2023-04-29 21:19:45 --> Router Class Initialized
INFO - 2023-04-29 21:19:45 --> Output Class Initialized
INFO - 2023-04-29 21:19:45 --> Security Class Initialized
DEBUG - 2023-04-29 21:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:19:45 --> Input Class Initialized
INFO - 2023-04-29 21:19:45 --> Language Class Initialized
INFO - 2023-04-29 21:19:45 --> Loader Class Initialized
INFO - 2023-04-29 21:19:45 --> Helper loaded: url_helper
INFO - 2023-04-29 21:19:45 --> Helper loaded: form_helper
INFO - 2023-04-29 21:19:45 --> Helper loaded: file_helper
INFO - 2023-04-29 21:19:45 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:19:45 --> Form Validation Class Initialized
INFO - 2023-04-29 21:19:45 --> Upload Class Initialized
INFO - 2023-04-29 21:19:45 --> Model "M_auth" initialized
INFO - 2023-04-29 21:19:45 --> Model "M_user" initialized
INFO - 2023-04-29 21:19:45 --> Model "M_produk" initialized
INFO - 2023-04-29 21:19:45 --> Controller Class Initialized
INFO - 2023-04-29 21:19:45 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-04-29 21:19:45 --> Final output sent to browser
DEBUG - 2023-04-29 21:19:45 --> Total execution time: 0.1411
INFO - 2023-04-29 21:19:53 --> Config Class Initialized
INFO - 2023-04-29 21:19:53 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:19:53 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:19:53 --> Utf8 Class Initialized
INFO - 2023-04-29 21:19:53 --> URI Class Initialized
INFO - 2023-04-29 21:19:53 --> Router Class Initialized
INFO - 2023-04-29 21:19:53 --> Output Class Initialized
INFO - 2023-04-29 21:19:53 --> Security Class Initialized
DEBUG - 2023-04-29 21:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:19:53 --> Input Class Initialized
INFO - 2023-04-29 21:19:53 --> Language Class Initialized
INFO - 2023-04-29 21:19:53 --> Loader Class Initialized
INFO - 2023-04-29 21:19:53 --> Helper loaded: url_helper
INFO - 2023-04-29 21:19:53 --> Helper loaded: form_helper
INFO - 2023-04-29 21:19:53 --> Helper loaded: file_helper
INFO - 2023-04-29 21:19:53 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:19:53 --> Form Validation Class Initialized
INFO - 2023-04-29 21:19:53 --> Upload Class Initialized
INFO - 2023-04-29 21:19:53 --> Model "M_auth" initialized
INFO - 2023-04-29 21:19:53 --> Model "M_user" initialized
INFO - 2023-04-29 21:19:53 --> Model "M_produk" initialized
INFO - 2023-04-29 21:19:53 --> Controller Class Initialized
INFO - 2023-04-29 21:19:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-04-29 21:19:53 --> Config Class Initialized
INFO - 2023-04-29 21:19:53 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:19:53 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:19:53 --> Utf8 Class Initialized
INFO - 2023-04-29 21:19:53 --> URI Class Initialized
INFO - 2023-04-29 21:19:53 --> Router Class Initialized
INFO - 2023-04-29 21:19:53 --> Output Class Initialized
INFO - 2023-04-29 21:19:53 --> Security Class Initialized
DEBUG - 2023-04-29 21:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:19:53 --> Input Class Initialized
INFO - 2023-04-29 21:19:53 --> Language Class Initialized
INFO - 2023-04-29 21:19:53 --> Loader Class Initialized
INFO - 2023-04-29 21:19:53 --> Helper loaded: url_helper
INFO - 2023-04-29 21:19:53 --> Helper loaded: form_helper
INFO - 2023-04-29 21:19:53 --> Helper loaded: file_helper
INFO - 2023-04-29 21:19:53 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:19:53 --> Form Validation Class Initialized
INFO - 2023-04-29 21:19:53 --> Upload Class Initialized
INFO - 2023-04-29 21:19:53 --> Model "M_auth" initialized
INFO - 2023-04-29 21:19:53 --> Model "M_user" initialized
INFO - 2023-04-29 21:19:53 --> Model "M_produk" initialized
INFO - 2023-04-29 21:19:53 --> Controller Class Initialized
INFO - 2023-04-29 21:19:53 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 21:19:53 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 21:19:53 --> Final output sent to browser
DEBUG - 2023-04-29 21:19:53 --> Total execution time: 0.1054
INFO - 2023-04-29 21:19:57 --> Config Class Initialized
INFO - 2023-04-29 21:19:57 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:19:57 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:19:57 --> Utf8 Class Initialized
INFO - 2023-04-29 21:19:57 --> URI Class Initialized
INFO - 2023-04-29 21:19:57 --> Router Class Initialized
INFO - 2023-04-29 21:19:57 --> Output Class Initialized
INFO - 2023-04-29 21:19:57 --> Security Class Initialized
DEBUG - 2023-04-29 21:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:19:57 --> Input Class Initialized
INFO - 2023-04-29 21:19:57 --> Language Class Initialized
INFO - 2023-04-29 21:19:57 --> Loader Class Initialized
INFO - 2023-04-29 21:19:57 --> Helper loaded: url_helper
INFO - 2023-04-29 21:19:57 --> Helper loaded: form_helper
INFO - 2023-04-29 21:19:57 --> Helper loaded: file_helper
INFO - 2023-04-29 21:19:57 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:19:57 --> Form Validation Class Initialized
INFO - 2023-04-29 21:19:57 --> Upload Class Initialized
INFO - 2023-04-29 21:19:57 --> Model "M_auth" initialized
INFO - 2023-04-29 21:19:57 --> Model "M_user" initialized
INFO - 2023-04-29 21:19:57 --> Model "M_produk" initialized
INFO - 2023-04-29 21:19:57 --> Controller Class Initialized
INFO - 2023-04-29 21:19:57 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 21:19:57 --> Model "M_produk" initialized
DEBUG - 2023-04-29 21:19:57 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 21:19:57 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 21:19:57 --> Model "M_transaksi" initialized
INFO - 2023-04-29 21:19:57 --> Model "M_bank" initialized
INFO - 2023-04-29 21:19:57 --> Model "M_pesan" initialized
ERROR - 2023-04-29 21:19:57 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 21:19:57 --> Config Class Initialized
INFO - 2023-04-29 21:19:57 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:19:57 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:19:57 --> Utf8 Class Initialized
INFO - 2023-04-29 21:19:57 --> URI Class Initialized
INFO - 2023-04-29 21:19:57 --> Router Class Initialized
INFO - 2023-04-29 21:19:57 --> Output Class Initialized
INFO - 2023-04-29 21:19:57 --> Security Class Initialized
DEBUG - 2023-04-29 21:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:19:57 --> Input Class Initialized
INFO - 2023-04-29 21:19:57 --> Language Class Initialized
ERROR - 2023-04-29 21:19:57 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 21:19:59 --> Config Class Initialized
INFO - 2023-04-29 21:19:59 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:19:59 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:19:59 --> Utf8 Class Initialized
INFO - 2023-04-29 21:19:59 --> URI Class Initialized
INFO - 2023-04-29 21:19:59 --> Router Class Initialized
INFO - 2023-04-29 21:19:59 --> Output Class Initialized
INFO - 2023-04-29 21:19:59 --> Security Class Initialized
DEBUG - 2023-04-29 21:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:19:59 --> Input Class Initialized
INFO - 2023-04-29 21:19:59 --> Language Class Initialized
INFO - 2023-04-29 21:19:59 --> Loader Class Initialized
INFO - 2023-04-29 21:19:59 --> Helper loaded: url_helper
INFO - 2023-04-29 21:19:59 --> Helper loaded: form_helper
INFO - 2023-04-29 21:19:59 --> Helper loaded: file_helper
INFO - 2023-04-29 21:19:59 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:19:59 --> Form Validation Class Initialized
INFO - 2023-04-29 21:19:59 --> Upload Class Initialized
INFO - 2023-04-29 21:19:59 --> Model "M_auth" initialized
INFO - 2023-04-29 21:19:59 --> Model "M_user" initialized
INFO - 2023-04-29 21:19:59 --> Model "M_produk" initialized
INFO - 2023-04-29 21:19:59 --> Controller Class Initialized
INFO - 2023-04-29 21:19:59 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 21:19:59 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 21:19:59 --> Final output sent to browser
DEBUG - 2023-04-29 21:19:59 --> Total execution time: 0.1172
INFO - 2023-04-29 21:20:17 --> Config Class Initialized
INFO - 2023-04-29 21:20:17 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:20:17 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:20:17 --> Utf8 Class Initialized
INFO - 2023-04-29 21:20:17 --> URI Class Initialized
INFO - 2023-04-29 21:20:17 --> Router Class Initialized
INFO - 2023-04-29 21:20:17 --> Output Class Initialized
INFO - 2023-04-29 21:20:17 --> Security Class Initialized
DEBUG - 2023-04-29 21:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:20:17 --> Input Class Initialized
INFO - 2023-04-29 21:20:17 --> Language Class Initialized
INFO - 2023-04-29 21:20:17 --> Loader Class Initialized
INFO - 2023-04-29 21:20:17 --> Helper loaded: url_helper
INFO - 2023-04-29 21:20:17 --> Helper loaded: form_helper
INFO - 2023-04-29 21:20:17 --> Helper loaded: file_helper
INFO - 2023-04-29 21:20:17 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:20:17 --> Form Validation Class Initialized
INFO - 2023-04-29 21:20:17 --> Upload Class Initialized
INFO - 2023-04-29 21:20:17 --> Model "M_auth" initialized
INFO - 2023-04-29 21:20:17 --> Model "M_user" initialized
INFO - 2023-04-29 21:20:17 --> Model "M_produk" initialized
INFO - 2023-04-29 21:20:17 --> Controller Class Initialized
INFO - 2023-04-29 21:20:17 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 21:20:17 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 21:20:17 --> Final output sent to browser
DEBUG - 2023-04-29 21:20:17 --> Total execution time: 0.1049
INFO - 2023-04-29 21:20:20 --> Config Class Initialized
INFO - 2023-04-29 21:20:20 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:20:20 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:20:20 --> Utf8 Class Initialized
INFO - 2023-04-29 21:20:20 --> URI Class Initialized
INFO - 2023-04-29 21:20:20 --> Router Class Initialized
INFO - 2023-04-29 21:20:20 --> Output Class Initialized
INFO - 2023-04-29 21:20:20 --> Security Class Initialized
DEBUG - 2023-04-29 21:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:20:20 --> Input Class Initialized
INFO - 2023-04-29 21:20:20 --> Language Class Initialized
INFO - 2023-04-29 21:20:20 --> Loader Class Initialized
INFO - 2023-04-29 21:20:20 --> Helper loaded: url_helper
INFO - 2023-04-29 21:20:20 --> Helper loaded: form_helper
INFO - 2023-04-29 21:20:20 --> Helper loaded: file_helper
INFO - 2023-04-29 21:20:20 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:20:20 --> Form Validation Class Initialized
INFO - 2023-04-29 21:20:20 --> Upload Class Initialized
INFO - 2023-04-29 21:20:20 --> Model "M_auth" initialized
INFO - 2023-04-29 21:20:20 --> Model "M_user" initialized
INFO - 2023-04-29 21:20:20 --> Model "M_produk" initialized
INFO - 2023-04-29 21:20:20 --> Controller Class Initialized
INFO - 2023-04-29 21:20:20 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 21:20:20 --> Model "M_produk" initialized
DEBUG - 2023-04-29 21:20:20 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 21:20:20 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 21:20:20 --> Model "M_transaksi" initialized
INFO - 2023-04-29 21:20:20 --> Model "M_bank" initialized
INFO - 2023-04-29 21:20:20 --> Model "M_pesan" initialized
ERROR - 2023-04-29 21:20:20 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 21:20:20 --> Config Class Initialized
INFO - 2023-04-29 21:20:20 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:20:20 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:20:20 --> Utf8 Class Initialized
INFO - 2023-04-29 21:20:20 --> URI Class Initialized
INFO - 2023-04-29 21:20:20 --> Router Class Initialized
INFO - 2023-04-29 21:20:20 --> Output Class Initialized
INFO - 2023-04-29 21:20:20 --> Security Class Initialized
DEBUG - 2023-04-29 21:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:20:20 --> Input Class Initialized
INFO - 2023-04-29 21:20:20 --> Language Class Initialized
ERROR - 2023-04-29 21:20:20 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 21:20:22 --> Config Class Initialized
INFO - 2023-04-29 21:20:22 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:20:22 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:20:22 --> Utf8 Class Initialized
INFO - 2023-04-29 21:20:22 --> URI Class Initialized
INFO - 2023-04-29 21:20:22 --> Router Class Initialized
INFO - 2023-04-29 21:20:22 --> Output Class Initialized
INFO - 2023-04-29 21:20:22 --> Security Class Initialized
DEBUG - 2023-04-29 21:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:20:22 --> Input Class Initialized
INFO - 2023-04-29 21:20:22 --> Language Class Initialized
INFO - 2023-04-29 21:20:22 --> Loader Class Initialized
INFO - 2023-04-29 21:20:22 --> Helper loaded: url_helper
INFO - 2023-04-29 21:20:22 --> Helper loaded: form_helper
INFO - 2023-04-29 21:20:22 --> Helper loaded: file_helper
INFO - 2023-04-29 21:20:22 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:20:22 --> Form Validation Class Initialized
INFO - 2023-04-29 21:20:22 --> Upload Class Initialized
INFO - 2023-04-29 21:20:22 --> Model "M_auth" initialized
INFO - 2023-04-29 21:20:22 --> Model "M_user" initialized
INFO - 2023-04-29 21:20:22 --> Model "M_produk" initialized
INFO - 2023-04-29 21:20:22 --> Controller Class Initialized
INFO - 2023-04-29 21:20:22 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 21:20:22 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 21:20:22 --> Final output sent to browser
DEBUG - 2023-04-29 21:20:22 --> Total execution time: 0.1133
INFO - 2023-04-29 21:22:04 --> Config Class Initialized
INFO - 2023-04-29 21:22:04 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:22:04 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:22:04 --> Utf8 Class Initialized
INFO - 2023-04-29 21:22:04 --> URI Class Initialized
DEBUG - 2023-04-29 21:22:04 --> No URI present. Default controller set.
INFO - 2023-04-29 21:22:04 --> Router Class Initialized
INFO - 2023-04-29 21:22:04 --> Output Class Initialized
INFO - 2023-04-29 21:22:04 --> Security Class Initialized
DEBUG - 2023-04-29 21:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:22:04 --> Input Class Initialized
INFO - 2023-04-29 21:22:04 --> Language Class Initialized
INFO - 2023-04-29 21:22:04 --> Loader Class Initialized
INFO - 2023-04-29 21:22:04 --> Helper loaded: url_helper
INFO - 2023-04-29 21:22:04 --> Helper loaded: form_helper
INFO - 2023-04-29 21:22:04 --> Helper loaded: file_helper
INFO - 2023-04-29 21:22:04 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:22:04 --> Form Validation Class Initialized
INFO - 2023-04-29 21:22:04 --> Upload Class Initialized
INFO - 2023-04-29 21:22:04 --> Model "M_auth" initialized
INFO - 2023-04-29 21:22:04 --> Model "M_user" initialized
INFO - 2023-04-29 21:22:04 --> Model "M_produk" initialized
INFO - 2023-04-29 21:22:04 --> Controller Class Initialized
INFO - 2023-04-29 21:22:04 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 21:22:04 --> Model "M_produk" initialized
DEBUG - 2023-04-29 21:22:04 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 21:22:04 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 21:22:04 --> Model "M_transaksi" initialized
INFO - 2023-04-29 21:22:04 --> Model "M_bank" initialized
INFO - 2023-04-29 21:22:04 --> Model "M_pesan" initialized
INFO - 2023-04-29 21:22:04 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-29 21:22:04 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-04-29 21:22:04 --> Final output sent to browser
DEBUG - 2023-04-29 21:22:04 --> Total execution time: 0.1195
INFO - 2023-04-29 21:22:09 --> Config Class Initialized
INFO - 2023-04-29 21:22:09 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:22:09 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:22:09 --> Utf8 Class Initialized
INFO - 2023-04-29 21:22:09 --> URI Class Initialized
INFO - 2023-04-29 21:22:09 --> Router Class Initialized
INFO - 2023-04-29 21:22:09 --> Output Class Initialized
INFO - 2023-04-29 21:22:09 --> Security Class Initialized
DEBUG - 2023-04-29 21:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:22:09 --> Input Class Initialized
INFO - 2023-04-29 21:22:09 --> Language Class Initialized
INFO - 2023-04-29 21:22:09 --> Loader Class Initialized
INFO - 2023-04-29 21:22:09 --> Helper loaded: url_helper
INFO - 2023-04-29 21:22:09 --> Helper loaded: form_helper
INFO - 2023-04-29 21:22:09 --> Helper loaded: file_helper
INFO - 2023-04-29 21:22:09 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:22:09 --> Form Validation Class Initialized
INFO - 2023-04-29 21:22:09 --> Upload Class Initialized
INFO - 2023-04-29 21:22:09 --> Model "M_auth" initialized
INFO - 2023-04-29 21:22:09 --> Model "M_user" initialized
INFO - 2023-04-29 21:22:09 --> Model "M_produk" initialized
INFO - 2023-04-29 21:22:09 --> Controller Class Initialized
INFO - 2023-04-29 21:22:09 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 21:22:09 --> Model "M_produk" initialized
DEBUG - 2023-04-29 21:22:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 21:22:09 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 21:22:09 --> Model "M_transaksi" initialized
INFO - 2023-04-29 21:22:09 --> Model "M_bank" initialized
INFO - 2023-04-29 21:22:09 --> Model "M_pesan" initialized
INFO - 2023-04-29 21:22:09 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-29 21:22:09 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/v_produk_detail.php
INFO - 2023-04-29 21:22:09 --> Final output sent to browser
DEBUG - 2023-04-29 21:22:09 --> Total execution time: 0.1399
INFO - 2023-04-29 21:22:11 --> Config Class Initialized
INFO - 2023-04-29 21:22:11 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:22:11 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:22:11 --> Utf8 Class Initialized
INFO - 2023-04-29 21:22:11 --> URI Class Initialized
DEBUG - 2023-04-29 21:22:11 --> No URI present. Default controller set.
INFO - 2023-04-29 21:22:11 --> Router Class Initialized
INFO - 2023-04-29 21:22:11 --> Output Class Initialized
INFO - 2023-04-29 21:22:11 --> Security Class Initialized
DEBUG - 2023-04-29 21:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:22:11 --> Input Class Initialized
INFO - 2023-04-29 21:22:11 --> Language Class Initialized
INFO - 2023-04-29 21:22:11 --> Loader Class Initialized
INFO - 2023-04-29 21:22:11 --> Helper loaded: url_helper
INFO - 2023-04-29 21:22:11 --> Helper loaded: form_helper
INFO - 2023-04-29 21:22:11 --> Helper loaded: file_helper
INFO - 2023-04-29 21:22:11 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:22:11 --> Form Validation Class Initialized
INFO - 2023-04-29 21:22:11 --> Upload Class Initialized
INFO - 2023-04-29 21:22:11 --> Model "M_auth" initialized
INFO - 2023-04-29 21:22:11 --> Model "M_user" initialized
INFO - 2023-04-29 21:22:11 --> Model "M_produk" initialized
INFO - 2023-04-29 21:22:11 --> Controller Class Initialized
INFO - 2023-04-29 21:22:11 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 21:22:11 --> Model "M_produk" initialized
DEBUG - 2023-04-29 21:22:11 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 21:22:11 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 21:22:11 --> Model "M_transaksi" initialized
INFO - 2023-04-29 21:22:11 --> Model "M_bank" initialized
INFO - 2023-04-29 21:22:11 --> Model "M_pesan" initialized
INFO - 2023-04-29 21:22:11 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-29 21:22:11 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-04-29 21:22:11 --> Final output sent to browser
DEBUG - 2023-04-29 21:22:11 --> Total execution time: 0.1332
INFO - 2023-04-29 21:22:13 --> Config Class Initialized
INFO - 2023-04-29 21:22:13 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:22:13 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:22:13 --> Utf8 Class Initialized
INFO - 2023-04-29 21:22:13 --> URI Class Initialized
INFO - 2023-04-29 21:22:13 --> Router Class Initialized
INFO - 2023-04-29 21:22:13 --> Output Class Initialized
INFO - 2023-04-29 21:22:13 --> Security Class Initialized
DEBUG - 2023-04-29 21:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:22:13 --> Input Class Initialized
INFO - 2023-04-29 21:22:13 --> Language Class Initialized
INFO - 2023-04-29 21:22:13 --> Loader Class Initialized
INFO - 2023-04-29 21:22:13 --> Helper loaded: url_helper
INFO - 2023-04-29 21:22:13 --> Helper loaded: form_helper
INFO - 2023-04-29 21:22:13 --> Helper loaded: file_helper
INFO - 2023-04-29 21:22:13 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:22:13 --> Form Validation Class Initialized
INFO - 2023-04-29 21:22:13 --> Upload Class Initialized
INFO - 2023-04-29 21:22:13 --> Model "M_auth" initialized
INFO - 2023-04-29 21:22:13 --> Model "M_user" initialized
INFO - 2023-04-29 21:22:13 --> Model "M_produk" initialized
INFO - 2023-04-29 21:22:13 --> Controller Class Initialized
INFO - 2023-04-29 21:22:13 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-04-29 21:22:13 --> Final output sent to browser
DEBUG - 2023-04-29 21:22:13 --> Total execution time: 0.1223
INFO - 2023-04-29 21:22:20 --> Config Class Initialized
INFO - 2023-04-29 21:22:20 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:22:20 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:22:20 --> Utf8 Class Initialized
INFO - 2023-04-29 21:22:20 --> URI Class Initialized
INFO - 2023-04-29 21:22:20 --> Router Class Initialized
INFO - 2023-04-29 21:22:20 --> Output Class Initialized
INFO - 2023-04-29 21:22:20 --> Security Class Initialized
DEBUG - 2023-04-29 21:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:22:20 --> Input Class Initialized
INFO - 2023-04-29 21:22:20 --> Language Class Initialized
INFO - 2023-04-29 21:22:20 --> Loader Class Initialized
INFO - 2023-04-29 21:22:20 --> Helper loaded: url_helper
INFO - 2023-04-29 21:22:20 --> Helper loaded: form_helper
INFO - 2023-04-29 21:22:20 --> Helper loaded: file_helper
INFO - 2023-04-29 21:22:20 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:22:20 --> Form Validation Class Initialized
INFO - 2023-04-29 21:22:20 --> Upload Class Initialized
INFO - 2023-04-29 21:22:20 --> Model "M_auth" initialized
INFO - 2023-04-29 21:22:20 --> Model "M_user" initialized
INFO - 2023-04-29 21:22:20 --> Model "M_produk" initialized
INFO - 2023-04-29 21:22:20 --> Controller Class Initialized
INFO - 2023-04-29 21:22:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-04-29 21:22:20 --> Config Class Initialized
INFO - 2023-04-29 21:22:20 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:22:20 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:22:20 --> Utf8 Class Initialized
INFO - 2023-04-29 21:22:20 --> URI Class Initialized
INFO - 2023-04-29 21:22:20 --> Router Class Initialized
INFO - 2023-04-29 21:22:20 --> Output Class Initialized
INFO - 2023-04-29 21:22:20 --> Security Class Initialized
DEBUG - 2023-04-29 21:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:22:20 --> Input Class Initialized
INFO - 2023-04-29 21:22:20 --> Language Class Initialized
INFO - 2023-04-29 21:22:20 --> Loader Class Initialized
INFO - 2023-04-29 21:22:20 --> Helper loaded: url_helper
INFO - 2023-04-29 21:22:20 --> Helper loaded: form_helper
INFO - 2023-04-29 21:22:20 --> Helper loaded: file_helper
INFO - 2023-04-29 21:22:20 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:22:20 --> Form Validation Class Initialized
INFO - 2023-04-29 21:22:20 --> Upload Class Initialized
INFO - 2023-04-29 21:22:20 --> Model "M_auth" initialized
INFO - 2023-04-29 21:22:20 --> Model "M_user" initialized
INFO - 2023-04-29 21:22:20 --> Model "M_produk" initialized
INFO - 2023-04-29 21:22:20 --> Controller Class Initialized
INFO - 2023-04-29 21:22:20 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 21:22:20 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 21:22:20 --> Final output sent to browser
DEBUG - 2023-04-29 21:22:20 --> Total execution time: 0.1076
INFO - 2023-04-29 21:22:22 --> Config Class Initialized
INFO - 2023-04-29 21:22:22 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:22:22 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:22:22 --> Utf8 Class Initialized
INFO - 2023-04-29 21:22:22 --> URI Class Initialized
INFO - 2023-04-29 21:22:22 --> Router Class Initialized
INFO - 2023-04-29 21:22:22 --> Output Class Initialized
INFO - 2023-04-29 21:22:22 --> Security Class Initialized
DEBUG - 2023-04-29 21:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:22:22 --> Input Class Initialized
INFO - 2023-04-29 21:22:22 --> Language Class Initialized
INFO - 2023-04-29 21:22:22 --> Loader Class Initialized
INFO - 2023-04-29 21:22:22 --> Helper loaded: url_helper
INFO - 2023-04-29 21:22:22 --> Helper loaded: form_helper
INFO - 2023-04-29 21:22:22 --> Helper loaded: file_helper
INFO - 2023-04-29 21:22:22 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:22:22 --> Form Validation Class Initialized
INFO - 2023-04-29 21:22:22 --> Upload Class Initialized
INFO - 2023-04-29 21:22:22 --> Model "M_auth" initialized
INFO - 2023-04-29 21:22:22 --> Model "M_user" initialized
INFO - 2023-04-29 21:22:22 --> Model "M_produk" initialized
INFO - 2023-04-29 21:22:22 --> Controller Class Initialized
INFO - 2023-04-29 21:22:22 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 21:22:22 --> Model "M_produk" initialized
DEBUG - 2023-04-29 21:22:22 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 21:22:22 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 21:22:22 --> Model "M_transaksi" initialized
INFO - 2023-04-29 21:22:22 --> Model "M_bank" initialized
INFO - 2023-04-29 21:22:22 --> Model "M_pesan" initialized
ERROR - 2023-04-29 21:22:22 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 21:22:22 --> Config Class Initialized
INFO - 2023-04-29 21:22:22 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:22:22 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:22:22 --> Utf8 Class Initialized
INFO - 2023-04-29 21:22:22 --> URI Class Initialized
INFO - 2023-04-29 21:22:22 --> Router Class Initialized
INFO - 2023-04-29 21:22:22 --> Output Class Initialized
INFO - 2023-04-29 21:22:22 --> Security Class Initialized
DEBUG - 2023-04-29 21:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:22:22 --> Input Class Initialized
INFO - 2023-04-29 21:22:22 --> Language Class Initialized
ERROR - 2023-04-29 21:22:22 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 21:22:51 --> Config Class Initialized
INFO - 2023-04-29 21:22:51 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:22:51 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:22:51 --> Utf8 Class Initialized
INFO - 2023-04-29 21:22:51 --> URI Class Initialized
INFO - 2023-04-29 21:22:51 --> Router Class Initialized
INFO - 2023-04-29 21:22:51 --> Output Class Initialized
INFO - 2023-04-29 21:22:51 --> Security Class Initialized
DEBUG - 2023-04-29 21:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:22:51 --> Input Class Initialized
INFO - 2023-04-29 21:22:51 --> Language Class Initialized
INFO - 2023-04-29 21:22:51 --> Loader Class Initialized
INFO - 2023-04-29 21:22:51 --> Helper loaded: url_helper
INFO - 2023-04-29 21:22:51 --> Helper loaded: form_helper
INFO - 2023-04-29 21:22:51 --> Helper loaded: file_helper
INFO - 2023-04-29 21:22:51 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:22:51 --> Form Validation Class Initialized
INFO - 2023-04-29 21:22:51 --> Upload Class Initialized
INFO - 2023-04-29 21:22:51 --> Model "M_auth" initialized
INFO - 2023-04-29 21:22:51 --> Model "M_user" initialized
INFO - 2023-04-29 21:22:51 --> Model "M_produk" initialized
INFO - 2023-04-29 21:22:51 --> Controller Class Initialized
INFO - 2023-04-29 21:22:51 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 21:22:51 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 21:22:51 --> Final output sent to browser
DEBUG - 2023-04-29 21:22:51 --> Total execution time: 0.1254
INFO - 2023-04-29 21:23:03 --> Config Class Initialized
INFO - 2023-04-29 21:23:03 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:23:03 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:23:03 --> Utf8 Class Initialized
INFO - 2023-04-29 21:23:03 --> URI Class Initialized
INFO - 2023-04-29 21:23:03 --> Router Class Initialized
INFO - 2023-04-29 21:23:03 --> Output Class Initialized
INFO - 2023-04-29 21:23:03 --> Security Class Initialized
DEBUG - 2023-04-29 21:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:23:03 --> Input Class Initialized
INFO - 2023-04-29 21:23:03 --> Language Class Initialized
INFO - 2023-04-29 21:23:03 --> Loader Class Initialized
INFO - 2023-04-29 21:23:03 --> Helper loaded: url_helper
INFO - 2023-04-29 21:23:03 --> Helper loaded: form_helper
INFO - 2023-04-29 21:23:03 --> Helper loaded: file_helper
INFO - 2023-04-29 21:23:03 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:23:03 --> Form Validation Class Initialized
INFO - 2023-04-29 21:23:03 --> Upload Class Initialized
INFO - 2023-04-29 21:23:03 --> Model "M_auth" initialized
INFO - 2023-04-29 21:23:03 --> Model "M_user" initialized
INFO - 2023-04-29 21:23:03 --> Model "M_produk" initialized
INFO - 2023-04-29 21:23:03 --> Controller Class Initialized
INFO - 2023-04-29 21:23:03 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_user_profile.php
INFO - 2023-04-29 21:23:03 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 21:23:03 --> Final output sent to browser
DEBUG - 2023-04-29 21:23:03 --> Total execution time: 0.1223
INFO - 2023-04-29 21:24:16 --> Config Class Initialized
INFO - 2023-04-29 21:24:16 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:24:16 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:24:16 --> Utf8 Class Initialized
INFO - 2023-04-29 21:24:16 --> URI Class Initialized
INFO - 2023-04-29 21:24:16 --> Router Class Initialized
INFO - 2023-04-29 21:24:16 --> Output Class Initialized
INFO - 2023-04-29 21:24:16 --> Security Class Initialized
DEBUG - 2023-04-29 21:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:24:16 --> Input Class Initialized
INFO - 2023-04-29 21:24:16 --> Language Class Initialized
INFO - 2023-04-29 21:24:16 --> Loader Class Initialized
INFO - 2023-04-29 21:24:16 --> Helper loaded: url_helper
INFO - 2023-04-29 21:24:16 --> Helper loaded: form_helper
INFO - 2023-04-29 21:24:16 --> Helper loaded: file_helper
INFO - 2023-04-29 21:24:16 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:24:16 --> Form Validation Class Initialized
INFO - 2023-04-29 21:24:16 --> Upload Class Initialized
INFO - 2023-04-29 21:24:16 --> Model "M_auth" initialized
INFO - 2023-04-29 21:24:16 --> Model "M_user" initialized
INFO - 2023-04-29 21:24:16 --> Model "M_produk" initialized
INFO - 2023-04-29 21:24:16 --> Controller Class Initialized
INFO - 2023-04-29 21:24:16 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_user_profile.php
INFO - 2023-04-29 21:24:16 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 21:24:16 --> Final output sent to browser
DEBUG - 2023-04-29 21:24:16 --> Total execution time: 0.1259
INFO - 2023-04-29 21:24:18 --> Config Class Initialized
INFO - 2023-04-29 21:24:18 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:24:18 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:24:18 --> Utf8 Class Initialized
INFO - 2023-04-29 21:24:18 --> URI Class Initialized
INFO - 2023-04-29 21:24:18 --> Router Class Initialized
INFO - 2023-04-29 21:24:18 --> Output Class Initialized
INFO - 2023-04-29 21:24:18 --> Security Class Initialized
DEBUG - 2023-04-29 21:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:24:18 --> Input Class Initialized
INFO - 2023-04-29 21:24:18 --> Language Class Initialized
INFO - 2023-04-29 21:24:18 --> Loader Class Initialized
INFO - 2023-04-29 21:24:18 --> Helper loaded: url_helper
INFO - 2023-04-29 21:24:18 --> Helper loaded: form_helper
INFO - 2023-04-29 21:24:18 --> Helper loaded: file_helper
INFO - 2023-04-29 21:24:18 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:24:18 --> Form Validation Class Initialized
INFO - 2023-04-29 21:24:18 --> Upload Class Initialized
INFO - 2023-04-29 21:24:18 --> Model "M_auth" initialized
INFO - 2023-04-29 21:24:18 --> Model "M_user" initialized
INFO - 2023-04-29 21:24:18 --> Model "M_produk" initialized
INFO - 2023-04-29 21:24:18 --> Controller Class Initialized
INFO - 2023-04-29 21:24:18 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 21:24:18 --> Model "M_produk" initialized
DEBUG - 2023-04-29 21:24:18 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 21:24:18 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 21:24:18 --> Model "M_transaksi" initialized
INFO - 2023-04-29 21:24:18 --> Model "M_bank" initialized
INFO - 2023-04-29 21:24:18 --> Model "M_pesan" initialized
ERROR - 2023-04-29 21:24:18 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 21:24:18 --> Config Class Initialized
INFO - 2023-04-29 21:24:18 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:24:18 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:24:18 --> Utf8 Class Initialized
INFO - 2023-04-29 21:24:18 --> URI Class Initialized
INFO - 2023-04-29 21:24:18 --> Router Class Initialized
INFO - 2023-04-29 21:24:18 --> Output Class Initialized
INFO - 2023-04-29 21:24:18 --> Security Class Initialized
DEBUG - 2023-04-29 21:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:24:18 --> Input Class Initialized
INFO - 2023-04-29 21:24:18 --> Language Class Initialized
ERROR - 2023-04-29 21:24:18 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 21:24:19 --> Config Class Initialized
INFO - 2023-04-29 21:24:19 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:24:19 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:24:19 --> Utf8 Class Initialized
INFO - 2023-04-29 21:24:19 --> URI Class Initialized
INFO - 2023-04-29 21:24:19 --> Router Class Initialized
INFO - 2023-04-29 21:24:19 --> Output Class Initialized
INFO - 2023-04-29 21:24:19 --> Security Class Initialized
DEBUG - 2023-04-29 21:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:24:19 --> Input Class Initialized
INFO - 2023-04-29 21:24:19 --> Language Class Initialized
INFO - 2023-04-29 21:24:19 --> Loader Class Initialized
INFO - 2023-04-29 21:24:19 --> Helper loaded: url_helper
INFO - 2023-04-29 21:24:19 --> Helper loaded: form_helper
INFO - 2023-04-29 21:24:19 --> Helper loaded: file_helper
INFO - 2023-04-29 21:24:19 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:24:19 --> Form Validation Class Initialized
INFO - 2023-04-29 21:24:19 --> Upload Class Initialized
INFO - 2023-04-29 21:24:19 --> Model "M_auth" initialized
INFO - 2023-04-29 21:24:19 --> Model "M_user" initialized
INFO - 2023-04-29 21:24:19 --> Model "M_produk" initialized
INFO - 2023-04-29 21:24:19 --> Controller Class Initialized
INFO - 2023-04-29 21:24:19 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_user_profile.php
INFO - 2023-04-29 21:24:19 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 21:24:19 --> Final output sent to browser
DEBUG - 2023-04-29 21:24:19 --> Total execution time: 0.1310
INFO - 2023-04-29 21:24:21 --> Config Class Initialized
INFO - 2023-04-29 21:24:21 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:24:21 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:24:21 --> Utf8 Class Initialized
INFO - 2023-04-29 21:24:21 --> URI Class Initialized
INFO - 2023-04-29 21:24:21 --> Router Class Initialized
INFO - 2023-04-29 21:24:21 --> Output Class Initialized
INFO - 2023-04-29 21:24:21 --> Security Class Initialized
DEBUG - 2023-04-29 21:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:24:21 --> Input Class Initialized
INFO - 2023-04-29 21:24:21 --> Language Class Initialized
INFO - 2023-04-29 21:24:21 --> Loader Class Initialized
INFO - 2023-04-29 21:24:21 --> Helper loaded: url_helper
INFO - 2023-04-29 21:24:21 --> Helper loaded: form_helper
INFO - 2023-04-29 21:24:21 --> Helper loaded: file_helper
INFO - 2023-04-29 21:24:21 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:24:21 --> Form Validation Class Initialized
INFO - 2023-04-29 21:24:21 --> Upload Class Initialized
INFO - 2023-04-29 21:24:21 --> Model "M_auth" initialized
INFO - 2023-04-29 21:24:21 --> Model "M_user" initialized
INFO - 2023-04-29 21:24:21 --> Model "M_produk" initialized
INFO - 2023-04-29 21:24:21 --> Controller Class Initialized
INFO - 2023-04-29 21:24:21 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 21:24:21 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 21:24:21 --> Final output sent to browser
DEBUG - 2023-04-29 21:24:21 --> Total execution time: 0.1269
INFO - 2023-04-29 21:24:23 --> Config Class Initialized
INFO - 2023-04-29 21:24:23 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:24:23 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:24:23 --> Utf8 Class Initialized
INFO - 2023-04-29 21:24:23 --> URI Class Initialized
INFO - 2023-04-29 21:24:23 --> Router Class Initialized
INFO - 2023-04-29 21:24:23 --> Output Class Initialized
INFO - 2023-04-29 21:24:23 --> Security Class Initialized
DEBUG - 2023-04-29 21:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:24:23 --> Input Class Initialized
INFO - 2023-04-29 21:24:23 --> Language Class Initialized
INFO - 2023-04-29 21:24:23 --> Loader Class Initialized
INFO - 2023-04-29 21:24:23 --> Helper loaded: url_helper
INFO - 2023-04-29 21:24:23 --> Helper loaded: form_helper
INFO - 2023-04-29 21:24:23 --> Helper loaded: file_helper
INFO - 2023-04-29 21:24:23 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:24:23 --> Form Validation Class Initialized
INFO - 2023-04-29 21:24:23 --> Upload Class Initialized
INFO - 2023-04-29 21:24:23 --> Model "M_auth" initialized
INFO - 2023-04-29 21:24:23 --> Model "M_user" initialized
INFO - 2023-04-29 21:24:23 --> Model "M_produk" initialized
INFO - 2023-04-29 21:24:23 --> Controller Class Initialized
INFO - 2023-04-29 21:24:23 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 21:24:23 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 21:24:23 --> Final output sent to browser
DEBUG - 2023-04-29 21:24:23 --> Total execution time: 0.1097
INFO - 2023-04-29 21:24:55 --> Config Class Initialized
INFO - 2023-04-29 21:24:55 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:24:55 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:24:55 --> Utf8 Class Initialized
INFO - 2023-04-29 21:24:55 --> URI Class Initialized
DEBUG - 2023-04-29 21:24:55 --> No URI present. Default controller set.
INFO - 2023-04-29 21:24:55 --> Router Class Initialized
INFO - 2023-04-29 21:24:55 --> Output Class Initialized
INFO - 2023-04-29 21:24:55 --> Security Class Initialized
DEBUG - 2023-04-29 21:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:24:55 --> Input Class Initialized
INFO - 2023-04-29 21:24:55 --> Language Class Initialized
INFO - 2023-04-29 21:24:55 --> Loader Class Initialized
INFO - 2023-04-29 21:24:55 --> Helper loaded: url_helper
INFO - 2023-04-29 21:24:55 --> Helper loaded: form_helper
INFO - 2023-04-29 21:24:55 --> Helper loaded: file_helper
INFO - 2023-04-29 21:24:55 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:24:55 --> Form Validation Class Initialized
INFO - 2023-04-29 21:24:55 --> Upload Class Initialized
INFO - 2023-04-29 21:24:55 --> Model "M_auth" initialized
INFO - 2023-04-29 21:24:55 --> Model "M_user" initialized
INFO - 2023-04-29 21:24:55 --> Model "M_produk" initialized
INFO - 2023-04-29 21:24:55 --> Controller Class Initialized
INFO - 2023-04-29 21:24:55 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 21:24:55 --> Model "M_produk" initialized
DEBUG - 2023-04-29 21:24:55 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 21:24:55 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 21:24:55 --> Model "M_transaksi" initialized
INFO - 2023-04-29 21:24:55 --> Model "M_bank" initialized
INFO - 2023-04-29 21:24:55 --> Model "M_pesan" initialized
INFO - 2023-04-29 21:24:55 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-29 21:24:55 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-04-29 21:24:55 --> Final output sent to browser
DEBUG - 2023-04-29 21:24:55 --> Total execution time: 0.1310
INFO - 2023-04-29 21:24:57 --> Config Class Initialized
INFO - 2023-04-29 21:24:57 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:24:57 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:24:57 --> Utf8 Class Initialized
INFO - 2023-04-29 21:24:58 --> URI Class Initialized
INFO - 2023-04-29 21:24:58 --> Router Class Initialized
INFO - 2023-04-29 21:24:58 --> Output Class Initialized
INFO - 2023-04-29 21:24:58 --> Security Class Initialized
DEBUG - 2023-04-29 21:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:24:58 --> Input Class Initialized
INFO - 2023-04-29 21:24:58 --> Language Class Initialized
INFO - 2023-04-29 21:24:58 --> Loader Class Initialized
INFO - 2023-04-29 21:24:58 --> Helper loaded: url_helper
INFO - 2023-04-29 21:24:58 --> Helper loaded: form_helper
INFO - 2023-04-29 21:24:58 --> Helper loaded: file_helper
INFO - 2023-04-29 21:24:58 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:24:58 --> Form Validation Class Initialized
INFO - 2023-04-29 21:24:58 --> Upload Class Initialized
INFO - 2023-04-29 21:24:58 --> Model "M_auth" initialized
INFO - 2023-04-29 21:24:58 --> Model "M_user" initialized
INFO - 2023-04-29 21:24:58 --> Model "M_produk" initialized
INFO - 2023-04-29 21:24:58 --> Controller Class Initialized
INFO - 2023-04-29 21:24:58 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-04-29 21:24:58 --> Final output sent to browser
DEBUG - 2023-04-29 21:24:58 --> Total execution time: 0.1315
INFO - 2023-04-29 21:25:06 --> Config Class Initialized
INFO - 2023-04-29 21:25:06 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:25:06 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:25:06 --> Utf8 Class Initialized
INFO - 2023-04-29 21:25:06 --> URI Class Initialized
INFO - 2023-04-29 21:25:06 --> Router Class Initialized
INFO - 2023-04-29 21:25:06 --> Output Class Initialized
INFO - 2023-04-29 21:25:06 --> Security Class Initialized
DEBUG - 2023-04-29 21:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:25:06 --> Input Class Initialized
INFO - 2023-04-29 21:25:06 --> Language Class Initialized
INFO - 2023-04-29 21:25:06 --> Loader Class Initialized
INFO - 2023-04-29 21:25:06 --> Helper loaded: url_helper
INFO - 2023-04-29 21:25:06 --> Helper loaded: form_helper
INFO - 2023-04-29 21:25:06 --> Helper loaded: file_helper
INFO - 2023-04-29 21:25:06 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:25:06 --> Form Validation Class Initialized
INFO - 2023-04-29 21:25:06 --> Upload Class Initialized
INFO - 2023-04-29 21:25:06 --> Model "M_auth" initialized
INFO - 2023-04-29 21:25:06 --> Model "M_user" initialized
INFO - 2023-04-29 21:25:06 --> Model "M_produk" initialized
INFO - 2023-04-29 21:25:06 --> Controller Class Initialized
INFO - 2023-04-29 21:25:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-04-29 21:25:06 --> Config Class Initialized
INFO - 2023-04-29 21:25:06 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:25:06 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:25:06 --> Utf8 Class Initialized
INFO - 2023-04-29 21:25:06 --> URI Class Initialized
INFO - 2023-04-29 21:25:06 --> Router Class Initialized
INFO - 2023-04-29 21:25:06 --> Output Class Initialized
INFO - 2023-04-29 21:25:06 --> Security Class Initialized
DEBUG - 2023-04-29 21:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:25:06 --> Input Class Initialized
INFO - 2023-04-29 21:25:06 --> Language Class Initialized
INFO - 2023-04-29 21:25:06 --> Loader Class Initialized
INFO - 2023-04-29 21:25:06 --> Helper loaded: url_helper
INFO - 2023-04-29 21:25:06 --> Helper loaded: form_helper
INFO - 2023-04-29 21:25:06 --> Helper loaded: file_helper
INFO - 2023-04-29 21:25:06 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:25:06 --> Form Validation Class Initialized
INFO - 2023-04-29 21:25:06 --> Upload Class Initialized
INFO - 2023-04-29 21:25:06 --> Model "M_auth" initialized
INFO - 2023-04-29 21:25:06 --> Model "M_user" initialized
INFO - 2023-04-29 21:25:06 --> Model "M_produk" initialized
INFO - 2023-04-29 21:25:06 --> Controller Class Initialized
INFO - 2023-04-29 21:25:06 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 21:25:06 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 21:25:06 --> Final output sent to browser
DEBUG - 2023-04-29 21:25:06 --> Total execution time: 0.0996
INFO - 2023-04-29 21:25:08 --> Config Class Initialized
INFO - 2023-04-29 21:25:08 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:25:08 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:25:08 --> Utf8 Class Initialized
INFO - 2023-04-29 21:25:08 --> URI Class Initialized
INFO - 2023-04-29 21:25:08 --> Router Class Initialized
INFO - 2023-04-29 21:25:08 --> Output Class Initialized
INFO - 2023-04-29 21:25:08 --> Security Class Initialized
DEBUG - 2023-04-29 21:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:25:08 --> Input Class Initialized
INFO - 2023-04-29 21:25:08 --> Language Class Initialized
INFO - 2023-04-29 21:25:08 --> Loader Class Initialized
INFO - 2023-04-29 21:25:08 --> Helper loaded: url_helper
INFO - 2023-04-29 21:25:08 --> Helper loaded: form_helper
INFO - 2023-04-29 21:25:08 --> Helper loaded: file_helper
INFO - 2023-04-29 21:25:08 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:25:08 --> Form Validation Class Initialized
INFO - 2023-04-29 21:25:08 --> Upload Class Initialized
INFO - 2023-04-29 21:25:08 --> Model "M_auth" initialized
INFO - 2023-04-29 21:25:08 --> Model "M_user" initialized
INFO - 2023-04-29 21:25:08 --> Model "M_produk" initialized
INFO - 2023-04-29 21:25:08 --> Controller Class Initialized
INFO - 2023-04-29 21:25:08 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 21:25:08 --> Model "M_produk" initialized
DEBUG - 2023-04-29 21:25:08 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 21:25:08 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 21:25:08 --> Model "M_transaksi" initialized
INFO - 2023-04-29 21:25:08 --> Model "M_bank" initialized
INFO - 2023-04-29 21:25:08 --> Model "M_pesan" initialized
ERROR - 2023-04-29 21:25:08 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 21:25:08 --> Config Class Initialized
INFO - 2023-04-29 21:25:08 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:25:08 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:25:08 --> Utf8 Class Initialized
INFO - 2023-04-29 21:25:08 --> URI Class Initialized
INFO - 2023-04-29 21:25:08 --> Router Class Initialized
INFO - 2023-04-29 21:25:08 --> Output Class Initialized
INFO - 2023-04-29 21:25:08 --> Security Class Initialized
DEBUG - 2023-04-29 21:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:25:08 --> Input Class Initialized
INFO - 2023-04-29 21:25:08 --> Language Class Initialized
ERROR - 2023-04-29 21:25:08 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 21:26:55 --> Config Class Initialized
INFO - 2023-04-29 21:26:55 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:26:55 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:26:55 --> Utf8 Class Initialized
INFO - 2023-04-29 21:26:55 --> URI Class Initialized
INFO - 2023-04-29 21:26:55 --> Router Class Initialized
INFO - 2023-04-29 21:26:55 --> Output Class Initialized
INFO - 2023-04-29 21:26:55 --> Security Class Initialized
DEBUG - 2023-04-29 21:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:26:55 --> Input Class Initialized
INFO - 2023-04-29 21:26:55 --> Language Class Initialized
INFO - 2023-04-29 21:26:55 --> Loader Class Initialized
INFO - 2023-04-29 21:26:55 --> Helper loaded: url_helper
INFO - 2023-04-29 21:26:55 --> Helper loaded: form_helper
INFO - 2023-04-29 21:26:55 --> Helper loaded: file_helper
INFO - 2023-04-29 21:26:55 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:26:55 --> Form Validation Class Initialized
INFO - 2023-04-29 21:26:55 --> Upload Class Initialized
INFO - 2023-04-29 21:26:55 --> Model "M_auth" initialized
INFO - 2023-04-29 21:26:55 --> Model "M_user" initialized
INFO - 2023-04-29 21:26:55 --> Model "M_produk" initialized
INFO - 2023-04-29 21:26:55 --> Controller Class Initialized
INFO - 2023-04-29 21:26:55 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 21:26:55 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 21:26:55 --> Final output sent to browser
DEBUG - 2023-04-29 21:26:55 --> Total execution time: 0.1180
INFO - 2023-04-29 21:26:58 --> Config Class Initialized
INFO - 2023-04-29 21:26:58 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:26:58 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:26:58 --> Utf8 Class Initialized
INFO - 2023-04-29 21:26:58 --> URI Class Initialized
INFO - 2023-04-29 21:26:58 --> Router Class Initialized
INFO - 2023-04-29 21:26:58 --> Output Class Initialized
INFO - 2023-04-29 21:26:58 --> Security Class Initialized
DEBUG - 2023-04-29 21:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:26:58 --> Input Class Initialized
INFO - 2023-04-29 21:26:58 --> Language Class Initialized
INFO - 2023-04-29 21:26:58 --> Loader Class Initialized
INFO - 2023-04-29 21:26:58 --> Helper loaded: url_helper
INFO - 2023-04-29 21:26:58 --> Helper loaded: form_helper
INFO - 2023-04-29 21:26:58 --> Helper loaded: file_helper
INFO - 2023-04-29 21:26:58 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:26:58 --> Form Validation Class Initialized
INFO - 2023-04-29 21:26:58 --> Upload Class Initialized
INFO - 2023-04-29 21:26:58 --> Model "M_auth" initialized
INFO - 2023-04-29 21:26:58 --> Model "M_user" initialized
INFO - 2023-04-29 21:26:58 --> Model "M_produk" initialized
INFO - 2023-04-29 21:26:58 --> Controller Class Initialized
INFO - 2023-04-29 21:26:58 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 21:26:58 --> Model "M_produk" initialized
DEBUG - 2023-04-29 21:26:58 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 21:26:58 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 21:26:58 --> Model "M_transaksi" initialized
INFO - 2023-04-29 21:26:58 --> Model "M_bank" initialized
INFO - 2023-04-29 21:26:58 --> Model "M_pesan" initialized
ERROR - 2023-04-29 21:26:58 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 21:26:58 --> Config Class Initialized
INFO - 2023-04-29 21:26:58 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:26:58 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:26:58 --> Utf8 Class Initialized
INFO - 2023-04-29 21:26:58 --> URI Class Initialized
INFO - 2023-04-29 21:26:58 --> Router Class Initialized
INFO - 2023-04-29 21:26:58 --> Output Class Initialized
INFO - 2023-04-29 21:26:58 --> Security Class Initialized
DEBUG - 2023-04-29 21:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:26:58 --> Input Class Initialized
INFO - 2023-04-29 21:26:58 --> Language Class Initialized
ERROR - 2023-04-29 21:26:58 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 21:27:00 --> Config Class Initialized
INFO - 2023-04-29 21:27:00 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:27:00 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:27:00 --> Utf8 Class Initialized
INFO - 2023-04-29 21:27:00 --> URI Class Initialized
INFO - 2023-04-29 21:27:00 --> Router Class Initialized
INFO - 2023-04-29 21:27:00 --> Output Class Initialized
INFO - 2023-04-29 21:27:00 --> Security Class Initialized
DEBUG - 2023-04-29 21:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:27:00 --> Input Class Initialized
INFO - 2023-04-29 21:27:00 --> Language Class Initialized
INFO - 2023-04-29 21:27:00 --> Loader Class Initialized
INFO - 2023-04-29 21:27:00 --> Helper loaded: url_helper
INFO - 2023-04-29 21:27:00 --> Helper loaded: form_helper
INFO - 2023-04-29 21:27:00 --> Helper loaded: file_helper
INFO - 2023-04-29 21:27:00 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:27:00 --> Form Validation Class Initialized
INFO - 2023-04-29 21:27:00 --> Upload Class Initialized
INFO - 2023-04-29 21:27:00 --> Model "M_auth" initialized
INFO - 2023-04-29 21:27:00 --> Model "M_user" initialized
INFO - 2023-04-29 21:27:00 --> Model "M_produk" initialized
INFO - 2023-04-29 21:27:00 --> Controller Class Initialized
INFO - 2023-04-29 21:27:00 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 21:27:00 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 21:27:00 --> Final output sent to browser
DEBUG - 2023-04-29 21:27:00 --> Total execution time: 0.1156
INFO - 2023-04-29 21:27:47 --> Config Class Initialized
INFO - 2023-04-29 21:27:47 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:27:47 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:27:47 --> Utf8 Class Initialized
INFO - 2023-04-29 21:27:47 --> URI Class Initialized
INFO - 2023-04-29 21:27:47 --> Router Class Initialized
INFO - 2023-04-29 21:27:47 --> Output Class Initialized
INFO - 2023-04-29 21:27:47 --> Security Class Initialized
DEBUG - 2023-04-29 21:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:27:47 --> Input Class Initialized
INFO - 2023-04-29 21:27:47 --> Language Class Initialized
INFO - 2023-04-29 21:27:47 --> Loader Class Initialized
INFO - 2023-04-29 21:27:47 --> Helper loaded: url_helper
INFO - 2023-04-29 21:27:47 --> Helper loaded: form_helper
INFO - 2023-04-29 21:27:47 --> Helper loaded: file_helper
INFO - 2023-04-29 21:27:47 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:27:47 --> Form Validation Class Initialized
INFO - 2023-04-29 21:27:47 --> Upload Class Initialized
INFO - 2023-04-29 21:27:47 --> Model "M_auth" initialized
INFO - 2023-04-29 21:27:47 --> Model "M_user" initialized
INFO - 2023-04-29 21:27:47 --> Model "M_produk" initialized
INFO - 2023-04-29 21:27:47 --> Controller Class Initialized
INFO - 2023-04-29 21:27:47 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 21:27:47 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 21:27:47 --> Final output sent to browser
DEBUG - 2023-04-29 21:27:47 --> Total execution time: 0.1082
INFO - 2023-04-29 21:28:11 --> Config Class Initialized
INFO - 2023-04-29 21:28:11 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:28:11 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:28:11 --> Utf8 Class Initialized
INFO - 2023-04-29 21:28:11 --> URI Class Initialized
INFO - 2023-04-29 21:28:11 --> Router Class Initialized
INFO - 2023-04-29 21:28:11 --> Output Class Initialized
INFO - 2023-04-29 21:28:11 --> Security Class Initialized
DEBUG - 2023-04-29 21:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:28:11 --> Input Class Initialized
INFO - 2023-04-29 21:28:11 --> Language Class Initialized
INFO - 2023-04-29 21:28:11 --> Loader Class Initialized
INFO - 2023-04-29 21:28:11 --> Helper loaded: url_helper
INFO - 2023-04-29 21:28:11 --> Helper loaded: form_helper
INFO - 2023-04-29 21:28:11 --> Helper loaded: file_helper
INFO - 2023-04-29 21:28:11 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:28:11 --> Form Validation Class Initialized
INFO - 2023-04-29 21:28:11 --> Upload Class Initialized
INFO - 2023-04-29 21:28:11 --> Model "M_auth" initialized
INFO - 2023-04-29 21:28:11 --> Model "M_user" initialized
INFO - 2023-04-29 21:28:11 --> Model "M_produk" initialized
INFO - 2023-04-29 21:28:11 --> Controller Class Initialized
INFO - 2023-04-29 21:28:11 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 21:28:11 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 21:28:11 --> Final output sent to browser
DEBUG - 2023-04-29 21:28:11 --> Total execution time: 0.1136
INFO - 2023-04-29 21:28:13 --> Config Class Initialized
INFO - 2023-04-29 21:28:13 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:28:13 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:28:13 --> Utf8 Class Initialized
INFO - 2023-04-29 21:28:13 --> URI Class Initialized
INFO - 2023-04-29 21:28:13 --> Router Class Initialized
INFO - 2023-04-29 21:28:13 --> Output Class Initialized
INFO - 2023-04-29 21:28:13 --> Security Class Initialized
DEBUG - 2023-04-29 21:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:28:13 --> Input Class Initialized
INFO - 2023-04-29 21:28:13 --> Language Class Initialized
INFO - 2023-04-29 21:28:13 --> Loader Class Initialized
INFO - 2023-04-29 21:28:13 --> Helper loaded: url_helper
INFO - 2023-04-29 21:28:13 --> Helper loaded: form_helper
INFO - 2023-04-29 21:28:13 --> Helper loaded: file_helper
INFO - 2023-04-29 21:28:13 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:28:13 --> Form Validation Class Initialized
INFO - 2023-04-29 21:28:13 --> Upload Class Initialized
INFO - 2023-04-29 21:28:13 --> Model "M_auth" initialized
INFO - 2023-04-29 21:28:13 --> Model "M_user" initialized
INFO - 2023-04-29 21:28:13 --> Model "M_produk" initialized
INFO - 2023-04-29 21:28:13 --> Controller Class Initialized
INFO - 2023-04-29 21:28:13 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_user.php
INFO - 2023-04-29 21:28:13 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 21:28:13 --> Final output sent to browser
DEBUG - 2023-04-29 21:28:13 --> Total execution time: 0.1457
INFO - 2023-04-29 21:28:15 --> Config Class Initialized
INFO - 2023-04-29 21:28:15 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:28:15 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:28:15 --> Utf8 Class Initialized
INFO - 2023-04-29 21:28:15 --> URI Class Initialized
INFO - 2023-04-29 21:28:15 --> Router Class Initialized
INFO - 2023-04-29 21:28:15 --> Output Class Initialized
INFO - 2023-04-29 21:28:15 --> Security Class Initialized
DEBUG - 2023-04-29 21:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:28:15 --> Input Class Initialized
INFO - 2023-04-29 21:28:15 --> Language Class Initialized
INFO - 2023-04-29 21:28:15 --> Loader Class Initialized
INFO - 2023-04-29 21:28:15 --> Helper loaded: url_helper
INFO - 2023-04-29 21:28:15 --> Helper loaded: form_helper
INFO - 2023-04-29 21:28:15 --> Helper loaded: file_helper
INFO - 2023-04-29 21:28:15 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:28:15 --> Form Validation Class Initialized
INFO - 2023-04-29 21:28:15 --> Upload Class Initialized
INFO - 2023-04-29 21:28:15 --> Model "M_auth" initialized
INFO - 2023-04-29 21:28:15 --> Model "M_user" initialized
INFO - 2023-04-29 21:28:15 --> Model "M_produk" initialized
INFO - 2023-04-29 21:28:15 --> Controller Class Initialized
INFO - 2023-04-29 21:28:15 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 21:28:15 --> Model "M_produk" initialized
DEBUG - 2023-04-29 21:28:15 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 21:28:15 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 21:28:15 --> Model "M_transaksi" initialized
INFO - 2023-04-29 21:28:15 --> Model "M_bank" initialized
INFO - 2023-04-29 21:28:15 --> Model "M_pesan" initialized
ERROR - 2023-04-29 21:28:16 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 21:28:16 --> Config Class Initialized
INFO - 2023-04-29 21:28:16 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:28:16 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:28:16 --> Utf8 Class Initialized
INFO - 2023-04-29 21:28:16 --> URI Class Initialized
INFO - 2023-04-29 21:28:16 --> Router Class Initialized
INFO - 2023-04-29 21:28:16 --> Output Class Initialized
INFO - 2023-04-29 21:28:16 --> Security Class Initialized
DEBUG - 2023-04-29 21:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:28:16 --> Input Class Initialized
INFO - 2023-04-29 21:28:16 --> Language Class Initialized
ERROR - 2023-04-29 21:28:16 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 21:28:17 --> Config Class Initialized
INFO - 2023-04-29 21:28:17 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:28:17 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:28:17 --> Utf8 Class Initialized
INFO - 2023-04-29 21:28:17 --> URI Class Initialized
INFO - 2023-04-29 21:28:17 --> Router Class Initialized
INFO - 2023-04-29 21:28:17 --> Output Class Initialized
INFO - 2023-04-29 21:28:17 --> Security Class Initialized
DEBUG - 2023-04-29 21:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:28:17 --> Input Class Initialized
INFO - 2023-04-29 21:28:17 --> Language Class Initialized
INFO - 2023-04-29 21:28:17 --> Loader Class Initialized
INFO - 2023-04-29 21:28:17 --> Helper loaded: url_helper
INFO - 2023-04-29 21:28:17 --> Helper loaded: form_helper
INFO - 2023-04-29 21:28:17 --> Helper loaded: file_helper
INFO - 2023-04-29 21:28:17 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:28:17 --> Form Validation Class Initialized
INFO - 2023-04-29 21:28:17 --> Upload Class Initialized
INFO - 2023-04-29 21:28:17 --> Model "M_auth" initialized
INFO - 2023-04-29 21:28:17 --> Model "M_user" initialized
INFO - 2023-04-29 21:28:17 --> Model "M_produk" initialized
INFO - 2023-04-29 21:28:17 --> Controller Class Initialized
INFO - 2023-04-29 21:28:17 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_user.php
INFO - 2023-04-29 21:28:17 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 21:28:17 --> Final output sent to browser
DEBUG - 2023-04-29 21:28:17 --> Total execution time: 0.1366
INFO - 2023-04-29 21:50:18 --> Config Class Initialized
INFO - 2023-04-29 21:50:18 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:50:18 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:50:18 --> Utf8 Class Initialized
INFO - 2023-04-29 21:50:18 --> URI Class Initialized
DEBUG - 2023-04-29 21:50:18 --> No URI present. Default controller set.
INFO - 2023-04-29 21:50:18 --> Router Class Initialized
INFO - 2023-04-29 21:50:18 --> Output Class Initialized
INFO - 2023-04-29 21:50:18 --> Security Class Initialized
DEBUG - 2023-04-29 21:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:50:18 --> Input Class Initialized
INFO - 2023-04-29 21:50:18 --> Language Class Initialized
INFO - 2023-04-29 21:50:19 --> Loader Class Initialized
INFO - 2023-04-29 21:50:19 --> Helper loaded: url_helper
INFO - 2023-04-29 21:50:19 --> Helper loaded: form_helper
INFO - 2023-04-29 21:50:19 --> Helper loaded: file_helper
INFO - 2023-04-29 21:50:19 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:50:19 --> Form Validation Class Initialized
INFO - 2023-04-29 21:50:19 --> Upload Class Initialized
INFO - 2023-04-29 21:50:19 --> Model "M_auth" initialized
INFO - 2023-04-29 21:50:19 --> Model "M_user" initialized
INFO - 2023-04-29 21:50:19 --> Model "M_produk" initialized
INFO - 2023-04-29 21:50:19 --> Controller Class Initialized
INFO - 2023-04-29 21:50:19 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 21:50:19 --> Model "M_produk" initialized
DEBUG - 2023-04-29 21:50:19 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 21:50:19 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 21:50:19 --> Model "M_transaksi" initialized
INFO - 2023-04-29 21:50:19 --> Model "M_bank" initialized
INFO - 2023-04-29 21:50:19 --> Model "M_pesan" initialized
INFO - 2023-04-29 21:50:20 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-29 21:50:20 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-04-29 21:50:20 --> Final output sent to browser
DEBUG - 2023-04-29 21:50:20 --> Total execution time: 1.6520
INFO - 2023-04-29 21:50:23 --> Config Class Initialized
INFO - 2023-04-29 21:50:23 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:50:23 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:50:23 --> Utf8 Class Initialized
INFO - 2023-04-29 21:50:23 --> URI Class Initialized
INFO - 2023-04-29 21:50:23 --> Router Class Initialized
INFO - 2023-04-29 21:50:23 --> Output Class Initialized
INFO - 2023-04-29 21:50:24 --> Security Class Initialized
DEBUG - 2023-04-29 21:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:50:24 --> Input Class Initialized
INFO - 2023-04-29 21:50:24 --> Language Class Initialized
INFO - 2023-04-29 21:50:24 --> Loader Class Initialized
INFO - 2023-04-29 21:50:24 --> Helper loaded: url_helper
INFO - 2023-04-29 21:50:24 --> Helper loaded: form_helper
INFO - 2023-04-29 21:50:24 --> Helper loaded: file_helper
INFO - 2023-04-29 21:50:24 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:50:24 --> Form Validation Class Initialized
INFO - 2023-04-29 21:50:24 --> Upload Class Initialized
INFO - 2023-04-29 21:50:24 --> Model "M_auth" initialized
INFO - 2023-04-29 21:50:24 --> Model "M_user" initialized
INFO - 2023-04-29 21:50:24 --> Model "M_produk" initialized
INFO - 2023-04-29 21:50:24 --> Controller Class Initialized
INFO - 2023-04-29 21:50:24 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-04-29 21:50:24 --> Final output sent to browser
DEBUG - 2023-04-29 21:50:24 --> Total execution time: 0.1452
INFO - 2023-04-29 21:50:30 --> Config Class Initialized
INFO - 2023-04-29 21:50:30 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:50:30 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:50:30 --> Utf8 Class Initialized
INFO - 2023-04-29 21:50:30 --> URI Class Initialized
INFO - 2023-04-29 21:50:30 --> Router Class Initialized
INFO - 2023-04-29 21:50:30 --> Output Class Initialized
INFO - 2023-04-29 21:50:30 --> Security Class Initialized
DEBUG - 2023-04-29 21:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:50:30 --> Input Class Initialized
INFO - 2023-04-29 21:50:30 --> Language Class Initialized
INFO - 2023-04-29 21:50:30 --> Loader Class Initialized
INFO - 2023-04-29 21:50:30 --> Helper loaded: url_helper
INFO - 2023-04-29 21:50:30 --> Helper loaded: form_helper
INFO - 2023-04-29 21:50:30 --> Helper loaded: file_helper
INFO - 2023-04-29 21:50:30 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:50:30 --> Form Validation Class Initialized
INFO - 2023-04-29 21:50:30 --> Upload Class Initialized
INFO - 2023-04-29 21:50:30 --> Model "M_auth" initialized
INFO - 2023-04-29 21:50:30 --> Model "M_user" initialized
INFO - 2023-04-29 21:50:30 --> Model "M_produk" initialized
INFO - 2023-04-29 21:50:30 --> Controller Class Initialized
INFO - 2023-04-29 21:50:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-04-29 21:50:30 --> Config Class Initialized
INFO - 2023-04-29 21:50:30 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:50:30 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:50:30 --> Utf8 Class Initialized
INFO - 2023-04-29 21:50:30 --> URI Class Initialized
INFO - 2023-04-29 21:50:30 --> Router Class Initialized
INFO - 2023-04-29 21:50:30 --> Output Class Initialized
INFO - 2023-04-29 21:50:30 --> Security Class Initialized
DEBUG - 2023-04-29 21:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:50:30 --> Input Class Initialized
INFO - 2023-04-29 21:50:30 --> Language Class Initialized
INFO - 2023-04-29 21:50:30 --> Loader Class Initialized
INFO - 2023-04-29 21:50:30 --> Helper loaded: url_helper
INFO - 2023-04-29 21:50:30 --> Helper loaded: form_helper
INFO - 2023-04-29 21:50:30 --> Helper loaded: file_helper
INFO - 2023-04-29 21:50:30 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:50:30 --> Form Validation Class Initialized
INFO - 2023-04-29 21:50:30 --> Upload Class Initialized
INFO - 2023-04-29 21:50:30 --> Model "M_auth" initialized
INFO - 2023-04-29 21:50:30 --> Model "M_user" initialized
INFO - 2023-04-29 21:50:30 --> Model "M_produk" initialized
INFO - 2023-04-29 21:50:30 --> Controller Class Initialized
INFO - 2023-04-29 21:50:30 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 21:50:31 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 21:50:31 --> Final output sent to browser
DEBUG - 2023-04-29 21:50:31 --> Total execution time: 0.2458
INFO - 2023-04-29 21:50:34 --> Config Class Initialized
INFO - 2023-04-29 21:50:34 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:50:34 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:50:34 --> Utf8 Class Initialized
INFO - 2023-04-29 21:50:34 --> URI Class Initialized
INFO - 2023-04-29 21:50:34 --> Router Class Initialized
INFO - 2023-04-29 21:50:34 --> Output Class Initialized
INFO - 2023-04-29 21:50:34 --> Security Class Initialized
DEBUG - 2023-04-29 21:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:50:34 --> Input Class Initialized
INFO - 2023-04-29 21:50:34 --> Language Class Initialized
INFO - 2023-04-29 21:50:34 --> Loader Class Initialized
INFO - 2023-04-29 21:50:34 --> Helper loaded: url_helper
INFO - 2023-04-29 21:50:34 --> Helper loaded: form_helper
INFO - 2023-04-29 21:50:34 --> Helper loaded: file_helper
INFO - 2023-04-29 21:50:34 --> Database Driver Class Initialized
DEBUG - 2023-04-29 21:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 21:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 21:50:34 --> Form Validation Class Initialized
INFO - 2023-04-29 21:50:34 --> Upload Class Initialized
INFO - 2023-04-29 21:50:34 --> Model "M_auth" initialized
INFO - 2023-04-29 21:50:34 --> Model "M_user" initialized
INFO - 2023-04-29 21:50:34 --> Model "M_produk" initialized
INFO - 2023-04-29 21:50:34 --> Controller Class Initialized
INFO - 2023-04-29 21:50:34 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 21:50:34 --> Model "M_produk" initialized
DEBUG - 2023-04-29 21:50:34 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 21:50:34 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 21:50:34 --> Model "M_transaksi" initialized
INFO - 2023-04-29 21:50:34 --> Model "M_bank" initialized
INFO - 2023-04-29 21:50:34 --> Model "M_pesan" initialized
ERROR - 2023-04-29 21:50:34 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 21:50:34 --> Config Class Initialized
INFO - 2023-04-29 21:50:34 --> Hooks Class Initialized
DEBUG - 2023-04-29 21:50:34 --> UTF-8 Support Enabled
INFO - 2023-04-29 21:50:34 --> Utf8 Class Initialized
INFO - 2023-04-29 21:50:34 --> URI Class Initialized
INFO - 2023-04-29 21:50:34 --> Router Class Initialized
INFO - 2023-04-29 21:50:34 --> Output Class Initialized
INFO - 2023-04-29 21:50:34 --> Security Class Initialized
DEBUG - 2023-04-29 21:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 21:50:34 --> Input Class Initialized
INFO - 2023-04-29 21:50:34 --> Language Class Initialized
ERROR - 2023-04-29 21:50:34 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 22:21:44 --> Config Class Initialized
INFO - 2023-04-29 22:21:44 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:21:44 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:21:44 --> Utf8 Class Initialized
INFO - 2023-04-29 22:21:44 --> URI Class Initialized
INFO - 2023-04-29 22:21:44 --> Router Class Initialized
INFO - 2023-04-29 22:21:44 --> Output Class Initialized
INFO - 2023-04-29 22:21:45 --> Security Class Initialized
DEBUG - 2023-04-29 22:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:21:45 --> Input Class Initialized
INFO - 2023-04-29 22:21:45 --> Language Class Initialized
ERROR - 2023-04-29 22:21:45 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 22:21:47 --> Config Class Initialized
INFO - 2023-04-29 22:21:47 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:21:47 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:21:47 --> Utf8 Class Initialized
INFO - 2023-04-29 22:21:47 --> URI Class Initialized
INFO - 2023-04-29 22:21:48 --> Router Class Initialized
INFO - 2023-04-29 22:21:48 --> Output Class Initialized
INFO - 2023-04-29 22:21:48 --> Security Class Initialized
DEBUG - 2023-04-29 22:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:21:48 --> Input Class Initialized
INFO - 2023-04-29 22:21:48 --> Language Class Initialized
INFO - 2023-04-29 22:21:48 --> Loader Class Initialized
INFO - 2023-04-29 22:21:48 --> Helper loaded: url_helper
INFO - 2023-04-29 22:21:48 --> Helper loaded: form_helper
INFO - 2023-04-29 22:21:48 --> Helper loaded: file_helper
INFO - 2023-04-29 22:21:48 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:21:48 --> Form Validation Class Initialized
INFO - 2023-04-29 22:21:48 --> Upload Class Initialized
INFO - 2023-04-29 22:21:48 --> Model "M_auth" initialized
INFO - 2023-04-29 22:21:48 --> Model "M_user" initialized
INFO - 2023-04-29 22:21:48 --> Model "M_produk" initialized
INFO - 2023-04-29 22:21:48 --> Controller Class Initialized
INFO - 2023-04-29 22:21:48 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 22:21:48 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:21:48 --> Final output sent to browser
DEBUG - 2023-04-29 22:21:48 --> Total execution time: 0.1181
INFO - 2023-04-29 22:21:56 --> Config Class Initialized
INFO - 2023-04-29 22:21:56 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:21:56 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:21:56 --> Utf8 Class Initialized
INFO - 2023-04-29 22:21:56 --> URI Class Initialized
INFO - 2023-04-29 22:21:56 --> Router Class Initialized
INFO - 2023-04-29 22:21:56 --> Output Class Initialized
INFO - 2023-04-29 22:21:57 --> Security Class Initialized
DEBUG - 2023-04-29 22:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:21:57 --> Input Class Initialized
INFO - 2023-04-29 22:21:57 --> Language Class Initialized
INFO - 2023-04-29 22:21:57 --> Loader Class Initialized
INFO - 2023-04-29 22:21:57 --> Helper loaded: url_helper
INFO - 2023-04-29 22:21:57 --> Helper loaded: form_helper
INFO - 2023-04-29 22:21:57 --> Helper loaded: file_helper
INFO - 2023-04-29 22:21:57 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:21:57 --> Form Validation Class Initialized
INFO - 2023-04-29 22:21:57 --> Upload Class Initialized
INFO - 2023-04-29 22:21:57 --> Model "M_auth" initialized
INFO - 2023-04-29 22:21:57 --> Model "M_user" initialized
INFO - 2023-04-29 22:21:57 --> Model "M_produk" initialized
INFO - 2023-04-29 22:21:57 --> Controller Class Initialized
INFO - 2023-04-29 22:21:57 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:21:57 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:21:57 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:21:57 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:21:57 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:21:57 --> Model "M_bank" initialized
INFO - 2023-04-29 22:21:57 --> Model "M_pesan" initialized
ERROR - 2023-04-29 22:21:57 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 22:21:57 --> Config Class Initialized
INFO - 2023-04-29 22:21:57 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:21:57 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:21:57 --> Utf8 Class Initialized
INFO - 2023-04-29 22:21:57 --> URI Class Initialized
INFO - 2023-04-29 22:21:57 --> Router Class Initialized
INFO - 2023-04-29 22:21:57 --> Output Class Initialized
INFO - 2023-04-29 22:21:57 --> Security Class Initialized
DEBUG - 2023-04-29 22:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:21:57 --> Input Class Initialized
INFO - 2023-04-29 22:21:57 --> Language Class Initialized
ERROR - 2023-04-29 22:21:57 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 22:21:58 --> Config Class Initialized
INFO - 2023-04-29 22:21:58 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:21:58 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:21:58 --> Utf8 Class Initialized
INFO - 2023-04-29 22:21:58 --> URI Class Initialized
INFO - 2023-04-29 22:21:58 --> Router Class Initialized
INFO - 2023-04-29 22:21:58 --> Output Class Initialized
INFO - 2023-04-29 22:21:58 --> Security Class Initialized
DEBUG - 2023-04-29 22:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:21:58 --> Input Class Initialized
INFO - 2023-04-29 22:21:58 --> Language Class Initialized
INFO - 2023-04-29 22:21:58 --> Loader Class Initialized
INFO - 2023-04-29 22:21:58 --> Helper loaded: url_helper
INFO - 2023-04-29 22:21:58 --> Helper loaded: form_helper
INFO - 2023-04-29 22:21:58 --> Helper loaded: file_helper
INFO - 2023-04-29 22:21:58 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:21:58 --> Form Validation Class Initialized
INFO - 2023-04-29 22:21:58 --> Upload Class Initialized
INFO - 2023-04-29 22:21:58 --> Model "M_auth" initialized
INFO - 2023-04-29 22:21:58 --> Model "M_user" initialized
INFO - 2023-04-29 22:21:58 --> Model "M_produk" initialized
INFO - 2023-04-29 22:21:58 --> Controller Class Initialized
INFO - 2023-04-29 22:21:58 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 22:21:58 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:21:58 --> Final output sent to browser
DEBUG - 2023-04-29 22:21:58 --> Total execution time: 0.1193
INFO - 2023-04-29 22:22:02 --> Config Class Initialized
INFO - 2023-04-29 22:22:02 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:22:02 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:22:02 --> Utf8 Class Initialized
INFO - 2023-04-29 22:22:02 --> URI Class Initialized
INFO - 2023-04-29 22:22:02 --> Router Class Initialized
INFO - 2023-04-29 22:22:02 --> Output Class Initialized
INFO - 2023-04-29 22:22:02 --> Security Class Initialized
DEBUG - 2023-04-29 22:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:22:02 --> Input Class Initialized
INFO - 2023-04-29 22:22:02 --> Language Class Initialized
INFO - 2023-04-29 22:22:02 --> Loader Class Initialized
INFO - 2023-04-29 22:22:02 --> Helper loaded: url_helper
INFO - 2023-04-29 22:22:02 --> Helper loaded: form_helper
INFO - 2023-04-29 22:22:02 --> Helper loaded: file_helper
INFO - 2023-04-29 22:22:02 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:22:02 --> Form Validation Class Initialized
INFO - 2023-04-29 22:22:02 --> Upload Class Initialized
INFO - 2023-04-29 22:22:02 --> Model "M_auth" initialized
INFO - 2023-04-29 22:22:02 --> Model "M_user" initialized
INFO - 2023-04-29 22:22:02 --> Model "M_produk" initialized
INFO - 2023-04-29 22:22:02 --> Controller Class Initialized
INFO - 2023-04-29 22:22:02 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:22:02 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:22:02 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:22:02 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:22:02 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:22:02 --> Model "M_bank" initialized
INFO - 2023-04-29 22:22:02 --> Model "M_pesan" initialized
ERROR - 2023-04-29 22:22:02 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 22:22:02 --> Config Class Initialized
INFO - 2023-04-29 22:22:02 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:22:02 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:22:02 --> Utf8 Class Initialized
INFO - 2023-04-29 22:22:02 --> URI Class Initialized
INFO - 2023-04-29 22:22:02 --> Router Class Initialized
INFO - 2023-04-29 22:22:02 --> Output Class Initialized
INFO - 2023-04-29 22:22:02 --> Security Class Initialized
DEBUG - 2023-04-29 22:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:22:02 --> Input Class Initialized
INFO - 2023-04-29 22:22:02 --> Language Class Initialized
ERROR - 2023-04-29 22:22:02 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 22:22:03 --> Config Class Initialized
INFO - 2023-04-29 22:22:03 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:22:03 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:22:03 --> Utf8 Class Initialized
INFO - 2023-04-29 22:22:03 --> URI Class Initialized
INFO - 2023-04-29 22:22:03 --> Router Class Initialized
INFO - 2023-04-29 22:22:03 --> Output Class Initialized
INFO - 2023-04-29 22:22:03 --> Security Class Initialized
DEBUG - 2023-04-29 22:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:22:03 --> Input Class Initialized
INFO - 2023-04-29 22:22:03 --> Language Class Initialized
INFO - 2023-04-29 22:22:03 --> Loader Class Initialized
INFO - 2023-04-29 22:22:03 --> Helper loaded: url_helper
INFO - 2023-04-29 22:22:03 --> Helper loaded: form_helper
INFO - 2023-04-29 22:22:03 --> Helper loaded: file_helper
INFO - 2023-04-29 22:22:03 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:22:04 --> Form Validation Class Initialized
INFO - 2023-04-29 22:22:04 --> Upload Class Initialized
INFO - 2023-04-29 22:22:04 --> Model "M_auth" initialized
INFO - 2023-04-29 22:22:04 --> Model "M_user" initialized
INFO - 2023-04-29 22:22:04 --> Model "M_produk" initialized
INFO - 2023-04-29 22:22:04 --> Controller Class Initialized
INFO - 2023-04-29 22:22:04 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 22:22:04 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:22:04 --> Final output sent to browser
DEBUG - 2023-04-29 22:22:04 --> Total execution time: 0.1125
INFO - 2023-04-29 22:22:16 --> Config Class Initialized
INFO - 2023-04-29 22:22:16 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:22:16 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:22:16 --> Utf8 Class Initialized
INFO - 2023-04-29 22:22:16 --> URI Class Initialized
INFO - 2023-04-29 22:22:16 --> Router Class Initialized
INFO - 2023-04-29 22:22:16 --> Output Class Initialized
INFO - 2023-04-29 22:22:16 --> Security Class Initialized
DEBUG - 2023-04-29 22:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:22:16 --> Input Class Initialized
INFO - 2023-04-29 22:22:16 --> Language Class Initialized
INFO - 2023-04-29 22:22:16 --> Loader Class Initialized
INFO - 2023-04-29 22:22:16 --> Helper loaded: url_helper
INFO - 2023-04-29 22:22:16 --> Helper loaded: form_helper
INFO - 2023-04-29 22:22:16 --> Helper loaded: file_helper
INFO - 2023-04-29 22:22:16 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:22:16 --> Form Validation Class Initialized
INFO - 2023-04-29 22:22:16 --> Upload Class Initialized
INFO - 2023-04-29 22:22:16 --> Model "M_auth" initialized
INFO - 2023-04-29 22:22:16 --> Model "M_user" initialized
INFO - 2023-04-29 22:22:16 --> Model "M_produk" initialized
INFO - 2023-04-29 22:22:16 --> Controller Class Initialized
INFO - 2023-04-29 22:22:16 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:22:16 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:22:16 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:22:16 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:22:16 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:22:16 --> Model "M_bank" initialized
INFO - 2023-04-29 22:22:16 --> Model "M_pesan" initialized
ERROR - 2023-04-29 22:22:16 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 22:22:16 --> Config Class Initialized
INFO - 2023-04-29 22:22:16 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:22:16 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:22:16 --> Utf8 Class Initialized
INFO - 2023-04-29 22:22:16 --> URI Class Initialized
INFO - 2023-04-29 22:22:16 --> Router Class Initialized
INFO - 2023-04-29 22:22:16 --> Output Class Initialized
INFO - 2023-04-29 22:22:16 --> Security Class Initialized
DEBUG - 2023-04-29 22:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:22:16 --> Input Class Initialized
INFO - 2023-04-29 22:22:16 --> Language Class Initialized
ERROR - 2023-04-29 22:22:16 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 22:23:36 --> Config Class Initialized
INFO - 2023-04-29 22:23:36 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:23:36 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:23:36 --> Utf8 Class Initialized
INFO - 2023-04-29 22:23:36 --> URI Class Initialized
DEBUG - 2023-04-29 22:23:36 --> No URI present. Default controller set.
INFO - 2023-04-29 22:23:36 --> Router Class Initialized
INFO - 2023-04-29 22:23:36 --> Output Class Initialized
INFO - 2023-04-29 22:23:36 --> Security Class Initialized
DEBUG - 2023-04-29 22:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:23:36 --> Input Class Initialized
INFO - 2023-04-29 22:23:36 --> Language Class Initialized
INFO - 2023-04-29 22:23:36 --> Loader Class Initialized
INFO - 2023-04-29 22:23:36 --> Helper loaded: url_helper
INFO - 2023-04-29 22:23:36 --> Helper loaded: form_helper
INFO - 2023-04-29 22:23:36 --> Helper loaded: file_helper
INFO - 2023-04-29 22:23:36 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:23:36 --> Form Validation Class Initialized
INFO - 2023-04-29 22:23:36 --> Upload Class Initialized
INFO - 2023-04-29 22:23:36 --> Model "M_auth" initialized
INFO - 2023-04-29 22:23:36 --> Model "M_user" initialized
INFO - 2023-04-29 22:23:36 --> Model "M_produk" initialized
INFO - 2023-04-29 22:23:36 --> Controller Class Initialized
INFO - 2023-04-29 22:23:36 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:23:36 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:23:36 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:23:36 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:23:36 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:23:36 --> Model "M_bank" initialized
INFO - 2023-04-29 22:23:36 --> Model "M_pesan" initialized
INFO - 2023-04-29 22:23:36 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-29 22:23:36 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-04-29 22:23:36 --> Final output sent to browser
DEBUG - 2023-04-29 22:23:36 --> Total execution time: 0.1214
INFO - 2023-04-29 22:23:48 --> Config Class Initialized
INFO - 2023-04-29 22:23:48 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:23:48 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:23:48 --> Utf8 Class Initialized
INFO - 2023-04-29 22:23:48 --> URI Class Initialized
DEBUG - 2023-04-29 22:23:48 --> No URI present. Default controller set.
INFO - 2023-04-29 22:23:48 --> Router Class Initialized
INFO - 2023-04-29 22:23:48 --> Output Class Initialized
INFO - 2023-04-29 22:23:48 --> Security Class Initialized
DEBUG - 2023-04-29 22:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:23:48 --> Input Class Initialized
INFO - 2023-04-29 22:23:48 --> Language Class Initialized
INFO - 2023-04-29 22:23:48 --> Loader Class Initialized
INFO - 2023-04-29 22:23:48 --> Helper loaded: url_helper
INFO - 2023-04-29 22:23:48 --> Helper loaded: form_helper
INFO - 2023-04-29 22:23:48 --> Helper loaded: file_helper
INFO - 2023-04-29 22:23:48 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:23:48 --> Form Validation Class Initialized
INFO - 2023-04-29 22:23:48 --> Upload Class Initialized
INFO - 2023-04-29 22:23:48 --> Model "M_auth" initialized
INFO - 2023-04-29 22:23:48 --> Model "M_user" initialized
INFO - 2023-04-29 22:23:48 --> Model "M_produk" initialized
INFO - 2023-04-29 22:23:48 --> Controller Class Initialized
INFO - 2023-04-29 22:23:48 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:23:48 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:23:48 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:23:48 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:23:48 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:23:48 --> Model "M_bank" initialized
INFO - 2023-04-29 22:23:48 --> Model "M_pesan" initialized
INFO - 2023-04-29 22:23:48 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-29 22:23:48 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-04-29 22:23:48 --> Final output sent to browser
DEBUG - 2023-04-29 22:23:48 --> Total execution time: 0.1862
INFO - 2023-04-29 22:23:52 --> Config Class Initialized
INFO - 2023-04-29 22:23:52 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:23:52 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:23:52 --> Utf8 Class Initialized
INFO - 2023-04-29 22:23:52 --> URI Class Initialized
INFO - 2023-04-29 22:23:52 --> Router Class Initialized
INFO - 2023-04-29 22:23:52 --> Output Class Initialized
INFO - 2023-04-29 22:23:52 --> Security Class Initialized
DEBUG - 2023-04-29 22:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:23:52 --> Input Class Initialized
INFO - 2023-04-29 22:23:52 --> Language Class Initialized
INFO - 2023-04-29 22:23:52 --> Loader Class Initialized
INFO - 2023-04-29 22:23:52 --> Helper loaded: url_helper
INFO - 2023-04-29 22:23:52 --> Helper loaded: form_helper
INFO - 2023-04-29 22:23:52 --> Helper loaded: file_helper
INFO - 2023-04-29 22:23:52 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:23:52 --> Form Validation Class Initialized
INFO - 2023-04-29 22:23:52 --> Upload Class Initialized
INFO - 2023-04-29 22:23:52 --> Model "M_auth" initialized
INFO - 2023-04-29 22:23:52 --> Model "M_user" initialized
INFO - 2023-04-29 22:23:52 --> Model "M_produk" initialized
INFO - 2023-04-29 22:23:52 --> Controller Class Initialized
INFO - 2023-04-29 22:23:52 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:23:52 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:23:52 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:23:52 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:23:52 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:23:52 --> Model "M_bank" initialized
INFO - 2023-04-29 22:23:52 --> Model "M_pesan" initialized
INFO - 2023-04-29 22:23:52 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-29 22:23:52 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/v_produk_detail.php
INFO - 2023-04-29 22:23:52 --> Final output sent to browser
DEBUG - 2023-04-29 22:23:52 --> Total execution time: 0.1188
INFO - 2023-04-29 22:23:54 --> Config Class Initialized
INFO - 2023-04-29 22:23:54 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:23:54 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:23:54 --> Utf8 Class Initialized
INFO - 2023-04-29 22:23:54 --> URI Class Initialized
DEBUG - 2023-04-29 22:23:54 --> No URI present. Default controller set.
INFO - 2023-04-29 22:23:54 --> Router Class Initialized
INFO - 2023-04-29 22:23:54 --> Output Class Initialized
INFO - 2023-04-29 22:23:54 --> Security Class Initialized
DEBUG - 2023-04-29 22:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:23:54 --> Input Class Initialized
INFO - 2023-04-29 22:23:54 --> Language Class Initialized
INFO - 2023-04-29 22:23:54 --> Loader Class Initialized
INFO - 2023-04-29 22:23:54 --> Helper loaded: url_helper
INFO - 2023-04-29 22:23:54 --> Helper loaded: form_helper
INFO - 2023-04-29 22:23:54 --> Helper loaded: file_helper
INFO - 2023-04-29 22:23:54 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:23:54 --> Form Validation Class Initialized
INFO - 2023-04-29 22:23:54 --> Upload Class Initialized
INFO - 2023-04-29 22:23:54 --> Model "M_auth" initialized
INFO - 2023-04-29 22:23:54 --> Model "M_user" initialized
INFO - 2023-04-29 22:23:54 --> Model "M_produk" initialized
INFO - 2023-04-29 22:23:54 --> Controller Class Initialized
INFO - 2023-04-29 22:23:54 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:23:54 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:23:54 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:23:54 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:23:54 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:23:54 --> Model "M_bank" initialized
INFO - 2023-04-29 22:23:54 --> Model "M_pesan" initialized
INFO - 2023-04-29 22:23:54 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-29 22:23:54 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-04-29 22:23:54 --> Final output sent to browser
DEBUG - 2023-04-29 22:23:54 --> Total execution time: 0.1505
INFO - 2023-04-29 22:23:56 --> Config Class Initialized
INFO - 2023-04-29 22:23:56 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:23:56 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:23:56 --> Utf8 Class Initialized
INFO - 2023-04-29 22:23:56 --> URI Class Initialized
INFO - 2023-04-29 22:23:56 --> Router Class Initialized
INFO - 2023-04-29 22:23:56 --> Output Class Initialized
INFO - 2023-04-29 22:23:56 --> Security Class Initialized
DEBUG - 2023-04-29 22:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:23:56 --> Input Class Initialized
INFO - 2023-04-29 22:23:56 --> Language Class Initialized
INFO - 2023-04-29 22:23:56 --> Loader Class Initialized
INFO - 2023-04-29 22:23:56 --> Helper loaded: url_helper
INFO - 2023-04-29 22:23:56 --> Helper loaded: form_helper
INFO - 2023-04-29 22:23:56 --> Helper loaded: file_helper
INFO - 2023-04-29 22:23:56 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:23:56 --> Form Validation Class Initialized
INFO - 2023-04-29 22:23:56 --> Upload Class Initialized
INFO - 2023-04-29 22:23:56 --> Model "M_auth" initialized
INFO - 2023-04-29 22:23:56 --> Model "M_user" initialized
INFO - 2023-04-29 22:23:56 --> Model "M_produk" initialized
INFO - 2023-04-29 22:23:56 --> Controller Class Initialized
INFO - 2023-04-29 22:23:56 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-04-29 22:23:56 --> Final output sent to browser
DEBUG - 2023-04-29 22:23:56 --> Total execution time: 0.1285
INFO - 2023-04-29 22:24:03 --> Config Class Initialized
INFO - 2023-04-29 22:24:03 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:24:03 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:24:03 --> Utf8 Class Initialized
INFO - 2023-04-29 22:24:03 --> URI Class Initialized
INFO - 2023-04-29 22:24:03 --> Router Class Initialized
INFO - 2023-04-29 22:24:03 --> Output Class Initialized
INFO - 2023-04-29 22:24:03 --> Security Class Initialized
DEBUG - 2023-04-29 22:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:24:03 --> Input Class Initialized
INFO - 2023-04-29 22:24:03 --> Language Class Initialized
INFO - 2023-04-29 22:24:03 --> Loader Class Initialized
INFO - 2023-04-29 22:24:03 --> Helper loaded: url_helper
INFO - 2023-04-29 22:24:03 --> Helper loaded: form_helper
INFO - 2023-04-29 22:24:03 --> Helper loaded: file_helper
INFO - 2023-04-29 22:24:03 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:24:03 --> Form Validation Class Initialized
INFO - 2023-04-29 22:24:03 --> Upload Class Initialized
INFO - 2023-04-29 22:24:03 --> Model "M_auth" initialized
INFO - 2023-04-29 22:24:03 --> Model "M_user" initialized
INFO - 2023-04-29 22:24:03 --> Model "M_produk" initialized
INFO - 2023-04-29 22:24:03 --> Controller Class Initialized
INFO - 2023-04-29 22:24:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-04-29 22:24:03 --> Config Class Initialized
INFO - 2023-04-29 22:24:03 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:24:03 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:24:03 --> Utf8 Class Initialized
INFO - 2023-04-29 22:24:03 --> URI Class Initialized
INFO - 2023-04-29 22:24:03 --> Router Class Initialized
INFO - 2023-04-29 22:24:03 --> Output Class Initialized
INFO - 2023-04-29 22:24:03 --> Security Class Initialized
DEBUG - 2023-04-29 22:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:24:03 --> Input Class Initialized
INFO - 2023-04-29 22:24:03 --> Language Class Initialized
INFO - 2023-04-29 22:24:03 --> Loader Class Initialized
INFO - 2023-04-29 22:24:03 --> Helper loaded: url_helper
INFO - 2023-04-29 22:24:03 --> Helper loaded: form_helper
INFO - 2023-04-29 22:24:03 --> Helper loaded: file_helper
INFO - 2023-04-29 22:24:03 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:24:03 --> Form Validation Class Initialized
INFO - 2023-04-29 22:24:03 --> Upload Class Initialized
INFO - 2023-04-29 22:24:03 --> Model "M_auth" initialized
INFO - 2023-04-29 22:24:03 --> Model "M_user" initialized
INFO - 2023-04-29 22:24:03 --> Model "M_produk" initialized
INFO - 2023-04-29 22:24:03 --> Controller Class Initialized
INFO - 2023-04-29 22:24:03 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 22:24:03 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:24:03 --> Final output sent to browser
DEBUG - 2023-04-29 22:24:03 --> Total execution time: 0.1035
INFO - 2023-04-29 22:24:34 --> Config Class Initialized
INFO - 2023-04-29 22:24:34 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:24:34 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:24:34 --> Utf8 Class Initialized
INFO - 2023-04-29 22:24:34 --> URI Class Initialized
INFO - 2023-04-29 22:24:34 --> Router Class Initialized
INFO - 2023-04-29 22:24:34 --> Output Class Initialized
INFO - 2023-04-29 22:24:34 --> Security Class Initialized
DEBUG - 2023-04-29 22:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:24:34 --> Input Class Initialized
INFO - 2023-04-29 22:24:34 --> Language Class Initialized
INFO - 2023-04-29 22:24:34 --> Loader Class Initialized
INFO - 2023-04-29 22:24:34 --> Helper loaded: url_helper
INFO - 2023-04-29 22:24:34 --> Helper loaded: form_helper
INFO - 2023-04-29 22:24:34 --> Helper loaded: file_helper
INFO - 2023-04-29 22:24:34 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:24:34 --> Form Validation Class Initialized
INFO - 2023-04-29 22:24:34 --> Upload Class Initialized
INFO - 2023-04-29 22:24:34 --> Model "M_auth" initialized
INFO - 2023-04-29 22:24:34 --> Model "M_user" initialized
INFO - 2023-04-29 22:24:34 --> Model "M_produk" initialized
INFO - 2023-04-29 22:24:34 --> Controller Class Initialized
INFO - 2023-04-29 22:24:34 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 22:24:34 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:24:34 --> Final output sent to browser
DEBUG - 2023-04-29 22:24:34 --> Total execution time: 0.1183
INFO - 2023-04-29 22:25:21 --> Config Class Initialized
INFO - 2023-04-29 22:25:21 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:25:21 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:25:21 --> Utf8 Class Initialized
INFO - 2023-04-29 22:25:21 --> URI Class Initialized
INFO - 2023-04-29 22:25:21 --> Router Class Initialized
INFO - 2023-04-29 22:25:21 --> Output Class Initialized
INFO - 2023-04-29 22:25:21 --> Security Class Initialized
DEBUG - 2023-04-29 22:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:25:21 --> Input Class Initialized
INFO - 2023-04-29 22:25:21 --> Language Class Initialized
INFO - 2023-04-29 22:25:21 --> Loader Class Initialized
INFO - 2023-04-29 22:25:21 --> Helper loaded: url_helper
INFO - 2023-04-29 22:25:21 --> Helper loaded: form_helper
INFO - 2023-04-29 22:25:21 --> Helper loaded: file_helper
INFO - 2023-04-29 22:25:21 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:25:21 --> Form Validation Class Initialized
INFO - 2023-04-29 22:25:21 --> Upload Class Initialized
INFO - 2023-04-29 22:25:21 --> Model "M_auth" initialized
INFO - 2023-04-29 22:25:21 --> Model "M_user" initialized
INFO - 2023-04-29 22:25:21 --> Model "M_produk" initialized
INFO - 2023-04-29 22:25:21 --> Controller Class Initialized
INFO - 2023-04-29 22:25:21 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 22:25:21 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:25:21 --> Final output sent to browser
DEBUG - 2023-04-29 22:25:21 --> Total execution time: 0.1586
INFO - 2023-04-29 22:25:24 --> Config Class Initialized
INFO - 2023-04-29 22:25:24 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:25:24 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:25:24 --> Utf8 Class Initialized
INFO - 2023-04-29 22:25:24 --> URI Class Initialized
INFO - 2023-04-29 22:25:24 --> Router Class Initialized
INFO - 2023-04-29 22:25:24 --> Output Class Initialized
INFO - 2023-04-29 22:25:24 --> Security Class Initialized
DEBUG - 2023-04-29 22:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:25:24 --> Input Class Initialized
INFO - 2023-04-29 22:25:24 --> Language Class Initialized
INFO - 2023-04-29 22:25:24 --> Loader Class Initialized
INFO - 2023-04-29 22:25:24 --> Helper loaded: url_helper
INFO - 2023-04-29 22:25:24 --> Helper loaded: form_helper
INFO - 2023-04-29 22:25:24 --> Helper loaded: file_helper
INFO - 2023-04-29 22:25:24 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:25:24 --> Form Validation Class Initialized
INFO - 2023-04-29 22:25:24 --> Upload Class Initialized
INFO - 2023-04-29 22:25:24 --> Model "M_auth" initialized
INFO - 2023-04-29 22:25:24 --> Model "M_user" initialized
INFO - 2023-04-29 22:25:24 --> Model "M_produk" initialized
INFO - 2023-04-29 22:25:24 --> Controller Class Initialized
INFO - 2023-04-29 22:25:24 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:25:24 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:25:24 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:25:24 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:25:24 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:25:24 --> Model "M_bank" initialized
INFO - 2023-04-29 22:25:24 --> Model "M_pesan" initialized
ERROR - 2023-04-29 22:25:24 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 22:25:24 --> Config Class Initialized
INFO - 2023-04-29 22:25:24 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:25:24 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:25:24 --> Utf8 Class Initialized
INFO - 2023-04-29 22:25:24 --> URI Class Initialized
INFO - 2023-04-29 22:25:24 --> Router Class Initialized
INFO - 2023-04-29 22:25:24 --> Output Class Initialized
INFO - 2023-04-29 22:25:24 --> Security Class Initialized
DEBUG - 2023-04-29 22:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:25:24 --> Input Class Initialized
INFO - 2023-04-29 22:25:24 --> Language Class Initialized
ERROR - 2023-04-29 22:25:24 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 22:25:25 --> Config Class Initialized
INFO - 2023-04-29 22:25:25 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:25:25 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:25:25 --> Utf8 Class Initialized
INFO - 2023-04-29 22:25:25 --> URI Class Initialized
INFO - 2023-04-29 22:25:25 --> Router Class Initialized
INFO - 2023-04-29 22:25:25 --> Output Class Initialized
INFO - 2023-04-29 22:25:25 --> Security Class Initialized
DEBUG - 2023-04-29 22:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:25:25 --> Input Class Initialized
INFO - 2023-04-29 22:25:25 --> Language Class Initialized
INFO - 2023-04-29 22:25:25 --> Loader Class Initialized
INFO - 2023-04-29 22:25:25 --> Helper loaded: url_helper
INFO - 2023-04-29 22:25:25 --> Helper loaded: form_helper
INFO - 2023-04-29 22:25:25 --> Helper loaded: file_helper
INFO - 2023-04-29 22:25:25 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:25:25 --> Form Validation Class Initialized
INFO - 2023-04-29 22:25:25 --> Upload Class Initialized
INFO - 2023-04-29 22:25:25 --> Model "M_auth" initialized
INFO - 2023-04-29 22:25:25 --> Model "M_user" initialized
INFO - 2023-04-29 22:25:25 --> Model "M_produk" initialized
INFO - 2023-04-29 22:25:25 --> Controller Class Initialized
INFO - 2023-04-29 22:25:25 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 22:25:25 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:25:25 --> Final output sent to browser
DEBUG - 2023-04-29 22:25:25 --> Total execution time: 0.1187
INFO - 2023-04-29 22:25:27 --> Config Class Initialized
INFO - 2023-04-29 22:25:27 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:25:27 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:25:27 --> Utf8 Class Initialized
INFO - 2023-04-29 22:25:27 --> URI Class Initialized
INFO - 2023-04-29 22:25:28 --> Router Class Initialized
INFO - 2023-04-29 22:25:28 --> Output Class Initialized
INFO - 2023-04-29 22:25:28 --> Security Class Initialized
DEBUG - 2023-04-29 22:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:25:28 --> Input Class Initialized
INFO - 2023-04-29 22:25:28 --> Language Class Initialized
INFO - 2023-04-29 22:25:28 --> Loader Class Initialized
INFO - 2023-04-29 22:25:28 --> Helper loaded: url_helper
INFO - 2023-04-29 22:25:28 --> Helper loaded: form_helper
INFO - 2023-04-29 22:25:28 --> Helper loaded: file_helper
INFO - 2023-04-29 22:25:28 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:25:28 --> Form Validation Class Initialized
INFO - 2023-04-29 22:25:28 --> Upload Class Initialized
INFO - 2023-04-29 22:25:28 --> Model "M_auth" initialized
INFO - 2023-04-29 22:25:28 --> Model "M_user" initialized
INFO - 2023-04-29 22:25:28 --> Model "M_produk" initialized
INFO - 2023-04-29 22:25:28 --> Controller Class Initialized
INFO - 2023-04-29 22:25:28 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 22:25:28 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:25:28 --> Final output sent to browser
DEBUG - 2023-04-29 22:25:28 --> Total execution time: 0.1205
INFO - 2023-04-29 22:25:31 --> Config Class Initialized
INFO - 2023-04-29 22:25:31 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:25:31 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:25:31 --> Utf8 Class Initialized
INFO - 2023-04-29 22:25:31 --> URI Class Initialized
DEBUG - 2023-04-29 22:25:31 --> No URI present. Default controller set.
INFO - 2023-04-29 22:25:31 --> Router Class Initialized
INFO - 2023-04-29 22:25:31 --> Output Class Initialized
INFO - 2023-04-29 22:25:31 --> Security Class Initialized
DEBUG - 2023-04-29 22:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:25:31 --> Input Class Initialized
INFO - 2023-04-29 22:25:31 --> Language Class Initialized
INFO - 2023-04-29 22:25:31 --> Loader Class Initialized
INFO - 2023-04-29 22:25:31 --> Helper loaded: url_helper
INFO - 2023-04-29 22:25:31 --> Helper loaded: form_helper
INFO - 2023-04-29 22:25:31 --> Helper loaded: file_helper
INFO - 2023-04-29 22:25:31 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:25:31 --> Form Validation Class Initialized
INFO - 2023-04-29 22:25:31 --> Upload Class Initialized
INFO - 2023-04-29 22:25:31 --> Model "M_auth" initialized
INFO - 2023-04-29 22:25:31 --> Model "M_user" initialized
INFO - 2023-04-29 22:25:31 --> Model "M_produk" initialized
INFO - 2023-04-29 22:25:31 --> Controller Class Initialized
INFO - 2023-04-29 22:25:31 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:25:31 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:25:31 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:25:31 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:25:31 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:25:31 --> Model "M_bank" initialized
INFO - 2023-04-29 22:25:31 --> Model "M_pesan" initialized
INFO - 2023-04-29 22:25:31 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-29 22:25:31 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-04-29 22:25:31 --> Final output sent to browser
DEBUG - 2023-04-29 22:25:31 --> Total execution time: 0.1164
INFO - 2023-04-29 22:25:35 --> Config Class Initialized
INFO - 2023-04-29 22:25:35 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:25:35 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:25:35 --> Utf8 Class Initialized
INFO - 2023-04-29 22:25:35 --> URI Class Initialized
INFO - 2023-04-29 22:25:35 --> Router Class Initialized
INFO - 2023-04-29 22:25:35 --> Output Class Initialized
INFO - 2023-04-29 22:25:35 --> Security Class Initialized
DEBUG - 2023-04-29 22:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:25:35 --> Input Class Initialized
INFO - 2023-04-29 22:25:35 --> Language Class Initialized
INFO - 2023-04-29 22:25:35 --> Loader Class Initialized
INFO - 2023-04-29 22:25:35 --> Helper loaded: url_helper
INFO - 2023-04-29 22:25:35 --> Helper loaded: form_helper
INFO - 2023-04-29 22:25:35 --> Helper loaded: file_helper
INFO - 2023-04-29 22:25:35 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:25:35 --> Form Validation Class Initialized
INFO - 2023-04-29 22:25:35 --> Upload Class Initialized
INFO - 2023-04-29 22:25:35 --> Model "M_auth" initialized
INFO - 2023-04-29 22:25:35 --> Model "M_user" initialized
INFO - 2023-04-29 22:25:35 --> Model "M_produk" initialized
INFO - 2023-04-29 22:25:35 --> Controller Class Initialized
INFO - 2023-04-29 22:25:35 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:25:35 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:25:35 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:25:35 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:25:35 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:25:35 --> Model "M_bank" initialized
INFO - 2023-04-29 22:25:35 --> Model "M_pesan" initialized
INFO - 2023-04-29 22:25:35 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-29 22:25:35 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/v_produk_detail.php
INFO - 2023-04-29 22:25:35 --> Final output sent to browser
DEBUG - 2023-04-29 22:25:35 --> Total execution time: 0.1348
INFO - 2023-04-29 22:25:37 --> Config Class Initialized
INFO - 2023-04-29 22:25:37 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:25:37 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:25:37 --> Utf8 Class Initialized
INFO - 2023-04-29 22:25:37 --> URI Class Initialized
DEBUG - 2023-04-29 22:25:37 --> No URI present. Default controller set.
INFO - 2023-04-29 22:25:37 --> Router Class Initialized
INFO - 2023-04-29 22:25:37 --> Output Class Initialized
INFO - 2023-04-29 22:25:37 --> Security Class Initialized
DEBUG - 2023-04-29 22:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:25:37 --> Input Class Initialized
INFO - 2023-04-29 22:25:37 --> Language Class Initialized
INFO - 2023-04-29 22:25:37 --> Loader Class Initialized
INFO - 2023-04-29 22:25:37 --> Helper loaded: url_helper
INFO - 2023-04-29 22:25:37 --> Helper loaded: form_helper
INFO - 2023-04-29 22:25:37 --> Helper loaded: file_helper
INFO - 2023-04-29 22:25:37 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:25:37 --> Form Validation Class Initialized
INFO - 2023-04-29 22:25:37 --> Upload Class Initialized
INFO - 2023-04-29 22:25:37 --> Model "M_auth" initialized
INFO - 2023-04-29 22:25:37 --> Model "M_user" initialized
INFO - 2023-04-29 22:25:37 --> Model "M_produk" initialized
INFO - 2023-04-29 22:25:37 --> Controller Class Initialized
INFO - 2023-04-29 22:25:37 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:25:37 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:25:37 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:25:37 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:25:37 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:25:37 --> Model "M_bank" initialized
INFO - 2023-04-29 22:25:37 --> Model "M_pesan" initialized
INFO - 2023-04-29 22:25:37 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-29 22:25:37 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-04-29 22:25:37 --> Final output sent to browser
DEBUG - 2023-04-29 22:25:37 --> Total execution time: 0.1518
INFO - 2023-04-29 22:25:39 --> Config Class Initialized
INFO - 2023-04-29 22:25:39 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:25:39 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:25:39 --> Utf8 Class Initialized
INFO - 2023-04-29 22:25:39 --> URI Class Initialized
INFO - 2023-04-29 22:25:39 --> Router Class Initialized
INFO - 2023-04-29 22:25:39 --> Output Class Initialized
INFO - 2023-04-29 22:25:39 --> Security Class Initialized
DEBUG - 2023-04-29 22:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:25:39 --> Input Class Initialized
INFO - 2023-04-29 22:25:39 --> Language Class Initialized
INFO - 2023-04-29 22:25:39 --> Loader Class Initialized
INFO - 2023-04-29 22:25:39 --> Helper loaded: url_helper
INFO - 2023-04-29 22:25:39 --> Helper loaded: form_helper
INFO - 2023-04-29 22:25:39 --> Helper loaded: file_helper
INFO - 2023-04-29 22:25:39 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:25:39 --> Form Validation Class Initialized
INFO - 2023-04-29 22:25:39 --> Upload Class Initialized
INFO - 2023-04-29 22:25:39 --> Model "M_auth" initialized
INFO - 2023-04-29 22:25:39 --> Model "M_user" initialized
INFO - 2023-04-29 22:25:39 --> Model "M_produk" initialized
INFO - 2023-04-29 22:25:39 --> Controller Class Initialized
INFO - 2023-04-29 22:25:39 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-04-29 22:25:39 --> Final output sent to browser
DEBUG - 2023-04-29 22:25:39 --> Total execution time: 0.1284
INFO - 2023-04-29 22:25:47 --> Config Class Initialized
INFO - 2023-04-29 22:25:47 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:25:47 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:25:47 --> Utf8 Class Initialized
INFO - 2023-04-29 22:25:47 --> URI Class Initialized
INFO - 2023-04-29 22:25:47 --> Router Class Initialized
INFO - 2023-04-29 22:25:47 --> Output Class Initialized
INFO - 2023-04-29 22:25:47 --> Security Class Initialized
DEBUG - 2023-04-29 22:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:25:47 --> Input Class Initialized
INFO - 2023-04-29 22:25:47 --> Language Class Initialized
INFO - 2023-04-29 22:25:47 --> Loader Class Initialized
INFO - 2023-04-29 22:25:47 --> Helper loaded: url_helper
INFO - 2023-04-29 22:25:47 --> Helper loaded: form_helper
INFO - 2023-04-29 22:25:47 --> Helper loaded: file_helper
INFO - 2023-04-29 22:25:47 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:25:47 --> Form Validation Class Initialized
INFO - 2023-04-29 22:25:47 --> Upload Class Initialized
INFO - 2023-04-29 22:25:47 --> Model "M_auth" initialized
INFO - 2023-04-29 22:25:47 --> Model "M_user" initialized
INFO - 2023-04-29 22:25:47 --> Model "M_produk" initialized
INFO - 2023-04-29 22:25:47 --> Controller Class Initialized
INFO - 2023-04-29 22:25:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-04-29 22:25:47 --> Config Class Initialized
INFO - 2023-04-29 22:25:47 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:25:47 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:25:47 --> Utf8 Class Initialized
INFO - 2023-04-29 22:25:47 --> URI Class Initialized
INFO - 2023-04-29 22:25:47 --> Router Class Initialized
INFO - 2023-04-29 22:25:47 --> Output Class Initialized
INFO - 2023-04-29 22:25:47 --> Security Class Initialized
DEBUG - 2023-04-29 22:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:25:47 --> Input Class Initialized
INFO - 2023-04-29 22:25:47 --> Language Class Initialized
INFO - 2023-04-29 22:25:47 --> Loader Class Initialized
INFO - 2023-04-29 22:25:47 --> Helper loaded: url_helper
INFO - 2023-04-29 22:25:47 --> Helper loaded: form_helper
INFO - 2023-04-29 22:25:47 --> Helper loaded: file_helper
INFO - 2023-04-29 22:25:47 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:25:47 --> Form Validation Class Initialized
INFO - 2023-04-29 22:25:47 --> Upload Class Initialized
INFO - 2023-04-29 22:25:47 --> Model "M_auth" initialized
INFO - 2023-04-29 22:25:47 --> Model "M_user" initialized
INFO - 2023-04-29 22:25:47 --> Model "M_produk" initialized
INFO - 2023-04-29 22:25:47 --> Controller Class Initialized
INFO - 2023-04-29 22:25:47 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 22:25:47 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:25:47 --> Final output sent to browser
DEBUG - 2023-04-29 22:25:47 --> Total execution time: 0.1036
INFO - 2023-04-29 22:25:50 --> Config Class Initialized
INFO - 2023-04-29 22:25:50 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:25:50 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:25:50 --> Utf8 Class Initialized
INFO - 2023-04-29 22:25:50 --> URI Class Initialized
INFO - 2023-04-29 22:25:50 --> Router Class Initialized
INFO - 2023-04-29 22:25:50 --> Output Class Initialized
INFO - 2023-04-29 22:25:50 --> Security Class Initialized
DEBUG - 2023-04-29 22:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:25:50 --> Input Class Initialized
INFO - 2023-04-29 22:25:50 --> Language Class Initialized
INFO - 2023-04-29 22:25:50 --> Loader Class Initialized
INFO - 2023-04-29 22:25:50 --> Helper loaded: url_helper
INFO - 2023-04-29 22:25:50 --> Helper loaded: form_helper
INFO - 2023-04-29 22:25:50 --> Helper loaded: file_helper
INFO - 2023-04-29 22:25:50 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:25:50 --> Form Validation Class Initialized
INFO - 2023-04-29 22:25:50 --> Upload Class Initialized
INFO - 2023-04-29 22:25:50 --> Model "M_auth" initialized
INFO - 2023-04-29 22:25:50 --> Model "M_user" initialized
INFO - 2023-04-29 22:25:50 --> Model "M_produk" initialized
INFO - 2023-04-29 22:25:50 --> Controller Class Initialized
INFO - 2023-04-29 22:25:50 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:25:50 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:25:50 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:25:50 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:25:50 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:25:50 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_transaksi_all.php
INFO - 2023-04-29 22:25:50 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:25:50 --> Final output sent to browser
DEBUG - 2023-04-29 22:25:50 --> Total execution time: 0.2161
INFO - 2023-04-29 22:25:53 --> Config Class Initialized
INFO - 2023-04-29 22:25:53 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:25:53 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:25:53 --> Utf8 Class Initialized
INFO - 2023-04-29 22:25:53 --> URI Class Initialized
INFO - 2023-04-29 22:25:53 --> Router Class Initialized
INFO - 2023-04-29 22:25:53 --> Output Class Initialized
INFO - 2023-04-29 22:25:53 --> Security Class Initialized
DEBUG - 2023-04-29 22:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:25:53 --> Input Class Initialized
INFO - 2023-04-29 22:25:53 --> Language Class Initialized
INFO - 2023-04-29 22:25:53 --> Loader Class Initialized
INFO - 2023-04-29 22:25:53 --> Helper loaded: url_helper
INFO - 2023-04-29 22:25:53 --> Helper loaded: form_helper
INFO - 2023-04-29 22:25:53 --> Helper loaded: file_helper
INFO - 2023-04-29 22:25:53 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:25:53 --> Form Validation Class Initialized
INFO - 2023-04-29 22:25:53 --> Upload Class Initialized
INFO - 2023-04-29 22:25:53 --> Model "M_auth" initialized
INFO - 2023-04-29 22:25:53 --> Model "M_user" initialized
INFO - 2023-04-29 22:25:53 --> Model "M_produk" initialized
INFO - 2023-04-29 22:25:53 --> Controller Class Initialized
INFO - 2023-04-29 22:25:53 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:25:53 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:25:53 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:25:53 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:25:53 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:25:53 --> Model "M_bank" initialized
INFO - 2023-04-29 22:25:53 --> Model "M_pesan" initialized
ERROR - 2023-04-29 22:25:53 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 22:25:53 --> Config Class Initialized
INFO - 2023-04-29 22:25:53 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:25:53 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:25:53 --> Utf8 Class Initialized
INFO - 2023-04-29 22:25:53 --> URI Class Initialized
INFO - 2023-04-29 22:25:53 --> Router Class Initialized
INFO - 2023-04-29 22:25:53 --> Output Class Initialized
INFO - 2023-04-29 22:25:53 --> Security Class Initialized
DEBUG - 2023-04-29 22:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:25:53 --> Input Class Initialized
INFO - 2023-04-29 22:25:53 --> Language Class Initialized
ERROR - 2023-04-29 22:25:53 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 22:25:55 --> Config Class Initialized
INFO - 2023-04-29 22:25:55 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:25:55 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:25:55 --> Utf8 Class Initialized
INFO - 2023-04-29 22:25:55 --> URI Class Initialized
INFO - 2023-04-29 22:25:55 --> Router Class Initialized
INFO - 2023-04-29 22:25:55 --> Output Class Initialized
INFO - 2023-04-29 22:25:55 --> Security Class Initialized
DEBUG - 2023-04-29 22:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:25:55 --> Input Class Initialized
INFO - 2023-04-29 22:25:55 --> Language Class Initialized
INFO - 2023-04-29 22:25:55 --> Loader Class Initialized
INFO - 2023-04-29 22:25:55 --> Helper loaded: url_helper
INFO - 2023-04-29 22:25:55 --> Helper loaded: form_helper
INFO - 2023-04-29 22:25:55 --> Helper loaded: file_helper
INFO - 2023-04-29 22:25:55 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:25:55 --> Form Validation Class Initialized
INFO - 2023-04-29 22:25:55 --> Upload Class Initialized
INFO - 2023-04-29 22:25:55 --> Model "M_auth" initialized
INFO - 2023-04-29 22:25:55 --> Model "M_user" initialized
INFO - 2023-04-29 22:25:55 --> Model "M_produk" initialized
INFO - 2023-04-29 22:25:55 --> Controller Class Initialized
INFO - 2023-04-29 22:25:55 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:25:55 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:25:55 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:25:55 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:25:55 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:25:55 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_transaksi_all.php
INFO - 2023-04-29 22:25:55 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:25:55 --> Final output sent to browser
DEBUG - 2023-04-29 22:25:55 --> Total execution time: 0.1130
INFO - 2023-04-29 22:25:57 --> Config Class Initialized
INFO - 2023-04-29 22:25:57 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:25:57 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:25:57 --> Utf8 Class Initialized
INFO - 2023-04-29 22:25:57 --> URI Class Initialized
INFO - 2023-04-29 22:25:57 --> Router Class Initialized
INFO - 2023-04-29 22:25:57 --> Output Class Initialized
INFO - 2023-04-29 22:25:57 --> Security Class Initialized
DEBUG - 2023-04-29 22:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:25:57 --> Input Class Initialized
INFO - 2023-04-29 22:25:57 --> Language Class Initialized
INFO - 2023-04-29 22:25:57 --> Loader Class Initialized
INFO - 2023-04-29 22:25:57 --> Helper loaded: url_helper
INFO - 2023-04-29 22:25:57 --> Helper loaded: form_helper
INFO - 2023-04-29 22:25:57 --> Helper loaded: file_helper
INFO - 2023-04-29 22:25:57 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:25:57 --> Form Validation Class Initialized
INFO - 2023-04-29 22:25:57 --> Upload Class Initialized
INFO - 2023-04-29 22:25:57 --> Model "M_auth" initialized
INFO - 2023-04-29 22:25:57 --> Model "M_user" initialized
INFO - 2023-04-29 22:25:57 --> Model "M_produk" initialized
INFO - 2023-04-29 22:25:57 --> Controller Class Initialized
INFO - 2023-04-29 22:25:57 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:25:57 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:25:57 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:25:57 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:25:57 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:25:57 --> Model "M_bank" initialized
INFO - 2023-04-29 22:25:57 --> Model "M_pesan" initialized
ERROR - 2023-04-29 22:25:57 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 22:25:57 --> Config Class Initialized
INFO - 2023-04-29 22:25:57 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:25:57 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:25:57 --> Utf8 Class Initialized
INFO - 2023-04-29 22:25:57 --> URI Class Initialized
INFO - 2023-04-29 22:25:57 --> Router Class Initialized
INFO - 2023-04-29 22:25:57 --> Output Class Initialized
INFO - 2023-04-29 22:25:57 --> Security Class Initialized
DEBUG - 2023-04-29 22:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:25:58 --> Input Class Initialized
INFO - 2023-04-29 22:25:58 --> Language Class Initialized
ERROR - 2023-04-29 22:25:58 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 22:25:59 --> Config Class Initialized
INFO - 2023-04-29 22:25:59 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:25:59 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:25:59 --> Utf8 Class Initialized
INFO - 2023-04-29 22:25:59 --> URI Class Initialized
INFO - 2023-04-29 22:25:59 --> Router Class Initialized
INFO - 2023-04-29 22:25:59 --> Output Class Initialized
INFO - 2023-04-29 22:25:59 --> Security Class Initialized
DEBUG - 2023-04-29 22:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:25:59 --> Input Class Initialized
INFO - 2023-04-29 22:25:59 --> Language Class Initialized
INFO - 2023-04-29 22:25:59 --> Loader Class Initialized
INFO - 2023-04-29 22:25:59 --> Helper loaded: url_helper
INFO - 2023-04-29 22:25:59 --> Helper loaded: form_helper
INFO - 2023-04-29 22:25:59 --> Helper loaded: file_helper
INFO - 2023-04-29 22:25:59 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:25:59 --> Form Validation Class Initialized
INFO - 2023-04-29 22:25:59 --> Upload Class Initialized
INFO - 2023-04-29 22:25:59 --> Model "M_auth" initialized
INFO - 2023-04-29 22:25:59 --> Model "M_user" initialized
INFO - 2023-04-29 22:25:59 --> Model "M_produk" initialized
INFO - 2023-04-29 22:25:59 --> Controller Class Initialized
INFO - 2023-04-29 22:25:59 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:25:59 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:25:59 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:25:59 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:25:59 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:25:59 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_transaksi_all.php
INFO - 2023-04-29 22:25:59 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:25:59 --> Final output sent to browser
DEBUG - 2023-04-29 22:25:59 --> Total execution time: 0.1388
INFO - 2023-04-29 22:26:02 --> Config Class Initialized
INFO - 2023-04-29 22:26:02 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:26:02 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:26:02 --> Utf8 Class Initialized
INFO - 2023-04-29 22:26:02 --> URI Class Initialized
INFO - 2023-04-29 22:26:02 --> Router Class Initialized
INFO - 2023-04-29 22:26:02 --> Output Class Initialized
INFO - 2023-04-29 22:26:02 --> Security Class Initialized
DEBUG - 2023-04-29 22:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:26:02 --> Input Class Initialized
INFO - 2023-04-29 22:26:02 --> Language Class Initialized
INFO - 2023-04-29 22:26:02 --> Loader Class Initialized
INFO - 2023-04-29 22:26:02 --> Helper loaded: url_helper
INFO - 2023-04-29 22:26:02 --> Helper loaded: form_helper
INFO - 2023-04-29 22:26:02 --> Helper loaded: file_helper
INFO - 2023-04-29 22:26:02 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:26:02 --> Form Validation Class Initialized
INFO - 2023-04-29 22:26:02 --> Upload Class Initialized
INFO - 2023-04-29 22:26:02 --> Model "M_auth" initialized
INFO - 2023-04-29 22:26:02 --> Model "M_user" initialized
INFO - 2023-04-29 22:26:02 --> Model "M_produk" initialized
INFO - 2023-04-29 22:26:02 --> Controller Class Initialized
INFO - 2023-04-29 22:26:02 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:26:02 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:26:02 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:26:02 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:26:02 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:26:02 --> Model "M_bank" initialized
INFO - 2023-04-29 22:26:02 --> Model "M_pesan" initialized
ERROR - 2023-04-29 22:26:02 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 22:26:02 --> Config Class Initialized
INFO - 2023-04-29 22:26:02 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:26:02 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:26:02 --> Utf8 Class Initialized
INFO - 2023-04-29 22:26:02 --> URI Class Initialized
INFO - 2023-04-29 22:26:02 --> Router Class Initialized
INFO - 2023-04-29 22:26:02 --> Output Class Initialized
INFO - 2023-04-29 22:26:02 --> Security Class Initialized
DEBUG - 2023-04-29 22:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:26:02 --> Input Class Initialized
INFO - 2023-04-29 22:26:02 --> Language Class Initialized
ERROR - 2023-04-29 22:26:02 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 22:26:04 --> Config Class Initialized
INFO - 2023-04-29 22:26:04 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:26:04 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:26:04 --> Utf8 Class Initialized
INFO - 2023-04-29 22:26:04 --> URI Class Initialized
INFO - 2023-04-29 22:26:04 --> Router Class Initialized
INFO - 2023-04-29 22:26:04 --> Output Class Initialized
INFO - 2023-04-29 22:26:04 --> Security Class Initialized
DEBUG - 2023-04-29 22:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:26:04 --> Input Class Initialized
INFO - 2023-04-29 22:26:04 --> Language Class Initialized
INFO - 2023-04-29 22:26:04 --> Loader Class Initialized
INFO - 2023-04-29 22:26:04 --> Helper loaded: url_helper
INFO - 2023-04-29 22:26:04 --> Helper loaded: form_helper
INFO - 2023-04-29 22:26:04 --> Helper loaded: file_helper
INFO - 2023-04-29 22:26:04 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:26:04 --> Form Validation Class Initialized
INFO - 2023-04-29 22:26:04 --> Upload Class Initialized
INFO - 2023-04-29 22:26:04 --> Model "M_auth" initialized
INFO - 2023-04-29 22:26:04 --> Model "M_user" initialized
INFO - 2023-04-29 22:26:04 --> Model "M_produk" initialized
INFO - 2023-04-29 22:26:04 --> Controller Class Initialized
INFO - 2023-04-29 22:26:04 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:26:04 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:26:04 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:26:04 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:26:04 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:26:04 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_transaksi_all.php
INFO - 2023-04-29 22:26:04 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:26:04 --> Final output sent to browser
DEBUG - 2023-04-29 22:26:04 --> Total execution time: 0.1065
INFO - 2023-04-29 22:26:07 --> Config Class Initialized
INFO - 2023-04-29 22:26:07 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:26:07 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:26:07 --> Utf8 Class Initialized
INFO - 2023-04-29 22:26:07 --> URI Class Initialized
INFO - 2023-04-29 22:26:07 --> Router Class Initialized
INFO - 2023-04-29 22:26:07 --> Output Class Initialized
INFO - 2023-04-29 22:26:07 --> Security Class Initialized
DEBUG - 2023-04-29 22:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:26:07 --> Input Class Initialized
INFO - 2023-04-29 22:26:07 --> Language Class Initialized
INFO - 2023-04-29 22:26:07 --> Loader Class Initialized
INFO - 2023-04-29 22:26:07 --> Helper loaded: url_helper
INFO - 2023-04-29 22:26:07 --> Helper loaded: form_helper
INFO - 2023-04-29 22:26:07 --> Helper loaded: file_helper
INFO - 2023-04-29 22:26:07 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:26:07 --> Form Validation Class Initialized
INFO - 2023-04-29 22:26:07 --> Upload Class Initialized
INFO - 2023-04-29 22:26:07 --> Model "M_auth" initialized
INFO - 2023-04-29 22:26:07 --> Model "M_user" initialized
INFO - 2023-04-29 22:26:07 --> Model "M_produk" initialized
INFO - 2023-04-29 22:26:07 --> Controller Class Initialized
INFO - 2023-04-29 22:26:07 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:26:07 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:26:07 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:26:07 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:26:07 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:26:07 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_transaksi_all.php
INFO - 2023-04-29 22:26:07 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:26:07 --> Final output sent to browser
DEBUG - 2023-04-29 22:26:07 --> Total execution time: 0.1055
INFO - 2023-04-29 22:26:11 --> Config Class Initialized
INFO - 2023-04-29 22:26:11 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:26:11 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:26:11 --> Utf8 Class Initialized
INFO - 2023-04-29 22:26:11 --> URI Class Initialized
INFO - 2023-04-29 22:26:11 --> Router Class Initialized
INFO - 2023-04-29 22:26:11 --> Output Class Initialized
INFO - 2023-04-29 22:26:11 --> Security Class Initialized
DEBUG - 2023-04-29 22:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:26:11 --> Input Class Initialized
INFO - 2023-04-29 22:26:11 --> Language Class Initialized
INFO - 2023-04-29 22:26:11 --> Loader Class Initialized
INFO - 2023-04-29 22:26:11 --> Helper loaded: url_helper
INFO - 2023-04-29 22:26:11 --> Helper loaded: form_helper
INFO - 2023-04-29 22:26:11 --> Helper loaded: file_helper
INFO - 2023-04-29 22:26:11 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:26:11 --> Form Validation Class Initialized
INFO - 2023-04-29 22:26:11 --> Upload Class Initialized
INFO - 2023-04-29 22:26:11 --> Model "M_auth" initialized
INFO - 2023-04-29 22:26:11 --> Model "M_user" initialized
INFO - 2023-04-29 22:26:11 --> Model "M_produk" initialized
INFO - 2023-04-29 22:26:11 --> Controller Class Initialized
INFO - 2023-04-29 22:26:11 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:26:11 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:26:11 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:26:11 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:26:11 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:26:11 --> Model "M_bank" initialized
INFO - 2023-04-29 22:26:11 --> Model "M_pesan" initialized
ERROR - 2023-04-29 22:26:11 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 22:26:11 --> Config Class Initialized
INFO - 2023-04-29 22:26:11 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:26:11 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:26:11 --> Utf8 Class Initialized
INFO - 2023-04-29 22:26:11 --> URI Class Initialized
INFO - 2023-04-29 22:26:11 --> Router Class Initialized
INFO - 2023-04-29 22:26:11 --> Output Class Initialized
INFO - 2023-04-29 22:26:11 --> Security Class Initialized
DEBUG - 2023-04-29 22:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:26:11 --> Input Class Initialized
INFO - 2023-04-29 22:26:11 --> Language Class Initialized
ERROR - 2023-04-29 22:26:11 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 22:26:12 --> Config Class Initialized
INFO - 2023-04-29 22:26:12 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:26:12 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:26:12 --> Utf8 Class Initialized
INFO - 2023-04-29 22:26:12 --> URI Class Initialized
INFO - 2023-04-29 22:26:12 --> Router Class Initialized
INFO - 2023-04-29 22:26:12 --> Output Class Initialized
INFO - 2023-04-29 22:26:12 --> Security Class Initialized
DEBUG - 2023-04-29 22:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:26:13 --> Input Class Initialized
INFO - 2023-04-29 22:26:13 --> Language Class Initialized
INFO - 2023-04-29 22:26:13 --> Loader Class Initialized
INFO - 2023-04-29 22:26:13 --> Helper loaded: url_helper
INFO - 2023-04-29 22:26:13 --> Helper loaded: form_helper
INFO - 2023-04-29 22:26:13 --> Helper loaded: file_helper
INFO - 2023-04-29 22:26:13 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:26:13 --> Form Validation Class Initialized
INFO - 2023-04-29 22:26:13 --> Upload Class Initialized
INFO - 2023-04-29 22:26:13 --> Model "M_auth" initialized
INFO - 2023-04-29 22:26:13 --> Model "M_user" initialized
INFO - 2023-04-29 22:26:13 --> Model "M_produk" initialized
INFO - 2023-04-29 22:26:13 --> Controller Class Initialized
INFO - 2023-04-29 22:26:13 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:26:13 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:26:13 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:26:13 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:26:13 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:26:13 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_transaksi_all.php
INFO - 2023-04-29 22:26:13 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:26:13 --> Final output sent to browser
DEBUG - 2023-04-29 22:26:13 --> Total execution time: 0.1237
INFO - 2023-04-29 22:27:31 --> Config Class Initialized
INFO - 2023-04-29 22:27:31 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:27:31 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:27:31 --> Utf8 Class Initialized
INFO - 2023-04-29 22:27:31 --> URI Class Initialized
INFO - 2023-04-29 22:27:32 --> Router Class Initialized
INFO - 2023-04-29 22:27:32 --> Output Class Initialized
INFO - 2023-04-29 22:27:32 --> Security Class Initialized
DEBUG - 2023-04-29 22:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:27:32 --> Input Class Initialized
INFO - 2023-04-29 22:27:32 --> Language Class Initialized
INFO - 2023-04-29 22:27:32 --> Loader Class Initialized
INFO - 2023-04-29 22:27:32 --> Helper loaded: url_helper
INFO - 2023-04-29 22:27:32 --> Helper loaded: form_helper
INFO - 2023-04-29 22:27:32 --> Helper loaded: file_helper
INFO - 2023-04-29 22:27:32 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:27:32 --> Form Validation Class Initialized
INFO - 2023-04-29 22:27:32 --> Upload Class Initialized
INFO - 2023-04-29 22:27:32 --> Model "M_auth" initialized
INFO - 2023-04-29 22:27:32 --> Model "M_user" initialized
INFO - 2023-04-29 22:27:32 --> Model "M_produk" initialized
INFO - 2023-04-29 22:27:32 --> Controller Class Initialized
INFO - 2023-04-29 22:27:32 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:27:32 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:27:32 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:27:32 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:27:32 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:27:32 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_transaksi_all.php
INFO - 2023-04-29 22:27:32 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:27:32 --> Final output sent to browser
DEBUG - 2023-04-29 22:27:32 --> Total execution time: 0.1152
INFO - 2023-04-29 22:27:34 --> Config Class Initialized
INFO - 2023-04-29 22:27:34 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:27:34 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:27:34 --> Utf8 Class Initialized
INFO - 2023-04-29 22:27:34 --> URI Class Initialized
INFO - 2023-04-29 22:27:34 --> Router Class Initialized
INFO - 2023-04-29 22:27:34 --> Output Class Initialized
INFO - 2023-04-29 22:27:34 --> Security Class Initialized
DEBUG - 2023-04-29 22:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:27:34 --> Input Class Initialized
INFO - 2023-04-29 22:27:34 --> Language Class Initialized
INFO - 2023-04-29 22:27:34 --> Loader Class Initialized
INFO - 2023-04-29 22:27:34 --> Helper loaded: url_helper
INFO - 2023-04-29 22:27:34 --> Helper loaded: form_helper
INFO - 2023-04-29 22:27:34 --> Helper loaded: file_helper
INFO - 2023-04-29 22:27:34 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:27:34 --> Form Validation Class Initialized
INFO - 2023-04-29 22:27:34 --> Upload Class Initialized
INFO - 2023-04-29 22:27:35 --> Model "M_auth" initialized
INFO - 2023-04-29 22:27:35 --> Model "M_user" initialized
INFO - 2023-04-29 22:27:35 --> Model "M_produk" initialized
INFO - 2023-04-29 22:27:35 --> Controller Class Initialized
INFO - 2023-04-29 22:27:35 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 22:27:35 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:27:35 --> Final output sent to browser
DEBUG - 2023-04-29 22:27:35 --> Total execution time: 0.0967
INFO - 2023-04-29 22:27:37 --> Config Class Initialized
INFO - 2023-04-29 22:27:37 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:27:37 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:27:37 --> Utf8 Class Initialized
INFO - 2023-04-29 22:27:37 --> URI Class Initialized
INFO - 2023-04-29 22:27:37 --> Router Class Initialized
INFO - 2023-04-29 22:27:37 --> Output Class Initialized
INFO - 2023-04-29 22:27:37 --> Security Class Initialized
DEBUG - 2023-04-29 22:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:27:37 --> Input Class Initialized
INFO - 2023-04-29 22:27:37 --> Language Class Initialized
INFO - 2023-04-29 22:27:37 --> Loader Class Initialized
INFO - 2023-04-29 22:27:37 --> Helper loaded: url_helper
INFO - 2023-04-29 22:27:37 --> Helper loaded: form_helper
INFO - 2023-04-29 22:27:37 --> Helper loaded: file_helper
INFO - 2023-04-29 22:27:37 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:27:37 --> Form Validation Class Initialized
INFO - 2023-04-29 22:27:37 --> Upload Class Initialized
INFO - 2023-04-29 22:27:37 --> Model "M_auth" initialized
INFO - 2023-04-29 22:27:37 --> Model "M_user" initialized
INFO - 2023-04-29 22:27:37 --> Model "M_produk" initialized
INFO - 2023-04-29 22:27:37 --> Controller Class Initialized
INFO - 2023-04-29 22:27:37 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:27:37 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:27:37 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:27:37 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:27:37 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:27:37 --> Model "M_bank" initialized
INFO - 2023-04-29 22:27:37 --> Model "M_pesan" initialized
ERROR - 2023-04-29 22:27:37 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 22:27:37 --> Config Class Initialized
INFO - 2023-04-29 22:27:37 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:27:37 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:27:37 --> Utf8 Class Initialized
INFO - 2023-04-29 22:27:37 --> URI Class Initialized
INFO - 2023-04-29 22:27:37 --> Router Class Initialized
INFO - 2023-04-29 22:27:37 --> Output Class Initialized
INFO - 2023-04-29 22:27:37 --> Security Class Initialized
DEBUG - 2023-04-29 22:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:27:37 --> Input Class Initialized
INFO - 2023-04-29 22:27:37 --> Language Class Initialized
ERROR - 2023-04-29 22:27:37 --> 404 Page Not Found: 404_override/index
INFO - 2023-04-29 22:27:38 --> Config Class Initialized
INFO - 2023-04-29 22:27:38 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:27:38 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:27:38 --> Utf8 Class Initialized
INFO - 2023-04-29 22:27:38 --> URI Class Initialized
INFO - 2023-04-29 22:27:38 --> Router Class Initialized
INFO - 2023-04-29 22:27:38 --> Output Class Initialized
INFO - 2023-04-29 22:27:38 --> Security Class Initialized
DEBUG - 2023-04-29 22:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:27:38 --> Input Class Initialized
INFO - 2023-04-29 22:27:38 --> Language Class Initialized
INFO - 2023-04-29 22:27:38 --> Loader Class Initialized
INFO - 2023-04-29 22:27:38 --> Helper loaded: url_helper
INFO - 2023-04-29 22:27:38 --> Helper loaded: form_helper
INFO - 2023-04-29 22:27:38 --> Helper loaded: file_helper
INFO - 2023-04-29 22:27:38 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:27:38 --> Form Validation Class Initialized
INFO - 2023-04-29 22:27:38 --> Upload Class Initialized
INFO - 2023-04-29 22:27:38 --> Model "M_auth" initialized
INFO - 2023-04-29 22:27:38 --> Model "M_user" initialized
INFO - 2023-04-29 22:27:38 --> Model "M_produk" initialized
INFO - 2023-04-29 22:27:38 --> Controller Class Initialized
INFO - 2023-04-29 22:27:38 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 22:27:38 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:27:38 --> Final output sent to browser
DEBUG - 2023-04-29 22:27:38 --> Total execution time: 0.1166
INFO - 2023-04-29 22:27:52 --> Config Class Initialized
INFO - 2023-04-29 22:27:52 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:27:52 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:27:52 --> Utf8 Class Initialized
INFO - 2023-04-29 22:27:52 --> URI Class Initialized
INFO - 2023-04-29 22:27:52 --> Router Class Initialized
INFO - 2023-04-29 22:27:52 --> Output Class Initialized
INFO - 2023-04-29 22:27:52 --> Security Class Initialized
DEBUG - 2023-04-29 22:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:27:52 --> Input Class Initialized
INFO - 2023-04-29 22:27:52 --> Language Class Initialized
INFO - 2023-04-29 22:27:52 --> Loader Class Initialized
INFO - 2023-04-29 22:27:52 --> Helper loaded: url_helper
INFO - 2023-04-29 22:27:52 --> Helper loaded: form_helper
INFO - 2023-04-29 22:27:52 --> Helper loaded: file_helper
INFO - 2023-04-29 22:27:52 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:27:52 --> Form Validation Class Initialized
INFO - 2023-04-29 22:27:52 --> Upload Class Initialized
INFO - 2023-04-29 22:27:52 --> Model "M_auth" initialized
INFO - 2023-04-29 22:27:53 --> Model "M_user" initialized
INFO - 2023-04-29 22:27:53 --> Model "M_produk" initialized
INFO - 2023-04-29 22:27:53 --> Controller Class Initialized
INFO - 2023-04-29 22:27:53 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 22:27:53 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:27:53 --> Final output sent to browser
DEBUG - 2023-04-29 22:27:53 --> Total execution time: 0.1064
INFO - 2023-04-29 22:27:54 --> Config Class Initialized
INFO - 2023-04-29 22:27:54 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:27:54 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:27:54 --> Utf8 Class Initialized
INFO - 2023-04-29 22:27:54 --> URI Class Initialized
INFO - 2023-04-29 22:27:54 --> Router Class Initialized
INFO - 2023-04-29 22:27:54 --> Output Class Initialized
INFO - 2023-04-29 22:27:54 --> Security Class Initialized
DEBUG - 2023-04-29 22:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:27:54 --> Input Class Initialized
INFO - 2023-04-29 22:27:54 --> Language Class Initialized
INFO - 2023-04-29 22:27:54 --> Loader Class Initialized
INFO - 2023-04-29 22:27:54 --> Helper loaded: url_helper
INFO - 2023-04-29 22:27:54 --> Helper loaded: form_helper
INFO - 2023-04-29 22:27:54 --> Helper loaded: file_helper
INFO - 2023-04-29 22:27:54 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:27:54 --> Form Validation Class Initialized
INFO - 2023-04-29 22:27:54 --> Upload Class Initialized
INFO - 2023-04-29 22:27:54 --> Model "M_auth" initialized
INFO - 2023-04-29 22:27:54 --> Model "M_user" initialized
INFO - 2023-04-29 22:27:54 --> Model "M_produk" initialized
INFO - 2023-04-29 22:27:54 --> Controller Class Initialized
INFO - 2023-04-29 22:27:54 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:27:54 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:27:54 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:27:54 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:27:54 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:27:54 --> Model "M_bank" initialized
INFO - 2023-04-29 22:27:54 --> Model "M_pesan" initialized
ERROR - 2023-04-29 22:27:54 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 22:27:54 --> Config Class Initialized
INFO - 2023-04-29 22:27:54 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:27:54 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:27:54 --> Utf8 Class Initialized
INFO - 2023-04-29 22:27:54 --> URI Class Initialized
INFO - 2023-04-29 22:27:54 --> Router Class Initialized
INFO - 2023-04-29 22:27:54 --> Output Class Initialized
INFO - 2023-04-29 22:27:54 --> Security Class Initialized
DEBUG - 2023-04-29 22:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:27:54 --> Input Class Initialized
INFO - 2023-04-29 22:27:54 --> Language Class Initialized
INFO - 2023-04-29 22:27:54 --> Loader Class Initialized
INFO - 2023-04-29 22:27:54 --> Helper loaded: url_helper
INFO - 2023-04-29 22:27:54 --> Helper loaded: form_helper
INFO - 2023-04-29 22:27:54 --> Helper loaded: file_helper
INFO - 2023-04-29 22:27:54 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:27:54 --> Form Validation Class Initialized
INFO - 2023-04-29 22:27:54 --> Upload Class Initialized
INFO - 2023-04-29 22:27:54 --> Model "M_auth" initialized
INFO - 2023-04-29 22:27:54 --> Model "M_user" initialized
INFO - 2023-04-29 22:27:54 --> Model "M_produk" initialized
INFO - 2023-04-29 22:27:54 --> Controller Class Initialized
INFO - 2023-04-29 22:27:54 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-04-29 22:27:54 --> Final output sent to browser
DEBUG - 2023-04-29 22:27:54 --> Total execution time: 0.1620
INFO - 2023-04-29 22:27:57 --> Config Class Initialized
INFO - 2023-04-29 22:27:57 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:27:57 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:27:57 --> Utf8 Class Initialized
INFO - 2023-04-29 22:27:57 --> URI Class Initialized
DEBUG - 2023-04-29 22:27:57 --> No URI present. Default controller set.
INFO - 2023-04-29 22:27:57 --> Router Class Initialized
INFO - 2023-04-29 22:27:57 --> Output Class Initialized
INFO - 2023-04-29 22:27:57 --> Security Class Initialized
DEBUG - 2023-04-29 22:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:27:57 --> Input Class Initialized
INFO - 2023-04-29 22:27:57 --> Language Class Initialized
INFO - 2023-04-29 22:27:57 --> Loader Class Initialized
INFO - 2023-04-29 22:27:57 --> Helper loaded: url_helper
INFO - 2023-04-29 22:27:57 --> Helper loaded: form_helper
INFO - 2023-04-29 22:27:57 --> Helper loaded: file_helper
INFO - 2023-04-29 22:27:57 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:27:57 --> Form Validation Class Initialized
INFO - 2023-04-29 22:27:57 --> Upload Class Initialized
INFO - 2023-04-29 22:27:57 --> Model "M_auth" initialized
INFO - 2023-04-29 22:27:57 --> Model "M_user" initialized
INFO - 2023-04-29 22:27:57 --> Model "M_produk" initialized
INFO - 2023-04-29 22:27:57 --> Controller Class Initialized
INFO - 2023-04-29 22:27:57 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:27:57 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:27:57 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:27:57 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:27:57 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:27:57 --> Model "M_bank" initialized
INFO - 2023-04-29 22:27:57 --> Model "M_pesan" initialized
INFO - 2023-04-29 22:27:57 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-29 22:27:57 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-04-29 22:27:57 --> Final output sent to browser
DEBUG - 2023-04-29 22:27:57 --> Total execution time: 0.1452
INFO - 2023-04-29 22:27:59 --> Config Class Initialized
INFO - 2023-04-29 22:27:59 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:27:59 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:27:59 --> Utf8 Class Initialized
INFO - 2023-04-29 22:27:59 --> URI Class Initialized
INFO - 2023-04-29 22:27:59 --> Router Class Initialized
INFO - 2023-04-29 22:27:59 --> Output Class Initialized
INFO - 2023-04-29 22:27:59 --> Security Class Initialized
DEBUG - 2023-04-29 22:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:27:59 --> Input Class Initialized
INFO - 2023-04-29 22:27:59 --> Language Class Initialized
INFO - 2023-04-29 22:27:59 --> Loader Class Initialized
INFO - 2023-04-29 22:27:59 --> Helper loaded: url_helper
INFO - 2023-04-29 22:27:59 --> Helper loaded: form_helper
INFO - 2023-04-29 22:27:59 --> Helper loaded: file_helper
INFO - 2023-04-29 22:27:59 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:27:59 --> Form Validation Class Initialized
INFO - 2023-04-29 22:27:59 --> Upload Class Initialized
INFO - 2023-04-29 22:27:59 --> Model "M_auth" initialized
INFO - 2023-04-29 22:27:59 --> Model "M_user" initialized
INFO - 2023-04-29 22:27:59 --> Model "M_produk" initialized
INFO - 2023-04-29 22:27:59 --> Controller Class Initialized
INFO - 2023-04-29 22:27:59 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-04-29 22:27:59 --> Final output sent to browser
DEBUG - 2023-04-29 22:27:59 --> Total execution time: 0.1527
INFO - 2023-04-29 22:28:00 --> Config Class Initialized
INFO - 2023-04-29 22:28:00 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:28:00 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:28:00 --> Utf8 Class Initialized
INFO - 2023-04-29 22:28:00 --> URI Class Initialized
INFO - 2023-04-29 22:28:00 --> Router Class Initialized
INFO - 2023-04-29 22:28:00 --> Output Class Initialized
INFO - 2023-04-29 22:28:00 --> Security Class Initialized
DEBUG - 2023-04-29 22:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:28:00 --> Input Class Initialized
INFO - 2023-04-29 22:28:00 --> Language Class Initialized
INFO - 2023-04-29 22:28:00 --> Loader Class Initialized
INFO - 2023-04-29 22:28:00 --> Helper loaded: url_helper
INFO - 2023-04-29 22:28:00 --> Helper loaded: form_helper
INFO - 2023-04-29 22:28:00 --> Helper loaded: file_helper
INFO - 2023-04-29 22:28:00 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:28:00 --> Form Validation Class Initialized
INFO - 2023-04-29 22:28:00 --> Upload Class Initialized
INFO - 2023-04-29 22:28:00 --> Model "M_auth" initialized
INFO - 2023-04-29 22:28:00 --> Model "M_user" initialized
INFO - 2023-04-29 22:28:00 --> Model "M_produk" initialized
INFO - 2023-04-29 22:28:00 --> Controller Class Initialized
INFO - 2023-04-29 22:28:00 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 22:28:00 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:28:00 --> Final output sent to browser
DEBUG - 2023-04-29 22:28:00 --> Total execution time: 0.1078
INFO - 2023-04-29 22:35:42 --> Config Class Initialized
INFO - 2023-04-29 22:35:42 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:35:42 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:35:42 --> Utf8 Class Initialized
INFO - 2023-04-29 22:35:42 --> URI Class Initialized
DEBUG - 2023-04-29 22:35:42 --> No URI present. Default controller set.
INFO - 2023-04-29 22:35:42 --> Router Class Initialized
INFO - 2023-04-29 22:35:42 --> Output Class Initialized
INFO - 2023-04-29 22:35:42 --> Security Class Initialized
DEBUG - 2023-04-29 22:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:35:42 --> Input Class Initialized
INFO - 2023-04-29 22:35:42 --> Language Class Initialized
INFO - 2023-04-29 22:35:42 --> Loader Class Initialized
INFO - 2023-04-29 22:35:42 --> Helper loaded: url_helper
INFO - 2023-04-29 22:35:42 --> Helper loaded: form_helper
INFO - 2023-04-29 22:35:42 --> Helper loaded: file_helper
INFO - 2023-04-29 22:35:42 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:35:42 --> Form Validation Class Initialized
INFO - 2023-04-29 22:35:42 --> Upload Class Initialized
INFO - 2023-04-29 22:35:42 --> Model "M_auth" initialized
INFO - 2023-04-29 22:35:42 --> Model "M_user" initialized
INFO - 2023-04-29 22:35:42 --> Model "M_produk" initialized
INFO - 2023-04-29 22:35:42 --> Controller Class Initialized
INFO - 2023-04-29 22:35:42 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:35:42 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:35:42 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:35:42 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:35:42 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:35:42 --> Model "M_bank" initialized
INFO - 2023-04-29 22:35:42 --> Model "M_pesan" initialized
INFO - 2023-04-29 22:35:42 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-29 22:35:42 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-04-29 22:35:42 --> Final output sent to browser
DEBUG - 2023-04-29 22:35:42 --> Total execution time: 0.1216
INFO - 2023-04-29 22:35:45 --> Config Class Initialized
INFO - 2023-04-29 22:35:45 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:35:45 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:35:45 --> Utf8 Class Initialized
INFO - 2023-04-29 22:35:45 --> URI Class Initialized
INFO - 2023-04-29 22:35:45 --> Router Class Initialized
INFO - 2023-04-29 22:35:45 --> Output Class Initialized
INFO - 2023-04-29 22:35:45 --> Security Class Initialized
DEBUG - 2023-04-29 22:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:35:45 --> Input Class Initialized
INFO - 2023-04-29 22:35:45 --> Language Class Initialized
INFO - 2023-04-29 22:35:45 --> Loader Class Initialized
INFO - 2023-04-29 22:35:45 --> Helper loaded: url_helper
INFO - 2023-04-29 22:35:45 --> Helper loaded: form_helper
INFO - 2023-04-29 22:35:45 --> Helper loaded: file_helper
INFO - 2023-04-29 22:35:45 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:35:45 --> Form Validation Class Initialized
INFO - 2023-04-29 22:35:45 --> Upload Class Initialized
INFO - 2023-04-29 22:35:45 --> Model "M_auth" initialized
INFO - 2023-04-29 22:35:45 --> Model "M_user" initialized
INFO - 2023-04-29 22:35:45 --> Model "M_produk" initialized
INFO - 2023-04-29 22:35:45 --> Controller Class Initialized
INFO - 2023-04-29 22:35:45 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-04-29 22:35:45 --> Final output sent to browser
DEBUG - 2023-04-29 22:35:45 --> Total execution time: 0.1124
INFO - 2023-04-29 22:35:51 --> Config Class Initialized
INFO - 2023-04-29 22:35:51 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:35:51 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:35:51 --> Utf8 Class Initialized
INFO - 2023-04-29 22:35:51 --> URI Class Initialized
INFO - 2023-04-29 22:35:51 --> Router Class Initialized
INFO - 2023-04-29 22:35:51 --> Output Class Initialized
INFO - 2023-04-29 22:35:51 --> Security Class Initialized
DEBUG - 2023-04-29 22:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:35:51 --> Input Class Initialized
INFO - 2023-04-29 22:35:51 --> Language Class Initialized
INFO - 2023-04-29 22:35:51 --> Loader Class Initialized
INFO - 2023-04-29 22:35:51 --> Helper loaded: url_helper
INFO - 2023-04-29 22:35:51 --> Helper loaded: form_helper
INFO - 2023-04-29 22:35:51 --> Helper loaded: file_helper
INFO - 2023-04-29 22:35:51 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:35:51 --> Form Validation Class Initialized
INFO - 2023-04-29 22:35:51 --> Upload Class Initialized
INFO - 2023-04-29 22:35:51 --> Model "M_auth" initialized
INFO - 2023-04-29 22:35:51 --> Model "M_user" initialized
INFO - 2023-04-29 22:35:51 --> Model "M_produk" initialized
INFO - 2023-04-29 22:35:51 --> Controller Class Initialized
INFO - 2023-04-29 22:35:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-04-29 22:35:51 --> Config Class Initialized
INFO - 2023-04-29 22:35:51 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:35:51 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:35:51 --> Utf8 Class Initialized
INFO - 2023-04-29 22:35:51 --> URI Class Initialized
INFO - 2023-04-29 22:35:51 --> Router Class Initialized
INFO - 2023-04-29 22:35:51 --> Output Class Initialized
INFO - 2023-04-29 22:35:51 --> Security Class Initialized
DEBUG - 2023-04-29 22:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:35:51 --> Input Class Initialized
INFO - 2023-04-29 22:35:51 --> Language Class Initialized
INFO - 2023-04-29 22:35:51 --> Loader Class Initialized
INFO - 2023-04-29 22:35:51 --> Helper loaded: url_helper
INFO - 2023-04-29 22:35:51 --> Helper loaded: form_helper
INFO - 2023-04-29 22:35:51 --> Helper loaded: file_helper
INFO - 2023-04-29 22:35:51 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:35:51 --> Form Validation Class Initialized
INFO - 2023-04-29 22:35:51 --> Upload Class Initialized
INFO - 2023-04-29 22:35:51 --> Model "M_auth" initialized
INFO - 2023-04-29 22:35:51 --> Model "M_user" initialized
INFO - 2023-04-29 22:35:51 --> Model "M_produk" initialized
INFO - 2023-04-29 22:35:51 --> Controller Class Initialized
INFO - 2023-04-29 22:35:51 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 22:35:51 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:35:51 --> Final output sent to browser
DEBUG - 2023-04-29 22:35:51 --> Total execution time: 0.0999
INFO - 2023-04-29 22:35:55 --> Config Class Initialized
INFO - 2023-04-29 22:35:55 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:35:55 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:35:55 --> Utf8 Class Initialized
INFO - 2023-04-29 22:35:55 --> URI Class Initialized
INFO - 2023-04-29 22:35:55 --> Router Class Initialized
INFO - 2023-04-29 22:35:55 --> Output Class Initialized
INFO - 2023-04-29 22:35:55 --> Security Class Initialized
DEBUG - 2023-04-29 22:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:35:55 --> Input Class Initialized
INFO - 2023-04-29 22:35:55 --> Language Class Initialized
INFO - 2023-04-29 22:35:55 --> Loader Class Initialized
INFO - 2023-04-29 22:35:55 --> Helper loaded: url_helper
INFO - 2023-04-29 22:35:55 --> Helper loaded: form_helper
INFO - 2023-04-29 22:35:55 --> Helper loaded: file_helper
INFO - 2023-04-29 22:35:55 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:35:55 --> Form Validation Class Initialized
INFO - 2023-04-29 22:35:55 --> Upload Class Initialized
INFO - 2023-04-29 22:35:55 --> Model "M_auth" initialized
INFO - 2023-04-29 22:35:55 --> Model "M_user" initialized
INFO - 2023-04-29 22:35:55 --> Model "M_produk" initialized
INFO - 2023-04-29 22:35:55 --> Controller Class Initialized
INFO - 2023-04-29 22:35:55 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_user.php
INFO - 2023-04-29 22:35:55 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:35:55 --> Final output sent to browser
DEBUG - 2023-04-29 22:35:55 --> Total execution time: 0.1059
INFO - 2023-04-29 22:35:59 --> Config Class Initialized
INFO - 2023-04-29 22:35:59 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:35:59 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:35:59 --> Utf8 Class Initialized
INFO - 2023-04-29 22:35:59 --> URI Class Initialized
INFO - 2023-04-29 22:35:59 --> Router Class Initialized
INFO - 2023-04-29 22:35:59 --> Output Class Initialized
INFO - 2023-04-29 22:35:59 --> Security Class Initialized
DEBUG - 2023-04-29 22:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:35:59 --> Input Class Initialized
INFO - 2023-04-29 22:35:59 --> Language Class Initialized
INFO - 2023-04-29 22:35:59 --> Loader Class Initialized
INFO - 2023-04-29 22:35:59 --> Helper loaded: url_helper
INFO - 2023-04-29 22:35:59 --> Helper loaded: form_helper
INFO - 2023-04-29 22:35:59 --> Helper loaded: file_helper
INFO - 2023-04-29 22:35:59 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:35:59 --> Form Validation Class Initialized
INFO - 2023-04-29 22:35:59 --> Upload Class Initialized
INFO - 2023-04-29 22:35:59 --> Model "M_auth" initialized
INFO - 2023-04-29 22:35:59 --> Model "M_user" initialized
INFO - 2023-04-29 22:35:59 --> Model "M_produk" initialized
INFO - 2023-04-29 22:35:59 --> Controller Class Initialized
INFO - 2023-04-29 22:35:59 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:35:59 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:35:59 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:35:59 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:35:59 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:35:59 --> Model "M_bank" initialized
INFO - 2023-04-29 22:35:59 --> Model "M_pesan" initialized
ERROR - 2023-04-29 22:35:59 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 22:35:59 --> Config Class Initialized
INFO - 2023-04-29 22:35:59 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:35:59 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:35:59 --> Utf8 Class Initialized
INFO - 2023-04-29 22:35:59 --> URI Class Initialized
INFO - 2023-04-29 22:35:59 --> Router Class Initialized
INFO - 2023-04-29 22:35:59 --> Output Class Initialized
INFO - 2023-04-29 22:35:59 --> Security Class Initialized
DEBUG - 2023-04-29 22:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:35:59 --> Input Class Initialized
INFO - 2023-04-29 22:35:59 --> Language Class Initialized
INFO - 2023-04-29 22:35:59 --> Loader Class Initialized
INFO - 2023-04-29 22:35:59 --> Helper loaded: url_helper
INFO - 2023-04-29 22:35:59 --> Helper loaded: form_helper
INFO - 2023-04-29 22:35:59 --> Helper loaded: file_helper
INFO - 2023-04-29 22:35:59 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:35:59 --> Form Validation Class Initialized
INFO - 2023-04-29 22:35:59 --> Upload Class Initialized
INFO - 2023-04-29 22:35:59 --> Model "M_auth" initialized
INFO - 2023-04-29 22:35:59 --> Model "M_user" initialized
INFO - 2023-04-29 22:35:59 --> Model "M_produk" initialized
INFO - 2023-04-29 22:35:59 --> Controller Class Initialized
INFO - 2023-04-29 22:35:59 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-04-29 22:35:59 --> Final output sent to browser
DEBUG - 2023-04-29 22:35:59 --> Total execution time: 0.0873
INFO - 2023-04-29 22:36:07 --> Config Class Initialized
INFO - 2023-04-29 22:36:07 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:36:07 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:36:07 --> Utf8 Class Initialized
INFO - 2023-04-29 22:36:07 --> URI Class Initialized
INFO - 2023-04-29 22:36:07 --> Router Class Initialized
INFO - 2023-04-29 22:36:07 --> Output Class Initialized
INFO - 2023-04-29 22:36:07 --> Security Class Initialized
DEBUG - 2023-04-29 22:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:36:07 --> Input Class Initialized
INFO - 2023-04-29 22:36:07 --> Language Class Initialized
INFO - 2023-04-29 22:36:07 --> Loader Class Initialized
INFO - 2023-04-29 22:36:07 --> Helper loaded: url_helper
INFO - 2023-04-29 22:36:07 --> Helper loaded: form_helper
INFO - 2023-04-29 22:36:07 --> Helper loaded: file_helper
INFO - 2023-04-29 22:36:07 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:36:07 --> Form Validation Class Initialized
INFO - 2023-04-29 22:36:07 --> Upload Class Initialized
INFO - 2023-04-29 22:36:07 --> Model "M_auth" initialized
INFO - 2023-04-29 22:36:07 --> Model "M_user" initialized
INFO - 2023-04-29 22:36:07 --> Model "M_produk" initialized
INFO - 2023-04-29 22:36:07 --> Controller Class Initialized
INFO - 2023-04-29 22:36:07 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:36:07 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:36:07 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:36:07 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:36:07 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:36:07 --> Model "M_bank" initialized
INFO - 2023-04-29 22:36:07 --> Model "M_pesan" initialized
ERROR - 2023-04-29 22:36:07 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 22:36:07 --> Config Class Initialized
INFO - 2023-04-29 22:36:07 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:36:07 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:36:07 --> Utf8 Class Initialized
INFO - 2023-04-29 22:36:07 --> URI Class Initialized
INFO - 2023-04-29 22:36:07 --> Router Class Initialized
INFO - 2023-04-29 22:36:07 --> Output Class Initialized
INFO - 2023-04-29 22:36:07 --> Security Class Initialized
DEBUG - 2023-04-29 22:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:36:07 --> Input Class Initialized
INFO - 2023-04-29 22:36:07 --> Language Class Initialized
INFO - 2023-04-29 22:36:07 --> Loader Class Initialized
INFO - 2023-04-29 22:36:07 --> Helper loaded: url_helper
INFO - 2023-04-29 22:36:07 --> Helper loaded: form_helper
INFO - 2023-04-29 22:36:07 --> Helper loaded: file_helper
INFO - 2023-04-29 22:36:07 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:36:07 --> Form Validation Class Initialized
INFO - 2023-04-29 22:36:07 --> Upload Class Initialized
INFO - 2023-04-29 22:36:07 --> Model "M_auth" initialized
INFO - 2023-04-29 22:36:07 --> Model "M_user" initialized
INFO - 2023-04-29 22:36:07 --> Model "M_produk" initialized
INFO - 2023-04-29 22:36:07 --> Controller Class Initialized
INFO - 2023-04-29 22:36:07 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-04-29 22:36:07 --> Final output sent to browser
DEBUG - 2023-04-29 22:36:07 --> Total execution time: 0.1037
INFO - 2023-04-29 22:37:27 --> Config Class Initialized
INFO - 2023-04-29 22:37:27 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:37:27 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:37:27 --> Utf8 Class Initialized
INFO - 2023-04-29 22:37:27 --> URI Class Initialized
INFO - 2023-04-29 22:37:27 --> Router Class Initialized
INFO - 2023-04-29 22:37:27 --> Output Class Initialized
INFO - 2023-04-29 22:37:27 --> Security Class Initialized
DEBUG - 2023-04-29 22:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:37:27 --> Input Class Initialized
INFO - 2023-04-29 22:37:27 --> Language Class Initialized
INFO - 2023-04-29 22:37:27 --> Loader Class Initialized
INFO - 2023-04-29 22:37:27 --> Helper loaded: url_helper
INFO - 2023-04-29 22:37:27 --> Helper loaded: form_helper
INFO - 2023-04-29 22:37:27 --> Helper loaded: file_helper
INFO - 2023-04-29 22:37:27 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:37:27 --> Form Validation Class Initialized
INFO - 2023-04-29 22:37:27 --> Upload Class Initialized
INFO - 2023-04-29 22:37:27 --> Model "M_auth" initialized
INFO - 2023-04-29 22:37:27 --> Model "M_user" initialized
INFO - 2023-04-29 22:37:27 --> Model "M_produk" initialized
INFO - 2023-04-29 22:37:27 --> Controller Class Initialized
INFO - 2023-04-29 22:37:27 --> Model "M_produk" initialized
INFO - 2023-04-29 22:37:27 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_typeproduk.php
INFO - 2023-04-29 22:37:27 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:37:27 --> Final output sent to browser
DEBUG - 2023-04-29 22:37:27 --> Total execution time: 0.1245
INFO - 2023-04-29 22:38:26 --> Config Class Initialized
INFO - 2023-04-29 22:38:26 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:38:26 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:38:26 --> Utf8 Class Initialized
INFO - 2023-04-29 22:38:26 --> URI Class Initialized
INFO - 2023-04-29 22:38:26 --> Router Class Initialized
INFO - 2023-04-29 22:38:26 --> Output Class Initialized
INFO - 2023-04-29 22:38:26 --> Security Class Initialized
DEBUG - 2023-04-29 22:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:38:26 --> Input Class Initialized
INFO - 2023-04-29 22:38:26 --> Language Class Initialized
INFO - 2023-04-29 22:38:26 --> Loader Class Initialized
INFO - 2023-04-29 22:38:26 --> Helper loaded: url_helper
INFO - 2023-04-29 22:38:26 --> Helper loaded: form_helper
INFO - 2023-04-29 22:38:26 --> Helper loaded: file_helper
INFO - 2023-04-29 22:38:26 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:38:26 --> Form Validation Class Initialized
INFO - 2023-04-29 22:38:26 --> Upload Class Initialized
INFO - 2023-04-29 22:38:26 --> Model "M_auth" initialized
INFO - 2023-04-29 22:38:26 --> Model "M_user" initialized
INFO - 2023-04-29 22:38:26 --> Model "M_produk" initialized
INFO - 2023-04-29 22:38:26 --> Controller Class Initialized
INFO - 2023-04-29 22:38:26 --> Model "M_produk" initialized
INFO - 2023-04-29 22:38:26 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_typeproduk.php
INFO - 2023-04-29 22:38:26 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:38:26 --> Final output sent to browser
DEBUG - 2023-04-29 22:38:26 --> Total execution time: 0.1008
INFO - 2023-04-29 22:38:30 --> Config Class Initialized
INFO - 2023-04-29 22:38:30 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:38:30 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:38:30 --> Utf8 Class Initialized
INFO - 2023-04-29 22:38:30 --> URI Class Initialized
INFO - 2023-04-29 22:38:30 --> Router Class Initialized
INFO - 2023-04-29 22:38:30 --> Output Class Initialized
INFO - 2023-04-29 22:38:30 --> Security Class Initialized
DEBUG - 2023-04-29 22:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:38:30 --> Input Class Initialized
INFO - 2023-04-29 22:38:30 --> Language Class Initialized
INFO - 2023-04-29 22:38:30 --> Loader Class Initialized
INFO - 2023-04-29 22:38:30 --> Helper loaded: url_helper
INFO - 2023-04-29 22:38:30 --> Helper loaded: form_helper
INFO - 2023-04-29 22:38:30 --> Helper loaded: file_helper
INFO - 2023-04-29 22:38:30 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:38:30 --> Form Validation Class Initialized
INFO - 2023-04-29 22:38:30 --> Upload Class Initialized
INFO - 2023-04-29 22:38:30 --> Model "M_auth" initialized
INFO - 2023-04-29 22:38:30 --> Model "M_user" initialized
INFO - 2023-04-29 22:38:30 --> Model "M_produk" initialized
INFO - 2023-04-29 22:38:30 --> Controller Class Initialized
INFO - 2023-04-29 22:38:30 --> Model "M_produk" initialized
INFO - 2023-04-29 22:38:30 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_typeproduk.php
INFO - 2023-04-29 22:38:30 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:38:30 --> Final output sent to browser
DEBUG - 2023-04-29 22:38:30 --> Total execution time: 0.1131
INFO - 2023-04-29 22:39:11 --> Config Class Initialized
INFO - 2023-04-29 22:39:11 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:39:11 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:39:11 --> Utf8 Class Initialized
INFO - 2023-04-29 22:39:11 --> URI Class Initialized
INFO - 2023-04-29 22:39:11 --> Router Class Initialized
INFO - 2023-04-29 22:39:11 --> Output Class Initialized
INFO - 2023-04-29 22:39:11 --> Security Class Initialized
DEBUG - 2023-04-29 22:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:39:11 --> Input Class Initialized
INFO - 2023-04-29 22:39:11 --> Language Class Initialized
INFO - 2023-04-29 22:39:11 --> Loader Class Initialized
INFO - 2023-04-29 22:39:11 --> Helper loaded: url_helper
INFO - 2023-04-29 22:39:11 --> Helper loaded: form_helper
INFO - 2023-04-29 22:39:11 --> Helper loaded: file_helper
INFO - 2023-04-29 22:39:11 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:39:11 --> Form Validation Class Initialized
INFO - 2023-04-29 22:39:11 --> Upload Class Initialized
INFO - 2023-04-29 22:39:11 --> Model "M_auth" initialized
INFO - 2023-04-29 22:39:11 --> Model "M_user" initialized
INFO - 2023-04-29 22:39:11 --> Model "M_produk" initialized
INFO - 2023-04-29 22:39:11 --> Controller Class Initialized
INFO - 2023-04-29 22:39:11 --> Model "M_produk" initialized
INFO - 2023-04-29 22:39:11 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_typeproduk.php
INFO - 2023-04-29 22:39:11 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:39:11 --> Final output sent to browser
DEBUG - 2023-04-29 22:39:11 --> Total execution time: 0.1020
INFO - 2023-04-29 22:39:49 --> Config Class Initialized
INFO - 2023-04-29 22:39:49 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:39:49 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:39:49 --> Utf8 Class Initialized
INFO - 2023-04-29 22:39:49 --> URI Class Initialized
INFO - 2023-04-29 22:39:49 --> Router Class Initialized
INFO - 2023-04-29 22:39:49 --> Output Class Initialized
INFO - 2023-04-29 22:39:49 --> Security Class Initialized
DEBUG - 2023-04-29 22:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:39:49 --> Input Class Initialized
INFO - 2023-04-29 22:39:49 --> Language Class Initialized
INFO - 2023-04-29 22:39:49 --> Loader Class Initialized
INFO - 2023-04-29 22:39:49 --> Helper loaded: url_helper
INFO - 2023-04-29 22:39:49 --> Helper loaded: form_helper
INFO - 2023-04-29 22:39:49 --> Helper loaded: file_helper
INFO - 2023-04-29 22:39:49 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:39:49 --> Form Validation Class Initialized
INFO - 2023-04-29 22:39:49 --> Upload Class Initialized
INFO - 2023-04-29 22:39:49 --> Model "M_auth" initialized
INFO - 2023-04-29 22:39:49 --> Model "M_user" initialized
INFO - 2023-04-29 22:39:49 --> Model "M_produk" initialized
INFO - 2023-04-29 22:39:49 --> Controller Class Initialized
INFO - 2023-04-29 22:39:49 --> Model "M_produk" initialized
INFO - 2023-04-29 22:39:49 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_typeproduk.php
INFO - 2023-04-29 22:39:49 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:39:49 --> Final output sent to browser
DEBUG - 2023-04-29 22:39:49 --> Total execution time: 0.1124
INFO - 2023-04-29 22:39:51 --> Config Class Initialized
INFO - 2023-04-29 22:39:51 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:39:51 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:39:51 --> Utf8 Class Initialized
INFO - 2023-04-29 22:39:51 --> URI Class Initialized
INFO - 2023-04-29 22:39:51 --> Router Class Initialized
INFO - 2023-04-29 22:39:51 --> Output Class Initialized
INFO - 2023-04-29 22:39:51 --> Security Class Initialized
DEBUG - 2023-04-29 22:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:39:51 --> Input Class Initialized
INFO - 2023-04-29 22:39:51 --> Language Class Initialized
INFO - 2023-04-29 22:39:51 --> Loader Class Initialized
INFO - 2023-04-29 22:39:51 --> Helper loaded: url_helper
INFO - 2023-04-29 22:39:51 --> Helper loaded: form_helper
INFO - 2023-04-29 22:39:51 --> Helper loaded: file_helper
INFO - 2023-04-29 22:39:51 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:39:51 --> Form Validation Class Initialized
INFO - 2023-04-29 22:39:51 --> Upload Class Initialized
INFO - 2023-04-29 22:39:51 --> Model "M_auth" initialized
INFO - 2023-04-29 22:39:51 --> Model "M_user" initialized
INFO - 2023-04-29 22:39:51 --> Model "M_produk" initialized
INFO - 2023-04-29 22:39:51 --> Controller Class Initialized
INFO - 2023-04-29 22:39:51 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 22:39:51 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:39:51 --> Final output sent to browser
DEBUG - 2023-04-29 22:39:51 --> Total execution time: 0.0903
INFO - 2023-04-29 22:39:53 --> Config Class Initialized
INFO - 2023-04-29 22:39:53 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:39:53 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:39:53 --> Utf8 Class Initialized
INFO - 2023-04-29 22:39:53 --> URI Class Initialized
INFO - 2023-04-29 22:39:53 --> Router Class Initialized
INFO - 2023-04-29 22:39:53 --> Output Class Initialized
INFO - 2023-04-29 22:39:53 --> Security Class Initialized
DEBUG - 2023-04-29 22:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:39:53 --> Input Class Initialized
INFO - 2023-04-29 22:39:53 --> Language Class Initialized
INFO - 2023-04-29 22:39:53 --> Loader Class Initialized
INFO - 2023-04-29 22:39:53 --> Helper loaded: url_helper
INFO - 2023-04-29 22:39:53 --> Helper loaded: form_helper
INFO - 2023-04-29 22:39:53 --> Helper loaded: file_helper
INFO - 2023-04-29 22:39:53 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:39:53 --> Form Validation Class Initialized
INFO - 2023-04-29 22:39:53 --> Upload Class Initialized
INFO - 2023-04-29 22:39:53 --> Model "M_auth" initialized
INFO - 2023-04-29 22:39:53 --> Model "M_user" initialized
INFO - 2023-04-29 22:39:53 --> Model "M_produk" initialized
INFO - 2023-04-29 22:39:53 --> Controller Class Initialized
INFO - 2023-04-29 22:39:53 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_user.php
INFO - 2023-04-29 22:39:53 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:39:53 --> Final output sent to browser
DEBUG - 2023-04-29 22:39:53 --> Total execution time: 0.1126
INFO - 2023-04-29 22:39:55 --> Config Class Initialized
INFO - 2023-04-29 22:39:55 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:39:55 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:39:55 --> Utf8 Class Initialized
INFO - 2023-04-29 22:39:55 --> URI Class Initialized
INFO - 2023-04-29 22:39:55 --> Router Class Initialized
INFO - 2023-04-29 22:39:55 --> Output Class Initialized
INFO - 2023-04-29 22:39:55 --> Security Class Initialized
DEBUG - 2023-04-29 22:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:39:55 --> Input Class Initialized
INFO - 2023-04-29 22:39:55 --> Language Class Initialized
INFO - 2023-04-29 22:39:55 --> Loader Class Initialized
INFO - 2023-04-29 22:39:55 --> Helper loaded: url_helper
INFO - 2023-04-29 22:39:55 --> Helper loaded: form_helper
INFO - 2023-04-29 22:39:55 --> Helper loaded: file_helper
INFO - 2023-04-29 22:39:55 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:39:55 --> Form Validation Class Initialized
INFO - 2023-04-29 22:39:55 --> Upload Class Initialized
INFO - 2023-04-29 22:39:55 --> Model "M_auth" initialized
INFO - 2023-04-29 22:39:55 --> Model "M_user" initialized
INFO - 2023-04-29 22:39:55 --> Model "M_produk" initialized
INFO - 2023-04-29 22:39:55 --> Controller Class Initialized
INFO - 2023-04-29 22:39:55 --> Model "M_produk" initialized
INFO - 2023-04-29 22:39:55 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_typeproduk.php
INFO - 2023-04-29 22:39:55 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:39:55 --> Final output sent to browser
DEBUG - 2023-04-29 22:39:55 --> Total execution time: 0.1082
INFO - 2023-04-29 22:39:57 --> Config Class Initialized
INFO - 2023-04-29 22:39:57 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:39:57 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:39:57 --> Utf8 Class Initialized
INFO - 2023-04-29 22:39:57 --> URI Class Initialized
INFO - 2023-04-29 22:39:57 --> Router Class Initialized
INFO - 2023-04-29 22:39:57 --> Output Class Initialized
INFO - 2023-04-29 22:39:57 --> Security Class Initialized
DEBUG - 2023-04-29 22:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:39:57 --> Input Class Initialized
INFO - 2023-04-29 22:39:57 --> Language Class Initialized
INFO - 2023-04-29 22:39:57 --> Loader Class Initialized
INFO - 2023-04-29 22:39:57 --> Helper loaded: url_helper
INFO - 2023-04-29 22:39:57 --> Helper loaded: form_helper
INFO - 2023-04-29 22:39:57 --> Helper loaded: file_helper
INFO - 2023-04-29 22:39:57 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:39:57 --> Form Validation Class Initialized
INFO - 2023-04-29 22:39:57 --> Upload Class Initialized
INFO - 2023-04-29 22:39:57 --> Model "M_auth" initialized
INFO - 2023-04-29 22:39:57 --> Model "M_user" initialized
INFO - 2023-04-29 22:39:57 --> Model "M_produk" initialized
INFO - 2023-04-29 22:39:57 --> Controller Class Initialized
INFO - 2023-04-29 22:39:57 --> Model "M_produk" initialized
INFO - 2023-04-29 22:39:57 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_type_merek.php
INFO - 2023-04-29 22:39:57 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:39:57 --> Final output sent to browser
DEBUG - 2023-04-29 22:39:57 --> Total execution time: 0.1156
INFO - 2023-04-29 22:39:59 --> Config Class Initialized
INFO - 2023-04-29 22:39:59 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:39:59 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:39:59 --> Utf8 Class Initialized
INFO - 2023-04-29 22:39:59 --> URI Class Initialized
INFO - 2023-04-29 22:39:59 --> Router Class Initialized
INFO - 2023-04-29 22:39:59 --> Output Class Initialized
INFO - 2023-04-29 22:39:59 --> Security Class Initialized
DEBUG - 2023-04-29 22:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:39:59 --> Input Class Initialized
INFO - 2023-04-29 22:39:59 --> Language Class Initialized
INFO - 2023-04-29 22:39:59 --> Loader Class Initialized
INFO - 2023-04-29 22:39:59 --> Helper loaded: url_helper
INFO - 2023-04-29 22:39:59 --> Helper loaded: form_helper
INFO - 2023-04-29 22:39:59 --> Helper loaded: file_helper
INFO - 2023-04-29 22:39:59 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:39:59 --> Form Validation Class Initialized
INFO - 2023-04-29 22:39:59 --> Upload Class Initialized
INFO - 2023-04-29 22:39:59 --> Model "M_auth" initialized
INFO - 2023-04-29 22:39:59 --> Model "M_user" initialized
INFO - 2023-04-29 22:39:59 --> Model "M_produk" initialized
INFO - 2023-04-29 22:39:59 --> Controller Class Initialized
INFO - 2023-04-29 22:39:59 --> Model "M_produk" initialized
INFO - 2023-04-29 22:39:59 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-04-29 22:39:59 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:39:59 --> Final output sent to browser
DEBUG - 2023-04-29 22:39:59 --> Total execution time: 0.1253
INFO - 2023-04-29 22:42:29 --> Config Class Initialized
INFO - 2023-04-29 22:42:29 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:42:29 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:42:29 --> Utf8 Class Initialized
INFO - 2023-04-29 22:42:29 --> URI Class Initialized
INFO - 2023-04-29 22:42:29 --> Router Class Initialized
INFO - 2023-04-29 22:42:29 --> Output Class Initialized
INFO - 2023-04-29 22:42:29 --> Security Class Initialized
DEBUG - 2023-04-29 22:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:42:29 --> Input Class Initialized
INFO - 2023-04-29 22:42:29 --> Language Class Initialized
INFO - 2023-04-29 22:42:29 --> Loader Class Initialized
INFO - 2023-04-29 22:42:29 --> Helper loaded: url_helper
INFO - 2023-04-29 22:42:29 --> Helper loaded: form_helper
INFO - 2023-04-29 22:42:29 --> Helper loaded: file_helper
INFO - 2023-04-29 22:42:29 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:42:29 --> Form Validation Class Initialized
INFO - 2023-04-29 22:42:29 --> Upload Class Initialized
INFO - 2023-04-29 22:42:29 --> Model "M_auth" initialized
INFO - 2023-04-29 22:42:29 --> Model "M_user" initialized
INFO - 2023-04-29 22:42:29 --> Model "M_produk" initialized
INFO - 2023-04-29 22:42:29 --> Controller Class Initialized
INFO - 2023-04-29 22:42:29 --> Model "M_produk" initialized
INFO - 2023-04-29 22:42:29 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-04-29 22:42:29 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:42:29 --> Final output sent to browser
DEBUG - 2023-04-29 22:42:29 --> Total execution time: 0.1070
INFO - 2023-04-29 22:44:16 --> Config Class Initialized
INFO - 2023-04-29 22:44:16 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:44:16 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:44:16 --> Utf8 Class Initialized
INFO - 2023-04-29 22:44:16 --> URI Class Initialized
INFO - 2023-04-29 22:44:16 --> Router Class Initialized
INFO - 2023-04-29 22:44:16 --> Output Class Initialized
INFO - 2023-04-29 22:44:16 --> Security Class Initialized
DEBUG - 2023-04-29 22:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:44:16 --> Input Class Initialized
INFO - 2023-04-29 22:44:16 --> Language Class Initialized
INFO - 2023-04-29 22:44:16 --> Loader Class Initialized
INFO - 2023-04-29 22:44:16 --> Helper loaded: url_helper
INFO - 2023-04-29 22:44:16 --> Helper loaded: form_helper
INFO - 2023-04-29 22:44:16 --> Helper loaded: file_helper
INFO - 2023-04-29 22:44:16 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:44:16 --> Form Validation Class Initialized
INFO - 2023-04-29 22:44:16 --> Upload Class Initialized
INFO - 2023-04-29 22:44:16 --> Model "M_auth" initialized
INFO - 2023-04-29 22:44:16 --> Model "M_user" initialized
INFO - 2023-04-29 22:44:16 --> Model "M_produk" initialized
INFO - 2023-04-29 22:44:16 --> Controller Class Initialized
INFO - 2023-04-29 22:44:16 --> Model "M_produk" initialized
INFO - 2023-04-29 22:44:16 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-04-29 22:44:16 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:44:16 --> Final output sent to browser
DEBUG - 2023-04-29 22:44:16 --> Total execution time: 0.1069
INFO - 2023-04-29 22:44:37 --> Config Class Initialized
INFO - 2023-04-29 22:44:37 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:44:37 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:44:37 --> Utf8 Class Initialized
INFO - 2023-04-29 22:44:37 --> URI Class Initialized
INFO - 2023-04-29 22:44:37 --> Router Class Initialized
INFO - 2023-04-29 22:44:37 --> Output Class Initialized
INFO - 2023-04-29 22:44:37 --> Security Class Initialized
DEBUG - 2023-04-29 22:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:44:37 --> Input Class Initialized
INFO - 2023-04-29 22:44:37 --> Language Class Initialized
INFO - 2023-04-29 22:44:37 --> Loader Class Initialized
INFO - 2023-04-29 22:44:37 --> Helper loaded: url_helper
INFO - 2023-04-29 22:44:37 --> Helper loaded: form_helper
INFO - 2023-04-29 22:44:37 --> Helper loaded: file_helper
INFO - 2023-04-29 22:44:37 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:44:37 --> Form Validation Class Initialized
INFO - 2023-04-29 22:44:37 --> Upload Class Initialized
INFO - 2023-04-29 22:44:37 --> Model "M_auth" initialized
INFO - 2023-04-29 22:44:37 --> Model "M_user" initialized
INFO - 2023-04-29 22:44:37 --> Model "M_produk" initialized
INFO - 2023-04-29 22:44:37 --> Controller Class Initialized
INFO - 2023-04-29 22:44:37 --> Model "M_produk" initialized
INFO - 2023-04-29 22:44:37 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-04-29 22:44:37 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:44:37 --> Final output sent to browser
DEBUG - 2023-04-29 22:44:37 --> Total execution time: 0.1003
INFO - 2023-04-29 22:44:51 --> Config Class Initialized
INFO - 2023-04-29 22:44:51 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:44:51 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:44:51 --> Utf8 Class Initialized
INFO - 2023-04-29 22:44:51 --> URI Class Initialized
INFO - 2023-04-29 22:44:51 --> Router Class Initialized
INFO - 2023-04-29 22:44:51 --> Output Class Initialized
INFO - 2023-04-29 22:44:51 --> Security Class Initialized
DEBUG - 2023-04-29 22:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:44:51 --> Input Class Initialized
INFO - 2023-04-29 22:44:51 --> Language Class Initialized
INFO - 2023-04-29 22:44:51 --> Loader Class Initialized
INFO - 2023-04-29 22:44:51 --> Helper loaded: url_helper
INFO - 2023-04-29 22:44:51 --> Helper loaded: form_helper
INFO - 2023-04-29 22:44:51 --> Helper loaded: file_helper
INFO - 2023-04-29 22:44:51 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:44:51 --> Form Validation Class Initialized
INFO - 2023-04-29 22:44:51 --> Upload Class Initialized
INFO - 2023-04-29 22:44:51 --> Model "M_auth" initialized
INFO - 2023-04-29 22:44:51 --> Model "M_user" initialized
INFO - 2023-04-29 22:44:51 --> Model "M_produk" initialized
INFO - 2023-04-29 22:44:51 --> Controller Class Initialized
INFO - 2023-04-29 22:44:51 --> Model "M_produk" initialized
INFO - 2023-04-29 22:44:51 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-04-29 22:44:51 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:44:51 --> Final output sent to browser
DEBUG - 2023-04-29 22:44:51 --> Total execution time: 0.1101
INFO - 2023-04-29 22:44:53 --> Config Class Initialized
INFO - 2023-04-29 22:44:53 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:44:53 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:44:53 --> Utf8 Class Initialized
INFO - 2023-04-29 22:44:53 --> URI Class Initialized
INFO - 2023-04-29 22:44:53 --> Router Class Initialized
INFO - 2023-04-29 22:44:53 --> Output Class Initialized
INFO - 2023-04-29 22:44:53 --> Security Class Initialized
DEBUG - 2023-04-29 22:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:44:53 --> Input Class Initialized
INFO - 2023-04-29 22:44:53 --> Language Class Initialized
INFO - 2023-04-29 22:44:53 --> Loader Class Initialized
INFO - 2023-04-29 22:44:53 --> Helper loaded: url_helper
INFO - 2023-04-29 22:44:53 --> Helper loaded: form_helper
INFO - 2023-04-29 22:44:53 --> Helper loaded: file_helper
INFO - 2023-04-29 22:44:53 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:44:53 --> Form Validation Class Initialized
INFO - 2023-04-29 22:44:53 --> Upload Class Initialized
INFO - 2023-04-29 22:44:53 --> Model "M_auth" initialized
INFO - 2023-04-29 22:44:53 --> Model "M_user" initialized
INFO - 2023-04-29 22:44:53 --> Model "M_produk" initialized
INFO - 2023-04-29 22:44:53 --> Controller Class Initialized
INFO - 2023-04-29 22:44:53 --> Model "M_produk" initialized
INFO - 2023-04-29 22:44:53 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-04-29 22:44:53 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:44:53 --> Final output sent to browser
DEBUG - 2023-04-29 22:44:53 --> Total execution time: 0.0949
INFO - 2023-04-29 22:44:55 --> Config Class Initialized
INFO - 2023-04-29 22:44:55 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:44:55 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:44:55 --> Utf8 Class Initialized
INFO - 2023-04-29 22:44:55 --> URI Class Initialized
INFO - 2023-04-29 22:44:55 --> Router Class Initialized
INFO - 2023-04-29 22:44:55 --> Output Class Initialized
INFO - 2023-04-29 22:44:55 --> Security Class Initialized
DEBUG - 2023-04-29 22:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:44:55 --> Input Class Initialized
INFO - 2023-04-29 22:44:55 --> Language Class Initialized
INFO - 2023-04-29 22:44:55 --> Loader Class Initialized
INFO - 2023-04-29 22:44:55 --> Helper loaded: url_helper
INFO - 2023-04-29 22:44:55 --> Helper loaded: form_helper
INFO - 2023-04-29 22:44:55 --> Helper loaded: file_helper
INFO - 2023-04-29 22:44:55 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:44:55 --> Form Validation Class Initialized
INFO - 2023-04-29 22:44:55 --> Upload Class Initialized
INFO - 2023-04-29 22:44:55 --> Model "M_auth" initialized
INFO - 2023-04-29 22:44:55 --> Model "M_user" initialized
INFO - 2023-04-29 22:44:55 --> Model "M_produk" initialized
INFO - 2023-04-29 22:44:55 --> Controller Class Initialized
INFO - 2023-04-29 22:44:55 --> Model "M_produk" initialized
INFO - 2023-04-29 22:44:55 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-04-29 22:44:55 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:44:55 --> Final output sent to browser
DEBUG - 2023-04-29 22:44:55 --> Total execution time: 0.0999
INFO - 2023-04-29 22:44:58 --> Config Class Initialized
INFO - 2023-04-29 22:44:58 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:44:58 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:44:58 --> Utf8 Class Initialized
INFO - 2023-04-29 22:44:58 --> URI Class Initialized
INFO - 2023-04-29 22:44:58 --> Router Class Initialized
INFO - 2023-04-29 22:44:58 --> Output Class Initialized
INFO - 2023-04-29 22:44:58 --> Security Class Initialized
DEBUG - 2023-04-29 22:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:44:58 --> Input Class Initialized
INFO - 2023-04-29 22:44:58 --> Language Class Initialized
INFO - 2023-04-29 22:44:58 --> Loader Class Initialized
INFO - 2023-04-29 22:44:58 --> Helper loaded: url_helper
INFO - 2023-04-29 22:44:58 --> Helper loaded: form_helper
INFO - 2023-04-29 22:44:58 --> Helper loaded: file_helper
INFO - 2023-04-29 22:44:58 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:44:58 --> Form Validation Class Initialized
INFO - 2023-04-29 22:44:58 --> Upload Class Initialized
INFO - 2023-04-29 22:44:58 --> Model "M_auth" initialized
INFO - 2023-04-29 22:44:58 --> Model "M_user" initialized
INFO - 2023-04-29 22:44:58 --> Model "M_produk" initialized
INFO - 2023-04-29 22:44:58 --> Controller Class Initialized
INFO - 2023-04-29 22:44:58 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:44:58 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_pelanggan.php
INFO - 2023-04-29 22:44:58 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:44:58 --> Final output sent to browser
DEBUG - 2023-04-29 22:44:58 --> Total execution time: 0.1019
INFO - 2023-04-29 22:45:08 --> Config Class Initialized
INFO - 2023-04-29 22:45:08 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:45:08 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:45:08 --> Utf8 Class Initialized
INFO - 2023-04-29 22:45:08 --> URI Class Initialized
INFO - 2023-04-29 22:45:08 --> Router Class Initialized
INFO - 2023-04-29 22:45:08 --> Output Class Initialized
INFO - 2023-04-29 22:45:08 --> Security Class Initialized
DEBUG - 2023-04-29 22:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:45:08 --> Input Class Initialized
INFO - 2023-04-29 22:45:08 --> Language Class Initialized
INFO - 2023-04-29 22:45:08 --> Loader Class Initialized
INFO - 2023-04-29 22:45:08 --> Helper loaded: url_helper
INFO - 2023-04-29 22:45:08 --> Helper loaded: form_helper
INFO - 2023-04-29 22:45:08 --> Helper loaded: file_helper
INFO - 2023-04-29 22:45:08 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:45:08 --> Form Validation Class Initialized
INFO - 2023-04-29 22:45:08 --> Upload Class Initialized
INFO - 2023-04-29 22:45:08 --> Model "M_auth" initialized
INFO - 2023-04-29 22:45:08 --> Model "M_user" initialized
INFO - 2023-04-29 22:45:08 --> Model "M_produk" initialized
INFO - 2023-04-29 22:45:08 --> Controller Class Initialized
INFO - 2023-04-29 22:45:08 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_user.php
INFO - 2023-04-29 22:45:08 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:45:08 --> Final output sent to browser
DEBUG - 2023-04-29 22:45:08 --> Total execution time: 0.0984
INFO - 2023-04-29 22:46:09 --> Config Class Initialized
INFO - 2023-04-29 22:46:09 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:46:09 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:46:09 --> Utf8 Class Initialized
INFO - 2023-04-29 22:46:09 --> URI Class Initialized
INFO - 2023-04-29 22:46:09 --> Router Class Initialized
INFO - 2023-04-29 22:46:09 --> Output Class Initialized
INFO - 2023-04-29 22:46:09 --> Security Class Initialized
DEBUG - 2023-04-29 22:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:46:09 --> Input Class Initialized
INFO - 2023-04-29 22:46:09 --> Language Class Initialized
INFO - 2023-04-29 22:46:09 --> Loader Class Initialized
INFO - 2023-04-29 22:46:09 --> Helper loaded: url_helper
INFO - 2023-04-29 22:46:09 --> Helper loaded: form_helper
INFO - 2023-04-29 22:46:09 --> Helper loaded: file_helper
INFO - 2023-04-29 22:46:09 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:46:09 --> Form Validation Class Initialized
INFO - 2023-04-29 22:46:09 --> Upload Class Initialized
INFO - 2023-04-29 22:46:09 --> Model "M_auth" initialized
INFO - 2023-04-29 22:46:09 --> Model "M_user" initialized
INFO - 2023-04-29 22:46:09 --> Model "M_produk" initialized
INFO - 2023-04-29 22:46:09 --> Controller Class Initialized
INFO - 2023-04-29 22:46:09 --> Model "M_produk" initialized
INFO - 2023-04-29 22:46:09 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-04-29 22:46:09 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:46:09 --> Final output sent to browser
DEBUG - 2023-04-29 22:46:09 --> Total execution time: 0.1058
INFO - 2023-04-29 22:46:10 --> Config Class Initialized
INFO - 2023-04-29 22:46:10 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:46:10 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:46:10 --> Utf8 Class Initialized
INFO - 2023-04-29 22:46:10 --> URI Class Initialized
INFO - 2023-04-29 22:46:10 --> Router Class Initialized
INFO - 2023-04-29 22:46:11 --> Output Class Initialized
INFO - 2023-04-29 22:46:11 --> Security Class Initialized
DEBUG - 2023-04-29 22:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:46:11 --> Input Class Initialized
INFO - 2023-04-29 22:46:11 --> Language Class Initialized
INFO - 2023-04-29 22:46:11 --> Loader Class Initialized
INFO - 2023-04-29 22:46:11 --> Helper loaded: url_helper
INFO - 2023-04-29 22:46:11 --> Helper loaded: form_helper
INFO - 2023-04-29 22:46:11 --> Helper loaded: file_helper
INFO - 2023-04-29 22:46:11 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:46:11 --> Form Validation Class Initialized
INFO - 2023-04-29 22:46:11 --> Upload Class Initialized
INFO - 2023-04-29 22:46:11 --> Model "M_auth" initialized
INFO - 2023-04-29 22:46:11 --> Model "M_user" initialized
INFO - 2023-04-29 22:46:11 --> Model "M_produk" initialized
INFO - 2023-04-29 22:46:11 --> Controller Class Initialized
INFO - 2023-04-29 22:46:11 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:46:11 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:46:11 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:46:11 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:46:11 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:46:11 --> Model "M_bank" initialized
INFO - 2023-04-29 22:46:11 --> Model "M_pesan" initialized
ERROR - 2023-04-29 22:46:11 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 22:46:11 --> Config Class Initialized
INFO - 2023-04-29 22:46:11 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:46:11 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:46:11 --> Utf8 Class Initialized
INFO - 2023-04-29 22:46:11 --> URI Class Initialized
INFO - 2023-04-29 22:46:11 --> Router Class Initialized
INFO - 2023-04-29 22:46:11 --> Output Class Initialized
INFO - 2023-04-29 22:46:11 --> Security Class Initialized
DEBUG - 2023-04-29 22:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:46:11 --> Input Class Initialized
INFO - 2023-04-29 22:46:11 --> Language Class Initialized
INFO - 2023-04-29 22:46:11 --> Loader Class Initialized
INFO - 2023-04-29 22:46:11 --> Helper loaded: url_helper
INFO - 2023-04-29 22:46:11 --> Helper loaded: form_helper
INFO - 2023-04-29 22:46:11 --> Helper loaded: file_helper
INFO - 2023-04-29 22:46:11 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:46:11 --> Form Validation Class Initialized
INFO - 2023-04-29 22:46:11 --> Upload Class Initialized
INFO - 2023-04-29 22:46:11 --> Model "M_auth" initialized
INFO - 2023-04-29 22:46:11 --> Model "M_user" initialized
INFO - 2023-04-29 22:46:11 --> Model "M_produk" initialized
INFO - 2023-04-29 22:46:11 --> Controller Class Initialized
INFO - 2023-04-29 22:46:11 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-04-29 22:46:11 --> Final output sent to browser
DEBUG - 2023-04-29 22:46:11 --> Total execution time: 0.1150
INFO - 2023-04-29 22:46:17 --> Config Class Initialized
INFO - 2023-04-29 22:46:17 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:46:17 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:46:17 --> Utf8 Class Initialized
INFO - 2023-04-29 22:46:17 --> URI Class Initialized
INFO - 2023-04-29 22:46:17 --> Router Class Initialized
INFO - 2023-04-29 22:46:17 --> Output Class Initialized
INFO - 2023-04-29 22:46:17 --> Security Class Initialized
DEBUG - 2023-04-29 22:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:46:17 --> Input Class Initialized
INFO - 2023-04-29 22:46:17 --> Language Class Initialized
INFO - 2023-04-29 22:46:17 --> Loader Class Initialized
INFO - 2023-04-29 22:46:17 --> Helper loaded: url_helper
INFO - 2023-04-29 22:46:17 --> Helper loaded: form_helper
INFO - 2023-04-29 22:46:17 --> Helper loaded: file_helper
INFO - 2023-04-29 22:46:17 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:46:17 --> Form Validation Class Initialized
INFO - 2023-04-29 22:46:17 --> Upload Class Initialized
INFO - 2023-04-29 22:46:17 --> Model "M_auth" initialized
INFO - 2023-04-29 22:46:17 --> Model "M_user" initialized
INFO - 2023-04-29 22:46:17 --> Model "M_produk" initialized
INFO - 2023-04-29 22:46:17 --> Controller Class Initialized
INFO - 2023-04-29 22:46:17 --> Model "M_produk" initialized
INFO - 2023-04-29 22:46:17 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-04-29 22:46:17 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:46:17 --> Final output sent to browser
DEBUG - 2023-04-29 22:46:17 --> Total execution time: 0.1296
INFO - 2023-04-29 22:46:18 --> Config Class Initialized
INFO - 2023-04-29 22:46:18 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:46:18 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:46:18 --> Utf8 Class Initialized
INFO - 2023-04-29 22:46:18 --> URI Class Initialized
INFO - 2023-04-29 22:46:18 --> Router Class Initialized
INFO - 2023-04-29 22:46:18 --> Output Class Initialized
INFO - 2023-04-29 22:46:18 --> Security Class Initialized
DEBUG - 2023-04-29 22:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:46:18 --> Input Class Initialized
INFO - 2023-04-29 22:46:18 --> Language Class Initialized
INFO - 2023-04-29 22:46:18 --> Loader Class Initialized
INFO - 2023-04-29 22:46:18 --> Helper loaded: url_helper
INFO - 2023-04-29 22:46:18 --> Helper loaded: form_helper
INFO - 2023-04-29 22:46:18 --> Helper loaded: file_helper
INFO - 2023-04-29 22:46:18 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:46:18 --> Form Validation Class Initialized
INFO - 2023-04-29 22:46:18 --> Upload Class Initialized
INFO - 2023-04-29 22:46:18 --> Model "M_auth" initialized
INFO - 2023-04-29 22:46:18 --> Model "M_user" initialized
INFO - 2023-04-29 22:46:18 --> Model "M_produk" initialized
INFO - 2023-04-29 22:46:18 --> Controller Class Initialized
INFO - 2023-04-29 22:46:18 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:46:18 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:46:18 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:46:18 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:46:18 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:46:18 --> Model "M_bank" initialized
INFO - 2023-04-29 22:46:18 --> Model "M_pesan" initialized
ERROR - 2023-04-29 22:46:18 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 22:46:18 --> Config Class Initialized
INFO - 2023-04-29 22:46:18 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:46:18 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:46:18 --> Utf8 Class Initialized
INFO - 2023-04-29 22:46:18 --> URI Class Initialized
INFO - 2023-04-29 22:46:18 --> Router Class Initialized
INFO - 2023-04-29 22:46:18 --> Output Class Initialized
INFO - 2023-04-29 22:46:18 --> Security Class Initialized
DEBUG - 2023-04-29 22:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:46:18 --> Input Class Initialized
INFO - 2023-04-29 22:46:18 --> Language Class Initialized
INFO - 2023-04-29 22:46:18 --> Loader Class Initialized
INFO - 2023-04-29 22:46:18 --> Helper loaded: url_helper
INFO - 2023-04-29 22:46:18 --> Helper loaded: form_helper
INFO - 2023-04-29 22:46:18 --> Helper loaded: file_helper
INFO - 2023-04-29 22:46:18 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:46:18 --> Form Validation Class Initialized
INFO - 2023-04-29 22:46:18 --> Upload Class Initialized
INFO - 2023-04-29 22:46:18 --> Model "M_auth" initialized
INFO - 2023-04-29 22:46:18 --> Model "M_user" initialized
INFO - 2023-04-29 22:46:18 --> Model "M_produk" initialized
INFO - 2023-04-29 22:46:18 --> Controller Class Initialized
INFO - 2023-04-29 22:46:18 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-04-29 22:46:18 --> Final output sent to browser
DEBUG - 2023-04-29 22:46:18 --> Total execution time: 0.0962
INFO - 2023-04-29 22:46:20 --> Config Class Initialized
INFO - 2023-04-29 22:46:20 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:46:20 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:46:20 --> Utf8 Class Initialized
INFO - 2023-04-29 22:46:20 --> URI Class Initialized
INFO - 2023-04-29 22:46:20 --> Router Class Initialized
INFO - 2023-04-29 22:46:20 --> Output Class Initialized
INFO - 2023-04-29 22:46:20 --> Security Class Initialized
DEBUG - 2023-04-29 22:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:46:20 --> Input Class Initialized
INFO - 2023-04-29 22:46:20 --> Language Class Initialized
INFO - 2023-04-29 22:46:20 --> Loader Class Initialized
INFO - 2023-04-29 22:46:20 --> Helper loaded: url_helper
INFO - 2023-04-29 22:46:20 --> Helper loaded: form_helper
INFO - 2023-04-29 22:46:20 --> Helper loaded: file_helper
INFO - 2023-04-29 22:46:20 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:46:20 --> Form Validation Class Initialized
INFO - 2023-04-29 22:46:20 --> Upload Class Initialized
INFO - 2023-04-29 22:46:20 --> Model "M_auth" initialized
INFO - 2023-04-29 22:46:20 --> Model "M_user" initialized
INFO - 2023-04-29 22:46:20 --> Model "M_produk" initialized
INFO - 2023-04-29 22:46:20 --> Controller Class Initialized
INFO - 2023-04-29 22:46:20 --> Model "M_produk" initialized
INFO - 2023-04-29 22:46:20 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-04-29 22:46:20 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:46:20 --> Final output sent to browser
DEBUG - 2023-04-29 22:46:20 --> Total execution time: 0.1298
INFO - 2023-04-29 22:47:22 --> Config Class Initialized
INFO - 2023-04-29 22:47:22 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:47:22 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:47:22 --> Utf8 Class Initialized
INFO - 2023-04-29 22:47:22 --> URI Class Initialized
INFO - 2023-04-29 22:47:22 --> Router Class Initialized
INFO - 2023-04-29 22:47:22 --> Output Class Initialized
INFO - 2023-04-29 22:47:22 --> Security Class Initialized
DEBUG - 2023-04-29 22:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:47:22 --> Input Class Initialized
INFO - 2023-04-29 22:47:22 --> Language Class Initialized
INFO - 2023-04-29 22:47:22 --> Loader Class Initialized
INFO - 2023-04-29 22:47:22 --> Helper loaded: url_helper
INFO - 2023-04-29 22:47:22 --> Helper loaded: form_helper
INFO - 2023-04-29 22:47:22 --> Helper loaded: file_helper
INFO - 2023-04-29 22:47:22 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:47:22 --> Form Validation Class Initialized
INFO - 2023-04-29 22:47:22 --> Upload Class Initialized
INFO - 2023-04-29 22:47:22 --> Model "M_auth" initialized
INFO - 2023-04-29 22:47:22 --> Model "M_user" initialized
INFO - 2023-04-29 22:47:22 --> Model "M_produk" initialized
INFO - 2023-04-29 22:47:22 --> Controller Class Initialized
INFO - 2023-04-29 22:47:22 --> Model "M_produk" initialized
INFO - 2023-04-29 22:47:22 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-04-29 22:47:22 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:47:22 --> Final output sent to browser
DEBUG - 2023-04-29 22:47:22 --> Total execution time: 0.1174
INFO - 2023-04-29 22:47:26 --> Config Class Initialized
INFO - 2023-04-29 22:47:26 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:47:26 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:47:26 --> Utf8 Class Initialized
INFO - 2023-04-29 22:47:26 --> URI Class Initialized
INFO - 2023-04-29 22:47:26 --> Router Class Initialized
INFO - 2023-04-29 22:47:26 --> Output Class Initialized
INFO - 2023-04-29 22:47:26 --> Security Class Initialized
DEBUG - 2023-04-29 22:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:47:26 --> Input Class Initialized
INFO - 2023-04-29 22:47:26 --> Language Class Initialized
INFO - 2023-04-29 22:47:26 --> Loader Class Initialized
INFO - 2023-04-29 22:47:26 --> Helper loaded: url_helper
INFO - 2023-04-29 22:47:26 --> Helper loaded: form_helper
INFO - 2023-04-29 22:47:26 --> Helper loaded: file_helper
INFO - 2023-04-29 22:47:26 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:47:26 --> Form Validation Class Initialized
INFO - 2023-04-29 22:47:26 --> Upload Class Initialized
INFO - 2023-04-29 22:47:26 --> Model "M_auth" initialized
INFO - 2023-04-29 22:47:26 --> Model "M_user" initialized
INFO - 2023-04-29 22:47:26 --> Model "M_produk" initialized
INFO - 2023-04-29 22:47:26 --> Controller Class Initialized
INFO - 2023-04-29 22:47:26 --> Model "M_produk" initialized
INFO - 2023-04-29 22:47:26 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_add_produk.php
INFO - 2023-04-29 22:47:26 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:47:26 --> Final output sent to browser
DEBUG - 2023-04-29 22:47:26 --> Total execution time: 0.1134
INFO - 2023-04-29 22:47:29 --> Config Class Initialized
INFO - 2023-04-29 22:47:29 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:47:29 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:47:29 --> Utf8 Class Initialized
INFO - 2023-04-29 22:47:29 --> URI Class Initialized
INFO - 2023-04-29 22:47:29 --> Router Class Initialized
INFO - 2023-04-29 22:47:29 --> Output Class Initialized
INFO - 2023-04-29 22:47:29 --> Security Class Initialized
DEBUG - 2023-04-29 22:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:47:29 --> Input Class Initialized
INFO - 2023-04-29 22:47:29 --> Language Class Initialized
INFO - 2023-04-29 22:47:29 --> Loader Class Initialized
INFO - 2023-04-29 22:47:29 --> Helper loaded: url_helper
INFO - 2023-04-29 22:47:29 --> Helper loaded: form_helper
INFO - 2023-04-29 22:47:29 --> Helper loaded: file_helper
INFO - 2023-04-29 22:47:29 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:47:29 --> Form Validation Class Initialized
INFO - 2023-04-29 22:47:29 --> Upload Class Initialized
INFO - 2023-04-29 22:47:29 --> Model "M_auth" initialized
INFO - 2023-04-29 22:47:29 --> Model "M_user" initialized
INFO - 2023-04-29 22:47:29 --> Model "M_produk" initialized
INFO - 2023-04-29 22:47:29 --> Controller Class Initialized
INFO - 2023-04-29 22:47:29 --> Model "M_produk" initialized
INFO - 2023-04-29 22:47:29 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-04-29 22:47:29 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:47:29 --> Final output sent to browser
DEBUG - 2023-04-29 22:47:29 --> Total execution time: 0.1033
INFO - 2023-04-29 22:47:31 --> Config Class Initialized
INFO - 2023-04-29 22:47:31 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:47:31 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:47:31 --> Utf8 Class Initialized
INFO - 2023-04-29 22:47:31 --> URI Class Initialized
INFO - 2023-04-29 22:47:31 --> Router Class Initialized
INFO - 2023-04-29 22:47:31 --> Output Class Initialized
INFO - 2023-04-29 22:47:31 --> Security Class Initialized
DEBUG - 2023-04-29 22:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:47:31 --> Input Class Initialized
INFO - 2023-04-29 22:47:31 --> Language Class Initialized
INFO - 2023-04-29 22:47:31 --> Loader Class Initialized
INFO - 2023-04-29 22:47:31 --> Helper loaded: url_helper
INFO - 2023-04-29 22:47:31 --> Helper loaded: form_helper
INFO - 2023-04-29 22:47:31 --> Helper loaded: file_helper
INFO - 2023-04-29 22:47:31 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:47:31 --> Form Validation Class Initialized
INFO - 2023-04-29 22:47:31 --> Upload Class Initialized
INFO - 2023-04-29 22:47:31 --> Model "M_auth" initialized
INFO - 2023-04-29 22:47:31 --> Model "M_user" initialized
INFO - 2023-04-29 22:47:31 --> Model "M_produk" initialized
INFO - 2023-04-29 22:47:31 --> Controller Class Initialized
INFO - 2023-04-29 22:47:31 --> Model "M_produk" initialized
INFO - 2023-04-29 22:47:31 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_edit_produk.php
INFO - 2023-04-29 22:47:31 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:47:31 --> Final output sent to browser
DEBUG - 2023-04-29 22:47:31 --> Total execution time: 0.1437
INFO - 2023-04-29 22:47:34 --> Config Class Initialized
INFO - 2023-04-29 22:47:34 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:47:34 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:47:34 --> Utf8 Class Initialized
INFO - 2023-04-29 22:47:34 --> URI Class Initialized
INFO - 2023-04-29 22:47:34 --> Router Class Initialized
INFO - 2023-04-29 22:47:34 --> Output Class Initialized
INFO - 2023-04-29 22:47:34 --> Security Class Initialized
DEBUG - 2023-04-29 22:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:47:34 --> Input Class Initialized
INFO - 2023-04-29 22:47:34 --> Language Class Initialized
INFO - 2023-04-29 22:47:34 --> Loader Class Initialized
INFO - 2023-04-29 22:47:34 --> Helper loaded: url_helper
INFO - 2023-04-29 22:47:34 --> Helper loaded: form_helper
INFO - 2023-04-29 22:47:34 --> Helper loaded: file_helper
INFO - 2023-04-29 22:47:34 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:47:34 --> Form Validation Class Initialized
INFO - 2023-04-29 22:47:34 --> Upload Class Initialized
INFO - 2023-04-29 22:47:34 --> Model "M_auth" initialized
INFO - 2023-04-29 22:47:34 --> Model "M_user" initialized
INFO - 2023-04-29 22:47:34 --> Model "M_produk" initialized
INFO - 2023-04-29 22:47:34 --> Controller Class Initialized
INFO - 2023-04-29 22:47:34 --> Model "M_produk" initialized
INFO - 2023-04-29 22:47:34 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-04-29 22:47:34 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:47:34 --> Final output sent to browser
DEBUG - 2023-04-29 22:47:34 --> Total execution time: 0.1142
INFO - 2023-04-29 22:47:39 --> Config Class Initialized
INFO - 2023-04-29 22:47:39 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:47:39 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:47:39 --> Utf8 Class Initialized
INFO - 2023-04-29 22:47:39 --> URI Class Initialized
INFO - 2023-04-29 22:47:39 --> Router Class Initialized
INFO - 2023-04-29 22:47:39 --> Output Class Initialized
INFO - 2023-04-29 22:47:39 --> Security Class Initialized
DEBUG - 2023-04-29 22:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:47:39 --> Input Class Initialized
INFO - 2023-04-29 22:47:39 --> Language Class Initialized
INFO - 2023-04-29 22:47:39 --> Loader Class Initialized
INFO - 2023-04-29 22:47:39 --> Helper loaded: url_helper
INFO - 2023-04-29 22:47:39 --> Helper loaded: form_helper
INFO - 2023-04-29 22:47:39 --> Helper loaded: file_helper
INFO - 2023-04-29 22:47:39 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:47:39 --> Form Validation Class Initialized
INFO - 2023-04-29 22:47:39 --> Upload Class Initialized
INFO - 2023-04-29 22:47:39 --> Model "M_auth" initialized
INFO - 2023-04-29 22:47:39 --> Model "M_user" initialized
INFO - 2023-04-29 22:47:39 --> Model "M_produk" initialized
INFO - 2023-04-29 22:47:39 --> Controller Class Initialized
INFO - 2023-04-29 22:47:39 --> Model "M_produk" initialized
INFO - 2023-04-29 22:47:39 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_type_merek.php
INFO - 2023-04-29 22:47:39 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:47:39 --> Final output sent to browser
DEBUG - 2023-04-29 22:47:39 --> Total execution time: 0.0939
INFO - 2023-04-29 22:49:02 --> Config Class Initialized
INFO - 2023-04-29 22:49:02 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:49:02 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:49:02 --> Utf8 Class Initialized
INFO - 2023-04-29 22:49:02 --> URI Class Initialized
INFO - 2023-04-29 22:49:02 --> Router Class Initialized
INFO - 2023-04-29 22:49:02 --> Output Class Initialized
INFO - 2023-04-29 22:49:02 --> Security Class Initialized
DEBUG - 2023-04-29 22:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:49:02 --> Input Class Initialized
INFO - 2023-04-29 22:49:02 --> Language Class Initialized
INFO - 2023-04-29 22:49:02 --> Loader Class Initialized
INFO - 2023-04-29 22:49:02 --> Helper loaded: url_helper
INFO - 2023-04-29 22:49:02 --> Helper loaded: form_helper
INFO - 2023-04-29 22:49:02 --> Helper loaded: file_helper
INFO - 2023-04-29 22:49:02 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:49:02 --> Form Validation Class Initialized
INFO - 2023-04-29 22:49:02 --> Upload Class Initialized
INFO - 2023-04-29 22:49:02 --> Model "M_auth" initialized
INFO - 2023-04-29 22:49:02 --> Model "M_user" initialized
INFO - 2023-04-29 22:49:02 --> Model "M_produk" initialized
INFO - 2023-04-29 22:49:02 --> Controller Class Initialized
INFO - 2023-04-29 22:49:02 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:49:02 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:49:02 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:49:02 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:49:02 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:49:02 --> Model "M_bank" initialized
INFO - 2023-04-29 22:49:02 --> Model "M_pesan" initialized
ERROR - 2023-04-29 22:49:02 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 22:49:02 --> Config Class Initialized
INFO - 2023-04-29 22:49:02 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:49:02 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:49:02 --> Utf8 Class Initialized
INFO - 2023-04-29 22:49:02 --> URI Class Initialized
INFO - 2023-04-29 22:49:02 --> Router Class Initialized
INFO - 2023-04-29 22:49:02 --> Output Class Initialized
INFO - 2023-04-29 22:49:02 --> Security Class Initialized
DEBUG - 2023-04-29 22:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:49:02 --> Input Class Initialized
INFO - 2023-04-29 22:49:02 --> Language Class Initialized
INFO - 2023-04-29 22:49:02 --> Loader Class Initialized
INFO - 2023-04-29 22:49:02 --> Helper loaded: url_helper
INFO - 2023-04-29 22:49:02 --> Helper loaded: form_helper
INFO - 2023-04-29 22:49:02 --> Helper loaded: file_helper
INFO - 2023-04-29 22:49:02 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:49:02 --> Form Validation Class Initialized
INFO - 2023-04-29 22:49:02 --> Upload Class Initialized
INFO - 2023-04-29 22:49:02 --> Model "M_auth" initialized
INFO - 2023-04-29 22:49:02 --> Model "M_user" initialized
INFO - 2023-04-29 22:49:02 --> Model "M_produk" initialized
INFO - 2023-04-29 22:49:02 --> Controller Class Initialized
INFO - 2023-04-29 22:49:02 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-04-29 22:49:02 --> Final output sent to browser
DEBUG - 2023-04-29 22:49:02 --> Total execution time: 0.1188
INFO - 2023-04-29 22:49:05 --> Config Class Initialized
INFO - 2023-04-29 22:49:05 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:49:05 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:49:05 --> Utf8 Class Initialized
INFO - 2023-04-29 22:49:05 --> URI Class Initialized
INFO - 2023-04-29 22:49:05 --> Router Class Initialized
INFO - 2023-04-29 22:49:05 --> Output Class Initialized
INFO - 2023-04-29 22:49:05 --> Security Class Initialized
DEBUG - 2023-04-29 22:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:49:05 --> Input Class Initialized
INFO - 2023-04-29 22:49:05 --> Language Class Initialized
INFO - 2023-04-29 22:49:05 --> Loader Class Initialized
INFO - 2023-04-29 22:49:05 --> Helper loaded: url_helper
INFO - 2023-04-29 22:49:05 --> Helper loaded: form_helper
INFO - 2023-04-29 22:49:05 --> Helper loaded: file_helper
INFO - 2023-04-29 22:49:05 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:49:05 --> Form Validation Class Initialized
INFO - 2023-04-29 22:49:05 --> Upload Class Initialized
INFO - 2023-04-29 22:49:05 --> Model "M_auth" initialized
INFO - 2023-04-29 22:49:05 --> Model "M_user" initialized
INFO - 2023-04-29 22:49:05 --> Model "M_produk" initialized
INFO - 2023-04-29 22:49:05 --> Controller Class Initialized
INFO - 2023-04-29 22:49:05 --> Model "M_produk" initialized
INFO - 2023-04-29 22:49:05 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_type_merek.php
INFO - 2023-04-29 22:49:05 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:49:05 --> Final output sent to browser
DEBUG - 2023-04-29 22:49:05 --> Total execution time: 0.1429
INFO - 2023-04-29 22:49:12 --> Config Class Initialized
INFO - 2023-04-29 22:49:12 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:49:12 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:49:12 --> Utf8 Class Initialized
INFO - 2023-04-29 22:49:12 --> URI Class Initialized
INFO - 2023-04-29 22:49:12 --> Router Class Initialized
INFO - 2023-04-29 22:49:12 --> Output Class Initialized
INFO - 2023-04-29 22:49:12 --> Security Class Initialized
DEBUG - 2023-04-29 22:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:49:12 --> Input Class Initialized
INFO - 2023-04-29 22:49:12 --> Language Class Initialized
INFO - 2023-04-29 22:49:12 --> Loader Class Initialized
INFO - 2023-04-29 22:49:12 --> Helper loaded: url_helper
INFO - 2023-04-29 22:49:12 --> Helper loaded: form_helper
INFO - 2023-04-29 22:49:12 --> Helper loaded: file_helper
INFO - 2023-04-29 22:49:12 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:49:12 --> Form Validation Class Initialized
INFO - 2023-04-29 22:49:12 --> Upload Class Initialized
INFO - 2023-04-29 22:49:12 --> Model "M_auth" initialized
INFO - 2023-04-29 22:49:12 --> Model "M_user" initialized
INFO - 2023-04-29 22:49:12 --> Model "M_produk" initialized
INFO - 2023-04-29 22:49:12 --> Controller Class Initialized
INFO - 2023-04-29 22:49:12 --> Model "M_produk" initialized
INFO - 2023-04-29 22:49:12 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-04-29 22:49:12 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:49:12 --> Final output sent to browser
DEBUG - 2023-04-29 22:49:12 --> Total execution time: 0.1129
INFO - 2023-04-29 22:49:14 --> Config Class Initialized
INFO - 2023-04-29 22:49:14 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:49:14 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:49:14 --> Utf8 Class Initialized
INFO - 2023-04-29 22:49:14 --> URI Class Initialized
INFO - 2023-04-29 22:49:14 --> Router Class Initialized
INFO - 2023-04-29 22:49:14 --> Output Class Initialized
INFO - 2023-04-29 22:49:14 --> Security Class Initialized
DEBUG - 2023-04-29 22:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:49:14 --> Input Class Initialized
INFO - 2023-04-29 22:49:14 --> Language Class Initialized
INFO - 2023-04-29 22:49:14 --> Loader Class Initialized
INFO - 2023-04-29 22:49:14 --> Helper loaded: url_helper
INFO - 2023-04-29 22:49:14 --> Helper loaded: form_helper
INFO - 2023-04-29 22:49:14 --> Helper loaded: file_helper
INFO - 2023-04-29 22:49:14 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:49:14 --> Form Validation Class Initialized
INFO - 2023-04-29 22:49:14 --> Upload Class Initialized
INFO - 2023-04-29 22:49:14 --> Model "M_auth" initialized
INFO - 2023-04-29 22:49:14 --> Model "M_user" initialized
INFO - 2023-04-29 22:49:14 --> Model "M_produk" initialized
INFO - 2023-04-29 22:49:14 --> Controller Class Initialized
INFO - 2023-04-29 22:49:14 --> Model "M_produk" initialized
INFO - 2023-04-29 22:49:14 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_typeproduk.php
INFO - 2023-04-29 22:49:14 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:49:14 --> Final output sent to browser
DEBUG - 2023-04-29 22:49:14 --> Total execution time: 0.1117
INFO - 2023-04-29 22:49:44 --> Config Class Initialized
INFO - 2023-04-29 22:49:44 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:49:44 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:49:44 --> Utf8 Class Initialized
INFO - 2023-04-29 22:49:44 --> URI Class Initialized
INFO - 2023-04-29 22:49:44 --> Router Class Initialized
INFO - 2023-04-29 22:49:44 --> Output Class Initialized
INFO - 2023-04-29 22:49:44 --> Security Class Initialized
DEBUG - 2023-04-29 22:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:49:44 --> Input Class Initialized
INFO - 2023-04-29 22:49:44 --> Language Class Initialized
INFO - 2023-04-29 22:49:44 --> Loader Class Initialized
INFO - 2023-04-29 22:49:44 --> Helper loaded: url_helper
INFO - 2023-04-29 22:49:44 --> Helper loaded: form_helper
INFO - 2023-04-29 22:49:44 --> Helper loaded: file_helper
INFO - 2023-04-29 22:49:44 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:49:44 --> Form Validation Class Initialized
INFO - 2023-04-29 22:49:44 --> Upload Class Initialized
INFO - 2023-04-29 22:49:44 --> Model "M_auth" initialized
INFO - 2023-04-29 22:49:44 --> Model "M_user" initialized
INFO - 2023-04-29 22:49:44 --> Model "M_produk" initialized
INFO - 2023-04-29 22:49:44 --> Controller Class Initialized
INFO - 2023-04-29 22:49:44 --> Model "M_produk" initialized
INFO - 2023-04-29 22:49:44 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_typeproduk.php
INFO - 2023-04-29 22:49:44 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:49:44 --> Final output sent to browser
DEBUG - 2023-04-29 22:49:44 --> Total execution time: 0.1148
INFO - 2023-04-29 22:50:12 --> Config Class Initialized
INFO - 2023-04-29 22:50:12 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:50:12 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:50:12 --> Utf8 Class Initialized
INFO - 2023-04-29 22:50:12 --> URI Class Initialized
INFO - 2023-04-29 22:50:12 --> Router Class Initialized
INFO - 2023-04-29 22:50:12 --> Output Class Initialized
INFO - 2023-04-29 22:50:12 --> Security Class Initialized
DEBUG - 2023-04-29 22:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:50:12 --> Input Class Initialized
INFO - 2023-04-29 22:50:12 --> Language Class Initialized
INFO - 2023-04-29 22:50:12 --> Loader Class Initialized
INFO - 2023-04-29 22:50:12 --> Helper loaded: url_helper
INFO - 2023-04-29 22:50:12 --> Helper loaded: form_helper
INFO - 2023-04-29 22:50:12 --> Helper loaded: file_helper
INFO - 2023-04-29 22:50:12 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:50:12 --> Form Validation Class Initialized
INFO - 2023-04-29 22:50:12 --> Upload Class Initialized
INFO - 2023-04-29 22:50:12 --> Model "M_auth" initialized
INFO - 2023-04-29 22:50:12 --> Model "M_user" initialized
INFO - 2023-04-29 22:50:12 --> Model "M_produk" initialized
INFO - 2023-04-29 22:50:12 --> Controller Class Initialized
INFO - 2023-04-29 22:50:12 --> Model "M_produk" initialized
INFO - 2023-04-29 22:50:12 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_typeproduk.php
INFO - 2023-04-29 22:50:12 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:50:12 --> Final output sent to browser
DEBUG - 2023-04-29 22:50:12 --> Total execution time: 0.1376
INFO - 2023-04-29 22:50:14 --> Config Class Initialized
INFO - 2023-04-29 22:50:14 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:50:14 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:50:14 --> Utf8 Class Initialized
INFO - 2023-04-29 22:50:14 --> URI Class Initialized
INFO - 2023-04-29 22:50:14 --> Router Class Initialized
INFO - 2023-04-29 22:50:14 --> Output Class Initialized
INFO - 2023-04-29 22:50:14 --> Security Class Initialized
DEBUG - 2023-04-29 22:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:50:14 --> Input Class Initialized
INFO - 2023-04-29 22:50:14 --> Language Class Initialized
INFO - 2023-04-29 22:50:14 --> Loader Class Initialized
INFO - 2023-04-29 22:50:14 --> Helper loaded: url_helper
INFO - 2023-04-29 22:50:14 --> Helper loaded: form_helper
INFO - 2023-04-29 22:50:14 --> Helper loaded: file_helper
INFO - 2023-04-29 22:50:14 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:50:14 --> Form Validation Class Initialized
INFO - 2023-04-29 22:50:15 --> Upload Class Initialized
INFO - 2023-04-29 22:50:15 --> Model "M_auth" initialized
INFO - 2023-04-29 22:50:15 --> Model "M_user" initialized
INFO - 2023-04-29 22:50:15 --> Model "M_produk" initialized
INFO - 2023-04-29 22:50:15 --> Controller Class Initialized
INFO - 2023-04-29 22:50:15 --> Model "M_produk" initialized
INFO - 2023-04-29 22:50:15 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_typeproduk.php
INFO - 2023-04-29 22:50:15 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:50:15 --> Final output sent to browser
DEBUG - 2023-04-29 22:50:15 --> Total execution time: 0.1005
INFO - 2023-04-29 22:50:17 --> Config Class Initialized
INFO - 2023-04-29 22:50:17 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:50:17 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:50:17 --> Utf8 Class Initialized
INFO - 2023-04-29 22:50:17 --> URI Class Initialized
INFO - 2023-04-29 22:50:17 --> Router Class Initialized
INFO - 2023-04-29 22:50:17 --> Output Class Initialized
INFO - 2023-04-29 22:50:17 --> Security Class Initialized
DEBUG - 2023-04-29 22:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:50:17 --> Input Class Initialized
INFO - 2023-04-29 22:50:17 --> Language Class Initialized
INFO - 2023-04-29 22:50:17 --> Loader Class Initialized
INFO - 2023-04-29 22:50:17 --> Helper loaded: url_helper
INFO - 2023-04-29 22:50:17 --> Helper loaded: form_helper
INFO - 2023-04-29 22:50:17 --> Helper loaded: file_helper
INFO - 2023-04-29 22:50:17 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:50:17 --> Form Validation Class Initialized
INFO - 2023-04-29 22:50:17 --> Upload Class Initialized
INFO - 2023-04-29 22:50:17 --> Model "M_auth" initialized
INFO - 2023-04-29 22:50:17 --> Model "M_user" initialized
INFO - 2023-04-29 22:50:17 --> Model "M_produk" initialized
INFO - 2023-04-29 22:50:17 --> Controller Class Initialized
INFO - 2023-04-29 22:50:17 --> Model "M_produk" initialized
INFO - 2023-04-29 22:50:17 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_type_merek.php
INFO - 2023-04-29 22:50:17 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:50:17 --> Final output sent to browser
DEBUG - 2023-04-29 22:50:17 --> Total execution time: 0.1019
INFO - 2023-04-29 22:50:26 --> Config Class Initialized
INFO - 2023-04-29 22:50:26 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:50:26 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:50:26 --> Utf8 Class Initialized
INFO - 2023-04-29 22:50:26 --> URI Class Initialized
INFO - 2023-04-29 22:50:26 --> Router Class Initialized
INFO - 2023-04-29 22:50:26 --> Output Class Initialized
INFO - 2023-04-29 22:50:26 --> Security Class Initialized
DEBUG - 2023-04-29 22:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:50:26 --> Input Class Initialized
INFO - 2023-04-29 22:50:26 --> Language Class Initialized
INFO - 2023-04-29 22:50:26 --> Loader Class Initialized
INFO - 2023-04-29 22:50:26 --> Helper loaded: url_helper
INFO - 2023-04-29 22:50:26 --> Helper loaded: form_helper
INFO - 2023-04-29 22:50:26 --> Helper loaded: file_helper
INFO - 2023-04-29 22:50:26 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:50:26 --> Form Validation Class Initialized
INFO - 2023-04-29 22:50:26 --> Upload Class Initialized
INFO - 2023-04-29 22:50:26 --> Model "M_auth" initialized
INFO - 2023-04-29 22:50:26 --> Model "M_user" initialized
INFO - 2023-04-29 22:50:26 --> Model "M_produk" initialized
INFO - 2023-04-29 22:50:26 --> Controller Class Initialized
INFO - 2023-04-29 22:50:26 --> Model "M_produk" initialized
INFO - 2023-04-29 22:50:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2023-04-29 22:50:26 --> Upload class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:50:26 --> Config Class Initialized
INFO - 2023-04-29 22:50:26 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:50:26 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:50:26 --> Utf8 Class Initialized
INFO - 2023-04-29 22:50:26 --> URI Class Initialized
INFO - 2023-04-29 22:50:26 --> Router Class Initialized
INFO - 2023-04-29 22:50:26 --> Output Class Initialized
INFO - 2023-04-29 22:50:26 --> Security Class Initialized
DEBUG - 2023-04-29 22:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:50:26 --> Input Class Initialized
INFO - 2023-04-29 22:50:26 --> Language Class Initialized
INFO - 2023-04-29 22:50:26 --> Loader Class Initialized
INFO - 2023-04-29 22:50:26 --> Helper loaded: url_helper
INFO - 2023-04-29 22:50:26 --> Helper loaded: form_helper
INFO - 2023-04-29 22:50:26 --> Helper loaded: file_helper
INFO - 2023-04-29 22:50:26 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:50:26 --> Form Validation Class Initialized
INFO - 2023-04-29 22:50:26 --> Upload Class Initialized
INFO - 2023-04-29 22:50:26 --> Model "M_auth" initialized
INFO - 2023-04-29 22:50:26 --> Model "M_user" initialized
INFO - 2023-04-29 22:50:26 --> Model "M_produk" initialized
INFO - 2023-04-29 22:50:26 --> Controller Class Initialized
INFO - 2023-04-29 22:50:26 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:50:26 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:50:26 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:50:26 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:50:26 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:50:26 --> Model "M_bank" initialized
INFO - 2023-04-29 22:50:26 --> Model "M_pesan" initialized
ERROR - 2023-04-29 22:50:26 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 22:50:26 --> Config Class Initialized
INFO - 2023-04-29 22:50:26 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:50:26 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:50:26 --> Utf8 Class Initialized
INFO - 2023-04-29 22:50:26 --> URI Class Initialized
INFO - 2023-04-29 22:50:26 --> Router Class Initialized
INFO - 2023-04-29 22:50:26 --> Output Class Initialized
INFO - 2023-04-29 22:50:26 --> Security Class Initialized
DEBUG - 2023-04-29 22:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:50:26 --> Input Class Initialized
INFO - 2023-04-29 22:50:26 --> Language Class Initialized
INFO - 2023-04-29 22:50:26 --> Loader Class Initialized
INFO - 2023-04-29 22:50:26 --> Helper loaded: url_helper
INFO - 2023-04-29 22:50:26 --> Helper loaded: form_helper
INFO - 2023-04-29 22:50:26 --> Helper loaded: file_helper
INFO - 2023-04-29 22:50:26 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:50:26 --> Form Validation Class Initialized
INFO - 2023-04-29 22:50:26 --> Upload Class Initialized
INFO - 2023-04-29 22:50:26 --> Model "M_auth" initialized
INFO - 2023-04-29 22:50:26 --> Model "M_user" initialized
INFO - 2023-04-29 22:50:26 --> Model "M_produk" initialized
INFO - 2023-04-29 22:50:26 --> Controller Class Initialized
INFO - 2023-04-29 22:50:26 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-04-29 22:50:26 --> Final output sent to browser
DEBUG - 2023-04-29 22:50:26 --> Total execution time: 0.1063
INFO - 2023-04-29 22:50:29 --> Config Class Initialized
INFO - 2023-04-29 22:50:29 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:50:29 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:50:29 --> Utf8 Class Initialized
INFO - 2023-04-29 22:50:29 --> URI Class Initialized
INFO - 2023-04-29 22:50:29 --> Router Class Initialized
INFO - 2023-04-29 22:50:29 --> Output Class Initialized
INFO - 2023-04-29 22:50:29 --> Security Class Initialized
DEBUG - 2023-04-29 22:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:50:29 --> Input Class Initialized
INFO - 2023-04-29 22:50:29 --> Language Class Initialized
INFO - 2023-04-29 22:50:29 --> Loader Class Initialized
INFO - 2023-04-29 22:50:29 --> Helper loaded: url_helper
INFO - 2023-04-29 22:50:29 --> Helper loaded: form_helper
INFO - 2023-04-29 22:50:29 --> Helper loaded: file_helper
INFO - 2023-04-29 22:50:29 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:50:29 --> Form Validation Class Initialized
INFO - 2023-04-29 22:50:29 --> Upload Class Initialized
INFO - 2023-04-29 22:50:29 --> Model "M_auth" initialized
INFO - 2023-04-29 22:50:29 --> Model "M_user" initialized
INFO - 2023-04-29 22:50:29 --> Model "M_produk" initialized
INFO - 2023-04-29 22:50:29 --> Controller Class Initialized
INFO - 2023-04-29 22:50:29 --> Model "M_produk" initialized
INFO - 2023-04-29 22:50:29 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_type_merek.php
INFO - 2023-04-29 22:50:29 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:50:29 --> Final output sent to browser
DEBUG - 2023-04-29 22:50:29 --> Total execution time: 0.1165
INFO - 2023-04-29 22:50:30 --> Config Class Initialized
INFO - 2023-04-29 22:50:30 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:50:30 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:50:30 --> Utf8 Class Initialized
INFO - 2023-04-29 22:50:30 --> URI Class Initialized
INFO - 2023-04-29 22:50:30 --> Router Class Initialized
INFO - 2023-04-29 22:50:30 --> Output Class Initialized
INFO - 2023-04-29 22:50:30 --> Security Class Initialized
DEBUG - 2023-04-29 22:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:50:30 --> Input Class Initialized
INFO - 2023-04-29 22:50:30 --> Language Class Initialized
INFO - 2023-04-29 22:50:30 --> Loader Class Initialized
INFO - 2023-04-29 22:50:30 --> Helper loaded: url_helper
INFO - 2023-04-29 22:50:30 --> Helper loaded: form_helper
INFO - 2023-04-29 22:50:30 --> Helper loaded: file_helper
INFO - 2023-04-29 22:50:30 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:50:30 --> Form Validation Class Initialized
INFO - 2023-04-29 22:50:30 --> Upload Class Initialized
INFO - 2023-04-29 22:50:30 --> Model "M_auth" initialized
INFO - 2023-04-29 22:50:30 --> Model "M_user" initialized
INFO - 2023-04-29 22:50:30 --> Model "M_produk" initialized
INFO - 2023-04-29 22:50:30 --> Controller Class Initialized
INFO - 2023-04-29 22:50:30 --> Model "M_produk" initialized
INFO - 2023-04-29 22:50:30 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_type_merek.php
INFO - 2023-04-29 22:50:30 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:50:30 --> Final output sent to browser
DEBUG - 2023-04-29 22:50:30 --> Total execution time: 0.1589
INFO - 2023-04-29 22:50:32 --> Config Class Initialized
INFO - 2023-04-29 22:50:32 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:50:32 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:50:32 --> Utf8 Class Initialized
INFO - 2023-04-29 22:50:32 --> URI Class Initialized
INFO - 2023-04-29 22:50:32 --> Router Class Initialized
INFO - 2023-04-29 22:50:32 --> Output Class Initialized
INFO - 2023-04-29 22:50:32 --> Security Class Initialized
DEBUG - 2023-04-29 22:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:50:32 --> Input Class Initialized
INFO - 2023-04-29 22:50:32 --> Language Class Initialized
INFO - 2023-04-29 22:50:32 --> Loader Class Initialized
INFO - 2023-04-29 22:50:32 --> Helper loaded: url_helper
INFO - 2023-04-29 22:50:32 --> Helper loaded: form_helper
INFO - 2023-04-29 22:50:32 --> Helper loaded: file_helper
INFO - 2023-04-29 22:50:32 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:50:32 --> Form Validation Class Initialized
INFO - 2023-04-29 22:50:32 --> Upload Class Initialized
INFO - 2023-04-29 22:50:32 --> Model "M_auth" initialized
INFO - 2023-04-29 22:50:32 --> Model "M_user" initialized
INFO - 2023-04-29 22:50:32 --> Model "M_produk" initialized
INFO - 2023-04-29 22:50:32 --> Controller Class Initialized
INFO - 2023-04-29 22:50:32 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 22:50:32 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:50:32 --> Final output sent to browser
DEBUG - 2023-04-29 22:50:32 --> Total execution time: 0.1228
INFO - 2023-04-29 22:50:34 --> Config Class Initialized
INFO - 2023-04-29 22:50:34 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:50:34 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:50:34 --> Utf8 Class Initialized
INFO - 2023-04-29 22:50:34 --> URI Class Initialized
INFO - 2023-04-29 22:50:34 --> Router Class Initialized
INFO - 2023-04-29 22:50:34 --> Output Class Initialized
INFO - 2023-04-29 22:50:34 --> Security Class Initialized
DEBUG - 2023-04-29 22:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:50:34 --> Input Class Initialized
INFO - 2023-04-29 22:50:34 --> Language Class Initialized
INFO - 2023-04-29 22:50:34 --> Loader Class Initialized
INFO - 2023-04-29 22:50:34 --> Helper loaded: url_helper
INFO - 2023-04-29 22:50:34 --> Helper loaded: form_helper
INFO - 2023-04-29 22:50:34 --> Helper loaded: file_helper
INFO - 2023-04-29 22:50:34 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:50:34 --> Form Validation Class Initialized
INFO - 2023-04-29 22:50:34 --> Upload Class Initialized
INFO - 2023-04-29 22:50:34 --> Model "M_auth" initialized
INFO - 2023-04-29 22:50:34 --> Model "M_user" initialized
INFO - 2023-04-29 22:50:34 --> Model "M_produk" initialized
INFO - 2023-04-29 22:50:34 --> Controller Class Initialized
INFO - 2023-04-29 22:50:34 --> Model "M_produk" initialized
INFO - 2023-04-29 22:50:34 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_type_merek.php
INFO - 2023-04-29 22:50:34 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:50:34 --> Final output sent to browser
DEBUG - 2023-04-29 22:50:34 --> Total execution time: 0.0959
INFO - 2023-04-29 22:50:36 --> Config Class Initialized
INFO - 2023-04-29 22:50:36 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:50:36 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:50:36 --> Utf8 Class Initialized
INFO - 2023-04-29 22:50:36 --> URI Class Initialized
INFO - 2023-04-29 22:50:36 --> Router Class Initialized
INFO - 2023-04-29 22:50:36 --> Output Class Initialized
INFO - 2023-04-29 22:50:36 --> Security Class Initialized
DEBUG - 2023-04-29 22:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:50:36 --> Input Class Initialized
INFO - 2023-04-29 22:50:36 --> Language Class Initialized
INFO - 2023-04-29 22:50:36 --> Loader Class Initialized
INFO - 2023-04-29 22:50:36 --> Helper loaded: url_helper
INFO - 2023-04-29 22:50:36 --> Helper loaded: form_helper
INFO - 2023-04-29 22:50:36 --> Helper loaded: file_helper
INFO - 2023-04-29 22:50:36 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:50:36 --> Form Validation Class Initialized
INFO - 2023-04-29 22:50:36 --> Upload Class Initialized
INFO - 2023-04-29 22:50:36 --> Model "M_auth" initialized
INFO - 2023-04-29 22:50:36 --> Model "M_user" initialized
INFO - 2023-04-29 22:50:36 --> Model "M_produk" initialized
INFO - 2023-04-29 22:50:36 --> Controller Class Initialized
INFO - 2023-04-29 22:50:36 --> Model "M_produk" initialized
INFO - 2023-04-29 22:50:36 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_type_merek.php
INFO - 2023-04-29 22:50:36 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:50:36 --> Final output sent to browser
DEBUG - 2023-04-29 22:50:36 --> Total execution time: 0.0955
INFO - 2023-04-29 22:50:48 --> Config Class Initialized
INFO - 2023-04-29 22:50:48 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:50:48 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:50:48 --> Utf8 Class Initialized
INFO - 2023-04-29 22:50:48 --> URI Class Initialized
INFO - 2023-04-29 22:50:48 --> Router Class Initialized
INFO - 2023-04-29 22:50:48 --> Output Class Initialized
INFO - 2023-04-29 22:50:48 --> Security Class Initialized
DEBUG - 2023-04-29 22:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:50:48 --> Input Class Initialized
INFO - 2023-04-29 22:50:48 --> Language Class Initialized
INFO - 2023-04-29 22:50:48 --> Loader Class Initialized
INFO - 2023-04-29 22:50:48 --> Helper loaded: url_helper
INFO - 2023-04-29 22:50:48 --> Helper loaded: form_helper
INFO - 2023-04-29 22:50:48 --> Helper loaded: file_helper
INFO - 2023-04-29 22:50:48 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:50:48 --> Form Validation Class Initialized
INFO - 2023-04-29 22:50:48 --> Upload Class Initialized
INFO - 2023-04-29 22:50:48 --> Model "M_auth" initialized
INFO - 2023-04-29 22:50:48 --> Model "M_user" initialized
INFO - 2023-04-29 22:50:48 --> Model "M_produk" initialized
INFO - 2023-04-29 22:50:48 --> Controller Class Initialized
INFO - 2023-04-29 22:50:48 --> Model "M_produk" initialized
INFO - 2023-04-29 22:50:48 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2023-04-29 22:50:48 --> Upload class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:50:48 --> Config Class Initialized
INFO - 2023-04-29 22:50:48 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:50:48 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:50:48 --> Utf8 Class Initialized
INFO - 2023-04-29 22:50:48 --> URI Class Initialized
INFO - 2023-04-29 22:50:48 --> Router Class Initialized
INFO - 2023-04-29 22:50:48 --> Output Class Initialized
INFO - 2023-04-29 22:50:48 --> Security Class Initialized
DEBUG - 2023-04-29 22:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:50:49 --> Input Class Initialized
INFO - 2023-04-29 22:50:49 --> Language Class Initialized
INFO - 2023-04-29 22:50:49 --> Loader Class Initialized
INFO - 2023-04-29 22:50:49 --> Helper loaded: url_helper
INFO - 2023-04-29 22:50:49 --> Helper loaded: form_helper
INFO - 2023-04-29 22:50:49 --> Helper loaded: file_helper
INFO - 2023-04-29 22:50:49 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:50:49 --> Form Validation Class Initialized
INFO - 2023-04-29 22:50:49 --> Upload Class Initialized
INFO - 2023-04-29 22:50:49 --> Model "M_auth" initialized
INFO - 2023-04-29 22:50:49 --> Model "M_user" initialized
INFO - 2023-04-29 22:50:49 --> Model "M_produk" initialized
INFO - 2023-04-29 22:50:49 --> Controller Class Initialized
INFO - 2023-04-29 22:50:49 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:50:49 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:50:49 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:50:49 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:50:49 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:50:49 --> Model "M_bank" initialized
INFO - 2023-04-29 22:50:49 --> Model "M_pesan" initialized
ERROR - 2023-04-29 22:50:49 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 22:50:49 --> Config Class Initialized
INFO - 2023-04-29 22:50:49 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:50:49 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:50:49 --> Utf8 Class Initialized
INFO - 2023-04-29 22:50:49 --> URI Class Initialized
INFO - 2023-04-29 22:50:49 --> Router Class Initialized
INFO - 2023-04-29 22:50:49 --> Output Class Initialized
INFO - 2023-04-29 22:50:49 --> Security Class Initialized
DEBUG - 2023-04-29 22:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:50:49 --> Input Class Initialized
INFO - 2023-04-29 22:50:49 --> Language Class Initialized
INFO - 2023-04-29 22:50:49 --> Loader Class Initialized
INFO - 2023-04-29 22:50:49 --> Helper loaded: url_helper
INFO - 2023-04-29 22:50:49 --> Helper loaded: form_helper
INFO - 2023-04-29 22:50:49 --> Helper loaded: file_helper
INFO - 2023-04-29 22:50:49 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:50:49 --> Form Validation Class Initialized
INFO - 2023-04-29 22:50:49 --> Upload Class Initialized
INFO - 2023-04-29 22:50:49 --> Model "M_auth" initialized
INFO - 2023-04-29 22:50:49 --> Model "M_user" initialized
INFO - 2023-04-29 22:50:49 --> Model "M_produk" initialized
INFO - 2023-04-29 22:50:49 --> Controller Class Initialized
INFO - 2023-04-29 22:50:49 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-04-29 22:50:49 --> Final output sent to browser
DEBUG - 2023-04-29 22:50:49 --> Total execution time: 0.0863
INFO - 2023-04-29 22:50:54 --> Config Class Initialized
INFO - 2023-04-29 22:50:54 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:50:54 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:50:54 --> Utf8 Class Initialized
INFO - 2023-04-29 22:50:54 --> URI Class Initialized
INFO - 2023-04-29 22:50:54 --> Router Class Initialized
INFO - 2023-04-29 22:50:54 --> Output Class Initialized
INFO - 2023-04-29 22:50:54 --> Security Class Initialized
DEBUG - 2023-04-29 22:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:50:54 --> Input Class Initialized
INFO - 2023-04-29 22:50:54 --> Language Class Initialized
INFO - 2023-04-29 22:50:54 --> Loader Class Initialized
INFO - 2023-04-29 22:50:54 --> Helper loaded: url_helper
INFO - 2023-04-29 22:50:54 --> Helper loaded: form_helper
INFO - 2023-04-29 22:50:54 --> Helper loaded: file_helper
INFO - 2023-04-29 22:50:54 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:50:54 --> Form Validation Class Initialized
INFO - 2023-04-29 22:50:54 --> Upload Class Initialized
INFO - 2023-04-29 22:50:54 --> Model "M_auth" initialized
INFO - 2023-04-29 22:50:54 --> Model "M_user" initialized
INFO - 2023-04-29 22:50:54 --> Model "M_produk" initialized
INFO - 2023-04-29 22:50:54 --> Controller Class Initialized
INFO - 2023-04-29 22:50:54 --> Model "M_produk" initialized
INFO - 2023-04-29 22:50:54 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_type_merek.php
INFO - 2023-04-29 22:50:54 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:50:54 --> Final output sent to browser
DEBUG - 2023-04-29 22:50:54 --> Total execution time: 0.1165
INFO - 2023-04-29 22:50:59 --> Config Class Initialized
INFO - 2023-04-29 22:50:59 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:50:59 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:50:59 --> Utf8 Class Initialized
INFO - 2023-04-29 22:50:59 --> URI Class Initialized
INFO - 2023-04-29 22:50:59 --> Router Class Initialized
INFO - 2023-04-29 22:50:59 --> Output Class Initialized
INFO - 2023-04-29 22:50:59 --> Security Class Initialized
DEBUG - 2023-04-29 22:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:50:59 --> Input Class Initialized
INFO - 2023-04-29 22:50:59 --> Language Class Initialized
INFO - 2023-04-29 22:50:59 --> Loader Class Initialized
INFO - 2023-04-29 22:50:59 --> Helper loaded: url_helper
INFO - 2023-04-29 22:50:59 --> Helper loaded: form_helper
INFO - 2023-04-29 22:50:59 --> Helper loaded: file_helper
INFO - 2023-04-29 22:50:59 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:50:59 --> Form Validation Class Initialized
INFO - 2023-04-29 22:50:59 --> Upload Class Initialized
INFO - 2023-04-29 22:50:59 --> Model "M_auth" initialized
INFO - 2023-04-29 22:50:59 --> Model "M_user" initialized
INFO - 2023-04-29 22:50:59 --> Model "M_produk" initialized
INFO - 2023-04-29 22:50:59 --> Controller Class Initialized
INFO - 2023-04-29 22:50:59 --> Model "M_produk" initialized
INFO - 2023-04-29 22:50:59 --> Config Class Initialized
INFO - 2023-04-29 22:50:59 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:50:59 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:50:59 --> Utf8 Class Initialized
INFO - 2023-04-29 22:50:59 --> URI Class Initialized
INFO - 2023-04-29 22:50:59 --> Router Class Initialized
INFO - 2023-04-29 22:50:59 --> Output Class Initialized
INFO - 2023-04-29 22:50:59 --> Security Class Initialized
DEBUG - 2023-04-29 22:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:50:59 --> Input Class Initialized
INFO - 2023-04-29 22:50:59 --> Language Class Initialized
INFO - 2023-04-29 22:50:59 --> Loader Class Initialized
INFO - 2023-04-29 22:50:59 --> Helper loaded: url_helper
INFO - 2023-04-29 22:50:59 --> Helper loaded: form_helper
INFO - 2023-04-29 22:50:59 --> Helper loaded: file_helper
INFO - 2023-04-29 22:50:59 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:50:59 --> Form Validation Class Initialized
INFO - 2023-04-29 22:50:59 --> Upload Class Initialized
INFO - 2023-04-29 22:50:59 --> Model "M_auth" initialized
INFO - 2023-04-29 22:50:59 --> Model "M_user" initialized
INFO - 2023-04-29 22:50:59 --> Model "M_produk" initialized
INFO - 2023-04-29 22:50:59 --> Controller Class Initialized
INFO - 2023-04-29 22:50:59 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:50:59 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:50:59 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:50:59 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:50:59 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:50:59 --> Model "M_bank" initialized
INFO - 2023-04-29 22:50:59 --> Model "M_pesan" initialized
ERROR - 2023-04-29 22:50:59 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 22:50:59 --> Config Class Initialized
INFO - 2023-04-29 22:50:59 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:50:59 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:50:59 --> Utf8 Class Initialized
INFO - 2023-04-29 22:50:59 --> URI Class Initialized
INFO - 2023-04-29 22:50:59 --> Router Class Initialized
INFO - 2023-04-29 22:50:59 --> Output Class Initialized
INFO - 2023-04-29 22:50:59 --> Security Class Initialized
DEBUG - 2023-04-29 22:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:50:59 --> Input Class Initialized
INFO - 2023-04-29 22:50:59 --> Language Class Initialized
INFO - 2023-04-29 22:50:59 --> Loader Class Initialized
INFO - 2023-04-29 22:50:59 --> Helper loaded: url_helper
INFO - 2023-04-29 22:50:59 --> Helper loaded: form_helper
INFO - 2023-04-29 22:50:59 --> Helper loaded: file_helper
INFO - 2023-04-29 22:50:59 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:50:59 --> Form Validation Class Initialized
INFO - 2023-04-29 22:50:59 --> Upload Class Initialized
INFO - 2023-04-29 22:50:59 --> Model "M_auth" initialized
INFO - 2023-04-29 22:50:59 --> Model "M_user" initialized
INFO - 2023-04-29 22:50:59 --> Model "M_produk" initialized
INFO - 2023-04-29 22:50:59 --> Controller Class Initialized
INFO - 2023-04-29 22:50:59 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-04-29 22:50:59 --> Final output sent to browser
DEBUG - 2023-04-29 22:50:59 --> Total execution time: 0.0860
INFO - 2023-04-29 22:51:23 --> Config Class Initialized
INFO - 2023-04-29 22:51:23 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:51:23 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:51:23 --> Utf8 Class Initialized
INFO - 2023-04-29 22:51:23 --> URI Class Initialized
INFO - 2023-04-29 22:51:23 --> Router Class Initialized
INFO - 2023-04-29 22:51:23 --> Output Class Initialized
INFO - 2023-04-29 22:51:23 --> Security Class Initialized
DEBUG - 2023-04-29 22:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:51:23 --> Input Class Initialized
INFO - 2023-04-29 22:51:23 --> Language Class Initialized
INFO - 2023-04-29 22:51:23 --> Loader Class Initialized
INFO - 2023-04-29 22:51:23 --> Helper loaded: url_helper
INFO - 2023-04-29 22:51:23 --> Helper loaded: form_helper
INFO - 2023-04-29 22:51:23 --> Helper loaded: file_helper
INFO - 2023-04-29 22:51:23 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:51:23 --> Form Validation Class Initialized
INFO - 2023-04-29 22:51:23 --> Upload Class Initialized
INFO - 2023-04-29 22:51:23 --> Model "M_auth" initialized
INFO - 2023-04-29 22:51:23 --> Model "M_user" initialized
INFO - 2023-04-29 22:51:23 --> Model "M_produk" initialized
INFO - 2023-04-29 22:51:23 --> Controller Class Initialized
INFO - 2023-04-29 22:51:23 --> Model "M_produk" initialized
INFO - 2023-04-29 22:51:23 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_type_merek.php
INFO - 2023-04-29 22:51:23 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:51:23 --> Final output sent to browser
DEBUG - 2023-04-29 22:51:23 --> Total execution time: 0.1306
INFO - 2023-04-29 22:51:25 --> Config Class Initialized
INFO - 2023-04-29 22:51:25 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:51:25 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:51:25 --> Utf8 Class Initialized
INFO - 2023-04-29 22:51:25 --> URI Class Initialized
INFO - 2023-04-29 22:51:25 --> Router Class Initialized
INFO - 2023-04-29 22:51:25 --> Output Class Initialized
INFO - 2023-04-29 22:51:25 --> Security Class Initialized
DEBUG - 2023-04-29 22:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:51:25 --> Input Class Initialized
INFO - 2023-04-29 22:51:25 --> Language Class Initialized
INFO - 2023-04-29 22:51:25 --> Loader Class Initialized
INFO - 2023-04-29 22:51:25 --> Helper loaded: url_helper
INFO - 2023-04-29 22:51:25 --> Helper loaded: form_helper
INFO - 2023-04-29 22:51:25 --> Helper loaded: file_helper
INFO - 2023-04-29 22:51:25 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:51:25 --> Form Validation Class Initialized
INFO - 2023-04-29 22:51:25 --> Upload Class Initialized
INFO - 2023-04-29 22:51:25 --> Model "M_auth" initialized
INFO - 2023-04-29 22:51:25 --> Model "M_user" initialized
INFO - 2023-04-29 22:51:25 --> Model "M_produk" initialized
INFO - 2023-04-29 22:51:25 --> Controller Class Initialized
INFO - 2023-04-29 22:51:25 --> Model "M_produk" initialized
INFO - 2023-04-29 22:51:26 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_type_merek.php
INFO - 2023-04-29 22:51:26 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:51:26 --> Final output sent to browser
DEBUG - 2023-04-29 22:51:26 --> Total execution time: 0.1027
INFO - 2023-04-29 22:51:49 --> Config Class Initialized
INFO - 2023-04-29 22:51:49 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:51:49 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:51:49 --> Utf8 Class Initialized
INFO - 2023-04-29 22:51:49 --> URI Class Initialized
INFO - 2023-04-29 22:51:49 --> Router Class Initialized
INFO - 2023-04-29 22:51:49 --> Output Class Initialized
INFO - 2023-04-29 22:51:49 --> Security Class Initialized
DEBUG - 2023-04-29 22:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:51:49 --> Input Class Initialized
INFO - 2023-04-29 22:51:49 --> Language Class Initialized
INFO - 2023-04-29 22:51:49 --> Loader Class Initialized
INFO - 2023-04-29 22:51:49 --> Helper loaded: url_helper
INFO - 2023-04-29 22:51:49 --> Helper loaded: form_helper
INFO - 2023-04-29 22:51:49 --> Helper loaded: file_helper
INFO - 2023-04-29 22:51:49 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:51:49 --> Form Validation Class Initialized
INFO - 2023-04-29 22:51:49 --> Upload Class Initialized
INFO - 2023-04-29 22:51:49 --> Model "M_auth" initialized
INFO - 2023-04-29 22:51:49 --> Model "M_user" initialized
INFO - 2023-04-29 22:51:49 --> Model "M_produk" initialized
INFO - 2023-04-29 22:51:49 --> Controller Class Initialized
INFO - 2023-04-29 22:51:49 --> Model "M_produk" initialized
INFO - 2023-04-29 22:51:49 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-04-29 22:51:49 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:51:49 --> Final output sent to browser
DEBUG - 2023-04-29 22:51:49 --> Total execution time: 0.1240
INFO - 2023-04-29 22:51:51 --> Config Class Initialized
INFO - 2023-04-29 22:51:51 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:51:51 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:51:51 --> Utf8 Class Initialized
INFO - 2023-04-29 22:51:51 --> URI Class Initialized
INFO - 2023-04-29 22:51:51 --> Router Class Initialized
INFO - 2023-04-29 22:51:51 --> Output Class Initialized
INFO - 2023-04-29 22:51:51 --> Security Class Initialized
DEBUG - 2023-04-29 22:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:51:51 --> Input Class Initialized
INFO - 2023-04-29 22:51:51 --> Language Class Initialized
INFO - 2023-04-29 22:51:51 --> Loader Class Initialized
INFO - 2023-04-29 22:51:51 --> Helper loaded: url_helper
INFO - 2023-04-29 22:51:51 --> Helper loaded: form_helper
INFO - 2023-04-29 22:51:51 --> Helper loaded: file_helper
INFO - 2023-04-29 22:51:51 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:51:51 --> Form Validation Class Initialized
INFO - 2023-04-29 22:51:51 --> Upload Class Initialized
INFO - 2023-04-29 22:51:51 --> Model "M_auth" initialized
INFO - 2023-04-29 22:51:51 --> Model "M_user" initialized
INFO - 2023-04-29 22:51:51 --> Model "M_produk" initialized
INFO - 2023-04-29 22:51:51 --> Controller Class Initialized
INFO - 2023-04-29 22:51:51 --> Model "M_produk" initialized
INFO - 2023-04-29 22:51:51 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_add_produk.php
INFO - 2023-04-29 22:51:51 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:51:51 --> Final output sent to browser
DEBUG - 2023-04-29 22:51:51 --> Total execution time: 0.1239
INFO - 2023-04-29 22:52:16 --> Config Class Initialized
INFO - 2023-04-29 22:52:16 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:52:16 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:52:16 --> Utf8 Class Initialized
INFO - 2023-04-29 22:52:16 --> URI Class Initialized
INFO - 2023-04-29 22:52:16 --> Router Class Initialized
INFO - 2023-04-29 22:52:16 --> Output Class Initialized
INFO - 2023-04-29 22:52:16 --> Security Class Initialized
DEBUG - 2023-04-29 22:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:52:16 --> Input Class Initialized
INFO - 2023-04-29 22:52:16 --> Language Class Initialized
INFO - 2023-04-29 22:52:16 --> Loader Class Initialized
INFO - 2023-04-29 22:52:16 --> Helper loaded: url_helper
INFO - 2023-04-29 22:52:16 --> Helper loaded: form_helper
INFO - 2023-04-29 22:52:16 --> Helper loaded: file_helper
INFO - 2023-04-29 22:52:16 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:52:16 --> Form Validation Class Initialized
INFO - 2023-04-29 22:52:16 --> Upload Class Initialized
INFO - 2023-04-29 22:52:16 --> Model "M_auth" initialized
INFO - 2023-04-29 22:52:16 --> Model "M_user" initialized
INFO - 2023-04-29 22:52:16 --> Model "M_produk" initialized
INFO - 2023-04-29 22:52:16 --> Controller Class Initialized
INFO - 2023-04-29 22:52:16 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:52:16 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:52:16 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:52:16 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:52:16 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:52:16 --> Model "M_bank" initialized
INFO - 2023-04-29 22:52:16 --> Model "M_pesan" initialized
ERROR - 2023-04-29 22:52:16 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 22:52:16 --> Config Class Initialized
INFO - 2023-04-29 22:52:16 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:52:16 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:52:16 --> Utf8 Class Initialized
INFO - 2023-04-29 22:52:16 --> URI Class Initialized
INFO - 2023-04-29 22:52:16 --> Router Class Initialized
INFO - 2023-04-29 22:52:16 --> Output Class Initialized
INFO - 2023-04-29 22:52:16 --> Security Class Initialized
DEBUG - 2023-04-29 22:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:52:16 --> Input Class Initialized
INFO - 2023-04-29 22:52:16 --> Language Class Initialized
INFO - 2023-04-29 22:52:16 --> Loader Class Initialized
INFO - 2023-04-29 22:52:16 --> Helper loaded: url_helper
INFO - 2023-04-29 22:52:16 --> Helper loaded: form_helper
INFO - 2023-04-29 22:52:16 --> Helper loaded: file_helper
INFO - 2023-04-29 22:52:16 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:52:16 --> Form Validation Class Initialized
INFO - 2023-04-29 22:52:17 --> Upload Class Initialized
INFO - 2023-04-29 22:52:17 --> Model "M_auth" initialized
INFO - 2023-04-29 22:52:17 --> Model "M_user" initialized
INFO - 2023-04-29 22:52:17 --> Model "M_produk" initialized
INFO - 2023-04-29 22:52:17 --> Controller Class Initialized
INFO - 2023-04-29 22:52:17 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-04-29 22:52:17 --> Final output sent to browser
DEBUG - 2023-04-29 22:52:17 --> Total execution time: 0.0856
INFO - 2023-04-29 22:53:28 --> Config Class Initialized
INFO - 2023-04-29 22:53:28 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:53:28 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:53:28 --> Utf8 Class Initialized
INFO - 2023-04-29 22:53:28 --> URI Class Initialized
INFO - 2023-04-29 22:53:28 --> Router Class Initialized
INFO - 2023-04-29 22:53:28 --> Output Class Initialized
INFO - 2023-04-29 22:53:28 --> Security Class Initialized
DEBUG - 2023-04-29 22:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:53:28 --> Input Class Initialized
INFO - 2023-04-29 22:53:28 --> Language Class Initialized
INFO - 2023-04-29 22:53:28 --> Loader Class Initialized
INFO - 2023-04-29 22:53:28 --> Helper loaded: url_helper
INFO - 2023-04-29 22:53:28 --> Helper loaded: form_helper
INFO - 2023-04-29 22:53:28 --> Helper loaded: file_helper
INFO - 2023-04-29 22:53:28 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:53:28 --> Form Validation Class Initialized
INFO - 2023-04-29 22:53:28 --> Upload Class Initialized
INFO - 2023-04-29 22:53:28 --> Model "M_auth" initialized
INFO - 2023-04-29 22:53:28 --> Model "M_user" initialized
INFO - 2023-04-29 22:53:28 --> Model "M_produk" initialized
INFO - 2023-04-29 22:53:28 --> Controller Class Initialized
INFO - 2023-04-29 22:53:28 --> Model "M_produk" initialized
INFO - 2023-04-29 22:53:28 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_add_produk.php
INFO - 2023-04-29 22:53:28 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:53:28 --> Final output sent to browser
DEBUG - 2023-04-29 22:53:28 --> Total execution time: 0.1374
INFO - 2023-04-29 22:53:31 --> Config Class Initialized
INFO - 2023-04-29 22:53:31 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:53:31 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:53:31 --> Utf8 Class Initialized
INFO - 2023-04-29 22:53:31 --> URI Class Initialized
INFO - 2023-04-29 22:53:31 --> Router Class Initialized
INFO - 2023-04-29 22:53:31 --> Output Class Initialized
INFO - 2023-04-29 22:53:31 --> Security Class Initialized
DEBUG - 2023-04-29 22:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:53:31 --> Input Class Initialized
INFO - 2023-04-29 22:53:31 --> Language Class Initialized
INFO - 2023-04-29 22:53:31 --> Loader Class Initialized
INFO - 2023-04-29 22:53:31 --> Helper loaded: url_helper
INFO - 2023-04-29 22:53:31 --> Helper loaded: form_helper
INFO - 2023-04-29 22:53:31 --> Helper loaded: file_helper
INFO - 2023-04-29 22:53:32 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:53:32 --> Form Validation Class Initialized
INFO - 2023-04-29 22:53:32 --> Upload Class Initialized
INFO - 2023-04-29 22:53:32 --> Model "M_auth" initialized
INFO - 2023-04-29 22:53:32 --> Model "M_user" initialized
INFO - 2023-04-29 22:53:32 --> Model "M_produk" initialized
INFO - 2023-04-29 22:53:32 --> Controller Class Initialized
INFO - 2023-04-29 22:53:32 --> Model "M_produk" initialized
INFO - 2023-04-29 22:53:32 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-04-29 22:53:32 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:53:32 --> Final output sent to browser
DEBUG - 2023-04-29 22:53:32 --> Total execution time: 0.1002
INFO - 2023-04-29 22:53:34 --> Config Class Initialized
INFO - 2023-04-29 22:53:34 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:53:34 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:53:34 --> Utf8 Class Initialized
INFO - 2023-04-29 22:53:34 --> URI Class Initialized
INFO - 2023-04-29 22:53:34 --> Router Class Initialized
INFO - 2023-04-29 22:53:34 --> Output Class Initialized
INFO - 2023-04-29 22:53:34 --> Security Class Initialized
DEBUG - 2023-04-29 22:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:53:34 --> Input Class Initialized
INFO - 2023-04-29 22:53:34 --> Language Class Initialized
INFO - 2023-04-29 22:53:34 --> Loader Class Initialized
INFO - 2023-04-29 22:53:34 --> Helper loaded: url_helper
INFO - 2023-04-29 22:53:34 --> Helper loaded: form_helper
INFO - 2023-04-29 22:53:34 --> Helper loaded: file_helper
INFO - 2023-04-29 22:53:34 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:53:34 --> Form Validation Class Initialized
INFO - 2023-04-29 22:53:34 --> Upload Class Initialized
INFO - 2023-04-29 22:53:34 --> Model "M_auth" initialized
INFO - 2023-04-29 22:53:34 --> Model "M_user" initialized
INFO - 2023-04-29 22:53:34 --> Model "M_produk" initialized
INFO - 2023-04-29 22:53:34 --> Controller Class Initialized
INFO - 2023-04-29 22:53:34 --> Model "M_produk" initialized
INFO - 2023-04-29 22:53:34 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-04-29 22:53:34 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:53:34 --> Final output sent to browser
DEBUG - 2023-04-29 22:53:34 --> Total execution time: 0.1557
INFO - 2023-04-29 22:53:43 --> Config Class Initialized
INFO - 2023-04-29 22:53:43 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:53:43 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:53:43 --> Utf8 Class Initialized
INFO - 2023-04-29 22:53:43 --> URI Class Initialized
INFO - 2023-04-29 22:53:43 --> Router Class Initialized
INFO - 2023-04-29 22:53:43 --> Output Class Initialized
INFO - 2023-04-29 22:53:43 --> Security Class Initialized
DEBUG - 2023-04-29 22:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:53:43 --> Input Class Initialized
INFO - 2023-04-29 22:53:43 --> Language Class Initialized
INFO - 2023-04-29 22:53:43 --> Loader Class Initialized
INFO - 2023-04-29 22:53:43 --> Helper loaded: url_helper
INFO - 2023-04-29 22:53:43 --> Helper loaded: form_helper
INFO - 2023-04-29 22:53:43 --> Helper loaded: file_helper
INFO - 2023-04-29 22:53:43 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:53:43 --> Form Validation Class Initialized
INFO - 2023-04-29 22:53:43 --> Upload Class Initialized
INFO - 2023-04-29 22:53:43 --> Model "M_auth" initialized
INFO - 2023-04-29 22:53:43 --> Model "M_user" initialized
INFO - 2023-04-29 22:53:43 --> Model "M_produk" initialized
INFO - 2023-04-29 22:53:43 --> Controller Class Initialized
INFO - 2023-04-29 22:53:43 --> Model "M_produk" initialized
INFO - 2023-04-29 22:53:43 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_add_produk.php
INFO - 2023-04-29 22:53:43 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:53:43 --> Final output sent to browser
DEBUG - 2023-04-29 22:53:43 --> Total execution time: 0.1366
INFO - 2023-04-29 22:55:32 --> Config Class Initialized
INFO - 2023-04-29 22:55:32 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:55:32 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:55:32 --> Utf8 Class Initialized
INFO - 2023-04-29 22:55:32 --> URI Class Initialized
INFO - 2023-04-29 22:55:32 --> Router Class Initialized
INFO - 2023-04-29 22:55:32 --> Output Class Initialized
INFO - 2023-04-29 22:55:32 --> Security Class Initialized
DEBUG - 2023-04-29 22:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:55:32 --> Input Class Initialized
INFO - 2023-04-29 22:55:32 --> Language Class Initialized
INFO - 2023-04-29 22:55:32 --> Loader Class Initialized
INFO - 2023-04-29 22:55:32 --> Helper loaded: url_helper
INFO - 2023-04-29 22:55:32 --> Helper loaded: form_helper
INFO - 2023-04-29 22:55:32 --> Helper loaded: file_helper
INFO - 2023-04-29 22:55:32 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:55:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:55:32 --> Form Validation Class Initialized
INFO - 2023-04-29 22:55:32 --> Upload Class Initialized
INFO - 2023-04-29 22:55:32 --> Model "M_auth" initialized
INFO - 2023-04-29 22:55:32 --> Model "M_user" initialized
INFO - 2023-04-29 22:55:32 --> Model "M_produk" initialized
INFO - 2023-04-29 22:55:32 --> Controller Class Initialized
INFO - 2023-04-29 22:55:32 --> Model "M_produk" initialized
INFO - 2023-04-29 22:55:32 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-04-29 22:55:32 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:55:32 --> Final output sent to browser
DEBUG - 2023-04-29 22:55:32 --> Total execution time: 0.1218
INFO - 2023-04-29 22:55:34 --> Config Class Initialized
INFO - 2023-04-29 22:55:34 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:55:34 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:55:34 --> Utf8 Class Initialized
INFO - 2023-04-29 22:55:34 --> URI Class Initialized
INFO - 2023-04-29 22:55:34 --> Router Class Initialized
INFO - 2023-04-29 22:55:34 --> Output Class Initialized
INFO - 2023-04-29 22:55:34 --> Security Class Initialized
DEBUG - 2023-04-29 22:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:55:34 --> Input Class Initialized
INFO - 2023-04-29 22:55:34 --> Language Class Initialized
INFO - 2023-04-29 22:55:34 --> Loader Class Initialized
INFO - 2023-04-29 22:55:34 --> Helper loaded: url_helper
INFO - 2023-04-29 22:55:34 --> Helper loaded: form_helper
INFO - 2023-04-29 22:55:34 --> Helper loaded: file_helper
INFO - 2023-04-29 22:55:34 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:55:34 --> Form Validation Class Initialized
INFO - 2023-04-29 22:55:34 --> Upload Class Initialized
INFO - 2023-04-29 22:55:34 --> Model "M_auth" initialized
INFO - 2023-04-29 22:55:34 --> Model "M_user" initialized
INFO - 2023-04-29 22:55:34 --> Model "M_produk" initialized
INFO - 2023-04-29 22:55:34 --> Controller Class Initialized
INFO - 2023-04-29 22:55:34 --> Model "M_produk" initialized
INFO - 2023-04-29 22:55:34 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_add_barang.php
INFO - 2023-04-29 22:55:34 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:55:34 --> Final output sent to browser
DEBUG - 2023-04-29 22:55:34 --> Total execution time: 0.1155
INFO - 2023-04-29 22:56:34 --> Config Class Initialized
INFO - 2023-04-29 22:56:34 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:56:34 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:56:34 --> Utf8 Class Initialized
INFO - 2023-04-29 22:56:34 --> URI Class Initialized
INFO - 2023-04-29 22:56:34 --> Router Class Initialized
INFO - 2023-04-29 22:56:34 --> Output Class Initialized
INFO - 2023-04-29 22:56:34 --> Security Class Initialized
DEBUG - 2023-04-29 22:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:56:34 --> Input Class Initialized
INFO - 2023-04-29 22:56:34 --> Language Class Initialized
INFO - 2023-04-29 22:56:34 --> Loader Class Initialized
INFO - 2023-04-29 22:56:34 --> Helper loaded: url_helper
INFO - 2023-04-29 22:56:34 --> Helper loaded: form_helper
INFO - 2023-04-29 22:56:34 --> Helper loaded: file_helper
INFO - 2023-04-29 22:56:34 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:56:34 --> Form Validation Class Initialized
INFO - 2023-04-29 22:56:34 --> Upload Class Initialized
INFO - 2023-04-29 22:56:34 --> Model "M_auth" initialized
INFO - 2023-04-29 22:56:34 --> Model "M_user" initialized
INFO - 2023-04-29 22:56:34 --> Model "M_produk" initialized
INFO - 2023-04-29 22:56:34 --> Controller Class Initialized
INFO - 2023-04-29 22:56:34 --> Model "M_produk" initialized
INFO - 2023-04-29 22:56:34 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-04-29 22:56:34 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:56:34 --> Final output sent to browser
DEBUG - 2023-04-29 22:56:34 --> Total execution time: 0.1372
INFO - 2023-04-29 22:56:36 --> Config Class Initialized
INFO - 2023-04-29 22:56:36 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:56:36 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:56:36 --> Utf8 Class Initialized
INFO - 2023-04-29 22:56:36 --> URI Class Initialized
INFO - 2023-04-29 22:56:36 --> Router Class Initialized
INFO - 2023-04-29 22:56:36 --> Output Class Initialized
INFO - 2023-04-29 22:56:36 --> Security Class Initialized
DEBUG - 2023-04-29 22:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:56:36 --> Input Class Initialized
INFO - 2023-04-29 22:56:36 --> Language Class Initialized
INFO - 2023-04-29 22:56:36 --> Loader Class Initialized
INFO - 2023-04-29 22:56:36 --> Helper loaded: url_helper
INFO - 2023-04-29 22:56:36 --> Helper loaded: form_helper
INFO - 2023-04-29 22:56:36 --> Helper loaded: file_helper
INFO - 2023-04-29 22:56:36 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:56:36 --> Form Validation Class Initialized
INFO - 2023-04-29 22:56:36 --> Upload Class Initialized
INFO - 2023-04-29 22:56:36 --> Model "M_auth" initialized
INFO - 2023-04-29 22:56:36 --> Model "M_user" initialized
INFO - 2023-04-29 22:56:36 --> Model "M_produk" initialized
INFO - 2023-04-29 22:56:36 --> Controller Class Initialized
INFO - 2023-04-29 22:56:36 --> Model "M_produk" initialized
INFO - 2023-04-29 22:56:36 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-04-29 22:56:36 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:56:36 --> Final output sent to browser
DEBUG - 2023-04-29 22:56:36 --> Total execution time: 0.1113
INFO - 2023-04-29 22:56:37 --> Config Class Initialized
INFO - 2023-04-29 22:56:37 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:56:37 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:56:37 --> Utf8 Class Initialized
INFO - 2023-04-29 22:56:37 --> URI Class Initialized
INFO - 2023-04-29 22:56:37 --> Router Class Initialized
INFO - 2023-04-29 22:56:37 --> Output Class Initialized
INFO - 2023-04-29 22:56:37 --> Security Class Initialized
DEBUG - 2023-04-29 22:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:56:37 --> Input Class Initialized
INFO - 2023-04-29 22:56:37 --> Language Class Initialized
INFO - 2023-04-29 22:56:37 --> Loader Class Initialized
INFO - 2023-04-29 22:56:37 --> Helper loaded: url_helper
INFO - 2023-04-29 22:56:37 --> Helper loaded: form_helper
INFO - 2023-04-29 22:56:37 --> Helper loaded: file_helper
INFO - 2023-04-29 22:56:37 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:56:37 --> Form Validation Class Initialized
INFO - 2023-04-29 22:56:37 --> Upload Class Initialized
INFO - 2023-04-29 22:56:37 --> Model "M_auth" initialized
INFO - 2023-04-29 22:56:37 --> Model "M_user" initialized
INFO - 2023-04-29 22:56:37 --> Model "M_produk" initialized
INFO - 2023-04-29 22:56:37 --> Controller Class Initialized
INFO - 2023-04-29 22:56:37 --> Model "M_produk" initialized
INFO - 2023-04-29 22:56:37 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_add_barang.php
INFO - 2023-04-29 22:56:37 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:56:37 --> Final output sent to browser
DEBUG - 2023-04-29 22:56:37 --> Total execution time: 0.1133
INFO - 2023-04-29 22:56:54 --> Config Class Initialized
INFO - 2023-04-29 22:56:54 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:56:54 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:56:54 --> Utf8 Class Initialized
INFO - 2023-04-29 22:56:54 --> URI Class Initialized
INFO - 2023-04-29 22:56:54 --> Router Class Initialized
INFO - 2023-04-29 22:56:54 --> Output Class Initialized
INFO - 2023-04-29 22:56:54 --> Security Class Initialized
DEBUG - 2023-04-29 22:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:56:54 --> Input Class Initialized
INFO - 2023-04-29 22:56:54 --> Language Class Initialized
INFO - 2023-04-29 22:56:54 --> Loader Class Initialized
INFO - 2023-04-29 22:56:54 --> Helper loaded: url_helper
INFO - 2023-04-29 22:56:54 --> Helper loaded: form_helper
INFO - 2023-04-29 22:56:54 --> Helper loaded: file_helper
INFO - 2023-04-29 22:56:54 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:56:54 --> Form Validation Class Initialized
INFO - 2023-04-29 22:56:54 --> Upload Class Initialized
INFO - 2023-04-29 22:56:54 --> Model "M_auth" initialized
INFO - 2023-04-29 22:56:54 --> Model "M_user" initialized
INFO - 2023-04-29 22:56:55 --> Model "M_produk" initialized
INFO - 2023-04-29 22:56:55 --> Controller Class Initialized
INFO - 2023-04-29 22:56:55 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:56:55 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:56:55 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:56:55 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:56:55 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:56:55 --> Model "M_bank" initialized
INFO - 2023-04-29 22:56:55 --> Model "M_pesan" initialized
ERROR - 2023-04-29 22:56:55 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 22:56:55 --> Config Class Initialized
INFO - 2023-04-29 22:56:55 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:56:55 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:56:55 --> Utf8 Class Initialized
INFO - 2023-04-29 22:56:55 --> URI Class Initialized
INFO - 2023-04-29 22:56:55 --> Router Class Initialized
INFO - 2023-04-29 22:56:55 --> Output Class Initialized
INFO - 2023-04-29 22:56:55 --> Security Class Initialized
DEBUG - 2023-04-29 22:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:56:55 --> Input Class Initialized
INFO - 2023-04-29 22:56:55 --> Language Class Initialized
INFO - 2023-04-29 22:56:55 --> Loader Class Initialized
INFO - 2023-04-29 22:56:55 --> Helper loaded: url_helper
INFO - 2023-04-29 22:56:55 --> Helper loaded: form_helper
INFO - 2023-04-29 22:56:55 --> Helper loaded: file_helper
INFO - 2023-04-29 22:56:55 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:56:55 --> Form Validation Class Initialized
INFO - 2023-04-29 22:56:55 --> Upload Class Initialized
INFO - 2023-04-29 22:56:55 --> Model "M_auth" initialized
INFO - 2023-04-29 22:56:55 --> Model "M_user" initialized
INFO - 2023-04-29 22:56:55 --> Model "M_produk" initialized
INFO - 2023-04-29 22:56:55 --> Controller Class Initialized
INFO - 2023-04-29 22:56:55 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-04-29 22:56:55 --> Final output sent to browser
DEBUG - 2023-04-29 22:56:55 --> Total execution time: 0.1242
INFO - 2023-04-29 22:57:17 --> Config Class Initialized
INFO - 2023-04-29 22:57:17 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:57:17 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:57:17 --> Utf8 Class Initialized
INFO - 2023-04-29 22:57:17 --> URI Class Initialized
INFO - 2023-04-29 22:57:17 --> Router Class Initialized
INFO - 2023-04-29 22:57:17 --> Output Class Initialized
INFO - 2023-04-29 22:57:17 --> Security Class Initialized
DEBUG - 2023-04-29 22:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:57:17 --> Input Class Initialized
INFO - 2023-04-29 22:57:17 --> Language Class Initialized
INFO - 2023-04-29 22:57:17 --> Loader Class Initialized
INFO - 2023-04-29 22:57:17 --> Helper loaded: url_helper
INFO - 2023-04-29 22:57:17 --> Helper loaded: form_helper
INFO - 2023-04-29 22:57:17 --> Helper loaded: file_helper
INFO - 2023-04-29 22:57:17 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:57:17 --> Form Validation Class Initialized
INFO - 2023-04-29 22:57:17 --> Upload Class Initialized
INFO - 2023-04-29 22:57:17 --> Model "M_auth" initialized
INFO - 2023-04-29 22:57:17 --> Model "M_user" initialized
INFO - 2023-04-29 22:57:17 --> Model "M_produk" initialized
INFO - 2023-04-29 22:57:17 --> Controller Class Initialized
INFO - 2023-04-29 22:57:17 --> Model "M_produk" initialized
INFO - 2023-04-29 22:57:17 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_add_barang.php
INFO - 2023-04-29 22:57:17 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:57:17 --> Final output sent to browser
DEBUG - 2023-04-29 22:57:17 --> Total execution time: 0.1282
INFO - 2023-04-29 22:57:25 --> Config Class Initialized
INFO - 2023-04-29 22:57:25 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:57:25 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:57:25 --> Utf8 Class Initialized
INFO - 2023-04-29 22:57:25 --> URI Class Initialized
INFO - 2023-04-29 22:57:25 --> Router Class Initialized
INFO - 2023-04-29 22:57:25 --> Output Class Initialized
INFO - 2023-04-29 22:57:25 --> Security Class Initialized
DEBUG - 2023-04-29 22:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:57:25 --> Input Class Initialized
INFO - 2023-04-29 22:57:25 --> Language Class Initialized
INFO - 2023-04-29 22:57:25 --> Loader Class Initialized
INFO - 2023-04-29 22:57:25 --> Helper loaded: url_helper
INFO - 2023-04-29 22:57:25 --> Helper loaded: form_helper
INFO - 2023-04-29 22:57:25 --> Helper loaded: file_helper
INFO - 2023-04-29 22:57:25 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:57:25 --> Form Validation Class Initialized
INFO - 2023-04-29 22:57:25 --> Upload Class Initialized
INFO - 2023-04-29 22:57:25 --> Model "M_auth" initialized
INFO - 2023-04-29 22:57:25 --> Model "M_user" initialized
INFO - 2023-04-29 22:57:25 --> Model "M_produk" initialized
INFO - 2023-04-29 22:57:25 --> Controller Class Initialized
INFO - 2023-04-29 22:57:25 --> Model "M_produk" initialized
INFO - 2023-04-29 22:57:25 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-04-29 22:57:25 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:57:25 --> Final output sent to browser
DEBUG - 2023-04-29 22:57:25 --> Total execution time: 0.1049
INFO - 2023-04-29 22:57:27 --> Config Class Initialized
INFO - 2023-04-29 22:57:27 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:57:27 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:57:27 --> Utf8 Class Initialized
INFO - 2023-04-29 22:57:27 --> URI Class Initialized
INFO - 2023-04-29 22:57:27 --> Router Class Initialized
INFO - 2023-04-29 22:57:27 --> Output Class Initialized
INFO - 2023-04-29 22:57:27 --> Security Class Initialized
DEBUG - 2023-04-29 22:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:57:27 --> Input Class Initialized
INFO - 2023-04-29 22:57:27 --> Language Class Initialized
INFO - 2023-04-29 22:57:27 --> Loader Class Initialized
INFO - 2023-04-29 22:57:27 --> Helper loaded: url_helper
INFO - 2023-04-29 22:57:27 --> Helper loaded: form_helper
INFO - 2023-04-29 22:57:27 --> Helper loaded: file_helper
INFO - 2023-04-29 22:57:27 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:57:28 --> Form Validation Class Initialized
INFO - 2023-04-29 22:57:28 --> Upload Class Initialized
INFO - 2023-04-29 22:57:28 --> Model "M_auth" initialized
INFO - 2023-04-29 22:57:28 --> Model "M_user" initialized
INFO - 2023-04-29 22:57:28 --> Model "M_produk" initialized
INFO - 2023-04-29 22:57:28 --> Controller Class Initialized
INFO - 2023-04-29 22:57:28 --> Model "M_produk" initialized
INFO - 2023-04-29 22:57:28 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-04-29 22:57:28 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:57:28 --> Final output sent to browser
DEBUG - 2023-04-29 22:57:28 --> Total execution time: 0.1219
INFO - 2023-04-29 22:58:28 --> Config Class Initialized
INFO - 2023-04-29 22:58:28 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:58:28 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:58:28 --> Utf8 Class Initialized
INFO - 2023-04-29 22:58:28 --> URI Class Initialized
INFO - 2023-04-29 22:58:28 --> Router Class Initialized
INFO - 2023-04-29 22:58:28 --> Output Class Initialized
INFO - 2023-04-29 22:58:28 --> Security Class Initialized
DEBUG - 2023-04-29 22:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:58:28 --> Input Class Initialized
INFO - 2023-04-29 22:58:28 --> Language Class Initialized
INFO - 2023-04-29 22:58:28 --> Loader Class Initialized
INFO - 2023-04-29 22:58:28 --> Helper loaded: url_helper
INFO - 2023-04-29 22:58:28 --> Helper loaded: form_helper
INFO - 2023-04-29 22:58:28 --> Helper loaded: file_helper
INFO - 2023-04-29 22:58:28 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:58:28 --> Form Validation Class Initialized
INFO - 2023-04-29 22:58:28 --> Upload Class Initialized
INFO - 2023-04-29 22:58:28 --> Model "M_auth" initialized
INFO - 2023-04-29 22:58:28 --> Model "M_user" initialized
INFO - 2023-04-29 22:58:28 --> Model "M_produk" initialized
INFO - 2023-04-29 22:58:28 --> Controller Class Initialized
INFO - 2023-04-29 22:58:28 --> Model "M_produk" initialized
INFO - 2023-04-29 22:58:28 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-04-29 22:58:28 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:58:28 --> Final output sent to browser
DEBUG - 2023-04-29 22:58:28 --> Total execution time: 0.1162
INFO - 2023-04-29 22:58:29 --> Config Class Initialized
INFO - 2023-04-29 22:58:29 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:58:29 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:58:29 --> Utf8 Class Initialized
INFO - 2023-04-29 22:58:29 --> URI Class Initialized
INFO - 2023-04-29 22:58:29 --> Router Class Initialized
INFO - 2023-04-29 22:58:29 --> Output Class Initialized
INFO - 2023-04-29 22:58:29 --> Security Class Initialized
DEBUG - 2023-04-29 22:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:58:29 --> Input Class Initialized
INFO - 2023-04-29 22:58:29 --> Language Class Initialized
INFO - 2023-04-29 22:58:29 --> Loader Class Initialized
INFO - 2023-04-29 22:58:29 --> Helper loaded: url_helper
INFO - 2023-04-29 22:58:29 --> Helper loaded: form_helper
INFO - 2023-04-29 22:58:29 --> Helper loaded: file_helper
INFO - 2023-04-29 22:58:29 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:58:29 --> Form Validation Class Initialized
INFO - 2023-04-29 22:58:29 --> Upload Class Initialized
INFO - 2023-04-29 22:58:29 --> Model "M_auth" initialized
INFO - 2023-04-29 22:58:29 --> Model "M_user" initialized
INFO - 2023-04-29 22:58:29 --> Model "M_produk" initialized
INFO - 2023-04-29 22:58:29 --> Controller Class Initialized
INFO - 2023-04-29 22:58:29 --> Model "M_produk" initialized
INFO - 2023-04-29 22:58:29 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_add_barang.php
INFO - 2023-04-29 22:58:29 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:58:29 --> Final output sent to browser
DEBUG - 2023-04-29 22:58:29 --> Total execution time: 0.1300
INFO - 2023-04-29 22:58:46 --> Config Class Initialized
INFO - 2023-04-29 22:58:46 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:58:46 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:58:46 --> Utf8 Class Initialized
INFO - 2023-04-29 22:58:46 --> URI Class Initialized
INFO - 2023-04-29 22:58:46 --> Router Class Initialized
INFO - 2023-04-29 22:58:46 --> Output Class Initialized
INFO - 2023-04-29 22:58:46 --> Security Class Initialized
DEBUG - 2023-04-29 22:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:58:46 --> Input Class Initialized
INFO - 2023-04-29 22:58:46 --> Language Class Initialized
INFO - 2023-04-29 22:58:46 --> Loader Class Initialized
INFO - 2023-04-29 22:58:46 --> Helper loaded: url_helper
INFO - 2023-04-29 22:58:46 --> Helper loaded: form_helper
INFO - 2023-04-29 22:58:46 --> Helper loaded: file_helper
INFO - 2023-04-29 22:58:46 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:58:46 --> Form Validation Class Initialized
INFO - 2023-04-29 22:58:46 --> Upload Class Initialized
INFO - 2023-04-29 22:58:46 --> Model "M_auth" initialized
INFO - 2023-04-29 22:58:46 --> Model "M_user" initialized
INFO - 2023-04-29 22:58:46 --> Model "M_produk" initialized
INFO - 2023-04-29 22:58:46 --> Controller Class Initialized
INFO - 2023-04-29 22:58:46 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 22:58:46 --> Model "M_produk" initialized
DEBUG - 2023-04-29 22:58:46 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 22:58:46 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 22:58:46 --> Model "M_transaksi" initialized
INFO - 2023-04-29 22:58:46 --> Model "M_bank" initialized
INFO - 2023-04-29 22:58:46 --> Model "M_pesan" initialized
ERROR - 2023-04-29 22:58:46 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 22:58:46 --> Config Class Initialized
INFO - 2023-04-29 22:58:46 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:58:46 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:58:46 --> Utf8 Class Initialized
INFO - 2023-04-29 22:58:46 --> URI Class Initialized
INFO - 2023-04-29 22:58:46 --> Router Class Initialized
INFO - 2023-04-29 22:58:46 --> Output Class Initialized
INFO - 2023-04-29 22:58:46 --> Security Class Initialized
DEBUG - 2023-04-29 22:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:58:46 --> Input Class Initialized
INFO - 2023-04-29 22:58:46 --> Language Class Initialized
INFO - 2023-04-29 22:58:46 --> Loader Class Initialized
INFO - 2023-04-29 22:58:46 --> Helper loaded: url_helper
INFO - 2023-04-29 22:58:46 --> Helper loaded: form_helper
INFO - 2023-04-29 22:58:46 --> Helper loaded: file_helper
INFO - 2023-04-29 22:58:46 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:58:46 --> Form Validation Class Initialized
INFO - 2023-04-29 22:58:46 --> Upload Class Initialized
INFO - 2023-04-29 22:58:46 --> Model "M_auth" initialized
INFO - 2023-04-29 22:58:46 --> Model "M_user" initialized
INFO - 2023-04-29 22:58:46 --> Model "M_produk" initialized
INFO - 2023-04-29 22:58:46 --> Controller Class Initialized
INFO - 2023-04-29 22:58:46 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-04-29 22:58:46 --> Final output sent to browser
DEBUG - 2023-04-29 22:58:46 --> Total execution time: 0.1370
INFO - 2023-04-29 22:58:59 --> Config Class Initialized
INFO - 2023-04-29 22:58:59 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:58:59 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:58:59 --> Utf8 Class Initialized
INFO - 2023-04-29 22:58:59 --> URI Class Initialized
INFO - 2023-04-29 22:58:59 --> Router Class Initialized
INFO - 2023-04-29 22:58:59 --> Output Class Initialized
INFO - 2023-04-29 22:58:59 --> Security Class Initialized
DEBUG - 2023-04-29 22:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:58:59 --> Input Class Initialized
INFO - 2023-04-29 22:58:59 --> Language Class Initialized
INFO - 2023-04-29 22:58:59 --> Loader Class Initialized
INFO - 2023-04-29 22:58:59 --> Helper loaded: url_helper
INFO - 2023-04-29 22:58:59 --> Helper loaded: form_helper
INFO - 2023-04-29 22:58:59 --> Helper loaded: file_helper
INFO - 2023-04-29 22:58:59 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:58:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:58:59 --> Form Validation Class Initialized
INFO - 2023-04-29 22:58:59 --> Upload Class Initialized
INFO - 2023-04-29 22:58:59 --> Model "M_auth" initialized
INFO - 2023-04-29 22:58:59 --> Model "M_user" initialized
INFO - 2023-04-29 22:58:59 --> Model "M_produk" initialized
INFO - 2023-04-29 22:58:59 --> Controller Class Initialized
INFO - 2023-04-29 22:58:59 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-04-29 22:58:59 --> Final output sent to browser
DEBUG - 2023-04-29 22:58:59 --> Total execution time: 0.1063
INFO - 2023-04-29 22:59:00 --> Config Class Initialized
INFO - 2023-04-29 22:59:00 --> Hooks Class Initialized
DEBUG - 2023-04-29 22:59:00 --> UTF-8 Support Enabled
INFO - 2023-04-29 22:59:00 --> Utf8 Class Initialized
INFO - 2023-04-29 22:59:00 --> URI Class Initialized
INFO - 2023-04-29 22:59:00 --> Router Class Initialized
INFO - 2023-04-29 22:59:00 --> Output Class Initialized
INFO - 2023-04-29 22:59:00 --> Security Class Initialized
DEBUG - 2023-04-29 22:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 22:59:00 --> Input Class Initialized
INFO - 2023-04-29 22:59:00 --> Language Class Initialized
INFO - 2023-04-29 22:59:00 --> Loader Class Initialized
INFO - 2023-04-29 22:59:00 --> Helper loaded: url_helper
INFO - 2023-04-29 22:59:00 --> Helper loaded: form_helper
INFO - 2023-04-29 22:59:00 --> Helper loaded: file_helper
INFO - 2023-04-29 22:59:00 --> Database Driver Class Initialized
DEBUG - 2023-04-29 22:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 22:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 22:59:00 --> Form Validation Class Initialized
INFO - 2023-04-29 22:59:00 --> Upload Class Initialized
INFO - 2023-04-29 22:59:00 --> Model "M_auth" initialized
INFO - 2023-04-29 22:59:00 --> Model "M_user" initialized
INFO - 2023-04-29 22:59:00 --> Model "M_produk" initialized
INFO - 2023-04-29 22:59:00 --> Controller Class Initialized
INFO - 2023-04-29 22:59:00 --> Model "M_produk" initialized
INFO - 2023-04-29 22:59:00 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_add_produk.php
INFO - 2023-04-29 22:59:00 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 22:59:00 --> Final output sent to browser
DEBUG - 2023-04-29 22:59:00 --> Total execution time: 0.1508
INFO - 2023-04-29 23:02:15 --> Config Class Initialized
INFO - 2023-04-29 23:02:15 --> Hooks Class Initialized
DEBUG - 2023-04-29 23:02:15 --> UTF-8 Support Enabled
INFO - 2023-04-29 23:02:15 --> Utf8 Class Initialized
INFO - 2023-04-29 23:02:15 --> URI Class Initialized
INFO - 2023-04-29 23:02:15 --> Router Class Initialized
INFO - 2023-04-29 23:02:15 --> Output Class Initialized
INFO - 2023-04-29 23:02:15 --> Security Class Initialized
DEBUG - 2023-04-29 23:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 23:02:15 --> Input Class Initialized
INFO - 2023-04-29 23:02:15 --> Language Class Initialized
INFO - 2023-04-29 23:02:15 --> Loader Class Initialized
INFO - 2023-04-29 23:02:15 --> Helper loaded: url_helper
INFO - 2023-04-29 23:02:15 --> Helper loaded: form_helper
INFO - 2023-04-29 23:02:15 --> Helper loaded: file_helper
INFO - 2023-04-29 23:02:15 --> Database Driver Class Initialized
DEBUG - 2023-04-29 23:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 23:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 23:02:15 --> Form Validation Class Initialized
INFO - 2023-04-29 23:02:15 --> Upload Class Initialized
INFO - 2023-04-29 23:02:15 --> Model "M_auth" initialized
INFO - 2023-04-29 23:02:15 --> Model "M_user" initialized
INFO - 2023-04-29 23:02:15 --> Model "M_produk" initialized
INFO - 2023-04-29 23:02:15 --> Controller Class Initialized
INFO - 2023-04-29 23:02:15 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 23:02:15 --> Model "M_produk" initialized
DEBUG - 2023-04-29 23:02:15 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 23:02:15 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 23:02:15 --> Model "M_transaksi" initialized
INFO - 2023-04-29 23:02:15 --> Model "M_bank" initialized
INFO - 2023-04-29 23:02:15 --> Model "M_pesan" initialized
ERROR - 2023-04-29 23:02:15 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 23:02:15 --> Config Class Initialized
INFO - 2023-04-29 23:02:15 --> Hooks Class Initialized
DEBUG - 2023-04-29 23:02:15 --> UTF-8 Support Enabled
INFO - 2023-04-29 23:02:15 --> Utf8 Class Initialized
INFO - 2023-04-29 23:02:15 --> URI Class Initialized
INFO - 2023-04-29 23:02:15 --> Router Class Initialized
INFO - 2023-04-29 23:02:15 --> Output Class Initialized
INFO - 2023-04-29 23:02:15 --> Security Class Initialized
DEBUG - 2023-04-29 23:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 23:02:15 --> Input Class Initialized
INFO - 2023-04-29 23:02:15 --> Language Class Initialized
INFO - 2023-04-29 23:02:15 --> Loader Class Initialized
INFO - 2023-04-29 23:02:15 --> Helper loaded: url_helper
INFO - 2023-04-29 23:02:15 --> Helper loaded: form_helper
INFO - 2023-04-29 23:02:15 --> Helper loaded: file_helper
INFO - 2023-04-29 23:02:15 --> Database Driver Class Initialized
DEBUG - 2023-04-29 23:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 23:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 23:02:15 --> Form Validation Class Initialized
INFO - 2023-04-29 23:02:15 --> Upload Class Initialized
INFO - 2023-04-29 23:02:15 --> Model "M_auth" initialized
INFO - 2023-04-29 23:02:15 --> Model "M_user" initialized
INFO - 2023-04-29 23:02:15 --> Model "M_produk" initialized
INFO - 2023-04-29 23:02:15 --> Controller Class Initialized
INFO - 2023-04-29 23:02:15 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-04-29 23:02:15 --> Final output sent to browser
DEBUG - 2023-04-29 23:02:15 --> Total execution time: 0.0846
INFO - 2023-04-29 23:02:17 --> Config Class Initialized
INFO - 2023-04-29 23:02:17 --> Hooks Class Initialized
DEBUG - 2023-04-29 23:02:17 --> UTF-8 Support Enabled
INFO - 2023-04-29 23:02:17 --> Utf8 Class Initialized
INFO - 2023-04-29 23:02:17 --> URI Class Initialized
INFO - 2023-04-29 23:02:17 --> Router Class Initialized
INFO - 2023-04-29 23:02:17 --> Output Class Initialized
INFO - 2023-04-29 23:02:17 --> Security Class Initialized
DEBUG - 2023-04-29 23:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 23:02:17 --> Input Class Initialized
INFO - 2023-04-29 23:02:17 --> Language Class Initialized
INFO - 2023-04-29 23:02:17 --> Loader Class Initialized
INFO - 2023-04-29 23:02:17 --> Helper loaded: url_helper
INFO - 2023-04-29 23:02:17 --> Helper loaded: form_helper
INFO - 2023-04-29 23:02:17 --> Helper loaded: file_helper
INFO - 2023-04-29 23:02:17 --> Database Driver Class Initialized
DEBUG - 2023-04-29 23:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 23:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 23:02:17 --> Form Validation Class Initialized
INFO - 2023-04-29 23:02:17 --> Upload Class Initialized
INFO - 2023-04-29 23:02:17 --> Model "M_auth" initialized
INFO - 2023-04-29 23:02:17 --> Model "M_user" initialized
INFO - 2023-04-29 23:02:17 --> Model "M_produk" initialized
INFO - 2023-04-29 23:02:17 --> Controller Class Initialized
INFO - 2023-04-29 23:02:17 --> Model "M_produk" initialized
INFO - 2023-04-29 23:02:17 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_add_produk.php
INFO - 2023-04-29 23:02:17 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 23:02:17 --> Final output sent to browser
DEBUG - 2023-04-29 23:02:17 --> Total execution time: 0.1252
INFO - 2023-04-29 23:02:19 --> Config Class Initialized
INFO - 2023-04-29 23:02:19 --> Hooks Class Initialized
DEBUG - 2023-04-29 23:02:19 --> UTF-8 Support Enabled
INFO - 2023-04-29 23:02:19 --> Utf8 Class Initialized
INFO - 2023-04-29 23:02:19 --> URI Class Initialized
INFO - 2023-04-29 23:02:19 --> Router Class Initialized
INFO - 2023-04-29 23:02:19 --> Output Class Initialized
INFO - 2023-04-29 23:02:19 --> Security Class Initialized
DEBUG - 2023-04-29 23:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 23:02:19 --> Input Class Initialized
INFO - 2023-04-29 23:02:19 --> Language Class Initialized
INFO - 2023-04-29 23:02:19 --> Loader Class Initialized
INFO - 2023-04-29 23:02:19 --> Helper loaded: url_helper
INFO - 2023-04-29 23:02:19 --> Helper loaded: form_helper
INFO - 2023-04-29 23:02:19 --> Helper loaded: file_helper
INFO - 2023-04-29 23:02:19 --> Database Driver Class Initialized
DEBUG - 2023-04-29 23:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 23:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 23:02:19 --> Form Validation Class Initialized
INFO - 2023-04-29 23:02:19 --> Upload Class Initialized
INFO - 2023-04-29 23:02:19 --> Model "M_auth" initialized
INFO - 2023-04-29 23:02:19 --> Model "M_user" initialized
INFO - 2023-04-29 23:02:19 --> Model "M_produk" initialized
INFO - 2023-04-29 23:02:19 --> Controller Class Initialized
INFO - 2023-04-29 23:02:19 --> Model "M_produk" initialized
INFO - 2023-04-29 23:02:19 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_add_produk.php
INFO - 2023-04-29 23:02:19 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 23:02:19 --> Final output sent to browser
DEBUG - 2023-04-29 23:02:19 --> Total execution time: 0.1134
INFO - 2023-04-29 23:02:22 --> Config Class Initialized
INFO - 2023-04-29 23:02:22 --> Hooks Class Initialized
DEBUG - 2023-04-29 23:02:22 --> UTF-8 Support Enabled
INFO - 2023-04-29 23:02:22 --> Utf8 Class Initialized
INFO - 2023-04-29 23:02:22 --> URI Class Initialized
INFO - 2023-04-29 23:02:22 --> Router Class Initialized
INFO - 2023-04-29 23:02:22 --> Output Class Initialized
INFO - 2023-04-29 23:02:22 --> Security Class Initialized
DEBUG - 2023-04-29 23:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 23:02:22 --> Input Class Initialized
INFO - 2023-04-29 23:02:22 --> Language Class Initialized
INFO - 2023-04-29 23:02:22 --> Loader Class Initialized
INFO - 2023-04-29 23:02:22 --> Helper loaded: url_helper
INFO - 2023-04-29 23:02:22 --> Helper loaded: form_helper
INFO - 2023-04-29 23:02:22 --> Helper loaded: file_helper
INFO - 2023-04-29 23:02:22 --> Database Driver Class Initialized
DEBUG - 2023-04-29 23:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 23:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 23:02:22 --> Form Validation Class Initialized
INFO - 2023-04-29 23:02:22 --> Upload Class Initialized
INFO - 2023-04-29 23:02:22 --> Model "M_auth" initialized
INFO - 2023-04-29 23:02:22 --> Model "M_user" initialized
INFO - 2023-04-29 23:02:22 --> Model "M_produk" initialized
INFO - 2023-04-29 23:02:22 --> Controller Class Initialized
INFO - 2023-04-29 23:02:22 --> Model "M_produk" initialized
INFO - 2023-04-29 23:02:22 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_add_produk.php
INFO - 2023-04-29 23:02:22 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 23:02:22 --> Final output sent to browser
DEBUG - 2023-04-29 23:02:22 --> Total execution time: 0.1181
INFO - 2023-04-29 23:03:30 --> Config Class Initialized
INFO - 2023-04-29 23:03:30 --> Hooks Class Initialized
DEBUG - 2023-04-29 23:03:30 --> UTF-8 Support Enabled
INFO - 2023-04-29 23:03:30 --> Utf8 Class Initialized
INFO - 2023-04-29 23:03:30 --> URI Class Initialized
INFO - 2023-04-29 23:03:30 --> Router Class Initialized
INFO - 2023-04-29 23:03:30 --> Output Class Initialized
INFO - 2023-04-29 23:03:30 --> Security Class Initialized
DEBUG - 2023-04-29 23:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 23:03:30 --> Input Class Initialized
INFO - 2023-04-29 23:03:30 --> Language Class Initialized
INFO - 2023-04-29 23:03:30 --> Loader Class Initialized
INFO - 2023-04-29 23:03:30 --> Helper loaded: url_helper
INFO - 2023-04-29 23:03:30 --> Helper loaded: form_helper
INFO - 2023-04-29 23:03:30 --> Helper loaded: file_helper
INFO - 2023-04-29 23:03:30 --> Database Driver Class Initialized
DEBUG - 2023-04-29 23:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 23:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 23:03:30 --> Form Validation Class Initialized
INFO - 2023-04-29 23:03:30 --> Upload Class Initialized
INFO - 2023-04-29 23:03:30 --> Model "M_auth" initialized
INFO - 2023-04-29 23:03:30 --> Model "M_user" initialized
INFO - 2023-04-29 23:03:30 --> Model "M_produk" initialized
INFO - 2023-04-29 23:03:30 --> Controller Class Initialized
INFO - 2023-04-29 23:03:30 --> Model "M_produk" initialized
INFO - 2023-04-29 23:03:30 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_add_produk.php
INFO - 2023-04-29 23:03:30 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 23:03:30 --> Final output sent to browser
DEBUG - 2023-04-29 23:03:30 --> Total execution time: 0.1374
INFO - 2023-04-29 23:03:44 --> Config Class Initialized
INFO - 2023-04-29 23:03:44 --> Hooks Class Initialized
DEBUG - 2023-04-29 23:03:44 --> UTF-8 Support Enabled
INFO - 2023-04-29 23:03:44 --> Utf8 Class Initialized
INFO - 2023-04-29 23:03:44 --> URI Class Initialized
INFO - 2023-04-29 23:03:44 --> Router Class Initialized
INFO - 2023-04-29 23:03:44 --> Output Class Initialized
INFO - 2023-04-29 23:03:44 --> Security Class Initialized
DEBUG - 2023-04-29 23:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 23:03:44 --> Input Class Initialized
INFO - 2023-04-29 23:03:44 --> Language Class Initialized
INFO - 2023-04-29 23:03:44 --> Loader Class Initialized
INFO - 2023-04-29 23:03:44 --> Helper loaded: url_helper
INFO - 2023-04-29 23:03:44 --> Helper loaded: form_helper
INFO - 2023-04-29 23:03:44 --> Helper loaded: file_helper
INFO - 2023-04-29 23:03:44 --> Database Driver Class Initialized
DEBUG - 2023-04-29 23:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 23:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 23:03:44 --> Form Validation Class Initialized
INFO - 2023-04-29 23:03:44 --> Upload Class Initialized
INFO - 2023-04-29 23:03:44 --> Model "M_auth" initialized
INFO - 2023-04-29 23:03:44 --> Model "M_user" initialized
INFO - 2023-04-29 23:03:44 --> Model "M_produk" initialized
INFO - 2023-04-29 23:03:44 --> Controller Class Initialized
INFO - 2023-04-29 23:03:44 --> Model "M_produk" initialized
INFO - 2023-04-29 23:03:44 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2023-04-29 23:03:44 --> Upload class already loaded. Second attempt ignored.
INFO - 2023-04-29 23:03:44 --> Config Class Initialized
INFO - 2023-04-29 23:03:44 --> Hooks Class Initialized
DEBUG - 2023-04-29 23:03:45 --> UTF-8 Support Enabled
INFO - 2023-04-29 23:03:45 --> Utf8 Class Initialized
INFO - 2023-04-29 23:03:45 --> URI Class Initialized
INFO - 2023-04-29 23:03:45 --> Router Class Initialized
INFO - 2023-04-29 23:03:45 --> Output Class Initialized
INFO - 2023-04-29 23:03:45 --> Security Class Initialized
DEBUG - 2023-04-29 23:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 23:03:45 --> Input Class Initialized
INFO - 2023-04-29 23:03:45 --> Language Class Initialized
INFO - 2023-04-29 23:03:45 --> Loader Class Initialized
INFO - 2023-04-29 23:03:45 --> Helper loaded: url_helper
INFO - 2023-04-29 23:03:45 --> Helper loaded: form_helper
INFO - 2023-04-29 23:03:45 --> Helper loaded: file_helper
INFO - 2023-04-29 23:03:45 --> Database Driver Class Initialized
DEBUG - 2023-04-29 23:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 23:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 23:03:45 --> Form Validation Class Initialized
INFO - 2023-04-29 23:03:45 --> Upload Class Initialized
INFO - 2023-04-29 23:03:45 --> Model "M_auth" initialized
INFO - 2023-04-29 23:03:45 --> Model "M_user" initialized
INFO - 2023-04-29 23:03:45 --> Model "M_produk" initialized
INFO - 2023-04-29 23:03:45 --> Controller Class Initialized
INFO - 2023-04-29 23:03:45 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 23:03:45 --> Model "M_produk" initialized
DEBUG - 2023-04-29 23:03:45 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 23:03:45 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 23:03:45 --> Model "M_transaksi" initialized
INFO - 2023-04-29 23:03:45 --> Model "M_bank" initialized
INFO - 2023-04-29 23:03:45 --> Model "M_pesan" initialized
ERROR - 2023-04-29 23:03:45 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 23:03:45 --> Config Class Initialized
INFO - 2023-04-29 23:03:45 --> Hooks Class Initialized
DEBUG - 2023-04-29 23:03:45 --> UTF-8 Support Enabled
INFO - 2023-04-29 23:03:45 --> Utf8 Class Initialized
INFO - 2023-04-29 23:03:45 --> URI Class Initialized
INFO - 2023-04-29 23:03:45 --> Router Class Initialized
INFO - 2023-04-29 23:03:45 --> Output Class Initialized
INFO - 2023-04-29 23:03:45 --> Security Class Initialized
DEBUG - 2023-04-29 23:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 23:03:45 --> Input Class Initialized
INFO - 2023-04-29 23:03:45 --> Language Class Initialized
INFO - 2023-04-29 23:03:45 --> Loader Class Initialized
INFO - 2023-04-29 23:03:45 --> Helper loaded: url_helper
INFO - 2023-04-29 23:03:45 --> Helper loaded: form_helper
INFO - 2023-04-29 23:03:45 --> Helper loaded: file_helper
INFO - 2023-04-29 23:03:45 --> Database Driver Class Initialized
DEBUG - 2023-04-29 23:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 23:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 23:03:45 --> Form Validation Class Initialized
INFO - 2023-04-29 23:03:45 --> Upload Class Initialized
INFO - 2023-04-29 23:03:45 --> Model "M_auth" initialized
INFO - 2023-04-29 23:03:45 --> Model "M_user" initialized
INFO - 2023-04-29 23:03:45 --> Model "M_produk" initialized
INFO - 2023-04-29 23:03:45 --> Controller Class Initialized
INFO - 2023-04-29 23:03:45 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-04-29 23:03:45 --> Final output sent to browser
DEBUG - 2023-04-29 23:03:45 --> Total execution time: 0.1234
INFO - 2023-04-29 23:03:47 --> Config Class Initialized
INFO - 2023-04-29 23:03:47 --> Hooks Class Initialized
DEBUG - 2023-04-29 23:03:47 --> UTF-8 Support Enabled
INFO - 2023-04-29 23:03:47 --> Utf8 Class Initialized
INFO - 2023-04-29 23:03:47 --> URI Class Initialized
INFO - 2023-04-29 23:03:47 --> Router Class Initialized
INFO - 2023-04-29 23:03:47 --> Output Class Initialized
INFO - 2023-04-29 23:03:47 --> Security Class Initialized
DEBUG - 2023-04-29 23:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 23:03:47 --> Input Class Initialized
INFO - 2023-04-29 23:03:47 --> Language Class Initialized
INFO - 2023-04-29 23:03:47 --> Loader Class Initialized
INFO - 2023-04-29 23:03:47 --> Helper loaded: url_helper
INFO - 2023-04-29 23:03:47 --> Helper loaded: form_helper
INFO - 2023-04-29 23:03:47 --> Helper loaded: file_helper
INFO - 2023-04-29 23:03:47 --> Database Driver Class Initialized
DEBUG - 2023-04-29 23:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 23:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 23:03:47 --> Form Validation Class Initialized
INFO - 2023-04-29 23:03:47 --> Upload Class Initialized
INFO - 2023-04-29 23:03:47 --> Model "M_auth" initialized
INFO - 2023-04-29 23:03:47 --> Model "M_user" initialized
INFO - 2023-04-29 23:03:47 --> Model "M_produk" initialized
INFO - 2023-04-29 23:03:47 --> Controller Class Initialized
INFO - 2023-04-29 23:03:47 --> Model "M_produk" initialized
INFO - 2023-04-29 23:03:47 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_add_produk.php
INFO - 2023-04-29 23:03:47 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 23:03:47 --> Final output sent to browser
DEBUG - 2023-04-29 23:03:47 --> Total execution time: 0.1139
INFO - 2023-04-29 23:03:54 --> Config Class Initialized
INFO - 2023-04-29 23:03:54 --> Hooks Class Initialized
DEBUG - 2023-04-29 23:03:54 --> UTF-8 Support Enabled
INFO - 2023-04-29 23:03:54 --> Utf8 Class Initialized
INFO - 2023-04-29 23:03:54 --> URI Class Initialized
INFO - 2023-04-29 23:03:54 --> Router Class Initialized
INFO - 2023-04-29 23:03:54 --> Output Class Initialized
INFO - 2023-04-29 23:03:54 --> Security Class Initialized
DEBUG - 2023-04-29 23:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 23:03:54 --> Input Class Initialized
INFO - 2023-04-29 23:03:54 --> Language Class Initialized
INFO - 2023-04-29 23:03:54 --> Loader Class Initialized
INFO - 2023-04-29 23:03:54 --> Helper loaded: url_helper
INFO - 2023-04-29 23:03:54 --> Helper loaded: form_helper
INFO - 2023-04-29 23:03:54 --> Helper loaded: file_helper
INFO - 2023-04-29 23:03:54 --> Database Driver Class Initialized
DEBUG - 2023-04-29 23:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 23:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 23:03:54 --> Form Validation Class Initialized
INFO - 2023-04-29 23:03:54 --> Upload Class Initialized
INFO - 2023-04-29 23:03:54 --> Model "M_auth" initialized
INFO - 2023-04-29 23:03:54 --> Model "M_user" initialized
INFO - 2023-04-29 23:03:54 --> Model "M_produk" initialized
INFO - 2023-04-29 23:03:54 --> Controller Class Initialized
INFO - 2023-04-29 23:03:54 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-29 23:03:54 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 23:03:54 --> Final output sent to browser
DEBUG - 2023-04-29 23:03:54 --> Total execution time: 0.0994
INFO - 2023-04-29 23:03:57 --> Config Class Initialized
INFO - 2023-04-29 23:03:57 --> Hooks Class Initialized
DEBUG - 2023-04-29 23:03:57 --> UTF-8 Support Enabled
INFO - 2023-04-29 23:03:57 --> Utf8 Class Initialized
INFO - 2023-04-29 23:03:57 --> URI Class Initialized
INFO - 2023-04-29 23:03:57 --> Router Class Initialized
INFO - 2023-04-29 23:03:57 --> Output Class Initialized
INFO - 2023-04-29 23:03:57 --> Security Class Initialized
DEBUG - 2023-04-29 23:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 23:03:57 --> Input Class Initialized
INFO - 2023-04-29 23:03:57 --> Language Class Initialized
INFO - 2023-04-29 23:03:57 --> Loader Class Initialized
INFO - 2023-04-29 23:03:57 --> Helper loaded: url_helper
INFO - 2023-04-29 23:03:57 --> Helper loaded: form_helper
INFO - 2023-04-29 23:03:57 --> Helper loaded: file_helper
INFO - 2023-04-29 23:03:57 --> Database Driver Class Initialized
DEBUG - 2023-04-29 23:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 23:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 23:03:57 --> Form Validation Class Initialized
INFO - 2023-04-29 23:03:57 --> Upload Class Initialized
INFO - 2023-04-29 23:03:57 --> Model "M_auth" initialized
INFO - 2023-04-29 23:03:57 --> Model "M_user" initialized
INFO - 2023-04-29 23:03:57 --> Model "M_produk" initialized
INFO - 2023-04-29 23:03:57 --> Controller Class Initialized
INFO - 2023-04-29 23:03:57 --> Model "M_produk" initialized
INFO - 2023-04-29 23:03:57 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-04-29 23:03:57 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 23:03:57 --> Final output sent to browser
DEBUG - 2023-04-29 23:03:57 --> Total execution time: 0.1310
INFO - 2023-04-29 23:04:09 --> Config Class Initialized
INFO - 2023-04-29 23:04:09 --> Hooks Class Initialized
DEBUG - 2023-04-29 23:04:09 --> UTF-8 Support Enabled
INFO - 2023-04-29 23:04:09 --> Utf8 Class Initialized
INFO - 2023-04-29 23:04:09 --> URI Class Initialized
INFO - 2023-04-29 23:04:09 --> Router Class Initialized
INFO - 2023-04-29 23:04:09 --> Output Class Initialized
INFO - 2023-04-29 23:04:09 --> Security Class Initialized
DEBUG - 2023-04-29 23:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 23:04:09 --> Input Class Initialized
INFO - 2023-04-29 23:04:09 --> Language Class Initialized
INFO - 2023-04-29 23:04:09 --> Loader Class Initialized
INFO - 2023-04-29 23:04:09 --> Helper loaded: url_helper
INFO - 2023-04-29 23:04:09 --> Helper loaded: form_helper
INFO - 2023-04-29 23:04:09 --> Helper loaded: file_helper
INFO - 2023-04-29 23:04:09 --> Database Driver Class Initialized
DEBUG - 2023-04-29 23:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 23:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 23:04:09 --> Form Validation Class Initialized
INFO - 2023-04-29 23:04:09 --> Upload Class Initialized
INFO - 2023-04-29 23:04:09 --> Model "M_auth" initialized
INFO - 2023-04-29 23:04:09 --> Model "M_user" initialized
INFO - 2023-04-29 23:04:09 --> Model "M_produk" initialized
INFO - 2023-04-29 23:04:09 --> Controller Class Initialized
INFO - 2023-04-29 23:04:09 --> Model "M_produk" initialized
INFO - 2023-04-29 23:04:09 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_add_produk.php
INFO - 2023-04-29 23:04:09 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 23:04:09 --> Final output sent to browser
DEBUG - 2023-04-29 23:04:09 --> Total execution time: 0.1107
INFO - 2023-04-29 23:04:26 --> Config Class Initialized
INFO - 2023-04-29 23:04:26 --> Hooks Class Initialized
DEBUG - 2023-04-29 23:04:26 --> UTF-8 Support Enabled
INFO - 2023-04-29 23:04:26 --> Utf8 Class Initialized
INFO - 2023-04-29 23:04:26 --> URI Class Initialized
INFO - 2023-04-29 23:04:26 --> Router Class Initialized
INFO - 2023-04-29 23:04:26 --> Output Class Initialized
INFO - 2023-04-29 23:04:26 --> Security Class Initialized
DEBUG - 2023-04-29 23:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 23:04:26 --> Input Class Initialized
INFO - 2023-04-29 23:04:26 --> Language Class Initialized
INFO - 2023-04-29 23:04:26 --> Loader Class Initialized
INFO - 2023-04-29 23:04:26 --> Helper loaded: url_helper
INFO - 2023-04-29 23:04:26 --> Helper loaded: form_helper
INFO - 2023-04-29 23:04:26 --> Helper loaded: file_helper
INFO - 2023-04-29 23:04:26 --> Database Driver Class Initialized
DEBUG - 2023-04-29 23:04:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 23:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 23:04:26 --> Form Validation Class Initialized
INFO - 2023-04-29 23:04:26 --> Upload Class Initialized
INFO - 2023-04-29 23:04:26 --> Model "M_auth" initialized
INFO - 2023-04-29 23:04:26 --> Model "M_user" initialized
INFO - 2023-04-29 23:04:26 --> Model "M_produk" initialized
INFO - 2023-04-29 23:04:26 --> Controller Class Initialized
INFO - 2023-04-29 23:04:26 --> Model "M_produk" initialized
INFO - 2023-04-29 23:04:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2023-04-29 23:04:26 --> Upload class already loaded. Second attempt ignored.
INFO - 2023-04-29 23:04:26 --> Config Class Initialized
INFO - 2023-04-29 23:04:26 --> Hooks Class Initialized
DEBUG - 2023-04-29 23:04:26 --> UTF-8 Support Enabled
INFO - 2023-04-29 23:04:26 --> Utf8 Class Initialized
INFO - 2023-04-29 23:04:26 --> URI Class Initialized
INFO - 2023-04-29 23:04:26 --> Router Class Initialized
INFO - 2023-04-29 23:04:26 --> Output Class Initialized
INFO - 2023-04-29 23:04:26 --> Security Class Initialized
DEBUG - 2023-04-29 23:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 23:04:26 --> Input Class Initialized
INFO - 2023-04-29 23:04:26 --> Language Class Initialized
INFO - 2023-04-29 23:04:26 --> Loader Class Initialized
INFO - 2023-04-29 23:04:26 --> Helper loaded: url_helper
INFO - 2023-04-29 23:04:26 --> Helper loaded: form_helper
INFO - 2023-04-29 23:04:26 --> Helper loaded: file_helper
INFO - 2023-04-29 23:04:26 --> Database Driver Class Initialized
DEBUG - 2023-04-29 23:04:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 23:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 23:04:26 --> Form Validation Class Initialized
INFO - 2023-04-29 23:04:26 --> Upload Class Initialized
INFO - 2023-04-29 23:04:26 --> Model "M_auth" initialized
INFO - 2023-04-29 23:04:26 --> Model "M_user" initialized
INFO - 2023-04-29 23:04:26 --> Model "M_produk" initialized
INFO - 2023-04-29 23:04:26 --> Controller Class Initialized
INFO - 2023-04-29 23:04:26 --> Model "M_pelanggan" initialized
INFO - 2023-04-29 23:04:26 --> Model "M_produk" initialized
DEBUG - 2023-04-29 23:04:26 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-29 23:04:26 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-29 23:04:26 --> Model "M_transaksi" initialized
INFO - 2023-04-29 23:04:26 --> Model "M_bank" initialized
INFO - 2023-04-29 23:04:26 --> Model "M_pesan" initialized
ERROR - 2023-04-29 23:04:26 --> Severity: Warning --> Attempt to read property "slug" on null C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front\v_produk_detail.php 98
INFO - 2023-04-29 23:04:26 --> Config Class Initialized
INFO - 2023-04-29 23:04:26 --> Hooks Class Initialized
DEBUG - 2023-04-29 23:04:26 --> UTF-8 Support Enabled
INFO - 2023-04-29 23:04:26 --> Utf8 Class Initialized
INFO - 2023-04-29 23:04:26 --> URI Class Initialized
INFO - 2023-04-29 23:04:26 --> Router Class Initialized
INFO - 2023-04-29 23:04:26 --> Output Class Initialized
INFO - 2023-04-29 23:04:26 --> Security Class Initialized
DEBUG - 2023-04-29 23:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 23:04:26 --> Input Class Initialized
INFO - 2023-04-29 23:04:26 --> Language Class Initialized
INFO - 2023-04-29 23:04:26 --> Loader Class Initialized
INFO - 2023-04-29 23:04:26 --> Helper loaded: url_helper
INFO - 2023-04-29 23:04:26 --> Helper loaded: form_helper
INFO - 2023-04-29 23:04:26 --> Helper loaded: file_helper
INFO - 2023-04-29 23:04:26 --> Database Driver Class Initialized
DEBUG - 2023-04-29 23:04:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 23:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 23:04:26 --> Form Validation Class Initialized
INFO - 2023-04-29 23:04:26 --> Upload Class Initialized
INFO - 2023-04-29 23:04:26 --> Model "M_auth" initialized
INFO - 2023-04-29 23:04:26 --> Model "M_user" initialized
INFO - 2023-04-29 23:04:26 --> Model "M_produk" initialized
INFO - 2023-04-29 23:04:26 --> Controller Class Initialized
INFO - 2023-04-29 23:04:26 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-04-29 23:04:26 --> Final output sent to browser
DEBUG - 2023-04-29 23:04:26 --> Total execution time: 0.1255
INFO - 2023-04-29 23:05:35 --> Config Class Initialized
INFO - 2023-04-29 23:05:35 --> Hooks Class Initialized
DEBUG - 2023-04-29 23:05:35 --> UTF-8 Support Enabled
INFO - 2023-04-29 23:05:35 --> Utf8 Class Initialized
INFO - 2023-04-29 23:05:35 --> URI Class Initialized
INFO - 2023-04-29 23:05:35 --> Router Class Initialized
INFO - 2023-04-29 23:05:35 --> Output Class Initialized
INFO - 2023-04-29 23:05:35 --> Security Class Initialized
DEBUG - 2023-04-29 23:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 23:05:35 --> Input Class Initialized
INFO - 2023-04-29 23:05:35 --> Language Class Initialized
INFO - 2023-04-29 23:05:35 --> Loader Class Initialized
INFO - 2023-04-29 23:05:35 --> Helper loaded: url_helper
INFO - 2023-04-29 23:05:35 --> Helper loaded: form_helper
INFO - 2023-04-29 23:05:35 --> Helper loaded: file_helper
INFO - 2023-04-29 23:05:35 --> Database Driver Class Initialized
DEBUG - 2023-04-29 23:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 23:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 23:05:35 --> Form Validation Class Initialized
INFO - 2023-04-29 23:05:35 --> Upload Class Initialized
INFO - 2023-04-29 23:05:35 --> Model "M_auth" initialized
INFO - 2023-04-29 23:05:35 --> Model "M_user" initialized
INFO - 2023-04-29 23:05:35 --> Model "M_produk" initialized
INFO - 2023-04-29 23:05:35 --> Controller Class Initialized
INFO - 2023-04-29 23:05:35 --> Model "M_produk" initialized
INFO - 2023-04-29 23:05:35 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_add_produk.php
INFO - 2023-04-29 23:05:35 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 23:05:35 --> Final output sent to browser
DEBUG - 2023-04-29 23:05:35 --> Total execution time: 0.1693
INFO - 2023-04-29 23:05:38 --> Config Class Initialized
INFO - 2023-04-29 23:05:38 --> Hooks Class Initialized
DEBUG - 2023-04-29 23:05:38 --> UTF-8 Support Enabled
INFO - 2023-04-29 23:05:38 --> Utf8 Class Initialized
INFO - 2023-04-29 23:05:38 --> URI Class Initialized
INFO - 2023-04-29 23:05:38 --> Router Class Initialized
INFO - 2023-04-29 23:05:38 --> Output Class Initialized
INFO - 2023-04-29 23:05:38 --> Security Class Initialized
DEBUG - 2023-04-29 23:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 23:05:38 --> Input Class Initialized
INFO - 2023-04-29 23:05:38 --> Language Class Initialized
INFO - 2023-04-29 23:05:38 --> Loader Class Initialized
INFO - 2023-04-29 23:05:38 --> Helper loaded: url_helper
INFO - 2023-04-29 23:05:38 --> Helper loaded: form_helper
INFO - 2023-04-29 23:05:38 --> Helper loaded: file_helper
INFO - 2023-04-29 23:05:38 --> Database Driver Class Initialized
DEBUG - 2023-04-29 23:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 23:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 23:05:38 --> Form Validation Class Initialized
INFO - 2023-04-29 23:05:38 --> Upload Class Initialized
INFO - 2023-04-29 23:05:38 --> Model "M_auth" initialized
INFO - 2023-04-29 23:05:38 --> Model "M_user" initialized
INFO - 2023-04-29 23:05:38 --> Model "M_produk" initialized
INFO - 2023-04-29 23:05:38 --> Controller Class Initialized
INFO - 2023-04-29 23:05:38 --> Model "M_produk" initialized
INFO - 2023-04-29 23:05:38 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2023-04-29 23:05:38 --> Upload class already loaded. Second attempt ignored.
INFO - 2023-04-29 23:05:38 --> Config Class Initialized
INFO - 2023-04-29 23:05:38 --> Hooks Class Initialized
DEBUG - 2023-04-29 23:05:38 --> UTF-8 Support Enabled
INFO - 2023-04-29 23:05:38 --> Utf8 Class Initialized
INFO - 2023-04-29 23:05:38 --> URI Class Initialized
INFO - 2023-04-29 23:05:38 --> Router Class Initialized
INFO - 2023-04-29 23:05:38 --> Output Class Initialized
INFO - 2023-04-29 23:05:38 --> Security Class Initialized
DEBUG - 2023-04-29 23:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 23:05:38 --> Input Class Initialized
INFO - 2023-04-29 23:05:38 --> Language Class Initialized
INFO - 2023-04-29 23:05:38 --> Loader Class Initialized
INFO - 2023-04-29 23:05:38 --> Helper loaded: url_helper
INFO - 2023-04-29 23:05:38 --> Helper loaded: form_helper
INFO - 2023-04-29 23:05:38 --> Helper loaded: file_helper
INFO - 2023-04-29 23:05:38 --> Database Driver Class Initialized
DEBUG - 2023-04-29 23:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 23:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 23:05:38 --> Form Validation Class Initialized
INFO - 2023-04-29 23:05:38 --> Upload Class Initialized
INFO - 2023-04-29 23:05:38 --> Model "M_auth" initialized
INFO - 2023-04-29 23:05:38 --> Model "M_user" initialized
INFO - 2023-04-29 23:05:38 --> Model "M_produk" initialized
INFO - 2023-04-29 23:05:38 --> Controller Class Initialized
INFO - 2023-04-29 23:05:38 --> Model "M_produk" initialized
INFO - 2023-04-29 23:05:38 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-04-29 23:05:38 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 23:05:38 --> Final output sent to browser
DEBUG - 2023-04-29 23:05:38 --> Total execution time: 0.0989
INFO - 2023-04-29 23:05:42 --> Config Class Initialized
INFO - 2023-04-29 23:05:42 --> Hooks Class Initialized
DEBUG - 2023-04-29 23:05:42 --> UTF-8 Support Enabled
INFO - 2023-04-29 23:05:42 --> Utf8 Class Initialized
INFO - 2023-04-29 23:05:42 --> URI Class Initialized
INFO - 2023-04-29 23:05:42 --> Router Class Initialized
INFO - 2023-04-29 23:05:42 --> Output Class Initialized
INFO - 2023-04-29 23:05:42 --> Security Class Initialized
DEBUG - 2023-04-29 23:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 23:05:42 --> Input Class Initialized
INFO - 2023-04-29 23:05:42 --> Language Class Initialized
INFO - 2023-04-29 23:05:42 --> Loader Class Initialized
INFO - 2023-04-29 23:05:42 --> Helper loaded: url_helper
INFO - 2023-04-29 23:05:42 --> Helper loaded: form_helper
INFO - 2023-04-29 23:05:42 --> Helper loaded: file_helper
INFO - 2023-04-29 23:05:42 --> Database Driver Class Initialized
DEBUG - 2023-04-29 23:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 23:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 23:05:42 --> Form Validation Class Initialized
INFO - 2023-04-29 23:05:42 --> Upload Class Initialized
INFO - 2023-04-29 23:05:42 --> Model "M_auth" initialized
INFO - 2023-04-29 23:05:42 --> Model "M_user" initialized
INFO - 2023-04-29 23:05:42 --> Model "M_produk" initialized
INFO - 2023-04-29 23:05:42 --> Controller Class Initialized
INFO - 2023-04-29 23:05:42 --> Model "M_produk" initialized
INFO - 2023-04-29 23:05:42 --> Config Class Initialized
INFO - 2023-04-29 23:05:42 --> Hooks Class Initialized
DEBUG - 2023-04-29 23:05:42 --> UTF-8 Support Enabled
INFO - 2023-04-29 23:05:42 --> Utf8 Class Initialized
INFO - 2023-04-29 23:05:42 --> URI Class Initialized
INFO - 2023-04-29 23:05:42 --> Router Class Initialized
INFO - 2023-04-29 23:05:42 --> Output Class Initialized
INFO - 2023-04-29 23:05:42 --> Security Class Initialized
DEBUG - 2023-04-29 23:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 23:05:42 --> Input Class Initialized
INFO - 2023-04-29 23:05:42 --> Language Class Initialized
INFO - 2023-04-29 23:05:42 --> Loader Class Initialized
INFO - 2023-04-29 23:05:42 --> Helper loaded: url_helper
INFO - 2023-04-29 23:05:42 --> Helper loaded: form_helper
INFO - 2023-04-29 23:05:42 --> Helper loaded: file_helper
INFO - 2023-04-29 23:05:42 --> Database Driver Class Initialized
DEBUG - 2023-04-29 23:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 23:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 23:05:42 --> Form Validation Class Initialized
INFO - 2023-04-29 23:05:42 --> Upload Class Initialized
INFO - 2023-04-29 23:05:42 --> Model "M_auth" initialized
INFO - 2023-04-29 23:05:42 --> Model "M_user" initialized
INFO - 2023-04-29 23:05:42 --> Model "M_produk" initialized
INFO - 2023-04-29 23:05:42 --> Controller Class Initialized
INFO - 2023-04-29 23:05:42 --> Model "M_produk" initialized
INFO - 2023-04-29 23:05:43 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-04-29 23:05:43 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 23:05:43 --> Final output sent to browser
DEBUG - 2023-04-29 23:05:43 --> Total execution time: 0.0936
INFO - 2023-04-29 23:06:45 --> Config Class Initialized
INFO - 2023-04-29 23:06:45 --> Hooks Class Initialized
DEBUG - 2023-04-29 23:06:45 --> UTF-8 Support Enabled
INFO - 2023-04-29 23:06:45 --> Utf8 Class Initialized
INFO - 2023-04-29 23:06:45 --> URI Class Initialized
INFO - 2023-04-29 23:06:45 --> Router Class Initialized
INFO - 2023-04-29 23:06:45 --> Output Class Initialized
INFO - 2023-04-29 23:06:45 --> Security Class Initialized
DEBUG - 2023-04-29 23:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 23:06:45 --> Input Class Initialized
INFO - 2023-04-29 23:06:45 --> Language Class Initialized
INFO - 2023-04-29 23:06:45 --> Loader Class Initialized
INFO - 2023-04-29 23:06:45 --> Helper loaded: url_helper
INFO - 2023-04-29 23:06:45 --> Helper loaded: form_helper
INFO - 2023-04-29 23:06:45 --> Helper loaded: file_helper
INFO - 2023-04-29 23:06:45 --> Database Driver Class Initialized
DEBUG - 2023-04-29 23:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 23:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 23:06:45 --> Form Validation Class Initialized
INFO - 2023-04-29 23:06:45 --> Upload Class Initialized
INFO - 2023-04-29 23:06:45 --> Model "M_auth" initialized
INFO - 2023-04-29 23:06:45 --> Model "M_user" initialized
INFO - 2023-04-29 23:06:45 --> Model "M_produk" initialized
INFO - 2023-04-29 23:06:45 --> Controller Class Initialized
INFO - 2023-04-29 23:06:45 --> Model "M_produk" initialized
INFO - 2023-04-29 23:06:45 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-04-29 23:06:45 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 23:06:45 --> Final output sent to browser
DEBUG - 2023-04-29 23:06:45 --> Total execution time: 0.1281
INFO - 2023-04-29 23:06:52 --> Config Class Initialized
INFO - 2023-04-29 23:06:52 --> Hooks Class Initialized
DEBUG - 2023-04-29 23:06:52 --> UTF-8 Support Enabled
INFO - 2023-04-29 23:06:52 --> Utf8 Class Initialized
INFO - 2023-04-29 23:06:52 --> URI Class Initialized
INFO - 2023-04-29 23:06:52 --> Router Class Initialized
INFO - 2023-04-29 23:06:52 --> Output Class Initialized
INFO - 2023-04-29 23:06:52 --> Security Class Initialized
DEBUG - 2023-04-29 23:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 23:06:52 --> Input Class Initialized
INFO - 2023-04-29 23:06:52 --> Language Class Initialized
INFO - 2023-04-29 23:06:52 --> Loader Class Initialized
INFO - 2023-04-29 23:06:52 --> Helper loaded: url_helper
INFO - 2023-04-29 23:06:52 --> Helper loaded: form_helper
INFO - 2023-04-29 23:06:52 --> Helper loaded: file_helper
INFO - 2023-04-29 23:06:52 --> Database Driver Class Initialized
DEBUG - 2023-04-29 23:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 23:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 23:06:52 --> Form Validation Class Initialized
INFO - 2023-04-29 23:06:52 --> Upload Class Initialized
INFO - 2023-04-29 23:06:52 --> Model "M_auth" initialized
INFO - 2023-04-29 23:06:52 --> Model "M_user" initialized
INFO - 2023-04-29 23:06:52 --> Model "M_produk" initialized
INFO - 2023-04-29 23:06:52 --> Controller Class Initialized
INFO - 2023-04-29 23:06:52 --> Model "M_produk" initialized
INFO - 2023-04-29 23:06:52 --> Config Class Initialized
INFO - 2023-04-29 23:06:52 --> Hooks Class Initialized
DEBUG - 2023-04-29 23:06:52 --> UTF-8 Support Enabled
INFO - 2023-04-29 23:06:52 --> Utf8 Class Initialized
INFO - 2023-04-29 23:06:52 --> URI Class Initialized
INFO - 2023-04-29 23:06:52 --> Router Class Initialized
INFO - 2023-04-29 23:06:52 --> Output Class Initialized
INFO - 2023-04-29 23:06:52 --> Security Class Initialized
DEBUG - 2023-04-29 23:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 23:06:52 --> Input Class Initialized
INFO - 2023-04-29 23:06:52 --> Language Class Initialized
INFO - 2023-04-29 23:06:52 --> Loader Class Initialized
INFO - 2023-04-29 23:06:52 --> Helper loaded: url_helper
INFO - 2023-04-29 23:06:52 --> Helper loaded: form_helper
INFO - 2023-04-29 23:06:52 --> Helper loaded: file_helper
INFO - 2023-04-29 23:06:52 --> Database Driver Class Initialized
DEBUG - 2023-04-29 23:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 23:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 23:06:52 --> Form Validation Class Initialized
INFO - 2023-04-29 23:06:52 --> Upload Class Initialized
INFO - 2023-04-29 23:06:52 --> Model "M_auth" initialized
INFO - 2023-04-29 23:06:52 --> Model "M_user" initialized
INFO - 2023-04-29 23:06:52 --> Model "M_produk" initialized
INFO - 2023-04-29 23:06:52 --> Controller Class Initialized
INFO - 2023-04-29 23:06:52 --> Model "M_produk" initialized
INFO - 2023-04-29 23:06:52 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-04-29 23:06:52 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 23:06:52 --> Final output sent to browser
DEBUG - 2023-04-29 23:06:52 --> Total execution time: 0.1144
INFO - 2023-04-29 23:06:55 --> Config Class Initialized
INFO - 2023-04-29 23:06:55 --> Hooks Class Initialized
DEBUG - 2023-04-29 23:06:55 --> UTF-8 Support Enabled
INFO - 2023-04-29 23:06:55 --> Utf8 Class Initialized
INFO - 2023-04-29 23:06:55 --> URI Class Initialized
INFO - 2023-04-29 23:06:55 --> Router Class Initialized
INFO - 2023-04-29 23:06:55 --> Output Class Initialized
INFO - 2023-04-29 23:06:55 --> Security Class Initialized
DEBUG - 2023-04-29 23:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 23:06:55 --> Input Class Initialized
INFO - 2023-04-29 23:06:55 --> Language Class Initialized
INFO - 2023-04-29 23:06:55 --> Loader Class Initialized
INFO - 2023-04-29 23:06:55 --> Helper loaded: url_helper
INFO - 2023-04-29 23:06:55 --> Helper loaded: form_helper
INFO - 2023-04-29 23:06:55 --> Helper loaded: file_helper
INFO - 2023-04-29 23:06:55 --> Database Driver Class Initialized
DEBUG - 2023-04-29 23:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 23:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 23:06:55 --> Form Validation Class Initialized
INFO - 2023-04-29 23:06:55 --> Upload Class Initialized
INFO - 2023-04-29 23:06:55 --> Model "M_auth" initialized
INFO - 2023-04-29 23:06:55 --> Model "M_user" initialized
INFO - 2023-04-29 23:06:55 --> Model "M_produk" initialized
INFO - 2023-04-29 23:06:55 --> Controller Class Initialized
INFO - 2023-04-29 23:06:55 --> Model "M_produk" initialized
INFO - 2023-04-29 23:06:55 --> Config Class Initialized
INFO - 2023-04-29 23:06:55 --> Hooks Class Initialized
DEBUG - 2023-04-29 23:06:55 --> UTF-8 Support Enabled
INFO - 2023-04-29 23:06:55 --> Utf8 Class Initialized
INFO - 2023-04-29 23:06:55 --> URI Class Initialized
INFO - 2023-04-29 23:06:55 --> Router Class Initialized
INFO - 2023-04-29 23:06:55 --> Output Class Initialized
INFO - 2023-04-29 23:06:55 --> Security Class Initialized
DEBUG - 2023-04-29 23:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 23:06:55 --> Input Class Initialized
INFO - 2023-04-29 23:06:55 --> Language Class Initialized
INFO - 2023-04-29 23:06:55 --> Loader Class Initialized
INFO - 2023-04-29 23:06:55 --> Helper loaded: url_helper
INFO - 2023-04-29 23:06:55 --> Helper loaded: form_helper
INFO - 2023-04-29 23:06:55 --> Helper loaded: file_helper
INFO - 2023-04-29 23:06:55 --> Database Driver Class Initialized
DEBUG - 2023-04-29 23:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 23:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 23:06:55 --> Form Validation Class Initialized
INFO - 2023-04-29 23:06:55 --> Upload Class Initialized
INFO - 2023-04-29 23:06:55 --> Model "M_auth" initialized
INFO - 2023-04-29 23:06:55 --> Model "M_user" initialized
INFO - 2023-04-29 23:06:55 --> Model "M_produk" initialized
INFO - 2023-04-29 23:06:55 --> Controller Class Initialized
INFO - 2023-04-29 23:06:55 --> Model "M_produk" initialized
INFO - 2023-04-29 23:06:55 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-04-29 23:06:55 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 23:06:55 --> Final output sent to browser
DEBUG - 2023-04-29 23:06:55 --> Total execution time: 0.1012
INFO - 2023-04-29 23:06:58 --> Config Class Initialized
INFO - 2023-04-29 23:06:58 --> Hooks Class Initialized
DEBUG - 2023-04-29 23:06:58 --> UTF-8 Support Enabled
INFO - 2023-04-29 23:06:58 --> Utf8 Class Initialized
INFO - 2023-04-29 23:06:58 --> URI Class Initialized
INFO - 2023-04-29 23:06:58 --> Router Class Initialized
INFO - 2023-04-29 23:06:58 --> Output Class Initialized
INFO - 2023-04-29 23:06:58 --> Security Class Initialized
DEBUG - 2023-04-29 23:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-29 23:06:58 --> Input Class Initialized
INFO - 2023-04-29 23:06:58 --> Language Class Initialized
INFO - 2023-04-29 23:06:58 --> Loader Class Initialized
INFO - 2023-04-29 23:06:58 --> Helper loaded: url_helper
INFO - 2023-04-29 23:06:58 --> Helper loaded: form_helper
INFO - 2023-04-29 23:06:58 --> Helper loaded: file_helper
INFO - 2023-04-29 23:06:58 --> Database Driver Class Initialized
DEBUG - 2023-04-29 23:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-29 23:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-29 23:06:58 --> Form Validation Class Initialized
INFO - 2023-04-29 23:06:58 --> Upload Class Initialized
INFO - 2023-04-29 23:06:58 --> Model "M_auth" initialized
INFO - 2023-04-29 23:06:58 --> Model "M_user" initialized
INFO - 2023-04-29 23:06:58 --> Model "M_produk" initialized
INFO - 2023-04-29 23:06:58 --> Controller Class Initialized
INFO - 2023-04-29 23:06:58 --> Model "M_produk" initialized
INFO - 2023-04-29 23:06:58 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_typeproduk.php
INFO - 2023-04-29 23:06:58 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-29 23:06:58 --> Final output sent to browser
DEBUG - 2023-04-29 23:06:58 --> Total execution time: 0.1070
