<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-23 01:21:24 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-23 01:21:24 --> Config Class Initialized
INFO - 2023-11-23 01:21:24 --> Hooks Class Initialized
DEBUG - 2023-11-23 01:21:24 --> UTF-8 Support Enabled
INFO - 2023-11-23 01:21:24 --> Utf8 Class Initialized
INFO - 2023-11-23 01:21:24 --> URI Class Initialized
DEBUG - 2023-11-23 01:21:24 --> No URI present. Default controller set.
INFO - 2023-11-23 01:21:24 --> Router Class Initialized
INFO - 2023-11-23 01:21:24 --> Output Class Initialized
INFO - 2023-11-23 01:21:24 --> Security Class Initialized
DEBUG - 2023-11-23 01:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 01:21:24 --> Input Class Initialized
INFO - 2023-11-23 01:21:24 --> Language Class Initialized
INFO - 2023-11-23 01:21:24 --> Loader Class Initialized
INFO - 2023-11-23 01:21:24 --> Helper loaded: url_helper
INFO - 2023-11-23 01:21:24 --> Helper loaded: form_helper
INFO - 2023-11-23 01:21:24 --> Helper loaded: file_helper
INFO - 2023-11-23 01:21:24 --> Database Driver Class Initialized
DEBUG - 2023-11-23 01:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-23 01:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 01:21:24 --> Form Validation Class Initialized
INFO - 2023-11-23 01:21:24 --> Upload Class Initialized
INFO - 2023-11-23 01:21:24 --> Model "M_auth" initialized
INFO - 2023-11-23 01:21:24 --> Model "M_user" initialized
INFO - 2023-11-23 01:21:24 --> Model "M_produk" initialized
INFO - 2023-11-23 01:21:24 --> Controller Class Initialized
INFO - 2023-11-23 01:21:24 --> Model "M_pelanggan" initialized
INFO - 2023-11-23 01:21:24 --> Model "M_produk" initialized
DEBUG - 2023-11-23 01:21:24 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 01:21:24 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-23 01:21:24 --> Model "M_transaksi" initialized
INFO - 2023-11-23 01:21:24 --> Model "M_bank" initialized
INFO - 2023-11-23 01:21:24 --> Model "M_pesan" initialized
DEBUG - 2023-11-23 01:21:24 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-23 01:21:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-23 01:21:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-23 01:21:24 --> Final output sent to browser
DEBUG - 2023-11-23 01:21:24 --> Total execution time: 0.0333
ERROR - 2023-11-23 02:38:48 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-23 02:38:48 --> Config Class Initialized
INFO - 2023-11-23 02:38:48 --> Hooks Class Initialized
DEBUG - 2023-11-23 02:38:48 --> UTF-8 Support Enabled
INFO - 2023-11-23 02:38:48 --> Utf8 Class Initialized
INFO - 2023-11-23 02:38:48 --> URI Class Initialized
INFO - 2023-11-23 02:38:48 --> Router Class Initialized
INFO - 2023-11-23 02:38:48 --> Output Class Initialized
INFO - 2023-11-23 02:38:48 --> Security Class Initialized
DEBUG - 2023-11-23 02:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 02:38:48 --> Input Class Initialized
INFO - 2023-11-23 02:38:48 --> Language Class Initialized
INFO - 2023-11-23 02:38:48 --> Loader Class Initialized
INFO - 2023-11-23 02:38:48 --> Helper loaded: url_helper
INFO - 2023-11-23 02:38:48 --> Helper loaded: form_helper
INFO - 2023-11-23 02:38:48 --> Helper loaded: file_helper
INFO - 2023-11-23 02:38:48 --> Database Driver Class Initialized
DEBUG - 2023-11-23 02:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-23 02:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 02:38:48 --> Form Validation Class Initialized
INFO - 2023-11-23 02:38:48 --> Upload Class Initialized
INFO - 2023-11-23 02:38:48 --> Model "M_auth" initialized
INFO - 2023-11-23 02:38:48 --> Model "M_user" initialized
INFO - 2023-11-23 02:38:48 --> Model "M_produk" initialized
INFO - 2023-11-23 02:38:48 --> Controller Class Initialized
INFO - 2023-11-23 02:38:48 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-23 02:38:48 --> Final output sent to browser
DEBUG - 2023-11-23 02:38:48 --> Total execution time: 0.0250
ERROR - 2023-11-23 03:04:11 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-23 03:04:11 --> Config Class Initialized
INFO - 2023-11-23 03:04:11 --> Hooks Class Initialized
DEBUG - 2023-11-23 03:04:11 --> UTF-8 Support Enabled
INFO - 2023-11-23 03:04:11 --> Utf8 Class Initialized
INFO - 2023-11-23 03:04:11 --> URI Class Initialized
DEBUG - 2023-11-23 03:04:11 --> No URI present. Default controller set.
INFO - 2023-11-23 03:04:11 --> Router Class Initialized
INFO - 2023-11-23 03:04:11 --> Output Class Initialized
INFO - 2023-11-23 03:04:11 --> Security Class Initialized
DEBUG - 2023-11-23 03:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 03:04:11 --> Input Class Initialized
INFO - 2023-11-23 03:04:11 --> Language Class Initialized
INFO - 2023-11-23 03:04:11 --> Loader Class Initialized
INFO - 2023-11-23 03:04:11 --> Helper loaded: url_helper
INFO - 2023-11-23 03:04:11 --> Helper loaded: form_helper
INFO - 2023-11-23 03:04:11 --> Helper loaded: file_helper
INFO - 2023-11-23 03:04:11 --> Database Driver Class Initialized
DEBUG - 2023-11-23 03:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-23 03:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 03:04:11 --> Form Validation Class Initialized
INFO - 2023-11-23 03:04:11 --> Upload Class Initialized
INFO - 2023-11-23 03:04:11 --> Model "M_auth" initialized
INFO - 2023-11-23 03:04:11 --> Model "M_user" initialized
INFO - 2023-11-23 03:04:11 --> Model "M_produk" initialized
INFO - 2023-11-23 03:04:11 --> Controller Class Initialized
INFO - 2023-11-23 03:04:11 --> Model "M_pelanggan" initialized
INFO - 2023-11-23 03:04:11 --> Model "M_produk" initialized
DEBUG - 2023-11-23 03:04:11 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 03:04:11 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-23 03:04:11 --> Model "M_transaksi" initialized
INFO - 2023-11-23 03:04:11 --> Model "M_bank" initialized
INFO - 2023-11-23 03:04:11 --> Model "M_pesan" initialized
DEBUG - 2023-11-23 03:04:11 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-23 03:04:11 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-23 03:04:11 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-23 03:04:11 --> Final output sent to browser
DEBUG - 2023-11-23 03:04:11 --> Total execution time: 0.0351
ERROR - 2023-11-23 04:05:08 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-23 04:05:08 --> Config Class Initialized
INFO - 2023-11-23 04:05:08 --> Hooks Class Initialized
DEBUG - 2023-11-23 04:05:08 --> UTF-8 Support Enabled
INFO - 2023-11-23 04:05:08 --> Utf8 Class Initialized
INFO - 2023-11-23 04:05:08 --> URI Class Initialized
DEBUG - 2023-11-23 04:05:08 --> No URI present. Default controller set.
INFO - 2023-11-23 04:05:08 --> Router Class Initialized
INFO - 2023-11-23 04:05:08 --> Output Class Initialized
INFO - 2023-11-23 04:05:08 --> Security Class Initialized
DEBUG - 2023-11-23 04:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 04:05:08 --> Input Class Initialized
INFO - 2023-11-23 04:05:08 --> Language Class Initialized
INFO - 2023-11-23 04:05:08 --> Loader Class Initialized
INFO - 2023-11-23 04:05:08 --> Helper loaded: url_helper
INFO - 2023-11-23 04:05:08 --> Helper loaded: form_helper
INFO - 2023-11-23 04:05:08 --> Helper loaded: file_helper
INFO - 2023-11-23 04:05:08 --> Database Driver Class Initialized
DEBUG - 2023-11-23 04:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-23 04:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 04:05:08 --> Form Validation Class Initialized
INFO - 2023-11-23 04:05:08 --> Upload Class Initialized
INFO - 2023-11-23 04:05:08 --> Model "M_auth" initialized
INFO - 2023-11-23 04:05:08 --> Model "M_user" initialized
INFO - 2023-11-23 04:05:08 --> Model "M_produk" initialized
INFO - 2023-11-23 04:05:08 --> Controller Class Initialized
INFO - 2023-11-23 04:05:08 --> Model "M_pelanggan" initialized
INFO - 2023-11-23 04:05:08 --> Model "M_produk" initialized
DEBUG - 2023-11-23 04:05:08 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 04:05:08 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-23 04:05:08 --> Model "M_transaksi" initialized
INFO - 2023-11-23 04:05:08 --> Model "M_bank" initialized
INFO - 2023-11-23 04:05:08 --> Model "M_pesan" initialized
DEBUG - 2023-11-23 04:05:08 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-23 04:05:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-23 04:05:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-23 04:05:08 --> Final output sent to browser
DEBUG - 2023-11-23 04:05:08 --> Total execution time: 0.0318
ERROR - 2023-11-23 05:38:48 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-23 05:38:48 --> Config Class Initialized
INFO - 2023-11-23 05:38:48 --> Hooks Class Initialized
DEBUG - 2023-11-23 05:38:48 --> UTF-8 Support Enabled
INFO - 2023-11-23 05:38:48 --> Utf8 Class Initialized
INFO - 2023-11-23 05:38:48 --> URI Class Initialized
DEBUG - 2023-11-23 05:38:48 --> No URI present. Default controller set.
INFO - 2023-11-23 05:38:48 --> Router Class Initialized
INFO - 2023-11-23 05:38:48 --> Output Class Initialized
INFO - 2023-11-23 05:38:48 --> Security Class Initialized
DEBUG - 2023-11-23 05:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 05:38:48 --> Input Class Initialized
INFO - 2023-11-23 05:38:48 --> Language Class Initialized
INFO - 2023-11-23 05:38:48 --> Loader Class Initialized
INFO - 2023-11-23 05:38:48 --> Helper loaded: url_helper
INFO - 2023-11-23 05:38:48 --> Helper loaded: form_helper
INFO - 2023-11-23 05:38:48 --> Helper loaded: file_helper
INFO - 2023-11-23 05:38:48 --> Database Driver Class Initialized
DEBUG - 2023-11-23 05:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-23 05:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 05:38:48 --> Form Validation Class Initialized
INFO - 2023-11-23 05:38:48 --> Upload Class Initialized
INFO - 2023-11-23 05:38:48 --> Model "M_auth" initialized
INFO - 2023-11-23 05:38:48 --> Model "M_user" initialized
INFO - 2023-11-23 05:38:48 --> Model "M_produk" initialized
INFO - 2023-11-23 05:38:48 --> Controller Class Initialized
INFO - 2023-11-23 05:38:48 --> Model "M_pelanggan" initialized
INFO - 2023-11-23 05:38:48 --> Model "M_produk" initialized
DEBUG - 2023-11-23 05:38:48 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 05:38:48 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-23 05:38:48 --> Model "M_transaksi" initialized
INFO - 2023-11-23 05:38:48 --> Model "M_bank" initialized
INFO - 2023-11-23 05:38:48 --> Model "M_pesan" initialized
DEBUG - 2023-11-23 05:38:48 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-23 05:38:48 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-23 05:38:48 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-23 05:38:48 --> Final output sent to browser
DEBUG - 2023-11-23 05:38:48 --> Total execution time: 0.0344
ERROR - 2023-11-23 09:40:41 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-23 09:40:41 --> Config Class Initialized
INFO - 2023-11-23 09:40:41 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:40:41 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:40:41 --> Utf8 Class Initialized
INFO - 2023-11-23 09:40:41 --> URI Class Initialized
DEBUG - 2023-11-23 09:40:41 --> No URI present. Default controller set.
INFO - 2023-11-23 09:40:41 --> Router Class Initialized
INFO - 2023-11-23 09:40:41 --> Output Class Initialized
INFO - 2023-11-23 09:40:41 --> Security Class Initialized
DEBUG - 2023-11-23 09:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:40:41 --> Input Class Initialized
INFO - 2023-11-23 09:40:41 --> Language Class Initialized
INFO - 2023-11-23 09:40:41 --> Loader Class Initialized
INFO - 2023-11-23 09:40:41 --> Helper loaded: url_helper
INFO - 2023-11-23 09:40:41 --> Helper loaded: form_helper
INFO - 2023-11-23 09:40:41 --> Helper loaded: file_helper
INFO - 2023-11-23 09:40:41 --> Database Driver Class Initialized
DEBUG - 2023-11-23 09:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-23 09:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:40:41 --> Form Validation Class Initialized
INFO - 2023-11-23 09:40:41 --> Upload Class Initialized
INFO - 2023-11-23 09:40:41 --> Model "M_auth" initialized
INFO - 2023-11-23 09:40:41 --> Model "M_user" initialized
INFO - 2023-11-23 09:40:41 --> Model "M_produk" initialized
INFO - 2023-11-23 09:40:41 --> Controller Class Initialized
INFO - 2023-11-23 09:40:41 --> Model "M_pelanggan" initialized
INFO - 2023-11-23 09:40:41 --> Model "M_produk" initialized
DEBUG - 2023-11-23 09:40:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 09:40:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-23 09:40:41 --> Model "M_transaksi" initialized
INFO - 2023-11-23 09:40:41 --> Model "M_bank" initialized
INFO - 2023-11-23 09:40:41 --> Model "M_pesan" initialized
DEBUG - 2023-11-23 09:40:41 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-23 09:40:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-23 09:40:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-23 09:40:41 --> Final output sent to browser
DEBUG - 2023-11-23 09:40:41 --> Total execution time: 0.0313
ERROR - 2023-11-23 11:36:32 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-23 11:36:32 --> Config Class Initialized
INFO - 2023-11-23 11:36:32 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:36:32 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:36:32 --> Utf8 Class Initialized
INFO - 2023-11-23 11:36:32 --> URI Class Initialized
DEBUG - 2023-11-23 11:36:32 --> No URI present. Default controller set.
INFO - 2023-11-23 11:36:32 --> Router Class Initialized
INFO - 2023-11-23 11:36:32 --> Output Class Initialized
INFO - 2023-11-23 11:36:32 --> Security Class Initialized
DEBUG - 2023-11-23 11:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:36:32 --> Input Class Initialized
INFO - 2023-11-23 11:36:32 --> Language Class Initialized
INFO - 2023-11-23 11:36:32 --> Loader Class Initialized
INFO - 2023-11-23 11:36:32 --> Helper loaded: url_helper
INFO - 2023-11-23 11:36:32 --> Helper loaded: form_helper
INFO - 2023-11-23 11:36:32 --> Helper loaded: file_helper
INFO - 2023-11-23 11:36:32 --> Database Driver Class Initialized
DEBUG - 2023-11-23 11:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-23 11:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:36:32 --> Form Validation Class Initialized
INFO - 2023-11-23 11:36:32 --> Upload Class Initialized
INFO - 2023-11-23 11:36:32 --> Model "M_auth" initialized
INFO - 2023-11-23 11:36:32 --> Model "M_user" initialized
INFO - 2023-11-23 11:36:32 --> Model "M_produk" initialized
INFO - 2023-11-23 11:36:32 --> Controller Class Initialized
INFO - 2023-11-23 11:36:32 --> Model "M_pelanggan" initialized
INFO - 2023-11-23 11:36:32 --> Model "M_produk" initialized
DEBUG - 2023-11-23 11:36:32 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 11:36:32 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-23 11:36:32 --> Model "M_transaksi" initialized
INFO - 2023-11-23 11:36:32 --> Model "M_bank" initialized
INFO - 2023-11-23 11:36:32 --> Model "M_pesan" initialized
DEBUG - 2023-11-23 11:36:32 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-23 11:36:32 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-23 11:36:32 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-23 11:36:32 --> Final output sent to browser
DEBUG - 2023-11-23 11:36:32 --> Total execution time: 0.0347
ERROR - 2023-11-23 13:30:21 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-23 13:30:21 --> Config Class Initialized
INFO - 2023-11-23 13:30:21 --> Hooks Class Initialized
DEBUG - 2023-11-23 13:30:21 --> UTF-8 Support Enabled
INFO - 2023-11-23 13:30:21 --> Utf8 Class Initialized
INFO - 2023-11-23 13:30:21 --> URI Class Initialized
DEBUG - 2023-11-23 13:30:21 --> No URI present. Default controller set.
INFO - 2023-11-23 13:30:21 --> Router Class Initialized
INFO - 2023-11-23 13:30:21 --> Output Class Initialized
INFO - 2023-11-23 13:30:21 --> Security Class Initialized
DEBUG - 2023-11-23 13:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 13:30:21 --> Input Class Initialized
INFO - 2023-11-23 13:30:21 --> Language Class Initialized
INFO - 2023-11-23 13:30:21 --> Loader Class Initialized
INFO - 2023-11-23 13:30:21 --> Helper loaded: url_helper
INFO - 2023-11-23 13:30:21 --> Helper loaded: form_helper
INFO - 2023-11-23 13:30:21 --> Helper loaded: file_helper
INFO - 2023-11-23 13:30:21 --> Database Driver Class Initialized
DEBUG - 2023-11-23 13:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-23 13:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 13:30:21 --> Form Validation Class Initialized
INFO - 2023-11-23 13:30:21 --> Upload Class Initialized
INFO - 2023-11-23 13:30:21 --> Model "M_auth" initialized
INFO - 2023-11-23 13:30:21 --> Model "M_user" initialized
INFO - 2023-11-23 13:30:21 --> Model "M_produk" initialized
INFO - 2023-11-23 13:30:21 --> Controller Class Initialized
INFO - 2023-11-23 13:30:21 --> Model "M_pelanggan" initialized
INFO - 2023-11-23 13:30:21 --> Model "M_produk" initialized
DEBUG - 2023-11-23 13:30:21 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 13:30:21 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-23 13:30:21 --> Model "M_transaksi" initialized
INFO - 2023-11-23 13:30:21 --> Model "M_bank" initialized
INFO - 2023-11-23 13:30:21 --> Model "M_pesan" initialized
DEBUG - 2023-11-23 13:30:21 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-23 13:30:21 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-23 13:30:21 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-23 13:30:21 --> Final output sent to browser
DEBUG - 2023-11-23 13:30:21 --> Total execution time: 0.0306
ERROR - 2023-11-23 16:19:41 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-23 16:19:41 --> Config Class Initialized
INFO - 2023-11-23 16:19:41 --> Hooks Class Initialized
DEBUG - 2023-11-23 16:19:41 --> UTF-8 Support Enabled
INFO - 2023-11-23 16:19:41 --> Utf8 Class Initialized
INFO - 2023-11-23 16:19:41 --> URI Class Initialized
DEBUG - 2023-11-23 16:19:41 --> No URI present. Default controller set.
INFO - 2023-11-23 16:19:41 --> Router Class Initialized
INFO - 2023-11-23 16:19:41 --> Output Class Initialized
INFO - 2023-11-23 16:19:41 --> Security Class Initialized
DEBUG - 2023-11-23 16:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 16:19:41 --> Input Class Initialized
INFO - 2023-11-23 16:19:41 --> Language Class Initialized
INFO - 2023-11-23 16:19:41 --> Loader Class Initialized
INFO - 2023-11-23 16:19:41 --> Helper loaded: url_helper
INFO - 2023-11-23 16:19:41 --> Helper loaded: form_helper
INFO - 2023-11-23 16:19:41 --> Helper loaded: file_helper
INFO - 2023-11-23 16:19:41 --> Database Driver Class Initialized
DEBUG - 2023-11-23 16:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-23 16:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 16:19:41 --> Form Validation Class Initialized
INFO - 2023-11-23 16:19:41 --> Upload Class Initialized
INFO - 2023-11-23 16:19:41 --> Model "M_auth" initialized
INFO - 2023-11-23 16:19:41 --> Model "M_user" initialized
INFO - 2023-11-23 16:19:41 --> Model "M_produk" initialized
INFO - 2023-11-23 16:19:41 --> Controller Class Initialized
INFO - 2023-11-23 16:19:41 --> Model "M_pelanggan" initialized
INFO - 2023-11-23 16:19:41 --> Model "M_produk" initialized
DEBUG - 2023-11-23 16:19:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 16:19:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-23 16:19:41 --> Model "M_transaksi" initialized
INFO - 2023-11-23 16:19:41 --> Model "M_bank" initialized
INFO - 2023-11-23 16:19:41 --> Model "M_pesan" initialized
DEBUG - 2023-11-23 16:19:41 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-23 16:19:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-23 16:19:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-23 16:19:41 --> Final output sent to browser
DEBUG - 2023-11-23 16:19:41 --> Total execution time: 0.0324
ERROR - 2023-11-23 17:27:02 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-23 17:27:02 --> Config Class Initialized
INFO - 2023-11-23 17:27:02 --> Hooks Class Initialized
DEBUG - 2023-11-23 17:27:02 --> UTF-8 Support Enabled
INFO - 2023-11-23 17:27:02 --> Utf8 Class Initialized
INFO - 2023-11-23 17:27:02 --> URI Class Initialized
DEBUG - 2023-11-23 17:27:02 --> No URI present. Default controller set.
INFO - 2023-11-23 17:27:02 --> Router Class Initialized
INFO - 2023-11-23 17:27:02 --> Output Class Initialized
INFO - 2023-11-23 17:27:02 --> Security Class Initialized
DEBUG - 2023-11-23 17:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 17:27:02 --> Input Class Initialized
INFO - 2023-11-23 17:27:02 --> Language Class Initialized
INFO - 2023-11-23 17:27:02 --> Loader Class Initialized
INFO - 2023-11-23 17:27:02 --> Helper loaded: url_helper
INFO - 2023-11-23 17:27:02 --> Helper loaded: form_helper
INFO - 2023-11-23 17:27:02 --> Helper loaded: file_helper
INFO - 2023-11-23 17:27:02 --> Database Driver Class Initialized
DEBUG - 2023-11-23 17:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-23 17:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 17:27:02 --> Form Validation Class Initialized
INFO - 2023-11-23 17:27:02 --> Upload Class Initialized
INFO - 2023-11-23 17:27:02 --> Model "M_auth" initialized
INFO - 2023-11-23 17:27:02 --> Model "M_user" initialized
INFO - 2023-11-23 17:27:02 --> Model "M_produk" initialized
INFO - 2023-11-23 17:27:02 --> Controller Class Initialized
INFO - 2023-11-23 17:27:02 --> Model "M_pelanggan" initialized
INFO - 2023-11-23 17:27:02 --> Model "M_produk" initialized
DEBUG - 2023-11-23 17:27:02 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 17:27:02 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-23 17:27:02 --> Model "M_transaksi" initialized
INFO - 2023-11-23 17:27:02 --> Model "M_bank" initialized
INFO - 2023-11-23 17:27:02 --> Model "M_pesan" initialized
DEBUG - 2023-11-23 17:27:02 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-23 17:27:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-23 17:27:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-23 17:27:02 --> Final output sent to browser
DEBUG - 2023-11-23 17:27:02 --> Total execution time: 0.0329
ERROR - 2023-11-23 20:24:13 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-23 20:24:13 --> Config Class Initialized
INFO - 2023-11-23 20:24:13 --> Hooks Class Initialized
DEBUG - 2023-11-23 20:24:13 --> UTF-8 Support Enabled
INFO - 2023-11-23 20:24:13 --> Utf8 Class Initialized
INFO - 2023-11-23 20:24:13 --> URI Class Initialized
INFO - 2023-11-23 20:24:13 --> Router Class Initialized
INFO - 2023-11-23 20:24:13 --> Output Class Initialized
INFO - 2023-11-23 20:24:13 --> Security Class Initialized
DEBUG - 2023-11-23 20:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 20:24:13 --> Input Class Initialized
INFO - 2023-11-23 20:24:13 --> Language Class Initialized
INFO - 2023-11-23 20:24:13 --> Loader Class Initialized
INFO - 2023-11-23 20:24:13 --> Helper loaded: url_helper
INFO - 2023-11-23 20:24:13 --> Helper loaded: form_helper
INFO - 2023-11-23 20:24:13 --> Helper loaded: file_helper
INFO - 2023-11-23 20:24:13 --> Database Driver Class Initialized
DEBUG - 2023-11-23 20:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-23 20:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 20:24:13 --> Form Validation Class Initialized
INFO - 2023-11-23 20:24:13 --> Upload Class Initialized
INFO - 2023-11-23 20:24:13 --> Model "M_auth" initialized
INFO - 2023-11-23 20:24:13 --> Model "M_user" initialized
INFO - 2023-11-23 20:24:13 --> Model "M_produk" initialized
INFO - 2023-11-23 20:24:13 --> Controller Class Initialized
INFO - 2023-11-23 20:24:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-23 20:24:13 --> Final output sent to browser
DEBUG - 2023-11-23 20:24:13 --> Total execution time: 0.0251
ERROR - 2023-11-23 20:24:15 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-23 20:24:15 --> Config Class Initialized
INFO - 2023-11-23 20:24:15 --> Hooks Class Initialized
DEBUG - 2023-11-23 20:24:15 --> UTF-8 Support Enabled
INFO - 2023-11-23 20:24:15 --> Utf8 Class Initialized
INFO - 2023-11-23 20:24:15 --> URI Class Initialized
DEBUG - 2023-11-23 20:24:15 --> No URI present. Default controller set.
INFO - 2023-11-23 20:24:15 --> Router Class Initialized
INFO - 2023-11-23 20:24:15 --> Output Class Initialized
INFO - 2023-11-23 20:24:15 --> Security Class Initialized
DEBUG - 2023-11-23 20:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 20:24:15 --> Input Class Initialized
INFO - 2023-11-23 20:24:15 --> Language Class Initialized
INFO - 2023-11-23 20:24:15 --> Loader Class Initialized
INFO - 2023-11-23 20:24:15 --> Helper loaded: url_helper
INFO - 2023-11-23 20:24:15 --> Helper loaded: form_helper
INFO - 2023-11-23 20:24:15 --> Helper loaded: file_helper
INFO - 2023-11-23 20:24:15 --> Database Driver Class Initialized
DEBUG - 2023-11-23 20:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-23 20:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 20:24:15 --> Form Validation Class Initialized
INFO - 2023-11-23 20:24:15 --> Upload Class Initialized
INFO - 2023-11-23 20:24:15 --> Model "M_auth" initialized
INFO - 2023-11-23 20:24:15 --> Model "M_user" initialized
INFO - 2023-11-23 20:24:15 --> Model "M_produk" initialized
INFO - 2023-11-23 20:24:15 --> Controller Class Initialized
INFO - 2023-11-23 20:24:15 --> Model "M_pelanggan" initialized
INFO - 2023-11-23 20:24:15 --> Model "M_produk" initialized
DEBUG - 2023-11-23 20:24:15 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 20:24:15 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-23 20:24:15 --> Model "M_transaksi" initialized
INFO - 2023-11-23 20:24:15 --> Model "M_bank" initialized
INFO - 2023-11-23 20:24:15 --> Model "M_pesan" initialized
DEBUG - 2023-11-23 20:24:15 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-23 20:24:15 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-23 20:24:15 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-23 20:24:15 --> Final output sent to browser
DEBUG - 2023-11-23 20:24:15 --> Total execution time: 0.0095
ERROR - 2023-11-23 20:25:06 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-23 20:25:06 --> Config Class Initialized
INFO - 2023-11-23 20:25:06 --> Hooks Class Initialized
DEBUG - 2023-11-23 20:25:06 --> UTF-8 Support Enabled
INFO - 2023-11-23 20:25:06 --> Utf8 Class Initialized
INFO - 2023-11-23 20:25:06 --> URI Class Initialized
DEBUG - 2023-11-23 20:25:06 --> No URI present. Default controller set.
INFO - 2023-11-23 20:25:06 --> Router Class Initialized
INFO - 2023-11-23 20:25:06 --> Output Class Initialized
INFO - 2023-11-23 20:25:06 --> Security Class Initialized
DEBUG - 2023-11-23 20:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 20:25:06 --> Input Class Initialized
INFO - 2023-11-23 20:25:06 --> Language Class Initialized
INFO - 2023-11-23 20:25:06 --> Loader Class Initialized
INFO - 2023-11-23 20:25:06 --> Helper loaded: url_helper
INFO - 2023-11-23 20:25:06 --> Helper loaded: form_helper
INFO - 2023-11-23 20:25:06 --> Helper loaded: file_helper
INFO - 2023-11-23 20:25:06 --> Database Driver Class Initialized
DEBUG - 2023-11-23 20:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-23 20:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 20:25:06 --> Form Validation Class Initialized
INFO - 2023-11-23 20:25:06 --> Upload Class Initialized
INFO - 2023-11-23 20:25:06 --> Model "M_auth" initialized
INFO - 2023-11-23 20:25:06 --> Model "M_user" initialized
INFO - 2023-11-23 20:25:06 --> Model "M_produk" initialized
INFO - 2023-11-23 20:25:06 --> Controller Class Initialized
INFO - 2023-11-23 20:25:06 --> Model "M_pelanggan" initialized
INFO - 2023-11-23 20:25:06 --> Model "M_produk" initialized
DEBUG - 2023-11-23 20:25:06 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 20:25:06 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-23 20:25:06 --> Model "M_transaksi" initialized
INFO - 2023-11-23 20:25:06 --> Model "M_bank" initialized
INFO - 2023-11-23 20:25:06 --> Model "M_pesan" initialized
DEBUG - 2023-11-23 20:25:06 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-23 20:25:06 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-23 20:25:06 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-23 20:25:06 --> Final output sent to browser
DEBUG - 2023-11-23 20:25:06 --> Total execution time: 0.0040
ERROR - 2023-11-23 20:43:33 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-23 20:43:33 --> Config Class Initialized
INFO - 2023-11-23 20:43:33 --> Hooks Class Initialized
DEBUG - 2023-11-23 20:43:33 --> UTF-8 Support Enabled
INFO - 2023-11-23 20:43:33 --> Utf8 Class Initialized
INFO - 2023-11-23 20:43:33 --> URI Class Initialized
INFO - 2023-11-23 20:43:33 --> Router Class Initialized
INFO - 2023-11-23 20:43:33 --> Output Class Initialized
INFO - 2023-11-23 20:43:33 --> Security Class Initialized
DEBUG - 2023-11-23 20:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 20:43:33 --> Input Class Initialized
INFO - 2023-11-23 20:43:33 --> Language Class Initialized
INFO - 2023-11-23 20:43:33 --> Loader Class Initialized
INFO - 2023-11-23 20:43:33 --> Helper loaded: url_helper
INFO - 2023-11-23 20:43:33 --> Helper loaded: form_helper
INFO - 2023-11-23 20:43:33 --> Helper loaded: file_helper
INFO - 2023-11-23 20:43:33 --> Database Driver Class Initialized
DEBUG - 2023-11-23 20:43:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-23 20:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 20:43:33 --> Form Validation Class Initialized
INFO - 2023-11-23 20:43:33 --> Upload Class Initialized
INFO - 2023-11-23 20:43:33 --> Model "M_auth" initialized
INFO - 2023-11-23 20:43:33 --> Model "M_user" initialized
INFO - 2023-11-23 20:43:33 --> Model "M_produk" initialized
INFO - 2023-11-23 20:43:33 --> Controller Class Initialized
INFO - 2023-11-23 20:43:33 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-23 20:43:33 --> Final output sent to browser
DEBUG - 2023-11-23 20:43:33 --> Total execution time: 0.0264
ERROR - 2023-11-23 21:09:22 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-23 21:09:22 --> Config Class Initialized
INFO - 2023-11-23 21:09:22 --> Hooks Class Initialized
DEBUG - 2023-11-23 21:09:22 --> UTF-8 Support Enabled
INFO - 2023-11-23 21:09:22 --> Utf8 Class Initialized
INFO - 2023-11-23 21:09:22 --> URI Class Initialized
DEBUG - 2023-11-23 21:09:22 --> No URI present. Default controller set.
INFO - 2023-11-23 21:09:22 --> Router Class Initialized
INFO - 2023-11-23 21:09:22 --> Output Class Initialized
INFO - 2023-11-23 21:09:22 --> Security Class Initialized
DEBUG - 2023-11-23 21:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 21:09:22 --> Input Class Initialized
INFO - 2023-11-23 21:09:22 --> Language Class Initialized
INFO - 2023-11-23 21:09:22 --> Loader Class Initialized
INFO - 2023-11-23 21:09:22 --> Helper loaded: url_helper
INFO - 2023-11-23 21:09:22 --> Helper loaded: form_helper
INFO - 2023-11-23 21:09:22 --> Helper loaded: file_helper
INFO - 2023-11-23 21:09:22 --> Database Driver Class Initialized
DEBUG - 2023-11-23 21:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-23 21:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 21:09:22 --> Form Validation Class Initialized
INFO - 2023-11-23 21:09:22 --> Upload Class Initialized
INFO - 2023-11-23 21:09:22 --> Model "M_auth" initialized
INFO - 2023-11-23 21:09:22 --> Model "M_user" initialized
INFO - 2023-11-23 21:09:22 --> Model "M_produk" initialized
INFO - 2023-11-23 21:09:22 --> Controller Class Initialized
INFO - 2023-11-23 21:09:22 --> Model "M_pelanggan" initialized
INFO - 2023-11-23 21:09:22 --> Model "M_produk" initialized
DEBUG - 2023-11-23 21:09:22 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 21:09:22 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-23 21:09:22 --> Model "M_transaksi" initialized
INFO - 2023-11-23 21:09:22 --> Model "M_bank" initialized
INFO - 2023-11-23 21:09:22 --> Model "M_pesan" initialized
DEBUG - 2023-11-23 21:09:22 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-23 21:09:22 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-23 21:09:22 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-23 21:09:22 --> Final output sent to browser
DEBUG - 2023-11-23 21:09:22 --> Total execution time: 0.0303
ERROR - 2023-11-23 23:38:24 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-23 23:38:24 --> Config Class Initialized
INFO - 2023-11-23 23:38:24 --> Hooks Class Initialized
DEBUG - 2023-11-23 23:38:24 --> UTF-8 Support Enabled
INFO - 2023-11-23 23:38:24 --> Utf8 Class Initialized
INFO - 2023-11-23 23:38:24 --> URI Class Initialized
DEBUG - 2023-11-23 23:38:24 --> No URI present. Default controller set.
INFO - 2023-11-23 23:38:24 --> Router Class Initialized
INFO - 2023-11-23 23:38:24 --> Output Class Initialized
INFO - 2023-11-23 23:38:24 --> Security Class Initialized
DEBUG - 2023-11-23 23:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 23:38:24 --> Input Class Initialized
INFO - 2023-11-23 23:38:24 --> Language Class Initialized
INFO - 2023-11-23 23:38:24 --> Loader Class Initialized
INFO - 2023-11-23 23:38:24 --> Helper loaded: url_helper
INFO - 2023-11-23 23:38:24 --> Helper loaded: form_helper
INFO - 2023-11-23 23:38:24 --> Helper loaded: file_helper
INFO - 2023-11-23 23:38:24 --> Database Driver Class Initialized
DEBUG - 2023-11-23 23:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-23 23:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 23:38:24 --> Form Validation Class Initialized
INFO - 2023-11-23 23:38:24 --> Upload Class Initialized
INFO - 2023-11-23 23:38:24 --> Model "M_auth" initialized
INFO - 2023-11-23 23:38:24 --> Model "M_user" initialized
INFO - 2023-11-23 23:38:24 --> Model "M_produk" initialized
INFO - 2023-11-23 23:38:24 --> Controller Class Initialized
INFO - 2023-11-23 23:38:24 --> Model "M_pelanggan" initialized
INFO - 2023-11-23 23:38:24 --> Model "M_produk" initialized
DEBUG - 2023-11-23 23:38:24 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-23 23:38:24 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-23 23:38:24 --> Model "M_transaksi" initialized
INFO - 2023-11-23 23:38:24 --> Model "M_bank" initialized
INFO - 2023-11-23 23:38:24 --> Model "M_pesan" initialized
DEBUG - 2023-11-23 23:38:24 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-23 23:38:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-23 23:38:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-23 23:38:24 --> Final output sent to browser
DEBUG - 2023-11-23 23:38:24 --> Total execution time: 0.0314
