<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-29 00:54:20 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-29 00:54:20 --> Config Class Initialized
INFO - 2023-11-29 00:54:20 --> Hooks Class Initialized
DEBUG - 2023-11-29 00:54:20 --> UTF-8 Support Enabled
INFO - 2023-11-29 00:54:20 --> Utf8 Class Initialized
INFO - 2023-11-29 00:54:20 --> URI Class Initialized
DEBUG - 2023-11-29 00:54:20 --> No URI present. Default controller set.
INFO - 2023-11-29 00:54:20 --> Router Class Initialized
INFO - 2023-11-29 00:54:20 --> Output Class Initialized
INFO - 2023-11-29 00:54:20 --> Security Class Initialized
DEBUG - 2023-11-29 00:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 00:54:20 --> Input Class Initialized
INFO - 2023-11-29 00:54:20 --> Language Class Initialized
INFO - 2023-11-29 00:54:20 --> Loader Class Initialized
INFO - 2023-11-29 00:54:20 --> Helper loaded: url_helper
INFO - 2023-11-29 00:54:20 --> Helper loaded: form_helper
INFO - 2023-11-29 00:54:20 --> Helper loaded: file_helper
INFO - 2023-11-29 00:54:20 --> Database Driver Class Initialized
DEBUG - 2023-11-29 00:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-29 00:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 00:54:20 --> Form Validation Class Initialized
INFO - 2023-11-29 00:54:20 --> Upload Class Initialized
INFO - 2023-11-29 00:54:20 --> Model "M_auth" initialized
INFO - 2023-11-29 00:54:20 --> Model "M_user" initialized
INFO - 2023-11-29 00:54:20 --> Model "M_produk" initialized
INFO - 2023-11-29 00:54:20 --> Controller Class Initialized
INFO - 2023-11-29 00:54:20 --> Model "M_pelanggan" initialized
INFO - 2023-11-29 00:54:20 --> Model "M_produk" initialized
DEBUG - 2023-11-29 00:54:20 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-29 00:54:20 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-29 00:54:20 --> Model "M_transaksi" initialized
INFO - 2023-11-29 00:54:20 --> Model "M_bank" initialized
INFO - 2023-11-29 00:54:20 --> Model "M_pesan" initialized
DEBUG - 2023-11-29 00:54:20 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-29 00:54:20 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-29 00:54:20 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-29 00:54:20 --> Final output sent to browser
DEBUG - 2023-11-29 00:54:20 --> Total execution time: 0.0321
ERROR - 2023-11-29 04:26:43 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-29 04:26:43 --> Config Class Initialized
INFO - 2023-11-29 04:26:43 --> Hooks Class Initialized
DEBUG - 2023-11-29 04:26:43 --> UTF-8 Support Enabled
INFO - 2023-11-29 04:26:43 --> Utf8 Class Initialized
INFO - 2023-11-29 04:26:43 --> URI Class Initialized
DEBUG - 2023-11-29 04:26:43 --> No URI present. Default controller set.
INFO - 2023-11-29 04:26:43 --> Router Class Initialized
INFO - 2023-11-29 04:26:43 --> Output Class Initialized
INFO - 2023-11-29 04:26:43 --> Security Class Initialized
DEBUG - 2023-11-29 04:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 04:26:43 --> Input Class Initialized
INFO - 2023-11-29 04:26:43 --> Language Class Initialized
INFO - 2023-11-29 04:26:43 --> Loader Class Initialized
INFO - 2023-11-29 04:26:43 --> Helper loaded: url_helper
INFO - 2023-11-29 04:26:43 --> Helper loaded: form_helper
INFO - 2023-11-29 04:26:43 --> Helper loaded: file_helper
INFO - 2023-11-29 04:26:43 --> Database Driver Class Initialized
DEBUG - 2023-11-29 04:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-29 04:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 04:26:43 --> Form Validation Class Initialized
INFO - 2023-11-29 04:26:43 --> Upload Class Initialized
INFO - 2023-11-29 04:26:43 --> Model "M_auth" initialized
INFO - 2023-11-29 04:26:43 --> Model "M_user" initialized
INFO - 2023-11-29 04:26:43 --> Model "M_produk" initialized
INFO - 2023-11-29 04:26:43 --> Controller Class Initialized
INFO - 2023-11-29 04:26:43 --> Model "M_pelanggan" initialized
INFO - 2023-11-29 04:26:43 --> Model "M_produk" initialized
DEBUG - 2023-11-29 04:26:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-29 04:26:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-29 04:26:43 --> Model "M_transaksi" initialized
INFO - 2023-11-29 04:26:43 --> Model "M_bank" initialized
INFO - 2023-11-29 04:26:43 --> Model "M_pesan" initialized
DEBUG - 2023-11-29 04:26:43 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-29 04:26:43 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-29 04:26:43 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-29 04:26:43 --> Final output sent to browser
DEBUG - 2023-11-29 04:26:43 --> Total execution time: 0.0331
ERROR - 2023-11-29 11:20:06 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-29 11:20:06 --> Config Class Initialized
INFO - 2023-11-29 11:20:06 --> Hooks Class Initialized
DEBUG - 2023-11-29 11:20:06 --> UTF-8 Support Enabled
INFO - 2023-11-29 11:20:06 --> Utf8 Class Initialized
INFO - 2023-11-29 11:20:06 --> URI Class Initialized
INFO - 2023-11-29 11:20:06 --> Router Class Initialized
INFO - 2023-11-29 11:20:06 --> Output Class Initialized
INFO - 2023-11-29 11:20:06 --> Security Class Initialized
DEBUG - 2023-11-29 11:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 11:20:06 --> Input Class Initialized
INFO - 2023-11-29 11:20:06 --> Language Class Initialized
INFO - 2023-11-29 11:20:06 --> Loader Class Initialized
INFO - 2023-11-29 11:20:06 --> Helper loaded: url_helper
INFO - 2023-11-29 11:20:06 --> Helper loaded: form_helper
INFO - 2023-11-29 11:20:06 --> Helper loaded: file_helper
INFO - 2023-11-29 11:20:06 --> Database Driver Class Initialized
DEBUG - 2023-11-29 11:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-29 11:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 11:20:06 --> Form Validation Class Initialized
INFO - 2023-11-29 11:20:06 --> Upload Class Initialized
INFO - 2023-11-29 11:20:06 --> Model "M_auth" initialized
INFO - 2023-11-29 11:20:06 --> Model "M_user" initialized
INFO - 2023-11-29 11:20:06 --> Model "M_produk" initialized
INFO - 2023-11-29 11:20:06 --> Controller Class Initialized
INFO - 2023-11-29 11:20:06 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-29 11:20:06 --> Final output sent to browser
DEBUG - 2023-11-29 11:20:06 --> Total execution time: 0.0307
ERROR - 2023-11-29 11:20:08 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-29 11:20:08 --> Config Class Initialized
INFO - 2023-11-29 11:20:08 --> Hooks Class Initialized
DEBUG - 2023-11-29 11:20:08 --> UTF-8 Support Enabled
INFO - 2023-11-29 11:20:08 --> Utf8 Class Initialized
INFO - 2023-11-29 11:20:08 --> URI Class Initialized
DEBUG - 2023-11-29 11:20:08 --> No URI present. Default controller set.
INFO - 2023-11-29 11:20:08 --> Router Class Initialized
INFO - 2023-11-29 11:20:08 --> Output Class Initialized
INFO - 2023-11-29 11:20:08 --> Security Class Initialized
DEBUG - 2023-11-29 11:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 11:20:08 --> Input Class Initialized
INFO - 2023-11-29 11:20:08 --> Language Class Initialized
INFO - 2023-11-29 11:20:08 --> Loader Class Initialized
INFO - 2023-11-29 11:20:08 --> Helper loaded: url_helper
INFO - 2023-11-29 11:20:08 --> Helper loaded: form_helper
INFO - 2023-11-29 11:20:08 --> Helper loaded: file_helper
INFO - 2023-11-29 11:20:08 --> Database Driver Class Initialized
DEBUG - 2023-11-29 11:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-29 11:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 11:20:08 --> Form Validation Class Initialized
INFO - 2023-11-29 11:20:08 --> Upload Class Initialized
INFO - 2023-11-29 11:20:08 --> Model "M_auth" initialized
INFO - 2023-11-29 11:20:08 --> Model "M_user" initialized
INFO - 2023-11-29 11:20:08 --> Model "M_produk" initialized
INFO - 2023-11-29 11:20:08 --> Controller Class Initialized
INFO - 2023-11-29 11:20:08 --> Model "M_pelanggan" initialized
INFO - 2023-11-29 11:20:08 --> Model "M_produk" initialized
DEBUG - 2023-11-29 11:20:08 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-29 11:20:08 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-29 11:20:08 --> Model "M_transaksi" initialized
INFO - 2023-11-29 11:20:08 --> Model "M_bank" initialized
INFO - 2023-11-29 11:20:08 --> Model "M_pesan" initialized
DEBUG - 2023-11-29 11:20:08 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-29 11:20:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-29 11:20:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-29 11:20:08 --> Final output sent to browser
DEBUG - 2023-11-29 11:20:08 --> Total execution time: 0.0110
ERROR - 2023-11-29 12:16:23 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-29 12:16:23 --> Config Class Initialized
INFO - 2023-11-29 12:16:23 --> Hooks Class Initialized
DEBUG - 2023-11-29 12:16:23 --> UTF-8 Support Enabled
INFO - 2023-11-29 12:16:23 --> Utf8 Class Initialized
INFO - 2023-11-29 12:16:23 --> URI Class Initialized
INFO - 2023-11-29 12:16:23 --> Router Class Initialized
INFO - 2023-11-29 12:16:23 --> Output Class Initialized
INFO - 2023-11-29 12:16:23 --> Security Class Initialized
DEBUG - 2023-11-29 12:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 12:16:23 --> Input Class Initialized
INFO - 2023-11-29 12:16:23 --> Language Class Initialized
INFO - 2023-11-29 12:16:23 --> Loader Class Initialized
INFO - 2023-11-29 12:16:23 --> Helper loaded: url_helper
INFO - 2023-11-29 12:16:23 --> Helper loaded: form_helper
INFO - 2023-11-29 12:16:23 --> Helper loaded: file_helper
INFO - 2023-11-29 12:16:23 --> Database Driver Class Initialized
DEBUG - 2023-11-29 12:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-29 12:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 12:16:23 --> Form Validation Class Initialized
INFO - 2023-11-29 12:16:23 --> Upload Class Initialized
INFO - 2023-11-29 12:16:23 --> Model "M_auth" initialized
INFO - 2023-11-29 12:16:23 --> Model "M_user" initialized
INFO - 2023-11-29 12:16:23 --> Model "M_produk" initialized
INFO - 2023-11-29 12:16:23 --> Controller Class Initialized
INFO - 2023-11-29 12:16:23 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-29 12:16:23 --> Final output sent to browser
DEBUG - 2023-11-29 12:16:23 --> Total execution time: 0.0271
ERROR - 2023-11-29 12:16:25 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-29 12:16:25 --> Config Class Initialized
INFO - 2023-11-29 12:16:25 --> Hooks Class Initialized
DEBUG - 2023-11-29 12:16:25 --> UTF-8 Support Enabled
INFO - 2023-11-29 12:16:25 --> Utf8 Class Initialized
INFO - 2023-11-29 12:16:25 --> URI Class Initialized
DEBUG - 2023-11-29 12:16:25 --> No URI present. Default controller set.
INFO - 2023-11-29 12:16:25 --> Router Class Initialized
INFO - 2023-11-29 12:16:25 --> Output Class Initialized
INFO - 2023-11-29 12:16:25 --> Security Class Initialized
DEBUG - 2023-11-29 12:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 12:16:25 --> Input Class Initialized
INFO - 2023-11-29 12:16:25 --> Language Class Initialized
INFO - 2023-11-29 12:16:25 --> Loader Class Initialized
INFO - 2023-11-29 12:16:25 --> Helper loaded: url_helper
INFO - 2023-11-29 12:16:25 --> Helper loaded: form_helper
INFO - 2023-11-29 12:16:25 --> Helper loaded: file_helper
INFO - 2023-11-29 12:16:25 --> Database Driver Class Initialized
DEBUG - 2023-11-29 12:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-29 12:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 12:16:25 --> Form Validation Class Initialized
INFO - 2023-11-29 12:16:25 --> Upload Class Initialized
INFO - 2023-11-29 12:16:25 --> Model "M_auth" initialized
INFO - 2023-11-29 12:16:25 --> Model "M_user" initialized
INFO - 2023-11-29 12:16:25 --> Model "M_produk" initialized
INFO - 2023-11-29 12:16:25 --> Controller Class Initialized
INFO - 2023-11-29 12:16:25 --> Model "M_pelanggan" initialized
INFO - 2023-11-29 12:16:25 --> Model "M_produk" initialized
DEBUG - 2023-11-29 12:16:25 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-29 12:16:25 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-29 12:16:25 --> Model "M_transaksi" initialized
INFO - 2023-11-29 12:16:25 --> Model "M_bank" initialized
INFO - 2023-11-29 12:16:25 --> Model "M_pesan" initialized
DEBUG - 2023-11-29 12:16:25 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-29 12:16:25 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-29 12:16:25 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-29 12:16:25 --> Final output sent to browser
DEBUG - 2023-11-29 12:16:25 --> Total execution time: 0.0114
ERROR - 2023-11-29 15:16:16 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-29 15:16:16 --> Config Class Initialized
INFO - 2023-11-29 15:16:16 --> Hooks Class Initialized
DEBUG - 2023-11-29 15:16:16 --> UTF-8 Support Enabled
INFO - 2023-11-29 15:16:16 --> Utf8 Class Initialized
INFO - 2023-11-29 15:16:16 --> URI Class Initialized
DEBUG - 2023-11-29 15:16:16 --> No URI present. Default controller set.
INFO - 2023-11-29 15:16:16 --> Router Class Initialized
INFO - 2023-11-29 15:16:16 --> Output Class Initialized
INFO - 2023-11-29 15:16:16 --> Security Class Initialized
DEBUG - 2023-11-29 15:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 15:16:16 --> Input Class Initialized
INFO - 2023-11-29 15:16:16 --> Language Class Initialized
INFO - 2023-11-29 15:16:16 --> Loader Class Initialized
INFO - 2023-11-29 15:16:16 --> Helper loaded: url_helper
INFO - 2023-11-29 15:16:16 --> Helper loaded: form_helper
INFO - 2023-11-29 15:16:16 --> Helper loaded: file_helper
INFO - 2023-11-29 15:16:16 --> Database Driver Class Initialized
DEBUG - 2023-11-29 15:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-29 15:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 15:16:16 --> Form Validation Class Initialized
INFO - 2023-11-29 15:16:16 --> Upload Class Initialized
INFO - 2023-11-29 15:16:16 --> Model "M_auth" initialized
INFO - 2023-11-29 15:16:16 --> Model "M_user" initialized
INFO - 2023-11-29 15:16:16 --> Model "M_produk" initialized
INFO - 2023-11-29 15:16:16 --> Controller Class Initialized
INFO - 2023-11-29 15:16:16 --> Model "M_pelanggan" initialized
INFO - 2023-11-29 15:16:16 --> Model "M_produk" initialized
DEBUG - 2023-11-29 15:16:16 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-29 15:16:16 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-29 15:16:16 --> Model "M_transaksi" initialized
INFO - 2023-11-29 15:16:16 --> Model "M_bank" initialized
INFO - 2023-11-29 15:16:16 --> Model "M_pesan" initialized
DEBUG - 2023-11-29 15:16:16 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-29 15:16:16 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-29 15:16:16 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-29 15:16:16 --> Final output sent to browser
DEBUG - 2023-11-29 15:16:16 --> Total execution time: 0.0353
ERROR - 2023-11-29 19:36:27 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-29 19:36:27 --> Config Class Initialized
INFO - 2023-11-29 19:36:27 --> Hooks Class Initialized
DEBUG - 2023-11-29 19:36:27 --> UTF-8 Support Enabled
INFO - 2023-11-29 19:36:27 --> Utf8 Class Initialized
INFO - 2023-11-29 19:36:27 --> URI Class Initialized
DEBUG - 2023-11-29 19:36:27 --> No URI present. Default controller set.
INFO - 2023-11-29 19:36:27 --> Router Class Initialized
INFO - 2023-11-29 19:36:27 --> Output Class Initialized
INFO - 2023-11-29 19:36:27 --> Security Class Initialized
DEBUG - 2023-11-29 19:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 19:36:27 --> Input Class Initialized
INFO - 2023-11-29 19:36:27 --> Language Class Initialized
INFO - 2023-11-29 19:36:27 --> Loader Class Initialized
INFO - 2023-11-29 19:36:27 --> Helper loaded: url_helper
INFO - 2023-11-29 19:36:27 --> Helper loaded: form_helper
INFO - 2023-11-29 19:36:27 --> Helper loaded: file_helper
INFO - 2023-11-29 19:36:27 --> Database Driver Class Initialized
DEBUG - 2023-11-29 19:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-29 19:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 19:36:27 --> Form Validation Class Initialized
INFO - 2023-11-29 19:36:27 --> Upload Class Initialized
INFO - 2023-11-29 19:36:27 --> Model "M_auth" initialized
INFO - 2023-11-29 19:36:27 --> Model "M_user" initialized
INFO - 2023-11-29 19:36:27 --> Model "M_produk" initialized
INFO - 2023-11-29 19:36:27 --> Controller Class Initialized
INFO - 2023-11-29 19:36:27 --> Model "M_pelanggan" initialized
INFO - 2023-11-29 19:36:27 --> Model "M_produk" initialized
DEBUG - 2023-11-29 19:36:27 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-29 19:36:27 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-29 19:36:27 --> Model "M_transaksi" initialized
INFO - 2023-11-29 19:36:27 --> Model "M_bank" initialized
INFO - 2023-11-29 19:36:27 --> Model "M_pesan" initialized
DEBUG - 2023-11-29 19:36:27 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-29 19:36:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-29 19:36:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-29 19:36:27 --> Final output sent to browser
DEBUG - 2023-11-29 19:36:27 --> Total execution time: 0.0323
ERROR - 2023-11-29 20:17:56 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-29 20:17:56 --> Config Class Initialized
INFO - 2023-11-29 20:17:56 --> Hooks Class Initialized
DEBUG - 2023-11-29 20:17:56 --> UTF-8 Support Enabled
INFO - 2023-11-29 20:17:56 --> Utf8 Class Initialized
INFO - 2023-11-29 20:17:56 --> URI Class Initialized
DEBUG - 2023-11-29 20:17:56 --> No URI present. Default controller set.
INFO - 2023-11-29 20:17:56 --> Router Class Initialized
INFO - 2023-11-29 20:17:56 --> Output Class Initialized
INFO - 2023-11-29 20:17:56 --> Security Class Initialized
DEBUG - 2023-11-29 20:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 20:17:56 --> Input Class Initialized
INFO - 2023-11-29 20:17:56 --> Language Class Initialized
INFO - 2023-11-29 20:17:56 --> Loader Class Initialized
INFO - 2023-11-29 20:17:56 --> Helper loaded: url_helper
INFO - 2023-11-29 20:17:56 --> Helper loaded: form_helper
INFO - 2023-11-29 20:17:56 --> Helper loaded: file_helper
INFO - 2023-11-29 20:17:56 --> Database Driver Class Initialized
DEBUG - 2023-11-29 20:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-29 20:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 20:17:56 --> Form Validation Class Initialized
INFO - 2023-11-29 20:17:56 --> Upload Class Initialized
INFO - 2023-11-29 20:17:56 --> Model "M_auth" initialized
INFO - 2023-11-29 20:17:56 --> Model "M_user" initialized
INFO - 2023-11-29 20:17:56 --> Model "M_produk" initialized
INFO - 2023-11-29 20:17:56 --> Controller Class Initialized
INFO - 2023-11-29 20:17:56 --> Model "M_pelanggan" initialized
INFO - 2023-11-29 20:17:56 --> Model "M_produk" initialized
DEBUG - 2023-11-29 20:17:56 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-29 20:17:56 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-29 20:17:56 --> Model "M_transaksi" initialized
INFO - 2023-11-29 20:17:56 --> Model "M_bank" initialized
INFO - 2023-11-29 20:17:56 --> Model "M_pesan" initialized
DEBUG - 2023-11-29 20:17:56 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-29 20:17:56 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-29 20:17:56 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-29 20:17:56 --> Final output sent to browser
DEBUG - 2023-11-29 20:17:56 --> Total execution time: 0.0300
