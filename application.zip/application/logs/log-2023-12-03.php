<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-03 00:06:09 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 00:06:09 --> Config Class Initialized
INFO - 2023-12-03 00:06:09 --> Hooks Class Initialized
DEBUG - 2023-12-03 00:06:09 --> UTF-8 Support Enabled
INFO - 2023-12-03 00:06:09 --> Utf8 Class Initialized
INFO - 2023-12-03 00:06:09 --> URI Class Initialized
DEBUG - 2023-12-03 00:06:09 --> No URI present. Default controller set.
INFO - 2023-12-03 00:06:09 --> Router Class Initialized
INFO - 2023-12-03 00:06:09 --> Output Class Initialized
INFO - 2023-12-03 00:06:09 --> Security Class Initialized
DEBUG - 2023-12-03 00:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 00:06:09 --> Input Class Initialized
INFO - 2023-12-03 00:06:09 --> Language Class Initialized
INFO - 2023-12-03 00:06:09 --> Loader Class Initialized
INFO - 2023-12-03 00:06:09 --> Helper loaded: url_helper
INFO - 2023-12-03 00:06:09 --> Helper loaded: form_helper
INFO - 2023-12-03 00:06:09 --> Helper loaded: file_helper
INFO - 2023-12-03 00:06:09 --> Database Driver Class Initialized
DEBUG - 2023-12-03 00:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 00:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 00:06:09 --> Form Validation Class Initialized
INFO - 2023-12-03 00:06:09 --> Upload Class Initialized
INFO - 2023-12-03 00:06:09 --> Model "M_auth" initialized
INFO - 2023-12-03 00:06:09 --> Model "M_user" initialized
INFO - 2023-12-03 00:06:09 --> Model "M_produk" initialized
INFO - 2023-12-03 00:06:09 --> Controller Class Initialized
INFO - 2023-12-03 00:06:09 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 00:06:09 --> Model "M_produk" initialized
DEBUG - 2023-12-03 00:06:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 00:06:09 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 00:06:09 --> Model "M_transaksi" initialized
INFO - 2023-12-03 00:06:09 --> Model "M_bank" initialized
INFO - 2023-12-03 00:06:09 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 00:06:09 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 00:06:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 00:06:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 00:06:09 --> Final output sent to browser
DEBUG - 2023-12-03 00:06:09 --> Total execution time: 0.0316
ERROR - 2023-12-03 02:40:31 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 02:40:31 --> Config Class Initialized
INFO - 2023-12-03 02:40:31 --> Hooks Class Initialized
DEBUG - 2023-12-03 02:40:31 --> UTF-8 Support Enabled
INFO - 2023-12-03 02:40:31 --> Utf8 Class Initialized
INFO - 2023-12-03 02:40:31 --> URI Class Initialized
DEBUG - 2023-12-03 02:40:31 --> No URI present. Default controller set.
INFO - 2023-12-03 02:40:31 --> Router Class Initialized
INFO - 2023-12-03 02:40:31 --> Output Class Initialized
INFO - 2023-12-03 02:40:31 --> Security Class Initialized
DEBUG - 2023-12-03 02:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 02:40:31 --> Input Class Initialized
INFO - 2023-12-03 02:40:31 --> Language Class Initialized
INFO - 2023-12-03 02:40:31 --> Loader Class Initialized
INFO - 2023-12-03 02:40:31 --> Helper loaded: url_helper
INFO - 2023-12-03 02:40:31 --> Helper loaded: form_helper
INFO - 2023-12-03 02:40:31 --> Helper loaded: file_helper
INFO - 2023-12-03 02:40:31 --> Database Driver Class Initialized
DEBUG - 2023-12-03 02:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 02:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 02:40:31 --> Form Validation Class Initialized
INFO - 2023-12-03 02:40:31 --> Upload Class Initialized
INFO - 2023-12-03 02:40:31 --> Model "M_auth" initialized
INFO - 2023-12-03 02:40:31 --> Model "M_user" initialized
INFO - 2023-12-03 02:40:31 --> Model "M_produk" initialized
INFO - 2023-12-03 02:40:31 --> Controller Class Initialized
INFO - 2023-12-03 02:40:31 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 02:40:31 --> Model "M_produk" initialized
DEBUG - 2023-12-03 02:40:31 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 02:40:31 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 02:40:31 --> Model "M_transaksi" initialized
INFO - 2023-12-03 02:40:31 --> Model "M_bank" initialized
INFO - 2023-12-03 02:40:31 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 02:40:31 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 02:40:31 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 02:40:31 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 02:40:31 --> Final output sent to browser
DEBUG - 2023-12-03 02:40:31 --> Total execution time: 0.0323
ERROR - 2023-12-03 04:40:32 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 04:40:32 --> Config Class Initialized
INFO - 2023-12-03 04:40:32 --> Hooks Class Initialized
DEBUG - 2023-12-03 04:40:32 --> UTF-8 Support Enabled
INFO - 2023-12-03 04:40:32 --> Utf8 Class Initialized
INFO - 2023-12-03 04:40:32 --> URI Class Initialized
INFO - 2023-12-03 04:40:32 --> Router Class Initialized
INFO - 2023-12-03 04:40:32 --> Output Class Initialized
INFO - 2023-12-03 04:40:32 --> Security Class Initialized
DEBUG - 2023-12-03 04:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 04:40:32 --> Input Class Initialized
INFO - 2023-12-03 04:40:32 --> Language Class Initialized
INFO - 2023-12-03 04:40:32 --> Loader Class Initialized
INFO - 2023-12-03 04:40:32 --> Helper loaded: url_helper
INFO - 2023-12-03 04:40:32 --> Helper loaded: form_helper
INFO - 2023-12-03 04:40:32 --> Helper loaded: file_helper
INFO - 2023-12-03 04:40:32 --> Database Driver Class Initialized
DEBUG - 2023-12-03 04:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 04:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 04:40:32 --> Form Validation Class Initialized
INFO - 2023-12-03 04:40:32 --> Upload Class Initialized
INFO - 2023-12-03 04:40:32 --> Model "M_auth" initialized
INFO - 2023-12-03 04:40:32 --> Model "M_user" initialized
INFO - 2023-12-03 04:40:32 --> Model "M_produk" initialized
INFO - 2023-12-03 04:40:32 --> Controller Class Initialized
INFO - 2023-12-03 04:40:32 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-03 04:40:32 --> Final output sent to browser
DEBUG - 2023-12-03 04:40:32 --> Total execution time: 0.0295
ERROR - 2023-12-03 10:42:13 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 10:42:13 --> Config Class Initialized
INFO - 2023-12-03 10:42:13 --> Hooks Class Initialized
DEBUG - 2023-12-03 10:42:13 --> UTF-8 Support Enabled
INFO - 2023-12-03 10:42:13 --> Utf8 Class Initialized
INFO - 2023-12-03 10:42:13 --> URI Class Initialized
DEBUG - 2023-12-03 10:42:13 --> No URI present. Default controller set.
INFO - 2023-12-03 10:42:13 --> Router Class Initialized
INFO - 2023-12-03 10:42:13 --> Output Class Initialized
INFO - 2023-12-03 10:42:13 --> Security Class Initialized
DEBUG - 2023-12-03 10:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 10:42:13 --> Input Class Initialized
INFO - 2023-12-03 10:42:13 --> Language Class Initialized
INFO - 2023-12-03 10:42:13 --> Loader Class Initialized
INFO - 2023-12-03 10:42:13 --> Helper loaded: url_helper
INFO - 2023-12-03 10:42:13 --> Helper loaded: form_helper
INFO - 2023-12-03 10:42:13 --> Helper loaded: file_helper
INFO - 2023-12-03 10:42:13 --> Database Driver Class Initialized
DEBUG - 2023-12-03 10:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 10:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 10:42:13 --> Form Validation Class Initialized
INFO - 2023-12-03 10:42:13 --> Upload Class Initialized
INFO - 2023-12-03 10:42:13 --> Model "M_auth" initialized
INFO - 2023-12-03 10:42:13 --> Model "M_user" initialized
INFO - 2023-12-03 10:42:13 --> Model "M_produk" initialized
INFO - 2023-12-03 10:42:13 --> Controller Class Initialized
INFO - 2023-12-03 10:42:13 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 10:42:13 --> Model "M_produk" initialized
DEBUG - 2023-12-03 10:42:13 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 10:42:13 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 10:42:13 --> Model "M_transaksi" initialized
INFO - 2023-12-03 10:42:13 --> Model "M_bank" initialized
INFO - 2023-12-03 10:42:13 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 10:42:13 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 10:42:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 10:42:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 10:42:13 --> Final output sent to browser
DEBUG - 2023-12-03 10:42:13 --> Total execution time: 0.0352
ERROR - 2023-12-03 12:54:54 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 12:54:54 --> Config Class Initialized
INFO - 2023-12-03 12:54:54 --> Hooks Class Initialized
DEBUG - 2023-12-03 12:54:54 --> UTF-8 Support Enabled
INFO - 2023-12-03 12:54:54 --> Utf8 Class Initialized
INFO - 2023-12-03 12:54:54 --> URI Class Initialized
DEBUG - 2023-12-03 12:54:54 --> No URI present. Default controller set.
INFO - 2023-12-03 12:54:54 --> Router Class Initialized
INFO - 2023-12-03 12:54:54 --> Output Class Initialized
INFO - 2023-12-03 12:54:54 --> Security Class Initialized
DEBUG - 2023-12-03 12:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 12:54:54 --> Input Class Initialized
INFO - 2023-12-03 12:54:54 --> Language Class Initialized
INFO - 2023-12-03 12:54:54 --> Loader Class Initialized
INFO - 2023-12-03 12:54:54 --> Helper loaded: url_helper
INFO - 2023-12-03 12:54:54 --> Helper loaded: form_helper
INFO - 2023-12-03 12:54:54 --> Helper loaded: file_helper
INFO - 2023-12-03 12:54:54 --> Database Driver Class Initialized
DEBUG - 2023-12-03 12:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 12:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 12:54:54 --> Form Validation Class Initialized
INFO - 2023-12-03 12:54:54 --> Upload Class Initialized
INFO - 2023-12-03 12:54:54 --> Model "M_auth" initialized
INFO - 2023-12-03 12:54:54 --> Model "M_user" initialized
INFO - 2023-12-03 12:54:54 --> Model "M_produk" initialized
INFO - 2023-12-03 12:54:54 --> Controller Class Initialized
INFO - 2023-12-03 12:54:54 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 12:54:54 --> Model "M_produk" initialized
DEBUG - 2023-12-03 12:54:54 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 12:54:54 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 12:54:54 --> Model "M_transaksi" initialized
INFO - 2023-12-03 12:54:54 --> Model "M_bank" initialized
INFO - 2023-12-03 12:54:54 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 12:54:54 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 12:54:54 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 12:54:54 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 12:54:54 --> Final output sent to browser
DEBUG - 2023-12-03 12:54:54 --> Total execution time: 0.0329
ERROR - 2023-12-03 13:13:28 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 13:13:28 --> Config Class Initialized
INFO - 2023-12-03 13:13:28 --> Hooks Class Initialized
DEBUG - 2023-12-03 13:13:28 --> UTF-8 Support Enabled
INFO - 2023-12-03 13:13:28 --> Utf8 Class Initialized
INFO - 2023-12-03 13:13:28 --> URI Class Initialized
DEBUG - 2023-12-03 13:13:28 --> No URI present. Default controller set.
INFO - 2023-12-03 13:13:28 --> Router Class Initialized
INFO - 2023-12-03 13:13:28 --> Output Class Initialized
INFO - 2023-12-03 13:13:28 --> Security Class Initialized
DEBUG - 2023-12-03 13:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 13:13:28 --> Input Class Initialized
INFO - 2023-12-03 13:13:28 --> Language Class Initialized
INFO - 2023-12-03 13:13:28 --> Loader Class Initialized
INFO - 2023-12-03 13:13:28 --> Helper loaded: url_helper
INFO - 2023-12-03 13:13:28 --> Helper loaded: form_helper
INFO - 2023-12-03 13:13:28 --> Helper loaded: file_helper
INFO - 2023-12-03 13:13:28 --> Database Driver Class Initialized
DEBUG - 2023-12-03 13:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 13:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 13:13:28 --> Form Validation Class Initialized
INFO - 2023-12-03 13:13:28 --> Upload Class Initialized
INFO - 2023-12-03 13:13:28 --> Model "M_auth" initialized
INFO - 2023-12-03 13:13:28 --> Model "M_user" initialized
INFO - 2023-12-03 13:13:28 --> Model "M_produk" initialized
INFO - 2023-12-03 13:13:28 --> Controller Class Initialized
INFO - 2023-12-03 13:13:28 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 13:13:28 --> Model "M_produk" initialized
DEBUG - 2023-12-03 13:13:28 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 13:13:28 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 13:13:28 --> Model "M_transaksi" initialized
INFO - 2023-12-03 13:13:28 --> Model "M_bank" initialized
INFO - 2023-12-03 13:13:28 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 13:13:28 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 13:13:28 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 13:13:28 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 13:13:28 --> Final output sent to browser
DEBUG - 2023-12-03 13:13:28 --> Total execution time: 0.0365
ERROR - 2023-12-03 13:13:28 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 13:13:28 --> Config Class Initialized
INFO - 2023-12-03 13:13:28 --> Hooks Class Initialized
DEBUG - 2023-12-03 13:13:28 --> UTF-8 Support Enabled
INFO - 2023-12-03 13:13:28 --> Utf8 Class Initialized
INFO - 2023-12-03 13:13:28 --> URI Class Initialized
DEBUG - 2023-12-03 13:13:28 --> No URI present. Default controller set.
INFO - 2023-12-03 13:13:28 --> Router Class Initialized
INFO - 2023-12-03 13:13:28 --> Output Class Initialized
INFO - 2023-12-03 13:13:28 --> Security Class Initialized
DEBUG - 2023-12-03 13:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 13:13:28 --> Input Class Initialized
INFO - 2023-12-03 13:13:28 --> Language Class Initialized
INFO - 2023-12-03 13:13:28 --> Loader Class Initialized
INFO - 2023-12-03 13:13:28 --> Helper loaded: url_helper
INFO - 2023-12-03 13:13:28 --> Helper loaded: form_helper
INFO - 2023-12-03 13:13:28 --> Helper loaded: file_helper
INFO - 2023-12-03 13:13:28 --> Database Driver Class Initialized
DEBUG - 2023-12-03 13:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 13:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 13:13:28 --> Form Validation Class Initialized
INFO - 2023-12-03 13:13:28 --> Upload Class Initialized
INFO - 2023-12-03 13:13:28 --> Model "M_auth" initialized
INFO - 2023-12-03 13:13:28 --> Model "M_user" initialized
INFO - 2023-12-03 13:13:28 --> Model "M_produk" initialized
INFO - 2023-12-03 13:13:28 --> Controller Class Initialized
INFO - 2023-12-03 13:13:28 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 13:13:28 --> Model "M_produk" initialized
DEBUG - 2023-12-03 13:13:28 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 13:13:28 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 13:13:28 --> Model "M_transaksi" initialized
INFO - 2023-12-03 13:13:28 --> Model "M_bank" initialized
INFO - 2023-12-03 13:13:28 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 13:13:28 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 13:13:28 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 13:13:28 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 13:13:28 --> Final output sent to browser
DEBUG - 2023-12-03 13:13:28 --> Total execution time: 0.0031
ERROR - 2023-12-03 15:39:02 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 15:39:02 --> Config Class Initialized
INFO - 2023-12-03 15:39:02 --> Hooks Class Initialized
DEBUG - 2023-12-03 15:39:02 --> UTF-8 Support Enabled
INFO - 2023-12-03 15:39:02 --> Utf8 Class Initialized
INFO - 2023-12-03 15:39:02 --> URI Class Initialized
DEBUG - 2023-12-03 15:39:02 --> No URI present. Default controller set.
INFO - 2023-12-03 15:39:02 --> Router Class Initialized
INFO - 2023-12-03 15:39:02 --> Output Class Initialized
INFO - 2023-12-03 15:39:02 --> Security Class Initialized
DEBUG - 2023-12-03 15:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 15:39:02 --> Input Class Initialized
INFO - 2023-12-03 15:39:02 --> Language Class Initialized
INFO - 2023-12-03 15:39:02 --> Loader Class Initialized
INFO - 2023-12-03 15:39:02 --> Helper loaded: url_helper
INFO - 2023-12-03 15:39:02 --> Helper loaded: form_helper
INFO - 2023-12-03 15:39:02 --> Helper loaded: file_helper
INFO - 2023-12-03 15:39:02 --> Database Driver Class Initialized
DEBUG - 2023-12-03 15:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 15:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 15:39:02 --> Form Validation Class Initialized
INFO - 2023-12-03 15:39:02 --> Upload Class Initialized
INFO - 2023-12-03 15:39:02 --> Model "M_auth" initialized
INFO - 2023-12-03 15:39:02 --> Model "M_user" initialized
INFO - 2023-12-03 15:39:02 --> Model "M_produk" initialized
INFO - 2023-12-03 15:39:02 --> Controller Class Initialized
INFO - 2023-12-03 15:39:02 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 15:39:02 --> Model "M_produk" initialized
DEBUG - 2023-12-03 15:39:02 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 15:39:02 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 15:39:02 --> Model "M_transaksi" initialized
INFO - 2023-12-03 15:39:02 --> Model "M_bank" initialized
INFO - 2023-12-03 15:39:02 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 15:39:02 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 15:39:03 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 15:39:03 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 15:39:03 --> Final output sent to browser
DEBUG - 2023-12-03 15:39:03 --> Total execution time: 0.0310
ERROR - 2023-12-03 15:39:05 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 15:39:05 --> Config Class Initialized
INFO - 2023-12-03 15:39:05 --> Hooks Class Initialized
DEBUG - 2023-12-03 15:39:05 --> UTF-8 Support Enabled
INFO - 2023-12-03 15:39:05 --> Utf8 Class Initialized
INFO - 2023-12-03 15:39:05 --> URI Class Initialized
DEBUG - 2023-12-03 15:39:05 --> No URI present. Default controller set.
INFO - 2023-12-03 15:39:05 --> Router Class Initialized
INFO - 2023-12-03 15:39:05 --> Output Class Initialized
INFO - 2023-12-03 15:39:05 --> Security Class Initialized
DEBUG - 2023-12-03 15:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 15:39:05 --> Input Class Initialized
INFO - 2023-12-03 15:39:05 --> Language Class Initialized
INFO - 2023-12-03 15:39:05 --> Loader Class Initialized
INFO - 2023-12-03 15:39:05 --> Helper loaded: url_helper
INFO - 2023-12-03 15:39:05 --> Helper loaded: form_helper
INFO - 2023-12-03 15:39:05 --> Helper loaded: file_helper
INFO - 2023-12-03 15:39:05 --> Database Driver Class Initialized
DEBUG - 2023-12-03 15:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 15:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 15:39:05 --> Form Validation Class Initialized
INFO - 2023-12-03 15:39:05 --> Upload Class Initialized
INFO - 2023-12-03 15:39:05 --> Model "M_auth" initialized
INFO - 2023-12-03 15:39:05 --> Model "M_user" initialized
INFO - 2023-12-03 15:39:05 --> Model "M_produk" initialized
INFO - 2023-12-03 15:39:05 --> Controller Class Initialized
INFO - 2023-12-03 15:39:05 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 15:39:05 --> Model "M_produk" initialized
DEBUG - 2023-12-03 15:39:05 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 15:39:05 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 15:39:05 --> Model "M_transaksi" initialized
INFO - 2023-12-03 15:39:05 --> Model "M_bank" initialized
INFO - 2023-12-03 15:39:05 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 15:39:05 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 15:39:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 15:39:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 15:39:05 --> Final output sent to browser
DEBUG - 2023-12-03 15:39:05 --> Total execution time: 0.0031
ERROR - 2023-12-03 15:39:05 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 15:39:05 --> Config Class Initialized
INFO - 2023-12-03 15:39:05 --> Hooks Class Initialized
DEBUG - 2023-12-03 15:39:05 --> UTF-8 Support Enabled
INFO - 2023-12-03 15:39:05 --> Utf8 Class Initialized
INFO - 2023-12-03 15:39:05 --> URI Class Initialized
DEBUG - 2023-12-03 15:39:05 --> No URI present. Default controller set.
INFO - 2023-12-03 15:39:05 --> Router Class Initialized
INFO - 2023-12-03 15:39:05 --> Output Class Initialized
INFO - 2023-12-03 15:39:05 --> Security Class Initialized
DEBUG - 2023-12-03 15:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 15:39:05 --> Input Class Initialized
INFO - 2023-12-03 15:39:05 --> Language Class Initialized
INFO - 2023-12-03 15:39:05 --> Loader Class Initialized
INFO - 2023-12-03 15:39:05 --> Helper loaded: url_helper
INFO - 2023-12-03 15:39:05 --> Helper loaded: form_helper
INFO - 2023-12-03 15:39:05 --> Helper loaded: file_helper
INFO - 2023-12-03 15:39:05 --> Database Driver Class Initialized
DEBUG - 2023-12-03 15:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 15:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 15:39:05 --> Form Validation Class Initialized
INFO - 2023-12-03 15:39:05 --> Upload Class Initialized
INFO - 2023-12-03 15:39:05 --> Model "M_auth" initialized
INFO - 2023-12-03 15:39:05 --> Model "M_user" initialized
INFO - 2023-12-03 15:39:05 --> Model "M_produk" initialized
INFO - 2023-12-03 15:39:05 --> Controller Class Initialized
INFO - 2023-12-03 15:39:05 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 15:39:05 --> Model "M_produk" initialized
DEBUG - 2023-12-03 15:39:05 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 15:39:05 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 15:39:05 --> Model "M_transaksi" initialized
INFO - 2023-12-03 15:39:05 --> Model "M_bank" initialized
INFO - 2023-12-03 15:39:05 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 15:39:05 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 15:39:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 15:39:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 15:39:05 --> Final output sent to browser
DEBUG - 2023-12-03 15:39:05 --> Total execution time: 0.0026
ERROR - 2023-12-03 15:39:09 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 15:39:09 --> Config Class Initialized
INFO - 2023-12-03 15:39:09 --> Hooks Class Initialized
DEBUG - 2023-12-03 15:39:09 --> UTF-8 Support Enabled
INFO - 2023-12-03 15:39:09 --> Utf8 Class Initialized
INFO - 2023-12-03 15:39:09 --> URI Class Initialized
DEBUG - 2023-12-03 15:39:09 --> No URI present. Default controller set.
INFO - 2023-12-03 15:39:09 --> Router Class Initialized
INFO - 2023-12-03 15:39:09 --> Output Class Initialized
INFO - 2023-12-03 15:39:09 --> Security Class Initialized
DEBUG - 2023-12-03 15:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 15:39:09 --> Input Class Initialized
INFO - 2023-12-03 15:39:09 --> Language Class Initialized
INFO - 2023-12-03 15:39:09 --> Loader Class Initialized
INFO - 2023-12-03 15:39:09 --> Helper loaded: url_helper
INFO - 2023-12-03 15:39:09 --> Helper loaded: form_helper
INFO - 2023-12-03 15:39:09 --> Helper loaded: file_helper
INFO - 2023-12-03 15:39:09 --> Database Driver Class Initialized
DEBUG - 2023-12-03 15:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 15:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 15:39:09 --> Form Validation Class Initialized
INFO - 2023-12-03 15:39:09 --> Upload Class Initialized
INFO - 2023-12-03 15:39:09 --> Model "M_auth" initialized
INFO - 2023-12-03 15:39:09 --> Model "M_user" initialized
INFO - 2023-12-03 15:39:09 --> Model "M_produk" initialized
INFO - 2023-12-03 15:39:09 --> Controller Class Initialized
INFO - 2023-12-03 15:39:09 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 15:39:09 --> Model "M_produk" initialized
DEBUG - 2023-12-03 15:39:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 15:39:09 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 15:39:09 --> Model "M_transaksi" initialized
INFO - 2023-12-03 15:39:09 --> Model "M_bank" initialized
INFO - 2023-12-03 15:39:09 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 15:39:09 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 15:39:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 15:39:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 15:39:09 --> Final output sent to browser
DEBUG - 2023-12-03 15:39:09 --> Total execution time: 0.0032
ERROR - 2023-12-03 15:39:10 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 15:39:10 --> Config Class Initialized
INFO - 2023-12-03 15:39:10 --> Hooks Class Initialized
DEBUG - 2023-12-03 15:39:10 --> UTF-8 Support Enabled
INFO - 2023-12-03 15:39:10 --> Utf8 Class Initialized
INFO - 2023-12-03 15:39:10 --> URI Class Initialized
DEBUG - 2023-12-03 15:39:10 --> No URI present. Default controller set.
INFO - 2023-12-03 15:39:10 --> Router Class Initialized
INFO - 2023-12-03 15:39:10 --> Output Class Initialized
INFO - 2023-12-03 15:39:10 --> Security Class Initialized
DEBUG - 2023-12-03 15:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 15:39:10 --> Input Class Initialized
INFO - 2023-12-03 15:39:10 --> Language Class Initialized
INFO - 2023-12-03 15:39:10 --> Loader Class Initialized
INFO - 2023-12-03 15:39:10 --> Helper loaded: url_helper
INFO - 2023-12-03 15:39:10 --> Helper loaded: form_helper
INFO - 2023-12-03 15:39:10 --> Helper loaded: file_helper
INFO - 2023-12-03 15:39:10 --> Database Driver Class Initialized
DEBUG - 2023-12-03 15:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 15:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 15:39:10 --> Form Validation Class Initialized
INFO - 2023-12-03 15:39:10 --> Upload Class Initialized
INFO - 2023-12-03 15:39:10 --> Model "M_auth" initialized
INFO - 2023-12-03 15:39:10 --> Model "M_user" initialized
INFO - 2023-12-03 15:39:10 --> Model "M_produk" initialized
INFO - 2023-12-03 15:39:10 --> Controller Class Initialized
INFO - 2023-12-03 15:39:10 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 15:39:10 --> Model "M_produk" initialized
DEBUG - 2023-12-03 15:39:10 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 15:39:10 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 15:39:10 --> Model "M_transaksi" initialized
INFO - 2023-12-03 15:39:10 --> Model "M_bank" initialized
INFO - 2023-12-03 15:39:10 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 15:39:10 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 15:39:10 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 15:39:10 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 15:39:10 --> Final output sent to browser
DEBUG - 2023-12-03 15:39:10 --> Total execution time: 0.0034
ERROR - 2023-12-03 15:39:10 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 15:39:10 --> Config Class Initialized
INFO - 2023-12-03 15:39:10 --> Hooks Class Initialized
DEBUG - 2023-12-03 15:39:10 --> UTF-8 Support Enabled
INFO - 2023-12-03 15:39:10 --> Utf8 Class Initialized
INFO - 2023-12-03 15:39:10 --> URI Class Initialized
DEBUG - 2023-12-03 15:39:10 --> No URI present. Default controller set.
INFO - 2023-12-03 15:39:10 --> Router Class Initialized
INFO - 2023-12-03 15:39:10 --> Output Class Initialized
INFO - 2023-12-03 15:39:10 --> Security Class Initialized
DEBUG - 2023-12-03 15:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 15:39:10 --> Input Class Initialized
INFO - 2023-12-03 15:39:10 --> Language Class Initialized
INFO - 2023-12-03 15:39:10 --> Loader Class Initialized
INFO - 2023-12-03 15:39:10 --> Helper loaded: url_helper
INFO - 2023-12-03 15:39:10 --> Helper loaded: form_helper
INFO - 2023-12-03 15:39:10 --> Helper loaded: file_helper
INFO - 2023-12-03 15:39:10 --> Database Driver Class Initialized
DEBUG - 2023-12-03 15:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 15:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 15:39:10 --> Form Validation Class Initialized
INFO - 2023-12-03 15:39:10 --> Upload Class Initialized
INFO - 2023-12-03 15:39:10 --> Model "M_auth" initialized
INFO - 2023-12-03 15:39:10 --> Model "M_user" initialized
INFO - 2023-12-03 15:39:10 --> Model "M_produk" initialized
INFO - 2023-12-03 15:39:10 --> Controller Class Initialized
INFO - 2023-12-03 15:39:10 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 15:39:10 --> Model "M_produk" initialized
DEBUG - 2023-12-03 15:39:10 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 15:39:10 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 15:39:10 --> Model "M_transaksi" initialized
INFO - 2023-12-03 15:39:10 --> Model "M_bank" initialized
INFO - 2023-12-03 15:39:10 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 15:39:10 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 15:39:10 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 15:39:10 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 15:39:10 --> Final output sent to browser
DEBUG - 2023-12-03 15:39:10 --> Total execution time: 0.0034
ERROR - 2023-12-03 15:39:10 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 15:39:10 --> Config Class Initialized
INFO - 2023-12-03 15:39:10 --> Hooks Class Initialized
DEBUG - 2023-12-03 15:39:10 --> UTF-8 Support Enabled
INFO - 2023-12-03 15:39:10 --> Utf8 Class Initialized
INFO - 2023-12-03 15:39:10 --> URI Class Initialized
DEBUG - 2023-12-03 15:39:10 --> No URI present. Default controller set.
INFO - 2023-12-03 15:39:10 --> Router Class Initialized
INFO - 2023-12-03 15:39:10 --> Output Class Initialized
INFO - 2023-12-03 15:39:10 --> Security Class Initialized
DEBUG - 2023-12-03 15:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 15:39:10 --> Input Class Initialized
INFO - 2023-12-03 15:39:10 --> Language Class Initialized
INFO - 2023-12-03 15:39:10 --> Loader Class Initialized
INFO - 2023-12-03 15:39:10 --> Helper loaded: url_helper
INFO - 2023-12-03 15:39:10 --> Helper loaded: form_helper
INFO - 2023-12-03 15:39:10 --> Helper loaded: file_helper
INFO - 2023-12-03 15:39:10 --> Database Driver Class Initialized
DEBUG - 2023-12-03 15:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 15:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 15:39:10 --> Form Validation Class Initialized
INFO - 2023-12-03 15:39:10 --> Upload Class Initialized
INFO - 2023-12-03 15:39:10 --> Model "M_auth" initialized
INFO - 2023-12-03 15:39:10 --> Model "M_user" initialized
INFO - 2023-12-03 15:39:10 --> Model "M_produk" initialized
INFO - 2023-12-03 15:39:10 --> Controller Class Initialized
INFO - 2023-12-03 15:39:10 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 15:39:10 --> Model "M_produk" initialized
DEBUG - 2023-12-03 15:39:10 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 15:39:10 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 15:39:10 --> Model "M_transaksi" initialized
INFO - 2023-12-03 15:39:10 --> Model "M_bank" initialized
INFO - 2023-12-03 15:39:10 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 15:39:10 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 15:39:10 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 15:39:10 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 15:39:10 --> Final output sent to browser
DEBUG - 2023-12-03 15:39:10 --> Total execution time: 0.0037
ERROR - 2023-12-03 15:39:11 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 15:39:11 --> Config Class Initialized
INFO - 2023-12-03 15:39:11 --> Hooks Class Initialized
DEBUG - 2023-12-03 15:39:11 --> UTF-8 Support Enabled
INFO - 2023-12-03 15:39:11 --> Utf8 Class Initialized
INFO - 2023-12-03 15:39:11 --> URI Class Initialized
DEBUG - 2023-12-03 15:39:11 --> No URI present. Default controller set.
INFO - 2023-12-03 15:39:11 --> Router Class Initialized
INFO - 2023-12-03 15:39:11 --> Output Class Initialized
INFO - 2023-12-03 15:39:11 --> Security Class Initialized
DEBUG - 2023-12-03 15:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 15:39:11 --> Input Class Initialized
INFO - 2023-12-03 15:39:11 --> Language Class Initialized
INFO - 2023-12-03 15:39:11 --> Loader Class Initialized
INFO - 2023-12-03 15:39:11 --> Helper loaded: url_helper
INFO - 2023-12-03 15:39:11 --> Helper loaded: form_helper
INFO - 2023-12-03 15:39:11 --> Helper loaded: file_helper
INFO - 2023-12-03 15:39:11 --> Database Driver Class Initialized
DEBUG - 2023-12-03 15:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 15:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 15:39:11 --> Form Validation Class Initialized
INFO - 2023-12-03 15:39:11 --> Upload Class Initialized
INFO - 2023-12-03 15:39:11 --> Model "M_auth" initialized
INFO - 2023-12-03 15:39:11 --> Model "M_user" initialized
INFO - 2023-12-03 15:39:11 --> Model "M_produk" initialized
INFO - 2023-12-03 15:39:11 --> Controller Class Initialized
INFO - 2023-12-03 15:39:11 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 15:39:11 --> Model "M_produk" initialized
DEBUG - 2023-12-03 15:39:11 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 15:39:11 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 15:39:11 --> Model "M_transaksi" initialized
INFO - 2023-12-03 15:39:11 --> Model "M_bank" initialized
INFO - 2023-12-03 15:39:11 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 15:39:11 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 15:39:11 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 15:39:11 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 15:39:11 --> Final output sent to browser
DEBUG - 2023-12-03 15:39:11 --> Total execution time: 0.0036
ERROR - 2023-12-03 15:39:26 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 15:39:26 --> Config Class Initialized
INFO - 2023-12-03 15:39:26 --> Hooks Class Initialized
DEBUG - 2023-12-03 15:39:26 --> UTF-8 Support Enabled
INFO - 2023-12-03 15:39:26 --> Utf8 Class Initialized
INFO - 2023-12-03 15:39:26 --> URI Class Initialized
DEBUG - 2023-12-03 15:39:26 --> No URI present. Default controller set.
INFO - 2023-12-03 15:39:26 --> Router Class Initialized
INFO - 2023-12-03 15:39:26 --> Output Class Initialized
INFO - 2023-12-03 15:39:26 --> Security Class Initialized
DEBUG - 2023-12-03 15:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 15:39:26 --> Input Class Initialized
INFO - 2023-12-03 15:39:26 --> Language Class Initialized
INFO - 2023-12-03 15:39:26 --> Loader Class Initialized
INFO - 2023-12-03 15:39:26 --> Helper loaded: url_helper
INFO - 2023-12-03 15:39:26 --> Helper loaded: form_helper
INFO - 2023-12-03 15:39:26 --> Helper loaded: file_helper
INFO - 2023-12-03 15:39:26 --> Database Driver Class Initialized
DEBUG - 2023-12-03 15:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 15:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 15:39:26 --> Form Validation Class Initialized
INFO - 2023-12-03 15:39:26 --> Upload Class Initialized
INFO - 2023-12-03 15:39:26 --> Model "M_auth" initialized
INFO - 2023-12-03 15:39:26 --> Model "M_user" initialized
INFO - 2023-12-03 15:39:26 --> Model "M_produk" initialized
INFO - 2023-12-03 15:39:26 --> Controller Class Initialized
INFO - 2023-12-03 15:39:26 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 15:39:26 --> Model "M_produk" initialized
DEBUG - 2023-12-03 15:39:26 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 15:39:26 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 15:39:26 --> Model "M_transaksi" initialized
INFO - 2023-12-03 15:39:26 --> Model "M_bank" initialized
INFO - 2023-12-03 15:39:26 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 15:39:26 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 15:39:26 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 15:39:26 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 15:39:26 --> Final output sent to browser
DEBUG - 2023-12-03 15:39:26 --> Total execution time: 0.0035
ERROR - 2023-12-03 15:39:33 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 15:39:33 --> Config Class Initialized
INFO - 2023-12-03 15:39:33 --> Hooks Class Initialized
DEBUG - 2023-12-03 15:39:33 --> UTF-8 Support Enabled
INFO - 2023-12-03 15:39:33 --> Utf8 Class Initialized
INFO - 2023-12-03 15:39:33 --> URI Class Initialized
DEBUG - 2023-12-03 15:39:33 --> No URI present. Default controller set.
INFO - 2023-12-03 15:39:33 --> Router Class Initialized
INFO - 2023-12-03 15:39:33 --> Output Class Initialized
INFO - 2023-12-03 15:39:33 --> Security Class Initialized
DEBUG - 2023-12-03 15:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 15:39:33 --> Input Class Initialized
INFO - 2023-12-03 15:39:33 --> Language Class Initialized
INFO - 2023-12-03 15:39:33 --> Loader Class Initialized
INFO - 2023-12-03 15:39:33 --> Helper loaded: url_helper
INFO - 2023-12-03 15:39:33 --> Helper loaded: form_helper
INFO - 2023-12-03 15:39:33 --> Helper loaded: file_helper
INFO - 2023-12-03 15:39:33 --> Database Driver Class Initialized
DEBUG - 2023-12-03 15:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 15:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 15:39:33 --> Form Validation Class Initialized
INFO - 2023-12-03 15:39:33 --> Upload Class Initialized
INFO - 2023-12-03 15:39:33 --> Model "M_auth" initialized
INFO - 2023-12-03 15:39:33 --> Model "M_user" initialized
INFO - 2023-12-03 15:39:33 --> Model "M_produk" initialized
INFO - 2023-12-03 15:39:33 --> Controller Class Initialized
INFO - 2023-12-03 15:39:33 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 15:39:33 --> Model "M_produk" initialized
DEBUG - 2023-12-03 15:39:33 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 15:39:33 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 15:39:33 --> Model "M_transaksi" initialized
INFO - 2023-12-03 15:39:33 --> Model "M_bank" initialized
INFO - 2023-12-03 15:39:33 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 15:39:33 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 15:39:33 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 15:39:33 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 15:39:33 --> Final output sent to browser
DEBUG - 2023-12-03 15:39:33 --> Total execution time: 0.0034
ERROR - 2023-12-03 15:39:49 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 15:39:49 --> Config Class Initialized
INFO - 2023-12-03 15:39:49 --> Hooks Class Initialized
DEBUG - 2023-12-03 15:39:49 --> UTF-8 Support Enabled
INFO - 2023-12-03 15:39:49 --> Utf8 Class Initialized
INFO - 2023-12-03 15:39:49 --> URI Class Initialized
DEBUG - 2023-12-03 15:39:49 --> No URI present. Default controller set.
INFO - 2023-12-03 15:39:49 --> Router Class Initialized
INFO - 2023-12-03 15:39:49 --> Output Class Initialized
INFO - 2023-12-03 15:39:49 --> Security Class Initialized
DEBUG - 2023-12-03 15:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 15:39:49 --> Input Class Initialized
INFO - 2023-12-03 15:39:49 --> Language Class Initialized
INFO - 2023-12-03 15:39:49 --> Loader Class Initialized
INFO - 2023-12-03 15:39:49 --> Helper loaded: url_helper
INFO - 2023-12-03 15:39:49 --> Helper loaded: form_helper
INFO - 2023-12-03 15:39:49 --> Helper loaded: file_helper
INFO - 2023-12-03 15:39:49 --> Database Driver Class Initialized
DEBUG - 2023-12-03 15:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 15:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 15:39:49 --> Form Validation Class Initialized
INFO - 2023-12-03 15:39:49 --> Upload Class Initialized
INFO - 2023-12-03 15:39:49 --> Model "M_auth" initialized
INFO - 2023-12-03 15:39:49 --> Model "M_user" initialized
INFO - 2023-12-03 15:39:49 --> Model "M_produk" initialized
INFO - 2023-12-03 15:39:49 --> Controller Class Initialized
INFO - 2023-12-03 15:39:49 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 15:39:49 --> Model "M_produk" initialized
DEBUG - 2023-12-03 15:39:49 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 15:39:49 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 15:39:49 --> Model "M_transaksi" initialized
INFO - 2023-12-03 15:39:49 --> Model "M_bank" initialized
INFO - 2023-12-03 15:39:49 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 15:39:49 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 15:39:49 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 15:39:49 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 15:39:49 --> Final output sent to browser
DEBUG - 2023-12-03 15:39:49 --> Total execution time: 0.0043
ERROR - 2023-12-03 15:39:50 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 15:39:50 --> Config Class Initialized
INFO - 2023-12-03 15:39:50 --> Hooks Class Initialized
DEBUG - 2023-12-03 15:39:50 --> UTF-8 Support Enabled
INFO - 2023-12-03 15:39:50 --> Utf8 Class Initialized
INFO - 2023-12-03 15:39:50 --> URI Class Initialized
DEBUG - 2023-12-03 15:39:50 --> No URI present. Default controller set.
INFO - 2023-12-03 15:39:50 --> Router Class Initialized
INFO - 2023-12-03 15:39:50 --> Output Class Initialized
INFO - 2023-12-03 15:39:50 --> Security Class Initialized
DEBUG - 2023-12-03 15:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 15:39:50 --> Input Class Initialized
INFO - 2023-12-03 15:39:50 --> Language Class Initialized
INFO - 2023-12-03 15:39:50 --> Loader Class Initialized
INFO - 2023-12-03 15:39:50 --> Helper loaded: url_helper
INFO - 2023-12-03 15:39:50 --> Helper loaded: form_helper
INFO - 2023-12-03 15:39:50 --> Helper loaded: file_helper
INFO - 2023-12-03 15:39:50 --> Database Driver Class Initialized
DEBUG - 2023-12-03 15:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 15:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 15:39:50 --> Form Validation Class Initialized
INFO - 2023-12-03 15:39:50 --> Upload Class Initialized
INFO - 2023-12-03 15:39:50 --> Model "M_auth" initialized
INFO - 2023-12-03 15:39:50 --> Model "M_user" initialized
INFO - 2023-12-03 15:39:50 --> Model "M_produk" initialized
INFO - 2023-12-03 15:39:50 --> Controller Class Initialized
INFO - 2023-12-03 15:39:50 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 15:39:50 --> Model "M_produk" initialized
DEBUG - 2023-12-03 15:39:50 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 15:39:50 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 15:39:50 --> Model "M_transaksi" initialized
INFO - 2023-12-03 15:39:50 --> Model "M_bank" initialized
INFO - 2023-12-03 15:39:50 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 15:39:50 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 15:39:50 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 15:39:50 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 15:39:50 --> Final output sent to browser
DEBUG - 2023-12-03 15:39:50 --> Total execution time: 0.0030
ERROR - 2023-12-03 15:39:52 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 15:39:52 --> Config Class Initialized
INFO - 2023-12-03 15:39:52 --> Hooks Class Initialized
DEBUG - 2023-12-03 15:39:52 --> UTF-8 Support Enabled
INFO - 2023-12-03 15:39:52 --> Utf8 Class Initialized
INFO - 2023-12-03 15:39:52 --> URI Class Initialized
DEBUG - 2023-12-03 15:39:52 --> No URI present. Default controller set.
INFO - 2023-12-03 15:39:52 --> Router Class Initialized
INFO - 2023-12-03 15:39:52 --> Output Class Initialized
INFO - 2023-12-03 15:39:52 --> Security Class Initialized
DEBUG - 2023-12-03 15:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 15:39:52 --> Input Class Initialized
INFO - 2023-12-03 15:39:52 --> Language Class Initialized
INFO - 2023-12-03 15:39:52 --> Loader Class Initialized
INFO - 2023-12-03 15:39:52 --> Helper loaded: url_helper
INFO - 2023-12-03 15:39:52 --> Helper loaded: form_helper
INFO - 2023-12-03 15:39:52 --> Helper loaded: file_helper
INFO - 2023-12-03 15:39:52 --> Database Driver Class Initialized
DEBUG - 2023-12-03 15:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 15:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 15:39:52 --> Form Validation Class Initialized
INFO - 2023-12-03 15:39:52 --> Upload Class Initialized
INFO - 2023-12-03 15:39:52 --> Model "M_auth" initialized
INFO - 2023-12-03 15:39:52 --> Model "M_user" initialized
INFO - 2023-12-03 15:39:52 --> Model "M_produk" initialized
INFO - 2023-12-03 15:39:52 --> Controller Class Initialized
INFO - 2023-12-03 15:39:52 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 15:39:52 --> Model "M_produk" initialized
DEBUG - 2023-12-03 15:39:52 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 15:39:52 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 15:39:52 --> Model "M_transaksi" initialized
INFO - 2023-12-03 15:39:52 --> Model "M_bank" initialized
INFO - 2023-12-03 15:39:52 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 15:39:52 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 15:39:52 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 15:39:52 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 15:39:52 --> Final output sent to browser
DEBUG - 2023-12-03 15:39:52 --> Total execution time: 0.0038
ERROR - 2023-12-03 15:39:55 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 15:39:55 --> Config Class Initialized
INFO - 2023-12-03 15:39:55 --> Hooks Class Initialized
DEBUG - 2023-12-03 15:39:55 --> UTF-8 Support Enabled
INFO - 2023-12-03 15:39:55 --> Utf8 Class Initialized
INFO - 2023-12-03 15:39:55 --> URI Class Initialized
DEBUG - 2023-12-03 15:39:55 --> No URI present. Default controller set.
INFO - 2023-12-03 15:39:55 --> Router Class Initialized
INFO - 2023-12-03 15:39:55 --> Output Class Initialized
INFO - 2023-12-03 15:39:55 --> Security Class Initialized
DEBUG - 2023-12-03 15:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 15:39:55 --> Input Class Initialized
INFO - 2023-12-03 15:39:55 --> Language Class Initialized
INFO - 2023-12-03 15:39:55 --> Loader Class Initialized
INFO - 2023-12-03 15:39:55 --> Helper loaded: url_helper
INFO - 2023-12-03 15:39:55 --> Helper loaded: form_helper
INFO - 2023-12-03 15:39:55 --> Helper loaded: file_helper
INFO - 2023-12-03 15:39:55 --> Database Driver Class Initialized
DEBUG - 2023-12-03 15:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 15:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 15:39:55 --> Form Validation Class Initialized
INFO - 2023-12-03 15:39:55 --> Upload Class Initialized
INFO - 2023-12-03 15:39:55 --> Model "M_auth" initialized
INFO - 2023-12-03 15:39:55 --> Model "M_user" initialized
INFO - 2023-12-03 15:39:55 --> Model "M_produk" initialized
INFO - 2023-12-03 15:39:55 --> Controller Class Initialized
INFO - 2023-12-03 15:39:55 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 15:39:55 --> Model "M_produk" initialized
DEBUG - 2023-12-03 15:39:55 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 15:39:55 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 15:39:55 --> Model "M_transaksi" initialized
INFO - 2023-12-03 15:39:55 --> Model "M_bank" initialized
INFO - 2023-12-03 15:39:55 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 15:39:55 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 15:39:55 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 15:39:55 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 15:39:55 --> Final output sent to browser
DEBUG - 2023-12-03 15:39:55 --> Total execution time: 0.0038
ERROR - 2023-12-03 17:49:39 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 17:49:39 --> Config Class Initialized
INFO - 2023-12-03 17:49:39 --> Hooks Class Initialized
DEBUG - 2023-12-03 17:49:39 --> UTF-8 Support Enabled
INFO - 2023-12-03 17:49:39 --> Utf8 Class Initialized
INFO - 2023-12-03 17:49:39 --> URI Class Initialized
DEBUG - 2023-12-03 17:49:39 --> No URI present. Default controller set.
INFO - 2023-12-03 17:49:39 --> Router Class Initialized
INFO - 2023-12-03 17:49:39 --> Output Class Initialized
INFO - 2023-12-03 17:49:39 --> Security Class Initialized
DEBUG - 2023-12-03 17:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 17:49:39 --> Input Class Initialized
INFO - 2023-12-03 17:49:39 --> Language Class Initialized
INFO - 2023-12-03 17:49:39 --> Loader Class Initialized
INFO - 2023-12-03 17:49:39 --> Helper loaded: url_helper
INFO - 2023-12-03 17:49:39 --> Helper loaded: form_helper
INFO - 2023-12-03 17:49:39 --> Helper loaded: file_helper
INFO - 2023-12-03 17:49:39 --> Database Driver Class Initialized
DEBUG - 2023-12-03 17:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 17:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 17:49:39 --> Form Validation Class Initialized
INFO - 2023-12-03 17:49:39 --> Upload Class Initialized
INFO - 2023-12-03 17:49:39 --> Model "M_auth" initialized
INFO - 2023-12-03 17:49:39 --> Model "M_user" initialized
INFO - 2023-12-03 17:49:39 --> Model "M_produk" initialized
INFO - 2023-12-03 17:49:39 --> Controller Class Initialized
INFO - 2023-12-03 17:49:39 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 17:49:39 --> Model "M_produk" initialized
DEBUG - 2023-12-03 17:49:39 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 17:49:39 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 17:49:39 --> Model "M_transaksi" initialized
INFO - 2023-12-03 17:49:39 --> Model "M_bank" initialized
INFO - 2023-12-03 17:49:39 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 17:49:39 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 17:49:39 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 17:49:39 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 17:49:39 --> Final output sent to browser
DEBUG - 2023-12-03 17:49:39 --> Total execution time: 0.0318
ERROR - 2023-12-03 18:38:19 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 18:38:19 --> Config Class Initialized
INFO - 2023-12-03 18:38:19 --> Hooks Class Initialized
DEBUG - 2023-12-03 18:38:19 --> UTF-8 Support Enabled
INFO - 2023-12-03 18:38:19 --> Utf8 Class Initialized
INFO - 2023-12-03 18:38:19 --> URI Class Initialized
INFO - 2023-12-03 18:38:19 --> Router Class Initialized
INFO - 2023-12-03 18:38:19 --> Output Class Initialized
INFO - 2023-12-03 18:38:19 --> Security Class Initialized
DEBUG - 2023-12-03 18:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 18:38:19 --> Input Class Initialized
INFO - 2023-12-03 18:38:19 --> Language Class Initialized
INFO - 2023-12-03 18:38:19 --> Loader Class Initialized
INFO - 2023-12-03 18:38:19 --> Helper loaded: url_helper
INFO - 2023-12-03 18:38:19 --> Helper loaded: form_helper
INFO - 2023-12-03 18:38:19 --> Helper loaded: file_helper
INFO - 2023-12-03 18:38:19 --> Database Driver Class Initialized
DEBUG - 2023-12-03 18:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 18:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 18:38:19 --> Form Validation Class Initialized
INFO - 2023-12-03 18:38:19 --> Upload Class Initialized
INFO - 2023-12-03 18:38:19 --> Model "M_auth" initialized
INFO - 2023-12-03 18:38:19 --> Model "M_user" initialized
INFO - 2023-12-03 18:38:19 --> Model "M_produk" initialized
INFO - 2023-12-03 18:38:19 --> Controller Class Initialized
INFO - 2023-12-03 18:38:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-03 18:38:19 --> Final output sent to browser
DEBUG - 2023-12-03 18:38:19 --> Total execution time: 0.0283
ERROR - 2023-12-03 18:38:19 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 18:38:19 --> Config Class Initialized
INFO - 2023-12-03 18:38:19 --> Hooks Class Initialized
DEBUG - 2023-12-03 18:38:19 --> UTF-8 Support Enabled
INFO - 2023-12-03 18:38:19 --> Utf8 Class Initialized
INFO - 2023-12-03 18:38:19 --> URI Class Initialized
DEBUG - 2023-12-03 18:38:19 --> No URI present. Default controller set.
INFO - 2023-12-03 18:38:19 --> Router Class Initialized
INFO - 2023-12-03 18:38:19 --> Output Class Initialized
INFO - 2023-12-03 18:38:19 --> Security Class Initialized
DEBUG - 2023-12-03 18:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 18:38:19 --> Input Class Initialized
INFO - 2023-12-03 18:38:19 --> Language Class Initialized
INFO - 2023-12-03 18:38:19 --> Loader Class Initialized
INFO - 2023-12-03 18:38:19 --> Helper loaded: url_helper
INFO - 2023-12-03 18:38:19 --> Helper loaded: form_helper
INFO - 2023-12-03 18:38:19 --> Helper loaded: file_helper
INFO - 2023-12-03 18:38:19 --> Database Driver Class Initialized
DEBUG - 2023-12-03 18:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 18:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 18:38:19 --> Form Validation Class Initialized
INFO - 2023-12-03 18:38:19 --> Upload Class Initialized
INFO - 2023-12-03 18:38:19 --> Model "M_auth" initialized
INFO - 2023-12-03 18:38:19 --> Model "M_user" initialized
INFO - 2023-12-03 18:38:19 --> Model "M_produk" initialized
INFO - 2023-12-03 18:38:19 --> Controller Class Initialized
INFO - 2023-12-03 18:38:19 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 18:38:19 --> Model "M_produk" initialized
DEBUG - 2023-12-03 18:38:19 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 18:38:19 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 18:38:19 --> Model "M_transaksi" initialized
INFO - 2023-12-03 18:38:19 --> Model "M_bank" initialized
INFO - 2023-12-03 18:38:19 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 18:38:19 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 18:38:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 18:38:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 18:38:19 --> Final output sent to browser
DEBUG - 2023-12-03 18:38:19 --> Total execution time: 0.0101
ERROR - 2023-12-03 18:49:55 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 18:49:55 --> Config Class Initialized
INFO - 2023-12-03 18:49:55 --> Hooks Class Initialized
DEBUG - 2023-12-03 18:49:55 --> UTF-8 Support Enabled
INFO - 2023-12-03 18:49:55 --> Utf8 Class Initialized
INFO - 2023-12-03 18:49:55 --> URI Class Initialized
DEBUG - 2023-12-03 18:49:55 --> No URI present. Default controller set.
INFO - 2023-12-03 18:49:55 --> Router Class Initialized
INFO - 2023-12-03 18:49:55 --> Output Class Initialized
INFO - 2023-12-03 18:49:55 --> Security Class Initialized
DEBUG - 2023-12-03 18:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 18:49:55 --> Input Class Initialized
INFO - 2023-12-03 18:49:55 --> Language Class Initialized
INFO - 2023-12-03 18:49:55 --> Loader Class Initialized
INFO - 2023-12-03 18:49:55 --> Helper loaded: url_helper
INFO - 2023-12-03 18:49:55 --> Helper loaded: form_helper
INFO - 2023-12-03 18:49:55 --> Helper loaded: file_helper
INFO - 2023-12-03 18:49:55 --> Database Driver Class Initialized
DEBUG - 2023-12-03 18:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 18:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 18:49:55 --> Form Validation Class Initialized
INFO - 2023-12-03 18:49:55 --> Upload Class Initialized
INFO - 2023-12-03 18:49:55 --> Model "M_auth" initialized
INFO - 2023-12-03 18:49:55 --> Model "M_user" initialized
INFO - 2023-12-03 18:49:55 --> Model "M_produk" initialized
INFO - 2023-12-03 18:49:55 --> Controller Class Initialized
INFO - 2023-12-03 18:49:55 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 18:49:55 --> Model "M_produk" initialized
DEBUG - 2023-12-03 18:49:55 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 18:49:55 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 18:49:55 --> Model "M_transaksi" initialized
INFO - 2023-12-03 18:49:55 --> Model "M_bank" initialized
INFO - 2023-12-03 18:49:55 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 18:49:55 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 18:49:55 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 18:49:55 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 18:49:55 --> Final output sent to browser
DEBUG - 2023-12-03 18:49:55 --> Total execution time: 0.0285
ERROR - 2023-12-03 20:02:28 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 20:02:28 --> Config Class Initialized
INFO - 2023-12-03 20:02:28 --> Hooks Class Initialized
DEBUG - 2023-12-03 20:02:28 --> UTF-8 Support Enabled
INFO - 2023-12-03 20:02:28 --> Utf8 Class Initialized
INFO - 2023-12-03 20:02:28 --> URI Class Initialized
DEBUG - 2023-12-03 20:02:28 --> No URI present. Default controller set.
INFO - 2023-12-03 20:02:28 --> Router Class Initialized
INFO - 2023-12-03 20:02:28 --> Output Class Initialized
INFO - 2023-12-03 20:02:28 --> Security Class Initialized
DEBUG - 2023-12-03 20:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 20:02:28 --> Input Class Initialized
INFO - 2023-12-03 20:02:28 --> Language Class Initialized
INFO - 2023-12-03 20:02:28 --> Loader Class Initialized
INFO - 2023-12-03 20:02:28 --> Helper loaded: url_helper
INFO - 2023-12-03 20:02:28 --> Helper loaded: form_helper
INFO - 2023-12-03 20:02:28 --> Helper loaded: file_helper
INFO - 2023-12-03 20:02:28 --> Database Driver Class Initialized
DEBUG - 2023-12-03 20:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 20:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 20:02:28 --> Form Validation Class Initialized
INFO - 2023-12-03 20:02:28 --> Upload Class Initialized
INFO - 2023-12-03 20:02:28 --> Model "M_auth" initialized
INFO - 2023-12-03 20:02:28 --> Model "M_user" initialized
INFO - 2023-12-03 20:02:28 --> Model "M_produk" initialized
INFO - 2023-12-03 20:02:28 --> Controller Class Initialized
INFO - 2023-12-03 20:02:28 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 20:02:28 --> Model "M_produk" initialized
DEBUG - 2023-12-03 20:02:28 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 20:02:28 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 20:02:28 --> Model "M_transaksi" initialized
INFO - 2023-12-03 20:02:28 --> Model "M_bank" initialized
INFO - 2023-12-03 20:02:28 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 20:02:28 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 20:02:28 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 20:02:28 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 20:02:28 --> Final output sent to browser
DEBUG - 2023-12-03 20:02:28 --> Total execution time: 0.0336
ERROR - 2023-12-03 20:18:02 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 20:18:02 --> Config Class Initialized
INFO - 2023-12-03 20:18:02 --> Hooks Class Initialized
DEBUG - 2023-12-03 20:18:02 --> UTF-8 Support Enabled
INFO - 2023-12-03 20:18:02 --> Utf8 Class Initialized
INFO - 2023-12-03 20:18:02 --> URI Class Initialized
DEBUG - 2023-12-03 20:18:02 --> No URI present. Default controller set.
INFO - 2023-12-03 20:18:02 --> Router Class Initialized
INFO - 2023-12-03 20:18:02 --> Output Class Initialized
INFO - 2023-12-03 20:18:02 --> Security Class Initialized
DEBUG - 2023-12-03 20:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 20:18:02 --> Input Class Initialized
INFO - 2023-12-03 20:18:02 --> Language Class Initialized
INFO - 2023-12-03 20:18:02 --> Loader Class Initialized
INFO - 2023-12-03 20:18:02 --> Helper loaded: url_helper
INFO - 2023-12-03 20:18:02 --> Helper loaded: form_helper
INFO - 2023-12-03 20:18:02 --> Helper loaded: file_helper
INFO - 2023-12-03 20:18:02 --> Database Driver Class Initialized
DEBUG - 2023-12-03 20:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 20:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 20:18:02 --> Form Validation Class Initialized
INFO - 2023-12-03 20:18:02 --> Upload Class Initialized
INFO - 2023-12-03 20:18:02 --> Model "M_auth" initialized
INFO - 2023-12-03 20:18:02 --> Model "M_user" initialized
INFO - 2023-12-03 20:18:02 --> Model "M_produk" initialized
INFO - 2023-12-03 20:18:02 --> Controller Class Initialized
INFO - 2023-12-03 20:18:02 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 20:18:02 --> Model "M_produk" initialized
DEBUG - 2023-12-03 20:18:02 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 20:18:02 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 20:18:02 --> Model "M_transaksi" initialized
INFO - 2023-12-03 20:18:02 --> Model "M_bank" initialized
INFO - 2023-12-03 20:18:02 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 20:18:02 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 20:18:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 20:18:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 20:18:02 --> Final output sent to browser
DEBUG - 2023-12-03 20:18:02 --> Total execution time: 0.0358
ERROR - 2023-12-03 20:19:43 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 20:19:43 --> Config Class Initialized
INFO - 2023-12-03 20:19:43 --> Hooks Class Initialized
DEBUG - 2023-12-03 20:19:43 --> UTF-8 Support Enabled
INFO - 2023-12-03 20:19:43 --> Utf8 Class Initialized
INFO - 2023-12-03 20:19:43 --> URI Class Initialized
DEBUG - 2023-12-03 20:19:43 --> No URI present. Default controller set.
INFO - 2023-12-03 20:19:43 --> Router Class Initialized
INFO - 2023-12-03 20:19:43 --> Output Class Initialized
INFO - 2023-12-03 20:19:43 --> Security Class Initialized
DEBUG - 2023-12-03 20:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 20:19:43 --> Input Class Initialized
INFO - 2023-12-03 20:19:43 --> Language Class Initialized
INFO - 2023-12-03 20:19:43 --> Loader Class Initialized
INFO - 2023-12-03 20:19:43 --> Helper loaded: url_helper
INFO - 2023-12-03 20:19:43 --> Helper loaded: form_helper
INFO - 2023-12-03 20:19:43 --> Helper loaded: file_helper
INFO - 2023-12-03 20:19:43 --> Database Driver Class Initialized
DEBUG - 2023-12-03 20:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 20:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 20:19:43 --> Form Validation Class Initialized
INFO - 2023-12-03 20:19:43 --> Upload Class Initialized
INFO - 2023-12-03 20:19:43 --> Model "M_auth" initialized
INFO - 2023-12-03 20:19:43 --> Model "M_user" initialized
INFO - 2023-12-03 20:19:43 --> Model "M_produk" initialized
INFO - 2023-12-03 20:19:43 --> Controller Class Initialized
INFO - 2023-12-03 20:19:43 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 20:19:43 --> Model "M_produk" initialized
DEBUG - 2023-12-03 20:19:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 20:19:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 20:19:43 --> Model "M_transaksi" initialized
INFO - 2023-12-03 20:19:43 --> Model "M_bank" initialized
INFO - 2023-12-03 20:19:43 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 20:19:43 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 20:19:43 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 20:19:43 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 20:19:43 --> Final output sent to browser
DEBUG - 2023-12-03 20:19:43 --> Total execution time: 0.0055
ERROR - 2023-12-03 20:47:49 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 20:47:49 --> Config Class Initialized
INFO - 2023-12-03 20:47:49 --> Hooks Class Initialized
DEBUG - 2023-12-03 20:47:49 --> UTF-8 Support Enabled
INFO - 2023-12-03 20:47:49 --> Utf8 Class Initialized
INFO - 2023-12-03 20:47:49 --> URI Class Initialized
DEBUG - 2023-12-03 20:47:49 --> No URI present. Default controller set.
INFO - 2023-12-03 20:47:49 --> Router Class Initialized
INFO - 2023-12-03 20:47:49 --> Output Class Initialized
INFO - 2023-12-03 20:47:49 --> Security Class Initialized
DEBUG - 2023-12-03 20:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 20:47:49 --> Input Class Initialized
INFO - 2023-12-03 20:47:49 --> Language Class Initialized
INFO - 2023-12-03 20:47:49 --> Loader Class Initialized
INFO - 2023-12-03 20:47:49 --> Helper loaded: url_helper
INFO - 2023-12-03 20:47:49 --> Helper loaded: form_helper
INFO - 2023-12-03 20:47:49 --> Helper loaded: file_helper
INFO - 2023-12-03 20:47:49 --> Database Driver Class Initialized
DEBUG - 2023-12-03 20:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 20:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 20:47:49 --> Form Validation Class Initialized
INFO - 2023-12-03 20:47:49 --> Upload Class Initialized
INFO - 2023-12-03 20:47:49 --> Model "M_auth" initialized
INFO - 2023-12-03 20:47:49 --> Model "M_user" initialized
INFO - 2023-12-03 20:47:49 --> Model "M_produk" initialized
INFO - 2023-12-03 20:47:49 --> Controller Class Initialized
INFO - 2023-12-03 20:47:49 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 20:47:49 --> Model "M_produk" initialized
DEBUG - 2023-12-03 20:47:49 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 20:47:49 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 20:47:49 --> Model "M_transaksi" initialized
INFO - 2023-12-03 20:47:49 --> Model "M_bank" initialized
INFO - 2023-12-03 20:47:49 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 20:47:49 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 20:47:49 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 20:47:49 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 20:47:49 --> Final output sent to browser
DEBUG - 2023-12-03 20:47:49 --> Total execution time: 0.0308
ERROR - 2023-12-03 21:17:57 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 21:17:57 --> Config Class Initialized
INFO - 2023-12-03 21:17:57 --> Hooks Class Initialized
DEBUG - 2023-12-03 21:17:57 --> UTF-8 Support Enabled
INFO - 2023-12-03 21:17:57 --> Utf8 Class Initialized
INFO - 2023-12-03 21:17:57 --> URI Class Initialized
INFO - 2023-12-03 21:17:57 --> Router Class Initialized
INFO - 2023-12-03 21:17:57 --> Output Class Initialized
INFO - 2023-12-03 21:17:57 --> Security Class Initialized
DEBUG - 2023-12-03 21:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 21:17:57 --> Input Class Initialized
INFO - 2023-12-03 21:17:57 --> Language Class Initialized
INFO - 2023-12-03 21:17:57 --> Loader Class Initialized
INFO - 2023-12-03 21:17:57 --> Helper loaded: url_helper
INFO - 2023-12-03 21:17:57 --> Helper loaded: form_helper
INFO - 2023-12-03 21:17:57 --> Helper loaded: file_helper
INFO - 2023-12-03 21:17:57 --> Database Driver Class Initialized
DEBUG - 2023-12-03 21:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 21:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 21:17:57 --> Form Validation Class Initialized
INFO - 2023-12-03 21:17:57 --> Upload Class Initialized
INFO - 2023-12-03 21:17:57 --> Model "M_auth" initialized
INFO - 2023-12-03 21:17:57 --> Model "M_user" initialized
INFO - 2023-12-03 21:17:57 --> Model "M_produk" initialized
INFO - 2023-12-03 21:17:57 --> Controller Class Initialized
INFO - 2023-12-03 21:17:57 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-03 21:17:57 --> Final output sent to browser
DEBUG - 2023-12-03 21:17:57 --> Total execution time: 0.0249
ERROR - 2023-12-03 21:50:21 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 21:50:21 --> Config Class Initialized
INFO - 2023-12-03 21:50:21 --> Hooks Class Initialized
DEBUG - 2023-12-03 21:50:21 --> UTF-8 Support Enabled
INFO - 2023-12-03 21:50:21 --> Utf8 Class Initialized
INFO - 2023-12-03 21:50:21 --> URI Class Initialized
INFO - 2023-12-03 21:50:21 --> Router Class Initialized
INFO - 2023-12-03 21:50:21 --> Output Class Initialized
INFO - 2023-12-03 21:50:21 --> Security Class Initialized
DEBUG - 2023-12-03 21:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 21:50:21 --> Input Class Initialized
INFO - 2023-12-03 21:50:21 --> Language Class Initialized
INFO - 2023-12-03 21:50:21 --> Loader Class Initialized
INFO - 2023-12-03 21:50:21 --> Helper loaded: url_helper
INFO - 2023-12-03 21:50:21 --> Helper loaded: form_helper
INFO - 2023-12-03 21:50:21 --> Helper loaded: file_helper
INFO - 2023-12-03 21:50:21 --> Database Driver Class Initialized
DEBUG - 2023-12-03 21:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 21:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 21:50:21 --> Form Validation Class Initialized
INFO - 2023-12-03 21:50:21 --> Upload Class Initialized
INFO - 2023-12-03 21:50:21 --> Model "M_auth" initialized
INFO - 2023-12-03 21:50:21 --> Model "M_user" initialized
INFO - 2023-12-03 21:50:21 --> Model "M_produk" initialized
INFO - 2023-12-03 21:50:21 --> Controller Class Initialized
INFO - 2023-12-03 21:50:21 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-03 21:50:21 --> Final output sent to browser
DEBUG - 2023-12-03 21:50:21 --> Total execution time: 0.0281
ERROR - 2023-12-03 21:50:21 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 21:50:21 --> Config Class Initialized
INFO - 2023-12-03 21:50:21 --> Hooks Class Initialized
DEBUG - 2023-12-03 21:50:21 --> UTF-8 Support Enabled
INFO - 2023-12-03 21:50:21 --> Utf8 Class Initialized
INFO - 2023-12-03 21:50:21 --> URI Class Initialized
DEBUG - 2023-12-03 21:50:21 --> No URI present. Default controller set.
INFO - 2023-12-03 21:50:21 --> Router Class Initialized
INFO - 2023-12-03 21:50:21 --> Output Class Initialized
INFO - 2023-12-03 21:50:21 --> Security Class Initialized
DEBUG - 2023-12-03 21:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 21:50:21 --> Input Class Initialized
INFO - 2023-12-03 21:50:21 --> Language Class Initialized
INFO - 2023-12-03 21:50:21 --> Loader Class Initialized
INFO - 2023-12-03 21:50:21 --> Helper loaded: url_helper
INFO - 2023-12-03 21:50:21 --> Helper loaded: form_helper
INFO - 2023-12-03 21:50:21 --> Helper loaded: file_helper
INFO - 2023-12-03 21:50:21 --> Database Driver Class Initialized
DEBUG - 2023-12-03 21:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 21:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 21:50:21 --> Form Validation Class Initialized
INFO - 2023-12-03 21:50:21 --> Upload Class Initialized
INFO - 2023-12-03 21:50:21 --> Model "M_auth" initialized
INFO - 2023-12-03 21:50:21 --> Model "M_user" initialized
INFO - 2023-12-03 21:50:21 --> Model "M_produk" initialized
INFO - 2023-12-03 21:50:21 --> Controller Class Initialized
INFO - 2023-12-03 21:50:21 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 21:50:21 --> Model "M_produk" initialized
DEBUG - 2023-12-03 21:50:21 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 21:50:21 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 21:50:21 --> Model "M_transaksi" initialized
INFO - 2023-12-03 21:50:21 --> Model "M_bank" initialized
INFO - 2023-12-03 21:50:21 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 21:50:21 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 21:50:21 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 21:50:21 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 21:50:21 --> Final output sent to browser
DEBUG - 2023-12-03 21:50:21 --> Total execution time: 0.0086
ERROR - 2023-12-03 22:28:28 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 22:28:28 --> Config Class Initialized
INFO - 2023-12-03 22:28:28 --> Hooks Class Initialized
DEBUG - 2023-12-03 22:28:28 --> UTF-8 Support Enabled
INFO - 2023-12-03 22:28:28 --> Utf8 Class Initialized
INFO - 2023-12-03 22:28:28 --> URI Class Initialized
INFO - 2023-12-03 22:28:28 --> Router Class Initialized
INFO - 2023-12-03 22:28:28 --> Output Class Initialized
INFO - 2023-12-03 22:28:28 --> Security Class Initialized
DEBUG - 2023-12-03 22:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 22:28:28 --> Input Class Initialized
INFO - 2023-12-03 22:28:28 --> Language Class Initialized
INFO - 2023-12-03 22:28:28 --> Loader Class Initialized
INFO - 2023-12-03 22:28:28 --> Helper loaded: url_helper
INFO - 2023-12-03 22:28:28 --> Helper loaded: form_helper
INFO - 2023-12-03 22:28:28 --> Helper loaded: file_helper
INFO - 2023-12-03 22:28:28 --> Database Driver Class Initialized
DEBUG - 2023-12-03 22:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 22:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 22:28:28 --> Form Validation Class Initialized
INFO - 2023-12-03 22:28:28 --> Upload Class Initialized
INFO - 2023-12-03 22:28:28 --> Model "M_auth" initialized
INFO - 2023-12-03 22:28:28 --> Model "M_user" initialized
INFO - 2023-12-03 22:28:28 --> Model "M_produk" initialized
INFO - 2023-12-03 22:28:28 --> Controller Class Initialized
INFO - 2023-12-03 22:28:28 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-03 22:28:28 --> Final output sent to browser
DEBUG - 2023-12-03 22:28:28 --> Total execution time: 0.0284
ERROR - 2023-12-03 22:28:34 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 22:28:34 --> Config Class Initialized
INFO - 2023-12-03 22:28:34 --> Hooks Class Initialized
DEBUG - 2023-12-03 22:28:34 --> UTF-8 Support Enabled
INFO - 2023-12-03 22:28:34 --> Utf8 Class Initialized
INFO - 2023-12-03 22:28:34 --> URI Class Initialized
INFO - 2023-12-03 22:28:34 --> Router Class Initialized
INFO - 2023-12-03 22:28:34 --> Output Class Initialized
INFO - 2023-12-03 22:28:34 --> Security Class Initialized
DEBUG - 2023-12-03 22:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 22:28:34 --> Input Class Initialized
INFO - 2023-12-03 22:28:34 --> Language Class Initialized
INFO - 2023-12-03 22:28:34 --> Loader Class Initialized
INFO - 2023-12-03 22:28:34 --> Helper loaded: url_helper
INFO - 2023-12-03 22:28:34 --> Helper loaded: form_helper
INFO - 2023-12-03 22:28:34 --> Helper loaded: file_helper
INFO - 2023-12-03 22:28:34 --> Database Driver Class Initialized
DEBUG - 2023-12-03 22:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 22:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 22:28:34 --> Form Validation Class Initialized
INFO - 2023-12-03 22:28:34 --> Upload Class Initialized
INFO - 2023-12-03 22:28:34 --> Model "M_auth" initialized
INFO - 2023-12-03 22:28:34 --> Model "M_user" initialized
INFO - 2023-12-03 22:28:34 --> Model "M_produk" initialized
INFO - 2023-12-03 22:28:34 --> Controller Class Initialized
INFO - 2023-12-03 22:28:34 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-03 22:28:34 --> Final output sent to browser
DEBUG - 2023-12-03 22:28:34 --> Total execution time: 0.0029
ERROR - 2023-12-03 22:28:47 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 22:28:47 --> Config Class Initialized
INFO - 2023-12-03 22:28:47 --> Hooks Class Initialized
DEBUG - 2023-12-03 22:28:47 --> UTF-8 Support Enabled
INFO - 2023-12-03 22:28:47 --> Utf8 Class Initialized
INFO - 2023-12-03 22:28:47 --> URI Class Initialized
INFO - 2023-12-03 22:28:47 --> Router Class Initialized
INFO - 2023-12-03 22:28:47 --> Output Class Initialized
INFO - 2023-12-03 22:28:47 --> Security Class Initialized
DEBUG - 2023-12-03 22:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 22:28:47 --> Input Class Initialized
INFO - 2023-12-03 22:28:47 --> Language Class Initialized
INFO - 2023-12-03 22:28:47 --> Loader Class Initialized
INFO - 2023-12-03 22:28:47 --> Helper loaded: url_helper
INFO - 2023-12-03 22:28:47 --> Helper loaded: form_helper
INFO - 2023-12-03 22:28:47 --> Helper loaded: file_helper
INFO - 2023-12-03 22:28:47 --> Database Driver Class Initialized
DEBUG - 2023-12-03 22:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 22:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 22:28:47 --> Form Validation Class Initialized
INFO - 2023-12-03 22:28:47 --> Upload Class Initialized
INFO - 2023-12-03 22:28:47 --> Model "M_auth" initialized
INFO - 2023-12-03 22:28:47 --> Model "M_user" initialized
INFO - 2023-12-03 22:28:47 --> Model "M_produk" initialized
INFO - 2023-12-03 22:28:47 --> Controller Class Initialized
INFO - 2023-12-03 22:28:47 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-03 22:28:47 --> Final output sent to browser
DEBUG - 2023-12-03 22:28:47 --> Total execution time: 0.0027
ERROR - 2023-12-03 22:50:09 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 22:50:09 --> Config Class Initialized
INFO - 2023-12-03 22:50:09 --> Hooks Class Initialized
DEBUG - 2023-12-03 22:50:09 --> UTF-8 Support Enabled
INFO - 2023-12-03 22:50:09 --> Utf8 Class Initialized
INFO - 2023-12-03 22:50:09 --> URI Class Initialized
DEBUG - 2023-12-03 22:50:09 --> No URI present. Default controller set.
INFO - 2023-12-03 22:50:09 --> Router Class Initialized
INFO - 2023-12-03 22:50:09 --> Output Class Initialized
INFO - 2023-12-03 22:50:09 --> Security Class Initialized
DEBUG - 2023-12-03 22:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 22:50:09 --> Input Class Initialized
INFO - 2023-12-03 22:50:09 --> Language Class Initialized
INFO - 2023-12-03 22:50:09 --> Loader Class Initialized
INFO - 2023-12-03 22:50:09 --> Helper loaded: url_helper
INFO - 2023-12-03 22:50:09 --> Helper loaded: form_helper
INFO - 2023-12-03 22:50:09 --> Helper loaded: file_helper
INFO - 2023-12-03 22:50:09 --> Database Driver Class Initialized
DEBUG - 2023-12-03 22:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 22:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 22:50:09 --> Form Validation Class Initialized
INFO - 2023-12-03 22:50:09 --> Upload Class Initialized
INFO - 2023-12-03 22:50:09 --> Model "M_auth" initialized
INFO - 2023-12-03 22:50:09 --> Model "M_user" initialized
INFO - 2023-12-03 22:50:09 --> Model "M_produk" initialized
INFO - 2023-12-03 22:50:09 --> Controller Class Initialized
INFO - 2023-12-03 22:50:09 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 22:50:09 --> Model "M_produk" initialized
DEBUG - 2023-12-03 22:50:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 22:50:09 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 22:50:09 --> Model "M_transaksi" initialized
INFO - 2023-12-03 22:50:09 --> Model "M_bank" initialized
INFO - 2023-12-03 22:50:09 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 22:50:09 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 22:50:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 22:50:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 22:50:09 --> Final output sent to browser
DEBUG - 2023-12-03 22:50:09 --> Total execution time: 0.0350
ERROR - 2023-12-03 22:52:50 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 22:52:50 --> Config Class Initialized
INFO - 2023-12-03 22:52:50 --> Hooks Class Initialized
DEBUG - 2023-12-03 22:52:50 --> UTF-8 Support Enabled
INFO - 2023-12-03 22:52:50 --> Utf8 Class Initialized
INFO - 2023-12-03 22:52:50 --> URI Class Initialized
DEBUG - 2023-12-03 22:52:50 --> No URI present. Default controller set.
INFO - 2023-12-03 22:52:50 --> Router Class Initialized
INFO - 2023-12-03 22:52:50 --> Output Class Initialized
INFO - 2023-12-03 22:52:50 --> Security Class Initialized
DEBUG - 2023-12-03 22:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 22:52:50 --> Input Class Initialized
INFO - 2023-12-03 22:52:50 --> Language Class Initialized
INFO - 2023-12-03 22:52:50 --> Loader Class Initialized
INFO - 2023-12-03 22:52:50 --> Helper loaded: url_helper
INFO - 2023-12-03 22:52:50 --> Helper loaded: form_helper
INFO - 2023-12-03 22:52:50 --> Helper loaded: file_helper
INFO - 2023-12-03 22:52:50 --> Database Driver Class Initialized
DEBUG - 2023-12-03 22:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 22:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 22:52:50 --> Form Validation Class Initialized
INFO - 2023-12-03 22:52:50 --> Upload Class Initialized
INFO - 2023-12-03 22:52:50 --> Model "M_auth" initialized
INFO - 2023-12-03 22:52:50 --> Model "M_user" initialized
INFO - 2023-12-03 22:52:50 --> Model "M_produk" initialized
INFO - 2023-12-03 22:52:50 --> Controller Class Initialized
INFO - 2023-12-03 22:52:50 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 22:52:50 --> Model "M_produk" initialized
DEBUG - 2023-12-03 22:52:50 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 22:52:50 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 22:52:50 --> Model "M_transaksi" initialized
INFO - 2023-12-03 22:52:50 --> Model "M_bank" initialized
INFO - 2023-12-03 22:52:50 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 22:52:50 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 22:52:50 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 22:52:50 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 22:52:50 --> Final output sent to browser
DEBUG - 2023-12-03 22:52:50 --> Total execution time: 0.0040
ERROR - 2023-12-03 22:52:50 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 22:52:50 --> Config Class Initialized
INFO - 2023-12-03 22:52:50 --> Hooks Class Initialized
DEBUG - 2023-12-03 22:52:50 --> UTF-8 Support Enabled
INFO - 2023-12-03 22:52:50 --> Utf8 Class Initialized
INFO - 2023-12-03 22:52:50 --> URI Class Initialized
DEBUG - 2023-12-03 22:52:50 --> No URI present. Default controller set.
INFO - 2023-12-03 22:52:50 --> Router Class Initialized
INFO - 2023-12-03 22:52:50 --> Output Class Initialized
INFO - 2023-12-03 22:52:50 --> Security Class Initialized
DEBUG - 2023-12-03 22:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 22:52:50 --> Input Class Initialized
INFO - 2023-12-03 22:52:50 --> Language Class Initialized
INFO - 2023-12-03 22:52:50 --> Loader Class Initialized
INFO - 2023-12-03 22:52:50 --> Helper loaded: url_helper
INFO - 2023-12-03 22:52:50 --> Helper loaded: form_helper
INFO - 2023-12-03 22:52:50 --> Helper loaded: file_helper
INFO - 2023-12-03 22:52:50 --> Database Driver Class Initialized
DEBUG - 2023-12-03 22:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 22:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 22:52:50 --> Form Validation Class Initialized
INFO - 2023-12-03 22:52:50 --> Upload Class Initialized
INFO - 2023-12-03 22:52:50 --> Model "M_auth" initialized
INFO - 2023-12-03 22:52:50 --> Model "M_user" initialized
INFO - 2023-12-03 22:52:50 --> Model "M_produk" initialized
INFO - 2023-12-03 22:52:50 --> Controller Class Initialized
INFO - 2023-12-03 22:52:50 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 22:52:50 --> Model "M_produk" initialized
DEBUG - 2023-12-03 22:52:50 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 22:52:50 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 22:52:50 --> Model "M_transaksi" initialized
INFO - 2023-12-03 22:52:50 --> Model "M_bank" initialized
INFO - 2023-12-03 22:52:50 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 22:52:50 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 22:52:50 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 22:52:50 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 22:52:50 --> Final output sent to browser
DEBUG - 2023-12-03 22:52:50 --> Total execution time: 0.0047
ERROR - 2023-12-03 23:06:07 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 23:06:07 --> Config Class Initialized
INFO - 2023-12-03 23:06:07 --> Hooks Class Initialized
DEBUG - 2023-12-03 23:06:07 --> UTF-8 Support Enabled
INFO - 2023-12-03 23:06:07 --> Utf8 Class Initialized
INFO - 2023-12-03 23:06:07 --> URI Class Initialized
DEBUG - 2023-12-03 23:06:07 --> No URI present. Default controller set.
INFO - 2023-12-03 23:06:07 --> Router Class Initialized
INFO - 2023-12-03 23:06:07 --> Output Class Initialized
INFO - 2023-12-03 23:06:07 --> Security Class Initialized
DEBUG - 2023-12-03 23:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 23:06:07 --> Input Class Initialized
INFO - 2023-12-03 23:06:07 --> Language Class Initialized
INFO - 2023-12-03 23:06:07 --> Loader Class Initialized
INFO - 2023-12-03 23:06:07 --> Helper loaded: url_helper
INFO - 2023-12-03 23:06:07 --> Helper loaded: form_helper
INFO - 2023-12-03 23:06:07 --> Helper loaded: file_helper
INFO - 2023-12-03 23:06:07 --> Database Driver Class Initialized
DEBUG - 2023-12-03 23:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 23:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 23:06:07 --> Form Validation Class Initialized
INFO - 2023-12-03 23:06:07 --> Upload Class Initialized
INFO - 2023-12-03 23:06:07 --> Model "M_auth" initialized
INFO - 2023-12-03 23:06:07 --> Model "M_user" initialized
INFO - 2023-12-03 23:06:07 --> Model "M_produk" initialized
INFO - 2023-12-03 23:06:07 --> Controller Class Initialized
INFO - 2023-12-03 23:06:07 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 23:06:07 --> Model "M_produk" initialized
DEBUG - 2023-12-03 23:06:07 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 23:06:07 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 23:06:07 --> Model "M_transaksi" initialized
INFO - 2023-12-03 23:06:07 --> Model "M_bank" initialized
INFO - 2023-12-03 23:06:07 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 23:06:07 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 23:06:07 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 23:06:07 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 23:06:07 --> Final output sent to browser
DEBUG - 2023-12-03 23:06:07 --> Total execution time: 0.0325
ERROR - 2023-12-03 23:49:12 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 23:49:12 --> Config Class Initialized
INFO - 2023-12-03 23:49:12 --> Hooks Class Initialized
DEBUG - 2023-12-03 23:49:12 --> UTF-8 Support Enabled
INFO - 2023-12-03 23:49:12 --> Utf8 Class Initialized
INFO - 2023-12-03 23:49:12 --> URI Class Initialized
DEBUG - 2023-12-03 23:49:12 --> No URI present. Default controller set.
INFO - 2023-12-03 23:49:12 --> Router Class Initialized
INFO - 2023-12-03 23:49:12 --> Output Class Initialized
INFO - 2023-12-03 23:49:12 --> Security Class Initialized
DEBUG - 2023-12-03 23:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 23:49:12 --> Input Class Initialized
INFO - 2023-12-03 23:49:12 --> Language Class Initialized
INFO - 2023-12-03 23:49:12 --> Loader Class Initialized
INFO - 2023-12-03 23:49:12 --> Helper loaded: url_helper
INFO - 2023-12-03 23:49:12 --> Helper loaded: form_helper
INFO - 2023-12-03 23:49:12 --> Helper loaded: file_helper
INFO - 2023-12-03 23:49:12 --> Database Driver Class Initialized
DEBUG - 2023-12-03 23:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 23:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 23:49:12 --> Form Validation Class Initialized
INFO - 2023-12-03 23:49:12 --> Upload Class Initialized
INFO - 2023-12-03 23:49:12 --> Model "M_auth" initialized
INFO - 2023-12-03 23:49:12 --> Model "M_user" initialized
INFO - 2023-12-03 23:49:12 --> Model "M_produk" initialized
INFO - 2023-12-03 23:49:12 --> Controller Class Initialized
INFO - 2023-12-03 23:49:12 --> Model "M_pelanggan" initialized
INFO - 2023-12-03 23:49:12 --> Model "M_produk" initialized
DEBUG - 2023-12-03 23:49:12 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-03 23:49:12 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-03 23:49:12 --> Model "M_transaksi" initialized
INFO - 2023-12-03 23:49:12 --> Model "M_bank" initialized
INFO - 2023-12-03 23:49:12 --> Model "M_pesan" initialized
DEBUG - 2023-12-03 23:49:12 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-03 23:49:12 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-03 23:49:12 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-03 23:49:12 --> Final output sent to browser
DEBUG - 2023-12-03 23:49:12 --> Total execution time: 0.0313
ERROR - 2023-12-03 23:55:30 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 23:55:30 --> Config Class Initialized
INFO - 2023-12-03 23:55:30 --> Hooks Class Initialized
DEBUG - 2023-12-03 23:55:30 --> UTF-8 Support Enabled
INFO - 2023-12-03 23:55:30 --> Utf8 Class Initialized
INFO - 2023-12-03 23:55:30 --> URI Class Initialized
INFO - 2023-12-03 23:55:30 --> Router Class Initialized
INFO - 2023-12-03 23:55:30 --> Output Class Initialized
INFO - 2023-12-03 23:55:30 --> Security Class Initialized
DEBUG - 2023-12-03 23:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 23:55:30 --> Input Class Initialized
INFO - 2023-12-03 23:55:30 --> Language Class Initialized
INFO - 2023-12-03 23:55:30 --> Loader Class Initialized
INFO - 2023-12-03 23:55:30 --> Helper loaded: url_helper
INFO - 2023-12-03 23:55:30 --> Helper loaded: form_helper
INFO - 2023-12-03 23:55:30 --> Helper loaded: file_helper
INFO - 2023-12-03 23:55:31 --> Database Driver Class Initialized
DEBUG - 2023-12-03 23:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 23:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 23:55:31 --> Form Validation Class Initialized
INFO - 2023-12-03 23:55:31 --> Upload Class Initialized
INFO - 2023-12-03 23:55:31 --> Model "M_auth" initialized
INFO - 2023-12-03 23:55:31 --> Model "M_user" initialized
INFO - 2023-12-03 23:55:31 --> Model "M_produk" initialized
INFO - 2023-12-03 23:55:31 --> Controller Class Initialized
INFO - 2023-12-03 23:55:31 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-03 23:55:31 --> Final output sent to browser
DEBUG - 2023-12-03 23:55:31 --> Total execution time: 0.0264
ERROR - 2023-12-03 23:55:31 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-03 23:55:31 --> Config Class Initialized
INFO - 2023-12-03 23:55:31 --> Hooks Class Initialized
DEBUG - 2023-12-03 23:55:31 --> UTF-8 Support Enabled
INFO - 2023-12-03 23:55:31 --> Utf8 Class Initialized
INFO - 2023-12-03 23:55:31 --> URI Class Initialized
INFO - 2023-12-03 23:55:31 --> Router Class Initialized
INFO - 2023-12-03 23:55:31 --> Output Class Initialized
INFO - 2023-12-03 23:55:31 --> Security Class Initialized
DEBUG - 2023-12-03 23:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-03 23:55:31 --> Input Class Initialized
INFO - 2023-12-03 23:55:31 --> Language Class Initialized
INFO - 2023-12-03 23:55:31 --> Loader Class Initialized
INFO - 2023-12-03 23:55:31 --> Helper loaded: url_helper
INFO - 2023-12-03 23:55:31 --> Helper loaded: form_helper
INFO - 2023-12-03 23:55:31 --> Helper loaded: file_helper
INFO - 2023-12-03 23:55:31 --> Database Driver Class Initialized
DEBUG - 2023-12-03 23:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-03 23:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-03 23:55:31 --> Form Validation Class Initialized
INFO - 2023-12-03 23:55:31 --> Upload Class Initialized
INFO - 2023-12-03 23:55:31 --> Model "M_auth" initialized
INFO - 2023-12-03 23:55:31 --> Model "M_user" initialized
INFO - 2023-12-03 23:55:31 --> Model "M_produk" initialized
INFO - 2023-12-03 23:55:31 --> Controller Class Initialized
INFO - 2023-12-03 23:55:31 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-03 23:55:31 --> Final output sent to browser
DEBUG - 2023-12-03 23:55:31 --> Total execution time: 0.0020
