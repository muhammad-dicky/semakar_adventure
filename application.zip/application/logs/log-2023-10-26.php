<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-10-26 00:26:22 --> Config Class Initialized
INFO - 2023-10-26 00:26:22 --> Hooks Class Initialized
DEBUG - 2023-10-26 00:26:22 --> UTF-8 Support Enabled
INFO - 2023-10-26 00:26:22 --> Utf8 Class Initialized
INFO - 2023-10-26 00:26:22 --> URI Class Initialized
DEBUG - 2023-10-26 00:26:22 --> No URI present. Default controller set.
INFO - 2023-10-26 00:26:22 --> Router Class Initialized
INFO - 2023-10-26 00:26:22 --> Output Class Initialized
INFO - 2023-10-26 00:26:22 --> Security Class Initialized
DEBUG - 2023-10-26 00:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 00:26:22 --> Input Class Initialized
INFO - 2023-10-26 00:26:22 --> Language Class Initialized
INFO - 2023-10-26 00:26:22 --> Loader Class Initialized
INFO - 2023-10-26 00:26:22 --> Helper loaded: url_helper
INFO - 2023-10-26 00:26:22 --> Helper loaded: form_helper
INFO - 2023-10-26 00:26:22 --> Helper loaded: file_helper
INFO - 2023-10-26 00:26:22 --> Database Driver Class Initialized
DEBUG - 2023-10-26 00:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-26 00:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 00:26:22 --> Form Validation Class Initialized
INFO - 2023-10-26 00:26:22 --> Upload Class Initialized
INFO - 2023-10-26 00:26:22 --> Model "M_auth" initialized
INFO - 2023-10-26 00:26:22 --> Model "M_user" initialized
INFO - 2023-10-26 00:26:23 --> Model "M_produk" initialized
INFO - 2023-10-26 00:26:23 --> Controller Class Initialized
INFO - 2023-10-26 00:26:23 --> Model "M_pelanggan" initialized
INFO - 2023-10-26 00:26:23 --> Model "M_produk" initialized
DEBUG - 2023-10-26 00:26:23 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-26 00:26:23 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-26 00:26:23 --> Model "M_transaksi" initialized
INFO - 2023-10-26 00:26:23 --> Model "M_bank" initialized
INFO - 2023-10-26 00:26:23 --> Model "M_pesan" initialized
INFO - 2023-10-26 00:26:23 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-26 00:26:23 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-26 00:26:23 --> Final output sent to browser
DEBUG - 2023-10-26 00:26:23 --> Total execution time: 0.4630
INFO - 2023-10-26 00:26:30 --> Config Class Initialized
INFO - 2023-10-26 00:26:30 --> Hooks Class Initialized
DEBUG - 2023-10-26 00:26:30 --> UTF-8 Support Enabled
INFO - 2023-10-26 00:26:30 --> Utf8 Class Initialized
INFO - 2023-10-26 00:26:30 --> URI Class Initialized
INFO - 2023-10-26 00:26:30 --> Router Class Initialized
INFO - 2023-10-26 00:26:30 --> Output Class Initialized
INFO - 2023-10-26 00:26:30 --> Security Class Initialized
DEBUG - 2023-10-26 00:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 00:26:30 --> Input Class Initialized
INFO - 2023-10-26 00:26:30 --> Language Class Initialized
INFO - 2023-10-26 00:26:30 --> Loader Class Initialized
INFO - 2023-10-26 00:26:30 --> Helper loaded: url_helper
INFO - 2023-10-26 00:26:30 --> Helper loaded: form_helper
INFO - 2023-10-26 00:26:30 --> Helper loaded: file_helper
INFO - 2023-10-26 00:26:30 --> Database Driver Class Initialized
DEBUG - 2023-10-26 00:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-26 00:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 00:26:30 --> Form Validation Class Initialized
INFO - 2023-10-26 00:26:30 --> Upload Class Initialized
INFO - 2023-10-26 00:26:30 --> Model "M_auth" initialized
INFO - 2023-10-26 00:26:30 --> Model "M_user" initialized
INFO - 2023-10-26 00:26:30 --> Model "M_produk" initialized
INFO - 2023-10-26 00:26:30 --> Controller Class Initialized
INFO - 2023-10-26 00:26:30 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-10-26 00:26:30 --> Final output sent to browser
DEBUG - 2023-10-26 00:26:30 --> Total execution time: 0.1027
INFO - 2023-10-26 00:26:34 --> Config Class Initialized
INFO - 2023-10-26 00:26:34 --> Hooks Class Initialized
DEBUG - 2023-10-26 00:26:34 --> UTF-8 Support Enabled
INFO - 2023-10-26 00:26:34 --> Utf8 Class Initialized
INFO - 2023-10-26 00:26:34 --> URI Class Initialized
INFO - 2023-10-26 00:26:34 --> Router Class Initialized
INFO - 2023-10-26 00:26:34 --> Output Class Initialized
INFO - 2023-10-26 00:26:34 --> Security Class Initialized
DEBUG - 2023-10-26 00:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 00:26:34 --> Input Class Initialized
INFO - 2023-10-26 00:26:34 --> Language Class Initialized
INFO - 2023-10-26 00:26:34 --> Loader Class Initialized
INFO - 2023-10-26 00:26:34 --> Helper loaded: url_helper
INFO - 2023-10-26 00:26:34 --> Helper loaded: form_helper
INFO - 2023-10-26 00:26:34 --> Helper loaded: file_helper
INFO - 2023-10-26 00:26:34 --> Database Driver Class Initialized
DEBUG - 2023-10-26 00:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-26 00:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 00:26:34 --> Form Validation Class Initialized
INFO - 2023-10-26 00:26:34 --> Upload Class Initialized
INFO - 2023-10-26 00:26:34 --> Model "M_auth" initialized
INFO - 2023-10-26 00:26:34 --> Model "M_user" initialized
INFO - 2023-10-26 00:26:34 --> Model "M_produk" initialized
INFO - 2023-10-26 00:26:34 --> Controller Class Initialized
INFO - 2023-10-26 00:26:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-10-26 00:26:34 --> Config Class Initialized
INFO - 2023-10-26 00:26:34 --> Hooks Class Initialized
DEBUG - 2023-10-26 00:26:34 --> UTF-8 Support Enabled
INFO - 2023-10-26 00:26:34 --> Utf8 Class Initialized
INFO - 2023-10-26 00:26:34 --> URI Class Initialized
INFO - 2023-10-26 00:26:34 --> Router Class Initialized
INFO - 2023-10-26 00:26:34 --> Output Class Initialized
INFO - 2023-10-26 00:26:34 --> Security Class Initialized
DEBUG - 2023-10-26 00:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 00:26:34 --> Input Class Initialized
INFO - 2023-10-26 00:26:34 --> Language Class Initialized
INFO - 2023-10-26 00:26:34 --> Loader Class Initialized
INFO - 2023-10-26 00:26:34 --> Helper loaded: url_helper
INFO - 2023-10-26 00:26:34 --> Helper loaded: form_helper
INFO - 2023-10-26 00:26:34 --> Helper loaded: file_helper
INFO - 2023-10-26 00:26:34 --> Database Driver Class Initialized
DEBUG - 2023-10-26 00:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-26 00:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 00:26:34 --> Form Validation Class Initialized
INFO - 2023-10-26 00:26:34 --> Upload Class Initialized
INFO - 2023-10-26 00:26:34 --> Model "M_auth" initialized
INFO - 2023-10-26 00:26:34 --> Model "M_user" initialized
INFO - 2023-10-26 00:26:34 --> Model "M_produk" initialized
INFO - 2023-10-26 00:26:34 --> Controller Class Initialized
INFO - 2023-10-26 00:26:34 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-10-26 00:26:34 --> Final output sent to browser
DEBUG - 2023-10-26 00:26:34 --> Total execution time: 0.0457
INFO - 2023-10-26 00:26:37 --> Config Class Initialized
INFO - 2023-10-26 00:26:37 --> Hooks Class Initialized
DEBUG - 2023-10-26 00:26:37 --> UTF-8 Support Enabled
INFO - 2023-10-26 00:26:37 --> Utf8 Class Initialized
INFO - 2023-10-26 00:26:37 --> URI Class Initialized
INFO - 2023-10-26 00:26:37 --> Router Class Initialized
INFO - 2023-10-26 00:26:37 --> Output Class Initialized
INFO - 2023-10-26 00:26:37 --> Security Class Initialized
DEBUG - 2023-10-26 00:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 00:26:37 --> Input Class Initialized
INFO - 2023-10-26 00:26:37 --> Language Class Initialized
INFO - 2023-10-26 00:26:37 --> Loader Class Initialized
INFO - 2023-10-26 00:26:37 --> Helper loaded: url_helper
INFO - 2023-10-26 00:26:37 --> Helper loaded: form_helper
INFO - 2023-10-26 00:26:37 --> Helper loaded: file_helper
INFO - 2023-10-26 00:26:37 --> Database Driver Class Initialized
DEBUG - 2023-10-26 00:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-26 00:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 00:26:37 --> Form Validation Class Initialized
INFO - 2023-10-26 00:26:37 --> Upload Class Initialized
INFO - 2023-10-26 00:26:37 --> Model "M_auth" initialized
INFO - 2023-10-26 00:26:37 --> Model "M_user" initialized
INFO - 2023-10-26 00:26:37 --> Model "M_produk" initialized
INFO - 2023-10-26 00:26:37 --> Controller Class Initialized
INFO - 2023-10-26 00:26:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-10-26 00:26:37 --> Config Class Initialized
INFO - 2023-10-26 00:26:37 --> Hooks Class Initialized
DEBUG - 2023-10-26 00:26:37 --> UTF-8 Support Enabled
INFO - 2023-10-26 00:26:37 --> Utf8 Class Initialized
INFO - 2023-10-26 00:26:37 --> URI Class Initialized
INFO - 2023-10-26 00:26:37 --> Router Class Initialized
INFO - 2023-10-26 00:26:37 --> Output Class Initialized
INFO - 2023-10-26 00:26:37 --> Security Class Initialized
DEBUG - 2023-10-26 00:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 00:26:37 --> Input Class Initialized
INFO - 2023-10-26 00:26:37 --> Language Class Initialized
INFO - 2023-10-26 00:26:37 --> Loader Class Initialized
INFO - 2023-10-26 00:26:37 --> Helper loaded: url_helper
INFO - 2023-10-26 00:26:37 --> Helper loaded: form_helper
INFO - 2023-10-26 00:26:37 --> Helper loaded: file_helper
INFO - 2023-10-26 00:26:37 --> Database Driver Class Initialized
DEBUG - 2023-10-26 00:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-26 00:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 00:26:37 --> Form Validation Class Initialized
INFO - 2023-10-26 00:26:37 --> Upload Class Initialized
INFO - 2023-10-26 00:26:37 --> Model "M_auth" initialized
INFO - 2023-10-26 00:26:37 --> Model "M_user" initialized
INFO - 2023-10-26 00:26:37 --> Model "M_produk" initialized
INFO - 2023-10-26 00:26:37 --> Controller Class Initialized
INFO - 2023-10-26 00:26:37 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-10-26 00:26:37 --> Final output sent to browser
DEBUG - 2023-10-26 00:26:37 --> Total execution time: 0.0406
INFO - 2023-10-26 00:28:11 --> Config Class Initialized
INFO - 2023-10-26 00:28:11 --> Hooks Class Initialized
DEBUG - 2023-10-26 00:28:11 --> UTF-8 Support Enabled
INFO - 2023-10-26 00:28:11 --> Utf8 Class Initialized
INFO - 2023-10-26 00:28:11 --> URI Class Initialized
INFO - 2023-10-26 00:28:11 --> Router Class Initialized
INFO - 2023-10-26 00:28:11 --> Output Class Initialized
INFO - 2023-10-26 00:28:11 --> Security Class Initialized
DEBUG - 2023-10-26 00:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 00:28:11 --> Input Class Initialized
INFO - 2023-10-26 00:28:11 --> Language Class Initialized
INFO - 2023-10-26 00:28:11 --> Loader Class Initialized
INFO - 2023-10-26 00:28:11 --> Helper loaded: url_helper
INFO - 2023-10-26 00:28:11 --> Helper loaded: form_helper
INFO - 2023-10-26 00:28:11 --> Helper loaded: file_helper
INFO - 2023-10-26 00:28:11 --> Database Driver Class Initialized
DEBUG - 2023-10-26 00:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-26 00:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 00:28:11 --> Form Validation Class Initialized
INFO - 2023-10-26 00:28:11 --> Upload Class Initialized
INFO - 2023-10-26 00:28:11 --> Model "M_auth" initialized
INFO - 2023-10-26 00:28:11 --> Model "M_user" initialized
INFO - 2023-10-26 00:28:11 --> Model "M_produk" initialized
INFO - 2023-10-26 00:28:11 --> Controller Class Initialized
INFO - 2023-10-26 00:28:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-10-26 00:28:11 --> Config Class Initialized
INFO - 2023-10-26 00:28:11 --> Hooks Class Initialized
DEBUG - 2023-10-26 00:28:11 --> UTF-8 Support Enabled
INFO - 2023-10-26 00:28:11 --> Utf8 Class Initialized
INFO - 2023-10-26 00:28:11 --> URI Class Initialized
INFO - 2023-10-26 00:28:11 --> Router Class Initialized
INFO - 2023-10-26 00:28:11 --> Output Class Initialized
INFO - 2023-10-26 00:28:11 --> Security Class Initialized
DEBUG - 2023-10-26 00:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 00:28:11 --> Input Class Initialized
INFO - 2023-10-26 00:28:11 --> Language Class Initialized
INFO - 2023-10-26 00:28:11 --> Loader Class Initialized
INFO - 2023-10-26 00:28:11 --> Helper loaded: url_helper
INFO - 2023-10-26 00:28:11 --> Helper loaded: form_helper
INFO - 2023-10-26 00:28:11 --> Helper loaded: file_helper
INFO - 2023-10-26 00:28:11 --> Database Driver Class Initialized
DEBUG - 2023-10-26 00:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-26 00:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 00:28:11 --> Form Validation Class Initialized
INFO - 2023-10-26 00:28:11 --> Upload Class Initialized
INFO - 2023-10-26 00:28:11 --> Model "M_auth" initialized
INFO - 2023-10-26 00:28:11 --> Model "M_user" initialized
INFO - 2023-10-26 00:28:11 --> Model "M_produk" initialized
INFO - 2023-10-26 00:28:11 --> Controller Class Initialized
INFO - 2023-10-26 00:28:11 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-10-26 00:28:12 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-26 00:28:12 --> Final output sent to browser
DEBUG - 2023-10-26 00:28:12 --> Total execution time: 0.1070
INFO - 2023-10-26 00:28:17 --> Config Class Initialized
INFO - 2023-10-26 00:28:17 --> Hooks Class Initialized
DEBUG - 2023-10-26 00:28:17 --> UTF-8 Support Enabled
INFO - 2023-10-26 00:28:17 --> Utf8 Class Initialized
INFO - 2023-10-26 00:28:17 --> URI Class Initialized
INFO - 2023-10-26 00:28:17 --> Router Class Initialized
INFO - 2023-10-26 00:28:17 --> Output Class Initialized
INFO - 2023-10-26 00:28:17 --> Security Class Initialized
DEBUG - 2023-10-26 00:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 00:28:17 --> Input Class Initialized
INFO - 2023-10-26 00:28:17 --> Language Class Initialized
INFO - 2023-10-26 00:28:17 --> Loader Class Initialized
INFO - 2023-10-26 00:28:17 --> Helper loaded: url_helper
INFO - 2023-10-26 00:28:17 --> Helper loaded: form_helper
INFO - 2023-10-26 00:28:17 --> Helper loaded: file_helper
INFO - 2023-10-26 00:28:17 --> Database Driver Class Initialized
DEBUG - 2023-10-26 00:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-26 00:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 00:28:17 --> Form Validation Class Initialized
INFO - 2023-10-26 00:28:17 --> Upload Class Initialized
INFO - 2023-10-26 00:28:17 --> Model "M_auth" initialized
INFO - 2023-10-26 00:28:17 --> Model "M_user" initialized
INFO - 2023-10-26 00:28:17 --> Model "M_produk" initialized
INFO - 2023-10-26 00:28:17 --> Controller Class Initialized
INFO - 2023-10-26 00:28:17 --> Config Class Initialized
INFO - 2023-10-26 00:28:17 --> Hooks Class Initialized
DEBUG - 2023-10-26 00:28:17 --> UTF-8 Support Enabled
INFO - 2023-10-26 00:28:17 --> Utf8 Class Initialized
INFO - 2023-10-26 00:28:17 --> URI Class Initialized
INFO - 2023-10-26 00:28:17 --> Router Class Initialized
INFO - 2023-10-26 00:28:17 --> Output Class Initialized
INFO - 2023-10-26 00:28:17 --> Security Class Initialized
DEBUG - 2023-10-26 00:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 00:28:17 --> Input Class Initialized
INFO - 2023-10-26 00:28:17 --> Language Class Initialized
INFO - 2023-10-26 00:28:17 --> Loader Class Initialized
INFO - 2023-10-26 00:28:17 --> Helper loaded: url_helper
INFO - 2023-10-26 00:28:17 --> Helper loaded: form_helper
INFO - 2023-10-26 00:28:17 --> Helper loaded: file_helper
INFO - 2023-10-26 00:28:17 --> Database Driver Class Initialized
DEBUG - 2023-10-26 00:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-26 00:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 00:28:17 --> Form Validation Class Initialized
INFO - 2023-10-26 00:28:17 --> Upload Class Initialized
INFO - 2023-10-26 00:28:17 --> Model "M_auth" initialized
INFO - 2023-10-26 00:28:17 --> Model "M_user" initialized
INFO - 2023-10-26 00:28:17 --> Model "M_produk" initialized
INFO - 2023-10-26 00:28:17 --> Controller Class Initialized
INFO - 2023-10-26 00:28:17 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-10-26 00:28:17 --> Final output sent to browser
DEBUG - 2023-10-26 00:28:17 --> Total execution time: 0.0201
INFO - 2023-10-26 00:28:24 --> Config Class Initialized
INFO - 2023-10-26 00:28:24 --> Hooks Class Initialized
DEBUG - 2023-10-26 00:28:24 --> UTF-8 Support Enabled
INFO - 2023-10-26 00:28:24 --> Utf8 Class Initialized
INFO - 2023-10-26 00:28:24 --> URI Class Initialized
INFO - 2023-10-26 00:28:24 --> Router Class Initialized
INFO - 2023-10-26 00:28:24 --> Output Class Initialized
INFO - 2023-10-26 00:28:24 --> Security Class Initialized
DEBUG - 2023-10-26 00:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 00:28:24 --> Input Class Initialized
INFO - 2023-10-26 00:28:24 --> Language Class Initialized
INFO - 2023-10-26 00:28:24 --> Loader Class Initialized
INFO - 2023-10-26 00:28:24 --> Helper loaded: url_helper
INFO - 2023-10-26 00:28:24 --> Helper loaded: form_helper
INFO - 2023-10-26 00:28:24 --> Helper loaded: file_helper
INFO - 2023-10-26 00:28:24 --> Database Driver Class Initialized
DEBUG - 2023-10-26 00:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-26 00:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 00:28:24 --> Form Validation Class Initialized
INFO - 2023-10-26 00:28:24 --> Upload Class Initialized
INFO - 2023-10-26 00:28:24 --> Model "M_auth" initialized
INFO - 2023-10-26 00:28:24 --> Model "M_user" initialized
INFO - 2023-10-26 00:28:24 --> Model "M_produk" initialized
INFO - 2023-10-26 00:28:24 --> Controller Class Initialized
INFO - 2023-10-26 00:28:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-10-26 00:28:24 --> Config Class Initialized
INFO - 2023-10-26 00:28:24 --> Hooks Class Initialized
DEBUG - 2023-10-26 00:28:24 --> UTF-8 Support Enabled
INFO - 2023-10-26 00:28:24 --> Utf8 Class Initialized
INFO - 2023-10-26 00:28:24 --> URI Class Initialized
INFO - 2023-10-26 00:28:24 --> Router Class Initialized
INFO - 2023-10-26 00:28:24 --> Output Class Initialized
INFO - 2023-10-26 00:28:24 --> Security Class Initialized
DEBUG - 2023-10-26 00:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 00:28:24 --> Input Class Initialized
INFO - 2023-10-26 00:28:24 --> Language Class Initialized
INFO - 2023-10-26 00:28:24 --> Loader Class Initialized
INFO - 2023-10-26 00:28:24 --> Helper loaded: url_helper
INFO - 2023-10-26 00:28:24 --> Helper loaded: form_helper
INFO - 2023-10-26 00:28:24 --> Helper loaded: file_helper
INFO - 2023-10-26 00:28:24 --> Database Driver Class Initialized
DEBUG - 2023-10-26 00:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-26 00:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 00:28:24 --> Form Validation Class Initialized
INFO - 2023-10-26 00:28:24 --> Upload Class Initialized
INFO - 2023-10-26 00:28:24 --> Model "M_auth" initialized
INFO - 2023-10-26 00:28:24 --> Model "M_user" initialized
INFO - 2023-10-26 00:28:24 --> Model "M_produk" initialized
INFO - 2023-10-26 00:28:24 --> Controller Class Initialized
INFO - 2023-10-26 00:28:24 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-10-26 00:28:24 --> Final output sent to browser
DEBUG - 2023-10-26 00:28:24 --> Total execution time: 0.0631
INFO - 2023-10-26 00:28:31 --> Config Class Initialized
INFO - 2023-10-26 00:28:31 --> Hooks Class Initialized
DEBUG - 2023-10-26 00:28:31 --> UTF-8 Support Enabled
INFO - 2023-10-26 00:28:31 --> Utf8 Class Initialized
INFO - 2023-10-26 00:28:31 --> URI Class Initialized
INFO - 2023-10-26 00:28:31 --> Router Class Initialized
INFO - 2023-10-26 00:28:31 --> Output Class Initialized
INFO - 2023-10-26 00:28:31 --> Security Class Initialized
DEBUG - 2023-10-26 00:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 00:28:31 --> Input Class Initialized
INFO - 2023-10-26 00:28:31 --> Language Class Initialized
INFO - 2023-10-26 00:28:31 --> Loader Class Initialized
INFO - 2023-10-26 00:28:31 --> Helper loaded: url_helper
INFO - 2023-10-26 00:28:31 --> Helper loaded: form_helper
INFO - 2023-10-26 00:28:31 --> Helper loaded: file_helper
INFO - 2023-10-26 00:28:31 --> Database Driver Class Initialized
DEBUG - 2023-10-26 00:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-26 00:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 00:28:31 --> Form Validation Class Initialized
INFO - 2023-10-26 00:28:31 --> Upload Class Initialized
INFO - 2023-10-26 00:28:31 --> Model "M_auth" initialized
INFO - 2023-10-26 00:28:31 --> Model "M_user" initialized
INFO - 2023-10-26 00:28:31 --> Model "M_produk" initialized
INFO - 2023-10-26 00:28:31 --> Controller Class Initialized
INFO - 2023-10-26 00:28:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-10-26 00:28:31 --> Config Class Initialized
INFO - 2023-10-26 00:28:31 --> Hooks Class Initialized
DEBUG - 2023-10-26 00:28:31 --> UTF-8 Support Enabled
INFO - 2023-10-26 00:28:31 --> Utf8 Class Initialized
INFO - 2023-10-26 00:28:31 --> URI Class Initialized
INFO - 2023-10-26 00:28:31 --> Router Class Initialized
INFO - 2023-10-26 00:28:31 --> Output Class Initialized
INFO - 2023-10-26 00:28:31 --> Security Class Initialized
DEBUG - 2023-10-26 00:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 00:28:31 --> Input Class Initialized
INFO - 2023-10-26 00:28:31 --> Language Class Initialized
INFO - 2023-10-26 00:28:31 --> Loader Class Initialized
INFO - 2023-10-26 00:28:31 --> Helper loaded: url_helper
INFO - 2023-10-26 00:28:31 --> Helper loaded: form_helper
INFO - 2023-10-26 00:28:31 --> Helper loaded: file_helper
INFO - 2023-10-26 00:28:31 --> Database Driver Class Initialized
DEBUG - 2023-10-26 00:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-26 00:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 00:28:31 --> Form Validation Class Initialized
INFO - 2023-10-26 00:28:31 --> Upload Class Initialized
INFO - 2023-10-26 00:28:31 --> Model "M_auth" initialized
INFO - 2023-10-26 00:28:31 --> Model "M_user" initialized
INFO - 2023-10-26 00:28:31 --> Model "M_produk" initialized
INFO - 2023-10-26 00:28:31 --> Controller Class Initialized
INFO - 2023-10-26 00:28:31 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-10-26 00:28:31 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-26 00:28:31 --> Final output sent to browser
DEBUG - 2023-10-26 00:28:31 --> Total execution time: 0.0331
INFO - 2023-10-26 13:34:02 --> Config Class Initialized
INFO - 2023-10-26 13:34:02 --> Hooks Class Initialized
DEBUG - 2023-10-26 13:34:02 --> UTF-8 Support Enabled
INFO - 2023-10-26 13:34:02 --> Utf8 Class Initialized
INFO - 2023-10-26 13:34:02 --> URI Class Initialized
DEBUG - 2023-10-26 13:34:02 --> No URI present. Default controller set.
INFO - 2023-10-26 13:34:02 --> Router Class Initialized
INFO - 2023-10-26 13:34:02 --> Output Class Initialized
INFO - 2023-10-26 13:34:02 --> Security Class Initialized
DEBUG - 2023-10-26 13:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 13:34:02 --> Input Class Initialized
INFO - 2023-10-26 13:34:02 --> Language Class Initialized
INFO - 2023-10-26 13:34:02 --> Loader Class Initialized
INFO - 2023-10-26 13:34:02 --> Helper loaded: url_helper
INFO - 2023-10-26 13:34:02 --> Helper loaded: form_helper
INFO - 2023-10-26 13:34:02 --> Helper loaded: file_helper
INFO - 2023-10-26 13:34:02 --> Database Driver Class Initialized
DEBUG - 2023-10-26 13:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-26 13:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 13:34:02 --> Form Validation Class Initialized
INFO - 2023-10-26 13:34:02 --> Upload Class Initialized
INFO - 2023-10-26 13:34:02 --> Model "M_auth" initialized
INFO - 2023-10-26 13:34:02 --> Model "M_user" initialized
INFO - 2023-10-26 13:34:02 --> Model "M_produk" initialized
INFO - 2023-10-26 13:34:02 --> Controller Class Initialized
INFO - 2023-10-26 13:34:02 --> Model "M_pelanggan" initialized
INFO - 2023-10-26 13:34:02 --> Model "M_produk" initialized
DEBUG - 2023-10-26 13:34:02 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-26 13:34:02 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-26 13:34:02 --> Model "M_transaksi" initialized
INFO - 2023-10-26 13:34:02 --> Model "M_bank" initialized
INFO - 2023-10-26 13:34:02 --> Model "M_pesan" initialized
INFO - 2023-10-26 13:34:02 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-26 13:34:02 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-26 13:34:02 --> Final output sent to browser
DEBUG - 2023-10-26 13:34:02 --> Total execution time: 0.4296
INFO - 2023-10-26 13:34:07 --> Config Class Initialized
INFO - 2023-10-26 13:34:07 --> Hooks Class Initialized
DEBUG - 2023-10-26 13:34:07 --> UTF-8 Support Enabled
INFO - 2023-10-26 13:34:07 --> Utf8 Class Initialized
INFO - 2023-10-26 13:34:07 --> URI Class Initialized
INFO - 2023-10-26 13:34:07 --> Router Class Initialized
INFO - 2023-10-26 13:34:07 --> Output Class Initialized
INFO - 2023-10-26 13:34:07 --> Security Class Initialized
DEBUG - 2023-10-26 13:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 13:34:07 --> Input Class Initialized
INFO - 2023-10-26 13:34:07 --> Language Class Initialized
INFO - 2023-10-26 13:34:07 --> Loader Class Initialized
INFO - 2023-10-26 13:34:07 --> Helper loaded: url_helper
INFO - 2023-10-26 13:34:07 --> Helper loaded: form_helper
INFO - 2023-10-26 13:34:07 --> Helper loaded: file_helper
INFO - 2023-10-26 13:34:07 --> Database Driver Class Initialized
DEBUG - 2023-10-26 13:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-26 13:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 13:34:07 --> Form Validation Class Initialized
INFO - 2023-10-26 13:34:07 --> Upload Class Initialized
INFO - 2023-10-26 13:34:07 --> Model "M_auth" initialized
INFO - 2023-10-26 13:34:07 --> Model "M_user" initialized
INFO - 2023-10-26 13:34:07 --> Model "M_produk" initialized
INFO - 2023-10-26 13:34:07 --> Controller Class Initialized
INFO - 2023-10-26 13:34:07 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-10-26 13:34:07 --> Final output sent to browser
DEBUG - 2023-10-26 13:34:07 --> Total execution time: 0.0730
INFO - 2023-10-26 13:34:10 --> Config Class Initialized
INFO - 2023-10-26 13:34:10 --> Hooks Class Initialized
DEBUG - 2023-10-26 13:34:10 --> UTF-8 Support Enabled
INFO - 2023-10-26 13:34:10 --> Utf8 Class Initialized
INFO - 2023-10-26 13:34:10 --> URI Class Initialized
INFO - 2023-10-26 13:34:10 --> Router Class Initialized
INFO - 2023-10-26 13:34:10 --> Output Class Initialized
INFO - 2023-10-26 13:34:10 --> Security Class Initialized
DEBUG - 2023-10-26 13:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 13:34:10 --> Input Class Initialized
INFO - 2023-10-26 13:34:10 --> Language Class Initialized
INFO - 2023-10-26 13:34:10 --> Loader Class Initialized
INFO - 2023-10-26 13:34:10 --> Helper loaded: url_helper
INFO - 2023-10-26 13:34:10 --> Helper loaded: form_helper
INFO - 2023-10-26 13:34:10 --> Helper loaded: file_helper
INFO - 2023-10-26 13:34:10 --> Database Driver Class Initialized
DEBUG - 2023-10-26 13:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-26 13:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 13:34:10 --> Form Validation Class Initialized
INFO - 2023-10-26 13:34:10 --> Upload Class Initialized
INFO - 2023-10-26 13:34:10 --> Model "M_auth" initialized
INFO - 2023-10-26 13:34:10 --> Model "M_user" initialized
INFO - 2023-10-26 13:34:10 --> Model "M_produk" initialized
INFO - 2023-10-26 13:34:10 --> Controller Class Initialized
INFO - 2023-10-26 13:34:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-10-26 13:34:10 --> Config Class Initialized
INFO - 2023-10-26 13:34:10 --> Hooks Class Initialized
DEBUG - 2023-10-26 13:34:10 --> UTF-8 Support Enabled
INFO - 2023-10-26 13:34:10 --> Utf8 Class Initialized
INFO - 2023-10-26 13:34:10 --> URI Class Initialized
INFO - 2023-10-26 13:34:10 --> Router Class Initialized
INFO - 2023-10-26 13:34:10 --> Output Class Initialized
INFO - 2023-10-26 13:34:10 --> Security Class Initialized
DEBUG - 2023-10-26 13:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 13:34:10 --> Input Class Initialized
INFO - 2023-10-26 13:34:10 --> Language Class Initialized
INFO - 2023-10-26 13:34:10 --> Loader Class Initialized
INFO - 2023-10-26 13:34:10 --> Helper loaded: url_helper
INFO - 2023-10-26 13:34:10 --> Helper loaded: form_helper
INFO - 2023-10-26 13:34:10 --> Helper loaded: file_helper
INFO - 2023-10-26 13:34:10 --> Database Driver Class Initialized
DEBUG - 2023-10-26 13:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-26 13:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 13:34:10 --> Form Validation Class Initialized
INFO - 2023-10-26 13:34:10 --> Upload Class Initialized
INFO - 2023-10-26 13:34:10 --> Model "M_auth" initialized
INFO - 2023-10-26 13:34:10 --> Model "M_user" initialized
INFO - 2023-10-26 13:34:10 --> Model "M_produk" initialized
INFO - 2023-10-26 13:34:10 --> Controller Class Initialized
INFO - 2023-10-26 13:34:10 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-10-26 13:34:10 --> Final output sent to browser
DEBUG - 2023-10-26 13:34:10 --> Total execution time: 0.0244
INFO - 2023-10-26 13:34:14 --> Config Class Initialized
INFO - 2023-10-26 13:34:14 --> Hooks Class Initialized
DEBUG - 2023-10-26 13:34:14 --> UTF-8 Support Enabled
INFO - 2023-10-26 13:34:14 --> Utf8 Class Initialized
INFO - 2023-10-26 13:34:14 --> URI Class Initialized
INFO - 2023-10-26 13:34:14 --> Router Class Initialized
INFO - 2023-10-26 13:34:14 --> Output Class Initialized
INFO - 2023-10-26 13:34:14 --> Security Class Initialized
DEBUG - 2023-10-26 13:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 13:34:14 --> Input Class Initialized
INFO - 2023-10-26 13:34:14 --> Language Class Initialized
INFO - 2023-10-26 13:34:14 --> Loader Class Initialized
INFO - 2023-10-26 13:34:14 --> Helper loaded: url_helper
INFO - 2023-10-26 13:34:14 --> Helper loaded: form_helper
INFO - 2023-10-26 13:34:14 --> Helper loaded: file_helper
INFO - 2023-10-26 13:34:14 --> Database Driver Class Initialized
DEBUG - 2023-10-26 13:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-26 13:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 13:34:14 --> Form Validation Class Initialized
INFO - 2023-10-26 13:34:14 --> Upload Class Initialized
INFO - 2023-10-26 13:34:14 --> Model "M_auth" initialized
INFO - 2023-10-26 13:34:14 --> Model "M_user" initialized
INFO - 2023-10-26 13:34:14 --> Model "M_produk" initialized
INFO - 2023-10-26 13:34:14 --> Controller Class Initialized
INFO - 2023-10-26 13:34:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-10-26 13:34:14 --> Config Class Initialized
INFO - 2023-10-26 13:34:14 --> Hooks Class Initialized
DEBUG - 2023-10-26 13:34:14 --> UTF-8 Support Enabled
INFO - 2023-10-26 13:34:14 --> Utf8 Class Initialized
INFO - 2023-10-26 13:34:14 --> URI Class Initialized
INFO - 2023-10-26 13:34:14 --> Router Class Initialized
INFO - 2023-10-26 13:34:14 --> Output Class Initialized
INFO - 2023-10-26 13:34:14 --> Security Class Initialized
DEBUG - 2023-10-26 13:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 13:34:14 --> Input Class Initialized
INFO - 2023-10-26 13:34:14 --> Language Class Initialized
INFO - 2023-10-26 13:34:14 --> Loader Class Initialized
INFO - 2023-10-26 13:34:14 --> Helper loaded: url_helper
INFO - 2023-10-26 13:34:14 --> Helper loaded: form_helper
INFO - 2023-10-26 13:34:14 --> Helper loaded: file_helper
INFO - 2023-10-26 13:34:14 --> Database Driver Class Initialized
DEBUG - 2023-10-26 13:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-26 13:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 13:34:14 --> Form Validation Class Initialized
INFO - 2023-10-26 13:34:14 --> Upload Class Initialized
INFO - 2023-10-26 13:34:14 --> Model "M_auth" initialized
INFO - 2023-10-26 13:34:14 --> Model "M_user" initialized
INFO - 2023-10-26 13:34:14 --> Model "M_produk" initialized
INFO - 2023-10-26 13:34:14 --> Controller Class Initialized
INFO - 2023-10-26 13:34:14 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-10-26 13:34:14 --> Final output sent to browser
DEBUG - 2023-10-26 13:34:14 --> Total execution time: 0.0232
INFO - 2023-10-26 13:34:19 --> Config Class Initialized
INFO - 2023-10-26 13:34:19 --> Hooks Class Initialized
DEBUG - 2023-10-26 13:34:19 --> UTF-8 Support Enabled
INFO - 2023-10-26 13:34:19 --> Utf8 Class Initialized
INFO - 2023-10-26 13:34:19 --> URI Class Initialized
INFO - 2023-10-26 13:34:19 --> Router Class Initialized
INFO - 2023-10-26 13:34:19 --> Output Class Initialized
INFO - 2023-10-26 13:34:19 --> Security Class Initialized
DEBUG - 2023-10-26 13:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 13:34:19 --> Input Class Initialized
INFO - 2023-10-26 13:34:19 --> Language Class Initialized
INFO - 2023-10-26 13:34:19 --> Loader Class Initialized
INFO - 2023-10-26 13:34:19 --> Helper loaded: url_helper
INFO - 2023-10-26 13:34:19 --> Helper loaded: form_helper
INFO - 2023-10-26 13:34:19 --> Helper loaded: file_helper
INFO - 2023-10-26 13:34:19 --> Database Driver Class Initialized
DEBUG - 2023-10-26 13:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-26 13:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 13:34:19 --> Form Validation Class Initialized
INFO - 2023-10-26 13:34:19 --> Upload Class Initialized
INFO - 2023-10-26 13:34:19 --> Model "M_auth" initialized
INFO - 2023-10-26 13:34:19 --> Model "M_user" initialized
INFO - 2023-10-26 13:34:19 --> Model "M_produk" initialized
INFO - 2023-10-26 13:34:19 --> Controller Class Initialized
INFO - 2023-10-26 13:34:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-10-26 13:34:19 --> Config Class Initialized
INFO - 2023-10-26 13:34:19 --> Hooks Class Initialized
DEBUG - 2023-10-26 13:34:19 --> UTF-8 Support Enabled
INFO - 2023-10-26 13:34:19 --> Utf8 Class Initialized
INFO - 2023-10-26 13:34:19 --> URI Class Initialized
INFO - 2023-10-26 13:34:19 --> Router Class Initialized
INFO - 2023-10-26 13:34:19 --> Output Class Initialized
INFO - 2023-10-26 13:34:19 --> Security Class Initialized
DEBUG - 2023-10-26 13:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 13:34:19 --> Input Class Initialized
INFO - 2023-10-26 13:34:19 --> Language Class Initialized
INFO - 2023-10-26 13:34:19 --> Loader Class Initialized
INFO - 2023-10-26 13:34:19 --> Helper loaded: url_helper
INFO - 2023-10-26 13:34:19 --> Helper loaded: form_helper
INFO - 2023-10-26 13:34:19 --> Helper loaded: file_helper
INFO - 2023-10-26 13:34:19 --> Database Driver Class Initialized
DEBUG - 2023-10-26 13:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-26 13:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 13:34:19 --> Form Validation Class Initialized
INFO - 2023-10-26 13:34:19 --> Upload Class Initialized
INFO - 2023-10-26 13:34:19 --> Model "M_auth" initialized
INFO - 2023-10-26 13:34:19 --> Model "M_user" initialized
INFO - 2023-10-26 13:34:19 --> Model "M_produk" initialized
INFO - 2023-10-26 13:34:19 --> Controller Class Initialized
INFO - 2023-10-26 13:34:19 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-10-26 13:34:19 --> Final output sent to browser
DEBUG - 2023-10-26 13:34:19 --> Total execution time: 0.0369
INFO - 2023-10-26 13:34:52 --> Config Class Initialized
INFO - 2023-10-26 13:34:52 --> Hooks Class Initialized
DEBUG - 2023-10-26 13:34:52 --> UTF-8 Support Enabled
INFO - 2023-10-26 13:34:52 --> Utf8 Class Initialized
INFO - 2023-10-26 13:34:52 --> URI Class Initialized
INFO - 2023-10-26 13:34:52 --> Router Class Initialized
INFO - 2023-10-26 13:34:52 --> Output Class Initialized
INFO - 2023-10-26 13:34:52 --> Security Class Initialized
DEBUG - 2023-10-26 13:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 13:34:52 --> Input Class Initialized
INFO - 2023-10-26 13:34:52 --> Language Class Initialized
INFO - 2023-10-26 13:34:52 --> Loader Class Initialized
INFO - 2023-10-26 13:34:52 --> Helper loaded: url_helper
INFO - 2023-10-26 13:34:52 --> Helper loaded: form_helper
INFO - 2023-10-26 13:34:52 --> Helper loaded: file_helper
INFO - 2023-10-26 13:34:52 --> Database Driver Class Initialized
DEBUG - 2023-10-26 13:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-26 13:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 13:34:52 --> Form Validation Class Initialized
INFO - 2023-10-26 13:34:52 --> Upload Class Initialized
INFO - 2023-10-26 13:34:52 --> Model "M_auth" initialized
INFO - 2023-10-26 13:34:52 --> Model "M_user" initialized
INFO - 2023-10-26 13:34:52 --> Model "M_produk" initialized
INFO - 2023-10-26 13:34:52 --> Controller Class Initialized
INFO - 2023-10-26 13:34:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-10-26 13:34:52 --> Config Class Initialized
INFO - 2023-10-26 13:34:52 --> Hooks Class Initialized
DEBUG - 2023-10-26 13:34:52 --> UTF-8 Support Enabled
INFO - 2023-10-26 13:34:52 --> Utf8 Class Initialized
INFO - 2023-10-26 13:34:52 --> URI Class Initialized
INFO - 2023-10-26 13:34:52 --> Router Class Initialized
INFO - 2023-10-26 13:34:52 --> Output Class Initialized
INFO - 2023-10-26 13:34:52 --> Security Class Initialized
DEBUG - 2023-10-26 13:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 13:34:52 --> Input Class Initialized
INFO - 2023-10-26 13:34:52 --> Language Class Initialized
INFO - 2023-10-26 13:34:52 --> Loader Class Initialized
INFO - 2023-10-26 13:34:52 --> Helper loaded: url_helper
INFO - 2023-10-26 13:34:52 --> Helper loaded: form_helper
INFO - 2023-10-26 13:34:52 --> Helper loaded: file_helper
INFO - 2023-10-26 13:34:52 --> Database Driver Class Initialized
DEBUG - 2023-10-26 13:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-26 13:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 13:34:52 --> Form Validation Class Initialized
INFO - 2023-10-26 13:34:52 --> Upload Class Initialized
INFO - 2023-10-26 13:34:52 --> Model "M_auth" initialized
INFO - 2023-10-26 13:34:52 --> Model "M_user" initialized
INFO - 2023-10-26 13:34:52 --> Model "M_produk" initialized
INFO - 2023-10-26 13:34:52 --> Controller Class Initialized
INFO - 2023-10-26 13:34:52 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-10-26 13:34:52 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-26 13:34:52 --> Final output sent to browser
DEBUG - 2023-10-26 13:34:52 --> Total execution time: 0.2292
INFO - 2023-10-26 13:34:57 --> Config Class Initialized
INFO - 2023-10-26 13:34:57 --> Hooks Class Initialized
DEBUG - 2023-10-26 13:34:57 --> UTF-8 Support Enabled
INFO - 2023-10-26 13:34:57 --> Utf8 Class Initialized
INFO - 2023-10-26 13:34:57 --> URI Class Initialized
INFO - 2023-10-26 13:34:57 --> Router Class Initialized
INFO - 2023-10-26 13:34:57 --> Output Class Initialized
INFO - 2023-10-26 13:34:57 --> Security Class Initialized
DEBUG - 2023-10-26 13:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 13:34:57 --> Input Class Initialized
INFO - 2023-10-26 13:34:57 --> Language Class Initialized
INFO - 2023-10-26 13:34:57 --> Loader Class Initialized
INFO - 2023-10-26 13:34:57 --> Helper loaded: url_helper
INFO - 2023-10-26 13:34:57 --> Helper loaded: form_helper
INFO - 2023-10-26 13:34:57 --> Helper loaded: file_helper
INFO - 2023-10-26 13:34:57 --> Database Driver Class Initialized
DEBUG - 2023-10-26 13:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-26 13:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 13:34:57 --> Form Validation Class Initialized
INFO - 2023-10-26 13:34:57 --> Upload Class Initialized
INFO - 2023-10-26 13:34:57 --> Model "M_auth" initialized
INFO - 2023-10-26 13:34:57 --> Model "M_user" initialized
INFO - 2023-10-26 13:34:57 --> Model "M_produk" initialized
INFO - 2023-10-26 13:34:57 --> Controller Class Initialized
INFO - 2023-10-26 13:34:57 --> Model "M_produk" initialized
INFO - 2023-10-26 13:34:57 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-10-26 13:34:57 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-26 13:34:57 --> Final output sent to browser
DEBUG - 2023-10-26 13:34:57 --> Total execution time: 0.1692
INFO - 2023-10-26 13:35:05 --> Config Class Initialized
INFO - 2023-10-26 13:35:05 --> Hooks Class Initialized
DEBUG - 2023-10-26 13:35:05 --> UTF-8 Support Enabled
INFO - 2023-10-26 13:35:05 --> Utf8 Class Initialized
INFO - 2023-10-26 13:35:05 --> URI Class Initialized
INFO - 2023-10-26 13:35:05 --> Router Class Initialized
INFO - 2023-10-26 13:35:05 --> Output Class Initialized
INFO - 2023-10-26 13:35:05 --> Security Class Initialized
DEBUG - 2023-10-26 13:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 13:35:05 --> Input Class Initialized
INFO - 2023-10-26 13:35:05 --> Language Class Initialized
INFO - 2023-10-26 13:35:05 --> Loader Class Initialized
INFO - 2023-10-26 13:35:05 --> Helper loaded: url_helper
INFO - 2023-10-26 13:35:05 --> Helper loaded: form_helper
INFO - 2023-10-26 13:35:05 --> Helper loaded: file_helper
INFO - 2023-10-26 13:35:05 --> Database Driver Class Initialized
DEBUG - 2023-10-26 13:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-26 13:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 13:35:05 --> Form Validation Class Initialized
INFO - 2023-10-26 13:35:05 --> Upload Class Initialized
INFO - 2023-10-26 13:35:05 --> Model "M_auth" initialized
INFO - 2023-10-26 13:35:05 --> Model "M_user" initialized
INFO - 2023-10-26 13:35:05 --> Model "M_produk" initialized
INFO - 2023-10-26 13:35:05 --> Controller Class Initialized
INFO - 2023-10-26 13:35:05 --> Model "M_produk" initialized
INFO - 2023-10-26 13:35:05 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_edit_produk.php
INFO - 2023-10-26 13:35:05 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-26 13:35:05 --> Final output sent to browser
DEBUG - 2023-10-26 13:35:05 --> Total execution time: 0.1267
INFO - 2023-10-26 13:35:13 --> Config Class Initialized
INFO - 2023-10-26 13:35:13 --> Hooks Class Initialized
DEBUG - 2023-10-26 13:35:13 --> UTF-8 Support Enabled
INFO - 2023-10-26 13:35:13 --> Utf8 Class Initialized
INFO - 2023-10-26 13:35:13 --> URI Class Initialized
INFO - 2023-10-26 13:35:13 --> Router Class Initialized
INFO - 2023-10-26 13:35:13 --> Output Class Initialized
INFO - 2023-10-26 13:35:13 --> Security Class Initialized
DEBUG - 2023-10-26 13:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 13:35:13 --> Input Class Initialized
INFO - 2023-10-26 13:35:13 --> Language Class Initialized
INFO - 2023-10-26 13:35:13 --> Loader Class Initialized
INFO - 2023-10-26 13:35:13 --> Helper loaded: url_helper
INFO - 2023-10-26 13:35:13 --> Helper loaded: form_helper
INFO - 2023-10-26 13:35:13 --> Helper loaded: file_helper
INFO - 2023-10-26 13:35:13 --> Database Driver Class Initialized
DEBUG - 2023-10-26 13:35:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-26 13:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 13:35:13 --> Form Validation Class Initialized
INFO - 2023-10-26 13:35:13 --> Upload Class Initialized
INFO - 2023-10-26 13:35:13 --> Model "M_auth" initialized
INFO - 2023-10-26 13:35:13 --> Model "M_user" initialized
INFO - 2023-10-26 13:35:13 --> Model "M_produk" initialized
INFO - 2023-10-26 13:35:13 --> Controller Class Initialized
INFO - 2023-10-26 13:35:13 --> Model "M_produk" initialized
INFO - 2023-10-26 13:35:13 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-10-26 13:35:13 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-26 13:35:13 --> Final output sent to browser
DEBUG - 2023-10-26 13:35:13 --> Total execution time: 0.0578
INFO - 2023-10-26 13:35:14 --> Config Class Initialized
INFO - 2023-10-26 13:35:14 --> Hooks Class Initialized
DEBUG - 2023-10-26 13:35:14 --> UTF-8 Support Enabled
INFO - 2023-10-26 13:35:14 --> Utf8 Class Initialized
INFO - 2023-10-26 13:35:14 --> URI Class Initialized
INFO - 2023-10-26 13:35:14 --> Router Class Initialized
INFO - 2023-10-26 13:35:14 --> Output Class Initialized
INFO - 2023-10-26 13:35:14 --> Security Class Initialized
DEBUG - 2023-10-26 13:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 13:35:14 --> Input Class Initialized
INFO - 2023-10-26 13:35:14 --> Language Class Initialized
INFO - 2023-10-26 13:35:14 --> Loader Class Initialized
INFO - 2023-10-26 13:35:14 --> Helper loaded: url_helper
INFO - 2023-10-26 13:35:14 --> Helper loaded: form_helper
INFO - 2023-10-26 13:35:14 --> Helper loaded: file_helper
INFO - 2023-10-26 13:35:14 --> Database Driver Class Initialized
DEBUG - 2023-10-26 13:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-26 13:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 13:35:14 --> Form Validation Class Initialized
INFO - 2023-10-26 13:35:14 --> Upload Class Initialized
INFO - 2023-10-26 13:35:14 --> Model "M_auth" initialized
INFO - 2023-10-26 13:35:14 --> Model "M_user" initialized
INFO - 2023-10-26 13:35:14 --> Model "M_produk" initialized
INFO - 2023-10-26 13:35:14 --> Controller Class Initialized
INFO - 2023-10-26 13:35:14 --> Model "M_produk" initialized
INFO - 2023-10-26 13:35:14 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_add_produk.php
INFO - 2023-10-26 13:35:14 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-10-26 13:35:14 --> Final output sent to browser
DEBUG - 2023-10-26 13:35:14 --> Total execution time: 0.1693
