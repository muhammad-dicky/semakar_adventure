<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-21 00:14:07 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 00:14:07 --> Config Class Initialized
INFO - 2023-11-21 00:14:07 --> Hooks Class Initialized
DEBUG - 2023-11-21 00:14:07 --> UTF-8 Support Enabled
INFO - 2023-11-21 00:14:07 --> Utf8 Class Initialized
INFO - 2023-11-21 00:14:07 --> URI Class Initialized
DEBUG - 2023-11-21 00:14:07 --> No URI present. Default controller set.
INFO - 2023-11-21 00:14:07 --> Router Class Initialized
INFO - 2023-11-21 00:14:07 --> Output Class Initialized
INFO - 2023-11-21 00:14:07 --> Security Class Initialized
DEBUG - 2023-11-21 00:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 00:14:07 --> Input Class Initialized
INFO - 2023-11-21 00:14:07 --> Language Class Initialized
INFO - 2023-11-21 00:14:07 --> Loader Class Initialized
INFO - 2023-11-21 00:14:07 --> Helper loaded: url_helper
INFO - 2023-11-21 00:14:07 --> Helper loaded: form_helper
INFO - 2023-11-21 00:14:07 --> Helper loaded: file_helper
INFO - 2023-11-21 00:14:07 --> Database Driver Class Initialized
DEBUG - 2023-11-21 00:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 00:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 00:14:07 --> Form Validation Class Initialized
INFO - 2023-11-21 00:14:07 --> Upload Class Initialized
INFO - 2023-11-21 00:14:07 --> Model "M_auth" initialized
INFO - 2023-11-21 00:14:07 --> Model "M_user" initialized
INFO - 2023-11-21 00:14:07 --> Model "M_produk" initialized
INFO - 2023-11-21 00:14:07 --> Controller Class Initialized
INFO - 2023-11-21 00:14:07 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 00:14:07 --> Model "M_produk" initialized
DEBUG - 2023-11-21 00:14:07 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 00:14:07 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 00:14:07 --> Model "M_transaksi" initialized
INFO - 2023-11-21 00:14:07 --> Model "M_bank" initialized
INFO - 2023-11-21 00:14:07 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 00:14:07 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 00:14:07 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 00:14:07 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-21 00:14:07 --> Final output sent to browser
DEBUG - 2023-11-21 00:14:07 --> Total execution time: 0.0346
ERROR - 2023-11-21 00:58:32 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 00:58:32 --> Config Class Initialized
INFO - 2023-11-21 00:58:32 --> Hooks Class Initialized
DEBUG - 2023-11-21 00:58:32 --> UTF-8 Support Enabled
INFO - 2023-11-21 00:58:32 --> Utf8 Class Initialized
INFO - 2023-11-21 00:58:32 --> URI Class Initialized
INFO - 2023-11-21 00:58:32 --> Router Class Initialized
INFO - 2023-11-21 00:58:32 --> Output Class Initialized
INFO - 2023-11-21 00:58:32 --> Security Class Initialized
DEBUG - 2023-11-21 00:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 00:58:32 --> Input Class Initialized
INFO - 2023-11-21 00:58:32 --> Language Class Initialized
INFO - 2023-11-21 00:58:32 --> Loader Class Initialized
INFO - 2023-11-21 00:58:32 --> Helper loaded: url_helper
INFO - 2023-11-21 00:58:32 --> Helper loaded: form_helper
INFO - 2023-11-21 00:58:32 --> Helper loaded: file_helper
INFO - 2023-11-21 00:58:32 --> Database Driver Class Initialized
DEBUG - 2023-11-21 00:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 00:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 00:58:32 --> Form Validation Class Initialized
INFO - 2023-11-21 00:58:32 --> Upload Class Initialized
INFO - 2023-11-21 00:58:32 --> Model "M_auth" initialized
INFO - 2023-11-21 00:58:32 --> Model "M_user" initialized
INFO - 2023-11-21 00:58:32 --> Model "M_produk" initialized
INFO - 2023-11-21 00:58:32 --> Controller Class Initialized
INFO - 2023-11-21 00:58:32 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 00:58:32 --> Model "M_produk" initialized
DEBUG - 2023-11-21 00:58:32 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 00:58:32 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 00:58:32 --> Model "M_transaksi" initialized
INFO - 2023-11-21 00:58:32 --> Model "M_bank" initialized
INFO - 2023-11-21 00:58:32 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 00:58:32 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 00:58:32 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 00:58:32 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-21 00:58:32 --> Final output sent to browser
DEBUG - 2023-11-21 00:58:32 --> Total execution time: 0.0331
ERROR - 2023-11-21 01:41:48 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 01:41:48 --> Config Class Initialized
INFO - 2023-11-21 01:41:48 --> Hooks Class Initialized
DEBUG - 2023-11-21 01:41:48 --> UTF-8 Support Enabled
INFO - 2023-11-21 01:41:48 --> Utf8 Class Initialized
INFO - 2023-11-21 01:41:48 --> URI Class Initialized
DEBUG - 2023-11-21 01:41:48 --> No URI present. Default controller set.
INFO - 2023-11-21 01:41:48 --> Router Class Initialized
INFO - 2023-11-21 01:41:48 --> Output Class Initialized
INFO - 2023-11-21 01:41:48 --> Security Class Initialized
DEBUG - 2023-11-21 01:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 01:41:48 --> Input Class Initialized
INFO - 2023-11-21 01:41:48 --> Language Class Initialized
INFO - 2023-11-21 01:41:48 --> Loader Class Initialized
INFO - 2023-11-21 01:41:48 --> Helper loaded: url_helper
INFO - 2023-11-21 01:41:48 --> Helper loaded: form_helper
INFO - 2023-11-21 01:41:48 --> Helper loaded: file_helper
INFO - 2023-11-21 01:41:48 --> Database Driver Class Initialized
DEBUG - 2023-11-21 01:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 01:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 01:41:48 --> Form Validation Class Initialized
INFO - 2023-11-21 01:41:48 --> Upload Class Initialized
INFO - 2023-11-21 01:41:48 --> Model "M_auth" initialized
INFO - 2023-11-21 01:41:48 --> Model "M_user" initialized
INFO - 2023-11-21 01:41:48 --> Model "M_produk" initialized
INFO - 2023-11-21 01:41:48 --> Controller Class Initialized
INFO - 2023-11-21 01:41:48 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 01:41:48 --> Model "M_produk" initialized
DEBUG - 2023-11-21 01:41:48 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 01:41:48 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 01:41:48 --> Model "M_transaksi" initialized
INFO - 2023-11-21 01:41:48 --> Model "M_bank" initialized
INFO - 2023-11-21 01:41:48 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 01:41:48 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 01:41:48 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 01:41:48 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-21 01:41:48 --> Final output sent to browser
DEBUG - 2023-11-21 01:41:48 --> Total execution time: 0.0352
ERROR - 2023-11-21 03:08:19 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 03:08:19 --> Config Class Initialized
INFO - 2023-11-21 03:08:19 --> Hooks Class Initialized
DEBUG - 2023-11-21 03:08:19 --> UTF-8 Support Enabled
INFO - 2023-11-21 03:08:19 --> Utf8 Class Initialized
INFO - 2023-11-21 03:08:19 --> URI Class Initialized
DEBUG - 2023-11-21 03:08:19 --> No URI present. Default controller set.
INFO - 2023-11-21 03:08:19 --> Router Class Initialized
INFO - 2023-11-21 03:08:19 --> Output Class Initialized
INFO - 2023-11-21 03:08:19 --> Security Class Initialized
DEBUG - 2023-11-21 03:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 03:08:19 --> Input Class Initialized
INFO - 2023-11-21 03:08:19 --> Language Class Initialized
INFO - 2023-11-21 03:08:19 --> Loader Class Initialized
INFO - 2023-11-21 03:08:19 --> Helper loaded: url_helper
INFO - 2023-11-21 03:08:19 --> Helper loaded: form_helper
INFO - 2023-11-21 03:08:19 --> Helper loaded: file_helper
INFO - 2023-11-21 03:08:19 --> Database Driver Class Initialized
DEBUG - 2023-11-21 03:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 03:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 03:08:19 --> Form Validation Class Initialized
INFO - 2023-11-21 03:08:19 --> Upload Class Initialized
INFO - 2023-11-21 03:08:19 --> Model "M_auth" initialized
INFO - 2023-11-21 03:08:19 --> Model "M_user" initialized
INFO - 2023-11-21 03:08:19 --> Model "M_produk" initialized
INFO - 2023-11-21 03:08:19 --> Controller Class Initialized
INFO - 2023-11-21 03:08:19 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 03:08:19 --> Model "M_produk" initialized
DEBUG - 2023-11-21 03:08:19 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 03:08:19 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 03:08:19 --> Model "M_transaksi" initialized
INFO - 2023-11-21 03:08:19 --> Model "M_bank" initialized
INFO - 2023-11-21 03:08:19 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 03:08:19 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 03:08:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 03:08:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-21 03:08:19 --> Final output sent to browser
DEBUG - 2023-11-21 03:08:19 --> Total execution time: 0.0368
ERROR - 2023-11-21 03:37:15 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 03:37:15 --> Config Class Initialized
INFO - 2023-11-21 03:37:15 --> Hooks Class Initialized
DEBUG - 2023-11-21 03:37:15 --> UTF-8 Support Enabled
INFO - 2023-11-21 03:37:15 --> Utf8 Class Initialized
INFO - 2023-11-21 03:37:15 --> URI Class Initialized
DEBUG - 2023-11-21 03:37:15 --> No URI present. Default controller set.
INFO - 2023-11-21 03:37:15 --> Router Class Initialized
INFO - 2023-11-21 03:37:15 --> Output Class Initialized
INFO - 2023-11-21 03:37:15 --> Security Class Initialized
DEBUG - 2023-11-21 03:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 03:37:15 --> Input Class Initialized
INFO - 2023-11-21 03:37:15 --> Language Class Initialized
INFO - 2023-11-21 03:37:15 --> Loader Class Initialized
INFO - 2023-11-21 03:37:15 --> Helper loaded: url_helper
INFO - 2023-11-21 03:37:15 --> Helper loaded: form_helper
INFO - 2023-11-21 03:37:15 --> Helper loaded: file_helper
INFO - 2023-11-21 03:37:15 --> Database Driver Class Initialized
DEBUG - 2023-11-21 03:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 03:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 03:37:15 --> Form Validation Class Initialized
INFO - 2023-11-21 03:37:15 --> Upload Class Initialized
INFO - 2023-11-21 03:37:15 --> Model "M_auth" initialized
INFO - 2023-11-21 03:37:15 --> Model "M_user" initialized
INFO - 2023-11-21 03:37:15 --> Model "M_produk" initialized
INFO - 2023-11-21 03:37:15 --> Controller Class Initialized
INFO - 2023-11-21 03:37:15 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 03:37:15 --> Model "M_produk" initialized
DEBUG - 2023-11-21 03:37:15 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 03:37:15 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 03:37:15 --> Model "M_transaksi" initialized
INFO - 2023-11-21 03:37:15 --> Model "M_bank" initialized
INFO - 2023-11-21 03:37:15 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 03:37:15 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 03:37:15 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 03:37:15 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-21 03:37:15 --> Final output sent to browser
DEBUG - 2023-11-21 03:37:15 --> Total execution time: 0.0316
ERROR - 2023-11-21 06:30:36 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 06:30:36 --> Config Class Initialized
INFO - 2023-11-21 06:30:36 --> Hooks Class Initialized
DEBUG - 2023-11-21 06:30:36 --> UTF-8 Support Enabled
INFO - 2023-11-21 06:30:36 --> Utf8 Class Initialized
INFO - 2023-11-21 06:30:36 --> URI Class Initialized
INFO - 2023-11-21 06:30:36 --> Router Class Initialized
INFO - 2023-11-21 06:30:36 --> Output Class Initialized
INFO - 2023-11-21 06:30:36 --> Security Class Initialized
DEBUG - 2023-11-21 06:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 06:30:36 --> Input Class Initialized
INFO - 2023-11-21 06:30:36 --> Language Class Initialized
INFO - 2023-11-21 06:30:36 --> Loader Class Initialized
INFO - 2023-11-21 06:30:36 --> Helper loaded: url_helper
INFO - 2023-11-21 06:30:36 --> Helper loaded: form_helper
INFO - 2023-11-21 06:30:36 --> Helper loaded: file_helper
INFO - 2023-11-21 06:30:36 --> Database Driver Class Initialized
DEBUG - 2023-11-21 06:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 06:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 06:30:36 --> Form Validation Class Initialized
INFO - 2023-11-21 06:30:36 --> Upload Class Initialized
INFO - 2023-11-21 06:30:36 --> Model "M_auth" initialized
INFO - 2023-11-21 06:30:36 --> Model "M_user" initialized
INFO - 2023-11-21 06:30:36 --> Model "M_produk" initialized
INFO - 2023-11-21 06:30:36 --> Controller Class Initialized
INFO - 2023-11-21 06:30:36 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-21 06:30:36 --> Final output sent to browser
DEBUG - 2023-11-21 06:30:36 --> Total execution time: 0.0302
ERROR - 2023-11-21 09:27:27 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 09:27:27 --> Config Class Initialized
INFO - 2023-11-21 09:27:27 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:27:27 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:27:27 --> Utf8 Class Initialized
INFO - 2023-11-21 09:27:27 --> URI Class Initialized
INFO - 2023-11-21 09:27:27 --> Router Class Initialized
INFO - 2023-11-21 09:27:27 --> Output Class Initialized
INFO - 2023-11-21 09:27:27 --> Security Class Initialized
DEBUG - 2023-11-21 09:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:27:27 --> Input Class Initialized
INFO - 2023-11-21 09:27:27 --> Language Class Initialized
INFO - 2023-11-21 09:27:27 --> Loader Class Initialized
INFO - 2023-11-21 09:27:27 --> Helper loaded: url_helper
INFO - 2023-11-21 09:27:27 --> Helper loaded: form_helper
INFO - 2023-11-21 09:27:27 --> Helper loaded: file_helper
INFO - 2023-11-21 09:27:27 --> Database Driver Class Initialized
DEBUG - 2023-11-21 09:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 09:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:27:27 --> Form Validation Class Initialized
INFO - 2023-11-21 09:27:27 --> Upload Class Initialized
INFO - 2023-11-21 09:27:27 --> Model "M_auth" initialized
INFO - 2023-11-21 09:27:27 --> Model "M_user" initialized
INFO - 2023-11-21 09:27:27 --> Model "M_produk" initialized
INFO - 2023-11-21 09:27:27 --> Controller Class Initialized
INFO - 2023-11-21 09:27:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-21 09:27:27 --> Final output sent to browser
DEBUG - 2023-11-21 09:27:27 --> Total execution time: 0.0277
ERROR - 2023-11-21 09:27:27 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 09:27:27 --> Config Class Initialized
INFO - 2023-11-21 09:27:27 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:27:27 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:27:27 --> Utf8 Class Initialized
INFO - 2023-11-21 09:27:27 --> URI Class Initialized
INFO - 2023-11-21 09:27:27 --> Router Class Initialized
INFO - 2023-11-21 09:27:27 --> Output Class Initialized
INFO - 2023-11-21 09:27:27 --> Security Class Initialized
DEBUG - 2023-11-21 09:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:27:27 --> Input Class Initialized
INFO - 2023-11-21 09:27:27 --> Language Class Initialized
INFO - 2023-11-21 09:27:27 --> Loader Class Initialized
INFO - 2023-11-21 09:27:27 --> Helper loaded: url_helper
INFO - 2023-11-21 09:27:27 --> Helper loaded: form_helper
INFO - 2023-11-21 09:27:27 --> Helper loaded: file_helper
INFO - 2023-11-21 09:27:27 --> Database Driver Class Initialized
DEBUG - 2023-11-21 09:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 09:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:27:27 --> Form Validation Class Initialized
INFO - 2023-11-21 09:27:27 --> Upload Class Initialized
INFO - 2023-11-21 09:27:27 --> Model "M_auth" initialized
INFO - 2023-11-21 09:27:27 --> Model "M_user" initialized
INFO - 2023-11-21 09:27:27 --> Model "M_produk" initialized
INFO - 2023-11-21 09:27:27 --> Controller Class Initialized
INFO - 2023-11-21 09:27:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-21 09:27:27 --> Final output sent to browser
DEBUG - 2023-11-21 09:27:27 --> Total execution time: 0.0024
ERROR - 2023-11-21 09:27:28 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 09:27:28 --> Config Class Initialized
INFO - 2023-11-21 09:27:28 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:27:28 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:27:28 --> Utf8 Class Initialized
INFO - 2023-11-21 09:27:28 --> URI Class Initialized
INFO - 2023-11-21 09:27:28 --> Router Class Initialized
INFO - 2023-11-21 09:27:28 --> Output Class Initialized
INFO - 2023-11-21 09:27:28 --> Security Class Initialized
DEBUG - 2023-11-21 09:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:27:28 --> Input Class Initialized
INFO - 2023-11-21 09:27:28 --> Language Class Initialized
INFO - 2023-11-21 09:27:28 --> Loader Class Initialized
INFO - 2023-11-21 09:27:28 --> Helper loaded: url_helper
INFO - 2023-11-21 09:27:28 --> Helper loaded: form_helper
INFO - 2023-11-21 09:27:28 --> Helper loaded: file_helper
INFO - 2023-11-21 09:27:28 --> Database Driver Class Initialized
DEBUG - 2023-11-21 09:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 09:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:27:28 --> Form Validation Class Initialized
INFO - 2023-11-21 09:27:28 --> Upload Class Initialized
INFO - 2023-11-21 09:27:28 --> Model "M_auth" initialized
INFO - 2023-11-21 09:27:28 --> Model "M_user" initialized
INFO - 2023-11-21 09:27:28 --> Model "M_produk" initialized
INFO - 2023-11-21 09:27:28 --> Controller Class Initialized
INFO - 2023-11-21 09:27:28 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-21 09:27:28 --> Final output sent to browser
DEBUG - 2023-11-21 09:27:28 --> Total execution time: 0.0026
ERROR - 2023-11-21 09:27:29 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 09:27:29 --> Config Class Initialized
INFO - 2023-11-21 09:27:29 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:27:29 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:27:29 --> Utf8 Class Initialized
INFO - 2023-11-21 09:27:29 --> URI Class Initialized
INFO - 2023-11-21 09:27:29 --> Router Class Initialized
INFO - 2023-11-21 09:27:29 --> Output Class Initialized
INFO - 2023-11-21 09:27:29 --> Security Class Initialized
DEBUG - 2023-11-21 09:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:27:29 --> Input Class Initialized
INFO - 2023-11-21 09:27:29 --> Language Class Initialized
INFO - 2023-11-21 09:27:29 --> Loader Class Initialized
INFO - 2023-11-21 09:27:29 --> Helper loaded: url_helper
INFO - 2023-11-21 09:27:29 --> Helper loaded: form_helper
INFO - 2023-11-21 09:27:29 --> Helper loaded: file_helper
INFO - 2023-11-21 09:27:29 --> Database Driver Class Initialized
DEBUG - 2023-11-21 09:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 09:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:27:29 --> Form Validation Class Initialized
INFO - 2023-11-21 09:27:29 --> Upload Class Initialized
INFO - 2023-11-21 09:27:29 --> Model "M_auth" initialized
INFO - 2023-11-21 09:27:29 --> Model "M_user" initialized
INFO - 2023-11-21 09:27:29 --> Model "M_produk" initialized
INFO - 2023-11-21 09:27:29 --> Controller Class Initialized
INFO - 2023-11-21 09:27:29 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-21 09:27:29 --> Final output sent to browser
DEBUG - 2023-11-21 09:27:29 --> Total execution time: 0.0022
ERROR - 2023-11-21 09:40:41 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 09:40:41 --> Config Class Initialized
INFO - 2023-11-21 09:40:41 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:40:41 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:40:41 --> Utf8 Class Initialized
INFO - 2023-11-21 09:40:41 --> URI Class Initialized
DEBUG - 2023-11-21 09:40:41 --> No URI present. Default controller set.
INFO - 2023-11-21 09:40:41 --> Router Class Initialized
INFO - 2023-11-21 09:40:41 --> Output Class Initialized
INFO - 2023-11-21 09:40:41 --> Security Class Initialized
DEBUG - 2023-11-21 09:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:40:41 --> Input Class Initialized
INFO - 2023-11-21 09:40:41 --> Language Class Initialized
INFO - 2023-11-21 09:40:41 --> Loader Class Initialized
INFO - 2023-11-21 09:40:41 --> Helper loaded: url_helper
INFO - 2023-11-21 09:40:41 --> Helper loaded: form_helper
INFO - 2023-11-21 09:40:41 --> Helper loaded: file_helper
INFO - 2023-11-21 09:40:41 --> Database Driver Class Initialized
DEBUG - 2023-11-21 09:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 09:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:40:41 --> Form Validation Class Initialized
INFO - 2023-11-21 09:40:41 --> Upload Class Initialized
INFO - 2023-11-21 09:40:41 --> Model "M_auth" initialized
INFO - 2023-11-21 09:40:41 --> Model "M_user" initialized
INFO - 2023-11-21 09:40:41 --> Model "M_produk" initialized
INFO - 2023-11-21 09:40:41 --> Controller Class Initialized
INFO - 2023-11-21 09:40:41 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 09:40:41 --> Model "M_produk" initialized
DEBUG - 2023-11-21 09:40:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 09:40:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 09:40:41 --> Model "M_transaksi" initialized
INFO - 2023-11-21 09:40:41 --> Model "M_bank" initialized
INFO - 2023-11-21 09:40:41 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 09:40:41 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 09:40:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 09:40:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-21 09:40:41 --> Final output sent to browser
DEBUG - 2023-11-21 09:40:41 --> Total execution time: 0.0349
ERROR - 2023-11-21 11:11:14 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:11:14 --> Config Class Initialized
INFO - 2023-11-21 11:11:14 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:11:14 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:11:14 --> Utf8 Class Initialized
INFO - 2023-11-21 11:11:14 --> URI Class Initialized
DEBUG - 2023-11-21 11:11:14 --> No URI present. Default controller set.
INFO - 2023-11-21 11:11:14 --> Router Class Initialized
INFO - 2023-11-21 11:11:14 --> Output Class Initialized
INFO - 2023-11-21 11:11:14 --> Security Class Initialized
DEBUG - 2023-11-21 11:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:11:14 --> Input Class Initialized
INFO - 2023-11-21 11:11:14 --> Language Class Initialized
INFO - 2023-11-21 11:11:14 --> Loader Class Initialized
INFO - 2023-11-21 11:11:14 --> Helper loaded: url_helper
INFO - 2023-11-21 11:11:14 --> Helper loaded: form_helper
INFO - 2023-11-21 11:11:14 --> Helper loaded: file_helper
INFO - 2023-11-21 11:11:14 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:11:14 --> Form Validation Class Initialized
INFO - 2023-11-21 11:11:14 --> Upload Class Initialized
INFO - 2023-11-21 11:11:14 --> Model "M_auth" initialized
INFO - 2023-11-21 11:11:14 --> Model "M_user" initialized
INFO - 2023-11-21 11:11:14 --> Model "M_produk" initialized
INFO - 2023-11-21 11:11:14 --> Controller Class Initialized
INFO - 2023-11-21 11:11:14 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 11:11:14 --> Model "M_produk" initialized
DEBUG - 2023-11-21 11:11:14 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 11:11:14 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 11:11:14 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:11:14 --> Model "M_bank" initialized
INFO - 2023-11-21 11:11:14 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 11:11:14 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 11:11:14 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 11:11:14 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-21 11:11:14 --> Final output sent to browser
DEBUG - 2023-11-21 11:11:14 --> Total execution time: 0.0368
ERROR - 2023-11-21 11:11:18 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:11:18 --> Config Class Initialized
INFO - 2023-11-21 11:11:18 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:11:18 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:11:18 --> Utf8 Class Initialized
INFO - 2023-11-21 11:11:18 --> URI Class Initialized
INFO - 2023-11-21 11:11:18 --> Router Class Initialized
INFO - 2023-11-21 11:11:18 --> Output Class Initialized
INFO - 2023-11-21 11:11:18 --> Security Class Initialized
DEBUG - 2023-11-21 11:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:11:18 --> Input Class Initialized
INFO - 2023-11-21 11:11:18 --> Language Class Initialized
INFO - 2023-11-21 11:11:18 --> Loader Class Initialized
INFO - 2023-11-21 11:11:18 --> Helper loaded: url_helper
INFO - 2023-11-21 11:11:18 --> Helper loaded: form_helper
INFO - 2023-11-21 11:11:18 --> Helper loaded: file_helper
INFO - 2023-11-21 11:11:18 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:11:18 --> Form Validation Class Initialized
INFO - 2023-11-21 11:11:18 --> Upload Class Initialized
INFO - 2023-11-21 11:11:18 --> Model "M_auth" initialized
INFO - 2023-11-21 11:11:18 --> Model "M_user" initialized
INFO - 2023-11-21 11:11:18 --> Model "M_produk" initialized
INFO - 2023-11-21 11:11:18 --> Controller Class Initialized
INFO - 2023-11-21 11:11:18 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-21 11:11:18 --> Final output sent to browser
DEBUG - 2023-11-21 11:11:18 --> Total execution time: 0.0026
ERROR - 2023-11-21 11:11:18 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:11:18 --> Config Class Initialized
INFO - 2023-11-21 11:11:18 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:11:18 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:11:18 --> Utf8 Class Initialized
INFO - 2023-11-21 11:11:18 --> URI Class Initialized
INFO - 2023-11-21 11:11:18 --> Router Class Initialized
INFO - 2023-11-21 11:11:18 --> Output Class Initialized
INFO - 2023-11-21 11:11:18 --> Security Class Initialized
DEBUG - 2023-11-21 11:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:11:18 --> Input Class Initialized
INFO - 2023-11-21 11:11:18 --> Language Class Initialized
INFO - 2023-11-21 11:11:18 --> Loader Class Initialized
INFO - 2023-11-21 11:11:18 --> Helper loaded: url_helper
INFO - 2023-11-21 11:11:18 --> Helper loaded: form_helper
INFO - 2023-11-21 11:11:18 --> Helper loaded: file_helper
INFO - 2023-11-21 11:11:18 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:11:18 --> Form Validation Class Initialized
INFO - 2023-11-21 11:11:18 --> Upload Class Initialized
INFO - 2023-11-21 11:11:18 --> Model "M_auth" initialized
INFO - 2023-11-21 11:11:18 --> Model "M_user" initialized
INFO - 2023-11-21 11:11:18 --> Model "M_produk" initialized
INFO - 2023-11-21 11:11:18 --> Controller Class Initialized
INFO - 2023-11-21 11:11:18 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-21 11:11:18 --> Final output sent to browser
DEBUG - 2023-11-21 11:11:18 --> Total execution time: 0.0021
ERROR - 2023-11-21 11:22:33 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:22:33 --> Config Class Initialized
INFO - 2023-11-21 11:22:33 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:22:33 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:22:33 --> Utf8 Class Initialized
INFO - 2023-11-21 11:22:33 --> URI Class Initialized
DEBUG - 2023-11-21 11:22:33 --> No URI present. Default controller set.
INFO - 2023-11-21 11:22:33 --> Router Class Initialized
INFO - 2023-11-21 11:22:33 --> Output Class Initialized
INFO - 2023-11-21 11:22:33 --> Security Class Initialized
DEBUG - 2023-11-21 11:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:22:33 --> Input Class Initialized
INFO - 2023-11-21 11:22:33 --> Language Class Initialized
INFO - 2023-11-21 11:22:33 --> Loader Class Initialized
INFO - 2023-11-21 11:22:33 --> Helper loaded: url_helper
INFO - 2023-11-21 11:22:33 --> Helper loaded: form_helper
INFO - 2023-11-21 11:22:33 --> Helper loaded: file_helper
INFO - 2023-11-21 11:22:33 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:22:33 --> Form Validation Class Initialized
INFO - 2023-11-21 11:22:33 --> Upload Class Initialized
INFO - 2023-11-21 11:22:33 --> Model "M_auth" initialized
INFO - 2023-11-21 11:22:33 --> Model "M_user" initialized
INFO - 2023-11-21 11:22:33 --> Model "M_produk" initialized
INFO - 2023-11-21 11:22:33 --> Controller Class Initialized
INFO - 2023-11-21 11:22:33 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 11:22:33 --> Model "M_produk" initialized
DEBUG - 2023-11-21 11:22:33 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 11:22:33 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 11:22:33 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:22:33 --> Model "M_bank" initialized
INFO - 2023-11-21 11:22:33 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 11:22:33 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 11:22:33 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2023-11-21 11:22:33 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:22:33 --> Config Class Initialized
INFO - 2023-11-21 11:22:33 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:22:33 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:22:33 --> Utf8 Class Initialized
INFO - 2023-11-21 11:22:33 --> URI Class Initialized
DEBUG - 2023-11-21 11:22:33 --> No URI present. Default controller set.
INFO - 2023-11-21 11:22:33 --> Router Class Initialized
INFO - 2023-11-21 11:22:33 --> Output Class Initialized
INFO - 2023-11-21 11:22:33 --> Security Class Initialized
DEBUG - 2023-11-21 11:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:22:33 --> Input Class Initialized
INFO - 2023-11-21 11:22:33 --> Language Class Initialized
INFO - 2023-11-21 11:22:33 --> Loader Class Initialized
INFO - 2023-11-21 11:22:33 --> Helper loaded: url_helper
INFO - 2023-11-21 11:22:33 --> Helper loaded: form_helper
INFO - 2023-11-21 11:22:33 --> Helper loaded: file_helper
INFO - 2023-11-21 11:22:33 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:22:33 --> Form Validation Class Initialized
INFO - 2023-11-21 11:22:33 --> Upload Class Initialized
INFO - 2023-11-21 11:22:33 --> Model "M_auth" initialized
INFO - 2023-11-21 11:22:33 --> Model "M_user" initialized
INFO - 2023-11-21 11:22:33 --> Model "M_produk" initialized
INFO - 2023-11-21 11:22:33 --> Controller Class Initialized
INFO - 2023-11-21 11:22:33 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 11:22:33 --> Model "M_produk" initialized
DEBUG - 2023-11-21 11:22:33 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 11:22:33 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 11:22:33 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:22:33 --> Model "M_bank" initialized
INFO - 2023-11-21 11:22:33 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 11:22:33 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 11:22:33 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 11:22:33 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-21 11:22:33 --> Final output sent to browser
DEBUG - 2023-11-21 11:22:33 --> Total execution time: 0.0042
ERROR - 2023-11-21 11:22:36 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:22:36 --> Config Class Initialized
INFO - 2023-11-21 11:22:36 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:22:36 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:22:36 --> Utf8 Class Initialized
INFO - 2023-11-21 11:22:36 --> URI Class Initialized
INFO - 2023-11-21 11:22:36 --> Router Class Initialized
INFO - 2023-11-21 11:22:36 --> Output Class Initialized
INFO - 2023-11-21 11:22:36 --> Security Class Initialized
DEBUG - 2023-11-21 11:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:22:36 --> Input Class Initialized
INFO - 2023-11-21 11:22:36 --> Language Class Initialized
INFO - 2023-11-21 11:22:36 --> Loader Class Initialized
INFO - 2023-11-21 11:22:36 --> Helper loaded: url_helper
INFO - 2023-11-21 11:22:36 --> Helper loaded: form_helper
INFO - 2023-11-21 11:22:36 --> Helper loaded: file_helper
INFO - 2023-11-21 11:22:36 --> Database Driver Class Initialized
ERROR - 2023-11-21 11:22:36 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:22:36 --> Config Class Initialized
INFO - 2023-11-21 11:22:36 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:22:36 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:22:36 --> Utf8 Class Initialized
INFO - 2023-11-21 11:22:36 --> URI Class Initialized
INFO - 2023-11-21 11:22:36 --> Router Class Initialized
INFO - 2023-11-21 11:22:36 --> Output Class Initialized
INFO - 2023-11-21 11:22:36 --> Security Class Initialized
DEBUG - 2023-11-21 11:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:22:36 --> Input Class Initialized
INFO - 2023-11-21 11:22:36 --> Language Class Initialized
DEBUG - 2023-11-21 11:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:22:36 --> Loader Class Initialized
INFO - 2023-11-21 11:22:36 --> Helper loaded: url_helper
INFO - 2023-11-21 11:22:36 --> Helper loaded: form_helper
INFO - 2023-11-21 11:22:36 --> Helper loaded: file_helper
INFO - 2023-11-21 11:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:22:36 --> Database Driver Class Initialized
INFO - 2023-11-21 11:22:36 --> Form Validation Class Initialized
INFO - 2023-11-21 11:22:36 --> Upload Class Initialized
INFO - 2023-11-21 11:22:36 --> Model "M_auth" initialized
INFO - 2023-11-21 11:22:36 --> Model "M_user" initialized
INFO - 2023-11-21 11:22:36 --> Model "M_produk" initialized
INFO - 2023-11-21 11:22:36 --> Controller Class Initialized
INFO - 2023-11-21 11:22:36 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-21 11:22:36 --> Final output sent to browser
DEBUG - 2023-11-21 11:22:36 --> Total execution time: 0.0036
DEBUG - 2023-11-21 11:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:22:36 --> Form Validation Class Initialized
INFO - 2023-11-21 11:22:36 --> Upload Class Initialized
INFO - 2023-11-21 11:22:36 --> Model "M_auth" initialized
INFO - 2023-11-21 11:22:36 --> Model "M_user" initialized
INFO - 2023-11-21 11:22:36 --> Model "M_produk" initialized
INFO - 2023-11-21 11:22:36 --> Controller Class Initialized
INFO - 2023-11-21 11:22:36 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-21 11:22:36 --> Final output sent to browser
DEBUG - 2023-11-21 11:22:36 --> Total execution time: 0.0028
ERROR - 2023-11-21 11:22:52 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:22:52 --> Config Class Initialized
INFO - 2023-11-21 11:22:52 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:22:52 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:22:52 --> Utf8 Class Initialized
INFO - 2023-11-21 11:22:52 --> URI Class Initialized
DEBUG - 2023-11-21 11:22:52 --> No URI present. Default controller set.
INFO - 2023-11-21 11:22:52 --> Router Class Initialized
INFO - 2023-11-21 11:22:52 --> Output Class Initialized
INFO - 2023-11-21 11:22:52 --> Security Class Initialized
DEBUG - 2023-11-21 11:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:22:52 --> Input Class Initialized
INFO - 2023-11-21 11:22:52 --> Language Class Initialized
INFO - 2023-11-21 11:22:52 --> Loader Class Initialized
INFO - 2023-11-21 11:22:52 --> Helper loaded: url_helper
INFO - 2023-11-21 11:22:52 --> Helper loaded: form_helper
INFO - 2023-11-21 11:22:52 --> Helper loaded: file_helper
INFO - 2023-11-21 11:22:52 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:22:52 --> Form Validation Class Initialized
INFO - 2023-11-21 11:22:52 --> Upload Class Initialized
INFO - 2023-11-21 11:22:52 --> Model "M_auth" initialized
INFO - 2023-11-21 11:22:52 --> Model "M_user" initialized
INFO - 2023-11-21 11:22:52 --> Model "M_produk" initialized
INFO - 2023-11-21 11:22:52 --> Controller Class Initialized
INFO - 2023-11-21 11:22:52 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 11:22:52 --> Model "M_produk" initialized
DEBUG - 2023-11-21 11:22:52 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 11:22:52 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 11:22:52 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:22:52 --> Model "M_bank" initialized
INFO - 2023-11-21 11:22:52 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 11:22:52 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 11:22:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-11-21 11:22:52 --> Email Class Initialized
INFO - 2023-11-21 11:22:53 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-11-21 11:22:55 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:22:55 --> Config Class Initialized
INFO - 2023-11-21 11:22:55 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:22:55 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:22:55 --> Utf8 Class Initialized
INFO - 2023-11-21 11:22:55 --> URI Class Initialized
DEBUG - 2023-11-21 11:22:55 --> No URI present. Default controller set.
INFO - 2023-11-21 11:22:55 --> Router Class Initialized
INFO - 2023-11-21 11:22:55 --> Output Class Initialized
INFO - 2023-11-21 11:22:55 --> Security Class Initialized
DEBUG - 2023-11-21 11:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:22:55 --> Input Class Initialized
INFO - 2023-11-21 11:22:55 --> Language Class Initialized
INFO - 2023-11-21 11:22:55 --> Loader Class Initialized
INFO - 2023-11-21 11:22:55 --> Helper loaded: url_helper
INFO - 2023-11-21 11:22:55 --> Helper loaded: form_helper
INFO - 2023-11-21 11:22:55 --> Helper loaded: file_helper
INFO - 2023-11-21 11:22:55 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:22:55 --> Form Validation Class Initialized
INFO - 2023-11-21 11:22:55 --> Upload Class Initialized
INFO - 2023-11-21 11:22:55 --> Model "M_auth" initialized
INFO - 2023-11-21 11:22:55 --> Model "M_user" initialized
INFO - 2023-11-21 11:22:55 --> Model "M_produk" initialized
INFO - 2023-11-21 11:22:55 --> Controller Class Initialized
INFO - 2023-11-21 11:22:55 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 11:22:55 --> Model "M_produk" initialized
DEBUG - 2023-11-21 11:22:55 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 11:22:55 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 11:22:55 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:22:55 --> Model "M_bank" initialized
INFO - 2023-11-21 11:22:55 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 11:22:55 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 11:22:55 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 11:22:55 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-21 11:22:55 --> Final output sent to browser
DEBUG - 2023-11-21 11:22:55 --> Total execution time: 0.0033
ERROR - 2023-11-21 11:22:55 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:22:55 --> Config Class Initialized
INFO - 2023-11-21 11:22:55 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:22:55 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:22:55 --> Utf8 Class Initialized
INFO - 2023-11-21 11:22:55 --> URI Class Initialized
INFO - 2023-11-21 11:22:55 --> Router Class Initialized
INFO - 2023-11-21 11:22:55 --> Output Class Initialized
INFO - 2023-11-21 11:22:55 --> Security Class Initialized
DEBUG - 2023-11-21 11:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:22:55 --> Input Class Initialized
INFO - 2023-11-21 11:22:55 --> Language Class Initialized
INFO - 2023-11-21 11:22:55 --> Loader Class Initialized
INFO - 2023-11-21 11:22:55 --> Helper loaded: url_helper
INFO - 2023-11-21 11:22:55 --> Helper loaded: form_helper
INFO - 2023-11-21 11:22:55 --> Helper loaded: file_helper
INFO - 2023-11-21 11:22:55 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:22:55 --> Form Validation Class Initialized
INFO - 2023-11-21 11:22:55 --> Upload Class Initialized
INFO - 2023-11-21 11:22:55 --> Model "M_auth" initialized
INFO - 2023-11-21 11:22:55 --> Model "M_user" initialized
INFO - 2023-11-21 11:22:55 --> Model "M_produk" initialized
INFO - 2023-11-21 11:22:55 --> Controller Class Initialized
INFO - 2023-11-21 11:22:55 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-21 11:22:55 --> Final output sent to browser
DEBUG - 2023-11-21 11:22:55 --> Total execution time: 0.0026
ERROR - 2023-11-21 11:22:55 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:22:55 --> Config Class Initialized
INFO - 2023-11-21 11:22:55 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:22:55 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:22:55 --> Utf8 Class Initialized
INFO - 2023-11-21 11:22:55 --> URI Class Initialized
INFO - 2023-11-21 11:22:55 --> Router Class Initialized
INFO - 2023-11-21 11:22:55 --> Output Class Initialized
INFO - 2023-11-21 11:22:55 --> Security Class Initialized
DEBUG - 2023-11-21 11:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:22:55 --> Input Class Initialized
INFO - 2023-11-21 11:22:55 --> Language Class Initialized
INFO - 2023-11-21 11:22:55 --> Loader Class Initialized
INFO - 2023-11-21 11:22:55 --> Helper loaded: url_helper
INFO - 2023-11-21 11:22:55 --> Helper loaded: form_helper
INFO - 2023-11-21 11:22:55 --> Helper loaded: file_helper
INFO - 2023-11-21 11:22:55 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:22:55 --> Form Validation Class Initialized
INFO - 2023-11-21 11:22:55 --> Upload Class Initialized
INFO - 2023-11-21 11:22:55 --> Model "M_auth" initialized
INFO - 2023-11-21 11:22:55 --> Model "M_user" initialized
INFO - 2023-11-21 11:22:55 --> Model "M_produk" initialized
INFO - 2023-11-21 11:22:55 --> Controller Class Initialized
INFO - 2023-11-21 11:22:55 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-21 11:22:55 --> Final output sent to browser
DEBUG - 2023-11-21 11:22:55 --> Total execution time: 0.0022
ERROR - 2023-11-21 11:23:00 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:23:00 --> Config Class Initialized
INFO - 2023-11-21 11:23:00 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:23:00 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:23:00 --> Utf8 Class Initialized
INFO - 2023-11-21 11:23:00 --> URI Class Initialized
INFO - 2023-11-21 11:23:00 --> Router Class Initialized
INFO - 2023-11-21 11:23:00 --> Output Class Initialized
INFO - 2023-11-21 11:23:00 --> Security Class Initialized
DEBUG - 2023-11-21 11:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:23:00 --> Input Class Initialized
INFO - 2023-11-21 11:23:00 --> Language Class Initialized
INFO - 2023-11-21 11:23:00 --> Loader Class Initialized
INFO - 2023-11-21 11:23:00 --> Helper loaded: url_helper
INFO - 2023-11-21 11:23:00 --> Helper loaded: form_helper
INFO - 2023-11-21 11:23:00 --> Helper loaded: file_helper
INFO - 2023-11-21 11:23:00 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:23:00 --> Form Validation Class Initialized
INFO - 2023-11-21 11:23:00 --> Upload Class Initialized
INFO - 2023-11-21 11:23:00 --> Model "M_auth" initialized
INFO - 2023-11-21 11:23:00 --> Model "M_user" initialized
INFO - 2023-11-21 11:23:00 --> Model "M_produk" initialized
INFO - 2023-11-21 11:23:00 --> Controller Class Initialized
INFO - 2023-11-21 11:23:00 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 11:23:00 --> Model "M_produk" initialized
DEBUG - 2023-11-21 11:23:00 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 11:23:00 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 11:23:00 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:23:00 --> Model "M_bank" initialized
INFO - 2023-11-21 11:23:00 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 11:23:00 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 11:23:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 11:23:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-21 11:23:02 --> Final output sent to browser
DEBUG - 2023-11-21 11:23:02 --> Total execution time: 1.8696
ERROR - 2023-11-21 11:23:02 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:23:02 --> Config Class Initialized
INFO - 2023-11-21 11:23:02 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:23:02 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:23:02 --> Utf8 Class Initialized
INFO - 2023-11-21 11:23:02 --> URI Class Initialized
INFO - 2023-11-21 11:23:02 --> Router Class Initialized
INFO - 2023-11-21 11:23:02 --> Output Class Initialized
INFO - 2023-11-21 11:23:02 --> Security Class Initialized
DEBUG - 2023-11-21 11:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:23:02 --> Input Class Initialized
INFO - 2023-11-21 11:23:02 --> Language Class Initialized
INFO - 2023-11-21 11:23:02 --> Loader Class Initialized
INFO - 2023-11-21 11:23:02 --> Helper loaded: url_helper
INFO - 2023-11-21 11:23:02 --> Helper loaded: form_helper
INFO - 2023-11-21 11:23:02 --> Helper loaded: file_helper
INFO - 2023-11-21 11:23:02 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:23:02 --> Form Validation Class Initialized
INFO - 2023-11-21 11:23:02 --> Upload Class Initialized
INFO - 2023-11-21 11:23:02 --> Model "M_auth" initialized
INFO - 2023-11-21 11:23:02 --> Model "M_user" initialized
INFO - 2023-11-21 11:23:02 --> Model "M_produk" initialized
INFO - 2023-11-21 11:23:02 --> Controller Class Initialized
INFO - 2023-11-21 11:23:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-21 11:23:02 --> Final output sent to browser
DEBUG - 2023-11-21 11:23:02 --> Total execution time: 0.0032
ERROR - 2023-11-21 11:23:49 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:23:49 --> Config Class Initialized
INFO - 2023-11-21 11:23:49 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:23:49 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:23:49 --> Utf8 Class Initialized
INFO - 2023-11-21 11:23:49 --> URI Class Initialized
DEBUG - 2023-11-21 11:23:49 --> No URI present. Default controller set.
INFO - 2023-11-21 11:23:49 --> Router Class Initialized
INFO - 2023-11-21 11:23:49 --> Output Class Initialized
INFO - 2023-11-21 11:23:49 --> Security Class Initialized
DEBUG - 2023-11-21 11:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:23:49 --> Input Class Initialized
INFO - 2023-11-21 11:23:49 --> Language Class Initialized
INFO - 2023-11-21 11:23:49 --> Loader Class Initialized
INFO - 2023-11-21 11:23:49 --> Helper loaded: url_helper
INFO - 2023-11-21 11:23:49 --> Helper loaded: form_helper
INFO - 2023-11-21 11:23:49 --> Helper loaded: file_helper
INFO - 2023-11-21 11:23:49 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:23:49 --> Form Validation Class Initialized
INFO - 2023-11-21 11:23:49 --> Upload Class Initialized
INFO - 2023-11-21 11:23:49 --> Model "M_auth" initialized
INFO - 2023-11-21 11:23:49 --> Model "M_user" initialized
INFO - 2023-11-21 11:23:49 --> Model "M_produk" initialized
INFO - 2023-11-21 11:23:49 --> Controller Class Initialized
INFO - 2023-11-21 11:23:49 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 11:23:49 --> Model "M_produk" initialized
DEBUG - 2023-11-21 11:23:49 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 11:23:49 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 11:23:49 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:23:49 --> Model "M_bank" initialized
INFO - 2023-11-21 11:23:49 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 11:23:49 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 11:23:49 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 11:23:49 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-21 11:23:49 --> Final output sent to browser
DEBUG - 2023-11-21 11:23:49 --> Total execution time: 0.0038
ERROR - 2023-11-21 11:23:49 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:23:49 --> Config Class Initialized
INFO - 2023-11-21 11:23:49 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:23:49 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:23:49 --> Utf8 Class Initialized
INFO - 2023-11-21 11:23:49 --> URI Class Initialized
INFO - 2023-11-21 11:23:49 --> Router Class Initialized
INFO - 2023-11-21 11:23:49 --> Output Class Initialized
INFO - 2023-11-21 11:23:49 --> Security Class Initialized
DEBUG - 2023-11-21 11:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:23:49 --> Input Class Initialized
INFO - 2023-11-21 11:23:49 --> Language Class Initialized
INFO - 2023-11-21 11:23:49 --> Loader Class Initialized
INFO - 2023-11-21 11:23:49 --> Helper loaded: url_helper
INFO - 2023-11-21 11:23:49 --> Helper loaded: form_helper
INFO - 2023-11-21 11:23:49 --> Helper loaded: file_helper
INFO - 2023-11-21 11:23:49 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:23:49 --> Form Validation Class Initialized
INFO - 2023-11-21 11:23:49 --> Upload Class Initialized
INFO - 2023-11-21 11:23:49 --> Model "M_auth" initialized
INFO - 2023-11-21 11:23:49 --> Model "M_user" initialized
INFO - 2023-11-21 11:23:49 --> Model "M_produk" initialized
INFO - 2023-11-21 11:23:49 --> Controller Class Initialized
INFO - 2023-11-21 11:23:49 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-21 11:23:49 --> Final output sent to browser
DEBUG - 2023-11-21 11:23:49 --> Total execution time: 0.0027
ERROR - 2023-11-21 11:23:50 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:23:50 --> Config Class Initialized
INFO - 2023-11-21 11:23:50 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:23:50 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:23:50 --> Utf8 Class Initialized
INFO - 2023-11-21 11:23:50 --> URI Class Initialized
INFO - 2023-11-21 11:23:50 --> Router Class Initialized
INFO - 2023-11-21 11:23:50 --> Output Class Initialized
INFO - 2023-11-21 11:23:50 --> Security Class Initialized
DEBUG - 2023-11-21 11:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:23:50 --> Input Class Initialized
INFO - 2023-11-21 11:23:50 --> Language Class Initialized
INFO - 2023-11-21 11:23:50 --> Loader Class Initialized
INFO - 2023-11-21 11:23:50 --> Helper loaded: url_helper
INFO - 2023-11-21 11:23:50 --> Helper loaded: form_helper
INFO - 2023-11-21 11:23:50 --> Helper loaded: file_helper
INFO - 2023-11-21 11:23:50 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:23:50 --> Form Validation Class Initialized
INFO - 2023-11-21 11:23:50 --> Upload Class Initialized
INFO - 2023-11-21 11:23:50 --> Model "M_auth" initialized
INFO - 2023-11-21 11:23:50 --> Model "M_user" initialized
INFO - 2023-11-21 11:23:50 --> Model "M_produk" initialized
INFO - 2023-11-21 11:23:50 --> Controller Class Initialized
INFO - 2023-11-21 11:23:50 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-21 11:23:50 --> Final output sent to browser
DEBUG - 2023-11-21 11:23:50 --> Total execution time: 0.0022
ERROR - 2023-11-21 11:23:52 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:23:52 --> Config Class Initialized
INFO - 2023-11-21 11:23:52 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:23:52 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:23:52 --> Utf8 Class Initialized
INFO - 2023-11-21 11:23:52 --> URI Class Initialized
INFO - 2023-11-21 11:23:52 --> Router Class Initialized
INFO - 2023-11-21 11:23:52 --> Output Class Initialized
INFO - 2023-11-21 11:23:52 --> Security Class Initialized
DEBUG - 2023-11-21 11:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:23:52 --> Input Class Initialized
INFO - 2023-11-21 11:23:52 --> Language Class Initialized
INFO - 2023-11-21 11:23:52 --> Loader Class Initialized
INFO - 2023-11-21 11:23:52 --> Helper loaded: url_helper
INFO - 2023-11-21 11:23:52 --> Helper loaded: form_helper
INFO - 2023-11-21 11:23:52 --> Helper loaded: file_helper
INFO - 2023-11-21 11:23:52 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:23:52 --> Form Validation Class Initialized
INFO - 2023-11-21 11:23:52 --> Upload Class Initialized
INFO - 2023-11-21 11:23:52 --> Model "M_auth" initialized
INFO - 2023-11-21 11:23:52 --> Model "M_user" initialized
INFO - 2023-11-21 11:23:52 --> Model "M_produk" initialized
INFO - 2023-11-21 11:23:52 --> Controller Class Initialized
INFO - 2023-11-21 11:23:52 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 11:23:52 --> Model "M_produk" initialized
DEBUG - 2023-11-21 11:23:52 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 11:23:52 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 11:23:52 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:23:52 --> Model "M_bank" initialized
INFO - 2023-11-21 11:23:52 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 11:23:52 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 11:23:52 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 11:23:52 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-21 11:23:52 --> Final output sent to browser
DEBUG - 2023-11-21 11:23:52 --> Total execution time: 0.0047
ERROR - 2023-11-21 11:23:52 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:23:52 --> Config Class Initialized
INFO - 2023-11-21 11:23:52 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:23:52 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:23:52 --> Utf8 Class Initialized
INFO - 2023-11-21 11:23:52 --> URI Class Initialized
INFO - 2023-11-21 11:23:52 --> Router Class Initialized
INFO - 2023-11-21 11:23:52 --> Output Class Initialized
INFO - 2023-11-21 11:23:52 --> Security Class Initialized
DEBUG - 2023-11-21 11:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:23:52 --> Input Class Initialized
INFO - 2023-11-21 11:23:52 --> Language Class Initialized
INFO - 2023-11-21 11:23:52 --> Loader Class Initialized
INFO - 2023-11-21 11:23:52 --> Helper loaded: url_helper
INFO - 2023-11-21 11:23:52 --> Helper loaded: form_helper
INFO - 2023-11-21 11:23:52 --> Helper loaded: file_helper
INFO - 2023-11-21 11:23:52 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:23:52 --> Form Validation Class Initialized
INFO - 2023-11-21 11:23:52 --> Upload Class Initialized
INFO - 2023-11-21 11:23:52 --> Model "M_auth" initialized
INFO - 2023-11-21 11:23:52 --> Model "M_user" initialized
INFO - 2023-11-21 11:23:52 --> Model "M_produk" initialized
INFO - 2023-11-21 11:23:52 --> Controller Class Initialized
INFO - 2023-11-21 11:23:52 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-21 11:23:52 --> Final output sent to browser
DEBUG - 2023-11-21 11:23:52 --> Total execution time: 0.0024
ERROR - 2023-11-21 11:24:01 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:24:01 --> Config Class Initialized
INFO - 2023-11-21 11:24:01 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:24:01 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:24:01 --> Utf8 Class Initialized
INFO - 2023-11-21 11:24:01 --> URI Class Initialized
INFO - 2023-11-21 11:24:01 --> Router Class Initialized
INFO - 2023-11-21 11:24:01 --> Output Class Initialized
INFO - 2023-11-21 11:24:01 --> Security Class Initialized
DEBUG - 2023-11-21 11:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:24:01 --> Input Class Initialized
INFO - 2023-11-21 11:24:01 --> Language Class Initialized
INFO - 2023-11-21 11:24:01 --> Loader Class Initialized
INFO - 2023-11-21 11:24:01 --> Helper loaded: url_helper
INFO - 2023-11-21 11:24:01 --> Helper loaded: form_helper
INFO - 2023-11-21 11:24:01 --> Helper loaded: file_helper
INFO - 2023-11-21 11:24:01 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:24:01 --> Form Validation Class Initialized
INFO - 2023-11-21 11:24:01 --> Upload Class Initialized
INFO - 2023-11-21 11:24:01 --> Model "M_auth" initialized
INFO - 2023-11-21 11:24:01 --> Model "M_user" initialized
INFO - 2023-11-21 11:24:01 --> Model "M_produk" initialized
INFO - 2023-11-21 11:24:01 --> Controller Class Initialized
INFO - 2023-11-21 11:24:01 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 11:24:01 --> Model "M_produk" initialized
DEBUG - 2023-11-21 11:24:01 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 11:24:01 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 11:24:01 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:24:01 --> Model "M_bank" initialized
INFO - 2023-11-21 11:24:01 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 11:24:01 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 11:24:01 --> Email Class Initialized
INFO - 2023-11-21 11:24:02 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-11-21 11:24:04 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:24:04 --> Config Class Initialized
INFO - 2023-11-21 11:24:04 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:24:04 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:24:04 --> Utf8 Class Initialized
INFO - 2023-11-21 11:24:04 --> URI Class Initialized
INFO - 2023-11-21 11:24:04 --> Router Class Initialized
INFO - 2023-11-21 11:24:04 --> Output Class Initialized
INFO - 2023-11-21 11:24:04 --> Security Class Initialized
DEBUG - 2023-11-21 11:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:24:04 --> Input Class Initialized
INFO - 2023-11-21 11:24:04 --> Language Class Initialized
INFO - 2023-11-21 11:24:04 --> Loader Class Initialized
INFO - 2023-11-21 11:24:04 --> Helper loaded: url_helper
INFO - 2023-11-21 11:24:04 --> Helper loaded: form_helper
INFO - 2023-11-21 11:24:04 --> Helper loaded: file_helper
INFO - 2023-11-21 11:24:04 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:24:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:24:04 --> Form Validation Class Initialized
INFO - 2023-11-21 11:24:04 --> Upload Class Initialized
INFO - 2023-11-21 11:24:04 --> Model "M_auth" initialized
INFO - 2023-11-21 11:24:04 --> Model "M_user" initialized
INFO - 2023-11-21 11:24:04 --> Model "M_produk" initialized
INFO - 2023-11-21 11:24:04 --> Controller Class Initialized
INFO - 2023-11-21 11:24:04 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 11:24:04 --> Model "M_produk" initialized
DEBUG - 2023-11-21 11:24:04 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 11:24:04 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 11:24:04 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:24:04 --> Model "M_bank" initialized
INFO - 2023-11-21 11:24:04 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 11:24:04 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 11:24:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 11:24:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-21 11:24:05 --> Final output sent to browser
DEBUG - 2023-11-21 11:24:05 --> Total execution time: 0.3752
ERROR - 2023-11-21 11:32:17 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:32:17 --> Config Class Initialized
INFO - 2023-11-21 11:32:17 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:32:17 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:32:17 --> Utf8 Class Initialized
INFO - 2023-11-21 11:32:17 --> URI Class Initialized
INFO - 2023-11-21 11:32:17 --> Router Class Initialized
INFO - 2023-11-21 11:32:17 --> Output Class Initialized
INFO - 2023-11-21 11:32:17 --> Security Class Initialized
DEBUG - 2023-11-21 11:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:32:17 --> Input Class Initialized
INFO - 2023-11-21 11:32:17 --> Language Class Initialized
INFO - 2023-11-21 11:32:17 --> Loader Class Initialized
INFO - 2023-11-21 11:32:17 --> Helper loaded: url_helper
INFO - 2023-11-21 11:32:17 --> Helper loaded: form_helper
INFO - 2023-11-21 11:32:17 --> Helper loaded: file_helper
INFO - 2023-11-21 11:32:17 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:32:17 --> Form Validation Class Initialized
INFO - 2023-11-21 11:32:17 --> Upload Class Initialized
INFO - 2023-11-21 11:32:17 --> Model "M_auth" initialized
INFO - 2023-11-21 11:32:17 --> Model "M_user" initialized
INFO - 2023-11-21 11:32:17 --> Model "M_produk" initialized
INFO - 2023-11-21 11:32:17 --> Controller Class Initialized
INFO - 2023-11-21 11:32:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-21 11:32:17 --> Final output sent to browser
DEBUG - 2023-11-21 11:32:17 --> Total execution time: 0.0289
ERROR - 2023-11-21 11:32:46 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:32:46 --> Config Class Initialized
INFO - 2023-11-21 11:32:46 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:32:46 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:32:46 --> Utf8 Class Initialized
INFO - 2023-11-21 11:32:46 --> URI Class Initialized
INFO - 2023-11-21 11:32:46 --> Router Class Initialized
INFO - 2023-11-21 11:32:46 --> Output Class Initialized
INFO - 2023-11-21 11:32:46 --> Security Class Initialized
DEBUG - 2023-11-21 11:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:32:46 --> Input Class Initialized
INFO - 2023-11-21 11:32:46 --> Language Class Initialized
INFO - 2023-11-21 11:32:46 --> Loader Class Initialized
INFO - 2023-11-21 11:32:46 --> Helper loaded: url_helper
INFO - 2023-11-21 11:32:46 --> Helper loaded: form_helper
INFO - 2023-11-21 11:32:46 --> Helper loaded: file_helper
INFO - 2023-11-21 11:32:46 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:32:46 --> Form Validation Class Initialized
INFO - 2023-11-21 11:32:46 --> Upload Class Initialized
INFO - 2023-11-21 11:32:46 --> Model "M_auth" initialized
INFO - 2023-11-21 11:32:46 --> Model "M_user" initialized
INFO - 2023-11-21 11:32:46 --> Model "M_produk" initialized
INFO - 2023-11-21 11:32:46 --> Controller Class Initialized
INFO - 2023-11-21 11:32:46 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 11:32:46 --> Model "M_produk" initialized
DEBUG - 2023-11-21 11:32:46 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 11:32:46 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 11:32:46 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:32:46 --> Model "M_bank" initialized
INFO - 2023-11-21 11:32:46 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 11:32:46 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 11:32:47 --> Final output sent to browser
DEBUG - 2023-11-21 11:32:47 --> Total execution time: 0.4101
ERROR - 2023-11-21 11:33:00 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:33:00 --> Config Class Initialized
INFO - 2023-11-21 11:33:00 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:33:00 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:33:00 --> Utf8 Class Initialized
INFO - 2023-11-21 11:33:00 --> URI Class Initialized
INFO - 2023-11-21 11:33:00 --> Router Class Initialized
INFO - 2023-11-21 11:33:00 --> Output Class Initialized
INFO - 2023-11-21 11:33:00 --> Security Class Initialized
DEBUG - 2023-11-21 11:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:33:00 --> Input Class Initialized
INFO - 2023-11-21 11:33:00 --> Language Class Initialized
INFO - 2023-11-21 11:33:00 --> Loader Class Initialized
INFO - 2023-11-21 11:33:00 --> Helper loaded: url_helper
INFO - 2023-11-21 11:33:00 --> Helper loaded: form_helper
INFO - 2023-11-21 11:33:00 --> Helper loaded: file_helper
INFO - 2023-11-21 11:33:00 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:33:00 --> Form Validation Class Initialized
INFO - 2023-11-21 11:33:00 --> Upload Class Initialized
INFO - 2023-11-21 11:33:00 --> Model "M_auth" initialized
INFO - 2023-11-21 11:33:00 --> Model "M_user" initialized
INFO - 2023-11-21 11:33:00 --> Model "M_produk" initialized
INFO - 2023-11-21 11:33:00 --> Controller Class Initialized
INFO - 2023-11-21 11:33:00 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 11:33:00 --> Model "M_produk" initialized
DEBUG - 2023-11-21 11:33:00 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 11:33:00 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 11:33:00 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:33:00 --> Model "M_bank" initialized
INFO - 2023-11-21 11:33:00 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 11:33:00 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 11:33:00 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:33:00 --> Final output sent to browser
DEBUG - 2023-11-21 11:33:00 --> Total execution time: 0.3726
ERROR - 2023-11-21 11:33:09 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:33:09 --> Config Class Initialized
INFO - 2023-11-21 11:33:09 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:33:09 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:33:09 --> Utf8 Class Initialized
INFO - 2023-11-21 11:33:09 --> URI Class Initialized
INFO - 2023-11-21 11:33:09 --> Router Class Initialized
INFO - 2023-11-21 11:33:09 --> Output Class Initialized
INFO - 2023-11-21 11:33:09 --> Security Class Initialized
DEBUG - 2023-11-21 11:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:33:09 --> Input Class Initialized
INFO - 2023-11-21 11:33:09 --> Language Class Initialized
INFO - 2023-11-21 11:33:09 --> Loader Class Initialized
INFO - 2023-11-21 11:33:09 --> Helper loaded: url_helper
INFO - 2023-11-21 11:33:09 --> Helper loaded: form_helper
INFO - 2023-11-21 11:33:09 --> Helper loaded: file_helper
INFO - 2023-11-21 11:33:09 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:33:09 --> Form Validation Class Initialized
INFO - 2023-11-21 11:33:09 --> Upload Class Initialized
INFO - 2023-11-21 11:33:09 --> Model "M_auth" initialized
INFO - 2023-11-21 11:33:09 --> Model "M_user" initialized
INFO - 2023-11-21 11:33:09 --> Model "M_produk" initialized
INFO - 2023-11-21 11:33:09 --> Controller Class Initialized
INFO - 2023-11-21 11:33:09 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 11:33:09 --> Model "M_produk" initialized
DEBUG - 2023-11-21 11:33:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 11:33:09 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 11:33:09 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:33:09 --> Model "M_bank" initialized
INFO - 2023-11-21 11:33:09 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 11:33:09 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 11:33:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 11:33:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-21 11:33:09 --> Final output sent to browser
DEBUG - 2023-11-21 11:33:09 --> Total execution time: 0.3842
ERROR - 2023-11-21 11:33:10 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:33:10 --> Config Class Initialized
INFO - 2023-11-21 11:33:10 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:33:10 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:33:10 --> Utf8 Class Initialized
INFO - 2023-11-21 11:33:10 --> URI Class Initialized
INFO - 2023-11-21 11:33:10 --> Router Class Initialized
INFO - 2023-11-21 11:33:10 --> Output Class Initialized
INFO - 2023-11-21 11:33:10 --> Security Class Initialized
DEBUG - 2023-11-21 11:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:33:10 --> Input Class Initialized
INFO - 2023-11-21 11:33:10 --> Language Class Initialized
INFO - 2023-11-21 11:33:10 --> Loader Class Initialized
INFO - 2023-11-21 11:33:10 --> Helper loaded: url_helper
INFO - 2023-11-21 11:33:10 --> Helper loaded: form_helper
INFO - 2023-11-21 11:33:10 --> Helper loaded: file_helper
INFO - 2023-11-21 11:33:10 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:33:10 --> Form Validation Class Initialized
INFO - 2023-11-21 11:33:10 --> Upload Class Initialized
INFO - 2023-11-21 11:33:10 --> Model "M_auth" initialized
INFO - 2023-11-21 11:33:10 --> Model "M_user" initialized
INFO - 2023-11-21 11:33:10 --> Model "M_produk" initialized
INFO - 2023-11-21 11:33:10 --> Controller Class Initialized
INFO - 2023-11-21 11:33:10 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-21 11:33:10 --> Final output sent to browser
DEBUG - 2023-11-21 11:33:10 --> Total execution time: 0.0029
ERROR - 2023-11-21 11:38:03 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:38:03 --> Config Class Initialized
INFO - 2023-11-21 11:38:03 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:38:03 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:38:03 --> Utf8 Class Initialized
INFO - 2023-11-21 11:38:03 --> URI Class Initialized
DEBUG - 2023-11-21 11:38:03 --> No URI present. Default controller set.
INFO - 2023-11-21 11:38:03 --> Router Class Initialized
INFO - 2023-11-21 11:38:03 --> Output Class Initialized
INFO - 2023-11-21 11:38:03 --> Security Class Initialized
DEBUG - 2023-11-21 11:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:38:03 --> Input Class Initialized
INFO - 2023-11-21 11:38:03 --> Language Class Initialized
INFO - 2023-11-21 11:38:03 --> Loader Class Initialized
INFO - 2023-11-21 11:38:03 --> Helper loaded: url_helper
INFO - 2023-11-21 11:38:03 --> Helper loaded: form_helper
INFO - 2023-11-21 11:38:03 --> Helper loaded: file_helper
INFO - 2023-11-21 11:38:03 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:38:03 --> Form Validation Class Initialized
INFO - 2023-11-21 11:38:03 --> Upload Class Initialized
INFO - 2023-11-21 11:38:03 --> Model "M_auth" initialized
INFO - 2023-11-21 11:38:03 --> Model "M_user" initialized
INFO - 2023-11-21 11:38:03 --> Model "M_produk" initialized
INFO - 2023-11-21 11:38:03 --> Controller Class Initialized
INFO - 2023-11-21 11:38:03 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 11:38:03 --> Model "M_produk" initialized
DEBUG - 2023-11-21 11:38:03 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 11:38:03 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 11:38:03 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:38:03 --> Model "M_bank" initialized
INFO - 2023-11-21 11:38:03 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 11:38:03 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 11:38:03 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 11:38:03 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-21 11:38:03 --> Final output sent to browser
DEBUG - 2023-11-21 11:38:03 --> Total execution time: 0.0054
ERROR - 2023-11-21 11:38:06 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:38:06 --> Config Class Initialized
INFO - 2023-11-21 11:38:06 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:38:06 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:38:06 --> Utf8 Class Initialized
INFO - 2023-11-21 11:38:06 --> URI Class Initialized
INFO - 2023-11-21 11:38:06 --> Router Class Initialized
INFO - 2023-11-21 11:38:06 --> Output Class Initialized
INFO - 2023-11-21 11:38:06 --> Security Class Initialized
DEBUG - 2023-11-21 11:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:38:06 --> Input Class Initialized
INFO - 2023-11-21 11:38:06 --> Language Class Initialized
INFO - 2023-11-21 11:38:06 --> Loader Class Initialized
INFO - 2023-11-21 11:38:06 --> Helper loaded: url_helper
INFO - 2023-11-21 11:38:06 --> Helper loaded: form_helper
INFO - 2023-11-21 11:38:06 --> Helper loaded: file_helper
INFO - 2023-11-21 11:38:06 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:38:06 --> Form Validation Class Initialized
INFO - 2023-11-21 11:38:06 --> Upload Class Initialized
INFO - 2023-11-21 11:38:06 --> Model "M_auth" initialized
INFO - 2023-11-21 11:38:06 --> Model "M_user" initialized
INFO - 2023-11-21 11:38:06 --> Model "M_produk" initialized
INFO - 2023-11-21 11:38:06 --> Controller Class Initialized
INFO - 2023-11-21 11:38:06 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 11:38:06 --> Model "M_produk" initialized
DEBUG - 2023-11-21 11:38:06 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 11:38:06 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 11:38:06 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:38:06 --> Model "M_bank" initialized
INFO - 2023-11-21 11:38:06 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 11:38:06 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 11:38:06 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 11:38:06 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-21 11:38:06 --> Final output sent to browser
DEBUG - 2023-11-21 11:38:06 --> Total execution time: 0.0050
ERROR - 2023-11-21 11:38:13 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:38:13 --> Config Class Initialized
INFO - 2023-11-21 11:38:13 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:38:13 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:38:13 --> Utf8 Class Initialized
INFO - 2023-11-21 11:38:13 --> URI Class Initialized
INFO - 2023-11-21 11:38:13 --> Router Class Initialized
INFO - 2023-11-21 11:38:13 --> Output Class Initialized
INFO - 2023-11-21 11:38:13 --> Security Class Initialized
DEBUG - 2023-11-21 11:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:38:13 --> Input Class Initialized
INFO - 2023-11-21 11:38:13 --> Language Class Initialized
INFO - 2023-11-21 11:38:13 --> Loader Class Initialized
INFO - 2023-11-21 11:38:13 --> Helper loaded: url_helper
INFO - 2023-11-21 11:38:13 --> Helper loaded: form_helper
INFO - 2023-11-21 11:38:13 --> Helper loaded: file_helper
INFO - 2023-11-21 11:38:13 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:38:13 --> Form Validation Class Initialized
INFO - 2023-11-21 11:38:13 --> Upload Class Initialized
INFO - 2023-11-21 11:38:13 --> Model "M_auth" initialized
INFO - 2023-11-21 11:38:13 --> Model "M_user" initialized
INFO - 2023-11-21 11:38:13 --> Model "M_produk" initialized
INFO - 2023-11-21 11:38:13 --> Controller Class Initialized
INFO - 2023-11-21 11:38:13 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 11:38:13 --> Model "M_produk" initialized
DEBUG - 2023-11-21 11:38:13 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 11:38:13 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 11:38:13 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:38:13 --> Model "M_bank" initialized
INFO - 2023-11-21 11:38:13 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 11:38:13 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 11:38:13 --> Email Class Initialized
INFO - 2023-11-21 11:38:14 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-11-21 11:38:17 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:38:17 --> Config Class Initialized
INFO - 2023-11-21 11:38:17 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:38:17 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:38:17 --> Utf8 Class Initialized
INFO - 2023-11-21 11:38:17 --> URI Class Initialized
INFO - 2023-11-21 11:38:17 --> Router Class Initialized
INFO - 2023-11-21 11:38:17 --> Output Class Initialized
INFO - 2023-11-21 11:38:17 --> Security Class Initialized
DEBUG - 2023-11-21 11:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:38:17 --> Input Class Initialized
INFO - 2023-11-21 11:38:17 --> Language Class Initialized
INFO - 2023-11-21 11:38:17 --> Loader Class Initialized
INFO - 2023-11-21 11:38:17 --> Helper loaded: url_helper
INFO - 2023-11-21 11:38:17 --> Helper loaded: form_helper
INFO - 2023-11-21 11:38:17 --> Helper loaded: file_helper
INFO - 2023-11-21 11:38:17 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:38:17 --> Form Validation Class Initialized
INFO - 2023-11-21 11:38:17 --> Upload Class Initialized
INFO - 2023-11-21 11:38:17 --> Model "M_auth" initialized
INFO - 2023-11-21 11:38:17 --> Model "M_user" initialized
INFO - 2023-11-21 11:38:17 --> Model "M_produk" initialized
INFO - 2023-11-21 11:38:17 --> Controller Class Initialized
INFO - 2023-11-21 11:38:17 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 11:38:17 --> Model "M_produk" initialized
DEBUG - 2023-11-21 11:38:17 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 11:38:17 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 11:38:17 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:38:17 --> Model "M_bank" initialized
INFO - 2023-11-21 11:38:17 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 11:38:17 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 11:38:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 11:38:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-21 11:38:17 --> Final output sent to browser
DEBUG - 2023-11-21 11:38:17 --> Total execution time: 0.2299
ERROR - 2023-11-21 11:38:56 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:38:56 --> Config Class Initialized
INFO - 2023-11-21 11:38:56 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:38:56 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:38:56 --> Utf8 Class Initialized
INFO - 2023-11-21 11:38:56 --> URI Class Initialized
INFO - 2023-11-21 11:38:56 --> Router Class Initialized
INFO - 2023-11-21 11:38:56 --> Output Class Initialized
INFO - 2023-11-21 11:38:56 --> Security Class Initialized
DEBUG - 2023-11-21 11:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:38:56 --> Input Class Initialized
INFO - 2023-11-21 11:38:56 --> Language Class Initialized
INFO - 2023-11-21 11:38:56 --> Loader Class Initialized
INFO - 2023-11-21 11:38:56 --> Helper loaded: url_helper
INFO - 2023-11-21 11:38:56 --> Helper loaded: form_helper
INFO - 2023-11-21 11:38:56 --> Helper loaded: file_helper
INFO - 2023-11-21 11:38:56 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:38:56 --> Form Validation Class Initialized
INFO - 2023-11-21 11:38:56 --> Upload Class Initialized
INFO - 2023-11-21 11:38:56 --> Model "M_auth" initialized
INFO - 2023-11-21 11:38:56 --> Model "M_user" initialized
INFO - 2023-11-21 11:38:56 --> Model "M_produk" initialized
INFO - 2023-11-21 11:38:56 --> Controller Class Initialized
INFO - 2023-11-21 11:38:56 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 11:38:56 --> Model "M_produk" initialized
DEBUG - 2023-11-21 11:38:56 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 11:38:56 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 11:38:56 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:38:56 --> Model "M_bank" initialized
INFO - 2023-11-21 11:38:56 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 11:38:56 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 11:38:56 --> Final output sent to browser
DEBUG - 2023-11-21 11:38:56 --> Total execution time: 0.4098
ERROR - 2023-11-21 11:40:36 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:40:36 --> Config Class Initialized
INFO - 2023-11-21 11:40:36 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:40:36 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:40:36 --> Utf8 Class Initialized
INFO - 2023-11-21 11:40:36 --> URI Class Initialized
INFO - 2023-11-21 11:40:36 --> Router Class Initialized
INFO - 2023-11-21 11:40:36 --> Output Class Initialized
INFO - 2023-11-21 11:40:36 --> Security Class Initialized
DEBUG - 2023-11-21 11:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:40:36 --> Input Class Initialized
INFO - 2023-11-21 11:40:36 --> Language Class Initialized
INFO - 2023-11-21 11:40:36 --> Loader Class Initialized
INFO - 2023-11-21 11:40:36 --> Helper loaded: url_helper
INFO - 2023-11-21 11:40:36 --> Helper loaded: form_helper
INFO - 2023-11-21 11:40:36 --> Helper loaded: file_helper
INFO - 2023-11-21 11:40:36 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:40:36 --> Form Validation Class Initialized
INFO - 2023-11-21 11:40:36 --> Upload Class Initialized
INFO - 2023-11-21 11:40:36 --> Model "M_auth" initialized
INFO - 2023-11-21 11:40:36 --> Model "M_user" initialized
INFO - 2023-11-21 11:40:36 --> Model "M_produk" initialized
INFO - 2023-11-21 11:40:36 --> Controller Class Initialized
INFO - 2023-11-21 11:40:36 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 11:40:36 --> Model "M_produk" initialized
DEBUG - 2023-11-21 11:40:36 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 11:40:36 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 11:40:36 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:40:36 --> Model "M_bank" initialized
INFO - 2023-11-21 11:40:36 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 11:40:36 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 11:40:36 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:40:36 --> Final output sent to browser
DEBUG - 2023-11-21 11:40:36 --> Total execution time: 0.3852
ERROR - 2023-11-21 11:40:43 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:40:43 --> Config Class Initialized
INFO - 2023-11-21 11:40:43 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:40:43 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:40:43 --> Utf8 Class Initialized
INFO - 2023-11-21 11:40:43 --> URI Class Initialized
INFO - 2023-11-21 11:40:43 --> Router Class Initialized
INFO - 2023-11-21 11:40:43 --> Output Class Initialized
INFO - 2023-11-21 11:40:43 --> Security Class Initialized
DEBUG - 2023-11-21 11:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:40:43 --> Input Class Initialized
INFO - 2023-11-21 11:40:43 --> Language Class Initialized
INFO - 2023-11-21 11:40:43 --> Loader Class Initialized
INFO - 2023-11-21 11:40:43 --> Helper loaded: url_helper
INFO - 2023-11-21 11:40:43 --> Helper loaded: form_helper
INFO - 2023-11-21 11:40:43 --> Helper loaded: file_helper
INFO - 2023-11-21 11:40:43 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:40:43 --> Form Validation Class Initialized
INFO - 2023-11-21 11:40:43 --> Upload Class Initialized
INFO - 2023-11-21 11:40:43 --> Model "M_auth" initialized
INFO - 2023-11-21 11:40:43 --> Model "M_user" initialized
INFO - 2023-11-21 11:40:43 --> Model "M_produk" initialized
INFO - 2023-11-21 11:40:43 --> Controller Class Initialized
INFO - 2023-11-21 11:40:43 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 11:40:43 --> Model "M_produk" initialized
DEBUG - 2023-11-21 11:40:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 11:40:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 11:40:43 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:40:43 --> Model "M_bank" initialized
INFO - 2023-11-21 11:40:43 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 11:40:43 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 11:40:43 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 11:40:43 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-21 11:40:43 --> Final output sent to browser
DEBUG - 2023-11-21 11:40:43 --> Total execution time: 0.3751
ERROR - 2023-11-21 11:41:08 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:41:08 --> Config Class Initialized
INFO - 2023-11-21 11:41:08 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:41:08 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:41:08 --> Utf8 Class Initialized
INFO - 2023-11-21 11:41:08 --> URI Class Initialized
DEBUG - 2023-11-21 11:41:08 --> No URI present. Default controller set.
INFO - 2023-11-21 11:41:08 --> Router Class Initialized
INFO - 2023-11-21 11:41:08 --> Output Class Initialized
INFO - 2023-11-21 11:41:08 --> Security Class Initialized
DEBUG - 2023-11-21 11:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:41:08 --> Input Class Initialized
INFO - 2023-11-21 11:41:08 --> Language Class Initialized
INFO - 2023-11-21 11:41:08 --> Loader Class Initialized
INFO - 2023-11-21 11:41:08 --> Helper loaded: url_helper
INFO - 2023-11-21 11:41:08 --> Helper loaded: form_helper
INFO - 2023-11-21 11:41:08 --> Helper loaded: file_helper
INFO - 2023-11-21 11:41:08 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:41:08 --> Form Validation Class Initialized
INFO - 2023-11-21 11:41:08 --> Upload Class Initialized
INFO - 2023-11-21 11:41:08 --> Model "M_auth" initialized
INFO - 2023-11-21 11:41:08 --> Model "M_user" initialized
INFO - 2023-11-21 11:41:08 --> Model "M_produk" initialized
INFO - 2023-11-21 11:41:08 --> Controller Class Initialized
INFO - 2023-11-21 11:41:08 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 11:41:08 --> Model "M_produk" initialized
DEBUG - 2023-11-21 11:41:08 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 11:41:08 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 11:41:08 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:41:08 --> Model "M_bank" initialized
INFO - 2023-11-21 11:41:08 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 11:41:08 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 11:41:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 11:41:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-21 11:41:08 --> Final output sent to browser
DEBUG - 2023-11-21 11:41:08 --> Total execution time: 0.0043
ERROR - 2023-11-21 11:41:12 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:41:12 --> Config Class Initialized
INFO - 2023-11-21 11:41:12 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:41:12 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:41:12 --> Utf8 Class Initialized
INFO - 2023-11-21 11:41:12 --> URI Class Initialized
INFO - 2023-11-21 11:41:12 --> Router Class Initialized
INFO - 2023-11-21 11:41:12 --> Output Class Initialized
INFO - 2023-11-21 11:41:12 --> Security Class Initialized
DEBUG - 2023-11-21 11:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:41:12 --> Input Class Initialized
INFO - 2023-11-21 11:41:12 --> Language Class Initialized
INFO - 2023-11-21 11:41:12 --> Loader Class Initialized
INFO - 2023-11-21 11:41:12 --> Helper loaded: url_helper
INFO - 2023-11-21 11:41:12 --> Helper loaded: form_helper
INFO - 2023-11-21 11:41:12 --> Helper loaded: file_helper
INFO - 2023-11-21 11:41:12 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:41:12 --> Form Validation Class Initialized
INFO - 2023-11-21 11:41:12 --> Upload Class Initialized
INFO - 2023-11-21 11:41:12 --> Model "M_auth" initialized
INFO - 2023-11-21 11:41:12 --> Model "M_user" initialized
INFO - 2023-11-21 11:41:12 --> Model "M_produk" initialized
INFO - 2023-11-21 11:41:12 --> Controller Class Initialized
INFO - 2023-11-21 11:41:12 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 11:41:12 --> Model "M_produk" initialized
DEBUG - 2023-11-21 11:41:12 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 11:41:12 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 11:41:12 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:41:12 --> Model "M_bank" initialized
INFO - 2023-11-21 11:41:12 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 11:41:12 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 11:41:12 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 11:41:12 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-21 11:41:12 --> Final output sent to browser
DEBUG - 2023-11-21 11:41:12 --> Total execution time: 0.0047
ERROR - 2023-11-21 11:41:31 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:41:31 --> Config Class Initialized
INFO - 2023-11-21 11:41:31 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:41:31 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:41:31 --> Utf8 Class Initialized
INFO - 2023-11-21 11:41:31 --> URI Class Initialized
INFO - 2023-11-21 11:41:31 --> Router Class Initialized
INFO - 2023-11-21 11:41:31 --> Output Class Initialized
INFO - 2023-11-21 11:41:31 --> Security Class Initialized
DEBUG - 2023-11-21 11:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:41:31 --> Input Class Initialized
INFO - 2023-11-21 11:41:31 --> Language Class Initialized
INFO - 2023-11-21 11:41:31 --> Loader Class Initialized
INFO - 2023-11-21 11:41:31 --> Helper loaded: url_helper
INFO - 2023-11-21 11:41:31 --> Helper loaded: form_helper
INFO - 2023-11-21 11:41:31 --> Helper loaded: file_helper
INFO - 2023-11-21 11:41:31 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:41:31 --> Form Validation Class Initialized
INFO - 2023-11-21 11:41:31 --> Upload Class Initialized
INFO - 2023-11-21 11:41:31 --> Model "M_auth" initialized
INFO - 2023-11-21 11:41:31 --> Model "M_user" initialized
INFO - 2023-11-21 11:41:31 --> Model "M_produk" initialized
INFO - 2023-11-21 11:41:31 --> Controller Class Initialized
INFO - 2023-11-21 11:41:31 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 11:41:31 --> Model "M_produk" initialized
DEBUG - 2023-11-21 11:41:31 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 11:41:31 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 11:41:31 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:41:31 --> Model "M_bank" initialized
INFO - 2023-11-21 11:41:31 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 11:41:31 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 11:41:31 --> Email Class Initialized
INFO - 2023-11-21 11:41:32 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-11-21 11:41:35 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:41:35 --> Config Class Initialized
INFO - 2023-11-21 11:41:35 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:41:35 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:41:35 --> Utf8 Class Initialized
INFO - 2023-11-21 11:41:35 --> URI Class Initialized
INFO - 2023-11-21 11:41:35 --> Router Class Initialized
INFO - 2023-11-21 11:41:35 --> Output Class Initialized
INFO - 2023-11-21 11:41:35 --> Security Class Initialized
DEBUG - 2023-11-21 11:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:41:35 --> Input Class Initialized
INFO - 2023-11-21 11:41:35 --> Language Class Initialized
INFO - 2023-11-21 11:41:35 --> Loader Class Initialized
INFO - 2023-11-21 11:41:35 --> Helper loaded: url_helper
INFO - 2023-11-21 11:41:35 --> Helper loaded: form_helper
INFO - 2023-11-21 11:41:35 --> Helper loaded: file_helper
INFO - 2023-11-21 11:41:35 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:41:35 --> Form Validation Class Initialized
INFO - 2023-11-21 11:41:35 --> Upload Class Initialized
INFO - 2023-11-21 11:41:35 --> Model "M_auth" initialized
INFO - 2023-11-21 11:41:35 --> Model "M_user" initialized
INFO - 2023-11-21 11:41:35 --> Model "M_produk" initialized
INFO - 2023-11-21 11:41:35 --> Controller Class Initialized
INFO - 2023-11-21 11:41:35 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 11:41:35 --> Model "M_produk" initialized
DEBUG - 2023-11-21 11:41:35 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 11:41:35 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 11:41:35 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:41:35 --> Model "M_bank" initialized
INFO - 2023-11-21 11:41:35 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 11:41:35 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
ERROR - 2023-11-21 11:41:35 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:41:35 --> Config Class Initialized
INFO - 2023-11-21 11:41:35 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:41:35 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:41:35 --> Utf8 Class Initialized
INFO - 2023-11-21 11:41:35 --> URI Class Initialized
DEBUG - 2023-11-21 11:41:35 --> No URI present. Default controller set.
INFO - 2023-11-21 11:41:35 --> Router Class Initialized
INFO - 2023-11-21 11:41:35 --> Output Class Initialized
INFO - 2023-11-21 11:41:35 --> Security Class Initialized
DEBUG - 2023-11-21 11:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:41:35 --> Input Class Initialized
INFO - 2023-11-21 11:41:35 --> Language Class Initialized
INFO - 2023-11-21 11:41:35 --> Loader Class Initialized
INFO - 2023-11-21 11:41:35 --> Helper loaded: url_helper
INFO - 2023-11-21 11:41:35 --> Helper loaded: form_helper
INFO - 2023-11-21 11:41:35 --> Helper loaded: file_helper
INFO - 2023-11-21 11:41:35 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:41:35 --> Form Validation Class Initialized
INFO - 2023-11-21 11:41:35 --> Upload Class Initialized
INFO - 2023-11-21 11:41:35 --> Model "M_auth" initialized
INFO - 2023-11-21 11:41:35 --> Model "M_user" initialized
INFO - 2023-11-21 11:41:35 --> Model "M_produk" initialized
INFO - 2023-11-21 11:41:35 --> Controller Class Initialized
INFO - 2023-11-21 11:41:35 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 11:41:35 --> Model "M_produk" initialized
DEBUG - 2023-11-21 11:41:35 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 11:41:35 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 11:41:35 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:41:35 --> Model "M_bank" initialized
INFO - 2023-11-21 11:41:35 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 11:41:35 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 11:41:35 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 11:41:35 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-21 11:41:35 --> Final output sent to browser
DEBUG - 2023-11-21 11:41:35 --> Total execution time: 0.0038
INFO - 2023-11-21 11:41:35 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 11:41:35 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-21 11:41:35 --> Final output sent to browser
DEBUG - 2023-11-21 11:41:35 --> Total execution time: 0.3733
ERROR - 2023-11-21 11:41:50 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:41:50 --> Config Class Initialized
INFO - 2023-11-21 11:41:50 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:41:50 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:41:50 --> Utf8 Class Initialized
INFO - 2023-11-21 11:41:50 --> URI Class Initialized
INFO - 2023-11-21 11:41:50 --> Router Class Initialized
INFO - 2023-11-21 11:41:50 --> Output Class Initialized
INFO - 2023-11-21 11:41:50 --> Security Class Initialized
DEBUG - 2023-11-21 11:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:41:50 --> Input Class Initialized
INFO - 2023-11-21 11:41:50 --> Language Class Initialized
INFO - 2023-11-21 11:41:50 --> Loader Class Initialized
INFO - 2023-11-21 11:41:50 --> Helper loaded: url_helper
INFO - 2023-11-21 11:41:50 --> Helper loaded: form_helper
INFO - 2023-11-21 11:41:50 --> Helper loaded: file_helper
INFO - 2023-11-21 11:41:50 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:41:50 --> Form Validation Class Initialized
INFO - 2023-11-21 11:41:50 --> Upload Class Initialized
INFO - 2023-11-21 11:41:50 --> Model "M_auth" initialized
INFO - 2023-11-21 11:41:50 --> Model "M_user" initialized
INFO - 2023-11-21 11:41:50 --> Model "M_produk" initialized
INFO - 2023-11-21 11:41:50 --> Controller Class Initialized
INFO - 2023-11-21 11:41:50 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 11:41:50 --> Model "M_produk" initialized
DEBUG - 2023-11-21 11:41:50 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 11:41:50 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 11:41:50 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:41:50 --> Model "M_bank" initialized
INFO - 2023-11-21 11:41:50 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 11:41:50 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 11:41:50 --> Final output sent to browser
DEBUG - 2023-11-21 11:41:50 --> Total execution time: 0.2320
ERROR - 2023-11-21 11:41:58 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:41:58 --> Config Class Initialized
INFO - 2023-11-21 11:41:58 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:41:58 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:41:58 --> Utf8 Class Initialized
INFO - 2023-11-21 11:41:58 --> URI Class Initialized
INFO - 2023-11-21 11:41:58 --> Router Class Initialized
INFO - 2023-11-21 11:41:58 --> Output Class Initialized
INFO - 2023-11-21 11:41:58 --> Security Class Initialized
DEBUG - 2023-11-21 11:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:41:58 --> Input Class Initialized
INFO - 2023-11-21 11:41:58 --> Language Class Initialized
INFO - 2023-11-21 11:41:58 --> Loader Class Initialized
INFO - 2023-11-21 11:41:58 --> Helper loaded: url_helper
INFO - 2023-11-21 11:41:58 --> Helper loaded: form_helper
INFO - 2023-11-21 11:41:58 --> Helper loaded: file_helper
INFO - 2023-11-21 11:41:58 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:41:58 --> Form Validation Class Initialized
INFO - 2023-11-21 11:41:58 --> Upload Class Initialized
INFO - 2023-11-21 11:41:58 --> Model "M_auth" initialized
INFO - 2023-11-21 11:41:58 --> Model "M_user" initialized
INFO - 2023-11-21 11:41:58 --> Model "M_produk" initialized
INFO - 2023-11-21 11:41:58 --> Controller Class Initialized
INFO - 2023-11-21 11:41:58 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 11:41:58 --> Model "M_produk" initialized
DEBUG - 2023-11-21 11:41:58 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 11:41:58 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 11:41:58 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:41:58 --> Model "M_bank" initialized
INFO - 2023-11-21 11:41:58 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 11:41:58 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 11:41:58 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:41:58 --> Final output sent to browser
DEBUG - 2023-11-21 11:41:58 --> Total execution time: 0.3207
ERROR - 2023-11-21 11:42:25 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:42:25 --> Config Class Initialized
INFO - 2023-11-21 11:42:25 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:42:25 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:42:25 --> Utf8 Class Initialized
INFO - 2023-11-21 11:42:25 --> URI Class Initialized
INFO - 2023-11-21 11:42:25 --> Router Class Initialized
INFO - 2023-11-21 11:42:25 --> Output Class Initialized
INFO - 2023-11-21 11:42:25 --> Security Class Initialized
DEBUG - 2023-11-21 11:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:42:25 --> Input Class Initialized
INFO - 2023-11-21 11:42:25 --> Language Class Initialized
INFO - 2023-11-21 11:42:25 --> Loader Class Initialized
INFO - 2023-11-21 11:42:25 --> Helper loaded: url_helper
INFO - 2023-11-21 11:42:25 --> Helper loaded: form_helper
INFO - 2023-11-21 11:42:25 --> Helper loaded: file_helper
INFO - 2023-11-21 11:42:25 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:42:25 --> Form Validation Class Initialized
INFO - 2023-11-21 11:42:25 --> Upload Class Initialized
INFO - 2023-11-21 11:42:25 --> Model "M_auth" initialized
INFO - 2023-11-21 11:42:25 --> Model "M_user" initialized
INFO - 2023-11-21 11:42:25 --> Model "M_produk" initialized
INFO - 2023-11-21 11:42:25 --> Controller Class Initialized
INFO - 2023-11-21 11:42:25 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 11:42:25 --> Model "M_produk" initialized
DEBUG - 2023-11-21 11:42:25 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 11:42:25 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 11:42:25 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:42:25 --> Model "M_bank" initialized
INFO - 2023-11-21 11:42:25 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 11:42:25 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 11:42:25 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 11:42:25 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-21 11:42:25 --> Final output sent to browser
DEBUG - 2023-11-21 11:42:25 --> Total execution time: 0.3564
ERROR - 2023-11-21 11:42:58 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:42:58 --> Config Class Initialized
INFO - 2023-11-21 11:42:58 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:42:58 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:42:58 --> Utf8 Class Initialized
INFO - 2023-11-21 11:42:58 --> URI Class Initialized
DEBUG - 2023-11-21 11:42:58 --> No URI present. Default controller set.
INFO - 2023-11-21 11:42:58 --> Router Class Initialized
INFO - 2023-11-21 11:42:58 --> Output Class Initialized
INFO - 2023-11-21 11:42:58 --> Security Class Initialized
DEBUG - 2023-11-21 11:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:42:58 --> Input Class Initialized
INFO - 2023-11-21 11:42:58 --> Language Class Initialized
INFO - 2023-11-21 11:42:58 --> Loader Class Initialized
INFO - 2023-11-21 11:42:58 --> Helper loaded: url_helper
INFO - 2023-11-21 11:42:58 --> Helper loaded: form_helper
INFO - 2023-11-21 11:42:58 --> Helper loaded: file_helper
INFO - 2023-11-21 11:42:58 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:42:58 --> Form Validation Class Initialized
INFO - 2023-11-21 11:42:58 --> Upload Class Initialized
INFO - 2023-11-21 11:42:58 --> Model "M_auth" initialized
INFO - 2023-11-21 11:42:58 --> Model "M_user" initialized
INFO - 2023-11-21 11:42:58 --> Model "M_produk" initialized
INFO - 2023-11-21 11:42:58 --> Controller Class Initialized
INFO - 2023-11-21 11:42:58 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 11:42:58 --> Model "M_produk" initialized
DEBUG - 2023-11-21 11:42:58 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 11:42:58 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 11:42:58 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:42:58 --> Model "M_bank" initialized
INFO - 2023-11-21 11:42:58 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 11:42:58 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 11:42:58 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 11:42:58 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-21 11:42:58 --> Final output sent to browser
DEBUG - 2023-11-21 11:42:58 --> Total execution time: 0.0038
ERROR - 2023-11-21 11:43:01 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:43:01 --> Config Class Initialized
INFO - 2023-11-21 11:43:01 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:43:01 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:43:01 --> Utf8 Class Initialized
INFO - 2023-11-21 11:43:01 --> URI Class Initialized
INFO - 2023-11-21 11:43:01 --> Router Class Initialized
INFO - 2023-11-21 11:43:01 --> Output Class Initialized
INFO - 2023-11-21 11:43:01 --> Security Class Initialized
DEBUG - 2023-11-21 11:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:43:01 --> Input Class Initialized
INFO - 2023-11-21 11:43:01 --> Language Class Initialized
INFO - 2023-11-21 11:43:01 --> Loader Class Initialized
INFO - 2023-11-21 11:43:01 --> Helper loaded: url_helper
INFO - 2023-11-21 11:43:01 --> Helper loaded: form_helper
INFO - 2023-11-21 11:43:01 --> Helper loaded: file_helper
INFO - 2023-11-21 11:43:01 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:43:01 --> Form Validation Class Initialized
INFO - 2023-11-21 11:43:01 --> Upload Class Initialized
INFO - 2023-11-21 11:43:01 --> Model "M_auth" initialized
INFO - 2023-11-21 11:43:01 --> Model "M_user" initialized
INFO - 2023-11-21 11:43:01 --> Model "M_produk" initialized
INFO - 2023-11-21 11:43:01 --> Controller Class Initialized
INFO - 2023-11-21 11:43:01 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 11:43:01 --> Model "M_produk" initialized
DEBUG - 2023-11-21 11:43:01 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 11:43:01 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 11:43:01 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:43:01 --> Model "M_bank" initialized
INFO - 2023-11-21 11:43:01 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 11:43:01 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 11:43:01 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 11:43:01 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-21 11:43:01 --> Final output sent to browser
DEBUG - 2023-11-21 11:43:01 --> Total execution time: 0.0043
ERROR - 2023-11-21 11:43:08 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:43:08 --> Config Class Initialized
INFO - 2023-11-21 11:43:08 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:43:08 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:43:08 --> Utf8 Class Initialized
INFO - 2023-11-21 11:43:08 --> URI Class Initialized
INFO - 2023-11-21 11:43:08 --> Router Class Initialized
INFO - 2023-11-21 11:43:08 --> Output Class Initialized
INFO - 2023-11-21 11:43:08 --> Security Class Initialized
DEBUG - 2023-11-21 11:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:43:08 --> Input Class Initialized
INFO - 2023-11-21 11:43:08 --> Language Class Initialized
INFO - 2023-11-21 11:43:08 --> Loader Class Initialized
INFO - 2023-11-21 11:43:08 --> Helper loaded: url_helper
INFO - 2023-11-21 11:43:08 --> Helper loaded: form_helper
INFO - 2023-11-21 11:43:08 --> Helper loaded: file_helper
INFO - 2023-11-21 11:43:08 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:43:08 --> Form Validation Class Initialized
INFO - 2023-11-21 11:43:08 --> Upload Class Initialized
INFO - 2023-11-21 11:43:08 --> Model "M_auth" initialized
INFO - 2023-11-21 11:43:08 --> Model "M_user" initialized
INFO - 2023-11-21 11:43:08 --> Model "M_produk" initialized
INFO - 2023-11-21 11:43:08 --> Controller Class Initialized
INFO - 2023-11-21 11:43:08 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 11:43:08 --> Model "M_produk" initialized
DEBUG - 2023-11-21 11:43:08 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 11:43:08 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 11:43:08 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:43:08 --> Model "M_bank" initialized
INFO - 2023-11-21 11:43:08 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 11:43:08 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 11:43:08 --> Email Class Initialized
INFO - 2023-11-21 11:43:09 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-11-21 11:43:12 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 11:43:12 --> Config Class Initialized
INFO - 2023-11-21 11:43:12 --> Hooks Class Initialized
DEBUG - 2023-11-21 11:43:12 --> UTF-8 Support Enabled
INFO - 2023-11-21 11:43:12 --> Utf8 Class Initialized
INFO - 2023-11-21 11:43:12 --> URI Class Initialized
INFO - 2023-11-21 11:43:12 --> Router Class Initialized
INFO - 2023-11-21 11:43:12 --> Output Class Initialized
INFO - 2023-11-21 11:43:12 --> Security Class Initialized
DEBUG - 2023-11-21 11:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 11:43:12 --> Input Class Initialized
INFO - 2023-11-21 11:43:12 --> Language Class Initialized
INFO - 2023-11-21 11:43:12 --> Loader Class Initialized
INFO - 2023-11-21 11:43:12 --> Helper loaded: url_helper
INFO - 2023-11-21 11:43:12 --> Helper loaded: form_helper
INFO - 2023-11-21 11:43:12 --> Helper loaded: file_helper
INFO - 2023-11-21 11:43:12 --> Database Driver Class Initialized
DEBUG - 2023-11-21 11:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 11:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 11:43:12 --> Form Validation Class Initialized
INFO - 2023-11-21 11:43:12 --> Upload Class Initialized
INFO - 2023-11-21 11:43:12 --> Model "M_auth" initialized
INFO - 2023-11-21 11:43:12 --> Model "M_user" initialized
INFO - 2023-11-21 11:43:12 --> Model "M_produk" initialized
INFO - 2023-11-21 11:43:12 --> Controller Class Initialized
INFO - 2023-11-21 11:43:12 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 11:43:12 --> Model "M_produk" initialized
DEBUG - 2023-11-21 11:43:12 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 11:43:12 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 11:43:12 --> Model "M_transaksi" initialized
INFO - 2023-11-21 11:43:12 --> Model "M_bank" initialized
INFO - 2023-11-21 11:43:12 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 11:43:12 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 11:43:12 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 11:43:12 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-21 11:43:12 --> Final output sent to browser
DEBUG - 2023-11-21 11:43:12 --> Total execution time: 0.4199
ERROR - 2023-11-21 12:14:58 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 12:14:58 --> Config Class Initialized
INFO - 2023-11-21 12:14:58 --> Hooks Class Initialized
DEBUG - 2023-11-21 12:14:58 --> UTF-8 Support Enabled
INFO - 2023-11-21 12:14:58 --> Utf8 Class Initialized
INFO - 2023-11-21 12:14:58 --> URI Class Initialized
INFO - 2023-11-21 12:14:58 --> Router Class Initialized
INFO - 2023-11-21 12:14:58 --> Output Class Initialized
INFO - 2023-11-21 12:14:58 --> Security Class Initialized
DEBUG - 2023-11-21 12:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 12:14:58 --> Input Class Initialized
INFO - 2023-11-21 12:14:58 --> Language Class Initialized
INFO - 2023-11-21 12:14:58 --> Loader Class Initialized
INFO - 2023-11-21 12:14:58 --> Helper loaded: url_helper
INFO - 2023-11-21 12:14:58 --> Helper loaded: form_helper
INFO - 2023-11-21 12:14:58 --> Helper loaded: file_helper
INFO - 2023-11-21 12:14:58 --> Database Driver Class Initialized
DEBUG - 2023-11-21 12:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 12:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 12:14:58 --> Form Validation Class Initialized
INFO - 2023-11-21 12:14:58 --> Upload Class Initialized
INFO - 2023-11-21 12:14:58 --> Model "M_auth" initialized
INFO - 2023-11-21 12:14:58 --> Model "M_user" initialized
INFO - 2023-11-21 12:14:58 --> Model "M_produk" initialized
INFO - 2023-11-21 12:14:58 --> Controller Class Initialized
INFO - 2023-11-21 12:14:58 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-21 12:14:58 --> Final output sent to browser
DEBUG - 2023-11-21 12:14:58 --> Total execution time: 0.0264
ERROR - 2023-11-21 12:16:07 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 12:16:07 --> Config Class Initialized
INFO - 2023-11-21 12:16:07 --> Hooks Class Initialized
DEBUG - 2023-11-21 12:16:07 --> UTF-8 Support Enabled
INFO - 2023-11-21 12:16:07 --> Utf8 Class Initialized
INFO - 2023-11-21 12:16:07 --> URI Class Initialized
INFO - 2023-11-21 12:16:07 --> Router Class Initialized
INFO - 2023-11-21 12:16:07 --> Output Class Initialized
INFO - 2023-11-21 12:16:07 --> Security Class Initialized
DEBUG - 2023-11-21 12:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 12:16:07 --> Input Class Initialized
INFO - 2023-11-21 12:16:07 --> Language Class Initialized
INFO - 2023-11-21 12:16:07 --> Loader Class Initialized
INFO - 2023-11-21 12:16:07 --> Helper loaded: url_helper
INFO - 2023-11-21 12:16:07 --> Helper loaded: form_helper
INFO - 2023-11-21 12:16:07 --> Helper loaded: file_helper
INFO - 2023-11-21 12:16:07 --> Database Driver Class Initialized
DEBUG - 2023-11-21 12:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 12:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 12:16:07 --> Form Validation Class Initialized
INFO - 2023-11-21 12:16:07 --> Upload Class Initialized
INFO - 2023-11-21 12:16:07 --> Model "M_auth" initialized
INFO - 2023-11-21 12:16:07 --> Model "M_user" initialized
INFO - 2023-11-21 12:16:07 --> Model "M_produk" initialized
INFO - 2023-11-21 12:16:07 --> Controller Class Initialized
INFO - 2023-11-21 12:16:07 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 12:16:07 --> Model "M_produk" initialized
DEBUG - 2023-11-21 12:16:07 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 12:16:07 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 12:16:07 --> Model "M_transaksi" initialized
INFO - 2023-11-21 12:16:07 --> Model "M_bank" initialized
INFO - 2023-11-21 12:16:07 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 12:16:07 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 12:16:07 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 12:16:07 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_edit_profile_pelanggan.php
INFO - 2023-11-21 12:16:07 --> Final output sent to browser
DEBUG - 2023-11-21 12:16:07 --> Total execution time: 0.0100
ERROR - 2023-11-21 12:16:08 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 12:16:08 --> Config Class Initialized
INFO - 2023-11-21 12:16:08 --> Hooks Class Initialized
DEBUG - 2023-11-21 12:16:08 --> UTF-8 Support Enabled
INFO - 2023-11-21 12:16:08 --> Utf8 Class Initialized
INFO - 2023-11-21 12:16:08 --> URI Class Initialized
INFO - 2023-11-21 12:16:08 --> Router Class Initialized
INFO - 2023-11-21 12:16:08 --> Output Class Initialized
INFO - 2023-11-21 12:16:08 --> Security Class Initialized
DEBUG - 2023-11-21 12:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 12:16:08 --> Input Class Initialized
INFO - 2023-11-21 12:16:08 --> Language Class Initialized
INFO - 2023-11-21 12:16:08 --> Loader Class Initialized
INFO - 2023-11-21 12:16:08 --> Helper loaded: url_helper
INFO - 2023-11-21 12:16:08 --> Helper loaded: form_helper
INFO - 2023-11-21 12:16:08 --> Helper loaded: file_helper
INFO - 2023-11-21 12:16:08 --> Database Driver Class Initialized
DEBUG - 2023-11-21 12:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 12:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 12:16:08 --> Form Validation Class Initialized
INFO - 2023-11-21 12:16:08 --> Upload Class Initialized
INFO - 2023-11-21 12:16:08 --> Model "M_auth" initialized
INFO - 2023-11-21 12:16:08 --> Model "M_user" initialized
INFO - 2023-11-21 12:16:08 --> Model "M_produk" initialized
INFO - 2023-11-21 12:16:08 --> Controller Class Initialized
INFO - 2023-11-21 12:16:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-21 12:16:08 --> Final output sent to browser
DEBUG - 2023-11-21 12:16:08 --> Total execution time: 0.0024
ERROR - 2023-11-21 12:16:33 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 12:16:33 --> Config Class Initialized
INFO - 2023-11-21 12:16:33 --> Hooks Class Initialized
DEBUG - 2023-11-21 12:16:33 --> UTF-8 Support Enabled
INFO - 2023-11-21 12:16:33 --> Utf8 Class Initialized
INFO - 2023-11-21 12:16:33 --> URI Class Initialized
INFO - 2023-11-21 12:16:33 --> Router Class Initialized
INFO - 2023-11-21 12:16:33 --> Output Class Initialized
INFO - 2023-11-21 12:16:33 --> Security Class Initialized
DEBUG - 2023-11-21 12:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 12:16:33 --> Input Class Initialized
INFO - 2023-11-21 12:16:33 --> Language Class Initialized
INFO - 2023-11-21 12:16:33 --> Loader Class Initialized
INFO - 2023-11-21 12:16:33 --> Helper loaded: url_helper
INFO - 2023-11-21 12:16:33 --> Helper loaded: form_helper
INFO - 2023-11-21 12:16:33 --> Helper loaded: file_helper
INFO - 2023-11-21 12:16:33 --> Database Driver Class Initialized
DEBUG - 2023-11-21 12:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 12:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 12:16:33 --> Form Validation Class Initialized
INFO - 2023-11-21 12:16:33 --> Upload Class Initialized
INFO - 2023-11-21 12:16:33 --> Model "M_auth" initialized
INFO - 2023-11-21 12:16:33 --> Model "M_user" initialized
INFO - 2023-11-21 12:16:33 --> Model "M_produk" initialized
INFO - 2023-11-21 12:16:33 --> Controller Class Initialized
INFO - 2023-11-21 12:16:33 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 12:16:33 --> Model "M_produk" initialized
DEBUG - 2023-11-21 12:16:33 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 12:16:33 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 12:16:33 --> Model "M_transaksi" initialized
INFO - 2023-11-21 12:16:33 --> Model "M_bank" initialized
INFO - 2023-11-21 12:16:33 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 12:16:33 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 12:16:33 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 12:16:33 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-21 12:16:33 --> Final output sent to browser
DEBUG - 2023-11-21 12:16:33 --> Total execution time: 0.2649
ERROR - 2023-11-21 12:17:57 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 12:17:57 --> Config Class Initialized
INFO - 2023-11-21 12:17:57 --> Hooks Class Initialized
DEBUG - 2023-11-21 12:17:57 --> UTF-8 Support Enabled
INFO - 2023-11-21 12:17:57 --> Utf8 Class Initialized
INFO - 2023-11-21 12:17:57 --> URI Class Initialized
INFO - 2023-11-21 12:17:57 --> Router Class Initialized
INFO - 2023-11-21 12:17:57 --> Output Class Initialized
INFO - 2023-11-21 12:17:57 --> Security Class Initialized
DEBUG - 2023-11-21 12:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 12:17:57 --> Input Class Initialized
INFO - 2023-11-21 12:17:57 --> Language Class Initialized
INFO - 2023-11-21 12:17:57 --> Loader Class Initialized
INFO - 2023-11-21 12:17:57 --> Helper loaded: url_helper
INFO - 2023-11-21 12:17:57 --> Helper loaded: form_helper
INFO - 2023-11-21 12:17:57 --> Helper loaded: file_helper
INFO - 2023-11-21 12:17:57 --> Database Driver Class Initialized
DEBUG - 2023-11-21 12:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 12:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 12:17:57 --> Form Validation Class Initialized
INFO - 2023-11-21 12:17:57 --> Upload Class Initialized
INFO - 2023-11-21 12:17:57 --> Model "M_auth" initialized
INFO - 2023-11-21 12:17:57 --> Model "M_user" initialized
INFO - 2023-11-21 12:17:57 --> Model "M_produk" initialized
INFO - 2023-11-21 12:17:57 --> Controller Class Initialized
INFO - 2023-11-21 12:17:57 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 12:17:57 --> Model "M_produk" initialized
DEBUG - 2023-11-21 12:17:57 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 12:17:57 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 12:17:57 --> Model "M_transaksi" initialized
INFO - 2023-11-21 12:17:57 --> Model "M_bank" initialized
INFO - 2023-11-21 12:17:57 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 12:17:57 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 12:17:57 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 12:17:57 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_edit_profile_pelanggan.php
INFO - 2023-11-21 12:17:57 --> Final output sent to browser
DEBUG - 2023-11-21 12:17:57 --> Total execution time: 0.0039
ERROR - 2023-11-21 12:17:57 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 12:17:57 --> Config Class Initialized
INFO - 2023-11-21 12:17:57 --> Hooks Class Initialized
DEBUG - 2023-11-21 12:17:57 --> UTF-8 Support Enabled
INFO - 2023-11-21 12:17:57 --> Utf8 Class Initialized
INFO - 2023-11-21 12:17:57 --> URI Class Initialized
INFO - 2023-11-21 12:17:57 --> Router Class Initialized
INFO - 2023-11-21 12:17:57 --> Output Class Initialized
INFO - 2023-11-21 12:17:57 --> Security Class Initialized
DEBUG - 2023-11-21 12:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 12:17:57 --> Input Class Initialized
INFO - 2023-11-21 12:17:57 --> Language Class Initialized
INFO - 2023-11-21 12:17:57 --> Loader Class Initialized
INFO - 2023-11-21 12:17:57 --> Helper loaded: url_helper
INFO - 2023-11-21 12:17:57 --> Helper loaded: form_helper
INFO - 2023-11-21 12:17:57 --> Helper loaded: file_helper
INFO - 2023-11-21 12:17:57 --> Database Driver Class Initialized
DEBUG - 2023-11-21 12:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 12:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 12:17:57 --> Form Validation Class Initialized
INFO - 2023-11-21 12:17:57 --> Upload Class Initialized
INFO - 2023-11-21 12:17:57 --> Model "M_auth" initialized
INFO - 2023-11-21 12:17:57 --> Model "M_user" initialized
INFO - 2023-11-21 12:17:57 --> Model "M_produk" initialized
INFO - 2023-11-21 12:17:57 --> Controller Class Initialized
INFO - 2023-11-21 12:17:57 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-21 12:17:57 --> Final output sent to browser
DEBUG - 2023-11-21 12:17:57 --> Total execution time: 0.0024
ERROR - 2023-11-21 12:18:02 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 12:18:02 --> Config Class Initialized
INFO - 2023-11-21 12:18:02 --> Hooks Class Initialized
DEBUG - 2023-11-21 12:18:02 --> UTF-8 Support Enabled
INFO - 2023-11-21 12:18:02 --> Utf8 Class Initialized
INFO - 2023-11-21 12:18:02 --> URI Class Initialized
INFO - 2023-11-21 12:18:02 --> Router Class Initialized
INFO - 2023-11-21 12:18:02 --> Output Class Initialized
INFO - 2023-11-21 12:18:02 --> Security Class Initialized
DEBUG - 2023-11-21 12:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 12:18:02 --> Input Class Initialized
INFO - 2023-11-21 12:18:02 --> Language Class Initialized
INFO - 2023-11-21 12:18:02 --> Loader Class Initialized
INFO - 2023-11-21 12:18:02 --> Helper loaded: url_helper
INFO - 2023-11-21 12:18:02 --> Helper loaded: form_helper
INFO - 2023-11-21 12:18:02 --> Helper loaded: file_helper
INFO - 2023-11-21 12:18:02 --> Database Driver Class Initialized
DEBUG - 2023-11-21 12:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 12:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 12:18:02 --> Form Validation Class Initialized
INFO - 2023-11-21 12:18:02 --> Upload Class Initialized
INFO - 2023-11-21 12:18:02 --> Model "M_auth" initialized
INFO - 2023-11-21 12:18:02 --> Model "M_user" initialized
INFO - 2023-11-21 12:18:02 --> Model "M_produk" initialized
INFO - 2023-11-21 12:18:02 --> Controller Class Initialized
INFO - 2023-11-21 12:18:02 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 12:18:02 --> Model "M_produk" initialized
DEBUG - 2023-11-21 12:18:02 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 12:18:02 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 12:18:02 --> Model "M_transaksi" initialized
INFO - 2023-11-21 12:18:02 --> Model "M_bank" initialized
INFO - 2023-11-21 12:18:02 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 12:18:02 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 12:18:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 12:18:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_booking_saya.php
INFO - 2023-11-21 12:18:02 --> Final output sent to browser
DEBUG - 2023-11-21 12:18:02 --> Total execution time: 0.4041
ERROR - 2023-11-21 12:18:03 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 12:18:03 --> Config Class Initialized
INFO - 2023-11-21 12:18:03 --> Hooks Class Initialized
DEBUG - 2023-11-21 12:18:03 --> UTF-8 Support Enabled
INFO - 2023-11-21 12:18:03 --> Utf8 Class Initialized
INFO - 2023-11-21 12:18:03 --> URI Class Initialized
INFO - 2023-11-21 12:18:03 --> Router Class Initialized
INFO - 2023-11-21 12:18:03 --> Output Class Initialized
INFO - 2023-11-21 12:18:03 --> Security Class Initialized
DEBUG - 2023-11-21 12:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 12:18:03 --> Input Class Initialized
INFO - 2023-11-21 12:18:03 --> Language Class Initialized
INFO - 2023-11-21 12:18:03 --> Loader Class Initialized
INFO - 2023-11-21 12:18:03 --> Helper loaded: url_helper
INFO - 2023-11-21 12:18:03 --> Helper loaded: form_helper
INFO - 2023-11-21 12:18:03 --> Helper loaded: file_helper
INFO - 2023-11-21 12:18:03 --> Database Driver Class Initialized
DEBUG - 2023-11-21 12:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 12:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 12:18:03 --> Form Validation Class Initialized
INFO - 2023-11-21 12:18:03 --> Upload Class Initialized
INFO - 2023-11-21 12:18:03 --> Model "M_auth" initialized
INFO - 2023-11-21 12:18:03 --> Model "M_user" initialized
INFO - 2023-11-21 12:18:03 --> Model "M_produk" initialized
INFO - 2023-11-21 12:18:03 --> Controller Class Initialized
INFO - 2023-11-21 12:18:03 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-21 12:18:03 --> Final output sent to browser
DEBUG - 2023-11-21 12:18:03 --> Total execution time: 0.0024
ERROR - 2023-11-21 12:23:59 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 12:23:59 --> Config Class Initialized
INFO - 2023-11-21 12:23:59 --> Hooks Class Initialized
DEBUG - 2023-11-21 12:23:59 --> UTF-8 Support Enabled
INFO - 2023-11-21 12:23:59 --> Utf8 Class Initialized
INFO - 2023-11-21 12:23:59 --> URI Class Initialized
INFO - 2023-11-21 12:23:59 --> Router Class Initialized
INFO - 2023-11-21 12:23:59 --> Output Class Initialized
INFO - 2023-11-21 12:23:59 --> Security Class Initialized
DEBUG - 2023-11-21 12:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 12:23:59 --> Input Class Initialized
INFO - 2023-11-21 12:23:59 --> Language Class Initialized
INFO - 2023-11-21 12:23:59 --> Loader Class Initialized
INFO - 2023-11-21 12:23:59 --> Helper loaded: url_helper
INFO - 2023-11-21 12:23:59 --> Helper loaded: form_helper
INFO - 2023-11-21 12:23:59 --> Helper loaded: file_helper
INFO - 2023-11-21 12:23:59 --> Database Driver Class Initialized
DEBUG - 2023-11-21 12:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 12:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 12:23:59 --> Form Validation Class Initialized
INFO - 2023-11-21 12:23:59 --> Upload Class Initialized
INFO - 2023-11-21 12:23:59 --> Model "M_auth" initialized
INFO - 2023-11-21 12:23:59 --> Model "M_user" initialized
INFO - 2023-11-21 12:23:59 --> Model "M_produk" initialized
INFO - 2023-11-21 12:23:59 --> Controller Class Initialized
INFO - 2023-11-21 12:23:59 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-21 12:23:59 --> Final output sent to browser
DEBUG - 2023-11-21 12:23:59 --> Total execution time: 0.0273
ERROR - 2023-11-21 12:23:59 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 12:23:59 --> Config Class Initialized
INFO - 2023-11-21 12:23:59 --> Hooks Class Initialized
DEBUG - 2023-11-21 12:23:59 --> UTF-8 Support Enabled
INFO - 2023-11-21 12:23:59 --> Utf8 Class Initialized
INFO - 2023-11-21 12:23:59 --> URI Class Initialized
INFO - 2023-11-21 12:23:59 --> Router Class Initialized
INFO - 2023-11-21 12:23:59 --> Output Class Initialized
INFO - 2023-11-21 12:23:59 --> Security Class Initialized
DEBUG - 2023-11-21 12:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 12:23:59 --> Input Class Initialized
INFO - 2023-11-21 12:23:59 --> Language Class Initialized
INFO - 2023-11-21 12:23:59 --> Loader Class Initialized
INFO - 2023-11-21 12:23:59 --> Helper loaded: url_helper
INFO - 2023-11-21 12:23:59 --> Helper loaded: form_helper
INFO - 2023-11-21 12:23:59 --> Helper loaded: file_helper
INFO - 2023-11-21 12:23:59 --> Database Driver Class Initialized
DEBUG - 2023-11-21 12:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 12:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 12:23:59 --> Form Validation Class Initialized
INFO - 2023-11-21 12:23:59 --> Upload Class Initialized
INFO - 2023-11-21 12:23:59 --> Model "M_auth" initialized
INFO - 2023-11-21 12:23:59 --> Model "M_user" initialized
INFO - 2023-11-21 12:23:59 --> Model "M_produk" initialized
INFO - 2023-11-21 12:23:59 --> Controller Class Initialized
INFO - 2023-11-21 12:23:59 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-21 12:23:59 --> Final output sent to browser
DEBUG - 2023-11-21 12:23:59 --> Total execution time: 0.0021
ERROR - 2023-11-21 13:48:20 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 13:48:20 --> Config Class Initialized
INFO - 2023-11-21 13:48:20 --> Hooks Class Initialized
DEBUG - 2023-11-21 13:48:20 --> UTF-8 Support Enabled
INFO - 2023-11-21 13:48:20 --> Utf8 Class Initialized
INFO - 2023-11-21 13:48:20 --> URI Class Initialized
DEBUG - 2023-11-21 13:48:20 --> No URI present. Default controller set.
INFO - 2023-11-21 13:48:20 --> Router Class Initialized
INFO - 2023-11-21 13:48:20 --> Output Class Initialized
INFO - 2023-11-21 13:48:20 --> Security Class Initialized
DEBUG - 2023-11-21 13:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 13:48:20 --> Input Class Initialized
INFO - 2023-11-21 13:48:20 --> Language Class Initialized
INFO - 2023-11-21 13:48:20 --> Loader Class Initialized
INFO - 2023-11-21 13:48:20 --> Helper loaded: url_helper
INFO - 2023-11-21 13:48:20 --> Helper loaded: form_helper
INFO - 2023-11-21 13:48:20 --> Helper loaded: file_helper
INFO - 2023-11-21 13:48:20 --> Database Driver Class Initialized
DEBUG - 2023-11-21 13:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 13:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 13:48:20 --> Form Validation Class Initialized
INFO - 2023-11-21 13:48:20 --> Upload Class Initialized
INFO - 2023-11-21 13:48:20 --> Model "M_auth" initialized
INFO - 2023-11-21 13:48:20 --> Model "M_user" initialized
INFO - 2023-11-21 13:48:20 --> Model "M_produk" initialized
INFO - 2023-11-21 13:48:20 --> Controller Class Initialized
INFO - 2023-11-21 13:48:20 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 13:48:20 --> Model "M_produk" initialized
DEBUG - 2023-11-21 13:48:20 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 13:48:20 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 13:48:20 --> Model "M_transaksi" initialized
INFO - 2023-11-21 13:48:20 --> Model "M_bank" initialized
INFO - 2023-11-21 13:48:20 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 13:48:20 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 13:48:20 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 13:48:20 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-21 13:48:20 --> Final output sent to browser
DEBUG - 2023-11-21 13:48:20 --> Total execution time: 0.0374
ERROR - 2023-11-21 14:10:44 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 14:10:44 --> Config Class Initialized
INFO - 2023-11-21 14:10:44 --> Hooks Class Initialized
DEBUG - 2023-11-21 14:10:44 --> UTF-8 Support Enabled
INFO - 2023-11-21 14:10:44 --> Utf8 Class Initialized
INFO - 2023-11-21 14:10:44 --> URI Class Initialized
INFO - 2023-11-21 14:10:44 --> Router Class Initialized
INFO - 2023-11-21 14:10:44 --> Output Class Initialized
INFO - 2023-11-21 14:10:44 --> Security Class Initialized
DEBUG - 2023-11-21 14:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 14:10:44 --> Input Class Initialized
INFO - 2023-11-21 14:10:44 --> Language Class Initialized
INFO - 2023-11-21 14:10:44 --> Loader Class Initialized
INFO - 2023-11-21 14:10:44 --> Helper loaded: url_helper
INFO - 2023-11-21 14:10:44 --> Helper loaded: form_helper
INFO - 2023-11-21 14:10:44 --> Helper loaded: file_helper
INFO - 2023-11-21 14:10:44 --> Database Driver Class Initialized
DEBUG - 2023-11-21 14:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 14:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 14:10:44 --> Form Validation Class Initialized
INFO - 2023-11-21 14:10:44 --> Upload Class Initialized
INFO - 2023-11-21 14:10:44 --> Model "M_auth" initialized
INFO - 2023-11-21 14:10:44 --> Model "M_user" initialized
INFO - 2023-11-21 14:10:44 --> Model "M_produk" initialized
INFO - 2023-11-21 14:10:44 --> Controller Class Initialized
INFO - 2023-11-21 14:10:44 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-21 14:10:44 --> Final output sent to browser
DEBUG - 2023-11-21 14:10:44 --> Total execution time: 0.0261
ERROR - 2023-11-21 14:10:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 14:10:45 --> Config Class Initialized
INFO - 2023-11-21 14:10:45 --> Hooks Class Initialized
DEBUG - 2023-11-21 14:10:45 --> UTF-8 Support Enabled
INFO - 2023-11-21 14:10:45 --> Utf8 Class Initialized
INFO - 2023-11-21 14:10:45 --> URI Class Initialized
INFO - 2023-11-21 14:10:45 --> Router Class Initialized
INFO - 2023-11-21 14:10:45 --> Output Class Initialized
INFO - 2023-11-21 14:10:45 --> Security Class Initialized
DEBUG - 2023-11-21 14:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 14:10:45 --> Input Class Initialized
INFO - 2023-11-21 14:10:45 --> Language Class Initialized
INFO - 2023-11-21 14:10:45 --> Loader Class Initialized
INFO - 2023-11-21 14:10:45 --> Helper loaded: url_helper
INFO - 2023-11-21 14:10:45 --> Helper loaded: form_helper
INFO - 2023-11-21 14:10:45 --> Helper loaded: file_helper
INFO - 2023-11-21 14:10:45 --> Database Driver Class Initialized
DEBUG - 2023-11-21 14:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 14:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 14:10:45 --> Form Validation Class Initialized
INFO - 2023-11-21 14:10:45 --> Upload Class Initialized
INFO - 2023-11-21 14:10:45 --> Model "M_auth" initialized
INFO - 2023-11-21 14:10:45 --> Model "M_user" initialized
INFO - 2023-11-21 14:10:45 --> Model "M_produk" initialized
INFO - 2023-11-21 14:10:45 --> Controller Class Initialized
INFO - 2023-11-21 14:10:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-21 14:10:45 --> Final output sent to browser
DEBUG - 2023-11-21 14:10:45 --> Total execution time: 0.0020
ERROR - 2023-11-21 15:39:40 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 15:39:40 --> Config Class Initialized
INFO - 2023-11-21 15:39:40 --> Hooks Class Initialized
DEBUG - 2023-11-21 15:39:40 --> UTF-8 Support Enabled
INFO - 2023-11-21 15:39:40 --> Utf8 Class Initialized
INFO - 2023-11-21 15:39:40 --> URI Class Initialized
INFO - 2023-11-21 15:39:40 --> Router Class Initialized
INFO - 2023-11-21 15:39:40 --> Output Class Initialized
INFO - 2023-11-21 15:39:40 --> Security Class Initialized
DEBUG - 2023-11-21 15:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 15:39:40 --> Input Class Initialized
INFO - 2023-11-21 15:39:40 --> Language Class Initialized
INFO - 2023-11-21 15:39:40 --> Loader Class Initialized
INFO - 2023-11-21 15:39:40 --> Helper loaded: url_helper
INFO - 2023-11-21 15:39:40 --> Helper loaded: form_helper
INFO - 2023-11-21 15:39:40 --> Helper loaded: file_helper
INFO - 2023-11-21 15:39:40 --> Database Driver Class Initialized
DEBUG - 2023-11-21 15:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 15:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 15:39:40 --> Form Validation Class Initialized
INFO - 2023-11-21 15:39:40 --> Upload Class Initialized
INFO - 2023-11-21 15:39:40 --> Model "M_auth" initialized
INFO - 2023-11-21 15:39:40 --> Model "M_user" initialized
INFO - 2023-11-21 15:39:40 --> Model "M_produk" initialized
INFO - 2023-11-21 15:39:40 --> Controller Class Initialized
INFO - 2023-11-21 15:39:40 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-21 15:39:40 --> Final output sent to browser
DEBUG - 2023-11-21 15:39:40 --> Total execution time: 0.0269
ERROR - 2023-11-21 15:39:40 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 15:39:40 --> Config Class Initialized
INFO - 2023-11-21 15:39:40 --> Hooks Class Initialized
DEBUG - 2023-11-21 15:39:40 --> UTF-8 Support Enabled
INFO - 2023-11-21 15:39:40 --> Utf8 Class Initialized
INFO - 2023-11-21 15:39:40 --> URI Class Initialized
INFO - 2023-11-21 15:39:40 --> Router Class Initialized
INFO - 2023-11-21 15:39:40 --> Output Class Initialized
INFO - 2023-11-21 15:39:40 --> Security Class Initialized
DEBUG - 2023-11-21 15:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 15:39:40 --> Input Class Initialized
INFO - 2023-11-21 15:39:40 --> Language Class Initialized
INFO - 2023-11-21 15:39:40 --> Loader Class Initialized
INFO - 2023-11-21 15:39:40 --> Helper loaded: url_helper
INFO - 2023-11-21 15:39:40 --> Helper loaded: form_helper
INFO - 2023-11-21 15:39:40 --> Helper loaded: file_helper
INFO - 2023-11-21 15:39:40 --> Database Driver Class Initialized
DEBUG - 2023-11-21 15:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 15:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 15:39:40 --> Form Validation Class Initialized
INFO - 2023-11-21 15:39:40 --> Upload Class Initialized
INFO - 2023-11-21 15:39:40 --> Model "M_auth" initialized
INFO - 2023-11-21 15:39:40 --> Model "M_user" initialized
INFO - 2023-11-21 15:39:40 --> Model "M_produk" initialized
INFO - 2023-11-21 15:39:40 --> Controller Class Initialized
INFO - 2023-11-21 15:39:40 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-21 15:39:40 --> Final output sent to browser
DEBUG - 2023-11-21 15:39:40 --> Total execution time: 0.0026
ERROR - 2023-11-21 16:38:08 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 16:38:08 --> Config Class Initialized
INFO - 2023-11-21 16:38:08 --> Hooks Class Initialized
DEBUG - 2023-11-21 16:38:08 --> UTF-8 Support Enabled
INFO - 2023-11-21 16:38:08 --> Utf8 Class Initialized
INFO - 2023-11-21 16:38:08 --> URI Class Initialized
DEBUG - 2023-11-21 16:38:08 --> No URI present. Default controller set.
INFO - 2023-11-21 16:38:08 --> Router Class Initialized
INFO - 2023-11-21 16:38:08 --> Output Class Initialized
INFO - 2023-11-21 16:38:08 --> Security Class Initialized
DEBUG - 2023-11-21 16:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 16:38:08 --> Input Class Initialized
INFO - 2023-11-21 16:38:08 --> Language Class Initialized
INFO - 2023-11-21 16:38:08 --> Loader Class Initialized
INFO - 2023-11-21 16:38:08 --> Helper loaded: url_helper
INFO - 2023-11-21 16:38:08 --> Helper loaded: form_helper
INFO - 2023-11-21 16:38:08 --> Helper loaded: file_helper
INFO - 2023-11-21 16:38:08 --> Database Driver Class Initialized
DEBUG - 2023-11-21 16:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 16:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 16:38:08 --> Form Validation Class Initialized
INFO - 2023-11-21 16:38:08 --> Upload Class Initialized
INFO - 2023-11-21 16:38:08 --> Model "M_auth" initialized
INFO - 2023-11-21 16:38:08 --> Model "M_user" initialized
INFO - 2023-11-21 16:38:08 --> Model "M_produk" initialized
INFO - 2023-11-21 16:38:08 --> Controller Class Initialized
INFO - 2023-11-21 16:38:08 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 16:38:08 --> Model "M_produk" initialized
DEBUG - 2023-11-21 16:38:08 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 16:38:08 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 16:38:08 --> Model "M_transaksi" initialized
INFO - 2023-11-21 16:38:08 --> Model "M_bank" initialized
INFO - 2023-11-21 16:38:08 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 16:38:08 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 16:38:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 16:38:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-21 16:38:08 --> Final output sent to browser
DEBUG - 2023-11-21 16:38:08 --> Total execution time: 0.0334
ERROR - 2023-11-21 17:00:18 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 17:00:18 --> Config Class Initialized
INFO - 2023-11-21 17:00:18 --> Hooks Class Initialized
DEBUG - 2023-11-21 17:00:18 --> UTF-8 Support Enabled
INFO - 2023-11-21 17:00:18 --> Utf8 Class Initialized
INFO - 2023-11-21 17:00:18 --> URI Class Initialized
DEBUG - 2023-11-21 17:00:18 --> No URI present. Default controller set.
INFO - 2023-11-21 17:00:18 --> Router Class Initialized
INFO - 2023-11-21 17:00:18 --> Output Class Initialized
INFO - 2023-11-21 17:00:18 --> Security Class Initialized
DEBUG - 2023-11-21 17:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 17:00:18 --> Input Class Initialized
INFO - 2023-11-21 17:00:18 --> Language Class Initialized
INFO - 2023-11-21 17:00:18 --> Loader Class Initialized
INFO - 2023-11-21 17:00:18 --> Helper loaded: url_helper
INFO - 2023-11-21 17:00:18 --> Helper loaded: form_helper
INFO - 2023-11-21 17:00:18 --> Helper loaded: file_helper
INFO - 2023-11-21 17:00:18 --> Database Driver Class Initialized
DEBUG - 2023-11-21 17:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 17:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 17:00:18 --> Form Validation Class Initialized
INFO - 2023-11-21 17:00:18 --> Upload Class Initialized
INFO - 2023-11-21 17:00:18 --> Model "M_auth" initialized
INFO - 2023-11-21 17:00:18 --> Model "M_user" initialized
INFO - 2023-11-21 17:00:18 --> Model "M_produk" initialized
INFO - 2023-11-21 17:00:18 --> Controller Class Initialized
INFO - 2023-11-21 17:00:18 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 17:00:18 --> Model "M_produk" initialized
DEBUG - 2023-11-21 17:00:18 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 17:00:18 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 17:00:18 --> Model "M_transaksi" initialized
INFO - 2023-11-21 17:00:18 --> Model "M_bank" initialized
INFO - 2023-11-21 17:00:18 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 17:00:18 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 17:00:18 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 17:00:18 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-21 17:00:18 --> Final output sent to browser
DEBUG - 2023-11-21 17:00:18 --> Total execution time: 0.0329
ERROR - 2023-11-21 17:30:52 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 17:30:52 --> Config Class Initialized
INFO - 2023-11-21 17:30:52 --> Hooks Class Initialized
DEBUG - 2023-11-21 17:30:52 --> UTF-8 Support Enabled
INFO - 2023-11-21 17:30:52 --> Utf8 Class Initialized
INFO - 2023-11-21 17:30:52 --> URI Class Initialized
DEBUG - 2023-11-21 17:30:52 --> No URI present. Default controller set.
INFO - 2023-11-21 17:30:52 --> Router Class Initialized
INFO - 2023-11-21 17:30:52 --> Output Class Initialized
INFO - 2023-11-21 17:30:52 --> Security Class Initialized
DEBUG - 2023-11-21 17:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 17:30:52 --> Input Class Initialized
INFO - 2023-11-21 17:30:52 --> Language Class Initialized
INFO - 2023-11-21 17:30:52 --> Loader Class Initialized
INFO - 2023-11-21 17:30:52 --> Helper loaded: url_helper
INFO - 2023-11-21 17:30:52 --> Helper loaded: form_helper
INFO - 2023-11-21 17:30:52 --> Helper loaded: file_helper
INFO - 2023-11-21 17:30:52 --> Database Driver Class Initialized
DEBUG - 2023-11-21 17:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 17:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 17:30:52 --> Form Validation Class Initialized
INFO - 2023-11-21 17:30:52 --> Upload Class Initialized
INFO - 2023-11-21 17:30:52 --> Model "M_auth" initialized
INFO - 2023-11-21 17:30:52 --> Model "M_user" initialized
INFO - 2023-11-21 17:30:52 --> Model "M_produk" initialized
INFO - 2023-11-21 17:30:52 --> Controller Class Initialized
INFO - 2023-11-21 17:30:52 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 17:30:52 --> Model "M_produk" initialized
DEBUG - 2023-11-21 17:30:52 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 17:30:52 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 17:30:52 --> Model "M_transaksi" initialized
INFO - 2023-11-21 17:30:52 --> Model "M_bank" initialized
INFO - 2023-11-21 17:30:52 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 17:30:52 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 17:30:52 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 17:30:52 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-21 17:30:52 --> Final output sent to browser
DEBUG - 2023-11-21 17:30:52 --> Total execution time: 0.0348
ERROR - 2023-11-21 19:25:08 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 19:25:08 --> Config Class Initialized
INFO - 2023-11-21 19:25:08 --> Hooks Class Initialized
DEBUG - 2023-11-21 19:25:08 --> UTF-8 Support Enabled
INFO - 2023-11-21 19:25:08 --> Utf8 Class Initialized
INFO - 2023-11-21 19:25:08 --> URI Class Initialized
DEBUG - 2023-11-21 19:25:08 --> No URI present. Default controller set.
INFO - 2023-11-21 19:25:08 --> Router Class Initialized
INFO - 2023-11-21 19:25:08 --> Output Class Initialized
INFO - 2023-11-21 19:25:08 --> Security Class Initialized
DEBUG - 2023-11-21 19:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 19:25:08 --> Input Class Initialized
INFO - 2023-11-21 19:25:08 --> Language Class Initialized
INFO - 2023-11-21 19:25:08 --> Loader Class Initialized
INFO - 2023-11-21 19:25:08 --> Helper loaded: url_helper
INFO - 2023-11-21 19:25:08 --> Helper loaded: form_helper
INFO - 2023-11-21 19:25:08 --> Helper loaded: file_helper
INFO - 2023-11-21 19:25:08 --> Database Driver Class Initialized
DEBUG - 2023-11-21 19:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 19:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 19:25:08 --> Form Validation Class Initialized
INFO - 2023-11-21 19:25:08 --> Upload Class Initialized
INFO - 2023-11-21 19:25:08 --> Model "M_auth" initialized
INFO - 2023-11-21 19:25:08 --> Model "M_user" initialized
INFO - 2023-11-21 19:25:08 --> Model "M_produk" initialized
INFO - 2023-11-21 19:25:08 --> Controller Class Initialized
INFO - 2023-11-21 19:25:08 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 19:25:08 --> Model "M_produk" initialized
DEBUG - 2023-11-21 19:25:08 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 19:25:08 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 19:25:08 --> Model "M_transaksi" initialized
INFO - 2023-11-21 19:25:08 --> Model "M_bank" initialized
INFO - 2023-11-21 19:25:08 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 19:25:08 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 19:25:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 19:25:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-21 19:25:08 --> Final output sent to browser
DEBUG - 2023-11-21 19:25:08 --> Total execution time: 0.0321
ERROR - 2023-11-21 20:18:06 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 20:18:06 --> Config Class Initialized
INFO - 2023-11-21 20:18:06 --> Hooks Class Initialized
DEBUG - 2023-11-21 20:18:06 --> UTF-8 Support Enabled
INFO - 2023-11-21 20:18:06 --> Utf8 Class Initialized
INFO - 2023-11-21 20:18:06 --> URI Class Initialized
DEBUG - 2023-11-21 20:18:06 --> No URI present. Default controller set.
INFO - 2023-11-21 20:18:06 --> Router Class Initialized
INFO - 2023-11-21 20:18:06 --> Output Class Initialized
INFO - 2023-11-21 20:18:06 --> Security Class Initialized
DEBUG - 2023-11-21 20:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 20:18:06 --> Input Class Initialized
INFO - 2023-11-21 20:18:06 --> Language Class Initialized
INFO - 2023-11-21 20:18:06 --> Loader Class Initialized
INFO - 2023-11-21 20:18:06 --> Helper loaded: url_helper
INFO - 2023-11-21 20:18:06 --> Helper loaded: form_helper
INFO - 2023-11-21 20:18:06 --> Helper loaded: file_helper
INFO - 2023-11-21 20:18:06 --> Database Driver Class Initialized
DEBUG - 2023-11-21 20:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 20:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 20:18:06 --> Form Validation Class Initialized
INFO - 2023-11-21 20:18:06 --> Upload Class Initialized
INFO - 2023-11-21 20:18:06 --> Model "M_auth" initialized
INFO - 2023-11-21 20:18:06 --> Model "M_user" initialized
INFO - 2023-11-21 20:18:06 --> Model "M_produk" initialized
INFO - 2023-11-21 20:18:06 --> Controller Class Initialized
INFO - 2023-11-21 20:18:06 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 20:18:06 --> Model "M_produk" initialized
DEBUG - 2023-11-21 20:18:06 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 20:18:06 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 20:18:06 --> Model "M_transaksi" initialized
INFO - 2023-11-21 20:18:06 --> Model "M_bank" initialized
INFO - 2023-11-21 20:18:06 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 20:18:06 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 20:18:06 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 20:18:06 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-21 20:18:06 --> Final output sent to browser
DEBUG - 2023-11-21 20:18:06 --> Total execution time: 0.0322
ERROR - 2023-11-21 22:37:31 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 22:37:31 --> Config Class Initialized
INFO - 2023-11-21 22:37:31 --> Hooks Class Initialized
DEBUG - 2023-11-21 22:37:31 --> UTF-8 Support Enabled
INFO - 2023-11-21 22:37:31 --> Utf8 Class Initialized
INFO - 2023-11-21 22:37:31 --> URI Class Initialized
DEBUG - 2023-11-21 22:37:31 --> No URI present. Default controller set.
INFO - 2023-11-21 22:37:31 --> Router Class Initialized
INFO - 2023-11-21 22:37:31 --> Output Class Initialized
INFO - 2023-11-21 22:37:31 --> Security Class Initialized
DEBUG - 2023-11-21 22:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 22:37:31 --> Input Class Initialized
INFO - 2023-11-21 22:37:31 --> Language Class Initialized
INFO - 2023-11-21 22:37:31 --> Loader Class Initialized
INFO - 2023-11-21 22:37:31 --> Helper loaded: url_helper
INFO - 2023-11-21 22:37:31 --> Helper loaded: form_helper
INFO - 2023-11-21 22:37:31 --> Helper loaded: file_helper
INFO - 2023-11-21 22:37:31 --> Database Driver Class Initialized
DEBUG - 2023-11-21 22:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 22:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 22:37:31 --> Form Validation Class Initialized
INFO - 2023-11-21 22:37:31 --> Upload Class Initialized
INFO - 2023-11-21 22:37:31 --> Model "M_auth" initialized
INFO - 2023-11-21 22:37:31 --> Model "M_user" initialized
INFO - 2023-11-21 22:37:31 --> Model "M_produk" initialized
INFO - 2023-11-21 22:37:31 --> Controller Class Initialized
INFO - 2023-11-21 22:37:31 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 22:37:31 --> Model "M_produk" initialized
DEBUG - 2023-11-21 22:37:31 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 22:37:31 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 22:37:31 --> Model "M_transaksi" initialized
INFO - 2023-11-21 22:37:31 --> Model "M_bank" initialized
INFO - 2023-11-21 22:37:31 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 22:37:31 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-21 22:37:31 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 22:37:31 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-21 22:37:31 --> Final output sent to browser
DEBUG - 2023-11-21 22:37:31 --> Total execution time: 0.0354
ERROR - 2023-11-21 23:39:47 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-21 23:39:47 --> Config Class Initialized
INFO - 2023-11-21 23:39:47 --> Hooks Class Initialized
DEBUG - 2023-11-21 23:39:47 --> UTF-8 Support Enabled
INFO - 2023-11-21 23:39:47 --> Utf8 Class Initialized
INFO - 2023-11-21 23:39:47 --> URI Class Initialized
INFO - 2023-11-21 23:39:47 --> Router Class Initialized
INFO - 2023-11-21 23:39:47 --> Output Class Initialized
INFO - 2023-11-21 23:39:47 --> Security Class Initialized
DEBUG - 2023-11-21 23:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 23:39:47 --> Input Class Initialized
INFO - 2023-11-21 23:39:47 --> Language Class Initialized
INFO - 2023-11-21 23:39:47 --> Loader Class Initialized
INFO - 2023-11-21 23:39:47 --> Helper loaded: url_helper
INFO - 2023-11-21 23:39:47 --> Helper loaded: form_helper
INFO - 2023-11-21 23:39:47 --> Helper loaded: file_helper
INFO - 2023-11-21 23:39:47 --> Database Driver Class Initialized
DEBUG - 2023-11-21 23:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-21 23:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 23:39:47 --> Form Validation Class Initialized
INFO - 2023-11-21 23:39:47 --> Upload Class Initialized
INFO - 2023-11-21 23:39:47 --> Model "M_auth" initialized
INFO - 2023-11-21 23:39:47 --> Model "M_user" initialized
INFO - 2023-11-21 23:39:47 --> Model "M_produk" initialized
INFO - 2023-11-21 23:39:47 --> Controller Class Initialized
INFO - 2023-11-21 23:39:47 --> Model "M_pelanggan" initialized
INFO - 2023-11-21 23:39:47 --> Model "M_produk" initialized
DEBUG - 2023-11-21 23:39:47 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-21 23:39:47 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-21 23:39:47 --> Model "M_transaksi" initialized
INFO - 2023-11-21 23:39:47 --> Model "M_bank" initialized
INFO - 2023-11-21 23:39:47 --> Model "M_pesan" initialized
DEBUG - 2023-11-21 23:39:47 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
ERROR - 2023-11-21 23:39:47 --> Severity: Warning --> Attempt to read property "nama_merek" on null /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_kategori_detail.php 112
INFO - 2023-11-21 23:39:47 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-21 23:39:47 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_kategori_detail.php
INFO - 2023-11-21 23:39:47 --> Final output sent to browser
DEBUG - 2023-11-21 23:39:47 --> Total execution time: 0.0310
