<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-10 03:29:49 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-10 03:29:49 --> Config Class Initialized
INFO - 2023-11-10 03:29:49 --> Hooks Class Initialized
DEBUG - 2023-11-10 03:29:49 --> UTF-8 Support Enabled
INFO - 2023-11-10 03:29:49 --> Utf8 Class Initialized
INFO - 2023-11-10 03:29:49 --> URI Class Initialized
DEBUG - 2023-11-10 03:29:49 --> No URI present. Default controller set.
INFO - 2023-11-10 03:29:49 --> Router Class Initialized
INFO - 2023-11-10 03:29:49 --> Output Class Initialized
INFO - 2023-11-10 03:29:49 --> Security Class Initialized
DEBUG - 2023-11-10 03:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-10 03:29:49 --> Input Class Initialized
INFO - 2023-11-10 03:29:49 --> Language Class Initialized
INFO - 2023-11-10 03:29:49 --> Loader Class Initialized
INFO - 2023-11-10 03:29:49 --> Helper loaded: url_helper
INFO - 2023-11-10 03:29:49 --> Helper loaded: form_helper
INFO - 2023-11-10 03:29:49 --> Helper loaded: file_helper
INFO - 2023-11-10 03:29:49 --> Database Driver Class Initialized
DEBUG - 2023-11-10 03:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-10 03:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-10 03:29:49 --> Form Validation Class Initialized
INFO - 2023-11-10 03:29:49 --> Upload Class Initialized
INFO - 2023-11-10 03:29:49 --> Model "M_auth" initialized
INFO - 2023-11-10 03:29:49 --> Model "M_user" initialized
INFO - 2023-11-10 03:29:49 --> Model "M_produk" initialized
INFO - 2023-11-10 03:29:49 --> Controller Class Initialized
INFO - 2023-11-10 03:29:49 --> Model "M_pelanggan" initialized
INFO - 2023-11-10 03:29:49 --> Model "M_produk" initialized
DEBUG - 2023-11-10 03:29:49 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-10 03:29:49 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-10 03:29:49 --> Model "M_transaksi" initialized
INFO - 2023-11-10 03:29:49 --> Model "M_bank" initialized
INFO - 2023-11-10 03:29:49 --> Model "M_pesan" initialized
DEBUG - 2023-11-10 03:29:49 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-10 03:29:49 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-10 03:29:49 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-10 03:29:49 --> Final output sent to browser
DEBUG - 2023-11-10 03:29:49 --> Total execution time: 0.0465
ERROR - 2023-11-10 09:47:55 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-10 09:47:55 --> Config Class Initialized
INFO - 2023-11-10 09:47:55 --> Hooks Class Initialized
DEBUG - 2023-11-10 09:47:55 --> UTF-8 Support Enabled
INFO - 2023-11-10 09:47:55 --> Utf8 Class Initialized
INFO - 2023-11-10 09:47:55 --> URI Class Initialized
DEBUG - 2023-11-10 09:47:55 --> No URI present. Default controller set.
INFO - 2023-11-10 09:47:55 --> Router Class Initialized
INFO - 2023-11-10 09:47:55 --> Output Class Initialized
INFO - 2023-11-10 09:47:55 --> Security Class Initialized
DEBUG - 2023-11-10 09:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-10 09:47:55 --> Input Class Initialized
INFO - 2023-11-10 09:47:55 --> Language Class Initialized
INFO - 2023-11-10 09:47:55 --> Loader Class Initialized
INFO - 2023-11-10 09:47:55 --> Helper loaded: url_helper
INFO - 2023-11-10 09:47:55 --> Helper loaded: form_helper
INFO - 2023-11-10 09:47:55 --> Helper loaded: file_helper
INFO - 2023-11-10 09:47:55 --> Database Driver Class Initialized
DEBUG - 2023-11-10 09:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-10 09:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-10 09:47:55 --> Form Validation Class Initialized
INFO - 2023-11-10 09:47:55 --> Upload Class Initialized
INFO - 2023-11-10 09:47:55 --> Model "M_auth" initialized
INFO - 2023-11-10 09:47:55 --> Model "M_user" initialized
INFO - 2023-11-10 09:47:55 --> Model "M_produk" initialized
INFO - 2023-11-10 09:47:55 --> Controller Class Initialized
INFO - 2023-11-10 09:47:55 --> Model "M_pelanggan" initialized
INFO - 2023-11-10 09:47:55 --> Model "M_produk" initialized
DEBUG - 2023-11-10 09:47:55 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-10 09:47:55 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-10 09:47:55 --> Model "M_transaksi" initialized
INFO - 2023-11-10 09:47:55 --> Model "M_bank" initialized
INFO - 2023-11-10 09:47:55 --> Model "M_pesan" initialized
DEBUG - 2023-11-10 09:47:55 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-10 09:47:55 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-10 09:47:55 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-10 09:47:55 --> Final output sent to browser
DEBUG - 2023-11-10 09:47:55 --> Total execution time: 0.0515
ERROR - 2023-11-10 09:48:10 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-10 09:48:10 --> Config Class Initialized
INFO - 2023-11-10 09:48:10 --> Hooks Class Initialized
DEBUG - 2023-11-10 09:48:10 --> UTF-8 Support Enabled
INFO - 2023-11-10 09:48:10 --> Utf8 Class Initialized
INFO - 2023-11-10 09:48:10 --> URI Class Initialized
DEBUG - 2023-11-10 09:48:10 --> No URI present. Default controller set.
INFO - 2023-11-10 09:48:10 --> Router Class Initialized
INFO - 2023-11-10 09:48:10 --> Output Class Initialized
INFO - 2023-11-10 09:48:10 --> Security Class Initialized
DEBUG - 2023-11-10 09:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-10 09:48:10 --> Input Class Initialized
INFO - 2023-11-10 09:48:10 --> Language Class Initialized
INFO - 2023-11-10 09:48:10 --> Loader Class Initialized
INFO - 2023-11-10 09:48:10 --> Helper loaded: url_helper
INFO - 2023-11-10 09:48:10 --> Helper loaded: form_helper
INFO - 2023-11-10 09:48:10 --> Helper loaded: file_helper
INFO - 2023-11-10 09:48:10 --> Database Driver Class Initialized
DEBUG - 2023-11-10 09:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-10 09:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-10 09:48:10 --> Form Validation Class Initialized
INFO - 2023-11-10 09:48:10 --> Upload Class Initialized
INFO - 2023-11-10 09:48:10 --> Model "M_auth" initialized
INFO - 2023-11-10 09:48:10 --> Model "M_user" initialized
INFO - 2023-11-10 09:48:10 --> Model "M_produk" initialized
INFO - 2023-11-10 09:48:10 --> Controller Class Initialized
INFO - 2023-11-10 09:48:10 --> Model "M_pelanggan" initialized
INFO - 2023-11-10 09:48:10 --> Model "M_produk" initialized
DEBUG - 2023-11-10 09:48:10 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-10 09:48:10 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-10 09:48:10 --> Model "M_transaksi" initialized
INFO - 2023-11-10 09:48:10 --> Model "M_bank" initialized
INFO - 2023-11-10 09:48:10 --> Model "M_pesan" initialized
DEBUG - 2023-11-10 09:48:10 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-10 09:48:10 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-10 09:48:10 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-10 09:48:10 --> Final output sent to browser
DEBUG - 2023-11-10 09:48:10 --> Total execution time: 0.0035
ERROR - 2023-11-10 10:26:31 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-10 10:26:31 --> Config Class Initialized
INFO - 2023-11-10 10:26:31 --> Hooks Class Initialized
DEBUG - 2023-11-10 10:26:31 --> UTF-8 Support Enabled
INFO - 2023-11-10 10:26:31 --> Utf8 Class Initialized
INFO - 2023-11-10 10:26:31 --> URI Class Initialized
DEBUG - 2023-11-10 10:26:31 --> No URI present. Default controller set.
INFO - 2023-11-10 10:26:31 --> Router Class Initialized
INFO - 2023-11-10 10:26:31 --> Output Class Initialized
INFO - 2023-11-10 10:26:31 --> Security Class Initialized
DEBUG - 2023-11-10 10:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-10 10:26:31 --> Input Class Initialized
INFO - 2023-11-10 10:26:31 --> Language Class Initialized
INFO - 2023-11-10 10:26:31 --> Loader Class Initialized
INFO - 2023-11-10 10:26:31 --> Helper loaded: url_helper
INFO - 2023-11-10 10:26:31 --> Helper loaded: form_helper
INFO - 2023-11-10 10:26:31 --> Helper loaded: file_helper
INFO - 2023-11-10 10:26:31 --> Database Driver Class Initialized
DEBUG - 2023-11-10 10:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-10 10:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-10 10:26:31 --> Form Validation Class Initialized
INFO - 2023-11-10 10:26:31 --> Upload Class Initialized
INFO - 2023-11-10 10:26:31 --> Model "M_auth" initialized
INFO - 2023-11-10 10:26:31 --> Model "M_user" initialized
INFO - 2023-11-10 10:26:31 --> Model "M_produk" initialized
INFO - 2023-11-10 10:26:31 --> Controller Class Initialized
INFO - 2023-11-10 10:26:31 --> Model "M_pelanggan" initialized
INFO - 2023-11-10 10:26:31 --> Model "M_produk" initialized
DEBUG - 2023-11-10 10:26:31 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-10 10:26:31 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-10 10:26:31 --> Model "M_transaksi" initialized
INFO - 2023-11-10 10:26:31 --> Model "M_bank" initialized
INFO - 2023-11-10 10:26:31 --> Model "M_pesan" initialized
DEBUG - 2023-11-10 10:26:31 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-10 10:26:31 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-10 10:26:31 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-10 10:26:31 --> Final output sent to browser
DEBUG - 2023-11-10 10:26:31 --> Total execution time: 0.0350
ERROR - 2023-11-10 14:47:44 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-10 14:47:44 --> Config Class Initialized
INFO - 2023-11-10 14:47:44 --> Hooks Class Initialized
DEBUG - 2023-11-10 14:47:44 --> UTF-8 Support Enabled
INFO - 2023-11-10 14:47:44 --> Utf8 Class Initialized
INFO - 2023-11-10 14:47:44 --> URI Class Initialized
DEBUG - 2023-11-10 14:47:44 --> No URI present. Default controller set.
INFO - 2023-11-10 14:47:44 --> Router Class Initialized
INFO - 2023-11-10 14:47:44 --> Output Class Initialized
INFO - 2023-11-10 14:47:44 --> Security Class Initialized
DEBUG - 2023-11-10 14:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-10 14:47:44 --> Input Class Initialized
INFO - 2023-11-10 14:47:44 --> Language Class Initialized
INFO - 2023-11-10 14:47:44 --> Loader Class Initialized
INFO - 2023-11-10 14:47:44 --> Helper loaded: url_helper
INFO - 2023-11-10 14:47:44 --> Helper loaded: form_helper
INFO - 2023-11-10 14:47:44 --> Helper loaded: file_helper
INFO - 2023-11-10 14:47:44 --> Database Driver Class Initialized
DEBUG - 2023-11-10 14:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-10 14:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-10 14:47:44 --> Form Validation Class Initialized
INFO - 2023-11-10 14:47:44 --> Upload Class Initialized
INFO - 2023-11-10 14:47:44 --> Model "M_auth" initialized
INFO - 2023-11-10 14:47:44 --> Model "M_user" initialized
INFO - 2023-11-10 14:47:44 --> Model "M_produk" initialized
INFO - 2023-11-10 14:47:44 --> Controller Class Initialized
INFO - 2023-11-10 14:47:44 --> Model "M_pelanggan" initialized
INFO - 2023-11-10 14:47:44 --> Model "M_produk" initialized
DEBUG - 2023-11-10 14:47:44 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-10 14:47:44 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-10 14:47:44 --> Model "M_transaksi" initialized
INFO - 2023-11-10 14:47:44 --> Model "M_bank" initialized
INFO - 2023-11-10 14:47:44 --> Model "M_pesan" initialized
DEBUG - 2023-11-10 14:47:44 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-10 14:47:44 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-10 14:47:44 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-10 14:47:44 --> Final output sent to browser
DEBUG - 2023-11-10 14:47:44 --> Total execution time: 0.0461
ERROR - 2023-11-10 14:53:20 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-10 14:53:20 --> Config Class Initialized
INFO - 2023-11-10 14:53:20 --> Hooks Class Initialized
DEBUG - 2023-11-10 14:53:20 --> UTF-8 Support Enabled
INFO - 2023-11-10 14:53:20 --> Utf8 Class Initialized
INFO - 2023-11-10 14:53:20 --> URI Class Initialized
INFO - 2023-11-10 14:53:20 --> Router Class Initialized
INFO - 2023-11-10 14:53:20 --> Output Class Initialized
INFO - 2023-11-10 14:53:20 --> Security Class Initialized
DEBUG - 2023-11-10 14:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-10 14:53:20 --> Input Class Initialized
INFO - 2023-11-10 14:53:20 --> Language Class Initialized
INFO - 2023-11-10 14:53:20 --> Loader Class Initialized
INFO - 2023-11-10 14:53:20 --> Helper loaded: url_helper
INFO - 2023-11-10 14:53:20 --> Helper loaded: form_helper
INFO - 2023-11-10 14:53:20 --> Helper loaded: file_helper
INFO - 2023-11-10 14:53:20 --> Database Driver Class Initialized
DEBUG - 2023-11-10 14:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-10 14:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-10 14:53:20 --> Form Validation Class Initialized
INFO - 2023-11-10 14:53:20 --> Upload Class Initialized
INFO - 2023-11-10 14:53:20 --> Model "M_auth" initialized
INFO - 2023-11-10 14:53:20 --> Model "M_user" initialized
INFO - 2023-11-10 14:53:20 --> Model "M_produk" initialized
INFO - 2023-11-10 14:53:20 --> Controller Class Initialized
INFO - 2023-11-10 14:53:20 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-10 14:53:20 --> Final output sent to browser
DEBUG - 2023-11-10 14:53:20 --> Total execution time: 0.0337
ERROR - 2023-11-10 14:53:22 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-10 14:53:22 --> Config Class Initialized
INFO - 2023-11-10 14:53:22 --> Hooks Class Initialized
DEBUG - 2023-11-10 14:53:22 --> UTF-8 Support Enabled
INFO - 2023-11-10 14:53:22 --> Utf8 Class Initialized
INFO - 2023-11-10 14:53:22 --> URI Class Initialized
DEBUG - 2023-11-10 14:53:22 --> No URI present. Default controller set.
INFO - 2023-11-10 14:53:22 --> Router Class Initialized
INFO - 2023-11-10 14:53:22 --> Output Class Initialized
INFO - 2023-11-10 14:53:22 --> Security Class Initialized
DEBUG - 2023-11-10 14:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-10 14:53:22 --> Input Class Initialized
INFO - 2023-11-10 14:53:22 --> Language Class Initialized
INFO - 2023-11-10 14:53:22 --> Loader Class Initialized
INFO - 2023-11-10 14:53:22 --> Helper loaded: url_helper
INFO - 2023-11-10 14:53:22 --> Helper loaded: form_helper
INFO - 2023-11-10 14:53:22 --> Helper loaded: file_helper
INFO - 2023-11-10 14:53:22 --> Database Driver Class Initialized
DEBUG - 2023-11-10 14:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-10 14:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-10 14:53:22 --> Form Validation Class Initialized
INFO - 2023-11-10 14:53:22 --> Upload Class Initialized
INFO - 2023-11-10 14:53:22 --> Model "M_auth" initialized
INFO - 2023-11-10 14:53:22 --> Model "M_user" initialized
INFO - 2023-11-10 14:53:22 --> Model "M_produk" initialized
INFO - 2023-11-10 14:53:22 --> Controller Class Initialized
INFO - 2023-11-10 14:53:22 --> Model "M_pelanggan" initialized
INFO - 2023-11-10 14:53:22 --> Model "M_produk" initialized
DEBUG - 2023-11-10 14:53:22 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-10 14:53:22 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-10 14:53:22 --> Model "M_transaksi" initialized
INFO - 2023-11-10 14:53:22 --> Model "M_bank" initialized
INFO - 2023-11-10 14:53:22 --> Model "M_pesan" initialized
DEBUG - 2023-11-10 14:53:22 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-10 14:53:22 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-10 14:53:22 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-10 14:53:22 --> Final output sent to browser
DEBUG - 2023-11-10 14:53:22 --> Total execution time: 0.0132
ERROR - 2023-11-10 16:00:16 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-10 16:00:16 --> Config Class Initialized
INFO - 2023-11-10 16:00:16 --> Hooks Class Initialized
DEBUG - 2023-11-10 16:00:16 --> UTF-8 Support Enabled
INFO - 2023-11-10 16:00:16 --> Utf8 Class Initialized
INFO - 2023-11-10 16:00:16 --> URI Class Initialized
DEBUG - 2023-11-10 16:00:16 --> No URI present. Default controller set.
INFO - 2023-11-10 16:00:16 --> Router Class Initialized
INFO - 2023-11-10 16:00:16 --> Output Class Initialized
INFO - 2023-11-10 16:00:16 --> Security Class Initialized
DEBUG - 2023-11-10 16:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-10 16:00:16 --> Input Class Initialized
INFO - 2023-11-10 16:00:16 --> Language Class Initialized
INFO - 2023-11-10 16:00:16 --> Loader Class Initialized
INFO - 2023-11-10 16:00:16 --> Helper loaded: url_helper
INFO - 2023-11-10 16:00:16 --> Helper loaded: form_helper
INFO - 2023-11-10 16:00:16 --> Helper loaded: file_helper
INFO - 2023-11-10 16:00:16 --> Database Driver Class Initialized
DEBUG - 2023-11-10 16:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-10 16:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-10 16:00:16 --> Form Validation Class Initialized
INFO - 2023-11-10 16:00:16 --> Upload Class Initialized
INFO - 2023-11-10 16:00:16 --> Model "M_auth" initialized
INFO - 2023-11-10 16:00:16 --> Model "M_user" initialized
INFO - 2023-11-10 16:00:16 --> Model "M_produk" initialized
INFO - 2023-11-10 16:00:16 --> Controller Class Initialized
INFO - 2023-11-10 16:00:16 --> Model "M_pelanggan" initialized
INFO - 2023-11-10 16:00:16 --> Model "M_produk" initialized
DEBUG - 2023-11-10 16:00:16 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-10 16:00:16 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-10 16:00:16 --> Model "M_transaksi" initialized
INFO - 2023-11-10 16:00:16 --> Model "M_bank" initialized
INFO - 2023-11-10 16:00:16 --> Model "M_pesan" initialized
DEBUG - 2023-11-10 16:00:16 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-10 16:00:16 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-10 16:00:16 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-10 16:00:16 --> Final output sent to browser
DEBUG - 2023-11-10 16:00:16 --> Total execution time: 0.0336
ERROR - 2023-11-10 16:10:51 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-10 16:10:51 --> Config Class Initialized
INFO - 2023-11-10 16:10:51 --> Hooks Class Initialized
DEBUG - 2023-11-10 16:10:51 --> UTF-8 Support Enabled
INFO - 2023-11-10 16:10:51 --> Utf8 Class Initialized
INFO - 2023-11-10 16:10:51 --> URI Class Initialized
DEBUG - 2023-11-10 16:10:51 --> No URI present. Default controller set.
INFO - 2023-11-10 16:10:51 --> Router Class Initialized
INFO - 2023-11-10 16:10:51 --> Output Class Initialized
INFO - 2023-11-10 16:10:51 --> Security Class Initialized
DEBUG - 2023-11-10 16:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-10 16:10:51 --> Input Class Initialized
INFO - 2023-11-10 16:10:51 --> Language Class Initialized
INFO - 2023-11-10 16:10:51 --> Loader Class Initialized
INFO - 2023-11-10 16:10:51 --> Helper loaded: url_helper
INFO - 2023-11-10 16:10:51 --> Helper loaded: form_helper
INFO - 2023-11-10 16:10:51 --> Helper loaded: file_helper
INFO - 2023-11-10 16:10:51 --> Database Driver Class Initialized
DEBUG - 2023-11-10 16:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-10 16:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-10 16:10:51 --> Form Validation Class Initialized
INFO - 2023-11-10 16:10:51 --> Upload Class Initialized
INFO - 2023-11-10 16:10:51 --> Model "M_auth" initialized
INFO - 2023-11-10 16:10:51 --> Model "M_user" initialized
INFO - 2023-11-10 16:10:51 --> Model "M_produk" initialized
INFO - 2023-11-10 16:10:51 --> Controller Class Initialized
INFO - 2023-11-10 16:10:51 --> Model "M_pelanggan" initialized
INFO - 2023-11-10 16:10:51 --> Model "M_produk" initialized
DEBUG - 2023-11-10 16:10:51 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-10 16:10:51 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-10 16:10:51 --> Model "M_transaksi" initialized
INFO - 2023-11-10 16:10:51 --> Model "M_bank" initialized
INFO - 2023-11-10 16:10:51 --> Model "M_pesan" initialized
DEBUG - 2023-11-10 16:10:51 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-10 16:10:51 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-10 16:10:51 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-10 16:10:51 --> Final output sent to browser
DEBUG - 2023-11-10 16:10:51 --> Total execution time: 0.0441
ERROR - 2023-11-10 16:10:52 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-10 16:10:52 --> Config Class Initialized
INFO - 2023-11-10 16:10:52 --> Hooks Class Initialized
DEBUG - 2023-11-10 16:10:52 --> UTF-8 Support Enabled
INFO - 2023-11-10 16:10:52 --> Utf8 Class Initialized
INFO - 2023-11-10 16:10:52 --> URI Class Initialized
INFO - 2023-11-10 16:10:52 --> Router Class Initialized
INFO - 2023-11-10 16:10:52 --> Output Class Initialized
INFO - 2023-11-10 16:10:52 --> Security Class Initialized
DEBUG - 2023-11-10 16:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-10 16:10:52 --> Input Class Initialized
INFO - 2023-11-10 16:10:52 --> Language Class Initialized
INFO - 2023-11-10 16:10:52 --> Loader Class Initialized
INFO - 2023-11-10 16:10:52 --> Helper loaded: url_helper
INFO - 2023-11-10 16:10:52 --> Helper loaded: form_helper
INFO - 2023-11-10 16:10:52 --> Helper loaded: file_helper
INFO - 2023-11-10 16:10:52 --> Database Driver Class Initialized
DEBUG - 2023-11-10 16:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-10 16:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-10 16:10:52 --> Form Validation Class Initialized
INFO - 2023-11-10 16:10:52 --> Upload Class Initialized
INFO - 2023-11-10 16:10:52 --> Model "M_auth" initialized
INFO - 2023-11-10 16:10:52 --> Model "M_user" initialized
INFO - 2023-11-10 16:10:52 --> Model "M_produk" initialized
INFO - 2023-11-10 16:10:52 --> Controller Class Initialized
INFO - 2023-11-10 16:10:52 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-10 16:10:52 --> Final output sent to browser
DEBUG - 2023-11-10 16:10:52 --> Total execution time: 0.0033
ERROR - 2023-11-10 16:10:52 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-10 16:10:52 --> Config Class Initialized
INFO - 2023-11-10 16:10:52 --> Hooks Class Initialized
DEBUG - 2023-11-10 16:10:52 --> UTF-8 Support Enabled
INFO - 2023-11-10 16:10:52 --> Utf8 Class Initialized
INFO - 2023-11-10 16:10:52 --> URI Class Initialized
INFO - 2023-11-10 16:10:52 --> Router Class Initialized
INFO - 2023-11-10 16:10:52 --> Output Class Initialized
INFO - 2023-11-10 16:10:52 --> Security Class Initialized
DEBUG - 2023-11-10 16:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-10 16:10:52 --> Input Class Initialized
INFO - 2023-11-10 16:10:52 --> Language Class Initialized
INFO - 2023-11-10 16:10:52 --> Loader Class Initialized
INFO - 2023-11-10 16:10:52 --> Helper loaded: url_helper
INFO - 2023-11-10 16:10:52 --> Helper loaded: form_helper
INFO - 2023-11-10 16:10:52 --> Helper loaded: file_helper
INFO - 2023-11-10 16:10:52 --> Database Driver Class Initialized
DEBUG - 2023-11-10 16:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-10 16:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-10 16:10:52 --> Form Validation Class Initialized
INFO - 2023-11-10 16:10:52 --> Upload Class Initialized
INFO - 2023-11-10 16:10:52 --> Model "M_auth" initialized
INFO - 2023-11-10 16:10:52 --> Model "M_user" initialized
INFO - 2023-11-10 16:10:52 --> Model "M_produk" initialized
INFO - 2023-11-10 16:10:52 --> Controller Class Initialized
INFO - 2023-11-10 16:10:52 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-10 16:10:52 --> Final output sent to browser
DEBUG - 2023-11-10 16:10:52 --> Total execution time: 0.0025
ERROR - 2023-11-10 16:23:47 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-10 16:23:47 --> Config Class Initialized
INFO - 2023-11-10 16:23:47 --> Hooks Class Initialized
DEBUG - 2023-11-10 16:23:47 --> UTF-8 Support Enabled
INFO - 2023-11-10 16:23:47 --> Utf8 Class Initialized
INFO - 2023-11-10 16:23:47 --> URI Class Initialized
DEBUG - 2023-11-10 16:23:47 --> No URI present. Default controller set.
INFO - 2023-11-10 16:23:47 --> Router Class Initialized
INFO - 2023-11-10 16:23:47 --> Output Class Initialized
INFO - 2023-11-10 16:23:47 --> Security Class Initialized
DEBUG - 2023-11-10 16:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-10 16:23:47 --> Input Class Initialized
INFO - 2023-11-10 16:23:47 --> Language Class Initialized
INFO - 2023-11-10 16:23:47 --> Loader Class Initialized
INFO - 2023-11-10 16:23:47 --> Helper loaded: url_helper
INFO - 2023-11-10 16:23:47 --> Helper loaded: form_helper
INFO - 2023-11-10 16:23:47 --> Helper loaded: file_helper
INFO - 2023-11-10 16:23:47 --> Database Driver Class Initialized
DEBUG - 2023-11-10 16:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-10 16:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-10 16:23:47 --> Form Validation Class Initialized
INFO - 2023-11-10 16:23:47 --> Upload Class Initialized
INFO - 2023-11-10 16:23:47 --> Model "M_auth" initialized
INFO - 2023-11-10 16:23:47 --> Model "M_user" initialized
INFO - 2023-11-10 16:23:47 --> Model "M_produk" initialized
INFO - 2023-11-10 16:23:47 --> Controller Class Initialized
INFO - 2023-11-10 16:23:47 --> Model "M_pelanggan" initialized
INFO - 2023-11-10 16:23:47 --> Model "M_produk" initialized
DEBUG - 2023-11-10 16:23:47 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-10 16:23:47 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-10 16:23:47 --> Model "M_transaksi" initialized
INFO - 2023-11-10 16:23:47 --> Model "M_bank" initialized
INFO - 2023-11-10 16:23:47 --> Model "M_pesan" initialized
DEBUG - 2023-11-10 16:23:47 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-10 16:23:47 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-10 16:23:47 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-10 16:23:47 --> Final output sent to browser
DEBUG - 2023-11-10 16:23:47 --> Total execution time: 0.0332
ERROR - 2023-11-10 16:25:08 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-10 16:25:08 --> Config Class Initialized
INFO - 2023-11-10 16:25:08 --> Hooks Class Initialized
DEBUG - 2023-11-10 16:25:08 --> UTF-8 Support Enabled
INFO - 2023-11-10 16:25:08 --> Utf8 Class Initialized
INFO - 2023-11-10 16:25:08 --> URI Class Initialized
DEBUG - 2023-11-10 16:25:08 --> No URI present. Default controller set.
INFO - 2023-11-10 16:25:08 --> Router Class Initialized
INFO - 2023-11-10 16:25:08 --> Output Class Initialized
INFO - 2023-11-10 16:25:08 --> Security Class Initialized
DEBUG - 2023-11-10 16:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-10 16:25:08 --> Input Class Initialized
INFO - 2023-11-10 16:25:08 --> Language Class Initialized
INFO - 2023-11-10 16:25:08 --> Loader Class Initialized
INFO - 2023-11-10 16:25:08 --> Helper loaded: url_helper
INFO - 2023-11-10 16:25:08 --> Helper loaded: form_helper
INFO - 2023-11-10 16:25:08 --> Helper loaded: file_helper
INFO - 2023-11-10 16:25:08 --> Database Driver Class Initialized
DEBUG - 2023-11-10 16:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-10 16:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-10 16:25:08 --> Form Validation Class Initialized
INFO - 2023-11-10 16:25:08 --> Upload Class Initialized
INFO - 2023-11-10 16:25:08 --> Model "M_auth" initialized
INFO - 2023-11-10 16:25:08 --> Model "M_user" initialized
INFO - 2023-11-10 16:25:08 --> Model "M_produk" initialized
INFO - 2023-11-10 16:25:08 --> Controller Class Initialized
INFO - 2023-11-10 16:25:08 --> Model "M_pelanggan" initialized
INFO - 2023-11-10 16:25:08 --> Model "M_produk" initialized
DEBUG - 2023-11-10 16:25:08 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-10 16:25:08 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-10 16:25:08 --> Model "M_transaksi" initialized
INFO - 2023-11-10 16:25:08 --> Model "M_bank" initialized
INFO - 2023-11-10 16:25:08 --> Model "M_pesan" initialized
DEBUG - 2023-11-10 16:25:08 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-10 16:25:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-10 16:25:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-10 16:25:08 --> Final output sent to browser
DEBUG - 2023-11-10 16:25:08 --> Total execution time: 0.0043
ERROR - 2023-11-10 16:44:54 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-10 16:44:54 --> Config Class Initialized
INFO - 2023-11-10 16:44:54 --> Hooks Class Initialized
DEBUG - 2023-11-10 16:44:54 --> UTF-8 Support Enabled
INFO - 2023-11-10 16:44:54 --> Utf8 Class Initialized
INFO - 2023-11-10 16:44:54 --> URI Class Initialized
DEBUG - 2023-11-10 16:44:54 --> No URI present. Default controller set.
INFO - 2023-11-10 16:44:54 --> Router Class Initialized
INFO - 2023-11-10 16:44:54 --> Output Class Initialized
INFO - 2023-11-10 16:44:54 --> Security Class Initialized
DEBUG - 2023-11-10 16:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-10 16:44:54 --> Input Class Initialized
INFO - 2023-11-10 16:44:54 --> Language Class Initialized
INFO - 2023-11-10 16:44:54 --> Loader Class Initialized
INFO - 2023-11-10 16:44:54 --> Helper loaded: url_helper
INFO - 2023-11-10 16:44:54 --> Helper loaded: form_helper
INFO - 2023-11-10 16:44:54 --> Helper loaded: file_helper
INFO - 2023-11-10 16:44:54 --> Database Driver Class Initialized
DEBUG - 2023-11-10 16:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-10 16:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-10 16:44:54 --> Form Validation Class Initialized
INFO - 2023-11-10 16:44:54 --> Upload Class Initialized
INFO - 2023-11-10 16:44:54 --> Model "M_auth" initialized
INFO - 2023-11-10 16:44:54 --> Model "M_user" initialized
INFO - 2023-11-10 16:44:54 --> Model "M_produk" initialized
INFO - 2023-11-10 16:44:54 --> Controller Class Initialized
INFO - 2023-11-10 16:44:54 --> Model "M_pelanggan" initialized
INFO - 2023-11-10 16:44:54 --> Model "M_produk" initialized
DEBUG - 2023-11-10 16:44:54 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-10 16:44:54 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-10 16:44:54 --> Model "M_transaksi" initialized
INFO - 2023-11-10 16:44:54 --> Model "M_bank" initialized
INFO - 2023-11-10 16:44:54 --> Model "M_pesan" initialized
DEBUG - 2023-11-10 16:44:54 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-10 16:44:54 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-10 16:44:54 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-10 16:44:54 --> Final output sent to browser
DEBUG - 2023-11-10 16:44:54 --> Total execution time: 0.0405
ERROR - 2023-11-10 16:44:55 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-10 16:44:55 --> Config Class Initialized
INFO - 2023-11-10 16:44:55 --> Hooks Class Initialized
DEBUG - 2023-11-10 16:44:55 --> UTF-8 Support Enabled
INFO - 2023-11-10 16:44:55 --> Utf8 Class Initialized
INFO - 2023-11-10 16:44:55 --> URI Class Initialized
DEBUG - 2023-11-10 16:44:55 --> No URI present. Default controller set.
INFO - 2023-11-10 16:44:55 --> Router Class Initialized
INFO - 2023-11-10 16:44:55 --> Output Class Initialized
INFO - 2023-11-10 16:44:55 --> Security Class Initialized
DEBUG - 2023-11-10 16:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-10 16:44:55 --> Input Class Initialized
INFO - 2023-11-10 16:44:55 --> Language Class Initialized
INFO - 2023-11-10 16:44:55 --> Loader Class Initialized
INFO - 2023-11-10 16:44:55 --> Helper loaded: url_helper
INFO - 2023-11-10 16:44:55 --> Helper loaded: form_helper
INFO - 2023-11-10 16:44:55 --> Helper loaded: file_helper
INFO - 2023-11-10 16:44:55 --> Database Driver Class Initialized
DEBUG - 2023-11-10 16:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-10 16:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-10 16:44:55 --> Form Validation Class Initialized
INFO - 2023-11-10 16:44:55 --> Upload Class Initialized
INFO - 2023-11-10 16:44:55 --> Model "M_auth" initialized
INFO - 2023-11-10 16:44:55 --> Model "M_user" initialized
INFO - 2023-11-10 16:44:55 --> Model "M_produk" initialized
INFO - 2023-11-10 16:44:55 --> Controller Class Initialized
INFO - 2023-11-10 16:44:55 --> Model "M_pelanggan" initialized
INFO - 2023-11-10 16:44:55 --> Model "M_produk" initialized
DEBUG - 2023-11-10 16:44:55 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-10 16:44:55 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-10 16:44:55 --> Model "M_transaksi" initialized
INFO - 2023-11-10 16:44:55 --> Model "M_bank" initialized
INFO - 2023-11-10 16:44:55 --> Model "M_pesan" initialized
DEBUG - 2023-11-10 16:44:55 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-10 16:44:55 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-10 16:44:55 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-10 16:44:55 --> Final output sent to browser
DEBUG - 2023-11-10 16:44:55 --> Total execution time: 0.0041
ERROR - 2023-11-10 17:36:35 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-10 17:36:35 --> Config Class Initialized
INFO - 2023-11-10 17:36:35 --> Hooks Class Initialized
DEBUG - 2023-11-10 17:36:35 --> UTF-8 Support Enabled
INFO - 2023-11-10 17:36:35 --> Utf8 Class Initialized
INFO - 2023-11-10 17:36:35 --> URI Class Initialized
INFO - 2023-11-10 17:36:35 --> Router Class Initialized
INFO - 2023-11-10 17:36:35 --> Output Class Initialized
INFO - 2023-11-10 17:36:35 --> Security Class Initialized
DEBUG - 2023-11-10 17:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-10 17:36:35 --> Input Class Initialized
INFO - 2023-11-10 17:36:35 --> Language Class Initialized
INFO - 2023-11-10 17:36:35 --> Loader Class Initialized
INFO - 2023-11-10 17:36:35 --> Helper loaded: url_helper
INFO - 2023-11-10 17:36:35 --> Helper loaded: form_helper
INFO - 2023-11-10 17:36:35 --> Helper loaded: file_helper
INFO - 2023-11-10 17:36:35 --> Database Driver Class Initialized
DEBUG - 2023-11-10 17:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-10 17:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-10 17:36:35 --> Form Validation Class Initialized
INFO - 2023-11-10 17:36:35 --> Upload Class Initialized
INFO - 2023-11-10 17:36:35 --> Model "M_auth" initialized
INFO - 2023-11-10 17:36:35 --> Model "M_user" initialized
INFO - 2023-11-10 17:36:35 --> Model "M_produk" initialized
INFO - 2023-11-10 17:36:35 --> Controller Class Initialized
INFO - 2023-11-10 17:36:35 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-10 17:36:35 --> Final output sent to browser
DEBUG - 2023-11-10 17:36:35 --> Total execution time: 0.0320
ERROR - 2023-11-10 17:36:37 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-10 17:36:37 --> Config Class Initialized
INFO - 2023-11-10 17:36:37 --> Hooks Class Initialized
DEBUG - 2023-11-10 17:36:37 --> UTF-8 Support Enabled
INFO - 2023-11-10 17:36:37 --> Utf8 Class Initialized
INFO - 2023-11-10 17:36:37 --> URI Class Initialized
DEBUG - 2023-11-10 17:36:37 --> No URI present. Default controller set.
INFO - 2023-11-10 17:36:37 --> Router Class Initialized
INFO - 2023-11-10 17:36:37 --> Output Class Initialized
INFO - 2023-11-10 17:36:37 --> Security Class Initialized
DEBUG - 2023-11-10 17:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-10 17:36:37 --> Input Class Initialized
INFO - 2023-11-10 17:36:37 --> Language Class Initialized
INFO - 2023-11-10 17:36:37 --> Loader Class Initialized
INFO - 2023-11-10 17:36:37 --> Helper loaded: url_helper
INFO - 2023-11-10 17:36:37 --> Helper loaded: form_helper
INFO - 2023-11-10 17:36:37 --> Helper loaded: file_helper
INFO - 2023-11-10 17:36:37 --> Database Driver Class Initialized
DEBUG - 2023-11-10 17:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-10 17:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-10 17:36:37 --> Form Validation Class Initialized
INFO - 2023-11-10 17:36:37 --> Upload Class Initialized
INFO - 2023-11-10 17:36:37 --> Model "M_auth" initialized
INFO - 2023-11-10 17:36:37 --> Model "M_user" initialized
INFO - 2023-11-10 17:36:37 --> Model "M_produk" initialized
INFO - 2023-11-10 17:36:37 --> Controller Class Initialized
INFO - 2023-11-10 17:36:37 --> Model "M_pelanggan" initialized
INFO - 2023-11-10 17:36:37 --> Model "M_produk" initialized
DEBUG - 2023-11-10 17:36:37 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-10 17:36:37 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-10 17:36:37 --> Model "M_transaksi" initialized
INFO - 2023-11-10 17:36:37 --> Model "M_bank" initialized
INFO - 2023-11-10 17:36:37 --> Model "M_pesan" initialized
DEBUG - 2023-11-10 17:36:37 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-10 17:36:37 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-10 17:36:37 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-10 17:36:37 --> Final output sent to browser
DEBUG - 2023-11-10 17:36:37 --> Total execution time: 0.0114
ERROR - 2023-11-10 19:45:48 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-10 19:45:48 --> Config Class Initialized
INFO - 2023-11-10 19:45:48 --> Hooks Class Initialized
DEBUG - 2023-11-10 19:45:48 --> UTF-8 Support Enabled
INFO - 2023-11-10 19:45:48 --> Utf8 Class Initialized
INFO - 2023-11-10 19:45:48 --> URI Class Initialized
DEBUG - 2023-11-10 19:45:48 --> No URI present. Default controller set.
INFO - 2023-11-10 19:45:48 --> Router Class Initialized
INFO - 2023-11-10 19:45:48 --> Output Class Initialized
INFO - 2023-11-10 19:45:48 --> Security Class Initialized
DEBUG - 2023-11-10 19:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-10 19:45:48 --> Input Class Initialized
INFO - 2023-11-10 19:45:48 --> Language Class Initialized
INFO - 2023-11-10 19:45:48 --> Loader Class Initialized
INFO - 2023-11-10 19:45:48 --> Helper loaded: url_helper
INFO - 2023-11-10 19:45:48 --> Helper loaded: form_helper
INFO - 2023-11-10 19:45:48 --> Helper loaded: file_helper
INFO - 2023-11-10 19:45:48 --> Database Driver Class Initialized
DEBUG - 2023-11-10 19:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-10 19:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-10 19:45:48 --> Form Validation Class Initialized
INFO - 2023-11-10 19:45:48 --> Upload Class Initialized
INFO - 2023-11-10 19:45:48 --> Model "M_auth" initialized
INFO - 2023-11-10 19:45:48 --> Model "M_user" initialized
INFO - 2023-11-10 19:45:48 --> Model "M_produk" initialized
INFO - 2023-11-10 19:45:48 --> Controller Class Initialized
INFO - 2023-11-10 19:45:48 --> Model "M_pelanggan" initialized
INFO - 2023-11-10 19:45:48 --> Model "M_produk" initialized
DEBUG - 2023-11-10 19:45:48 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-10 19:45:48 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-10 19:45:48 --> Model "M_transaksi" initialized
INFO - 2023-11-10 19:45:48 --> Model "M_bank" initialized
INFO - 2023-11-10 19:45:48 --> Model "M_pesan" initialized
DEBUG - 2023-11-10 19:45:48 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-10 19:45:48 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-10 19:45:48 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-10 19:45:48 --> Final output sent to browser
DEBUG - 2023-11-10 19:45:48 --> Total execution time: 0.0443
