<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-11 04:46:05 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-11 04:46:05 --> Config Class Initialized
INFO - 2023-11-11 04:46:05 --> Hooks Class Initialized
DEBUG - 2023-11-11 04:46:05 --> UTF-8 Support Enabled
INFO - 2023-11-11 04:46:05 --> Utf8 Class Initialized
INFO - 2023-11-11 04:46:05 --> URI Class Initialized
DEBUG - 2023-11-11 04:46:05 --> No URI present. Default controller set.
INFO - 2023-11-11 04:46:05 --> Router Class Initialized
INFO - 2023-11-11 04:46:05 --> Output Class Initialized
INFO - 2023-11-11 04:46:05 --> Security Class Initialized
DEBUG - 2023-11-11 04:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-11 04:46:05 --> Input Class Initialized
INFO - 2023-11-11 04:46:05 --> Language Class Initialized
INFO - 2023-11-11 04:46:05 --> Loader Class Initialized
INFO - 2023-11-11 04:46:05 --> Helper loaded: url_helper
INFO - 2023-11-11 04:46:05 --> Helper loaded: form_helper
INFO - 2023-11-11 04:46:05 --> Helper loaded: file_helper
INFO - 2023-11-11 04:46:05 --> Database Driver Class Initialized
DEBUG - 2023-11-11 04:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-11 04:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-11 04:46:05 --> Form Validation Class Initialized
INFO - 2023-11-11 04:46:05 --> Upload Class Initialized
INFO - 2023-11-11 04:46:05 --> Model "M_auth" initialized
INFO - 2023-11-11 04:46:05 --> Model "M_user" initialized
INFO - 2023-11-11 04:46:05 --> Model "M_produk" initialized
INFO - 2023-11-11 04:46:05 --> Controller Class Initialized
INFO - 2023-11-11 04:46:05 --> Model "M_pelanggan" initialized
INFO - 2023-11-11 04:46:05 --> Model "M_produk" initialized
DEBUG - 2023-11-11 04:46:05 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-11 04:46:05 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-11 04:46:05 --> Model "M_transaksi" initialized
INFO - 2023-11-11 04:46:05 --> Model "M_bank" initialized
INFO - 2023-11-11 04:46:05 --> Model "M_pesan" initialized
DEBUG - 2023-11-11 04:46:05 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-11 04:46:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-11 04:46:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-11 04:46:05 --> Final output sent to browser
DEBUG - 2023-11-11 04:46:05 --> Total execution time: 0.0485
ERROR - 2023-11-11 07:57:35 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-11 07:57:35 --> Config Class Initialized
INFO - 2023-11-11 07:57:35 --> Hooks Class Initialized
DEBUG - 2023-11-11 07:57:35 --> UTF-8 Support Enabled
INFO - 2023-11-11 07:57:35 --> Utf8 Class Initialized
INFO - 2023-11-11 07:57:35 --> URI Class Initialized
DEBUG - 2023-11-11 07:57:35 --> No URI present. Default controller set.
INFO - 2023-11-11 07:57:35 --> Router Class Initialized
INFO - 2023-11-11 07:57:35 --> Output Class Initialized
INFO - 2023-11-11 07:57:35 --> Security Class Initialized
DEBUG - 2023-11-11 07:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-11 07:57:35 --> Input Class Initialized
INFO - 2023-11-11 07:57:35 --> Language Class Initialized
INFO - 2023-11-11 07:57:35 --> Loader Class Initialized
INFO - 2023-11-11 07:57:35 --> Helper loaded: url_helper
INFO - 2023-11-11 07:57:35 --> Helper loaded: form_helper
INFO - 2023-11-11 07:57:35 --> Helper loaded: file_helper
INFO - 2023-11-11 07:57:35 --> Database Driver Class Initialized
DEBUG - 2023-11-11 07:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-11 07:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-11 07:57:35 --> Form Validation Class Initialized
INFO - 2023-11-11 07:57:35 --> Upload Class Initialized
INFO - 2023-11-11 07:57:35 --> Model "M_auth" initialized
INFO - 2023-11-11 07:57:35 --> Model "M_user" initialized
INFO - 2023-11-11 07:57:35 --> Model "M_produk" initialized
INFO - 2023-11-11 07:57:35 --> Controller Class Initialized
INFO - 2023-11-11 07:57:35 --> Model "M_pelanggan" initialized
INFO - 2023-11-11 07:57:35 --> Model "M_produk" initialized
DEBUG - 2023-11-11 07:57:35 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-11 07:57:35 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-11 07:57:35 --> Model "M_transaksi" initialized
INFO - 2023-11-11 07:57:35 --> Model "M_bank" initialized
INFO - 2023-11-11 07:57:35 --> Model "M_pesan" initialized
DEBUG - 2023-11-11 07:57:35 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-11 07:57:35 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-11 07:57:35 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-11 07:57:35 --> Final output sent to browser
DEBUG - 2023-11-11 07:57:35 --> Total execution time: 0.0536
ERROR - 2023-11-11 11:27:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-11 11:27:45 --> Config Class Initialized
INFO - 2023-11-11 11:27:45 --> Hooks Class Initialized
DEBUG - 2023-11-11 11:27:45 --> UTF-8 Support Enabled
INFO - 2023-11-11 11:27:45 --> Utf8 Class Initialized
INFO - 2023-11-11 11:27:45 --> URI Class Initialized
INFO - 2023-11-11 11:27:45 --> Router Class Initialized
INFO - 2023-11-11 11:27:45 --> Output Class Initialized
INFO - 2023-11-11 11:27:45 --> Security Class Initialized
DEBUG - 2023-11-11 11:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-11 11:27:45 --> Input Class Initialized
INFO - 2023-11-11 11:27:45 --> Language Class Initialized
INFO - 2023-11-11 11:27:45 --> Loader Class Initialized
INFO - 2023-11-11 11:27:45 --> Helper loaded: url_helper
INFO - 2023-11-11 11:27:45 --> Helper loaded: form_helper
INFO - 2023-11-11 11:27:45 --> Helper loaded: file_helper
INFO - 2023-11-11 11:27:45 --> Database Driver Class Initialized
DEBUG - 2023-11-11 11:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-11 11:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-11 11:27:45 --> Form Validation Class Initialized
INFO - 2023-11-11 11:27:45 --> Upload Class Initialized
INFO - 2023-11-11 11:27:45 --> Model "M_auth" initialized
INFO - 2023-11-11 11:27:45 --> Model "M_user" initialized
INFO - 2023-11-11 11:27:45 --> Model "M_produk" initialized
INFO - 2023-11-11 11:27:45 --> Controller Class Initialized
INFO - 2023-11-11 11:27:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-11 11:27:45 --> Final output sent to browser
DEBUG - 2023-11-11 11:27:45 --> Total execution time: 0.0376
ERROR - 2023-11-11 11:27:47 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-11 11:27:47 --> Config Class Initialized
INFO - 2023-11-11 11:27:47 --> Hooks Class Initialized
DEBUG - 2023-11-11 11:27:47 --> UTF-8 Support Enabled
INFO - 2023-11-11 11:27:47 --> Utf8 Class Initialized
INFO - 2023-11-11 11:27:47 --> URI Class Initialized
DEBUG - 2023-11-11 11:27:47 --> No URI present. Default controller set.
INFO - 2023-11-11 11:27:47 --> Router Class Initialized
INFO - 2023-11-11 11:27:47 --> Output Class Initialized
INFO - 2023-11-11 11:27:47 --> Security Class Initialized
DEBUG - 2023-11-11 11:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-11 11:27:47 --> Input Class Initialized
INFO - 2023-11-11 11:27:47 --> Language Class Initialized
INFO - 2023-11-11 11:27:47 --> Loader Class Initialized
INFO - 2023-11-11 11:27:47 --> Helper loaded: url_helper
INFO - 2023-11-11 11:27:47 --> Helper loaded: form_helper
INFO - 2023-11-11 11:27:47 --> Helper loaded: file_helper
INFO - 2023-11-11 11:27:47 --> Database Driver Class Initialized
DEBUG - 2023-11-11 11:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-11 11:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-11 11:27:47 --> Form Validation Class Initialized
INFO - 2023-11-11 11:27:47 --> Upload Class Initialized
INFO - 2023-11-11 11:27:47 --> Model "M_auth" initialized
INFO - 2023-11-11 11:27:47 --> Model "M_user" initialized
INFO - 2023-11-11 11:27:47 --> Model "M_produk" initialized
INFO - 2023-11-11 11:27:47 --> Controller Class Initialized
INFO - 2023-11-11 11:27:47 --> Model "M_pelanggan" initialized
INFO - 2023-11-11 11:27:47 --> Model "M_produk" initialized
DEBUG - 2023-11-11 11:27:47 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-11 11:27:47 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-11 11:27:47 --> Model "M_transaksi" initialized
INFO - 2023-11-11 11:27:47 --> Model "M_bank" initialized
INFO - 2023-11-11 11:27:47 --> Model "M_pesan" initialized
DEBUG - 2023-11-11 11:27:47 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-11 11:27:47 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-11 11:27:47 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-11 11:27:47 --> Final output sent to browser
DEBUG - 2023-11-11 11:27:47 --> Total execution time: 0.0163
ERROR - 2023-11-11 12:05:23 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-11 12:05:23 --> Config Class Initialized
INFO - 2023-11-11 12:05:23 --> Hooks Class Initialized
DEBUG - 2023-11-11 12:05:23 --> UTF-8 Support Enabled
INFO - 2023-11-11 12:05:23 --> Utf8 Class Initialized
INFO - 2023-11-11 12:05:23 --> URI Class Initialized
INFO - 2023-11-11 12:05:23 --> Router Class Initialized
INFO - 2023-11-11 12:05:23 --> Output Class Initialized
INFO - 2023-11-11 12:05:23 --> Security Class Initialized
DEBUG - 2023-11-11 12:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-11 12:05:23 --> Input Class Initialized
INFO - 2023-11-11 12:05:23 --> Language Class Initialized
INFO - 2023-11-11 12:05:23 --> Loader Class Initialized
INFO - 2023-11-11 12:05:23 --> Helper loaded: url_helper
INFO - 2023-11-11 12:05:23 --> Helper loaded: form_helper
INFO - 2023-11-11 12:05:23 --> Helper loaded: file_helper
INFO - 2023-11-11 12:05:23 --> Database Driver Class Initialized
DEBUG - 2023-11-11 12:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-11 12:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-11 12:05:23 --> Form Validation Class Initialized
INFO - 2023-11-11 12:05:23 --> Upload Class Initialized
INFO - 2023-11-11 12:05:23 --> Model "M_auth" initialized
INFO - 2023-11-11 12:05:23 --> Model "M_user" initialized
INFO - 2023-11-11 12:05:23 --> Model "M_produk" initialized
INFO - 2023-11-11 12:05:23 --> Controller Class Initialized
INFO - 2023-11-11 12:05:23 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-11 12:05:23 --> Final output sent to browser
DEBUG - 2023-11-11 12:05:23 --> Total execution time: 0.0438
ERROR - 2023-11-11 12:05:24 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-11 12:05:24 --> Config Class Initialized
INFO - 2023-11-11 12:05:24 --> Hooks Class Initialized
DEBUG - 2023-11-11 12:05:24 --> UTF-8 Support Enabled
INFO - 2023-11-11 12:05:24 --> Utf8 Class Initialized
INFO - 2023-11-11 12:05:24 --> URI Class Initialized
DEBUG - 2023-11-11 12:05:24 --> No URI present. Default controller set.
INFO - 2023-11-11 12:05:24 --> Router Class Initialized
INFO - 2023-11-11 12:05:24 --> Output Class Initialized
INFO - 2023-11-11 12:05:24 --> Security Class Initialized
DEBUG - 2023-11-11 12:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-11 12:05:24 --> Input Class Initialized
INFO - 2023-11-11 12:05:24 --> Language Class Initialized
INFO - 2023-11-11 12:05:24 --> Loader Class Initialized
INFO - 2023-11-11 12:05:24 --> Helper loaded: url_helper
INFO - 2023-11-11 12:05:24 --> Helper loaded: form_helper
INFO - 2023-11-11 12:05:24 --> Helper loaded: file_helper
INFO - 2023-11-11 12:05:24 --> Database Driver Class Initialized
DEBUG - 2023-11-11 12:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-11 12:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-11 12:05:24 --> Form Validation Class Initialized
INFO - 2023-11-11 12:05:24 --> Upload Class Initialized
INFO - 2023-11-11 12:05:24 --> Model "M_auth" initialized
INFO - 2023-11-11 12:05:24 --> Model "M_user" initialized
INFO - 2023-11-11 12:05:24 --> Model "M_produk" initialized
INFO - 2023-11-11 12:05:24 --> Controller Class Initialized
INFO - 2023-11-11 12:05:24 --> Model "M_pelanggan" initialized
INFO - 2023-11-11 12:05:24 --> Model "M_produk" initialized
DEBUG - 2023-11-11 12:05:24 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-11 12:05:24 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-11 12:05:24 --> Model "M_transaksi" initialized
INFO - 2023-11-11 12:05:24 --> Model "M_bank" initialized
INFO - 2023-11-11 12:05:24 --> Model "M_pesan" initialized
DEBUG - 2023-11-11 12:05:24 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-11 12:05:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-11 12:05:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-11 12:05:24 --> Final output sent to browser
DEBUG - 2023-11-11 12:05:24 --> Total execution time: 0.0128
ERROR - 2023-11-11 12:30:29 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-11 12:30:29 --> Config Class Initialized
INFO - 2023-11-11 12:30:29 --> Hooks Class Initialized
DEBUG - 2023-11-11 12:30:29 --> UTF-8 Support Enabled
INFO - 2023-11-11 12:30:29 --> Utf8 Class Initialized
INFO - 2023-11-11 12:30:29 --> URI Class Initialized
DEBUG - 2023-11-11 12:30:29 --> No URI present. Default controller set.
INFO - 2023-11-11 12:30:29 --> Router Class Initialized
INFO - 2023-11-11 12:30:29 --> Output Class Initialized
INFO - 2023-11-11 12:30:29 --> Security Class Initialized
DEBUG - 2023-11-11 12:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-11 12:30:29 --> Input Class Initialized
INFO - 2023-11-11 12:30:29 --> Language Class Initialized
INFO - 2023-11-11 12:30:29 --> Loader Class Initialized
INFO - 2023-11-11 12:30:29 --> Helper loaded: url_helper
INFO - 2023-11-11 12:30:29 --> Helper loaded: form_helper
INFO - 2023-11-11 12:30:29 --> Helper loaded: file_helper
INFO - 2023-11-11 12:30:29 --> Database Driver Class Initialized
DEBUG - 2023-11-11 12:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-11 12:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-11 12:30:29 --> Form Validation Class Initialized
INFO - 2023-11-11 12:30:29 --> Upload Class Initialized
INFO - 2023-11-11 12:30:29 --> Model "M_auth" initialized
INFO - 2023-11-11 12:30:29 --> Model "M_user" initialized
INFO - 2023-11-11 12:30:29 --> Model "M_produk" initialized
INFO - 2023-11-11 12:30:29 --> Controller Class Initialized
INFO - 2023-11-11 12:30:29 --> Model "M_pelanggan" initialized
INFO - 2023-11-11 12:30:29 --> Model "M_produk" initialized
DEBUG - 2023-11-11 12:30:29 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-11 12:30:29 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-11 12:30:29 --> Model "M_transaksi" initialized
INFO - 2023-11-11 12:30:29 --> Model "M_bank" initialized
INFO - 2023-11-11 12:30:29 --> Model "M_pesan" initialized
DEBUG - 2023-11-11 12:30:29 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-11 12:30:29 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-11 12:30:29 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-11 12:30:29 --> Final output sent to browser
DEBUG - 2023-11-11 12:30:29 --> Total execution time: 0.0365
ERROR - 2023-11-11 13:00:51 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-11 13:00:51 --> Config Class Initialized
INFO - 2023-11-11 13:00:51 --> Hooks Class Initialized
DEBUG - 2023-11-11 13:00:51 --> UTF-8 Support Enabled
INFO - 2023-11-11 13:00:51 --> Utf8 Class Initialized
INFO - 2023-11-11 13:00:51 --> URI Class Initialized
INFO - 2023-11-11 13:00:51 --> Router Class Initialized
INFO - 2023-11-11 13:00:51 --> Output Class Initialized
INFO - 2023-11-11 13:00:51 --> Security Class Initialized
DEBUG - 2023-11-11 13:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-11 13:00:51 --> Input Class Initialized
INFO - 2023-11-11 13:00:51 --> Language Class Initialized
INFO - 2023-11-11 13:00:51 --> Loader Class Initialized
INFO - 2023-11-11 13:00:51 --> Helper loaded: url_helper
INFO - 2023-11-11 13:00:51 --> Helper loaded: form_helper
INFO - 2023-11-11 13:00:51 --> Helper loaded: file_helper
INFO - 2023-11-11 13:00:51 --> Database Driver Class Initialized
DEBUG - 2023-11-11 13:00:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-11 13:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-11 13:00:51 --> Form Validation Class Initialized
INFO - 2023-11-11 13:00:51 --> Upload Class Initialized
INFO - 2023-11-11 13:00:51 --> Model "M_auth" initialized
INFO - 2023-11-11 13:00:51 --> Model "M_user" initialized
INFO - 2023-11-11 13:00:51 --> Model "M_produk" initialized
INFO - 2023-11-11 13:00:51 --> Controller Class Initialized
INFO - 2023-11-11 13:00:51 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-11 13:00:51 --> Final output sent to browser
DEBUG - 2023-11-11 13:00:51 --> Total execution time: 0.0334
ERROR - 2023-11-11 13:00:53 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-11 13:00:53 --> Config Class Initialized
INFO - 2023-11-11 13:00:53 --> Hooks Class Initialized
DEBUG - 2023-11-11 13:00:53 --> UTF-8 Support Enabled
INFO - 2023-11-11 13:00:53 --> Utf8 Class Initialized
INFO - 2023-11-11 13:00:53 --> URI Class Initialized
DEBUG - 2023-11-11 13:00:53 --> No URI present. Default controller set.
INFO - 2023-11-11 13:00:53 --> Router Class Initialized
INFO - 2023-11-11 13:00:53 --> Output Class Initialized
INFO - 2023-11-11 13:00:53 --> Security Class Initialized
DEBUG - 2023-11-11 13:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-11 13:00:53 --> Input Class Initialized
INFO - 2023-11-11 13:00:53 --> Language Class Initialized
INFO - 2023-11-11 13:00:53 --> Loader Class Initialized
INFO - 2023-11-11 13:00:53 --> Helper loaded: url_helper
INFO - 2023-11-11 13:00:53 --> Helper loaded: form_helper
INFO - 2023-11-11 13:00:53 --> Helper loaded: file_helper
INFO - 2023-11-11 13:00:53 --> Database Driver Class Initialized
DEBUG - 2023-11-11 13:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-11 13:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-11 13:00:53 --> Form Validation Class Initialized
INFO - 2023-11-11 13:00:53 --> Upload Class Initialized
INFO - 2023-11-11 13:00:53 --> Model "M_auth" initialized
INFO - 2023-11-11 13:00:53 --> Model "M_user" initialized
INFO - 2023-11-11 13:00:53 --> Model "M_produk" initialized
INFO - 2023-11-11 13:00:53 --> Controller Class Initialized
INFO - 2023-11-11 13:00:53 --> Model "M_pelanggan" initialized
INFO - 2023-11-11 13:00:53 --> Model "M_produk" initialized
DEBUG - 2023-11-11 13:00:53 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-11 13:00:53 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-11 13:00:53 --> Model "M_transaksi" initialized
INFO - 2023-11-11 13:00:53 --> Model "M_bank" initialized
INFO - 2023-11-11 13:00:53 --> Model "M_pesan" initialized
DEBUG - 2023-11-11 13:00:53 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-11 13:00:53 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-11 13:00:53 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-11 13:00:53 --> Final output sent to browser
DEBUG - 2023-11-11 13:00:53 --> Total execution time: 0.0118
ERROR - 2023-11-11 14:47:44 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-11 14:47:44 --> Config Class Initialized
INFO - 2023-11-11 14:47:44 --> Hooks Class Initialized
DEBUG - 2023-11-11 14:47:44 --> UTF-8 Support Enabled
INFO - 2023-11-11 14:47:44 --> Utf8 Class Initialized
INFO - 2023-11-11 14:47:44 --> URI Class Initialized
DEBUG - 2023-11-11 14:47:44 --> No URI present. Default controller set.
INFO - 2023-11-11 14:47:44 --> Router Class Initialized
INFO - 2023-11-11 14:47:44 --> Output Class Initialized
INFO - 2023-11-11 14:47:44 --> Security Class Initialized
DEBUG - 2023-11-11 14:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-11 14:47:44 --> Input Class Initialized
INFO - 2023-11-11 14:47:44 --> Language Class Initialized
INFO - 2023-11-11 14:47:44 --> Loader Class Initialized
INFO - 2023-11-11 14:47:44 --> Helper loaded: url_helper
INFO - 2023-11-11 14:47:44 --> Helper loaded: form_helper
INFO - 2023-11-11 14:47:44 --> Helper loaded: file_helper
INFO - 2023-11-11 14:47:44 --> Database Driver Class Initialized
DEBUG - 2023-11-11 14:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-11 14:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-11 14:47:44 --> Form Validation Class Initialized
INFO - 2023-11-11 14:47:44 --> Upload Class Initialized
INFO - 2023-11-11 14:47:44 --> Model "M_auth" initialized
INFO - 2023-11-11 14:47:44 --> Model "M_user" initialized
INFO - 2023-11-11 14:47:44 --> Model "M_produk" initialized
INFO - 2023-11-11 14:47:44 --> Controller Class Initialized
INFO - 2023-11-11 14:47:44 --> Model "M_pelanggan" initialized
INFO - 2023-11-11 14:47:44 --> Model "M_produk" initialized
DEBUG - 2023-11-11 14:47:44 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-11 14:47:44 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-11 14:47:44 --> Model "M_transaksi" initialized
INFO - 2023-11-11 14:47:44 --> Model "M_bank" initialized
INFO - 2023-11-11 14:47:44 --> Model "M_pesan" initialized
DEBUG - 2023-11-11 14:47:44 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-11 14:47:44 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-11 14:47:44 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-11 14:47:44 --> Final output sent to browser
DEBUG - 2023-11-11 14:47:44 --> Total execution time: 0.0410
ERROR - 2023-11-11 15:38:42 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-11 15:38:42 --> Config Class Initialized
INFO - 2023-11-11 15:38:42 --> Hooks Class Initialized
DEBUG - 2023-11-11 15:38:42 --> UTF-8 Support Enabled
INFO - 2023-11-11 15:38:42 --> Utf8 Class Initialized
INFO - 2023-11-11 15:38:42 --> URI Class Initialized
DEBUG - 2023-11-11 15:38:42 --> No URI present. Default controller set.
INFO - 2023-11-11 15:38:42 --> Router Class Initialized
INFO - 2023-11-11 15:38:42 --> Output Class Initialized
INFO - 2023-11-11 15:38:42 --> Security Class Initialized
DEBUG - 2023-11-11 15:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-11 15:38:42 --> Input Class Initialized
INFO - 2023-11-11 15:38:42 --> Language Class Initialized
INFO - 2023-11-11 15:38:42 --> Loader Class Initialized
INFO - 2023-11-11 15:38:42 --> Helper loaded: url_helper
INFO - 2023-11-11 15:38:42 --> Helper loaded: form_helper
INFO - 2023-11-11 15:38:42 --> Helper loaded: file_helper
INFO - 2023-11-11 15:38:42 --> Database Driver Class Initialized
DEBUG - 2023-11-11 15:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-11 15:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-11 15:38:42 --> Form Validation Class Initialized
INFO - 2023-11-11 15:38:42 --> Upload Class Initialized
INFO - 2023-11-11 15:38:42 --> Model "M_auth" initialized
INFO - 2023-11-11 15:38:42 --> Model "M_user" initialized
INFO - 2023-11-11 15:38:42 --> Model "M_produk" initialized
INFO - 2023-11-11 15:38:42 --> Controller Class Initialized
INFO - 2023-11-11 15:38:42 --> Model "M_pelanggan" initialized
INFO - 2023-11-11 15:38:42 --> Model "M_produk" initialized
DEBUG - 2023-11-11 15:38:42 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-11 15:38:42 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-11 15:38:42 --> Model "M_transaksi" initialized
INFO - 2023-11-11 15:38:42 --> Model "M_bank" initialized
INFO - 2023-11-11 15:38:42 --> Model "M_pesan" initialized
DEBUG - 2023-11-11 15:38:42 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-11 15:38:42 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-11 15:38:42 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-11 15:38:42 --> Final output sent to browser
DEBUG - 2023-11-11 15:38:42 --> Total execution time: 0.0395
ERROR - 2023-11-11 16:15:17 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-11 16:15:17 --> Config Class Initialized
INFO - 2023-11-11 16:15:17 --> Hooks Class Initialized
DEBUG - 2023-11-11 16:15:17 --> UTF-8 Support Enabled
INFO - 2023-11-11 16:15:17 --> Utf8 Class Initialized
INFO - 2023-11-11 16:15:17 --> URI Class Initialized
DEBUG - 2023-11-11 16:15:17 --> No URI present. Default controller set.
INFO - 2023-11-11 16:15:17 --> Router Class Initialized
INFO - 2023-11-11 16:15:17 --> Output Class Initialized
INFO - 2023-11-11 16:15:17 --> Security Class Initialized
DEBUG - 2023-11-11 16:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-11 16:15:17 --> Input Class Initialized
INFO - 2023-11-11 16:15:17 --> Language Class Initialized
INFO - 2023-11-11 16:15:17 --> Loader Class Initialized
INFO - 2023-11-11 16:15:17 --> Helper loaded: url_helper
INFO - 2023-11-11 16:15:17 --> Helper loaded: form_helper
INFO - 2023-11-11 16:15:17 --> Helper loaded: file_helper
INFO - 2023-11-11 16:15:17 --> Database Driver Class Initialized
DEBUG - 2023-11-11 16:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-11 16:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-11 16:15:17 --> Form Validation Class Initialized
INFO - 2023-11-11 16:15:17 --> Upload Class Initialized
INFO - 2023-11-11 16:15:17 --> Model "M_auth" initialized
INFO - 2023-11-11 16:15:17 --> Model "M_user" initialized
INFO - 2023-11-11 16:15:17 --> Model "M_produk" initialized
INFO - 2023-11-11 16:15:17 --> Controller Class Initialized
INFO - 2023-11-11 16:15:17 --> Model "M_pelanggan" initialized
INFO - 2023-11-11 16:15:17 --> Model "M_produk" initialized
DEBUG - 2023-11-11 16:15:17 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-11 16:15:17 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-11 16:15:17 --> Model "M_transaksi" initialized
INFO - 2023-11-11 16:15:17 --> Model "M_bank" initialized
INFO - 2023-11-11 16:15:17 --> Model "M_pesan" initialized
DEBUG - 2023-11-11 16:15:17 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-11 16:15:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-11 16:15:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-11 16:15:17 --> Final output sent to browser
DEBUG - 2023-11-11 16:15:17 --> Total execution time: 0.0424
ERROR - 2023-11-11 16:50:07 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-11 16:50:07 --> Config Class Initialized
INFO - 2023-11-11 16:50:07 --> Hooks Class Initialized
DEBUG - 2023-11-11 16:50:07 --> UTF-8 Support Enabled
INFO - 2023-11-11 16:50:07 --> Utf8 Class Initialized
INFO - 2023-11-11 16:50:07 --> URI Class Initialized
INFO - 2023-11-11 16:50:07 --> Router Class Initialized
INFO - 2023-11-11 16:50:07 --> Output Class Initialized
INFO - 2023-11-11 16:50:07 --> Security Class Initialized
DEBUG - 2023-11-11 16:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-11 16:50:07 --> Input Class Initialized
INFO - 2023-11-11 16:50:07 --> Language Class Initialized
INFO - 2023-11-11 16:50:07 --> Loader Class Initialized
INFO - 2023-11-11 16:50:07 --> Helper loaded: url_helper
INFO - 2023-11-11 16:50:07 --> Helper loaded: form_helper
INFO - 2023-11-11 16:50:07 --> Helper loaded: file_helper
INFO - 2023-11-11 16:50:07 --> Database Driver Class Initialized
DEBUG - 2023-11-11 16:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-11 16:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-11 16:50:07 --> Form Validation Class Initialized
INFO - 2023-11-11 16:50:07 --> Upload Class Initialized
INFO - 2023-11-11 16:50:07 --> Model "M_auth" initialized
INFO - 2023-11-11 16:50:07 --> Model "M_user" initialized
INFO - 2023-11-11 16:50:07 --> Model "M_produk" initialized
INFO - 2023-11-11 16:50:07 --> Controller Class Initialized
INFO - 2023-11-11 16:50:07 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-11 16:50:07 --> Final output sent to browser
DEBUG - 2023-11-11 16:50:07 --> Total execution time: 0.0349
ERROR - 2023-11-11 18:02:46 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-11 18:02:46 --> Config Class Initialized
INFO - 2023-11-11 18:02:46 --> Hooks Class Initialized
DEBUG - 2023-11-11 18:02:46 --> UTF-8 Support Enabled
INFO - 2023-11-11 18:02:46 --> Utf8 Class Initialized
INFO - 2023-11-11 18:02:46 --> URI Class Initialized
DEBUG - 2023-11-11 18:02:46 --> No URI present. Default controller set.
INFO - 2023-11-11 18:02:46 --> Router Class Initialized
INFO - 2023-11-11 18:02:46 --> Output Class Initialized
INFO - 2023-11-11 18:02:46 --> Security Class Initialized
DEBUG - 2023-11-11 18:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-11 18:02:46 --> Input Class Initialized
INFO - 2023-11-11 18:02:46 --> Language Class Initialized
INFO - 2023-11-11 18:02:46 --> Loader Class Initialized
INFO - 2023-11-11 18:02:46 --> Helper loaded: url_helper
INFO - 2023-11-11 18:02:46 --> Helper loaded: form_helper
INFO - 2023-11-11 18:02:46 --> Helper loaded: file_helper
INFO - 2023-11-11 18:02:46 --> Database Driver Class Initialized
DEBUG - 2023-11-11 18:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-11 18:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-11 18:02:46 --> Form Validation Class Initialized
INFO - 2023-11-11 18:02:46 --> Upload Class Initialized
INFO - 2023-11-11 18:02:46 --> Model "M_auth" initialized
INFO - 2023-11-11 18:02:46 --> Model "M_user" initialized
INFO - 2023-11-11 18:02:46 --> Model "M_produk" initialized
INFO - 2023-11-11 18:02:46 --> Controller Class Initialized
INFO - 2023-11-11 18:02:46 --> Model "M_pelanggan" initialized
INFO - 2023-11-11 18:02:46 --> Model "M_produk" initialized
DEBUG - 2023-11-11 18:02:46 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-11 18:02:46 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-11 18:02:46 --> Model "M_transaksi" initialized
INFO - 2023-11-11 18:02:46 --> Model "M_bank" initialized
INFO - 2023-11-11 18:02:46 --> Model "M_pesan" initialized
DEBUG - 2023-11-11 18:02:46 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-11 18:02:46 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-11 18:02:46 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-11 18:02:46 --> Final output sent to browser
DEBUG - 2023-11-11 18:02:46 --> Total execution time: 0.0401
ERROR - 2023-11-11 18:13:01 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-11 18:13:01 --> Config Class Initialized
INFO - 2023-11-11 18:13:01 --> Hooks Class Initialized
DEBUG - 2023-11-11 18:13:01 --> UTF-8 Support Enabled
INFO - 2023-11-11 18:13:01 --> Utf8 Class Initialized
INFO - 2023-11-11 18:13:01 --> URI Class Initialized
DEBUG - 2023-11-11 18:13:01 --> No URI present. Default controller set.
INFO - 2023-11-11 18:13:01 --> Router Class Initialized
INFO - 2023-11-11 18:13:01 --> Output Class Initialized
INFO - 2023-11-11 18:13:01 --> Security Class Initialized
DEBUG - 2023-11-11 18:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-11 18:13:01 --> Input Class Initialized
INFO - 2023-11-11 18:13:01 --> Language Class Initialized
INFO - 2023-11-11 18:13:01 --> Loader Class Initialized
INFO - 2023-11-11 18:13:01 --> Helper loaded: url_helper
INFO - 2023-11-11 18:13:01 --> Helper loaded: form_helper
INFO - 2023-11-11 18:13:01 --> Helper loaded: file_helper
INFO - 2023-11-11 18:13:01 --> Database Driver Class Initialized
DEBUG - 2023-11-11 18:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-11 18:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-11 18:13:01 --> Form Validation Class Initialized
INFO - 2023-11-11 18:13:01 --> Upload Class Initialized
INFO - 2023-11-11 18:13:01 --> Model "M_auth" initialized
INFO - 2023-11-11 18:13:01 --> Model "M_user" initialized
INFO - 2023-11-11 18:13:01 --> Model "M_produk" initialized
INFO - 2023-11-11 18:13:01 --> Controller Class Initialized
INFO - 2023-11-11 18:13:01 --> Model "M_pelanggan" initialized
INFO - 2023-11-11 18:13:01 --> Model "M_produk" initialized
DEBUG - 2023-11-11 18:13:01 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-11 18:13:01 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-11 18:13:01 --> Model "M_transaksi" initialized
INFO - 2023-11-11 18:13:01 --> Model "M_bank" initialized
INFO - 2023-11-11 18:13:01 --> Model "M_pesan" initialized
DEBUG - 2023-11-11 18:13:01 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-11 18:13:01 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-11 18:13:01 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-11 18:13:01 --> Final output sent to browser
DEBUG - 2023-11-11 18:13:01 --> Total execution time: 0.0327
ERROR - 2023-11-11 19:09:15 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-11 19:09:15 --> Config Class Initialized
INFO - 2023-11-11 19:09:15 --> Hooks Class Initialized
DEBUG - 2023-11-11 19:09:15 --> UTF-8 Support Enabled
INFO - 2023-11-11 19:09:15 --> Utf8 Class Initialized
INFO - 2023-11-11 19:09:15 --> URI Class Initialized
DEBUG - 2023-11-11 19:09:15 --> No URI present. Default controller set.
INFO - 2023-11-11 19:09:15 --> Router Class Initialized
INFO - 2023-11-11 19:09:15 --> Output Class Initialized
INFO - 2023-11-11 19:09:15 --> Security Class Initialized
DEBUG - 2023-11-11 19:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-11 19:09:15 --> Input Class Initialized
INFO - 2023-11-11 19:09:15 --> Language Class Initialized
INFO - 2023-11-11 19:09:15 --> Loader Class Initialized
INFO - 2023-11-11 19:09:15 --> Helper loaded: url_helper
INFO - 2023-11-11 19:09:15 --> Helper loaded: form_helper
INFO - 2023-11-11 19:09:15 --> Helper loaded: file_helper
INFO - 2023-11-11 19:09:15 --> Database Driver Class Initialized
DEBUG - 2023-11-11 19:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-11 19:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-11 19:09:15 --> Form Validation Class Initialized
INFO - 2023-11-11 19:09:15 --> Upload Class Initialized
INFO - 2023-11-11 19:09:15 --> Model "M_auth" initialized
INFO - 2023-11-11 19:09:15 --> Model "M_user" initialized
INFO - 2023-11-11 19:09:15 --> Model "M_produk" initialized
INFO - 2023-11-11 19:09:15 --> Controller Class Initialized
INFO - 2023-11-11 19:09:15 --> Model "M_pelanggan" initialized
INFO - 2023-11-11 19:09:15 --> Model "M_produk" initialized
DEBUG - 2023-11-11 19:09:15 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-11 19:09:15 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-11 19:09:15 --> Model "M_transaksi" initialized
INFO - 2023-11-11 19:09:15 --> Model "M_bank" initialized
INFO - 2023-11-11 19:09:15 --> Model "M_pesan" initialized
DEBUG - 2023-11-11 19:09:15 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-11 19:09:15 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-11 19:09:15 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-11 19:09:15 --> Final output sent to browser
DEBUG - 2023-11-11 19:09:15 --> Total execution time: 0.0391
