<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-31 11:00:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:00:12 --> Config Class Initialized
INFO - 2023-10-31 11:00:12 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:00:12 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:00:12 --> Utf8 Class Initialized
INFO - 2023-10-31 11:00:12 --> URI Class Initialized
DEBUG - 2023-10-31 11:00:12 --> No URI present. Default controller set.
INFO - 2023-10-31 11:00:12 --> Router Class Initialized
INFO - 2023-10-31 11:00:12 --> Output Class Initialized
INFO - 2023-10-31 11:00:12 --> Security Class Initialized
DEBUG - 2023-10-31 11:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:00:12 --> Input Class Initialized
INFO - 2023-10-31 11:00:12 --> Language Class Initialized
INFO - 2023-10-31 11:00:12 --> Loader Class Initialized
INFO - 2023-10-31 11:00:12 --> Helper loaded: url_helper
INFO - 2023-10-31 11:00:12 --> Helper loaded: form_helper
INFO - 2023-10-31 11:00:12 --> Helper loaded: file_helper
INFO - 2023-10-31 11:00:12 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:00:12 --> Form Validation Class Initialized
INFO - 2023-10-31 11:00:12 --> Upload Class Initialized
INFO - 2023-10-31 11:00:12 --> Model "M_auth" initialized
INFO - 2023-10-31 11:00:12 --> Model "M_user" initialized
INFO - 2023-10-31 11:00:12 --> Model "M_produk" initialized
INFO - 2023-10-31 11:00:12 --> Controller Class Initialized
INFO - 2023-10-31 11:00:12 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:00:12 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:00:12 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:00:12 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:00:12 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:00:12 --> Model "M_bank" initialized
INFO - 2023-10-31 11:00:12 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:00:12 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:00:12 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:00:12 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-31 11:00:12 --> Final output sent to browser
DEBUG - 2023-10-31 11:00:12 --> Total execution time: 0.5479
ERROR - 2023-10-31 11:00:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:00:21 --> Config Class Initialized
INFO - 2023-10-31 11:00:21 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:00:21 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:00:21 --> Utf8 Class Initialized
INFO - 2023-10-31 11:00:21 --> URI Class Initialized
DEBUG - 2023-10-31 11:00:21 --> No URI present. Default controller set.
INFO - 2023-10-31 11:00:21 --> Router Class Initialized
INFO - 2023-10-31 11:00:21 --> Output Class Initialized
INFO - 2023-10-31 11:00:21 --> Security Class Initialized
DEBUG - 2023-10-31 11:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:00:21 --> Input Class Initialized
INFO - 2023-10-31 11:00:21 --> Language Class Initialized
INFO - 2023-10-31 11:00:21 --> Loader Class Initialized
INFO - 2023-10-31 11:00:21 --> Helper loaded: url_helper
INFO - 2023-10-31 11:00:21 --> Helper loaded: form_helper
INFO - 2023-10-31 11:00:21 --> Helper loaded: file_helper
INFO - 2023-10-31 11:00:21 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:00:21 --> Form Validation Class Initialized
INFO - 2023-10-31 11:00:21 --> Upload Class Initialized
INFO - 2023-10-31 11:00:21 --> Model "M_auth" initialized
INFO - 2023-10-31 11:00:21 --> Model "M_user" initialized
INFO - 2023-10-31 11:00:21 --> Model "M_produk" initialized
INFO - 2023-10-31 11:00:21 --> Controller Class Initialized
INFO - 2023-10-31 11:00:21 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:00:21 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:00:21 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:00:21 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:00:21 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:00:21 --> Model "M_bank" initialized
INFO - 2023-10-31 11:00:21 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:00:21 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:00:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-10-31 11:00:22 --> Email Class Initialized
INFO - 2023-10-31 11:00:22 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-10-31 11:00:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:00:25 --> Config Class Initialized
INFO - 2023-10-31 11:00:25 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:00:25 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:00:25 --> Utf8 Class Initialized
INFO - 2023-10-31 11:00:25 --> URI Class Initialized
DEBUG - 2023-10-31 11:00:25 --> No URI present. Default controller set.
INFO - 2023-10-31 11:00:25 --> Router Class Initialized
INFO - 2023-10-31 11:00:25 --> Output Class Initialized
INFO - 2023-10-31 11:00:25 --> Security Class Initialized
DEBUG - 2023-10-31 11:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:00:25 --> Input Class Initialized
INFO - 2023-10-31 11:00:25 --> Language Class Initialized
INFO - 2023-10-31 11:00:25 --> Loader Class Initialized
INFO - 2023-10-31 11:00:25 --> Helper loaded: url_helper
INFO - 2023-10-31 11:00:25 --> Helper loaded: form_helper
INFO - 2023-10-31 11:00:25 --> Helper loaded: file_helper
INFO - 2023-10-31 11:00:25 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:00:25 --> Form Validation Class Initialized
INFO - 2023-10-31 11:00:25 --> Upload Class Initialized
INFO - 2023-10-31 11:00:25 --> Model "M_auth" initialized
INFO - 2023-10-31 11:00:25 --> Model "M_user" initialized
INFO - 2023-10-31 11:00:25 --> Model "M_produk" initialized
INFO - 2023-10-31 11:00:25 --> Controller Class Initialized
INFO - 2023-10-31 11:00:25 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:00:25 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:00:25 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:00:25 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:00:25 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:00:25 --> Model "M_bank" initialized
INFO - 2023-10-31 11:00:25 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:00:25 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:00:25 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:00:25 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-31 11:00:25 --> Final output sent to browser
DEBUG - 2023-10-31 11:00:25 --> Total execution time: 0.0949
ERROR - 2023-10-31 11:00:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:00:30 --> Config Class Initialized
INFO - 2023-10-31 11:00:30 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:00:30 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:00:30 --> Utf8 Class Initialized
INFO - 2023-10-31 11:00:30 --> URI Class Initialized
INFO - 2023-10-31 11:00:30 --> Router Class Initialized
INFO - 2023-10-31 11:00:30 --> Output Class Initialized
INFO - 2023-10-31 11:00:30 --> Security Class Initialized
DEBUG - 2023-10-31 11:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:00:30 --> Input Class Initialized
INFO - 2023-10-31 11:00:30 --> Language Class Initialized
INFO - 2023-10-31 11:00:30 --> Loader Class Initialized
INFO - 2023-10-31 11:00:30 --> Helper loaded: url_helper
INFO - 2023-10-31 11:00:30 --> Helper loaded: form_helper
INFO - 2023-10-31 11:00:30 --> Helper loaded: file_helper
INFO - 2023-10-31 11:00:30 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:00:30 --> Form Validation Class Initialized
INFO - 2023-10-31 11:00:30 --> Upload Class Initialized
INFO - 2023-10-31 11:00:30 --> Model "M_auth" initialized
INFO - 2023-10-31 11:00:30 --> Model "M_user" initialized
INFO - 2023-10-31 11:00:30 --> Model "M_produk" initialized
INFO - 2023-10-31 11:00:30 --> Controller Class Initialized
INFO - 2023-10-31 11:00:30 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:00:30 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:00:30 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:00:30 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:00:30 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:00:30 --> Model "M_bank" initialized
INFO - 2023-10-31 11:00:30 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:00:30 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:00:32 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:00:32 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:00:32 --> Final output sent to browser
DEBUG - 2023-10-31 11:00:32 --> Total execution time: 1.7619
ERROR - 2023-10-31 11:00:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:00:40 --> Config Class Initialized
INFO - 2023-10-31 11:00:40 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:00:40 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:00:40 --> Utf8 Class Initialized
INFO - 2023-10-31 11:00:40 --> URI Class Initialized
INFO - 2023-10-31 11:00:40 --> Router Class Initialized
INFO - 2023-10-31 11:00:40 --> Output Class Initialized
INFO - 2023-10-31 11:00:41 --> Security Class Initialized
DEBUG - 2023-10-31 11:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:00:41 --> Input Class Initialized
INFO - 2023-10-31 11:00:41 --> Language Class Initialized
INFO - 2023-10-31 11:00:41 --> Loader Class Initialized
INFO - 2023-10-31 11:00:41 --> Helper loaded: url_helper
INFO - 2023-10-31 11:00:41 --> Helper loaded: form_helper
INFO - 2023-10-31 11:00:41 --> Helper loaded: file_helper
INFO - 2023-10-31 11:00:41 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:00:41 --> Form Validation Class Initialized
INFO - 2023-10-31 11:00:41 --> Upload Class Initialized
INFO - 2023-10-31 11:00:41 --> Model "M_auth" initialized
INFO - 2023-10-31 11:00:41 --> Model "M_user" initialized
INFO - 2023-10-31 11:00:41 --> Model "M_produk" initialized
INFO - 2023-10-31 11:00:41 --> Controller Class Initialized
INFO - 2023-10-31 11:00:41 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:00:41 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:00:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:00:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:00:41 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:00:41 --> Model "M_bank" initialized
INFO - 2023-10-31 11:00:41 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:00:41 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:00:41 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:00:41 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:00:41 --> Final output sent to browser
DEBUG - 2023-10-31 11:00:41 --> Total execution time: 0.3834
ERROR - 2023-10-31 11:05:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:05:09 --> Config Class Initialized
INFO - 2023-10-31 11:05:09 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:05:09 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:05:09 --> Utf8 Class Initialized
INFO - 2023-10-31 11:05:09 --> URI Class Initialized
INFO - 2023-10-31 11:05:09 --> Router Class Initialized
INFO - 2023-10-31 11:05:09 --> Output Class Initialized
INFO - 2023-10-31 11:05:09 --> Security Class Initialized
DEBUG - 2023-10-31 11:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:05:09 --> Input Class Initialized
INFO - 2023-10-31 11:05:09 --> Language Class Initialized
INFO - 2023-10-31 11:05:09 --> Loader Class Initialized
INFO - 2023-10-31 11:05:09 --> Helper loaded: url_helper
INFO - 2023-10-31 11:05:09 --> Helper loaded: form_helper
INFO - 2023-10-31 11:05:09 --> Helper loaded: file_helper
INFO - 2023-10-31 11:05:09 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:05:09 --> Form Validation Class Initialized
INFO - 2023-10-31 11:05:09 --> Upload Class Initialized
INFO - 2023-10-31 11:05:09 --> Model "M_auth" initialized
INFO - 2023-10-31 11:05:09 --> Model "M_user" initialized
INFO - 2023-10-31 11:05:09 --> Model "M_produk" initialized
INFO - 2023-10-31 11:05:09 --> Controller Class Initialized
INFO - 2023-10-31 11:05:09 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:05:09 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:05:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:05:09 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:05:09 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:05:09 --> Model "M_bank" initialized
INFO - 2023-10-31 11:05:09 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:05:09 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:05:09 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:05:09 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:05:09 --> Final output sent to browser
DEBUG - 2023-10-31 11:05:09 --> Total execution time: 0.5709
ERROR - 2023-10-31 11:05:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:05:17 --> Config Class Initialized
INFO - 2023-10-31 11:05:17 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:05:17 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:05:17 --> Utf8 Class Initialized
INFO - 2023-10-31 11:05:17 --> URI Class Initialized
INFO - 2023-10-31 11:05:17 --> Router Class Initialized
INFO - 2023-10-31 11:05:17 --> Output Class Initialized
INFO - 2023-10-31 11:05:17 --> Security Class Initialized
DEBUG - 2023-10-31 11:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:05:17 --> Input Class Initialized
INFO - 2023-10-31 11:05:17 --> Language Class Initialized
INFO - 2023-10-31 11:05:17 --> Loader Class Initialized
INFO - 2023-10-31 11:05:17 --> Helper loaded: url_helper
INFO - 2023-10-31 11:05:17 --> Helper loaded: form_helper
INFO - 2023-10-31 11:05:17 --> Helper loaded: file_helper
INFO - 2023-10-31 11:05:17 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:05:17 --> Form Validation Class Initialized
INFO - 2023-10-31 11:05:17 --> Upload Class Initialized
INFO - 2023-10-31 11:05:17 --> Model "M_auth" initialized
INFO - 2023-10-31 11:05:17 --> Model "M_user" initialized
INFO - 2023-10-31 11:05:17 --> Model "M_produk" initialized
INFO - 2023-10-31 11:05:17 --> Controller Class Initialized
INFO - 2023-10-31 11:05:17 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:05:17 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:05:17 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:05:17 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:05:17 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:05:17 --> Model "M_bank" initialized
INFO - 2023-10-31 11:05:17 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:05:17 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:05:17 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:05:17 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:05:17 --> Final output sent to browser
DEBUG - 2023-10-31 11:05:17 --> Total execution time: 0.4171
ERROR - 2023-10-31 11:06:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:06:28 --> Config Class Initialized
INFO - 2023-10-31 11:06:28 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:06:28 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:06:28 --> Utf8 Class Initialized
INFO - 2023-10-31 11:06:28 --> URI Class Initialized
INFO - 2023-10-31 11:06:28 --> Router Class Initialized
INFO - 2023-10-31 11:06:28 --> Output Class Initialized
INFO - 2023-10-31 11:06:28 --> Security Class Initialized
DEBUG - 2023-10-31 11:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:06:28 --> Input Class Initialized
INFO - 2023-10-31 11:06:28 --> Language Class Initialized
INFO - 2023-10-31 11:06:28 --> Loader Class Initialized
INFO - 2023-10-31 11:06:28 --> Helper loaded: url_helper
INFO - 2023-10-31 11:06:28 --> Helper loaded: form_helper
INFO - 2023-10-31 11:06:28 --> Helper loaded: file_helper
INFO - 2023-10-31 11:06:28 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:06:28 --> Form Validation Class Initialized
INFO - 2023-10-31 11:06:28 --> Upload Class Initialized
INFO - 2023-10-31 11:06:28 --> Model "M_auth" initialized
INFO - 2023-10-31 11:06:28 --> Model "M_user" initialized
INFO - 2023-10-31 11:06:28 --> Model "M_produk" initialized
INFO - 2023-10-31 11:06:28 --> Controller Class Initialized
INFO - 2023-10-31 11:06:28 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:06:28 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:06:28 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:06:28 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:06:28 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:06:28 --> Model "M_bank" initialized
INFO - 2023-10-31 11:06:28 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:06:28 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:06:28 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:06:28 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:06:28 --> Final output sent to browser
DEBUG - 2023-10-31 11:06:28 --> Total execution time: 0.4449
ERROR - 2023-10-31 11:17:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:17:18 --> Config Class Initialized
INFO - 2023-10-31 11:17:18 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:17:18 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:17:18 --> Utf8 Class Initialized
INFO - 2023-10-31 11:17:18 --> URI Class Initialized
INFO - 2023-10-31 11:17:18 --> Router Class Initialized
INFO - 2023-10-31 11:17:18 --> Output Class Initialized
INFO - 2023-10-31 11:17:18 --> Security Class Initialized
DEBUG - 2023-10-31 11:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:17:18 --> Input Class Initialized
INFO - 2023-10-31 11:17:18 --> Language Class Initialized
ERROR - 2023-10-31 11:17:18 --> Severity: error --> Exception: syntax error, unexpected token ")", expecting identifier or variable or "{" or "$" C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Home.php 552
ERROR - 2023-10-31 11:17:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:17:43 --> Config Class Initialized
INFO - 2023-10-31 11:17:43 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:17:43 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:17:43 --> Utf8 Class Initialized
INFO - 2023-10-31 11:17:43 --> URI Class Initialized
INFO - 2023-10-31 11:17:43 --> Router Class Initialized
INFO - 2023-10-31 11:17:43 --> Output Class Initialized
INFO - 2023-10-31 11:17:43 --> Security Class Initialized
DEBUG - 2023-10-31 11:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:17:43 --> Input Class Initialized
INFO - 2023-10-31 11:17:43 --> Language Class Initialized
INFO - 2023-10-31 11:17:43 --> Loader Class Initialized
INFO - 2023-10-31 11:17:43 --> Helper loaded: url_helper
INFO - 2023-10-31 11:17:43 --> Helper loaded: form_helper
INFO - 2023-10-31 11:17:43 --> Helper loaded: file_helper
INFO - 2023-10-31 11:17:43 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:17:43 --> Form Validation Class Initialized
INFO - 2023-10-31 11:17:43 --> Upload Class Initialized
INFO - 2023-10-31 11:17:43 --> Model "M_auth" initialized
INFO - 2023-10-31 11:17:43 --> Model "M_user" initialized
INFO - 2023-10-31 11:17:43 --> Model "M_produk" initialized
INFO - 2023-10-31 11:17:43 --> Controller Class Initialized
INFO - 2023-10-31 11:17:43 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:17:43 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:17:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:17:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:17:43 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:17:43 --> Model "M_bank" initialized
INFO - 2023-10-31 11:17:43 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:17:43 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:17:44 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:17:44 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:17:44 --> Final output sent to browser
DEBUG - 2023-10-31 11:17:44 --> Total execution time: 0.5341
ERROR - 2023-10-31 11:17:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:17:49 --> Config Class Initialized
INFO - 2023-10-31 11:17:49 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:17:49 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:17:49 --> Utf8 Class Initialized
INFO - 2023-10-31 11:17:49 --> URI Class Initialized
INFO - 2023-10-31 11:17:49 --> Router Class Initialized
INFO - 2023-10-31 11:17:49 --> Output Class Initialized
INFO - 2023-10-31 11:17:49 --> Security Class Initialized
DEBUG - 2023-10-31 11:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:17:49 --> Input Class Initialized
INFO - 2023-10-31 11:17:49 --> Language Class Initialized
INFO - 2023-10-31 11:17:49 --> Loader Class Initialized
INFO - 2023-10-31 11:17:49 --> Helper loaded: url_helper
INFO - 2023-10-31 11:17:49 --> Helper loaded: form_helper
INFO - 2023-10-31 11:17:49 --> Helper loaded: file_helper
INFO - 2023-10-31 11:17:49 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:17:49 --> Form Validation Class Initialized
INFO - 2023-10-31 11:17:49 --> Upload Class Initialized
INFO - 2023-10-31 11:17:49 --> Model "M_auth" initialized
INFO - 2023-10-31 11:17:49 --> Model "M_user" initialized
INFO - 2023-10-31 11:17:49 --> Model "M_produk" initialized
INFO - 2023-10-31 11:17:49 --> Controller Class Initialized
INFO - 2023-10-31 11:17:49 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:17:49 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:17:49 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:17:49 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:17:49 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:17:49 --> Model "M_bank" initialized
INFO - 2023-10-31 11:17:49 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:17:49 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:17:50 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:17:50 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:17:50 --> Final output sent to browser
DEBUG - 2023-10-31 11:17:50 --> Total execution time: 0.4006
ERROR - 2023-10-31 11:18:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:18:10 --> Config Class Initialized
INFO - 2023-10-31 11:18:10 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:18:10 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:18:10 --> Utf8 Class Initialized
INFO - 2023-10-31 11:18:11 --> URI Class Initialized
INFO - 2023-10-31 11:18:11 --> Router Class Initialized
INFO - 2023-10-31 11:18:11 --> Output Class Initialized
INFO - 2023-10-31 11:18:11 --> Security Class Initialized
DEBUG - 2023-10-31 11:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:18:11 --> Input Class Initialized
INFO - 2023-10-31 11:18:11 --> Language Class Initialized
INFO - 2023-10-31 11:18:11 --> Loader Class Initialized
INFO - 2023-10-31 11:18:11 --> Helper loaded: url_helper
INFO - 2023-10-31 11:18:11 --> Helper loaded: form_helper
INFO - 2023-10-31 11:18:11 --> Helper loaded: file_helper
INFO - 2023-10-31 11:18:11 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:18:11 --> Form Validation Class Initialized
INFO - 2023-10-31 11:18:11 --> Upload Class Initialized
INFO - 2023-10-31 11:18:11 --> Model "M_auth" initialized
INFO - 2023-10-31 11:18:11 --> Model "M_user" initialized
INFO - 2023-10-31 11:18:11 --> Model "M_produk" initialized
INFO - 2023-10-31 11:18:11 --> Controller Class Initialized
INFO - 2023-10-31 11:18:11 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:18:11 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:18:11 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:18:11 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:18:11 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:18:11 --> Model "M_bank" initialized
INFO - 2023-10-31 11:18:11 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:18:11 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-31 11:18:11 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front\v_booking_saya.php 218
INFO - 2023-10-31 11:18:11 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:18:11 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:18:11 --> Final output sent to browser
DEBUG - 2023-10-31 11:18:11 --> Total execution time: 0.1357
ERROR - 2023-10-31 11:18:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:18:18 --> Config Class Initialized
INFO - 2023-10-31 11:18:18 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:18:18 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:18:18 --> Utf8 Class Initialized
INFO - 2023-10-31 11:18:18 --> URI Class Initialized
INFO - 2023-10-31 11:18:18 --> Router Class Initialized
INFO - 2023-10-31 11:18:18 --> Output Class Initialized
INFO - 2023-10-31 11:18:18 --> Security Class Initialized
DEBUG - 2023-10-31 11:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:18:18 --> Input Class Initialized
INFO - 2023-10-31 11:18:18 --> Language Class Initialized
INFO - 2023-10-31 11:18:18 --> Loader Class Initialized
INFO - 2023-10-31 11:18:18 --> Helper loaded: url_helper
INFO - 2023-10-31 11:18:18 --> Helper loaded: form_helper
INFO - 2023-10-31 11:18:18 --> Helper loaded: file_helper
INFO - 2023-10-31 11:18:18 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:18:18 --> Form Validation Class Initialized
INFO - 2023-10-31 11:18:18 --> Upload Class Initialized
INFO - 2023-10-31 11:18:18 --> Model "M_auth" initialized
INFO - 2023-10-31 11:18:18 --> Model "M_user" initialized
INFO - 2023-10-31 11:18:18 --> Model "M_produk" initialized
INFO - 2023-10-31 11:18:18 --> Controller Class Initialized
INFO - 2023-10-31 11:18:18 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:18:18 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:18:18 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:18:18 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:18:18 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:18:18 --> Model "M_bank" initialized
INFO - 2023-10-31 11:18:18 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:18:18 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-31 11:18:18 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front\v_booking_saya.php 218
INFO - 2023-10-31 11:18:18 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:18:18 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:18:18 --> Final output sent to browser
DEBUG - 2023-10-31 11:18:18 --> Total execution time: 0.0804
ERROR - 2023-10-31 11:18:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:18:19 --> Config Class Initialized
INFO - 2023-10-31 11:18:19 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:18:19 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:18:19 --> Utf8 Class Initialized
INFO - 2023-10-31 11:18:19 --> URI Class Initialized
INFO - 2023-10-31 11:18:19 --> Router Class Initialized
INFO - 2023-10-31 11:18:19 --> Output Class Initialized
INFO - 2023-10-31 11:18:19 --> Security Class Initialized
DEBUG - 2023-10-31 11:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:18:19 --> Input Class Initialized
INFO - 2023-10-31 11:18:19 --> Language Class Initialized
INFO - 2023-10-31 11:18:19 --> Loader Class Initialized
INFO - 2023-10-31 11:18:19 --> Helper loaded: url_helper
INFO - 2023-10-31 11:18:19 --> Helper loaded: form_helper
INFO - 2023-10-31 11:18:19 --> Helper loaded: file_helper
INFO - 2023-10-31 11:18:19 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:18:19 --> Form Validation Class Initialized
INFO - 2023-10-31 11:18:19 --> Upload Class Initialized
INFO - 2023-10-31 11:18:19 --> Model "M_auth" initialized
INFO - 2023-10-31 11:18:19 --> Model "M_user" initialized
INFO - 2023-10-31 11:18:19 --> Model "M_produk" initialized
INFO - 2023-10-31 11:18:19 --> Controller Class Initialized
INFO - 2023-10-31 11:18:19 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:18:19 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:18:19 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:18:19 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:18:19 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:18:19 --> Model "M_bank" initialized
INFO - 2023-10-31 11:18:19 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:18:19 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-31 11:18:19 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front\v_booking_saya.php 218
INFO - 2023-10-31 11:18:19 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:18:19 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:18:19 --> Final output sent to browser
DEBUG - 2023-10-31 11:18:19 --> Total execution time: 0.0649
ERROR - 2023-10-31 11:23:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:23:24 --> Config Class Initialized
INFO - 2023-10-31 11:23:24 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:23:24 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:23:24 --> Utf8 Class Initialized
INFO - 2023-10-31 11:23:24 --> URI Class Initialized
INFO - 2023-10-31 11:23:24 --> Router Class Initialized
INFO - 2023-10-31 11:23:24 --> Output Class Initialized
INFO - 2023-10-31 11:23:24 --> Security Class Initialized
DEBUG - 2023-10-31 11:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:23:24 --> Input Class Initialized
INFO - 2023-10-31 11:23:24 --> Language Class Initialized
INFO - 2023-10-31 11:23:24 --> Loader Class Initialized
INFO - 2023-10-31 11:23:24 --> Helper loaded: url_helper
INFO - 2023-10-31 11:23:24 --> Helper loaded: form_helper
INFO - 2023-10-31 11:23:24 --> Helper loaded: file_helper
INFO - 2023-10-31 11:23:24 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:23:24 --> Form Validation Class Initialized
INFO - 2023-10-31 11:23:24 --> Upload Class Initialized
INFO - 2023-10-31 11:23:24 --> Model "M_auth" initialized
INFO - 2023-10-31 11:23:24 --> Model "M_user" initialized
INFO - 2023-10-31 11:23:24 --> Model "M_produk" initialized
INFO - 2023-10-31 11:23:24 --> Controller Class Initialized
INFO - 2023-10-31 11:23:24 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:23:24 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:23:24 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:23:24 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:23:24 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:23:24 --> Model "M_bank" initialized
INFO - 2023-10-31 11:23:24 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:23:24 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-31 11:23:24 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front\v_booking_saya.php 218
INFO - 2023-10-31 11:23:24 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:23:24 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:23:24 --> Final output sent to browser
DEBUG - 2023-10-31 11:23:24 --> Total execution time: 0.0915
ERROR - 2023-10-31 11:24:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:24:01 --> Config Class Initialized
INFO - 2023-10-31 11:24:01 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:24:01 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:24:01 --> Utf8 Class Initialized
INFO - 2023-10-31 11:24:01 --> URI Class Initialized
INFO - 2023-10-31 11:24:01 --> Router Class Initialized
INFO - 2023-10-31 11:24:01 --> Output Class Initialized
INFO - 2023-10-31 11:24:01 --> Security Class Initialized
DEBUG - 2023-10-31 11:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:24:01 --> Input Class Initialized
INFO - 2023-10-31 11:24:01 --> Language Class Initialized
INFO - 2023-10-31 11:24:01 --> Loader Class Initialized
INFO - 2023-10-31 11:24:01 --> Helper loaded: url_helper
INFO - 2023-10-31 11:24:01 --> Helper loaded: form_helper
INFO - 2023-10-31 11:24:01 --> Helper loaded: file_helper
INFO - 2023-10-31 11:24:01 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:24:01 --> Form Validation Class Initialized
INFO - 2023-10-31 11:24:01 --> Upload Class Initialized
INFO - 2023-10-31 11:24:01 --> Model "M_auth" initialized
INFO - 2023-10-31 11:24:01 --> Model "M_user" initialized
INFO - 2023-10-31 11:24:01 --> Model "M_produk" initialized
INFO - 2023-10-31 11:24:01 --> Controller Class Initialized
INFO - 2023-10-31 11:24:01 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:24:01 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:24:01 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:24:01 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:24:01 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:24:01 --> Model "M_bank" initialized
INFO - 2023-10-31 11:24:01 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:24:01 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-31 11:24:01 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front\v_booking_saya.php 218
INFO - 2023-10-31 11:24:01 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:24:01 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:24:01 --> Final output sent to browser
DEBUG - 2023-10-31 11:24:01 --> Total execution time: 0.1177
ERROR - 2023-10-31 11:24:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:24:25 --> Config Class Initialized
INFO - 2023-10-31 11:24:25 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:24:25 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:24:25 --> Utf8 Class Initialized
INFO - 2023-10-31 11:24:25 --> URI Class Initialized
INFO - 2023-10-31 11:24:25 --> Router Class Initialized
INFO - 2023-10-31 11:24:25 --> Output Class Initialized
INFO - 2023-10-31 11:24:25 --> Security Class Initialized
DEBUG - 2023-10-31 11:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:24:25 --> Input Class Initialized
INFO - 2023-10-31 11:24:25 --> Language Class Initialized
INFO - 2023-10-31 11:24:25 --> Loader Class Initialized
INFO - 2023-10-31 11:24:25 --> Helper loaded: url_helper
INFO - 2023-10-31 11:24:25 --> Helper loaded: form_helper
INFO - 2023-10-31 11:24:25 --> Helper loaded: file_helper
INFO - 2023-10-31 11:24:25 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:24:25 --> Form Validation Class Initialized
INFO - 2023-10-31 11:24:25 --> Upload Class Initialized
INFO - 2023-10-31 11:24:25 --> Model "M_auth" initialized
INFO - 2023-10-31 11:24:25 --> Model "M_user" initialized
INFO - 2023-10-31 11:24:25 --> Model "M_produk" initialized
INFO - 2023-10-31 11:24:25 --> Controller Class Initialized
INFO - 2023-10-31 11:24:25 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:24:25 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:24:25 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:24:25 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:24:25 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:24:25 --> Model "M_bank" initialized
INFO - 2023-10-31 11:24:25 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:24:25 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:24:26 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:24:26 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:24:26 --> Final output sent to browser
DEBUG - 2023-10-31 11:24:26 --> Total execution time: 0.7345
ERROR - 2023-10-31 11:24:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:24:32 --> Config Class Initialized
INFO - 2023-10-31 11:24:32 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:24:32 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:24:32 --> Utf8 Class Initialized
INFO - 2023-10-31 11:24:32 --> URI Class Initialized
INFO - 2023-10-31 11:24:32 --> Router Class Initialized
INFO - 2023-10-31 11:24:32 --> Output Class Initialized
INFO - 2023-10-31 11:24:32 --> Security Class Initialized
DEBUG - 2023-10-31 11:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:24:32 --> Input Class Initialized
INFO - 2023-10-31 11:24:32 --> Language Class Initialized
INFO - 2023-10-31 11:24:32 --> Loader Class Initialized
INFO - 2023-10-31 11:24:32 --> Helper loaded: url_helper
INFO - 2023-10-31 11:24:32 --> Helper loaded: form_helper
INFO - 2023-10-31 11:24:32 --> Helper loaded: file_helper
INFO - 2023-10-31 11:24:32 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:24:32 --> Form Validation Class Initialized
INFO - 2023-10-31 11:24:32 --> Upload Class Initialized
INFO - 2023-10-31 11:24:32 --> Model "M_auth" initialized
INFO - 2023-10-31 11:24:32 --> Model "M_user" initialized
INFO - 2023-10-31 11:24:32 --> Model "M_produk" initialized
INFO - 2023-10-31 11:24:32 --> Controller Class Initialized
INFO - 2023-10-31 11:24:32 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:24:32 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:24:32 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:24:32 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:24:32 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:24:32 --> Model "M_bank" initialized
INFO - 2023-10-31 11:24:32 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:24:32 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:24:32 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:24:32 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:24:32 --> Final output sent to browser
DEBUG - 2023-10-31 11:24:32 --> Total execution time: 0.4587
ERROR - 2023-10-31 11:39:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:39:33 --> Config Class Initialized
INFO - 2023-10-31 11:39:33 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:39:33 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:39:33 --> Utf8 Class Initialized
INFO - 2023-10-31 11:39:33 --> URI Class Initialized
INFO - 2023-10-31 11:39:33 --> Router Class Initialized
INFO - 2023-10-31 11:39:33 --> Output Class Initialized
INFO - 2023-10-31 11:39:33 --> Security Class Initialized
DEBUG - 2023-10-31 11:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:39:33 --> Input Class Initialized
INFO - 2023-10-31 11:39:33 --> Language Class Initialized
INFO - 2023-10-31 11:39:33 --> Loader Class Initialized
INFO - 2023-10-31 11:39:33 --> Helper loaded: url_helper
INFO - 2023-10-31 11:39:33 --> Helper loaded: form_helper
INFO - 2023-10-31 11:39:33 --> Helper loaded: file_helper
INFO - 2023-10-31 11:39:33 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:39:33 --> Form Validation Class Initialized
INFO - 2023-10-31 11:39:33 --> Upload Class Initialized
INFO - 2023-10-31 11:39:33 --> Model "M_auth" initialized
INFO - 2023-10-31 11:39:33 --> Model "M_user" initialized
INFO - 2023-10-31 11:39:33 --> Model "M_produk" initialized
INFO - 2023-10-31 11:39:33 --> Controller Class Initialized
INFO - 2023-10-31 11:39:33 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:39:33 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:39:33 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:39:33 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:39:33 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:39:33 --> Model "M_bank" initialized
INFO - 2023-10-31 11:39:33 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:39:33 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-31 11:39:33 --> Severity: Warning --> Undefined variable $sub_total C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Home.php 549
INFO - 2023-10-31 11:39:34 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:39:34 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:39:34 --> Final output sent to browser
DEBUG - 2023-10-31 11:39:34 --> Total execution time: 0.5181
ERROR - 2023-10-31 11:39:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:39:43 --> Config Class Initialized
INFO - 2023-10-31 11:39:43 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:39:43 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:39:43 --> Utf8 Class Initialized
INFO - 2023-10-31 11:39:43 --> URI Class Initialized
INFO - 2023-10-31 11:39:43 --> Router Class Initialized
INFO - 2023-10-31 11:39:43 --> Output Class Initialized
INFO - 2023-10-31 11:39:43 --> Security Class Initialized
DEBUG - 2023-10-31 11:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:39:43 --> Input Class Initialized
INFO - 2023-10-31 11:39:43 --> Language Class Initialized
INFO - 2023-10-31 11:39:43 --> Loader Class Initialized
INFO - 2023-10-31 11:39:43 --> Helper loaded: url_helper
INFO - 2023-10-31 11:39:43 --> Helper loaded: form_helper
INFO - 2023-10-31 11:39:43 --> Helper loaded: file_helper
INFO - 2023-10-31 11:39:43 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:39:43 --> Form Validation Class Initialized
INFO - 2023-10-31 11:39:43 --> Upload Class Initialized
INFO - 2023-10-31 11:39:43 --> Model "M_auth" initialized
INFO - 2023-10-31 11:39:43 --> Model "M_user" initialized
INFO - 2023-10-31 11:39:43 --> Model "M_produk" initialized
INFO - 2023-10-31 11:39:43 --> Controller Class Initialized
INFO - 2023-10-31 11:39:43 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:39:43 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:39:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:39:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:39:43 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:39:43 --> Model "M_bank" initialized
INFO - 2023-10-31 11:39:43 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:39:43 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-31 11:39:43 --> Severity: Warning --> Undefined variable $sub_total C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Home.php 549
INFO - 2023-10-31 11:39:43 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:39:43 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:39:43 --> Final output sent to browser
DEBUG - 2023-10-31 11:39:43 --> Total execution time: 0.4063
ERROR - 2023-10-31 11:39:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:39:46 --> Config Class Initialized
INFO - 2023-10-31 11:39:46 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:39:46 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:39:46 --> Utf8 Class Initialized
INFO - 2023-10-31 11:39:46 --> URI Class Initialized
INFO - 2023-10-31 11:39:46 --> Router Class Initialized
INFO - 2023-10-31 11:39:47 --> Output Class Initialized
INFO - 2023-10-31 11:39:47 --> Security Class Initialized
DEBUG - 2023-10-31 11:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:39:47 --> Input Class Initialized
INFO - 2023-10-31 11:39:47 --> Language Class Initialized
INFO - 2023-10-31 11:39:47 --> Loader Class Initialized
INFO - 2023-10-31 11:39:47 --> Helper loaded: url_helper
INFO - 2023-10-31 11:39:47 --> Helper loaded: form_helper
INFO - 2023-10-31 11:39:47 --> Helper loaded: file_helper
INFO - 2023-10-31 11:39:47 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:39:47 --> Form Validation Class Initialized
INFO - 2023-10-31 11:39:47 --> Upload Class Initialized
INFO - 2023-10-31 11:39:47 --> Model "M_auth" initialized
INFO - 2023-10-31 11:39:47 --> Model "M_user" initialized
INFO - 2023-10-31 11:39:47 --> Model "M_produk" initialized
INFO - 2023-10-31 11:39:47 --> Controller Class Initialized
INFO - 2023-10-31 11:39:47 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:39:47 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:39:47 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:39:47 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:39:47 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:39:47 --> Model "M_bank" initialized
INFO - 2023-10-31 11:39:47 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:39:47 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-31 11:39:47 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Home.php 548
ERROR - 2023-10-31 11:39:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Home.php 548
INFO - 2023-10-31 11:39:47 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:39:47 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:39:47 --> Final output sent to browser
DEBUG - 2023-10-31 11:39:47 --> Total execution time: 0.4646
ERROR - 2023-10-31 11:39:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:39:50 --> Config Class Initialized
INFO - 2023-10-31 11:39:50 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:39:50 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:39:50 --> Utf8 Class Initialized
INFO - 2023-10-31 11:39:50 --> URI Class Initialized
INFO - 2023-10-31 11:39:50 --> Router Class Initialized
INFO - 2023-10-31 11:39:50 --> Output Class Initialized
INFO - 2023-10-31 11:39:50 --> Security Class Initialized
DEBUG - 2023-10-31 11:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:39:50 --> Input Class Initialized
INFO - 2023-10-31 11:39:50 --> Language Class Initialized
INFO - 2023-10-31 11:39:50 --> Loader Class Initialized
INFO - 2023-10-31 11:39:50 --> Helper loaded: url_helper
INFO - 2023-10-31 11:39:50 --> Helper loaded: form_helper
INFO - 2023-10-31 11:39:50 --> Helper loaded: file_helper
INFO - 2023-10-31 11:39:50 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:39:50 --> Form Validation Class Initialized
INFO - 2023-10-31 11:39:50 --> Upload Class Initialized
INFO - 2023-10-31 11:39:50 --> Model "M_auth" initialized
INFO - 2023-10-31 11:39:50 --> Model "M_user" initialized
INFO - 2023-10-31 11:39:50 --> Model "M_produk" initialized
INFO - 2023-10-31 11:39:50 --> Controller Class Initialized
INFO - 2023-10-31 11:39:50 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:39:50 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:39:50 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:39:50 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:39:50 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:39:50 --> Model "M_bank" initialized
INFO - 2023-10-31 11:39:50 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:39:50 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-31 11:39:50 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Home.php 548
ERROR - 2023-10-31 11:39:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Home.php 548
INFO - 2023-10-31 11:39:51 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:39:51 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:39:51 --> Final output sent to browser
DEBUG - 2023-10-31 11:39:51 --> Total execution time: 0.4416
ERROR - 2023-10-31 11:39:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:39:57 --> Config Class Initialized
INFO - 2023-10-31 11:39:57 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:39:57 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:39:57 --> Utf8 Class Initialized
INFO - 2023-10-31 11:39:57 --> URI Class Initialized
INFO - 2023-10-31 11:39:57 --> Router Class Initialized
INFO - 2023-10-31 11:39:57 --> Output Class Initialized
INFO - 2023-10-31 11:39:57 --> Security Class Initialized
DEBUG - 2023-10-31 11:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:39:57 --> Input Class Initialized
INFO - 2023-10-31 11:39:57 --> Language Class Initialized
INFO - 2023-10-31 11:39:57 --> Loader Class Initialized
INFO - 2023-10-31 11:39:57 --> Helper loaded: url_helper
INFO - 2023-10-31 11:39:57 --> Helper loaded: form_helper
INFO - 2023-10-31 11:39:57 --> Helper loaded: file_helper
INFO - 2023-10-31 11:39:57 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:39:57 --> Form Validation Class Initialized
INFO - 2023-10-31 11:39:57 --> Upload Class Initialized
INFO - 2023-10-31 11:39:57 --> Model "M_auth" initialized
INFO - 2023-10-31 11:39:57 --> Model "M_user" initialized
INFO - 2023-10-31 11:39:57 --> Model "M_produk" initialized
INFO - 2023-10-31 11:39:57 --> Controller Class Initialized
INFO - 2023-10-31 11:39:57 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:39:57 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:39:57 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:39:57 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:39:57 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:39:57 --> Model "M_bank" initialized
INFO - 2023-10-31 11:39:57 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:39:57 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:39:57 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:39:57 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:39:57 --> Final output sent to browser
DEBUG - 2023-10-31 11:39:57 --> Total execution time: 0.5884
ERROR - 2023-10-31 11:40:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:40:10 --> Config Class Initialized
INFO - 2023-10-31 11:40:10 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:40:10 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:40:10 --> Utf8 Class Initialized
INFO - 2023-10-31 11:40:10 --> URI Class Initialized
DEBUG - 2023-10-31 11:40:10 --> No URI present. Default controller set.
INFO - 2023-10-31 11:40:10 --> Router Class Initialized
INFO - 2023-10-31 11:40:10 --> Output Class Initialized
INFO - 2023-10-31 11:40:10 --> Security Class Initialized
DEBUG - 2023-10-31 11:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:40:10 --> Input Class Initialized
INFO - 2023-10-31 11:40:10 --> Language Class Initialized
INFO - 2023-10-31 11:40:10 --> Loader Class Initialized
INFO - 2023-10-31 11:40:10 --> Helper loaded: url_helper
INFO - 2023-10-31 11:40:10 --> Helper loaded: form_helper
INFO - 2023-10-31 11:40:10 --> Helper loaded: file_helper
INFO - 2023-10-31 11:40:10 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:40:10 --> Form Validation Class Initialized
INFO - 2023-10-31 11:40:10 --> Upload Class Initialized
INFO - 2023-10-31 11:40:10 --> Model "M_auth" initialized
INFO - 2023-10-31 11:40:10 --> Model "M_user" initialized
INFO - 2023-10-31 11:40:10 --> Model "M_produk" initialized
INFO - 2023-10-31 11:40:10 --> Controller Class Initialized
INFO - 2023-10-31 11:40:10 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:40:10 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:40:10 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:40:10 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:40:10 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:40:10 --> Model "M_bank" initialized
INFO - 2023-10-31 11:40:10 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:40:10 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:40:10 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:40:10 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-31 11:40:10 --> Final output sent to browser
DEBUG - 2023-10-31 11:40:10 --> Total execution time: 0.0740
ERROR - 2023-10-31 11:40:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:40:15 --> Config Class Initialized
INFO - 2023-10-31 11:40:15 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:40:15 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:40:15 --> Utf8 Class Initialized
INFO - 2023-10-31 11:40:15 --> URI Class Initialized
INFO - 2023-10-31 11:40:15 --> Router Class Initialized
INFO - 2023-10-31 11:40:15 --> Output Class Initialized
INFO - 2023-10-31 11:40:15 --> Security Class Initialized
DEBUG - 2023-10-31 11:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:40:15 --> Input Class Initialized
INFO - 2023-10-31 11:40:15 --> Language Class Initialized
INFO - 2023-10-31 11:40:15 --> Loader Class Initialized
INFO - 2023-10-31 11:40:15 --> Helper loaded: url_helper
INFO - 2023-10-31 11:40:15 --> Helper loaded: form_helper
INFO - 2023-10-31 11:40:15 --> Helper loaded: file_helper
INFO - 2023-10-31 11:40:15 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:40:15 --> Form Validation Class Initialized
INFO - 2023-10-31 11:40:15 --> Upload Class Initialized
INFO - 2023-10-31 11:40:15 --> Model "M_auth" initialized
INFO - 2023-10-31 11:40:15 --> Model "M_user" initialized
INFO - 2023-10-31 11:40:15 --> Model "M_produk" initialized
INFO - 2023-10-31 11:40:15 --> Controller Class Initialized
INFO - 2023-10-31 11:40:15 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:40:15 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:40:15 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:40:15 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:40:15 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:40:15 --> Model "M_bank" initialized
INFO - 2023-10-31 11:40:15 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:40:15 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:40:15 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:40:15 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_produk_detail.php
INFO - 2023-10-31 11:40:15 --> Final output sent to browser
DEBUG - 2023-10-31 11:40:15 --> Total execution time: 0.1612
ERROR - 2023-10-31 11:40:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:40:15 --> Config Class Initialized
INFO - 2023-10-31 11:40:15 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:40:15 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:40:15 --> Utf8 Class Initialized
INFO - 2023-10-31 11:40:15 --> URI Class Initialized
INFO - 2023-10-31 11:40:15 --> Router Class Initialized
INFO - 2023-10-31 11:40:15 --> Output Class Initialized
INFO - 2023-10-31 11:40:15 --> Security Class Initialized
DEBUG - 2023-10-31 11:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:40:15 --> Input Class Initialized
INFO - 2023-10-31 11:40:15 --> Language Class Initialized
INFO - 2023-10-31 11:40:16 --> Loader Class Initialized
INFO - 2023-10-31 11:40:16 --> Helper loaded: url_helper
INFO - 2023-10-31 11:40:16 --> Helper loaded: form_helper
INFO - 2023-10-31 11:40:16 --> Helper loaded: file_helper
INFO - 2023-10-31 11:40:16 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:40:16 --> Form Validation Class Initialized
INFO - 2023-10-31 11:40:16 --> Upload Class Initialized
INFO - 2023-10-31 11:40:16 --> Model "M_auth" initialized
INFO - 2023-10-31 11:40:16 --> Model "M_user" initialized
INFO - 2023-10-31 11:40:16 --> Model "M_produk" initialized
INFO - 2023-10-31 11:40:16 --> Controller Class Initialized
INFO - 2023-10-31 11:40:16 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/not_found.php
INFO - 2023-10-31 11:40:16 --> Final output sent to browser
DEBUG - 2023-10-31 11:40:16 --> Total execution time: 0.1566
ERROR - 2023-10-31 11:40:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:40:25 --> Config Class Initialized
INFO - 2023-10-31 11:40:25 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:40:26 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:40:26 --> Utf8 Class Initialized
INFO - 2023-10-31 11:40:26 --> URI Class Initialized
INFO - 2023-10-31 11:40:26 --> Router Class Initialized
INFO - 2023-10-31 11:40:26 --> Output Class Initialized
INFO - 2023-10-31 11:40:26 --> Security Class Initialized
DEBUG - 2023-10-31 11:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:40:26 --> Input Class Initialized
INFO - 2023-10-31 11:40:26 --> Language Class Initialized
INFO - 2023-10-31 11:40:26 --> Loader Class Initialized
INFO - 2023-10-31 11:40:26 --> Helper loaded: url_helper
INFO - 2023-10-31 11:40:26 --> Helper loaded: form_helper
INFO - 2023-10-31 11:40:26 --> Helper loaded: file_helper
INFO - 2023-10-31 11:40:26 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:40:26 --> Form Validation Class Initialized
INFO - 2023-10-31 11:40:26 --> Upload Class Initialized
INFO - 2023-10-31 11:40:26 --> Model "M_auth" initialized
INFO - 2023-10-31 11:40:26 --> Model "M_user" initialized
INFO - 2023-10-31 11:40:26 --> Model "M_produk" initialized
INFO - 2023-10-31 11:40:26 --> Controller Class Initialized
INFO - 2023-10-31 11:40:26 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:40:26 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:40:26 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:40:26 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:40:26 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:40:26 --> Model "M_bank" initialized
INFO - 2023-10-31 11:40:26 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:40:26 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:40:26 --> Email Class Initialized
INFO - 2023-10-31 11:40:26 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-10-31 11:40:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:40:30 --> Config Class Initialized
INFO - 2023-10-31 11:40:30 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:40:30 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:40:30 --> Utf8 Class Initialized
INFO - 2023-10-31 11:40:30 --> URI Class Initialized
INFO - 2023-10-31 11:40:30 --> Router Class Initialized
INFO - 2023-10-31 11:40:30 --> Output Class Initialized
INFO - 2023-10-31 11:40:30 --> Security Class Initialized
DEBUG - 2023-10-31 11:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:40:30 --> Input Class Initialized
INFO - 2023-10-31 11:40:30 --> Language Class Initialized
INFO - 2023-10-31 11:40:30 --> Loader Class Initialized
INFO - 2023-10-31 11:40:30 --> Helper loaded: url_helper
INFO - 2023-10-31 11:40:30 --> Helper loaded: form_helper
INFO - 2023-10-31 11:40:30 --> Helper loaded: file_helper
INFO - 2023-10-31 11:40:31 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:40:31 --> Form Validation Class Initialized
INFO - 2023-10-31 11:40:31 --> Upload Class Initialized
INFO - 2023-10-31 11:40:31 --> Model "M_auth" initialized
INFO - 2023-10-31 11:40:31 --> Model "M_user" initialized
INFO - 2023-10-31 11:40:31 --> Model "M_produk" initialized
INFO - 2023-10-31 11:40:31 --> Controller Class Initialized
INFO - 2023-10-31 11:40:31 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:40:31 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:40:31 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:40:31 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:40:31 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:40:31 --> Model "M_bank" initialized
INFO - 2023-10-31 11:40:31 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:40:31 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:40:31 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:40:31 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:40:31 --> Final output sent to browser
DEBUG - 2023-10-31 11:40:31 --> Total execution time: 0.4644
ERROR - 2023-10-31 11:41:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:41:45 --> Config Class Initialized
INFO - 2023-10-31 11:41:45 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:41:45 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:41:45 --> Utf8 Class Initialized
INFO - 2023-10-31 11:41:45 --> URI Class Initialized
INFO - 2023-10-31 11:41:45 --> Router Class Initialized
INFO - 2023-10-31 11:41:45 --> Output Class Initialized
INFO - 2023-10-31 11:41:45 --> Security Class Initialized
DEBUG - 2023-10-31 11:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:41:45 --> Input Class Initialized
INFO - 2023-10-31 11:41:45 --> Language Class Initialized
INFO - 2023-10-31 11:41:45 --> Loader Class Initialized
INFO - 2023-10-31 11:41:45 --> Helper loaded: url_helper
INFO - 2023-10-31 11:41:45 --> Helper loaded: form_helper
INFO - 2023-10-31 11:41:45 --> Helper loaded: file_helper
INFO - 2023-10-31 11:41:45 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:41:45 --> Form Validation Class Initialized
INFO - 2023-10-31 11:41:45 --> Upload Class Initialized
INFO - 2023-10-31 11:41:45 --> Model "M_auth" initialized
INFO - 2023-10-31 11:41:45 --> Model "M_user" initialized
INFO - 2023-10-31 11:41:45 --> Model "M_produk" initialized
INFO - 2023-10-31 11:41:45 --> Controller Class Initialized
INFO - 2023-10-31 11:41:45 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:41:45 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:41:45 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:41:45 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:41:45 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:41:45 --> Model "M_bank" initialized
INFO - 2023-10-31 11:41:45 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:41:45 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:41:46 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:41:46 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:41:46 --> Final output sent to browser
DEBUG - 2023-10-31 11:41:46 --> Total execution time: 0.4419
ERROR - 2023-10-31 11:41:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:41:52 --> Config Class Initialized
INFO - 2023-10-31 11:41:52 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:41:52 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:41:52 --> Utf8 Class Initialized
INFO - 2023-10-31 11:41:52 --> URI Class Initialized
INFO - 2023-10-31 11:41:52 --> Router Class Initialized
INFO - 2023-10-31 11:41:52 --> Output Class Initialized
INFO - 2023-10-31 11:41:52 --> Security Class Initialized
DEBUG - 2023-10-31 11:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:41:52 --> Input Class Initialized
INFO - 2023-10-31 11:41:52 --> Language Class Initialized
INFO - 2023-10-31 11:41:52 --> Loader Class Initialized
INFO - 2023-10-31 11:41:52 --> Helper loaded: url_helper
INFO - 2023-10-31 11:41:52 --> Helper loaded: form_helper
INFO - 2023-10-31 11:41:52 --> Helper loaded: file_helper
INFO - 2023-10-31 11:41:52 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:41:52 --> Form Validation Class Initialized
INFO - 2023-10-31 11:41:52 --> Upload Class Initialized
INFO - 2023-10-31 11:41:52 --> Model "M_auth" initialized
INFO - 2023-10-31 11:41:52 --> Model "M_user" initialized
INFO - 2023-10-31 11:41:52 --> Model "M_produk" initialized
INFO - 2023-10-31 11:41:52 --> Controller Class Initialized
INFO - 2023-10-31 11:41:52 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:41:52 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:41:52 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:41:52 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:41:52 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:41:52 --> Model "M_bank" initialized
INFO - 2023-10-31 11:41:52 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:41:52 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:41:52 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:41:52 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:41:52 --> Final output sent to browser
DEBUG - 2023-10-31 11:41:52 --> Total execution time: 0.4764
ERROR - 2023-10-31 11:42:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:42:04 --> Config Class Initialized
INFO - 2023-10-31 11:42:04 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:42:04 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:42:04 --> Utf8 Class Initialized
INFO - 2023-10-31 11:42:04 --> URI Class Initialized
DEBUG - 2023-10-31 11:42:04 --> No URI present. Default controller set.
INFO - 2023-10-31 11:42:04 --> Router Class Initialized
INFO - 2023-10-31 11:42:04 --> Output Class Initialized
INFO - 2023-10-31 11:42:04 --> Security Class Initialized
DEBUG - 2023-10-31 11:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:42:04 --> Input Class Initialized
INFO - 2023-10-31 11:42:04 --> Language Class Initialized
INFO - 2023-10-31 11:42:04 --> Loader Class Initialized
INFO - 2023-10-31 11:42:04 --> Helper loaded: url_helper
INFO - 2023-10-31 11:42:04 --> Helper loaded: form_helper
INFO - 2023-10-31 11:42:04 --> Helper loaded: file_helper
INFO - 2023-10-31 11:42:04 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:42:04 --> Form Validation Class Initialized
INFO - 2023-10-31 11:42:04 --> Upload Class Initialized
INFO - 2023-10-31 11:42:04 --> Model "M_auth" initialized
INFO - 2023-10-31 11:42:04 --> Model "M_user" initialized
INFO - 2023-10-31 11:42:04 --> Model "M_produk" initialized
INFO - 2023-10-31 11:42:04 --> Controller Class Initialized
INFO - 2023-10-31 11:42:04 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:42:04 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:42:04 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:42:04 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:42:04 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:42:04 --> Model "M_bank" initialized
INFO - 2023-10-31 11:42:04 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:42:04 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:42:04 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:42:04 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-31 11:42:04 --> Final output sent to browser
DEBUG - 2023-10-31 11:42:04 --> Total execution time: 0.0488
ERROR - 2023-10-31 11:42:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:42:13 --> Config Class Initialized
INFO - 2023-10-31 11:42:13 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:42:13 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:42:13 --> Utf8 Class Initialized
INFO - 2023-10-31 11:42:13 --> URI Class Initialized
DEBUG - 2023-10-31 11:42:13 --> No URI present. Default controller set.
INFO - 2023-10-31 11:42:13 --> Router Class Initialized
INFO - 2023-10-31 11:42:13 --> Output Class Initialized
INFO - 2023-10-31 11:42:13 --> Security Class Initialized
DEBUG - 2023-10-31 11:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:42:13 --> Input Class Initialized
INFO - 2023-10-31 11:42:13 --> Language Class Initialized
INFO - 2023-10-31 11:42:13 --> Loader Class Initialized
INFO - 2023-10-31 11:42:13 --> Helper loaded: url_helper
INFO - 2023-10-31 11:42:13 --> Helper loaded: form_helper
INFO - 2023-10-31 11:42:13 --> Helper loaded: file_helper
INFO - 2023-10-31 11:42:13 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:42:13 --> Form Validation Class Initialized
INFO - 2023-10-31 11:42:13 --> Upload Class Initialized
INFO - 2023-10-31 11:42:13 --> Model "M_auth" initialized
INFO - 2023-10-31 11:42:13 --> Model "M_user" initialized
INFO - 2023-10-31 11:42:13 --> Model "M_produk" initialized
INFO - 2023-10-31 11:42:13 --> Controller Class Initialized
INFO - 2023-10-31 11:42:13 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:42:13 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:42:13 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:42:13 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:42:13 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:42:13 --> Model "M_bank" initialized
INFO - 2023-10-31 11:42:13 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:42:13 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:42:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-10-31 11:42:13 --> Email Class Initialized
INFO - 2023-10-31 11:42:14 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-10-31 11:42:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:42:16 --> Config Class Initialized
INFO - 2023-10-31 11:42:16 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:42:16 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:42:16 --> Utf8 Class Initialized
INFO - 2023-10-31 11:42:16 --> URI Class Initialized
DEBUG - 2023-10-31 11:42:16 --> No URI present. Default controller set.
INFO - 2023-10-31 11:42:16 --> Router Class Initialized
INFO - 2023-10-31 11:42:16 --> Output Class Initialized
INFO - 2023-10-31 11:42:16 --> Security Class Initialized
DEBUG - 2023-10-31 11:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:42:16 --> Input Class Initialized
INFO - 2023-10-31 11:42:16 --> Language Class Initialized
INFO - 2023-10-31 11:42:16 --> Loader Class Initialized
INFO - 2023-10-31 11:42:16 --> Helper loaded: url_helper
INFO - 2023-10-31 11:42:16 --> Helper loaded: form_helper
INFO - 2023-10-31 11:42:16 --> Helper loaded: file_helper
INFO - 2023-10-31 11:42:16 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:42:16 --> Form Validation Class Initialized
INFO - 2023-10-31 11:42:16 --> Upload Class Initialized
INFO - 2023-10-31 11:42:16 --> Model "M_auth" initialized
INFO - 2023-10-31 11:42:16 --> Model "M_user" initialized
INFO - 2023-10-31 11:42:16 --> Model "M_produk" initialized
INFO - 2023-10-31 11:42:16 --> Controller Class Initialized
INFO - 2023-10-31 11:42:16 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:42:16 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:42:16 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:42:16 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:42:16 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:42:16 --> Model "M_bank" initialized
INFO - 2023-10-31 11:42:16 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:42:16 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:42:16 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:42:16 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-10-31 11:42:16 --> Final output sent to browser
DEBUG - 2023-10-31 11:42:16 --> Total execution time: 0.1094
ERROR - 2023-10-31 11:42:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:42:20 --> Config Class Initialized
INFO - 2023-10-31 11:42:20 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:42:20 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:42:20 --> Utf8 Class Initialized
INFO - 2023-10-31 11:42:20 --> URI Class Initialized
INFO - 2023-10-31 11:42:20 --> Router Class Initialized
INFO - 2023-10-31 11:42:20 --> Output Class Initialized
INFO - 2023-10-31 11:42:20 --> Security Class Initialized
DEBUG - 2023-10-31 11:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:42:20 --> Input Class Initialized
INFO - 2023-10-31 11:42:20 --> Language Class Initialized
INFO - 2023-10-31 11:42:20 --> Loader Class Initialized
INFO - 2023-10-31 11:42:20 --> Helper loaded: url_helper
INFO - 2023-10-31 11:42:20 --> Helper loaded: form_helper
INFO - 2023-10-31 11:42:20 --> Helper loaded: file_helper
INFO - 2023-10-31 11:42:20 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:42:20 --> Form Validation Class Initialized
INFO - 2023-10-31 11:42:20 --> Upload Class Initialized
INFO - 2023-10-31 11:42:20 --> Model "M_auth" initialized
INFO - 2023-10-31 11:42:20 --> Model "M_user" initialized
INFO - 2023-10-31 11:42:20 --> Model "M_produk" initialized
INFO - 2023-10-31 11:42:20 --> Controller Class Initialized
INFO - 2023-10-31 11:42:20 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:42:20 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:42:20 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:42:20 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:42:20 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:42:20 --> Model "M_bank" initialized
INFO - 2023-10-31 11:42:20 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:42:20 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:42:21 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:42:21 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:42:21 --> Final output sent to browser
DEBUG - 2023-10-31 11:42:21 --> Total execution time: 0.5443
ERROR - 2023-10-31 11:42:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:42:31 --> Config Class Initialized
INFO - 2023-10-31 11:42:31 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:42:31 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:42:31 --> Utf8 Class Initialized
INFO - 2023-10-31 11:42:31 --> URI Class Initialized
INFO - 2023-10-31 11:42:31 --> Router Class Initialized
INFO - 2023-10-31 11:42:31 --> Output Class Initialized
INFO - 2023-10-31 11:42:31 --> Security Class Initialized
DEBUG - 2023-10-31 11:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:42:31 --> Input Class Initialized
INFO - 2023-10-31 11:42:31 --> Language Class Initialized
INFO - 2023-10-31 11:42:31 --> Loader Class Initialized
INFO - 2023-10-31 11:42:31 --> Helper loaded: url_helper
INFO - 2023-10-31 11:42:31 --> Helper loaded: form_helper
INFO - 2023-10-31 11:42:31 --> Helper loaded: file_helper
INFO - 2023-10-31 11:42:31 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:42:31 --> Form Validation Class Initialized
INFO - 2023-10-31 11:42:31 --> Upload Class Initialized
INFO - 2023-10-31 11:42:31 --> Model "M_auth" initialized
INFO - 2023-10-31 11:42:31 --> Model "M_user" initialized
INFO - 2023-10-31 11:42:31 --> Model "M_produk" initialized
INFO - 2023-10-31 11:42:31 --> Controller Class Initialized
INFO - 2023-10-31 11:42:31 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:42:31 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:42:31 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:42:31 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:42:31 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:42:31 --> Model "M_bank" initialized
INFO - 2023-10-31 11:42:31 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:42:31 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:42:32 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:42:32 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:42:32 --> Final output sent to browser
DEBUG - 2023-10-31 11:42:32 --> Total execution time: 0.4793
ERROR - 2023-10-31 11:42:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:42:43 --> Config Class Initialized
INFO - 2023-10-31 11:42:43 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:42:43 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:42:43 --> Utf8 Class Initialized
INFO - 2023-10-31 11:42:43 --> URI Class Initialized
INFO - 2023-10-31 11:42:43 --> Router Class Initialized
INFO - 2023-10-31 11:42:43 --> Output Class Initialized
INFO - 2023-10-31 11:42:43 --> Security Class Initialized
DEBUG - 2023-10-31 11:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:42:43 --> Input Class Initialized
INFO - 2023-10-31 11:42:43 --> Language Class Initialized
INFO - 2023-10-31 11:42:43 --> Loader Class Initialized
INFO - 2023-10-31 11:42:43 --> Helper loaded: url_helper
INFO - 2023-10-31 11:42:43 --> Helper loaded: form_helper
INFO - 2023-10-31 11:42:43 --> Helper loaded: file_helper
INFO - 2023-10-31 11:42:43 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:42:43 --> Form Validation Class Initialized
INFO - 2023-10-31 11:42:43 --> Upload Class Initialized
INFO - 2023-10-31 11:42:43 --> Model "M_auth" initialized
INFO - 2023-10-31 11:42:43 --> Model "M_user" initialized
INFO - 2023-10-31 11:42:43 --> Model "M_produk" initialized
INFO - 2023-10-31 11:42:43 --> Controller Class Initialized
INFO - 2023-10-31 11:42:43 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:42:43 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:42:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:42:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:42:44 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:42:44 --> Model "M_bank" initialized
INFO - 2023-10-31 11:42:44 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:42:44 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:42:44 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:42:44 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:42:44 --> Final output sent to browser
DEBUG - 2023-10-31 11:42:44 --> Total execution time: 0.4644
ERROR - 2023-10-31 11:44:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:44:49 --> Config Class Initialized
INFO - 2023-10-31 11:44:49 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:44:49 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:44:49 --> Utf8 Class Initialized
INFO - 2023-10-31 11:44:49 --> URI Class Initialized
INFO - 2023-10-31 11:44:49 --> Router Class Initialized
INFO - 2023-10-31 11:44:49 --> Output Class Initialized
INFO - 2023-10-31 11:44:49 --> Security Class Initialized
DEBUG - 2023-10-31 11:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:44:49 --> Input Class Initialized
INFO - 2023-10-31 11:44:49 --> Language Class Initialized
INFO - 2023-10-31 11:44:49 --> Loader Class Initialized
INFO - 2023-10-31 11:44:49 --> Helper loaded: url_helper
INFO - 2023-10-31 11:44:49 --> Helper loaded: form_helper
INFO - 2023-10-31 11:44:49 --> Helper loaded: file_helper
INFO - 2023-10-31 11:44:49 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:44:49 --> Form Validation Class Initialized
INFO - 2023-10-31 11:44:49 --> Upload Class Initialized
INFO - 2023-10-31 11:44:49 --> Model "M_auth" initialized
INFO - 2023-10-31 11:44:49 --> Model "M_user" initialized
INFO - 2023-10-31 11:44:49 --> Model "M_produk" initialized
INFO - 2023-10-31 11:44:49 --> Controller Class Initialized
INFO - 2023-10-31 11:44:49 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:44:49 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:44:49 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:44:49 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:44:49 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:44:49 --> Model "M_bank" initialized
INFO - 2023-10-31 11:44:49 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:44:49 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:44:50 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:44:50 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:44:50 --> Final output sent to browser
DEBUG - 2023-10-31 11:44:50 --> Total execution time: 0.5384
ERROR - 2023-10-31 11:44:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:44:59 --> Config Class Initialized
INFO - 2023-10-31 11:44:59 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:44:59 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:44:59 --> Utf8 Class Initialized
INFO - 2023-10-31 11:44:59 --> URI Class Initialized
INFO - 2023-10-31 11:44:59 --> Router Class Initialized
INFO - 2023-10-31 11:44:59 --> Output Class Initialized
INFO - 2023-10-31 11:44:59 --> Security Class Initialized
DEBUG - 2023-10-31 11:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:44:59 --> Input Class Initialized
INFO - 2023-10-31 11:44:59 --> Language Class Initialized
INFO - 2023-10-31 11:44:59 --> Loader Class Initialized
INFO - 2023-10-31 11:44:59 --> Helper loaded: url_helper
INFO - 2023-10-31 11:44:59 --> Helper loaded: form_helper
INFO - 2023-10-31 11:44:59 --> Helper loaded: file_helper
INFO - 2023-10-31 11:44:59 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:44:59 --> Form Validation Class Initialized
INFO - 2023-10-31 11:44:59 --> Upload Class Initialized
INFO - 2023-10-31 11:44:59 --> Model "M_auth" initialized
INFO - 2023-10-31 11:44:59 --> Model "M_user" initialized
INFO - 2023-10-31 11:44:59 --> Model "M_produk" initialized
INFO - 2023-10-31 11:44:59 --> Controller Class Initialized
INFO - 2023-10-31 11:44:59 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:44:59 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:44:59 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:44:59 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:44:59 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:44:59 --> Model "M_bank" initialized
INFO - 2023-10-31 11:44:59 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:44:59 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:44:59 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:44:59 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:44:59 --> Final output sent to browser
DEBUG - 2023-10-31 11:44:59 --> Total execution time: 0.7614
ERROR - 2023-10-31 11:45:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:45:40 --> Config Class Initialized
INFO - 2023-10-31 11:45:40 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:45:40 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:45:40 --> Utf8 Class Initialized
INFO - 2023-10-31 11:45:40 --> URI Class Initialized
INFO - 2023-10-31 11:45:40 --> Router Class Initialized
INFO - 2023-10-31 11:45:40 --> Output Class Initialized
INFO - 2023-10-31 11:45:40 --> Security Class Initialized
DEBUG - 2023-10-31 11:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:45:40 --> Input Class Initialized
INFO - 2023-10-31 11:45:40 --> Language Class Initialized
INFO - 2023-10-31 11:45:40 --> Loader Class Initialized
INFO - 2023-10-31 11:45:40 --> Helper loaded: url_helper
INFO - 2023-10-31 11:45:40 --> Helper loaded: form_helper
INFO - 2023-10-31 11:45:40 --> Helper loaded: file_helper
INFO - 2023-10-31 11:45:40 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:45:40 --> Form Validation Class Initialized
INFO - 2023-10-31 11:45:40 --> Upload Class Initialized
INFO - 2023-10-31 11:45:40 --> Model "M_auth" initialized
INFO - 2023-10-31 11:45:40 --> Model "M_user" initialized
INFO - 2023-10-31 11:45:40 --> Model "M_produk" initialized
INFO - 2023-10-31 11:45:40 --> Controller Class Initialized
INFO - 2023-10-31 11:45:40 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:45:40 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:45:40 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:45:40 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:45:40 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:45:40 --> Model "M_bank" initialized
INFO - 2023-10-31 11:45:40 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:45:40 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:45:41 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:45:41 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:45:41 --> Final output sent to browser
DEBUG - 2023-10-31 11:45:41 --> Total execution time: 1.2808
ERROR - 2023-10-31 11:45:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:45:47 --> Config Class Initialized
INFO - 2023-10-31 11:45:47 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:45:47 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:45:47 --> Utf8 Class Initialized
INFO - 2023-10-31 11:45:47 --> URI Class Initialized
INFO - 2023-10-31 11:45:47 --> Router Class Initialized
INFO - 2023-10-31 11:45:47 --> Output Class Initialized
INFO - 2023-10-31 11:45:47 --> Security Class Initialized
DEBUG - 2023-10-31 11:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:45:47 --> Input Class Initialized
INFO - 2023-10-31 11:45:47 --> Language Class Initialized
INFO - 2023-10-31 11:45:47 --> Loader Class Initialized
INFO - 2023-10-31 11:45:47 --> Helper loaded: url_helper
INFO - 2023-10-31 11:45:47 --> Helper loaded: form_helper
INFO - 2023-10-31 11:45:47 --> Helper loaded: file_helper
INFO - 2023-10-31 11:45:47 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:45:47 --> Form Validation Class Initialized
INFO - 2023-10-31 11:45:47 --> Upload Class Initialized
INFO - 2023-10-31 11:45:47 --> Model "M_auth" initialized
INFO - 2023-10-31 11:45:47 --> Model "M_user" initialized
INFO - 2023-10-31 11:45:47 --> Model "M_produk" initialized
INFO - 2023-10-31 11:45:47 --> Controller Class Initialized
INFO - 2023-10-31 11:45:47 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:45:47 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:45:47 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:45:47 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:45:47 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:45:47 --> Model "M_bank" initialized
INFO - 2023-10-31 11:45:47 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:45:47 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:45:47 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:45:47 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:45:47 --> Final output sent to browser
DEBUG - 2023-10-31 11:45:47 --> Total execution time: 0.5078
ERROR - 2023-10-31 11:57:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:57:44 --> Config Class Initialized
INFO - 2023-10-31 11:57:44 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:57:44 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:57:44 --> Utf8 Class Initialized
INFO - 2023-10-31 11:57:44 --> URI Class Initialized
INFO - 2023-10-31 11:57:44 --> Router Class Initialized
INFO - 2023-10-31 11:57:44 --> Output Class Initialized
INFO - 2023-10-31 11:57:44 --> Security Class Initialized
DEBUG - 2023-10-31 11:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:57:44 --> Input Class Initialized
INFO - 2023-10-31 11:57:44 --> Language Class Initialized
INFO - 2023-10-31 11:57:45 --> Loader Class Initialized
INFO - 2023-10-31 11:57:45 --> Helper loaded: url_helper
INFO - 2023-10-31 11:57:45 --> Helper loaded: form_helper
INFO - 2023-10-31 11:57:45 --> Helper loaded: file_helper
INFO - 2023-10-31 11:57:45 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:57:45 --> Form Validation Class Initialized
INFO - 2023-10-31 11:57:45 --> Upload Class Initialized
INFO - 2023-10-31 11:57:45 --> Model "M_auth" initialized
INFO - 2023-10-31 11:57:45 --> Model "M_user" initialized
INFO - 2023-10-31 11:57:45 --> Model "M_produk" initialized
INFO - 2023-10-31 11:57:45 --> Controller Class Initialized
INFO - 2023-10-31 11:57:45 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:57:45 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:57:45 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:57:45 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:57:45 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:57:45 --> Model "M_bank" initialized
INFO - 2023-10-31 11:57:45 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:57:45 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-31 11:57:45 --> Severity: Warning --> Undefined variable $sub_total C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Home.php 549
ERROR - 2023-10-31 11:57:45 --> Severity: Warning --> Undefined property: Home::$ C:\xampp\htdocs\4_aan\semakar_adventure\system\core\Model.php 74
INFO - 2023-10-31 11:57:45 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:57:45 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:57:45 --> Final output sent to browser
DEBUG - 2023-10-31 11:57:45 --> Total execution time: 0.5035
ERROR - 2023-10-31 11:58:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:58:19 --> Config Class Initialized
INFO - 2023-10-31 11:58:19 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:58:19 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:58:19 --> Utf8 Class Initialized
INFO - 2023-10-31 11:58:19 --> URI Class Initialized
INFO - 2023-10-31 11:58:19 --> Router Class Initialized
INFO - 2023-10-31 11:58:19 --> Output Class Initialized
INFO - 2023-10-31 11:58:19 --> Security Class Initialized
DEBUG - 2023-10-31 11:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:58:19 --> Input Class Initialized
INFO - 2023-10-31 11:58:19 --> Language Class Initialized
INFO - 2023-10-31 11:58:19 --> Loader Class Initialized
INFO - 2023-10-31 11:58:19 --> Helper loaded: url_helper
INFO - 2023-10-31 11:58:19 --> Helper loaded: form_helper
INFO - 2023-10-31 11:58:19 --> Helper loaded: file_helper
INFO - 2023-10-31 11:58:19 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:58:19 --> Form Validation Class Initialized
INFO - 2023-10-31 11:58:19 --> Upload Class Initialized
INFO - 2023-10-31 11:58:19 --> Model "M_auth" initialized
INFO - 2023-10-31 11:58:19 --> Model "M_user" initialized
INFO - 2023-10-31 11:58:19 --> Model "M_produk" initialized
INFO - 2023-10-31 11:58:19 --> Controller Class Initialized
INFO - 2023-10-31 11:58:19 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:58:19 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:58:19 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:58:19 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:58:19 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:58:19 --> Model "M_bank" initialized
INFO - 2023-10-31 11:58:19 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:58:19 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:58:20 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:58:20 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:58:20 --> Final output sent to browser
DEBUG - 2023-10-31 11:58:20 --> Total execution time: 0.5233
ERROR - 2023-10-31 11:58:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:58:25 --> Config Class Initialized
INFO - 2023-10-31 11:58:25 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:58:25 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:58:25 --> Utf8 Class Initialized
INFO - 2023-10-31 11:58:25 --> URI Class Initialized
INFO - 2023-10-31 11:58:25 --> Router Class Initialized
INFO - 2023-10-31 11:58:25 --> Output Class Initialized
INFO - 2023-10-31 11:58:25 --> Security Class Initialized
DEBUG - 2023-10-31 11:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:58:25 --> Input Class Initialized
INFO - 2023-10-31 11:58:25 --> Language Class Initialized
INFO - 2023-10-31 11:58:25 --> Loader Class Initialized
INFO - 2023-10-31 11:58:25 --> Helper loaded: url_helper
INFO - 2023-10-31 11:58:25 --> Helper loaded: form_helper
INFO - 2023-10-31 11:58:26 --> Helper loaded: file_helper
INFO - 2023-10-31 11:58:26 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:58:26 --> Form Validation Class Initialized
INFO - 2023-10-31 11:58:26 --> Upload Class Initialized
INFO - 2023-10-31 11:58:26 --> Model "M_auth" initialized
INFO - 2023-10-31 11:58:26 --> Model "M_user" initialized
INFO - 2023-10-31 11:58:26 --> Model "M_produk" initialized
INFO - 2023-10-31 11:58:26 --> Controller Class Initialized
INFO - 2023-10-31 11:58:26 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:58:26 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:58:26 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:58:26 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:58:26 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:58:26 --> Model "M_bank" initialized
INFO - 2023-10-31 11:58:26 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:58:26 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:58:26 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:58:26 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:58:26 --> Final output sent to browser
DEBUG - 2023-10-31 11:58:26 --> Total execution time: 0.4492
ERROR - 2023-10-31 11:59:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:59:10 --> Config Class Initialized
INFO - 2023-10-31 11:59:10 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:59:10 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:59:10 --> Utf8 Class Initialized
INFO - 2023-10-31 11:59:10 --> URI Class Initialized
INFO - 2023-10-31 11:59:10 --> Router Class Initialized
INFO - 2023-10-31 11:59:10 --> Output Class Initialized
INFO - 2023-10-31 11:59:10 --> Security Class Initialized
DEBUG - 2023-10-31 11:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:59:10 --> Input Class Initialized
INFO - 2023-10-31 11:59:10 --> Language Class Initialized
INFO - 2023-10-31 11:59:10 --> Loader Class Initialized
INFO - 2023-10-31 11:59:10 --> Helper loaded: url_helper
INFO - 2023-10-31 11:59:10 --> Helper loaded: form_helper
INFO - 2023-10-31 11:59:10 --> Helper loaded: file_helper
INFO - 2023-10-31 11:59:10 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:59:10 --> Form Validation Class Initialized
INFO - 2023-10-31 11:59:10 --> Upload Class Initialized
INFO - 2023-10-31 11:59:10 --> Model "M_auth" initialized
INFO - 2023-10-31 11:59:10 --> Model "M_user" initialized
INFO - 2023-10-31 11:59:10 --> Model "M_produk" initialized
INFO - 2023-10-31 11:59:10 --> Controller Class Initialized
INFO - 2023-10-31 11:59:10 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:59:10 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:59:10 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:59:10 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:59:10 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:59:10 --> Model "M_bank" initialized
INFO - 2023-10-31 11:59:10 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:59:10 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:59:10 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:59:10 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:59:10 --> Final output sent to browser
DEBUG - 2023-10-31 11:59:10 --> Total execution time: 0.4353
ERROR - 2023-10-31 11:59:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:59:12 --> Config Class Initialized
INFO - 2023-10-31 11:59:12 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:59:12 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:59:12 --> Utf8 Class Initialized
INFO - 2023-10-31 11:59:12 --> URI Class Initialized
INFO - 2023-10-31 11:59:12 --> Router Class Initialized
INFO - 2023-10-31 11:59:12 --> Output Class Initialized
INFO - 2023-10-31 11:59:12 --> Security Class Initialized
DEBUG - 2023-10-31 11:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:59:12 --> Input Class Initialized
INFO - 2023-10-31 11:59:12 --> Language Class Initialized
INFO - 2023-10-31 11:59:12 --> Loader Class Initialized
INFO - 2023-10-31 11:59:12 --> Helper loaded: url_helper
INFO - 2023-10-31 11:59:12 --> Helper loaded: form_helper
INFO - 2023-10-31 11:59:12 --> Helper loaded: file_helper
INFO - 2023-10-31 11:59:12 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:59:12 --> Form Validation Class Initialized
INFO - 2023-10-31 11:59:12 --> Upload Class Initialized
INFO - 2023-10-31 11:59:12 --> Model "M_auth" initialized
INFO - 2023-10-31 11:59:12 --> Model "M_user" initialized
INFO - 2023-10-31 11:59:12 --> Model "M_produk" initialized
INFO - 2023-10-31 11:59:12 --> Controller Class Initialized
INFO - 2023-10-31 11:59:12 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:59:12 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:59:12 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:59:12 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:59:12 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:59:12 --> Model "M_bank" initialized
INFO - 2023-10-31 11:59:12 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:59:12 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:59:12 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:59:12 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:59:12 --> Final output sent to browser
DEBUG - 2023-10-31 11:59:12 --> Total execution time: 0.4172
ERROR - 2023-10-31 11:59:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:59:13 --> Config Class Initialized
INFO - 2023-10-31 11:59:13 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:59:13 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:59:13 --> Utf8 Class Initialized
INFO - 2023-10-31 11:59:13 --> URI Class Initialized
INFO - 2023-10-31 11:59:13 --> Router Class Initialized
INFO - 2023-10-31 11:59:13 --> Output Class Initialized
INFO - 2023-10-31 11:59:13 --> Security Class Initialized
DEBUG - 2023-10-31 11:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:59:13 --> Input Class Initialized
INFO - 2023-10-31 11:59:13 --> Language Class Initialized
INFO - 2023-10-31 11:59:13 --> Loader Class Initialized
INFO - 2023-10-31 11:59:13 --> Helper loaded: url_helper
INFO - 2023-10-31 11:59:13 --> Helper loaded: form_helper
INFO - 2023-10-31 11:59:13 --> Helper loaded: file_helper
INFO - 2023-10-31 11:59:13 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:59:13 --> Form Validation Class Initialized
INFO - 2023-10-31 11:59:13 --> Upload Class Initialized
INFO - 2023-10-31 11:59:13 --> Model "M_auth" initialized
INFO - 2023-10-31 11:59:13 --> Model "M_user" initialized
INFO - 2023-10-31 11:59:13 --> Model "M_produk" initialized
INFO - 2023-10-31 11:59:13 --> Controller Class Initialized
INFO - 2023-10-31 11:59:13 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:59:13 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:59:13 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:59:13 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:59:13 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:59:13 --> Model "M_bank" initialized
INFO - 2023-10-31 11:59:13 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:59:13 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:59:13 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:59:13 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:59:13 --> Final output sent to browser
DEBUG - 2023-10-31 11:59:13 --> Total execution time: 0.4855
ERROR - 2023-10-31 11:59:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:59:13 --> Config Class Initialized
INFO - 2023-10-31 11:59:13 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:59:13 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:59:13 --> Utf8 Class Initialized
INFO - 2023-10-31 11:59:13 --> URI Class Initialized
INFO - 2023-10-31 11:59:13 --> Router Class Initialized
INFO - 2023-10-31 11:59:13 --> Output Class Initialized
INFO - 2023-10-31 11:59:13 --> Security Class Initialized
DEBUG - 2023-10-31 11:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:59:13 --> Input Class Initialized
INFO - 2023-10-31 11:59:13 --> Language Class Initialized
INFO - 2023-10-31 11:59:13 --> Loader Class Initialized
INFO - 2023-10-31 11:59:13 --> Helper loaded: url_helper
INFO - 2023-10-31 11:59:13 --> Helper loaded: form_helper
INFO - 2023-10-31 11:59:13 --> Helper loaded: file_helper
INFO - 2023-10-31 11:59:13 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:59:13 --> Form Validation Class Initialized
INFO - 2023-10-31 11:59:13 --> Upload Class Initialized
INFO - 2023-10-31 11:59:13 --> Model "M_auth" initialized
INFO - 2023-10-31 11:59:13 --> Model "M_user" initialized
INFO - 2023-10-31 11:59:13 --> Model "M_produk" initialized
INFO - 2023-10-31 11:59:13 --> Controller Class Initialized
INFO - 2023-10-31 11:59:13 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:59:13 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:59:13 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:59:13 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:59:13 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:59:13 --> Model "M_bank" initialized
INFO - 2023-10-31 11:59:13 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:59:13 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:59:14 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:59:14 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:59:14 --> Final output sent to browser
DEBUG - 2023-10-31 11:59:14 --> Total execution time: 0.7247
ERROR - 2023-10-31 11:59:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 11:59:19 --> Config Class Initialized
INFO - 2023-10-31 11:59:19 --> Hooks Class Initialized
DEBUG - 2023-10-31 11:59:19 --> UTF-8 Support Enabled
INFO - 2023-10-31 11:59:19 --> Utf8 Class Initialized
INFO - 2023-10-31 11:59:19 --> URI Class Initialized
INFO - 2023-10-31 11:59:19 --> Router Class Initialized
INFO - 2023-10-31 11:59:19 --> Output Class Initialized
INFO - 2023-10-31 11:59:19 --> Security Class Initialized
DEBUG - 2023-10-31 11:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 11:59:19 --> Input Class Initialized
INFO - 2023-10-31 11:59:19 --> Language Class Initialized
INFO - 2023-10-31 11:59:19 --> Loader Class Initialized
INFO - 2023-10-31 11:59:19 --> Helper loaded: url_helper
INFO - 2023-10-31 11:59:19 --> Helper loaded: form_helper
INFO - 2023-10-31 11:59:19 --> Helper loaded: file_helper
INFO - 2023-10-31 11:59:19 --> Database Driver Class Initialized
DEBUG - 2023-10-31 11:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 11:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 11:59:19 --> Form Validation Class Initialized
INFO - 2023-10-31 11:59:19 --> Upload Class Initialized
INFO - 2023-10-31 11:59:19 --> Model "M_auth" initialized
INFO - 2023-10-31 11:59:19 --> Model "M_user" initialized
INFO - 2023-10-31 11:59:19 --> Model "M_produk" initialized
INFO - 2023-10-31 11:59:19 --> Controller Class Initialized
INFO - 2023-10-31 11:59:19 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 11:59:19 --> Model "M_produk" initialized
DEBUG - 2023-10-31 11:59:19 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 11:59:19 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 11:59:19 --> Model "M_transaksi" initialized
INFO - 2023-10-31 11:59:19 --> Model "M_bank" initialized
INFO - 2023-10-31 11:59:19 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 11:59:19 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 11:59:19 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 11:59:19 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 11:59:19 --> Final output sent to browser
DEBUG - 2023-10-31 11:59:19 --> Total execution time: 0.5478
ERROR - 2023-10-31 12:00:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 12:00:41 --> Config Class Initialized
INFO - 2023-10-31 12:00:41 --> Hooks Class Initialized
DEBUG - 2023-10-31 12:00:41 --> UTF-8 Support Enabled
INFO - 2023-10-31 12:00:41 --> Utf8 Class Initialized
INFO - 2023-10-31 12:00:41 --> URI Class Initialized
INFO - 2023-10-31 12:00:41 --> Router Class Initialized
INFO - 2023-10-31 12:00:41 --> Output Class Initialized
INFO - 2023-10-31 12:00:41 --> Security Class Initialized
DEBUG - 2023-10-31 12:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 12:00:41 --> Input Class Initialized
INFO - 2023-10-31 12:00:41 --> Language Class Initialized
INFO - 2023-10-31 12:00:41 --> Loader Class Initialized
INFO - 2023-10-31 12:00:41 --> Helper loaded: url_helper
INFO - 2023-10-31 12:00:41 --> Helper loaded: form_helper
INFO - 2023-10-31 12:00:41 --> Helper loaded: file_helper
INFO - 2023-10-31 12:00:41 --> Database Driver Class Initialized
DEBUG - 2023-10-31 12:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 12:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 12:00:41 --> Form Validation Class Initialized
INFO - 2023-10-31 12:00:41 --> Upload Class Initialized
INFO - 2023-10-31 12:00:41 --> Model "M_auth" initialized
INFO - 2023-10-31 12:00:41 --> Model "M_user" initialized
INFO - 2023-10-31 12:00:41 --> Model "M_produk" initialized
INFO - 2023-10-31 12:00:41 --> Controller Class Initialized
INFO - 2023-10-31 12:00:41 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 12:00:41 --> Model "M_produk" initialized
DEBUG - 2023-10-31 12:00:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 12:00:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 12:00:41 --> Model "M_transaksi" initialized
INFO - 2023-10-31 12:00:41 --> Model "M_bank" initialized
INFO - 2023-10-31 12:00:41 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 12:00:41 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-31 12:00:42 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front\v_booking_saya.php 8
ERROR - 2023-10-31 12:00:42 --> Severity: Warning --> Undefined variable $transaksi C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front\v_booking_saya.php 186
ERROR - 2023-10-31 12:00:42 --> Severity: Warning --> Undefined variable $transaksi_pending C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front\v_booking_saya.php 265
ERROR - 2023-10-31 12:00:42 --> Severity: Warning --> Undefined variable $transaksi_lunas C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front\v_booking_saya.php 318
ERROR - 2023-10-31 12:00:42 --> Severity: Warning --> Undefined variable $transaksi_sewaselesai C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front\v_booking_saya.php 372
INFO - 2023-10-31 12:00:42 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 12:00:42 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 12:00:42 --> Final output sent to browser
DEBUG - 2023-10-31 12:00:42 --> Total execution time: 0.6950
ERROR - 2023-10-31 12:00:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 12:00:48 --> Config Class Initialized
INFO - 2023-10-31 12:00:48 --> Hooks Class Initialized
DEBUG - 2023-10-31 12:00:48 --> UTF-8 Support Enabled
INFO - 2023-10-31 12:00:48 --> Utf8 Class Initialized
INFO - 2023-10-31 12:00:48 --> URI Class Initialized
INFO - 2023-10-31 12:00:48 --> Router Class Initialized
INFO - 2023-10-31 12:00:48 --> Output Class Initialized
INFO - 2023-10-31 12:00:48 --> Security Class Initialized
DEBUG - 2023-10-31 12:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 12:00:48 --> Input Class Initialized
INFO - 2023-10-31 12:00:48 --> Language Class Initialized
INFO - 2023-10-31 12:00:48 --> Loader Class Initialized
INFO - 2023-10-31 12:00:48 --> Helper loaded: url_helper
INFO - 2023-10-31 12:00:48 --> Helper loaded: form_helper
INFO - 2023-10-31 12:00:48 --> Helper loaded: file_helper
INFO - 2023-10-31 12:00:48 --> Database Driver Class Initialized
DEBUG - 2023-10-31 12:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 12:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 12:00:48 --> Form Validation Class Initialized
INFO - 2023-10-31 12:00:48 --> Upload Class Initialized
INFO - 2023-10-31 12:00:48 --> Model "M_auth" initialized
INFO - 2023-10-31 12:00:48 --> Model "M_user" initialized
INFO - 2023-10-31 12:00:48 --> Model "M_produk" initialized
INFO - 2023-10-31 12:00:48 --> Controller Class Initialized
INFO - 2023-10-31 12:00:48 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 12:00:48 --> Model "M_produk" initialized
DEBUG - 2023-10-31 12:00:48 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 12:00:48 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 12:00:48 --> Model "M_transaksi" initialized
INFO - 2023-10-31 12:00:48 --> Model "M_bank" initialized
INFO - 2023-10-31 12:00:48 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 12:00:48 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 12:00:49 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 12:00:49 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 12:00:49 --> Final output sent to browser
DEBUG - 2023-10-31 12:00:49 --> Total execution time: 0.4842
ERROR - 2023-10-31 12:01:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 12:01:03 --> Config Class Initialized
INFO - 2023-10-31 12:01:03 --> Hooks Class Initialized
DEBUG - 2023-10-31 12:01:03 --> UTF-8 Support Enabled
INFO - 2023-10-31 12:01:03 --> Utf8 Class Initialized
INFO - 2023-10-31 12:01:03 --> URI Class Initialized
INFO - 2023-10-31 12:01:03 --> Router Class Initialized
INFO - 2023-10-31 12:01:03 --> Output Class Initialized
INFO - 2023-10-31 12:01:03 --> Security Class Initialized
DEBUG - 2023-10-31 12:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 12:01:03 --> Input Class Initialized
INFO - 2023-10-31 12:01:03 --> Language Class Initialized
INFO - 2023-10-31 12:01:03 --> Loader Class Initialized
INFO - 2023-10-31 12:01:03 --> Helper loaded: url_helper
INFO - 2023-10-31 12:01:03 --> Helper loaded: form_helper
INFO - 2023-10-31 12:01:03 --> Helper loaded: file_helper
INFO - 2023-10-31 12:01:03 --> Database Driver Class Initialized
DEBUG - 2023-10-31 12:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 12:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 12:01:03 --> Form Validation Class Initialized
INFO - 2023-10-31 12:01:03 --> Upload Class Initialized
INFO - 2023-10-31 12:01:03 --> Model "M_auth" initialized
INFO - 2023-10-31 12:01:03 --> Model "M_user" initialized
INFO - 2023-10-31 12:01:03 --> Model "M_produk" initialized
INFO - 2023-10-31 12:01:03 --> Controller Class Initialized
INFO - 2023-10-31 12:01:03 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 12:01:03 --> Model "M_produk" initialized
DEBUG - 2023-10-31 12:01:03 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 12:01:03 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 12:01:03 --> Model "M_transaksi" initialized
INFO - 2023-10-31 12:01:03 --> Model "M_bank" initialized
INFO - 2023-10-31 12:01:03 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 12:01:03 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-31 12:01:03 --> Severity: Warning --> Undefined variable $transaksi C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front\v_booking_saya.php 186
INFO - 2023-10-31 12:01:03 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 12:01:03 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 12:01:03 --> Final output sent to browser
DEBUG - 2023-10-31 12:01:03 --> Total execution time: 0.4660
ERROR - 2023-10-31 12:01:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 12:01:10 --> Config Class Initialized
INFO - 2023-10-31 12:01:10 --> Hooks Class Initialized
DEBUG - 2023-10-31 12:01:10 --> UTF-8 Support Enabled
INFO - 2023-10-31 12:01:10 --> Utf8 Class Initialized
INFO - 2023-10-31 12:01:10 --> URI Class Initialized
INFO - 2023-10-31 12:01:10 --> Router Class Initialized
INFO - 2023-10-31 12:01:10 --> Output Class Initialized
INFO - 2023-10-31 12:01:10 --> Security Class Initialized
DEBUG - 2023-10-31 12:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 12:01:10 --> Input Class Initialized
INFO - 2023-10-31 12:01:10 --> Language Class Initialized
INFO - 2023-10-31 12:01:10 --> Loader Class Initialized
INFO - 2023-10-31 12:01:10 --> Helper loaded: url_helper
INFO - 2023-10-31 12:01:10 --> Helper loaded: form_helper
INFO - 2023-10-31 12:01:10 --> Helper loaded: file_helper
INFO - 2023-10-31 12:01:10 --> Database Driver Class Initialized
DEBUG - 2023-10-31 12:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 12:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 12:01:10 --> Form Validation Class Initialized
INFO - 2023-10-31 12:01:10 --> Upload Class Initialized
INFO - 2023-10-31 12:01:10 --> Model "M_auth" initialized
INFO - 2023-10-31 12:01:10 --> Model "M_user" initialized
INFO - 2023-10-31 12:01:10 --> Model "M_produk" initialized
INFO - 2023-10-31 12:01:10 --> Controller Class Initialized
INFO - 2023-10-31 12:01:10 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 12:01:10 --> Model "M_produk" initialized
DEBUG - 2023-10-31 12:01:10 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 12:01:10 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 12:01:10 --> Model "M_transaksi" initialized
INFO - 2023-10-31 12:01:10 --> Model "M_bank" initialized
INFO - 2023-10-31 12:01:10 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 12:01:10 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 12:01:11 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 12:01:11 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 12:01:11 --> Final output sent to browser
DEBUG - 2023-10-31 12:01:11 --> Total execution time: 1.3587
ERROR - 2023-10-31 12:01:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 12:01:23 --> Config Class Initialized
INFO - 2023-10-31 12:01:23 --> Hooks Class Initialized
DEBUG - 2023-10-31 12:01:23 --> UTF-8 Support Enabled
INFO - 2023-10-31 12:01:23 --> Utf8 Class Initialized
INFO - 2023-10-31 12:01:23 --> URI Class Initialized
INFO - 2023-10-31 12:01:23 --> Router Class Initialized
INFO - 2023-10-31 12:01:23 --> Output Class Initialized
INFO - 2023-10-31 12:01:23 --> Security Class Initialized
DEBUG - 2023-10-31 12:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 12:01:23 --> Input Class Initialized
INFO - 2023-10-31 12:01:23 --> Language Class Initialized
INFO - 2023-10-31 12:01:23 --> Loader Class Initialized
INFO - 2023-10-31 12:01:23 --> Helper loaded: url_helper
INFO - 2023-10-31 12:01:23 --> Helper loaded: form_helper
INFO - 2023-10-31 12:01:23 --> Helper loaded: file_helper
INFO - 2023-10-31 12:01:23 --> Database Driver Class Initialized
DEBUG - 2023-10-31 12:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 12:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 12:01:23 --> Form Validation Class Initialized
INFO - 2023-10-31 12:01:23 --> Upload Class Initialized
INFO - 2023-10-31 12:01:23 --> Model "M_auth" initialized
INFO - 2023-10-31 12:01:23 --> Model "M_user" initialized
INFO - 2023-10-31 12:01:23 --> Model "M_produk" initialized
INFO - 2023-10-31 12:01:23 --> Controller Class Initialized
INFO - 2023-10-31 12:01:23 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 12:01:23 --> Model "M_produk" initialized
DEBUG - 2023-10-31 12:01:23 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 12:01:23 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 12:01:23 --> Model "M_transaksi" initialized
INFO - 2023-10-31 12:01:23 --> Model "M_bank" initialized
INFO - 2023-10-31 12:01:23 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 12:01:23 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-31 12:01:23 --> Severity: Warning --> Undefined variable $transaksi_pending C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front\v_booking_saya.php 265
ERROR - 2023-10-31 12:01:23 --> Severity: Warning --> Undefined variable $transaksi_lunas C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front\v_booking_saya.php 318
INFO - 2023-10-31 12:01:23 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 12:01:23 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 12:01:23 --> Final output sent to browser
DEBUG - 2023-10-31 12:01:23 --> Total execution time: 0.4551
ERROR - 2023-10-31 12:04:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 12:04:42 --> Config Class Initialized
INFO - 2023-10-31 12:04:42 --> Hooks Class Initialized
DEBUG - 2023-10-31 12:04:42 --> UTF-8 Support Enabled
INFO - 2023-10-31 12:04:42 --> Utf8 Class Initialized
INFO - 2023-10-31 12:04:42 --> URI Class Initialized
INFO - 2023-10-31 12:04:42 --> Router Class Initialized
INFO - 2023-10-31 12:04:42 --> Output Class Initialized
INFO - 2023-10-31 12:04:42 --> Security Class Initialized
DEBUG - 2023-10-31 12:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 12:04:42 --> Input Class Initialized
INFO - 2023-10-31 12:04:42 --> Language Class Initialized
INFO - 2023-10-31 12:04:42 --> Loader Class Initialized
INFO - 2023-10-31 12:04:42 --> Helper loaded: url_helper
INFO - 2023-10-31 12:04:42 --> Helper loaded: form_helper
INFO - 2023-10-31 12:04:42 --> Helper loaded: file_helper
INFO - 2023-10-31 12:04:42 --> Database Driver Class Initialized
DEBUG - 2023-10-31 12:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 12:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 12:04:42 --> Form Validation Class Initialized
INFO - 2023-10-31 12:04:42 --> Upload Class Initialized
INFO - 2023-10-31 12:04:42 --> Model "M_auth" initialized
INFO - 2023-10-31 12:04:42 --> Model "M_user" initialized
INFO - 2023-10-31 12:04:42 --> Model "M_produk" initialized
INFO - 2023-10-31 12:04:42 --> Controller Class Initialized
INFO - 2023-10-31 12:04:42 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 12:04:42 --> Model "M_produk" initialized
DEBUG - 2023-10-31 12:04:42 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 12:04:42 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 12:04:42 --> Model "M_transaksi" initialized
INFO - 2023-10-31 12:04:42 --> Model "M_bank" initialized
INFO - 2023-10-31 12:04:42 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 12:04:42 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 12:04:43 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 12:04:43 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 12:04:43 --> Final output sent to browser
DEBUG - 2023-10-31 12:04:43 --> Total execution time: 0.5048
ERROR - 2023-10-31 12:04:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 12:04:52 --> Config Class Initialized
INFO - 2023-10-31 12:04:52 --> Hooks Class Initialized
DEBUG - 2023-10-31 12:04:52 --> UTF-8 Support Enabled
INFO - 2023-10-31 12:04:52 --> Utf8 Class Initialized
INFO - 2023-10-31 12:04:52 --> URI Class Initialized
INFO - 2023-10-31 12:04:52 --> Router Class Initialized
INFO - 2023-10-31 12:04:52 --> Output Class Initialized
INFO - 2023-10-31 12:04:52 --> Security Class Initialized
DEBUG - 2023-10-31 12:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 12:04:52 --> Input Class Initialized
INFO - 2023-10-31 12:04:52 --> Language Class Initialized
INFO - 2023-10-31 12:04:52 --> Loader Class Initialized
INFO - 2023-10-31 12:04:52 --> Helper loaded: url_helper
INFO - 2023-10-31 12:04:52 --> Helper loaded: form_helper
INFO - 2023-10-31 12:04:52 --> Helper loaded: file_helper
INFO - 2023-10-31 12:04:52 --> Database Driver Class Initialized
DEBUG - 2023-10-31 12:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 12:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 12:04:52 --> Form Validation Class Initialized
INFO - 2023-10-31 12:04:52 --> Upload Class Initialized
INFO - 2023-10-31 12:04:52 --> Model "M_auth" initialized
INFO - 2023-10-31 12:04:52 --> Model "M_user" initialized
INFO - 2023-10-31 12:04:52 --> Model "M_produk" initialized
INFO - 2023-10-31 12:04:52 --> Controller Class Initialized
INFO - 2023-10-31 12:04:52 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 12:04:52 --> Model "M_produk" initialized
DEBUG - 2023-10-31 12:04:52 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 12:04:52 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 12:04:52 --> Model "M_transaksi" initialized
INFO - 2023-10-31 12:04:52 --> Model "M_bank" initialized
INFO - 2023-10-31 12:04:52 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 12:04:52 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 12:04:53 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 12:04:53 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 12:04:53 --> Final output sent to browser
DEBUG - 2023-10-31 12:04:53 --> Total execution time: 0.4126
ERROR - 2023-10-31 12:04:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 12:04:59 --> Config Class Initialized
INFO - 2023-10-31 12:04:59 --> Hooks Class Initialized
DEBUG - 2023-10-31 12:04:59 --> UTF-8 Support Enabled
INFO - 2023-10-31 12:04:59 --> Utf8 Class Initialized
INFO - 2023-10-31 12:04:59 --> URI Class Initialized
INFO - 2023-10-31 12:04:59 --> Router Class Initialized
INFO - 2023-10-31 12:04:59 --> Output Class Initialized
INFO - 2023-10-31 12:04:59 --> Security Class Initialized
DEBUG - 2023-10-31 12:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 12:04:59 --> Input Class Initialized
INFO - 2023-10-31 12:04:59 --> Language Class Initialized
INFO - 2023-10-31 12:04:59 --> Loader Class Initialized
INFO - 2023-10-31 12:04:59 --> Helper loaded: url_helper
INFO - 2023-10-31 12:04:59 --> Helper loaded: form_helper
INFO - 2023-10-31 12:04:59 --> Helper loaded: file_helper
INFO - 2023-10-31 12:04:59 --> Database Driver Class Initialized
DEBUG - 2023-10-31 12:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 12:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 12:04:59 --> Form Validation Class Initialized
INFO - 2023-10-31 12:04:59 --> Upload Class Initialized
INFO - 2023-10-31 12:04:59 --> Model "M_auth" initialized
INFO - 2023-10-31 12:04:59 --> Model "M_user" initialized
INFO - 2023-10-31 12:04:59 --> Model "M_produk" initialized
INFO - 2023-10-31 12:04:59 --> Controller Class Initialized
INFO - 2023-10-31 12:04:59 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 12:04:59 --> Model "M_produk" initialized
DEBUG - 2023-10-31 12:04:59 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 12:04:59 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 12:04:59 --> Model "M_transaksi" initialized
INFO - 2023-10-31 12:04:59 --> Model "M_bank" initialized
INFO - 2023-10-31 12:04:59 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 12:04:59 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 12:05:00 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 12:05:00 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 12:05:00 --> Final output sent to browser
DEBUG - 2023-10-31 12:05:00 --> Total execution time: 0.8982
ERROR - 2023-10-31 12:05:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 12:05:23 --> Config Class Initialized
INFO - 2023-10-31 12:05:23 --> Hooks Class Initialized
DEBUG - 2023-10-31 12:05:23 --> UTF-8 Support Enabled
INFO - 2023-10-31 12:05:23 --> Utf8 Class Initialized
INFO - 2023-10-31 12:05:23 --> URI Class Initialized
INFO - 2023-10-31 12:05:23 --> Router Class Initialized
INFO - 2023-10-31 12:05:23 --> Output Class Initialized
INFO - 2023-10-31 12:05:23 --> Security Class Initialized
DEBUG - 2023-10-31 12:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 12:05:23 --> Input Class Initialized
INFO - 2023-10-31 12:05:23 --> Language Class Initialized
INFO - 2023-10-31 12:05:23 --> Loader Class Initialized
INFO - 2023-10-31 12:05:23 --> Helper loaded: url_helper
INFO - 2023-10-31 12:05:23 --> Helper loaded: form_helper
INFO - 2023-10-31 12:05:23 --> Helper loaded: file_helper
INFO - 2023-10-31 12:05:23 --> Database Driver Class Initialized
DEBUG - 2023-10-31 12:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 12:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 12:05:24 --> Form Validation Class Initialized
INFO - 2023-10-31 12:05:24 --> Upload Class Initialized
INFO - 2023-10-31 12:05:24 --> Model "M_auth" initialized
INFO - 2023-10-31 12:05:24 --> Model "M_user" initialized
INFO - 2023-10-31 12:05:24 --> Model "M_produk" initialized
INFO - 2023-10-31 12:05:24 --> Controller Class Initialized
INFO - 2023-10-31 12:05:24 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 12:05:24 --> Model "M_produk" initialized
DEBUG - 2023-10-31 12:05:24 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 12:05:24 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 12:05:24 --> Model "M_transaksi" initialized
INFO - 2023-10-31 12:05:24 --> Model "M_bank" initialized
INFO - 2023-10-31 12:05:24 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 12:05:24 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 12:05:24 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 12:05:24 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 12:05:24 --> Final output sent to browser
DEBUG - 2023-10-31 12:05:24 --> Total execution time: 0.4724
ERROR - 2023-10-31 12:05:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 12:05:54 --> Config Class Initialized
INFO - 2023-10-31 12:05:54 --> Hooks Class Initialized
DEBUG - 2023-10-31 12:05:54 --> UTF-8 Support Enabled
INFO - 2023-10-31 12:05:54 --> Utf8 Class Initialized
INFO - 2023-10-31 12:05:54 --> URI Class Initialized
INFO - 2023-10-31 12:05:54 --> Router Class Initialized
INFO - 2023-10-31 12:05:54 --> Output Class Initialized
INFO - 2023-10-31 12:05:54 --> Security Class Initialized
DEBUG - 2023-10-31 12:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 12:05:54 --> Input Class Initialized
INFO - 2023-10-31 12:05:54 --> Language Class Initialized
INFO - 2023-10-31 12:05:54 --> Loader Class Initialized
INFO - 2023-10-31 12:05:54 --> Helper loaded: url_helper
INFO - 2023-10-31 12:05:54 --> Helper loaded: form_helper
INFO - 2023-10-31 12:05:54 --> Helper loaded: file_helper
INFO - 2023-10-31 12:05:54 --> Database Driver Class Initialized
DEBUG - 2023-10-31 12:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 12:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 12:05:54 --> Form Validation Class Initialized
INFO - 2023-10-31 12:05:54 --> Upload Class Initialized
INFO - 2023-10-31 12:05:54 --> Model "M_auth" initialized
INFO - 2023-10-31 12:05:54 --> Model "M_user" initialized
INFO - 2023-10-31 12:05:54 --> Model "M_produk" initialized
INFO - 2023-10-31 12:05:54 --> Controller Class Initialized
INFO - 2023-10-31 12:05:54 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 12:05:54 --> Model "M_produk" initialized
DEBUG - 2023-10-31 12:05:54 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 12:05:54 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 12:05:54 --> Model "M_transaksi" initialized
INFO - 2023-10-31 12:05:54 --> Model "M_bank" initialized
INFO - 2023-10-31 12:05:54 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 12:05:54 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 12:05:54 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 12:05:54 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 12:05:54 --> Final output sent to browser
DEBUG - 2023-10-31 12:05:54 --> Total execution time: 0.3817
ERROR - 2023-10-31 12:08:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 12:08:09 --> Config Class Initialized
INFO - 2023-10-31 12:08:09 --> Hooks Class Initialized
DEBUG - 2023-10-31 12:08:09 --> UTF-8 Support Enabled
INFO - 2023-10-31 12:08:09 --> Utf8 Class Initialized
INFO - 2023-10-31 12:08:09 --> URI Class Initialized
INFO - 2023-10-31 12:08:09 --> Router Class Initialized
INFO - 2023-10-31 12:08:09 --> Output Class Initialized
INFO - 2023-10-31 12:08:09 --> Security Class Initialized
DEBUG - 2023-10-31 12:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 12:08:09 --> Input Class Initialized
INFO - 2023-10-31 12:08:09 --> Language Class Initialized
INFO - 2023-10-31 12:08:09 --> Loader Class Initialized
INFO - 2023-10-31 12:08:09 --> Helper loaded: url_helper
INFO - 2023-10-31 12:08:09 --> Helper loaded: form_helper
INFO - 2023-10-31 12:08:09 --> Helper loaded: file_helper
INFO - 2023-10-31 12:08:09 --> Database Driver Class Initialized
DEBUG - 2023-10-31 12:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 12:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 12:08:09 --> Form Validation Class Initialized
INFO - 2023-10-31 12:08:09 --> Upload Class Initialized
INFO - 2023-10-31 12:08:09 --> Model "M_auth" initialized
INFO - 2023-10-31 12:08:09 --> Model "M_user" initialized
INFO - 2023-10-31 12:08:09 --> Model "M_produk" initialized
INFO - 2023-10-31 12:08:09 --> Controller Class Initialized
INFO - 2023-10-31 12:08:09 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 12:08:09 --> Model "M_produk" initialized
DEBUG - 2023-10-31 12:08:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 12:08:09 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 12:08:09 --> Model "M_transaksi" initialized
INFO - 2023-10-31 12:08:09 --> Model "M_bank" initialized
INFO - 2023-10-31 12:08:09 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 12:08:09 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 12:08:12 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 12:08:12 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 12:08:12 --> Final output sent to browser
DEBUG - 2023-10-31 12:08:12 --> Total execution time: 3.6171
ERROR - 2023-10-31 12:08:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 12:08:58 --> Config Class Initialized
INFO - 2023-10-31 12:08:58 --> Hooks Class Initialized
DEBUG - 2023-10-31 12:08:58 --> UTF-8 Support Enabled
INFO - 2023-10-31 12:08:58 --> Utf8 Class Initialized
INFO - 2023-10-31 12:08:58 --> URI Class Initialized
INFO - 2023-10-31 12:08:58 --> Router Class Initialized
INFO - 2023-10-31 12:08:58 --> Output Class Initialized
INFO - 2023-10-31 12:08:58 --> Security Class Initialized
DEBUG - 2023-10-31 12:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 12:08:58 --> Input Class Initialized
INFO - 2023-10-31 12:08:58 --> Language Class Initialized
INFO - 2023-10-31 12:08:58 --> Loader Class Initialized
INFO - 2023-10-31 12:08:58 --> Helper loaded: url_helper
INFO - 2023-10-31 12:08:58 --> Helper loaded: form_helper
INFO - 2023-10-31 12:08:58 --> Helper loaded: file_helper
INFO - 2023-10-31 12:08:58 --> Database Driver Class Initialized
DEBUG - 2023-10-31 12:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 12:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 12:08:58 --> Form Validation Class Initialized
INFO - 2023-10-31 12:08:58 --> Upload Class Initialized
INFO - 2023-10-31 12:08:58 --> Model "M_auth" initialized
INFO - 2023-10-31 12:08:58 --> Model "M_user" initialized
INFO - 2023-10-31 12:08:58 --> Model "M_produk" initialized
INFO - 2023-10-31 12:08:58 --> Controller Class Initialized
INFO - 2023-10-31 12:08:58 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 12:08:58 --> Model "M_produk" initialized
DEBUG - 2023-10-31 12:08:58 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 12:08:58 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 12:08:58 --> Model "M_transaksi" initialized
INFO - 2023-10-31 12:08:58 --> Model "M_bank" initialized
INFO - 2023-10-31 12:08:58 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 12:08:58 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-31 12:08:58 --> Severity: error --> Exception: Too few arguments to function M_transaksi::calculateTotalSubTotal(), 0 passed in C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Home.php on line 551 and exactly 1 expected C:\xampp\htdocs\4_aan\semakar_adventure\application\models\M_transaksi.php 20
ERROR - 2023-10-31 12:08:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 12:08:59 --> Config Class Initialized
INFO - 2023-10-31 12:08:59 --> Hooks Class Initialized
DEBUG - 2023-10-31 12:08:59 --> UTF-8 Support Enabled
INFO - 2023-10-31 12:08:59 --> Utf8 Class Initialized
INFO - 2023-10-31 12:08:59 --> URI Class Initialized
INFO - 2023-10-31 12:08:59 --> Router Class Initialized
INFO - 2023-10-31 12:08:59 --> Output Class Initialized
INFO - 2023-10-31 12:08:59 --> Security Class Initialized
DEBUG - 2023-10-31 12:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 12:08:59 --> Input Class Initialized
INFO - 2023-10-31 12:08:59 --> Language Class Initialized
INFO - 2023-10-31 12:08:59 --> Loader Class Initialized
INFO - 2023-10-31 12:08:59 --> Helper loaded: url_helper
INFO - 2023-10-31 12:08:59 --> Helper loaded: form_helper
INFO - 2023-10-31 12:08:59 --> Helper loaded: file_helper
INFO - 2023-10-31 12:08:59 --> Database Driver Class Initialized
DEBUG - 2023-10-31 12:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 12:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 12:08:59 --> Form Validation Class Initialized
INFO - 2023-10-31 12:08:59 --> Upload Class Initialized
INFO - 2023-10-31 12:08:59 --> Model "M_auth" initialized
INFO - 2023-10-31 12:08:59 --> Model "M_user" initialized
INFO - 2023-10-31 12:08:59 --> Model "M_produk" initialized
INFO - 2023-10-31 12:08:59 --> Controller Class Initialized
INFO - 2023-10-31 12:08:59 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 12:08:59 --> Model "M_produk" initialized
DEBUG - 2023-10-31 12:08:59 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 12:08:59 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 12:08:59 --> Model "M_transaksi" initialized
INFO - 2023-10-31 12:08:59 --> Model "M_bank" initialized
INFO - 2023-10-31 12:08:59 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 12:08:59 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
ERROR - 2023-10-31 12:08:59 --> Severity: error --> Exception: Too few arguments to function M_transaksi::calculateTotalSubTotal(), 0 passed in C:\xampp\htdocs\4_aan\semakar_adventure\application\controllers\Home.php on line 551 and exactly 1 expected C:\xampp\htdocs\4_aan\semakar_adventure\application\models\M_transaksi.php 20
ERROR - 2023-10-31 12:09:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 12:09:02 --> Config Class Initialized
INFO - 2023-10-31 12:09:02 --> Hooks Class Initialized
DEBUG - 2023-10-31 12:09:02 --> UTF-8 Support Enabled
INFO - 2023-10-31 12:09:02 --> Utf8 Class Initialized
INFO - 2023-10-31 12:09:02 --> URI Class Initialized
INFO - 2023-10-31 12:09:02 --> Router Class Initialized
INFO - 2023-10-31 12:09:02 --> Output Class Initialized
INFO - 2023-10-31 12:09:02 --> Security Class Initialized
DEBUG - 2023-10-31 12:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 12:09:02 --> Input Class Initialized
INFO - 2023-10-31 12:09:02 --> Language Class Initialized
INFO - 2023-10-31 12:09:02 --> Loader Class Initialized
INFO - 2023-10-31 12:09:02 --> Helper loaded: url_helper
INFO - 2023-10-31 12:09:02 --> Helper loaded: form_helper
INFO - 2023-10-31 12:09:02 --> Helper loaded: file_helper
INFO - 2023-10-31 12:09:02 --> Database Driver Class Initialized
DEBUG - 2023-10-31 12:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 12:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 12:09:02 --> Form Validation Class Initialized
INFO - 2023-10-31 12:09:02 --> Upload Class Initialized
INFO - 2023-10-31 12:09:02 --> Model "M_auth" initialized
INFO - 2023-10-31 12:09:02 --> Model "M_user" initialized
INFO - 2023-10-31 12:09:02 --> Model "M_produk" initialized
INFO - 2023-10-31 12:09:02 --> Controller Class Initialized
INFO - 2023-10-31 12:09:02 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 12:09:02 --> Model "M_produk" initialized
DEBUG - 2023-10-31 12:09:02 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 12:09:02 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 12:09:02 --> Model "M_transaksi" initialized
INFO - 2023-10-31 12:09:02 --> Model "M_bank" initialized
INFO - 2023-10-31 12:09:02 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 12:09:02 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 12:09:03 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 12:09:03 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 12:09:03 --> Final output sent to browser
DEBUG - 2023-10-31 12:09:03 --> Total execution time: 0.6648
ERROR - 2023-10-31 12:09:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 12:09:12 --> Config Class Initialized
INFO - 2023-10-31 12:09:12 --> Hooks Class Initialized
DEBUG - 2023-10-31 12:09:12 --> UTF-8 Support Enabled
INFO - 2023-10-31 12:09:12 --> Utf8 Class Initialized
INFO - 2023-10-31 12:09:12 --> URI Class Initialized
INFO - 2023-10-31 12:09:12 --> Router Class Initialized
INFO - 2023-10-31 12:09:12 --> Output Class Initialized
INFO - 2023-10-31 12:09:12 --> Security Class Initialized
DEBUG - 2023-10-31 12:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 12:09:12 --> Input Class Initialized
INFO - 2023-10-31 12:09:12 --> Language Class Initialized
INFO - 2023-10-31 12:09:12 --> Loader Class Initialized
INFO - 2023-10-31 12:09:12 --> Helper loaded: url_helper
INFO - 2023-10-31 12:09:12 --> Helper loaded: form_helper
INFO - 2023-10-31 12:09:12 --> Helper loaded: file_helper
INFO - 2023-10-31 12:09:12 --> Database Driver Class Initialized
DEBUG - 2023-10-31 12:09:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 12:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 12:09:12 --> Form Validation Class Initialized
INFO - 2023-10-31 12:09:12 --> Upload Class Initialized
INFO - 2023-10-31 12:09:12 --> Model "M_auth" initialized
INFO - 2023-10-31 12:09:12 --> Model "M_user" initialized
INFO - 2023-10-31 12:09:12 --> Model "M_produk" initialized
INFO - 2023-10-31 12:09:12 --> Controller Class Initialized
INFO - 2023-10-31 12:09:12 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 12:09:12 --> Model "M_produk" initialized
DEBUG - 2023-10-31 12:09:12 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 12:09:12 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 12:09:12 --> Model "M_transaksi" initialized
INFO - 2023-10-31 12:09:12 --> Model "M_bank" initialized
INFO - 2023-10-31 12:09:12 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 12:09:12 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 12:09:13 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 12:09:13 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 12:09:13 --> Final output sent to browser
DEBUG - 2023-10-31 12:09:13 --> Total execution time: 0.4275
ERROR - 2023-10-31 12:10:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 12:10:23 --> Config Class Initialized
INFO - 2023-10-31 12:10:23 --> Hooks Class Initialized
DEBUG - 2023-10-31 12:10:23 --> UTF-8 Support Enabled
INFO - 2023-10-31 12:10:23 --> Utf8 Class Initialized
INFO - 2023-10-31 12:10:23 --> URI Class Initialized
INFO - 2023-10-31 12:10:23 --> Router Class Initialized
INFO - 2023-10-31 12:10:23 --> Output Class Initialized
INFO - 2023-10-31 12:10:23 --> Security Class Initialized
DEBUG - 2023-10-31 12:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 12:10:23 --> Input Class Initialized
INFO - 2023-10-31 12:10:23 --> Language Class Initialized
INFO - 2023-10-31 12:10:23 --> Loader Class Initialized
INFO - 2023-10-31 12:10:23 --> Helper loaded: url_helper
INFO - 2023-10-31 12:10:23 --> Helper loaded: form_helper
INFO - 2023-10-31 12:10:23 --> Helper loaded: file_helper
INFO - 2023-10-31 12:10:23 --> Database Driver Class Initialized
DEBUG - 2023-10-31 12:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 12:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 12:10:23 --> Form Validation Class Initialized
INFO - 2023-10-31 12:10:23 --> Upload Class Initialized
INFO - 2023-10-31 12:10:23 --> Model "M_auth" initialized
INFO - 2023-10-31 12:10:23 --> Model "M_user" initialized
INFO - 2023-10-31 12:10:23 --> Model "M_produk" initialized
INFO - 2023-10-31 12:10:23 --> Controller Class Initialized
INFO - 2023-10-31 12:10:23 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 12:10:23 --> Model "M_produk" initialized
DEBUG - 2023-10-31 12:10:23 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 12:10:23 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 12:10:23 --> Model "M_transaksi" initialized
INFO - 2023-10-31 12:10:23 --> Model "M_bank" initialized
INFO - 2023-10-31 12:10:23 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 12:10:23 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 12:10:24 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 12:10:24 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 12:10:24 --> Final output sent to browser
DEBUG - 2023-10-31 12:10:24 --> Total execution time: 0.4793
ERROR - 2023-10-31 12:10:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 12:10:33 --> Config Class Initialized
INFO - 2023-10-31 12:10:33 --> Hooks Class Initialized
DEBUG - 2023-10-31 12:10:33 --> UTF-8 Support Enabled
INFO - 2023-10-31 12:10:33 --> Utf8 Class Initialized
INFO - 2023-10-31 12:10:33 --> URI Class Initialized
INFO - 2023-10-31 12:10:33 --> Router Class Initialized
INFO - 2023-10-31 12:10:33 --> Output Class Initialized
INFO - 2023-10-31 12:10:33 --> Security Class Initialized
DEBUG - 2023-10-31 12:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 12:10:33 --> Input Class Initialized
INFO - 2023-10-31 12:10:33 --> Language Class Initialized
INFO - 2023-10-31 12:10:33 --> Loader Class Initialized
INFO - 2023-10-31 12:10:33 --> Helper loaded: url_helper
INFO - 2023-10-31 12:10:33 --> Helper loaded: form_helper
INFO - 2023-10-31 12:10:33 --> Helper loaded: file_helper
INFO - 2023-10-31 12:10:33 --> Database Driver Class Initialized
DEBUG - 2023-10-31 12:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 12:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 12:10:33 --> Form Validation Class Initialized
INFO - 2023-10-31 12:10:33 --> Upload Class Initialized
INFO - 2023-10-31 12:10:33 --> Model "M_auth" initialized
INFO - 2023-10-31 12:10:33 --> Model "M_user" initialized
INFO - 2023-10-31 12:10:33 --> Model "M_produk" initialized
INFO - 2023-10-31 12:10:33 --> Controller Class Initialized
INFO - 2023-10-31 12:10:33 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 12:10:33 --> Model "M_produk" initialized
DEBUG - 2023-10-31 12:10:33 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 12:10:33 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 12:10:33 --> Model "M_transaksi" initialized
INFO - 2023-10-31 12:10:33 --> Model "M_bank" initialized
INFO - 2023-10-31 12:10:33 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 12:10:33 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 12:10:33 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 12:10:33 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 12:10:33 --> Final output sent to browser
DEBUG - 2023-10-31 12:10:33 --> Total execution time: 0.4315
ERROR - 2023-10-31 12:13:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 12:13:23 --> Config Class Initialized
INFO - 2023-10-31 12:13:23 --> Hooks Class Initialized
DEBUG - 2023-10-31 12:13:23 --> UTF-8 Support Enabled
INFO - 2023-10-31 12:13:23 --> Utf8 Class Initialized
INFO - 2023-10-31 12:13:23 --> URI Class Initialized
INFO - 2023-10-31 12:13:23 --> Router Class Initialized
INFO - 2023-10-31 12:13:23 --> Output Class Initialized
INFO - 2023-10-31 12:13:23 --> Security Class Initialized
DEBUG - 2023-10-31 12:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 12:13:23 --> Input Class Initialized
INFO - 2023-10-31 12:13:23 --> Language Class Initialized
INFO - 2023-10-31 12:13:23 --> Loader Class Initialized
INFO - 2023-10-31 12:13:23 --> Helper loaded: url_helper
INFO - 2023-10-31 12:13:23 --> Helper loaded: form_helper
INFO - 2023-10-31 12:13:23 --> Helper loaded: file_helper
INFO - 2023-10-31 12:13:23 --> Database Driver Class Initialized
DEBUG - 2023-10-31 12:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 12:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 12:13:23 --> Form Validation Class Initialized
INFO - 2023-10-31 12:13:23 --> Upload Class Initialized
INFO - 2023-10-31 12:13:23 --> Model "M_auth" initialized
INFO - 2023-10-31 12:13:23 --> Model "M_user" initialized
INFO - 2023-10-31 12:13:23 --> Model "M_produk" initialized
INFO - 2023-10-31 12:13:23 --> Controller Class Initialized
INFO - 2023-10-31 12:13:23 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 12:13:23 --> Model "M_produk" initialized
DEBUG - 2023-10-31 12:13:23 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 12:13:23 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 12:13:23 --> Model "M_transaksi" initialized
INFO - 2023-10-31 12:13:23 --> Model "M_bank" initialized
INFO - 2023-10-31 12:13:23 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 12:13:23 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 12:13:23 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 12:13:23 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 12:13:23 --> Final output sent to browser
DEBUG - 2023-10-31 12:13:23 --> Total execution time: 0.4367
ERROR - 2023-10-31 12:15:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 12:15:37 --> Config Class Initialized
INFO - 2023-10-31 12:15:37 --> Hooks Class Initialized
DEBUG - 2023-10-31 12:15:37 --> UTF-8 Support Enabled
INFO - 2023-10-31 12:15:37 --> Utf8 Class Initialized
INFO - 2023-10-31 12:15:37 --> URI Class Initialized
INFO - 2023-10-31 12:15:37 --> Router Class Initialized
INFO - 2023-10-31 12:15:37 --> Output Class Initialized
INFO - 2023-10-31 12:15:37 --> Security Class Initialized
DEBUG - 2023-10-31 12:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 12:15:37 --> Input Class Initialized
INFO - 2023-10-31 12:15:37 --> Language Class Initialized
INFO - 2023-10-31 12:15:37 --> Loader Class Initialized
INFO - 2023-10-31 12:15:37 --> Helper loaded: url_helper
INFO - 2023-10-31 12:15:37 --> Helper loaded: form_helper
INFO - 2023-10-31 12:15:37 --> Helper loaded: file_helper
INFO - 2023-10-31 12:15:37 --> Database Driver Class Initialized
DEBUG - 2023-10-31 12:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 12:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 12:15:37 --> Form Validation Class Initialized
INFO - 2023-10-31 12:15:37 --> Upload Class Initialized
INFO - 2023-10-31 12:15:37 --> Model "M_auth" initialized
INFO - 2023-10-31 12:15:37 --> Model "M_user" initialized
INFO - 2023-10-31 12:15:37 --> Model "M_produk" initialized
INFO - 2023-10-31 12:15:37 --> Controller Class Initialized
INFO - 2023-10-31 12:15:37 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 12:15:37 --> Model "M_produk" initialized
DEBUG - 2023-10-31 12:15:37 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 12:15:37 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 12:15:37 --> Model "M_transaksi" initialized
INFO - 2023-10-31 12:15:37 --> Model "M_bank" initialized
INFO - 2023-10-31 12:15:37 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 12:15:37 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 12:15:37 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 12:15:37 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 12:15:37 --> Final output sent to browser
DEBUG - 2023-10-31 12:15:37 --> Total execution time: 0.4326
ERROR - 2023-10-31 12:15:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 12:15:45 --> Config Class Initialized
INFO - 2023-10-31 12:15:45 --> Hooks Class Initialized
DEBUG - 2023-10-31 12:15:45 --> UTF-8 Support Enabled
INFO - 2023-10-31 12:15:45 --> Utf8 Class Initialized
INFO - 2023-10-31 12:15:45 --> URI Class Initialized
INFO - 2023-10-31 12:15:45 --> Router Class Initialized
INFO - 2023-10-31 12:15:45 --> Output Class Initialized
INFO - 2023-10-31 12:15:45 --> Security Class Initialized
DEBUG - 2023-10-31 12:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 12:15:45 --> Input Class Initialized
INFO - 2023-10-31 12:15:45 --> Language Class Initialized
INFO - 2023-10-31 12:15:45 --> Loader Class Initialized
INFO - 2023-10-31 12:15:45 --> Helper loaded: url_helper
INFO - 2023-10-31 12:15:45 --> Helper loaded: form_helper
INFO - 2023-10-31 12:15:45 --> Helper loaded: file_helper
INFO - 2023-10-31 12:15:46 --> Database Driver Class Initialized
DEBUG - 2023-10-31 12:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 12:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 12:15:46 --> Form Validation Class Initialized
INFO - 2023-10-31 12:15:46 --> Upload Class Initialized
INFO - 2023-10-31 12:15:46 --> Model "M_auth" initialized
INFO - 2023-10-31 12:15:46 --> Model "M_user" initialized
INFO - 2023-10-31 12:15:46 --> Model "M_produk" initialized
INFO - 2023-10-31 12:15:46 --> Controller Class Initialized
INFO - 2023-10-31 12:15:46 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 12:15:46 --> Model "M_produk" initialized
DEBUG - 2023-10-31 12:15:46 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 12:15:46 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 12:15:46 --> Model "M_transaksi" initialized
INFO - 2023-10-31 12:15:46 --> Model "M_bank" initialized
INFO - 2023-10-31 12:15:46 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 12:15:46 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 12:15:46 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 12:15:46 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 12:15:46 --> Final output sent to browser
DEBUG - 2023-10-31 12:15:46 --> Total execution time: 0.4400
ERROR - 2023-10-31 12:15:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 12:15:50 --> Config Class Initialized
INFO - 2023-10-31 12:15:50 --> Hooks Class Initialized
DEBUG - 2023-10-31 12:15:50 --> UTF-8 Support Enabled
INFO - 2023-10-31 12:15:50 --> Utf8 Class Initialized
INFO - 2023-10-31 12:15:50 --> URI Class Initialized
INFO - 2023-10-31 12:15:50 --> Router Class Initialized
INFO - 2023-10-31 12:15:50 --> Output Class Initialized
INFO - 2023-10-31 12:15:50 --> Security Class Initialized
DEBUG - 2023-10-31 12:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 12:15:50 --> Input Class Initialized
INFO - 2023-10-31 12:15:50 --> Language Class Initialized
INFO - 2023-10-31 12:15:50 --> Loader Class Initialized
INFO - 2023-10-31 12:15:50 --> Helper loaded: url_helper
INFO - 2023-10-31 12:15:50 --> Helper loaded: form_helper
INFO - 2023-10-31 12:15:50 --> Helper loaded: file_helper
INFO - 2023-10-31 12:15:50 --> Database Driver Class Initialized
DEBUG - 2023-10-31 12:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 12:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 12:15:50 --> Form Validation Class Initialized
INFO - 2023-10-31 12:15:50 --> Upload Class Initialized
INFO - 2023-10-31 12:15:50 --> Model "M_auth" initialized
INFO - 2023-10-31 12:15:50 --> Model "M_user" initialized
INFO - 2023-10-31 12:15:50 --> Model "M_produk" initialized
INFO - 2023-10-31 12:15:50 --> Controller Class Initialized
INFO - 2023-10-31 12:15:50 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 12:15:50 --> Model "M_produk" initialized
DEBUG - 2023-10-31 12:15:50 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 12:15:50 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 12:15:50 --> Model "M_transaksi" initialized
INFO - 2023-10-31 12:15:50 --> Model "M_bank" initialized
INFO - 2023-10-31 12:15:50 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 12:15:50 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 12:15:50 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 12:15:50 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 12:15:50 --> Final output sent to browser
DEBUG - 2023-10-31 12:15:50 --> Total execution time: 0.3819
ERROR - 2023-10-31 12:16:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 12:16:01 --> Config Class Initialized
INFO - 2023-10-31 12:16:01 --> Hooks Class Initialized
DEBUG - 2023-10-31 12:16:01 --> UTF-8 Support Enabled
INFO - 2023-10-31 12:16:01 --> Utf8 Class Initialized
INFO - 2023-10-31 12:16:01 --> URI Class Initialized
INFO - 2023-10-31 12:16:01 --> Router Class Initialized
INFO - 2023-10-31 12:16:01 --> Output Class Initialized
INFO - 2023-10-31 12:16:01 --> Security Class Initialized
DEBUG - 2023-10-31 12:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 12:16:01 --> Input Class Initialized
INFO - 2023-10-31 12:16:01 --> Language Class Initialized
INFO - 2023-10-31 12:16:01 --> Loader Class Initialized
INFO - 2023-10-31 12:16:01 --> Helper loaded: url_helper
INFO - 2023-10-31 12:16:01 --> Helper loaded: form_helper
INFO - 2023-10-31 12:16:01 --> Helper loaded: file_helper
INFO - 2023-10-31 12:16:01 --> Database Driver Class Initialized
DEBUG - 2023-10-31 12:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 12:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 12:16:01 --> Form Validation Class Initialized
INFO - 2023-10-31 12:16:01 --> Upload Class Initialized
INFO - 2023-10-31 12:16:01 --> Model "M_auth" initialized
INFO - 2023-10-31 12:16:01 --> Model "M_user" initialized
INFO - 2023-10-31 12:16:01 --> Model "M_produk" initialized
INFO - 2023-10-31 12:16:01 --> Controller Class Initialized
INFO - 2023-10-31 12:16:01 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 12:16:01 --> Model "M_produk" initialized
DEBUG - 2023-10-31 12:16:01 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 12:16:01 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 12:16:01 --> Model "M_transaksi" initialized
INFO - 2023-10-31 12:16:01 --> Model "M_bank" initialized
INFO - 2023-10-31 12:16:01 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 12:16:01 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 12:16:02 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 12:16:02 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 12:16:02 --> Final output sent to browser
DEBUG - 2023-10-31 12:16:02 --> Total execution time: 0.3982
ERROR - 2023-10-31 12:16:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\4_aan\semakar_adventure\application\vendor/autoload.php was not found.
INFO - 2023-10-31 12:16:10 --> Config Class Initialized
INFO - 2023-10-31 12:16:10 --> Hooks Class Initialized
DEBUG - 2023-10-31 12:16:10 --> UTF-8 Support Enabled
INFO - 2023-10-31 12:16:10 --> Utf8 Class Initialized
INFO - 2023-10-31 12:16:10 --> URI Class Initialized
INFO - 2023-10-31 12:16:10 --> Router Class Initialized
INFO - 2023-10-31 12:16:10 --> Output Class Initialized
INFO - 2023-10-31 12:16:10 --> Security Class Initialized
DEBUG - 2023-10-31 12:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 12:16:10 --> Input Class Initialized
INFO - 2023-10-31 12:16:10 --> Language Class Initialized
INFO - 2023-10-31 12:16:10 --> Loader Class Initialized
INFO - 2023-10-31 12:16:10 --> Helper loaded: url_helper
INFO - 2023-10-31 12:16:10 --> Helper loaded: form_helper
INFO - 2023-10-31 12:16:10 --> Helper loaded: file_helper
INFO - 2023-10-31 12:16:10 --> Database Driver Class Initialized
DEBUG - 2023-10-31 12:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-31 12:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 12:16:10 --> Form Validation Class Initialized
INFO - 2023-10-31 12:16:10 --> Upload Class Initialized
INFO - 2023-10-31 12:16:10 --> Model "M_auth" initialized
INFO - 2023-10-31 12:16:10 --> Model "M_user" initialized
INFO - 2023-10-31 12:16:10 --> Model "M_produk" initialized
INFO - 2023-10-31 12:16:10 --> Controller Class Initialized
INFO - 2023-10-31 12:16:10 --> Model "M_pelanggan" initialized
INFO - 2023-10-31 12:16:10 --> Model "M_produk" initialized
DEBUG - 2023-10-31 12:16:10 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 12:16:10 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-10-31 12:16:10 --> Model "M_transaksi" initialized
INFO - 2023-10-31 12:16:10 --> Model "M_bank" initialized
INFO - 2023-10-31 12:16:10 --> Model "M_pesan" initialized
DEBUG - 2023-10-31 12:16:10 --> Config file loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\config/midtrans.php
INFO - 2023-10-31 12:16:10 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-10-31 12:16:10 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-10-31 12:16:10 --> Final output sent to browser
DEBUG - 2023-10-31 12:16:10 --> Total execution time: 0.5315
