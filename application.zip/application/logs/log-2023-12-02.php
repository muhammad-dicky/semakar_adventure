<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-02 00:37:19 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-02 00:37:19 --> Config Class Initialized
INFO - 2023-12-02 00:37:19 --> Hooks Class Initialized
DEBUG - 2023-12-02 00:37:19 --> UTF-8 Support Enabled
INFO - 2023-12-02 00:37:19 --> Utf8 Class Initialized
INFO - 2023-12-02 00:37:19 --> URI Class Initialized
DEBUG - 2023-12-02 00:37:19 --> No URI present. Default controller set.
INFO - 2023-12-02 00:37:19 --> Router Class Initialized
INFO - 2023-12-02 00:37:19 --> Output Class Initialized
INFO - 2023-12-02 00:37:19 --> Security Class Initialized
DEBUG - 2023-12-02 00:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-02 00:37:19 --> Input Class Initialized
INFO - 2023-12-02 00:37:19 --> Language Class Initialized
INFO - 2023-12-02 00:37:19 --> Loader Class Initialized
INFO - 2023-12-02 00:37:19 --> Helper loaded: url_helper
INFO - 2023-12-02 00:37:19 --> Helper loaded: form_helper
INFO - 2023-12-02 00:37:19 --> Helper loaded: file_helper
INFO - 2023-12-02 00:37:19 --> Database Driver Class Initialized
DEBUG - 2023-12-02 00:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-02 00:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-02 00:37:19 --> Form Validation Class Initialized
INFO - 2023-12-02 00:37:19 --> Upload Class Initialized
INFO - 2023-12-02 00:37:19 --> Model "M_auth" initialized
INFO - 2023-12-02 00:37:19 --> Model "M_user" initialized
INFO - 2023-12-02 00:37:19 --> Model "M_produk" initialized
INFO - 2023-12-02 00:37:19 --> Controller Class Initialized
INFO - 2023-12-02 00:37:19 --> Model "M_pelanggan" initialized
INFO - 2023-12-02 00:37:19 --> Model "M_produk" initialized
DEBUG - 2023-12-02 00:37:19 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-02 00:37:19 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-02 00:37:19 --> Model "M_transaksi" initialized
INFO - 2023-12-02 00:37:19 --> Model "M_bank" initialized
INFO - 2023-12-02 00:37:19 --> Model "M_pesan" initialized
DEBUG - 2023-12-02 00:37:19 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-02 00:37:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-02 00:37:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-02 00:37:19 --> Final output sent to browser
DEBUG - 2023-12-02 00:37:19 --> Total execution time: 0.0333
ERROR - 2023-12-02 03:01:27 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-02 03:01:27 --> Config Class Initialized
INFO - 2023-12-02 03:01:27 --> Hooks Class Initialized
DEBUG - 2023-12-02 03:01:27 --> UTF-8 Support Enabled
INFO - 2023-12-02 03:01:27 --> Utf8 Class Initialized
INFO - 2023-12-02 03:01:27 --> URI Class Initialized
DEBUG - 2023-12-02 03:01:27 --> No URI present. Default controller set.
INFO - 2023-12-02 03:01:27 --> Router Class Initialized
INFO - 2023-12-02 03:01:27 --> Output Class Initialized
INFO - 2023-12-02 03:01:27 --> Security Class Initialized
DEBUG - 2023-12-02 03:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-02 03:01:27 --> Input Class Initialized
INFO - 2023-12-02 03:01:27 --> Language Class Initialized
INFO - 2023-12-02 03:01:27 --> Loader Class Initialized
INFO - 2023-12-02 03:01:27 --> Helper loaded: url_helper
INFO - 2023-12-02 03:01:27 --> Helper loaded: form_helper
INFO - 2023-12-02 03:01:27 --> Helper loaded: file_helper
INFO - 2023-12-02 03:01:27 --> Database Driver Class Initialized
DEBUG - 2023-12-02 03:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-02 03:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-02 03:01:27 --> Form Validation Class Initialized
INFO - 2023-12-02 03:01:27 --> Upload Class Initialized
INFO - 2023-12-02 03:01:27 --> Model "M_auth" initialized
INFO - 2023-12-02 03:01:27 --> Model "M_user" initialized
INFO - 2023-12-02 03:01:27 --> Model "M_produk" initialized
INFO - 2023-12-02 03:01:27 --> Controller Class Initialized
INFO - 2023-12-02 03:01:27 --> Model "M_pelanggan" initialized
INFO - 2023-12-02 03:01:27 --> Model "M_produk" initialized
DEBUG - 2023-12-02 03:01:27 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-02 03:01:27 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-02 03:01:27 --> Model "M_transaksi" initialized
INFO - 2023-12-02 03:01:27 --> Model "M_bank" initialized
INFO - 2023-12-02 03:01:27 --> Model "M_pesan" initialized
DEBUG - 2023-12-02 03:01:27 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-02 03:01:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-02 03:01:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-02 03:01:27 --> Final output sent to browser
DEBUG - 2023-12-02 03:01:27 --> Total execution time: 0.0364
ERROR - 2023-12-02 04:25:36 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-02 04:25:36 --> Config Class Initialized
INFO - 2023-12-02 04:25:36 --> Hooks Class Initialized
DEBUG - 2023-12-02 04:25:36 --> UTF-8 Support Enabled
INFO - 2023-12-02 04:25:36 --> Utf8 Class Initialized
INFO - 2023-12-02 04:25:36 --> URI Class Initialized
DEBUG - 2023-12-02 04:25:36 --> No URI present. Default controller set.
INFO - 2023-12-02 04:25:36 --> Router Class Initialized
INFO - 2023-12-02 04:25:36 --> Output Class Initialized
INFO - 2023-12-02 04:25:36 --> Security Class Initialized
DEBUG - 2023-12-02 04:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-02 04:25:36 --> Input Class Initialized
INFO - 2023-12-02 04:25:36 --> Language Class Initialized
INFO - 2023-12-02 04:25:36 --> Loader Class Initialized
INFO - 2023-12-02 04:25:36 --> Helper loaded: url_helper
INFO - 2023-12-02 04:25:36 --> Helper loaded: form_helper
INFO - 2023-12-02 04:25:36 --> Helper loaded: file_helper
INFO - 2023-12-02 04:25:36 --> Database Driver Class Initialized
DEBUG - 2023-12-02 04:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-02 04:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-02 04:25:36 --> Form Validation Class Initialized
INFO - 2023-12-02 04:25:36 --> Upload Class Initialized
INFO - 2023-12-02 04:25:36 --> Model "M_auth" initialized
INFO - 2023-12-02 04:25:36 --> Model "M_user" initialized
INFO - 2023-12-02 04:25:36 --> Model "M_produk" initialized
INFO - 2023-12-02 04:25:36 --> Controller Class Initialized
INFO - 2023-12-02 04:25:36 --> Model "M_pelanggan" initialized
INFO - 2023-12-02 04:25:36 --> Model "M_produk" initialized
DEBUG - 2023-12-02 04:25:36 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-02 04:25:36 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-02 04:25:36 --> Model "M_transaksi" initialized
INFO - 2023-12-02 04:25:36 --> Model "M_bank" initialized
INFO - 2023-12-02 04:25:36 --> Model "M_pesan" initialized
DEBUG - 2023-12-02 04:25:36 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-02 04:25:36 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-02 04:25:36 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-02 04:25:36 --> Final output sent to browser
DEBUG - 2023-12-02 04:25:36 --> Total execution time: 0.0333
ERROR - 2023-12-02 06:34:09 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-02 06:34:09 --> Config Class Initialized
INFO - 2023-12-02 06:34:09 --> Hooks Class Initialized
DEBUG - 2023-12-02 06:34:09 --> UTF-8 Support Enabled
INFO - 2023-12-02 06:34:09 --> Utf8 Class Initialized
INFO - 2023-12-02 06:34:09 --> URI Class Initialized
DEBUG - 2023-12-02 06:34:09 --> No URI present. Default controller set.
INFO - 2023-12-02 06:34:09 --> Router Class Initialized
INFO - 2023-12-02 06:34:09 --> Output Class Initialized
INFO - 2023-12-02 06:34:09 --> Security Class Initialized
DEBUG - 2023-12-02 06:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-02 06:34:09 --> Input Class Initialized
INFO - 2023-12-02 06:34:09 --> Language Class Initialized
INFO - 2023-12-02 06:34:09 --> Loader Class Initialized
INFO - 2023-12-02 06:34:09 --> Helper loaded: url_helper
INFO - 2023-12-02 06:34:09 --> Helper loaded: form_helper
INFO - 2023-12-02 06:34:09 --> Helper loaded: file_helper
INFO - 2023-12-02 06:34:09 --> Database Driver Class Initialized
DEBUG - 2023-12-02 06:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-02 06:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-02 06:34:09 --> Form Validation Class Initialized
INFO - 2023-12-02 06:34:09 --> Upload Class Initialized
INFO - 2023-12-02 06:34:09 --> Model "M_auth" initialized
INFO - 2023-12-02 06:34:09 --> Model "M_user" initialized
INFO - 2023-12-02 06:34:09 --> Model "M_produk" initialized
INFO - 2023-12-02 06:34:09 --> Controller Class Initialized
INFO - 2023-12-02 06:34:09 --> Model "M_pelanggan" initialized
INFO - 2023-12-02 06:34:09 --> Model "M_produk" initialized
DEBUG - 2023-12-02 06:34:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-02 06:34:09 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-02 06:34:09 --> Model "M_transaksi" initialized
INFO - 2023-12-02 06:34:09 --> Model "M_bank" initialized
INFO - 2023-12-02 06:34:09 --> Model "M_pesan" initialized
DEBUG - 2023-12-02 06:34:09 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-02 06:34:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-02 06:34:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-02 06:34:09 --> Final output sent to browser
DEBUG - 2023-12-02 06:34:09 --> Total execution time: 0.0455
ERROR - 2023-12-02 07:24:58 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-02 07:24:58 --> Config Class Initialized
INFO - 2023-12-02 07:24:58 --> Hooks Class Initialized
DEBUG - 2023-12-02 07:24:58 --> UTF-8 Support Enabled
INFO - 2023-12-02 07:24:58 --> Utf8 Class Initialized
INFO - 2023-12-02 07:24:58 --> URI Class Initialized
DEBUG - 2023-12-02 07:24:58 --> No URI present. Default controller set.
INFO - 2023-12-02 07:24:58 --> Router Class Initialized
INFO - 2023-12-02 07:24:58 --> Output Class Initialized
INFO - 2023-12-02 07:24:58 --> Security Class Initialized
DEBUG - 2023-12-02 07:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-02 07:24:58 --> Input Class Initialized
INFO - 2023-12-02 07:24:58 --> Language Class Initialized
INFO - 2023-12-02 07:24:58 --> Loader Class Initialized
INFO - 2023-12-02 07:24:58 --> Helper loaded: url_helper
INFO - 2023-12-02 07:24:58 --> Helper loaded: form_helper
INFO - 2023-12-02 07:24:58 --> Helper loaded: file_helper
INFO - 2023-12-02 07:24:58 --> Database Driver Class Initialized
DEBUG - 2023-12-02 07:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-02 07:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-02 07:24:58 --> Form Validation Class Initialized
INFO - 2023-12-02 07:24:58 --> Upload Class Initialized
INFO - 2023-12-02 07:24:58 --> Model "M_auth" initialized
INFO - 2023-12-02 07:24:58 --> Model "M_user" initialized
INFO - 2023-12-02 07:24:58 --> Model "M_produk" initialized
INFO - 2023-12-02 07:24:58 --> Controller Class Initialized
INFO - 2023-12-02 07:24:58 --> Model "M_pelanggan" initialized
INFO - 2023-12-02 07:24:58 --> Model "M_produk" initialized
DEBUG - 2023-12-02 07:24:58 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-02 07:24:58 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-02 07:24:58 --> Model "M_transaksi" initialized
INFO - 2023-12-02 07:24:58 --> Model "M_bank" initialized
INFO - 2023-12-02 07:24:58 --> Model "M_pesan" initialized
DEBUG - 2023-12-02 07:24:58 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-02 07:24:58 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-02 07:24:58 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-02 07:24:58 --> Final output sent to browser
DEBUG - 2023-12-02 07:24:58 --> Total execution time: 0.0345
ERROR - 2023-12-02 07:49:17 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-02 07:49:17 --> Config Class Initialized
INFO - 2023-12-02 07:49:17 --> Hooks Class Initialized
DEBUG - 2023-12-02 07:49:17 --> UTF-8 Support Enabled
INFO - 2023-12-02 07:49:17 --> Utf8 Class Initialized
INFO - 2023-12-02 07:49:17 --> URI Class Initialized
DEBUG - 2023-12-02 07:49:17 --> No URI present. Default controller set.
INFO - 2023-12-02 07:49:17 --> Router Class Initialized
INFO - 2023-12-02 07:49:17 --> Output Class Initialized
INFO - 2023-12-02 07:49:17 --> Security Class Initialized
DEBUG - 2023-12-02 07:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-02 07:49:17 --> Input Class Initialized
INFO - 2023-12-02 07:49:17 --> Language Class Initialized
INFO - 2023-12-02 07:49:17 --> Loader Class Initialized
INFO - 2023-12-02 07:49:17 --> Helper loaded: url_helper
INFO - 2023-12-02 07:49:17 --> Helper loaded: form_helper
INFO - 2023-12-02 07:49:17 --> Helper loaded: file_helper
INFO - 2023-12-02 07:49:17 --> Database Driver Class Initialized
DEBUG - 2023-12-02 07:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-02 07:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-02 07:49:17 --> Form Validation Class Initialized
INFO - 2023-12-02 07:49:17 --> Upload Class Initialized
INFO - 2023-12-02 07:49:17 --> Model "M_auth" initialized
INFO - 2023-12-02 07:49:17 --> Model "M_user" initialized
INFO - 2023-12-02 07:49:17 --> Model "M_produk" initialized
INFO - 2023-12-02 07:49:17 --> Controller Class Initialized
INFO - 2023-12-02 07:49:17 --> Model "M_pelanggan" initialized
INFO - 2023-12-02 07:49:17 --> Model "M_produk" initialized
DEBUG - 2023-12-02 07:49:17 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-02 07:49:17 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-02 07:49:17 --> Model "M_transaksi" initialized
INFO - 2023-12-02 07:49:17 --> Model "M_bank" initialized
INFO - 2023-12-02 07:49:17 --> Model "M_pesan" initialized
DEBUG - 2023-12-02 07:49:17 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-02 07:49:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-02 07:49:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-02 07:49:17 --> Final output sent to browser
DEBUG - 2023-12-02 07:49:17 --> Total execution time: 0.0321
ERROR - 2023-12-02 11:07:07 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-02 11:07:07 --> Config Class Initialized
INFO - 2023-12-02 11:07:07 --> Hooks Class Initialized
DEBUG - 2023-12-02 11:07:07 --> UTF-8 Support Enabled
INFO - 2023-12-02 11:07:07 --> Utf8 Class Initialized
INFO - 2023-12-02 11:07:07 --> URI Class Initialized
DEBUG - 2023-12-02 11:07:07 --> No URI present. Default controller set.
INFO - 2023-12-02 11:07:07 --> Router Class Initialized
INFO - 2023-12-02 11:07:07 --> Output Class Initialized
INFO - 2023-12-02 11:07:07 --> Security Class Initialized
DEBUG - 2023-12-02 11:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-02 11:07:07 --> Input Class Initialized
INFO - 2023-12-02 11:07:07 --> Language Class Initialized
INFO - 2023-12-02 11:07:07 --> Loader Class Initialized
INFO - 2023-12-02 11:07:07 --> Helper loaded: url_helper
INFO - 2023-12-02 11:07:07 --> Helper loaded: form_helper
INFO - 2023-12-02 11:07:07 --> Helper loaded: file_helper
INFO - 2023-12-02 11:07:07 --> Database Driver Class Initialized
DEBUG - 2023-12-02 11:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-02 11:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-02 11:07:07 --> Form Validation Class Initialized
INFO - 2023-12-02 11:07:07 --> Upload Class Initialized
INFO - 2023-12-02 11:07:07 --> Model "M_auth" initialized
INFO - 2023-12-02 11:07:07 --> Model "M_user" initialized
INFO - 2023-12-02 11:07:07 --> Model "M_produk" initialized
INFO - 2023-12-02 11:07:07 --> Controller Class Initialized
INFO - 2023-12-02 11:07:07 --> Model "M_pelanggan" initialized
INFO - 2023-12-02 11:07:07 --> Model "M_produk" initialized
DEBUG - 2023-12-02 11:07:07 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-02 11:07:07 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-02 11:07:07 --> Model "M_transaksi" initialized
INFO - 2023-12-02 11:07:07 --> Model "M_bank" initialized
INFO - 2023-12-02 11:07:07 --> Model "M_pesan" initialized
DEBUG - 2023-12-02 11:07:07 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-02 11:07:07 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-02 11:07:07 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-02 11:07:07 --> Final output sent to browser
DEBUG - 2023-12-02 11:07:07 --> Total execution time: 0.0368
ERROR - 2023-12-02 11:11:32 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-02 11:11:32 --> Config Class Initialized
INFO - 2023-12-02 11:11:32 --> Hooks Class Initialized
DEBUG - 2023-12-02 11:11:32 --> UTF-8 Support Enabled
INFO - 2023-12-02 11:11:32 --> Utf8 Class Initialized
INFO - 2023-12-02 11:11:32 --> URI Class Initialized
INFO - 2023-12-02 11:11:32 --> Router Class Initialized
INFO - 2023-12-02 11:11:32 --> Output Class Initialized
INFO - 2023-12-02 11:11:32 --> Security Class Initialized
DEBUG - 2023-12-02 11:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-02 11:11:32 --> Input Class Initialized
INFO - 2023-12-02 11:11:32 --> Language Class Initialized
INFO - 2023-12-02 11:11:32 --> Loader Class Initialized
INFO - 2023-12-02 11:11:32 --> Helper loaded: url_helper
INFO - 2023-12-02 11:11:32 --> Helper loaded: form_helper
INFO - 2023-12-02 11:11:32 --> Helper loaded: file_helper
INFO - 2023-12-02 11:11:32 --> Database Driver Class Initialized
DEBUG - 2023-12-02 11:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-02 11:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-02 11:11:32 --> Form Validation Class Initialized
INFO - 2023-12-02 11:11:32 --> Upload Class Initialized
INFO - 2023-12-02 11:11:32 --> Model "M_auth" initialized
INFO - 2023-12-02 11:11:32 --> Model "M_user" initialized
INFO - 2023-12-02 11:11:32 --> Model "M_produk" initialized
INFO - 2023-12-02 11:11:32 --> Controller Class Initialized
INFO - 2023-12-02 11:11:32 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-02 11:11:32 --> Final output sent to browser
DEBUG - 2023-12-02 11:11:32 --> Total execution time: 0.0033
ERROR - 2023-12-02 14:08:52 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-02 14:08:52 --> Config Class Initialized
INFO - 2023-12-02 14:08:52 --> Hooks Class Initialized
DEBUG - 2023-12-02 14:08:52 --> UTF-8 Support Enabled
INFO - 2023-12-02 14:08:52 --> Utf8 Class Initialized
INFO - 2023-12-02 14:08:52 --> URI Class Initialized
DEBUG - 2023-12-02 14:08:52 --> No URI present. Default controller set.
INFO - 2023-12-02 14:08:52 --> Router Class Initialized
INFO - 2023-12-02 14:08:52 --> Output Class Initialized
INFO - 2023-12-02 14:08:52 --> Security Class Initialized
DEBUG - 2023-12-02 14:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-02 14:08:52 --> Input Class Initialized
INFO - 2023-12-02 14:08:52 --> Language Class Initialized
INFO - 2023-12-02 14:08:52 --> Loader Class Initialized
INFO - 2023-12-02 14:08:52 --> Helper loaded: url_helper
INFO - 2023-12-02 14:08:52 --> Helper loaded: form_helper
INFO - 2023-12-02 14:08:52 --> Helper loaded: file_helper
INFO - 2023-12-02 14:08:52 --> Database Driver Class Initialized
DEBUG - 2023-12-02 14:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-02 14:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-02 14:08:52 --> Form Validation Class Initialized
INFO - 2023-12-02 14:08:52 --> Upload Class Initialized
INFO - 2023-12-02 14:08:52 --> Model "M_auth" initialized
INFO - 2023-12-02 14:08:52 --> Model "M_user" initialized
INFO - 2023-12-02 14:08:52 --> Model "M_produk" initialized
INFO - 2023-12-02 14:08:52 --> Controller Class Initialized
INFO - 2023-12-02 14:08:52 --> Model "M_pelanggan" initialized
INFO - 2023-12-02 14:08:52 --> Model "M_produk" initialized
DEBUG - 2023-12-02 14:08:52 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-02 14:08:52 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-02 14:08:52 --> Model "M_transaksi" initialized
INFO - 2023-12-02 14:08:52 --> Model "M_bank" initialized
INFO - 2023-12-02 14:08:52 --> Model "M_pesan" initialized
DEBUG - 2023-12-02 14:08:52 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-02 14:08:52 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-02 14:08:52 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-02 14:08:52 --> Final output sent to browser
DEBUG - 2023-12-02 14:08:52 --> Total execution time: 0.0320
ERROR - 2023-12-02 14:08:54 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-02 14:08:54 --> Config Class Initialized
INFO - 2023-12-02 14:08:54 --> Hooks Class Initialized
DEBUG - 2023-12-02 14:08:54 --> UTF-8 Support Enabled
INFO - 2023-12-02 14:08:54 --> Utf8 Class Initialized
INFO - 2023-12-02 14:08:54 --> URI Class Initialized
INFO - 2023-12-02 14:08:54 --> Router Class Initialized
INFO - 2023-12-02 14:08:54 --> Output Class Initialized
INFO - 2023-12-02 14:08:54 --> Security Class Initialized
DEBUG - 2023-12-02 14:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-02 14:08:54 --> Input Class Initialized
INFO - 2023-12-02 14:08:54 --> Language Class Initialized
INFO - 2023-12-02 14:08:54 --> Loader Class Initialized
INFO - 2023-12-02 14:08:54 --> Helper loaded: url_helper
INFO - 2023-12-02 14:08:54 --> Helper loaded: form_helper
INFO - 2023-12-02 14:08:54 --> Helper loaded: file_helper
INFO - 2023-12-02 14:08:54 --> Database Driver Class Initialized
DEBUG - 2023-12-02 14:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-02 14:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-02 14:08:54 --> Form Validation Class Initialized
INFO - 2023-12-02 14:08:54 --> Upload Class Initialized
INFO - 2023-12-02 14:08:54 --> Model "M_auth" initialized
INFO - 2023-12-02 14:08:54 --> Model "M_user" initialized
INFO - 2023-12-02 14:08:54 --> Model "M_produk" initialized
INFO - 2023-12-02 14:08:54 --> Controller Class Initialized
INFO - 2023-12-02 14:08:54 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-02 14:08:54 --> Final output sent to browser
DEBUG - 2023-12-02 14:08:54 --> Total execution time: 0.0025
ERROR - 2023-12-02 14:08:54 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-02 14:08:54 --> Config Class Initialized
INFO - 2023-12-02 14:08:54 --> Hooks Class Initialized
DEBUG - 2023-12-02 14:08:54 --> UTF-8 Support Enabled
INFO - 2023-12-02 14:08:54 --> Utf8 Class Initialized
INFO - 2023-12-02 14:08:54 --> URI Class Initialized
INFO - 2023-12-02 14:08:54 --> Router Class Initialized
INFO - 2023-12-02 14:08:54 --> Output Class Initialized
INFO - 2023-12-02 14:08:54 --> Security Class Initialized
DEBUG - 2023-12-02 14:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-02 14:08:54 --> Input Class Initialized
INFO - 2023-12-02 14:08:54 --> Language Class Initialized
INFO - 2023-12-02 14:08:54 --> Loader Class Initialized
INFO - 2023-12-02 14:08:54 --> Helper loaded: url_helper
INFO - 2023-12-02 14:08:54 --> Helper loaded: form_helper
INFO - 2023-12-02 14:08:54 --> Helper loaded: file_helper
INFO - 2023-12-02 14:08:54 --> Database Driver Class Initialized
DEBUG - 2023-12-02 14:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-02 14:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-02 14:08:54 --> Form Validation Class Initialized
INFO - 2023-12-02 14:08:54 --> Upload Class Initialized
INFO - 2023-12-02 14:08:54 --> Model "M_auth" initialized
INFO - 2023-12-02 14:08:54 --> Model "M_user" initialized
INFO - 2023-12-02 14:08:54 --> Model "M_produk" initialized
INFO - 2023-12-02 14:08:54 --> Controller Class Initialized
INFO - 2023-12-02 14:08:54 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-12-02 14:08:54 --> Final output sent to browser
DEBUG - 2023-12-02 14:08:54 --> Total execution time: 0.0021
ERROR - 2023-12-02 14:08:54 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-02 14:08:54 --> Config Class Initialized
INFO - 2023-12-02 14:08:54 --> Hooks Class Initialized
DEBUG - 2023-12-02 14:08:54 --> UTF-8 Support Enabled
INFO - 2023-12-02 14:08:54 --> Utf8 Class Initialized
INFO - 2023-12-02 14:08:54 --> URI Class Initialized
DEBUG - 2023-12-02 14:08:54 --> No URI present. Default controller set.
INFO - 2023-12-02 14:08:54 --> Router Class Initialized
INFO - 2023-12-02 14:08:54 --> Output Class Initialized
INFO - 2023-12-02 14:08:54 --> Security Class Initialized
DEBUG - 2023-12-02 14:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-02 14:08:54 --> Input Class Initialized
INFO - 2023-12-02 14:08:54 --> Language Class Initialized
INFO - 2023-12-02 14:08:54 --> Loader Class Initialized
INFO - 2023-12-02 14:08:54 --> Helper loaded: url_helper
INFO - 2023-12-02 14:08:54 --> Helper loaded: form_helper
INFO - 2023-12-02 14:08:54 --> Helper loaded: file_helper
INFO - 2023-12-02 14:08:54 --> Database Driver Class Initialized
DEBUG - 2023-12-02 14:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-02 14:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-02 14:08:54 --> Form Validation Class Initialized
INFO - 2023-12-02 14:08:54 --> Upload Class Initialized
INFO - 2023-12-02 14:08:54 --> Model "M_auth" initialized
INFO - 2023-12-02 14:08:54 --> Model "M_user" initialized
INFO - 2023-12-02 14:08:54 --> Model "M_produk" initialized
INFO - 2023-12-02 14:08:54 --> Controller Class Initialized
INFO - 2023-12-02 14:08:54 --> Model "M_pelanggan" initialized
INFO - 2023-12-02 14:08:54 --> Model "M_produk" initialized
DEBUG - 2023-12-02 14:08:54 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-02 14:08:54 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-02 14:08:54 --> Model "M_transaksi" initialized
INFO - 2023-12-02 14:08:54 --> Model "M_bank" initialized
INFO - 2023-12-02 14:08:54 --> Model "M_pesan" initialized
DEBUG - 2023-12-02 14:08:54 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-02 14:08:54 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-02 14:08:54 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-02 14:08:54 --> Final output sent to browser
DEBUG - 2023-12-02 14:08:54 --> Total execution time: 0.0033
ERROR - 2023-12-02 14:08:59 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-02 14:08:59 --> Config Class Initialized
INFO - 2023-12-02 14:08:59 --> Hooks Class Initialized
DEBUG - 2023-12-02 14:08:59 --> UTF-8 Support Enabled
INFO - 2023-12-02 14:08:59 --> Utf8 Class Initialized
INFO - 2023-12-02 14:08:59 --> URI Class Initialized
DEBUG - 2023-12-02 14:08:59 --> No URI present. Default controller set.
INFO - 2023-12-02 14:08:59 --> Router Class Initialized
INFO - 2023-12-02 14:08:59 --> Output Class Initialized
INFO - 2023-12-02 14:08:59 --> Security Class Initialized
DEBUG - 2023-12-02 14:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-02 14:08:59 --> Input Class Initialized
INFO - 2023-12-02 14:08:59 --> Language Class Initialized
INFO - 2023-12-02 14:08:59 --> Loader Class Initialized
INFO - 2023-12-02 14:08:59 --> Helper loaded: url_helper
INFO - 2023-12-02 14:08:59 --> Helper loaded: form_helper
INFO - 2023-12-02 14:08:59 --> Helper loaded: file_helper
INFO - 2023-12-02 14:08:59 --> Database Driver Class Initialized
DEBUG - 2023-12-02 14:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-02 14:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-02 14:08:59 --> Form Validation Class Initialized
INFO - 2023-12-02 14:08:59 --> Upload Class Initialized
INFO - 2023-12-02 14:08:59 --> Model "M_auth" initialized
INFO - 2023-12-02 14:08:59 --> Model "M_user" initialized
INFO - 2023-12-02 14:08:59 --> Model "M_produk" initialized
INFO - 2023-12-02 14:08:59 --> Controller Class Initialized
INFO - 2023-12-02 14:08:59 --> Model "M_pelanggan" initialized
INFO - 2023-12-02 14:08:59 --> Model "M_produk" initialized
DEBUG - 2023-12-02 14:08:59 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-02 14:08:59 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-02 14:08:59 --> Model "M_transaksi" initialized
INFO - 2023-12-02 14:08:59 --> Model "M_bank" initialized
INFO - 2023-12-02 14:08:59 --> Model "M_pesan" initialized
DEBUG - 2023-12-02 14:08:59 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-02 14:08:59 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-02 14:08:59 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-02 14:08:59 --> Final output sent to browser
DEBUG - 2023-12-02 14:08:59 --> Total execution time: 0.0030
ERROR - 2023-12-02 14:17:48 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-02 14:17:48 --> Config Class Initialized
INFO - 2023-12-02 14:17:48 --> Hooks Class Initialized
DEBUG - 2023-12-02 14:17:48 --> UTF-8 Support Enabled
INFO - 2023-12-02 14:17:48 --> Utf8 Class Initialized
INFO - 2023-12-02 14:17:48 --> URI Class Initialized
DEBUG - 2023-12-02 14:17:48 --> No URI present. Default controller set.
INFO - 2023-12-02 14:17:48 --> Router Class Initialized
INFO - 2023-12-02 14:17:48 --> Output Class Initialized
INFO - 2023-12-02 14:17:48 --> Security Class Initialized
DEBUG - 2023-12-02 14:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-02 14:17:48 --> Input Class Initialized
INFO - 2023-12-02 14:17:48 --> Language Class Initialized
INFO - 2023-12-02 14:17:48 --> Loader Class Initialized
INFO - 2023-12-02 14:17:48 --> Helper loaded: url_helper
INFO - 2023-12-02 14:17:48 --> Helper loaded: form_helper
INFO - 2023-12-02 14:17:48 --> Helper loaded: file_helper
INFO - 2023-12-02 14:17:48 --> Database Driver Class Initialized
DEBUG - 2023-12-02 14:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-02 14:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-02 14:17:48 --> Form Validation Class Initialized
INFO - 2023-12-02 14:17:48 --> Upload Class Initialized
INFO - 2023-12-02 14:17:48 --> Model "M_auth" initialized
INFO - 2023-12-02 14:17:48 --> Model "M_user" initialized
INFO - 2023-12-02 14:17:48 --> Model "M_produk" initialized
INFO - 2023-12-02 14:17:48 --> Controller Class Initialized
INFO - 2023-12-02 14:17:48 --> Model "M_pelanggan" initialized
INFO - 2023-12-02 14:17:48 --> Model "M_produk" initialized
DEBUG - 2023-12-02 14:17:48 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-02 14:17:48 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-02 14:17:48 --> Model "M_transaksi" initialized
INFO - 2023-12-02 14:17:48 --> Model "M_bank" initialized
INFO - 2023-12-02 14:17:48 --> Model "M_pesan" initialized
DEBUG - 2023-12-02 14:17:48 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-02 14:17:48 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-02 14:17:48 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-02 14:17:48 --> Final output sent to browser
DEBUG - 2023-12-02 14:17:48 --> Total execution time: 0.0385
ERROR - 2023-12-02 14:18:23 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-02 14:18:23 --> Config Class Initialized
INFO - 2023-12-02 14:18:23 --> Hooks Class Initialized
DEBUG - 2023-12-02 14:18:23 --> UTF-8 Support Enabled
INFO - 2023-12-02 14:18:23 --> Utf8 Class Initialized
INFO - 2023-12-02 14:18:23 --> URI Class Initialized
DEBUG - 2023-12-02 14:18:23 --> No URI present. Default controller set.
INFO - 2023-12-02 14:18:23 --> Router Class Initialized
INFO - 2023-12-02 14:18:23 --> Output Class Initialized
INFO - 2023-12-02 14:18:23 --> Security Class Initialized
DEBUG - 2023-12-02 14:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-02 14:18:23 --> Input Class Initialized
INFO - 2023-12-02 14:18:23 --> Language Class Initialized
INFO - 2023-12-02 14:18:23 --> Loader Class Initialized
INFO - 2023-12-02 14:18:23 --> Helper loaded: url_helper
INFO - 2023-12-02 14:18:23 --> Helper loaded: form_helper
INFO - 2023-12-02 14:18:23 --> Helper loaded: file_helper
INFO - 2023-12-02 14:18:23 --> Database Driver Class Initialized
DEBUG - 2023-12-02 14:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-02 14:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-02 14:18:23 --> Form Validation Class Initialized
INFO - 2023-12-02 14:18:23 --> Upload Class Initialized
INFO - 2023-12-02 14:18:23 --> Model "M_auth" initialized
INFO - 2023-12-02 14:18:23 --> Model "M_user" initialized
INFO - 2023-12-02 14:18:23 --> Model "M_produk" initialized
INFO - 2023-12-02 14:18:23 --> Controller Class Initialized
INFO - 2023-12-02 14:18:23 --> Model "M_pelanggan" initialized
INFO - 2023-12-02 14:18:23 --> Model "M_produk" initialized
DEBUG - 2023-12-02 14:18:23 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-02 14:18:23 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-02 14:18:23 --> Model "M_transaksi" initialized
INFO - 2023-12-02 14:18:23 --> Model "M_bank" initialized
INFO - 2023-12-02 14:18:23 --> Model "M_pesan" initialized
DEBUG - 2023-12-02 14:18:23 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-02 14:18:23 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-02 14:18:23 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-02 14:18:23 --> Final output sent to browser
DEBUG - 2023-12-02 14:18:23 --> Total execution time: 0.0040
ERROR - 2023-12-02 14:18:52 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-02 14:18:52 --> Config Class Initialized
INFO - 2023-12-02 14:18:52 --> Hooks Class Initialized
DEBUG - 2023-12-02 14:18:52 --> UTF-8 Support Enabled
INFO - 2023-12-02 14:18:52 --> Utf8 Class Initialized
INFO - 2023-12-02 14:18:52 --> URI Class Initialized
DEBUG - 2023-12-02 14:18:52 --> No URI present. Default controller set.
INFO - 2023-12-02 14:18:52 --> Router Class Initialized
INFO - 2023-12-02 14:18:52 --> Output Class Initialized
INFO - 2023-12-02 14:18:52 --> Security Class Initialized
DEBUG - 2023-12-02 14:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-02 14:18:52 --> Input Class Initialized
INFO - 2023-12-02 14:18:52 --> Language Class Initialized
INFO - 2023-12-02 14:18:52 --> Loader Class Initialized
INFO - 2023-12-02 14:18:52 --> Helper loaded: url_helper
INFO - 2023-12-02 14:18:52 --> Helper loaded: form_helper
INFO - 2023-12-02 14:18:52 --> Helper loaded: file_helper
INFO - 2023-12-02 14:18:52 --> Database Driver Class Initialized
DEBUG - 2023-12-02 14:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-02 14:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-02 14:18:52 --> Form Validation Class Initialized
INFO - 2023-12-02 14:18:52 --> Upload Class Initialized
INFO - 2023-12-02 14:18:52 --> Model "M_auth" initialized
INFO - 2023-12-02 14:18:52 --> Model "M_user" initialized
INFO - 2023-12-02 14:18:52 --> Model "M_produk" initialized
INFO - 2023-12-02 14:18:52 --> Controller Class Initialized
INFO - 2023-12-02 14:18:52 --> Model "M_pelanggan" initialized
INFO - 2023-12-02 14:18:52 --> Model "M_produk" initialized
DEBUG - 2023-12-02 14:18:52 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-02 14:18:52 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-02 14:18:52 --> Model "M_transaksi" initialized
INFO - 2023-12-02 14:18:52 --> Model "M_bank" initialized
INFO - 2023-12-02 14:18:52 --> Model "M_pesan" initialized
DEBUG - 2023-12-02 14:18:52 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-02 14:18:52 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-02 14:18:52 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-02 14:18:52 --> Final output sent to browser
DEBUG - 2023-12-02 14:18:52 --> Total execution time: 0.0041
ERROR - 2023-12-02 14:18:54 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-02 14:18:54 --> Config Class Initialized
INFO - 2023-12-02 14:18:54 --> Hooks Class Initialized
DEBUG - 2023-12-02 14:18:54 --> UTF-8 Support Enabled
INFO - 2023-12-02 14:18:54 --> Utf8 Class Initialized
INFO - 2023-12-02 14:18:54 --> URI Class Initialized
DEBUG - 2023-12-02 14:18:54 --> No URI present. Default controller set.
INFO - 2023-12-02 14:18:54 --> Router Class Initialized
INFO - 2023-12-02 14:18:54 --> Output Class Initialized
INFO - 2023-12-02 14:18:54 --> Security Class Initialized
DEBUG - 2023-12-02 14:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-02 14:18:54 --> Input Class Initialized
INFO - 2023-12-02 14:18:54 --> Language Class Initialized
INFO - 2023-12-02 14:18:54 --> Loader Class Initialized
INFO - 2023-12-02 14:18:54 --> Helper loaded: url_helper
INFO - 2023-12-02 14:18:54 --> Helper loaded: form_helper
INFO - 2023-12-02 14:18:54 --> Helper loaded: file_helper
INFO - 2023-12-02 14:18:54 --> Database Driver Class Initialized
DEBUG - 2023-12-02 14:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-02 14:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-02 14:18:54 --> Form Validation Class Initialized
INFO - 2023-12-02 14:18:54 --> Upload Class Initialized
INFO - 2023-12-02 14:18:54 --> Model "M_auth" initialized
INFO - 2023-12-02 14:18:54 --> Model "M_user" initialized
INFO - 2023-12-02 14:18:54 --> Model "M_produk" initialized
INFO - 2023-12-02 14:18:54 --> Controller Class Initialized
INFO - 2023-12-02 14:18:54 --> Model "M_pelanggan" initialized
INFO - 2023-12-02 14:18:54 --> Model "M_produk" initialized
DEBUG - 2023-12-02 14:18:54 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-02 14:18:54 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-02 14:18:54 --> Model "M_transaksi" initialized
INFO - 2023-12-02 14:18:54 --> Model "M_bank" initialized
INFO - 2023-12-02 14:18:54 --> Model "M_pesan" initialized
DEBUG - 2023-12-02 14:18:54 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-02 14:18:54 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-02 14:18:54 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-02 14:18:54 --> Final output sent to browser
DEBUG - 2023-12-02 14:18:54 --> Total execution time: 0.0032
ERROR - 2023-12-02 14:19:06 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-02 14:19:06 --> Config Class Initialized
INFO - 2023-12-02 14:19:06 --> Hooks Class Initialized
DEBUG - 2023-12-02 14:19:06 --> UTF-8 Support Enabled
INFO - 2023-12-02 14:19:06 --> Utf8 Class Initialized
INFO - 2023-12-02 14:19:06 --> URI Class Initialized
DEBUG - 2023-12-02 14:19:06 --> No URI present. Default controller set.
INFO - 2023-12-02 14:19:06 --> Router Class Initialized
INFO - 2023-12-02 14:19:06 --> Output Class Initialized
INFO - 2023-12-02 14:19:06 --> Security Class Initialized
DEBUG - 2023-12-02 14:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-02 14:19:06 --> Input Class Initialized
INFO - 2023-12-02 14:19:06 --> Language Class Initialized
INFO - 2023-12-02 14:19:06 --> Loader Class Initialized
INFO - 2023-12-02 14:19:06 --> Helper loaded: url_helper
INFO - 2023-12-02 14:19:06 --> Helper loaded: form_helper
INFO - 2023-12-02 14:19:06 --> Helper loaded: file_helper
INFO - 2023-12-02 14:19:06 --> Database Driver Class Initialized
DEBUG - 2023-12-02 14:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-02 14:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-02 14:19:06 --> Form Validation Class Initialized
INFO - 2023-12-02 14:19:06 --> Upload Class Initialized
INFO - 2023-12-02 14:19:06 --> Model "M_auth" initialized
INFO - 2023-12-02 14:19:06 --> Model "M_user" initialized
INFO - 2023-12-02 14:19:06 --> Model "M_produk" initialized
INFO - 2023-12-02 14:19:06 --> Controller Class Initialized
INFO - 2023-12-02 14:19:06 --> Model "M_pelanggan" initialized
INFO - 2023-12-02 14:19:06 --> Model "M_produk" initialized
DEBUG - 2023-12-02 14:19:06 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-02 14:19:06 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-02 14:19:06 --> Model "M_transaksi" initialized
INFO - 2023-12-02 14:19:06 --> Model "M_bank" initialized
INFO - 2023-12-02 14:19:06 --> Model "M_pesan" initialized
DEBUG - 2023-12-02 14:19:06 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-02 14:19:06 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-02 14:19:06 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-02 14:19:06 --> Final output sent to browser
DEBUG - 2023-12-02 14:19:06 --> Total execution time: 0.0047
ERROR - 2023-12-02 14:21:01 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-02 14:21:01 --> Config Class Initialized
INFO - 2023-12-02 14:21:01 --> Hooks Class Initialized
DEBUG - 2023-12-02 14:21:01 --> UTF-8 Support Enabled
INFO - 2023-12-02 14:21:01 --> Utf8 Class Initialized
INFO - 2023-12-02 14:21:01 --> URI Class Initialized
INFO - 2023-12-02 14:21:01 --> Router Class Initialized
INFO - 2023-12-02 14:21:01 --> Output Class Initialized
INFO - 2023-12-02 14:21:01 --> Security Class Initialized
DEBUG - 2023-12-02 14:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-02 14:21:01 --> Input Class Initialized
INFO - 2023-12-02 14:21:01 --> Language Class Initialized
INFO - 2023-12-02 14:21:01 --> Loader Class Initialized
INFO - 2023-12-02 14:21:01 --> Helper loaded: url_helper
INFO - 2023-12-02 14:21:01 --> Helper loaded: form_helper
INFO - 2023-12-02 14:21:01 --> Helper loaded: file_helper
INFO - 2023-12-02 14:21:01 --> Database Driver Class Initialized
DEBUG - 2023-12-02 14:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-02 14:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-02 14:21:01 --> Form Validation Class Initialized
INFO - 2023-12-02 14:21:01 --> Upload Class Initialized
INFO - 2023-12-02 14:21:01 --> Model "M_auth" initialized
INFO - 2023-12-02 14:21:01 --> Model "M_user" initialized
INFO - 2023-12-02 14:21:01 --> Model "M_produk" initialized
INFO - 2023-12-02 14:21:01 --> Controller Class Initialized
INFO - 2023-12-02 14:21:01 --> Model "M_pelanggan" initialized
INFO - 2023-12-02 14:21:01 --> Model "M_produk" initialized
DEBUG - 2023-12-02 14:21:01 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-02 14:21:01 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-02 14:21:01 --> Model "M_transaksi" initialized
INFO - 2023-12-02 14:21:01 --> Model "M_bank" initialized
INFO - 2023-12-02 14:21:01 --> Model "M_pesan" initialized
DEBUG - 2023-12-02 14:21:01 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-02 14:21:01 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-02 14:21:01 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-12-02 14:21:01 --> Final output sent to browser
DEBUG - 2023-12-02 14:21:01 --> Total execution time: 0.0072
ERROR - 2023-12-02 14:21:39 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-02 14:21:39 --> Config Class Initialized
INFO - 2023-12-02 14:21:39 --> Hooks Class Initialized
DEBUG - 2023-12-02 14:21:39 --> UTF-8 Support Enabled
INFO - 2023-12-02 14:21:39 --> Utf8 Class Initialized
INFO - 2023-12-02 14:21:39 --> URI Class Initialized
DEBUG - 2023-12-02 14:21:39 --> No URI present. Default controller set.
INFO - 2023-12-02 14:21:39 --> Router Class Initialized
INFO - 2023-12-02 14:21:39 --> Output Class Initialized
INFO - 2023-12-02 14:21:39 --> Security Class Initialized
DEBUG - 2023-12-02 14:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-02 14:21:39 --> Input Class Initialized
INFO - 2023-12-02 14:21:39 --> Language Class Initialized
INFO - 2023-12-02 14:21:39 --> Loader Class Initialized
INFO - 2023-12-02 14:21:39 --> Helper loaded: url_helper
INFO - 2023-12-02 14:21:39 --> Helper loaded: form_helper
INFO - 2023-12-02 14:21:39 --> Helper loaded: file_helper
INFO - 2023-12-02 14:21:39 --> Database Driver Class Initialized
DEBUG - 2023-12-02 14:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-02 14:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-02 14:21:39 --> Form Validation Class Initialized
INFO - 2023-12-02 14:21:39 --> Upload Class Initialized
INFO - 2023-12-02 14:21:39 --> Model "M_auth" initialized
INFO - 2023-12-02 14:21:39 --> Model "M_user" initialized
INFO - 2023-12-02 14:21:39 --> Model "M_produk" initialized
INFO - 2023-12-02 14:21:39 --> Controller Class Initialized
INFO - 2023-12-02 14:21:39 --> Model "M_pelanggan" initialized
INFO - 2023-12-02 14:21:39 --> Model "M_produk" initialized
DEBUG - 2023-12-02 14:21:39 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-02 14:21:39 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-02 14:21:39 --> Model "M_transaksi" initialized
INFO - 2023-12-02 14:21:39 --> Model "M_bank" initialized
INFO - 2023-12-02 14:21:39 --> Model "M_pesan" initialized
DEBUG - 2023-12-02 14:21:39 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-02 14:21:39 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-02 14:21:39 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-02 14:21:39 --> Final output sent to browser
DEBUG - 2023-12-02 14:21:39 --> Total execution time: 0.0047
ERROR - 2023-12-02 14:29:16 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-02 14:29:16 --> Config Class Initialized
INFO - 2023-12-02 14:29:16 --> Hooks Class Initialized
DEBUG - 2023-12-02 14:29:16 --> UTF-8 Support Enabled
INFO - 2023-12-02 14:29:16 --> Utf8 Class Initialized
INFO - 2023-12-02 14:29:16 --> URI Class Initialized
DEBUG - 2023-12-02 14:29:16 --> No URI present. Default controller set.
INFO - 2023-12-02 14:29:16 --> Router Class Initialized
INFO - 2023-12-02 14:29:16 --> Output Class Initialized
INFO - 2023-12-02 14:29:16 --> Security Class Initialized
DEBUG - 2023-12-02 14:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-02 14:29:16 --> Input Class Initialized
INFO - 2023-12-02 14:29:16 --> Language Class Initialized
INFO - 2023-12-02 14:29:16 --> Loader Class Initialized
INFO - 2023-12-02 14:29:16 --> Helper loaded: url_helper
INFO - 2023-12-02 14:29:16 --> Helper loaded: form_helper
INFO - 2023-12-02 14:29:16 --> Helper loaded: file_helper
INFO - 2023-12-02 14:29:16 --> Database Driver Class Initialized
DEBUG - 2023-12-02 14:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-02 14:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-02 14:29:16 --> Form Validation Class Initialized
INFO - 2023-12-02 14:29:16 --> Upload Class Initialized
INFO - 2023-12-02 14:29:16 --> Model "M_auth" initialized
INFO - 2023-12-02 14:29:16 --> Model "M_user" initialized
INFO - 2023-12-02 14:29:16 --> Model "M_produk" initialized
INFO - 2023-12-02 14:29:16 --> Controller Class Initialized
INFO - 2023-12-02 14:29:16 --> Model "M_pelanggan" initialized
INFO - 2023-12-02 14:29:16 --> Model "M_produk" initialized
DEBUG - 2023-12-02 14:29:16 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-02 14:29:16 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-02 14:29:16 --> Model "M_transaksi" initialized
INFO - 2023-12-02 14:29:16 --> Model "M_bank" initialized
INFO - 2023-12-02 14:29:16 --> Model "M_pesan" initialized
DEBUG - 2023-12-02 14:29:16 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-02 14:29:16 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-02 14:29:16 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-02 14:29:16 --> Final output sent to browser
DEBUG - 2023-12-02 14:29:16 --> Total execution time: 0.0038
ERROR - 2023-12-02 14:43:53 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-02 14:43:53 --> Config Class Initialized
INFO - 2023-12-02 14:43:53 --> Hooks Class Initialized
DEBUG - 2023-12-02 14:43:53 --> UTF-8 Support Enabled
INFO - 2023-12-02 14:43:53 --> Utf8 Class Initialized
INFO - 2023-12-02 14:43:53 --> URI Class Initialized
INFO - 2023-12-02 14:43:53 --> Router Class Initialized
INFO - 2023-12-02 14:43:53 --> Output Class Initialized
INFO - 2023-12-02 14:43:53 --> Security Class Initialized
DEBUG - 2023-12-02 14:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-02 14:43:53 --> Input Class Initialized
INFO - 2023-12-02 14:43:53 --> Language Class Initialized
INFO - 2023-12-02 14:43:53 --> Loader Class Initialized
INFO - 2023-12-02 14:43:53 --> Helper loaded: url_helper
INFO - 2023-12-02 14:43:53 --> Helper loaded: form_helper
INFO - 2023-12-02 14:43:53 --> Helper loaded: file_helper
INFO - 2023-12-02 14:43:53 --> Database Driver Class Initialized
DEBUG - 2023-12-02 14:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-02 14:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-02 14:43:53 --> Form Validation Class Initialized
INFO - 2023-12-02 14:43:53 --> Upload Class Initialized
INFO - 2023-12-02 14:43:53 --> Model "M_auth" initialized
INFO - 2023-12-02 14:43:53 --> Model "M_user" initialized
INFO - 2023-12-02 14:43:53 --> Model "M_produk" initialized
INFO - 2023-12-02 14:43:53 --> Controller Class Initialized
INFO - 2023-12-02 14:43:53 --> Model "M_pelanggan" initialized
INFO - 2023-12-02 14:43:53 --> Model "M_produk" initialized
DEBUG - 2023-12-02 14:43:53 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-02 14:43:53 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-02 14:43:53 --> Model "M_transaksi" initialized
INFO - 2023-12-02 14:43:53 --> Model "M_bank" initialized
INFO - 2023-12-02 14:43:53 --> Model "M_pesan" initialized
DEBUG - 2023-12-02 14:43:53 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-02 14:43:53 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-02 14:43:53 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-12-02 14:43:53 --> Final output sent to browser
DEBUG - 2023-12-02 14:43:53 --> Total execution time: 0.0347
ERROR - 2023-12-02 15:16:15 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-12-02 15:16:15 --> Config Class Initialized
INFO - 2023-12-02 15:16:15 --> Hooks Class Initialized
DEBUG - 2023-12-02 15:16:15 --> UTF-8 Support Enabled
INFO - 2023-12-02 15:16:15 --> Utf8 Class Initialized
INFO - 2023-12-02 15:16:15 --> URI Class Initialized
DEBUG - 2023-12-02 15:16:15 --> No URI present. Default controller set.
INFO - 2023-12-02 15:16:15 --> Router Class Initialized
INFO - 2023-12-02 15:16:15 --> Output Class Initialized
INFO - 2023-12-02 15:16:15 --> Security Class Initialized
DEBUG - 2023-12-02 15:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-02 15:16:15 --> Input Class Initialized
INFO - 2023-12-02 15:16:15 --> Language Class Initialized
INFO - 2023-12-02 15:16:15 --> Loader Class Initialized
INFO - 2023-12-02 15:16:15 --> Helper loaded: url_helper
INFO - 2023-12-02 15:16:15 --> Helper loaded: form_helper
INFO - 2023-12-02 15:16:15 --> Helper loaded: file_helper
INFO - 2023-12-02 15:16:15 --> Database Driver Class Initialized
DEBUG - 2023-12-02 15:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-02 15:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-02 15:16:15 --> Form Validation Class Initialized
INFO - 2023-12-02 15:16:15 --> Upload Class Initialized
INFO - 2023-12-02 15:16:15 --> Model "M_auth" initialized
INFO - 2023-12-02 15:16:15 --> Model "M_user" initialized
INFO - 2023-12-02 15:16:15 --> Model "M_produk" initialized
INFO - 2023-12-02 15:16:15 --> Controller Class Initialized
INFO - 2023-12-02 15:16:15 --> Model "M_pelanggan" initialized
INFO - 2023-12-02 15:16:15 --> Model "M_produk" initialized
DEBUG - 2023-12-02 15:16:15 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-02 15:16:15 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-02 15:16:15 --> Model "M_transaksi" initialized
INFO - 2023-12-02 15:16:15 --> Model "M_bank" initialized
INFO - 2023-12-02 15:16:15 --> Model "M_pesan" initialized
DEBUG - 2023-12-02 15:16:15 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-12-02 15:16:15 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-12-02 15:16:15 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-12-02 15:16:15 --> Final output sent to browser
DEBUG - 2023-12-02 15:16:15 --> Total execution time: 0.0392
