<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-18 01:27:03 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 01:27:03 --> Config Class Initialized
INFO - 2023-11-18 01:27:03 --> Hooks Class Initialized
DEBUG - 2023-11-18 01:27:03 --> UTF-8 Support Enabled
INFO - 2023-11-18 01:27:03 --> Utf8 Class Initialized
INFO - 2023-11-18 01:27:03 --> URI Class Initialized
DEBUG - 2023-11-18 01:27:03 --> No URI present. Default controller set.
INFO - 2023-11-18 01:27:03 --> Router Class Initialized
INFO - 2023-11-18 01:27:03 --> Output Class Initialized
INFO - 2023-11-18 01:27:03 --> Security Class Initialized
DEBUG - 2023-11-18 01:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 01:27:03 --> Input Class Initialized
INFO - 2023-11-18 01:27:03 --> Language Class Initialized
INFO - 2023-11-18 01:27:03 --> Loader Class Initialized
INFO - 2023-11-18 01:27:03 --> Helper loaded: url_helper
INFO - 2023-11-18 01:27:03 --> Helper loaded: form_helper
INFO - 2023-11-18 01:27:03 --> Helper loaded: file_helper
INFO - 2023-11-18 01:27:03 --> Database Driver Class Initialized
DEBUG - 2023-11-18 01:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 01:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 01:27:03 --> Form Validation Class Initialized
INFO - 2023-11-18 01:27:03 --> Upload Class Initialized
INFO - 2023-11-18 01:27:03 --> Model "M_auth" initialized
INFO - 2023-11-18 01:27:03 --> Model "M_user" initialized
INFO - 2023-11-18 01:27:03 --> Model "M_produk" initialized
INFO - 2023-11-18 01:27:03 --> Controller Class Initialized
INFO - 2023-11-18 01:27:03 --> Model "M_pelanggan" initialized
INFO - 2023-11-18 01:27:03 --> Model "M_produk" initialized
DEBUG - 2023-11-18 01:27:03 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-18 01:27:03 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-18 01:27:03 --> Model "M_transaksi" initialized
INFO - 2023-11-18 01:27:03 --> Model "M_bank" initialized
INFO - 2023-11-18 01:27:03 --> Model "M_pesan" initialized
DEBUG - 2023-11-18 01:27:03 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-18 01:27:03 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-18 01:27:03 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-18 01:27:03 --> Final output sent to browser
DEBUG - 2023-11-18 01:27:03 --> Total execution time: 0.0360
ERROR - 2023-11-18 03:23:24 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:23:24 --> Config Class Initialized
INFO - 2023-11-18 03:23:24 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:23:24 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:23:24 --> Utf8 Class Initialized
INFO - 2023-11-18 03:23:24 --> URI Class Initialized
DEBUG - 2023-11-18 03:23:24 --> No URI present. Default controller set.
INFO - 2023-11-18 03:23:24 --> Router Class Initialized
INFO - 2023-11-18 03:23:24 --> Output Class Initialized
INFO - 2023-11-18 03:23:24 --> Security Class Initialized
DEBUG - 2023-11-18 03:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:23:24 --> Input Class Initialized
INFO - 2023-11-18 03:23:24 --> Language Class Initialized
INFO - 2023-11-18 03:23:24 --> Loader Class Initialized
INFO - 2023-11-18 03:23:24 --> Helper loaded: url_helper
INFO - 2023-11-18 03:23:24 --> Helper loaded: form_helper
INFO - 2023-11-18 03:23:24 --> Helper loaded: file_helper
INFO - 2023-11-18 03:23:24 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:23:24 --> Form Validation Class Initialized
INFO - 2023-11-18 03:23:24 --> Upload Class Initialized
INFO - 2023-11-18 03:23:24 --> Model "M_auth" initialized
INFO - 2023-11-18 03:23:24 --> Model "M_user" initialized
INFO - 2023-11-18 03:23:24 --> Model "M_produk" initialized
INFO - 2023-11-18 03:23:24 --> Controller Class Initialized
INFO - 2023-11-18 03:23:24 --> Model "M_pelanggan" initialized
INFO - 2023-11-18 03:23:24 --> Model "M_produk" initialized
DEBUG - 2023-11-18 03:23:24 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-18 03:23:24 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-18 03:23:24 --> Model "M_transaksi" initialized
INFO - 2023-11-18 03:23:24 --> Model "M_bank" initialized
INFO - 2023-11-18 03:23:24 --> Model "M_pesan" initialized
DEBUG - 2023-11-18 03:23:24 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-18 03:23:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-18 03:23:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-18 03:23:24 --> Final output sent to browser
DEBUG - 2023-11-18 03:23:24 --> Total execution time: 0.0352
ERROR - 2023-11-18 03:36:59 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:36:59 --> Config Class Initialized
INFO - 2023-11-18 03:36:59 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:36:59 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:36:59 --> Utf8 Class Initialized
INFO - 2023-11-18 03:36:59 --> URI Class Initialized
DEBUG - 2023-11-18 03:36:59 --> No URI present. Default controller set.
INFO - 2023-11-18 03:36:59 --> Router Class Initialized
INFO - 2023-11-18 03:36:59 --> Output Class Initialized
INFO - 2023-11-18 03:36:59 --> Security Class Initialized
DEBUG - 2023-11-18 03:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:36:59 --> Input Class Initialized
INFO - 2023-11-18 03:36:59 --> Language Class Initialized
INFO - 2023-11-18 03:36:59 --> Loader Class Initialized
INFO - 2023-11-18 03:36:59 --> Helper loaded: url_helper
INFO - 2023-11-18 03:36:59 --> Helper loaded: form_helper
INFO - 2023-11-18 03:36:59 --> Helper loaded: file_helper
INFO - 2023-11-18 03:36:59 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:36:59 --> Form Validation Class Initialized
INFO - 2023-11-18 03:36:59 --> Upload Class Initialized
INFO - 2023-11-18 03:36:59 --> Model "M_auth" initialized
INFO - 2023-11-18 03:36:59 --> Model "M_user" initialized
INFO - 2023-11-18 03:36:59 --> Model "M_produk" initialized
INFO - 2023-11-18 03:36:59 --> Controller Class Initialized
INFO - 2023-11-18 03:36:59 --> Model "M_pelanggan" initialized
INFO - 2023-11-18 03:36:59 --> Model "M_produk" initialized
DEBUG - 2023-11-18 03:36:59 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-18 03:36:59 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-18 03:36:59 --> Model "M_transaksi" initialized
INFO - 2023-11-18 03:36:59 --> Model "M_bank" initialized
INFO - 2023-11-18 03:36:59 --> Model "M_pesan" initialized
DEBUG - 2023-11-18 03:36:59 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-18 03:36:59 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-18 03:36:59 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-18 03:36:59 --> Final output sent to browser
DEBUG - 2023-11-18 03:36:59 --> Total execution time: 0.0300
ERROR - 2023-11-18 03:37:26 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:37:26 --> Config Class Initialized
INFO - 2023-11-18 03:37:26 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:37:26 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:37:26 --> Utf8 Class Initialized
INFO - 2023-11-18 03:37:26 --> URI Class Initialized
INFO - 2023-11-18 03:37:26 --> Router Class Initialized
INFO - 2023-11-18 03:37:26 --> Output Class Initialized
INFO - 2023-11-18 03:37:26 --> Security Class Initialized
DEBUG - 2023-11-18 03:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:37:26 --> Input Class Initialized
INFO - 2023-11-18 03:37:26 --> Language Class Initialized
INFO - 2023-11-18 03:37:26 --> Loader Class Initialized
INFO - 2023-11-18 03:37:26 --> Helper loaded: url_helper
INFO - 2023-11-18 03:37:26 --> Helper loaded: form_helper
INFO - 2023-11-18 03:37:26 --> Helper loaded: file_helper
INFO - 2023-11-18 03:37:26 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:37:26 --> Form Validation Class Initialized
INFO - 2023-11-18 03:37:26 --> Upload Class Initialized
INFO - 2023-11-18 03:37:26 --> Model "M_auth" initialized
INFO - 2023-11-18 03:37:26 --> Model "M_user" initialized
INFO - 2023-11-18 03:37:26 --> Model "M_produk" initialized
INFO - 2023-11-18 03:37:26 --> Controller Class Initialized
INFO - 2023-11-18 03:37:26 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:37:26 --> Final output sent to browser
DEBUG - 2023-11-18 03:37:26 --> Total execution time: 0.0034
ERROR - 2023-11-18 03:37:26 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:37:26 --> Config Class Initialized
INFO - 2023-11-18 03:37:26 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:37:26 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:37:26 --> Utf8 Class Initialized
INFO - 2023-11-18 03:37:26 --> URI Class Initialized
INFO - 2023-11-18 03:37:26 --> Router Class Initialized
INFO - 2023-11-18 03:37:26 --> Output Class Initialized
INFO - 2023-11-18 03:37:26 --> Security Class Initialized
DEBUG - 2023-11-18 03:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:37:26 --> Input Class Initialized
INFO - 2023-11-18 03:37:26 --> Language Class Initialized
INFO - 2023-11-18 03:37:26 --> Loader Class Initialized
INFO - 2023-11-18 03:37:26 --> Helper loaded: url_helper
INFO - 2023-11-18 03:37:26 --> Helper loaded: form_helper
INFO - 2023-11-18 03:37:26 --> Helper loaded: file_helper
INFO - 2023-11-18 03:37:26 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:37:26 --> Form Validation Class Initialized
INFO - 2023-11-18 03:37:26 --> Upload Class Initialized
ERROR - 2023-11-18 03:37:26 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:37:26 --> Model "M_auth" initialized
INFO - 2023-11-18 03:37:26 --> Config Class Initialized
INFO - 2023-11-18 03:37:26 --> Model "M_user" initialized
INFO - 2023-11-18 03:37:26 --> Hooks Class Initialized
INFO - 2023-11-18 03:37:26 --> Model "M_produk" initialized
INFO - 2023-11-18 03:37:26 --> Controller Class Initialized
DEBUG - 2023-11-18 03:37:26 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:37:26 --> Utf8 Class Initialized
INFO - 2023-11-18 03:37:26 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:37:26 --> URI Class Initialized
INFO - 2023-11-18 03:37:26 --> Final output sent to browser
DEBUG - 2023-11-18 03:37:26 --> Total execution time: 0.0026
INFO - 2023-11-18 03:37:26 --> Router Class Initialized
INFO - 2023-11-18 03:37:26 --> Output Class Initialized
ERROR - 2023-11-18 03:37:26 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:37:26 --> Security Class Initialized
DEBUG - 2023-11-18 03:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:37:26 --> Config Class Initialized
INFO - 2023-11-18 03:37:26 --> Input Class Initialized
INFO - 2023-11-18 03:37:26 --> Hooks Class Initialized
INFO - 2023-11-18 03:37:26 --> Language Class Initialized
INFO - 2023-11-18 03:37:26 --> Loader Class Initialized
DEBUG - 2023-11-18 03:37:26 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:37:26 --> Utf8 Class Initialized
INFO - 2023-11-18 03:37:26 --> Helper loaded: url_helper
INFO - 2023-11-18 03:37:26 --> Helper loaded: form_helper
INFO - 2023-11-18 03:37:26 --> URI Class Initialized
INFO - 2023-11-18 03:37:26 --> Helper loaded: file_helper
INFO - 2023-11-18 03:37:26 --> Database Driver Class Initialized
INFO - 2023-11-18 03:37:26 --> Router Class Initialized
INFO - 2023-11-18 03:37:26 --> Output Class Initialized
ERROR - 2023-11-18 03:37:26 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:37:26 --> Security Class Initialized
INFO - 2023-11-18 03:37:26 --> Config Class Initialized
DEBUG - 2023-11-18 03:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:37:26 --> Hooks Class Initialized
INFO - 2023-11-18 03:37:26 --> Input Class Initialized
INFO - 2023-11-18 03:37:26 --> Language Class Initialized
DEBUG - 2023-11-18 03:37:26 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:37:26 --> Utf8 Class Initialized
INFO - 2023-11-18 03:37:26 --> Loader Class Initialized
INFO - 2023-11-18 03:37:26 --> Helper loaded: url_helper
INFO - 2023-11-18 03:37:26 --> URI Class Initialized
INFO - 2023-11-18 03:37:26 --> Helper loaded: form_helper
INFO - 2023-11-18 03:37:26 --> Helper loaded: file_helper
INFO - 2023-11-18 03:37:26 --> Router Class Initialized
INFO - 2023-11-18 03:37:26 --> Database Driver Class Initialized
INFO - 2023-11-18 03:37:26 --> Output Class Initialized
INFO - 2023-11-18 03:37:26 --> Security Class Initialized
DEBUG - 2023-11-18 03:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-11-18 03:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:37:26 --> Input Class Initialized
INFO - 2023-11-18 03:37:26 --> Language Class Initialized
INFO - 2023-11-18 03:37:26 --> Loader Class Initialized
INFO - 2023-11-18 03:37:26 --> Helper loaded: url_helper
INFO - 2023-11-18 03:37:26 --> Helper loaded: form_helper
INFO - 2023-11-18 03:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:37:26 --> Helper loaded: file_helper
INFO - 2023-11-18 03:37:26 --> Database Driver Class Initialized
INFO - 2023-11-18 03:37:26 --> Form Validation Class Initialized
INFO - 2023-11-18 03:37:26 --> Upload Class Initialized
INFO - 2023-11-18 03:37:26 --> Model "M_auth" initialized
INFO - 2023-11-18 03:37:26 --> Model "M_user" initialized
INFO - 2023-11-18 03:37:26 --> Model "M_produk" initialized
INFO - 2023-11-18 03:37:26 --> Controller Class Initialized
INFO - 2023-11-18 03:37:26 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:37:26 --> Final output sent to browser
DEBUG - 2023-11-18 03:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-11-18 03:37:26 --> Total execution time: 0.0027
DEBUG - 2023-11-18 03:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:37:26 --> Form Validation Class Initialized
INFO - 2023-11-18 03:37:26 --> Form Validation Class Initialized
INFO - 2023-11-18 03:37:26 --> Upload Class Initialized
INFO - 2023-11-18 03:37:26 --> Upload Class Initialized
INFO - 2023-11-18 03:37:26 --> Model "M_auth" initialized
INFO - 2023-11-18 03:37:26 --> Model "M_auth" initialized
INFO - 2023-11-18 03:37:26 --> Model "M_user" initialized
INFO - 2023-11-18 03:37:26 --> Model "M_produk" initialized
INFO - 2023-11-18 03:37:26 --> Model "M_user" initialized
INFO - 2023-11-18 03:37:26 --> Controller Class Initialized
INFO - 2023-11-18 03:37:26 --> Model "M_produk" initialized
INFO - 2023-11-18 03:37:26 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:37:26 --> Controller Class Initialized
INFO - 2023-11-18 03:37:26 --> Final output sent to browser
DEBUG - 2023-11-18 03:37:26 --> Total execution time: 0.0025
INFO - 2023-11-18 03:37:26 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:37:26 --> Final output sent to browser
DEBUG - 2023-11-18 03:37:26 --> Total execution time: 0.0032
ERROR - 2023-11-18 03:37:27 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:37:27 --> Config Class Initialized
INFO - 2023-11-18 03:37:27 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:37:27 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:37:27 --> Utf8 Class Initialized
INFO - 2023-11-18 03:37:27 --> URI Class Initialized
INFO - 2023-11-18 03:37:27 --> Router Class Initialized
INFO - 2023-11-18 03:37:27 --> Output Class Initialized
INFO - 2023-11-18 03:37:27 --> Security Class Initialized
DEBUG - 2023-11-18 03:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:37:27 --> Input Class Initialized
INFO - 2023-11-18 03:37:27 --> Language Class Initialized
INFO - 2023-11-18 03:37:27 --> Loader Class Initialized
INFO - 2023-11-18 03:37:27 --> Helper loaded: url_helper
INFO - 2023-11-18 03:37:27 --> Helper loaded: form_helper
INFO - 2023-11-18 03:37:27 --> Helper loaded: file_helper
INFO - 2023-11-18 03:37:27 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:37:27 --> Form Validation Class Initialized
INFO - 2023-11-18 03:37:27 --> Upload Class Initialized
INFO - 2023-11-18 03:37:27 --> Model "M_auth" initialized
INFO - 2023-11-18 03:37:27 --> Model "M_user" initialized
INFO - 2023-11-18 03:37:27 --> Model "M_produk" initialized
INFO - 2023-11-18 03:37:27 --> Controller Class Initialized
INFO - 2023-11-18 03:37:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:37:27 --> Final output sent to browser
DEBUG - 2023-11-18 03:37:27 --> Total execution time: 0.0021
ERROR - 2023-11-18 03:37:27 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:37:27 --> Config Class Initialized
INFO - 2023-11-18 03:37:27 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:37:27 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:37:27 --> Utf8 Class Initialized
INFO - 2023-11-18 03:37:27 --> URI Class Initialized
INFO - 2023-11-18 03:37:27 --> Router Class Initialized
INFO - 2023-11-18 03:37:27 --> Output Class Initialized
INFO - 2023-11-18 03:37:27 --> Security Class Initialized
DEBUG - 2023-11-18 03:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:37:27 --> Input Class Initialized
INFO - 2023-11-18 03:37:27 --> Language Class Initialized
INFO - 2023-11-18 03:37:27 --> Loader Class Initialized
INFO - 2023-11-18 03:37:27 --> Helper loaded: url_helper
INFO - 2023-11-18 03:37:27 --> Helper loaded: form_helper
INFO - 2023-11-18 03:37:27 --> Helper loaded: file_helper
INFO - 2023-11-18 03:37:27 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:37:27 --> Form Validation Class Initialized
INFO - 2023-11-18 03:37:27 --> Upload Class Initialized
INFO - 2023-11-18 03:37:27 --> Model "M_auth" initialized
INFO - 2023-11-18 03:37:27 --> Model "M_user" initialized
INFO - 2023-11-18 03:37:27 --> Model "M_produk" initialized
INFO - 2023-11-18 03:37:27 --> Controller Class Initialized
INFO - 2023-11-18 03:37:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:37:27 --> Final output sent to browser
DEBUG - 2023-11-18 03:37:27 --> Total execution time: 0.0024
ERROR - 2023-11-18 03:37:27 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:37:27 --> Config Class Initialized
INFO - 2023-11-18 03:37:27 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:37:27 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:37:27 --> Utf8 Class Initialized
ERROR - 2023-11-18 03:37:27 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:37:27 --> URI Class Initialized
INFO - 2023-11-18 03:37:27 --> Config Class Initialized
INFO - 2023-11-18 03:37:27 --> Router Class Initialized
INFO - 2023-11-18 03:37:27 --> Hooks Class Initialized
INFO - 2023-11-18 03:37:27 --> Output Class Initialized
INFO - 2023-11-18 03:37:27 --> Security Class Initialized
DEBUG - 2023-11-18 03:37:27 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:37:27 --> Utf8 Class Initialized
DEBUG - 2023-11-18 03:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:37:27 --> Input Class Initialized
INFO - 2023-11-18 03:37:27 --> URI Class Initialized
INFO - 2023-11-18 03:37:27 --> Language Class Initialized
INFO - 2023-11-18 03:37:27 --> Router Class Initialized
INFO - 2023-11-18 03:37:27 --> Loader Class Initialized
INFO - 2023-11-18 03:37:27 --> Output Class Initialized
INFO - 2023-11-18 03:37:27 --> Security Class Initialized
INFO - 2023-11-18 03:37:27 --> Helper loaded: url_helper
DEBUG - 2023-11-18 03:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:37:27 --> Input Class Initialized
INFO - 2023-11-18 03:37:27 --> Helper loaded: form_helper
INFO - 2023-11-18 03:37:27 --> Language Class Initialized
INFO - 2023-11-18 03:37:27 --> Helper loaded: file_helper
INFO - 2023-11-18 03:37:27 --> Loader Class Initialized
INFO - 2023-11-18 03:37:27 --> Database Driver Class Initialized
INFO - 2023-11-18 03:37:27 --> Helper loaded: url_helper
INFO - 2023-11-18 03:37:27 --> Helper loaded: form_helper
INFO - 2023-11-18 03:37:27 --> Helper loaded: file_helper
INFO - 2023-11-18 03:37:27 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-11-18 03:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:37:27 --> Form Validation Class Initialized
INFO - 2023-11-18 03:37:27 --> Upload Class Initialized
INFO - 2023-11-18 03:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:37:27 --> Model "M_auth" initialized
INFO - 2023-11-18 03:37:27 --> Form Validation Class Initialized
INFO - 2023-11-18 03:37:27 --> Model "M_user" initialized
INFO - 2023-11-18 03:37:27 --> Upload Class Initialized
INFO - 2023-11-18 03:37:27 --> Model "M_produk" initialized
INFO - 2023-11-18 03:37:27 --> Controller Class Initialized
INFO - 2023-11-18 03:37:27 --> Model "M_auth" initialized
INFO - 2023-11-18 03:37:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:37:27 --> Model "M_user" initialized
INFO - 2023-11-18 03:37:27 --> Model "M_produk" initialized
INFO - 2023-11-18 03:37:27 --> Final output sent to browser
INFO - 2023-11-18 03:37:27 --> Controller Class Initialized
DEBUG - 2023-11-18 03:37:27 --> Total execution time: 0.0027
INFO - 2023-11-18 03:37:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:37:27 --> Final output sent to browser
DEBUG - 2023-11-18 03:37:27 --> Total execution time: 0.0026
ERROR - 2023-11-18 03:37:27 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:37:27 --> Config Class Initialized
INFO - 2023-11-18 03:37:27 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:37:27 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:37:27 --> Utf8 Class Initialized
INFO - 2023-11-18 03:37:27 --> URI Class Initialized
INFO - 2023-11-18 03:37:27 --> Router Class Initialized
INFO - 2023-11-18 03:37:27 --> Output Class Initialized
INFO - 2023-11-18 03:37:27 --> Security Class Initialized
DEBUG - 2023-11-18 03:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:37:27 --> Input Class Initialized
INFO - 2023-11-18 03:37:27 --> Language Class Initialized
INFO - 2023-11-18 03:37:27 --> Loader Class Initialized
INFO - 2023-11-18 03:37:27 --> Helper loaded: url_helper
INFO - 2023-11-18 03:37:27 --> Helper loaded: form_helper
INFO - 2023-11-18 03:37:27 --> Helper loaded: file_helper
INFO - 2023-11-18 03:37:27 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:37:27 --> Form Validation Class Initialized
INFO - 2023-11-18 03:37:27 --> Upload Class Initialized
INFO - 2023-11-18 03:37:27 --> Model "M_auth" initialized
INFO - 2023-11-18 03:37:27 --> Model "M_user" initialized
INFO - 2023-11-18 03:37:27 --> Model "M_produk" initialized
INFO - 2023-11-18 03:37:27 --> Controller Class Initialized
INFO - 2023-11-18 03:37:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:37:27 --> Final output sent to browser
DEBUG - 2023-11-18 03:37:27 --> Total execution time: 0.0024
ERROR - 2023-11-18 03:37:27 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:37:27 --> Config Class Initialized
INFO - 2023-11-18 03:37:27 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:37:27 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:37:27 --> Utf8 Class Initialized
INFO - 2023-11-18 03:37:27 --> URI Class Initialized
INFO - 2023-11-18 03:37:27 --> Router Class Initialized
INFO - 2023-11-18 03:37:27 --> Output Class Initialized
INFO - 2023-11-18 03:37:27 --> Security Class Initialized
DEBUG - 2023-11-18 03:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:37:27 --> Input Class Initialized
INFO - 2023-11-18 03:37:27 --> Language Class Initialized
INFO - 2023-11-18 03:37:27 --> Loader Class Initialized
INFO - 2023-11-18 03:37:27 --> Helper loaded: url_helper
INFO - 2023-11-18 03:37:27 --> Helper loaded: form_helper
INFO - 2023-11-18 03:37:27 --> Helper loaded: file_helper
INFO - 2023-11-18 03:37:27 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:37:27 --> Form Validation Class Initialized
INFO - 2023-11-18 03:37:27 --> Upload Class Initialized
INFO - 2023-11-18 03:37:27 --> Model "M_auth" initialized
INFO - 2023-11-18 03:37:27 --> Model "M_user" initialized
INFO - 2023-11-18 03:37:27 --> Model "M_produk" initialized
INFO - 2023-11-18 03:37:27 --> Controller Class Initialized
INFO - 2023-11-18 03:37:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:37:27 --> Final output sent to browser
DEBUG - 2023-11-18 03:37:27 --> Total execution time: 0.0021
ERROR - 2023-11-18 03:37:29 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:37:29 --> Config Class Initialized
INFO - 2023-11-18 03:37:29 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:37:29 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:37:29 --> Utf8 Class Initialized
INFO - 2023-11-18 03:37:29 --> URI Class Initialized
INFO - 2023-11-18 03:37:29 --> Router Class Initialized
INFO - 2023-11-18 03:37:29 --> Output Class Initialized
INFO - 2023-11-18 03:37:29 --> Security Class Initialized
DEBUG - 2023-11-18 03:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:37:29 --> Input Class Initialized
INFO - 2023-11-18 03:37:29 --> Language Class Initialized
INFO - 2023-11-18 03:37:29 --> Loader Class Initialized
INFO - 2023-11-18 03:37:29 --> Helper loaded: url_helper
INFO - 2023-11-18 03:37:29 --> Helper loaded: form_helper
INFO - 2023-11-18 03:37:29 --> Helper loaded: file_helper
INFO - 2023-11-18 03:37:29 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:37:29 --> Form Validation Class Initialized
INFO - 2023-11-18 03:37:29 --> Upload Class Initialized
INFO - 2023-11-18 03:37:29 --> Model "M_auth" initialized
INFO - 2023-11-18 03:37:29 --> Model "M_user" initialized
INFO - 2023-11-18 03:37:29 --> Model "M_produk" initialized
INFO - 2023-11-18 03:37:29 --> Controller Class Initialized
INFO - 2023-11-18 03:37:29 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:37:29 --> Final output sent to browser
DEBUG - 2023-11-18 03:37:29 --> Total execution time: 0.0029
ERROR - 2023-11-18 03:37:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:37:45 --> Config Class Initialized
INFO - 2023-11-18 03:37:45 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:37:45 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:37:45 --> Utf8 Class Initialized
INFO - 2023-11-18 03:37:45 --> URI Class Initialized
INFO - 2023-11-18 03:37:45 --> Router Class Initialized
INFO - 2023-11-18 03:37:45 --> Output Class Initialized
INFO - 2023-11-18 03:37:45 --> Security Class Initialized
DEBUG - 2023-11-18 03:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:37:45 --> Input Class Initialized
INFO - 2023-11-18 03:37:45 --> Language Class Initialized
INFO - 2023-11-18 03:37:45 --> Loader Class Initialized
INFO - 2023-11-18 03:37:45 --> Helper loaded: url_helper
INFO - 2023-11-18 03:37:45 --> Helper loaded: form_helper
INFO - 2023-11-18 03:37:45 --> Helper loaded: file_helper
INFO - 2023-11-18 03:37:45 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:37:45 --> Form Validation Class Initialized
INFO - 2023-11-18 03:37:45 --> Upload Class Initialized
INFO - 2023-11-18 03:37:45 --> Model "M_auth" initialized
INFO - 2023-11-18 03:37:45 --> Model "M_user" initialized
INFO - 2023-11-18 03:37:45 --> Model "M_produk" initialized
INFO - 2023-11-18 03:37:45 --> Controller Class Initialized
INFO - 2023-11-18 03:37:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:37:45 --> Final output sent to browser
DEBUG - 2023-11-18 03:37:45 --> Total execution time: 0.0032
ERROR - 2023-11-18 03:37:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:37:45 --> Config Class Initialized
INFO - 2023-11-18 03:37:45 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:37:45 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:37:45 --> Utf8 Class Initialized
INFO - 2023-11-18 03:37:45 --> URI Class Initialized
INFO - 2023-11-18 03:37:45 --> Router Class Initialized
INFO - 2023-11-18 03:37:45 --> Output Class Initialized
INFO - 2023-11-18 03:37:45 --> Security Class Initialized
DEBUG - 2023-11-18 03:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:37:45 --> Input Class Initialized
INFO - 2023-11-18 03:37:45 --> Language Class Initialized
ERROR - 2023-11-18 03:37:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:37:45 --> Loader Class Initialized
INFO - 2023-11-18 03:37:45 --> Config Class Initialized
INFO - 2023-11-18 03:37:45 --> Hooks Class Initialized
INFO - 2023-11-18 03:37:45 --> Helper loaded: url_helper
INFO - 2023-11-18 03:37:45 --> Helper loaded: form_helper
INFO - 2023-11-18 03:37:45 --> Helper loaded: file_helper
DEBUG - 2023-11-18 03:37:45 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:37:45 --> Utf8 Class Initialized
INFO - 2023-11-18 03:37:45 --> Database Driver Class Initialized
INFO - 2023-11-18 03:37:45 --> URI Class Initialized
INFO - 2023-11-18 03:37:45 --> Router Class Initialized
ERROR - 2023-11-18 03:37:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:37:45 --> Output Class Initialized
INFO - 2023-11-18 03:37:45 --> Config Class Initialized
INFO - 2023-11-18 03:37:45 --> Security Class Initialized
INFO - 2023-11-18 03:37:45 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:37:45 --> Input Class Initialized
DEBUG - 2023-11-18 03:37:45 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:37:45 --> Language Class Initialized
INFO - 2023-11-18 03:37:45 --> Utf8 Class Initialized
INFO - 2023-11-18 03:37:45 --> URI Class Initialized
INFO - 2023-11-18 03:37:45 --> Loader Class Initialized
INFO - 2023-11-18 03:37:45 --> Helper loaded: url_helper
INFO - 2023-11-18 03:37:45 --> Router Class Initialized
INFO - 2023-11-18 03:37:45 --> Helper loaded: form_helper
INFO - 2023-11-18 03:37:45 --> Output Class Initialized
INFO - 2023-11-18 03:37:45 --> Helper loaded: file_helper
INFO - 2023-11-18 03:37:45 --> Security Class Initialized
DEBUG - 2023-11-18 03:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:37:45 --> Input Class Initialized
INFO - 2023-11-18 03:37:45 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:37:45 --> Language Class Initialized
ERROR - 2023-11-18 03:37:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:37:45 --> Config Class Initialized
INFO - 2023-11-18 03:37:45 --> Loader Class Initialized
INFO - 2023-11-18 03:37:45 --> Hooks Class Initialized
INFO - 2023-11-18 03:37:45 --> Helper loaded: url_helper
DEBUG - 2023-11-18 03:37:45 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:37:45 --> Helper loaded: form_helper
INFO - 2023-11-18 03:37:45 --> Utf8 Class Initialized
INFO - 2023-11-18 03:37:45 --> Helper loaded: file_helper
INFO - 2023-11-18 03:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:37:45 --> URI Class Initialized
INFO - 2023-11-18 03:37:45 --> Database Driver Class Initialized
INFO - 2023-11-18 03:37:45 --> Form Validation Class Initialized
INFO - 2023-11-18 03:37:45 --> Router Class Initialized
INFO - 2023-11-18 03:37:45 --> Upload Class Initialized
INFO - 2023-11-18 03:37:45 --> Output Class Initialized
INFO - 2023-11-18 03:37:45 --> Security Class Initialized
INFO - 2023-11-18 03:37:45 --> Model "M_auth" initialized
DEBUG - 2023-11-18 03:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:37:45 --> Input Class Initialized
INFO - 2023-11-18 03:37:45 --> Model "M_user" initialized
INFO - 2023-11-18 03:37:45 --> Language Class Initialized
INFO - 2023-11-18 03:37:45 --> Model "M_produk" initialized
INFO - 2023-11-18 03:37:45 --> Controller Class Initialized
INFO - 2023-11-18 03:37:45 --> Loader Class Initialized
ERROR - 2023-11-18 03:37:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:37:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:37:45 --> Helper loaded: url_helper
INFO - 2023-11-18 03:37:45 --> Final output sent to browser
DEBUG - 2023-11-18 03:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:37:45 --> Helper loaded: form_helper
INFO - 2023-11-18 03:37:45 --> Config Class Initialized
DEBUG - 2023-11-18 03:37:45 --> Total execution time: 0.0028
INFO - 2023-11-18 03:37:45 --> Hooks Class Initialized
INFO - 2023-11-18 03:37:45 --> Helper loaded: file_helper
INFO - 2023-11-18 03:37:45 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:37:45 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:37:45 --> Utf8 Class Initialized
INFO - 2023-11-18 03:37:45 --> URI Class Initialized
DEBUG - 2023-11-18 03:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:37:45 --> Router Class Initialized
INFO - 2023-11-18 03:37:45 --> Form Validation Class Initialized
INFO - 2023-11-18 03:37:45 --> Output Class Initialized
INFO - 2023-11-18 03:37:45 --> Security Class Initialized
INFO - 2023-11-18 03:37:45 --> Upload Class Initialized
DEBUG - 2023-11-18 03:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:37:45 --> Input Class Initialized
INFO - 2023-11-18 03:37:45 --> Model "M_auth" initialized
INFO - 2023-11-18 03:37:45 --> Language Class Initialized
INFO - 2023-11-18 03:37:45 --> Model "M_user" initialized
INFO - 2023-11-18 03:37:45 --> Loader Class Initialized
INFO - 2023-11-18 03:37:45 --> Model "M_produk" initialized
DEBUG - 2023-11-18 03:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:37:45 --> Controller Class Initialized
INFO - 2023-11-18 03:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:37:45 --> Helper loaded: url_helper
INFO - 2023-11-18 03:37:45 --> Helper loaded: form_helper
INFO - 2023-11-18 03:37:45 --> Form Validation Class Initialized
INFO - 2023-11-18 03:37:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:37:45 --> Helper loaded: file_helper
INFO - 2023-11-18 03:37:45 --> Upload Class Initialized
INFO - 2023-11-18 03:37:45 --> Final output sent to browser
DEBUG - 2023-11-18 03:37:45 --> Total execution time: 0.0031
INFO - 2023-11-18 03:37:45 --> Database Driver Class Initialized
INFO - 2023-11-18 03:37:45 --> Model "M_auth" initialized
INFO - 2023-11-18 03:37:45 --> Model "M_user" initialized
INFO - 2023-11-18 03:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:37:45 --> Model "M_produk" initialized
INFO - 2023-11-18 03:37:45 --> Controller Class Initialized
INFO - 2023-11-18 03:37:45 --> Form Validation Class Initialized
INFO - 2023-11-18 03:37:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:37:45 --> Upload Class Initialized
INFO - 2023-11-18 03:37:45 --> Final output sent to browser
DEBUG - 2023-11-18 03:37:45 --> Total execution time: 0.0028
INFO - 2023-11-18 03:37:45 --> Model "M_auth" initialized
INFO - 2023-11-18 03:37:45 --> Model "M_user" initialized
INFO - 2023-11-18 03:37:45 --> Model "M_produk" initialized
INFO - 2023-11-18 03:37:45 --> Controller Class Initialized
INFO - 2023-11-18 03:37:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
DEBUG - 2023-11-18 03:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:37:45 --> Final output sent to browser
DEBUG - 2023-11-18 03:37:45 --> Total execution time: 0.0025
INFO - 2023-11-18 03:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:37:45 --> Form Validation Class Initialized
INFO - 2023-11-18 03:37:45 --> Upload Class Initialized
INFO - 2023-11-18 03:37:45 --> Model "M_auth" initialized
INFO - 2023-11-18 03:37:45 --> Model "M_user" initialized
INFO - 2023-11-18 03:37:45 --> Model "M_produk" initialized
INFO - 2023-11-18 03:37:45 --> Controller Class Initialized
INFO - 2023-11-18 03:37:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:37:45 --> Final output sent to browser
DEBUG - 2023-11-18 03:37:45 --> Total execution time: 0.0024
ERROR - 2023-11-18 03:37:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:37:45 --> Config Class Initialized
INFO - 2023-11-18 03:37:45 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:37:45 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:37:45 --> Utf8 Class Initialized
INFO - 2023-11-18 03:37:45 --> URI Class Initialized
INFO - 2023-11-18 03:37:45 --> Router Class Initialized
INFO - 2023-11-18 03:37:45 --> Output Class Initialized
INFO - 2023-11-18 03:37:45 --> Security Class Initialized
DEBUG - 2023-11-18 03:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:37:45 --> Input Class Initialized
INFO - 2023-11-18 03:37:45 --> Language Class Initialized
INFO - 2023-11-18 03:37:45 --> Loader Class Initialized
INFO - 2023-11-18 03:37:45 --> Helper loaded: url_helper
INFO - 2023-11-18 03:37:45 --> Helper loaded: form_helper
INFO - 2023-11-18 03:37:45 --> Helper loaded: file_helper
INFO - 2023-11-18 03:37:45 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:37:45 --> Form Validation Class Initialized
INFO - 2023-11-18 03:37:45 --> Upload Class Initialized
INFO - 2023-11-18 03:37:45 --> Model "M_auth" initialized
INFO - 2023-11-18 03:37:45 --> Model "M_user" initialized
INFO - 2023-11-18 03:37:45 --> Model "M_produk" initialized
INFO - 2023-11-18 03:37:45 --> Controller Class Initialized
INFO - 2023-11-18 03:37:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:37:45 --> Final output sent to browser
DEBUG - 2023-11-18 03:37:45 --> Total execution time: 0.0017
ERROR - 2023-11-18 03:37:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:37:45 --> Config Class Initialized
INFO - 2023-11-18 03:37:45 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:37:45 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:37:45 --> Utf8 Class Initialized
INFO - 2023-11-18 03:37:45 --> URI Class Initialized
INFO - 2023-11-18 03:37:45 --> Router Class Initialized
INFO - 2023-11-18 03:37:45 --> Output Class Initialized
INFO - 2023-11-18 03:37:45 --> Security Class Initialized
DEBUG - 2023-11-18 03:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:37:45 --> Input Class Initialized
INFO - 2023-11-18 03:37:45 --> Language Class Initialized
INFO - 2023-11-18 03:37:45 --> Loader Class Initialized
INFO - 2023-11-18 03:37:45 --> Helper loaded: url_helper
INFO - 2023-11-18 03:37:45 --> Helper loaded: form_helper
INFO - 2023-11-18 03:37:45 --> Helper loaded: file_helper
INFO - 2023-11-18 03:37:45 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:37:45 --> Form Validation Class Initialized
INFO - 2023-11-18 03:37:45 --> Upload Class Initialized
INFO - 2023-11-18 03:37:45 --> Model "M_auth" initialized
INFO - 2023-11-18 03:37:45 --> Model "M_user" initialized
INFO - 2023-11-18 03:37:45 --> Model "M_produk" initialized
INFO - 2023-11-18 03:37:45 --> Controller Class Initialized
INFO - 2023-11-18 03:37:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:37:45 --> Final output sent to browser
DEBUG - 2023-11-18 03:37:45 --> Total execution time: 0.0023
ERROR - 2023-11-18 03:37:46 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
ERROR - 2023-11-18 03:37:46 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:37:46 --> Config Class Initialized
INFO - 2023-11-18 03:37:46 --> Hooks Class Initialized
INFO - 2023-11-18 03:37:46 --> Config Class Initialized
INFO - 2023-11-18 03:37:46 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:37:46 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:37:46 --> Utf8 Class Initialized
DEBUG - 2023-11-18 03:37:46 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:37:46 --> Utf8 Class Initialized
INFO - 2023-11-18 03:37:46 --> URI Class Initialized
INFO - 2023-11-18 03:37:46 --> URI Class Initialized
INFO - 2023-11-18 03:37:46 --> Router Class Initialized
INFO - 2023-11-18 03:37:46 --> Router Class Initialized
INFO - 2023-11-18 03:37:46 --> Output Class Initialized
INFO - 2023-11-18 03:37:46 --> Output Class Initialized
INFO - 2023-11-18 03:37:46 --> Security Class Initialized
INFO - 2023-11-18 03:37:46 --> Security Class Initialized
DEBUG - 2023-11-18 03:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:37:46 --> Input Class Initialized
DEBUG - 2023-11-18 03:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:37:46 --> Input Class Initialized
INFO - 2023-11-18 03:37:46 --> Language Class Initialized
INFO - 2023-11-18 03:37:46 --> Language Class Initialized
INFO - 2023-11-18 03:37:46 --> Loader Class Initialized
INFO - 2023-11-18 03:37:46 --> Loader Class Initialized
INFO - 2023-11-18 03:37:46 --> Helper loaded: url_helper
INFO - 2023-11-18 03:37:46 --> Helper loaded: url_helper
INFO - 2023-11-18 03:37:46 --> Helper loaded: form_helper
INFO - 2023-11-18 03:37:46 --> Helper loaded: form_helper
INFO - 2023-11-18 03:37:46 --> Helper loaded: file_helper
INFO - 2023-11-18 03:37:46 --> Helper loaded: file_helper
INFO - 2023-11-18 03:37:46 --> Database Driver Class Initialized
INFO - 2023-11-18 03:37:46 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-11-18 03:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:37:46 --> Form Validation Class Initialized
INFO - 2023-11-18 03:37:46 --> Form Validation Class Initialized
INFO - 2023-11-18 03:37:46 --> Upload Class Initialized
INFO - 2023-11-18 03:37:46 --> Upload Class Initialized
ERROR - 2023-11-18 03:37:46 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:37:46 --> Model "M_auth" initialized
INFO - 2023-11-18 03:37:46 --> Config Class Initialized
INFO - 2023-11-18 03:37:46 --> Model "M_user" initialized
INFO - 2023-11-18 03:37:46 --> Hooks Class Initialized
INFO - 2023-11-18 03:37:46 --> Model "M_produk" initialized
INFO - 2023-11-18 03:37:46 --> Controller Class Initialized
DEBUG - 2023-11-18 03:37:46 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:37:46 --> Utf8 Class Initialized
INFO - 2023-11-18 03:37:46 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:37:46 --> URI Class Initialized
INFO - 2023-11-18 03:37:46 --> Final output sent to browser
INFO - 2023-11-18 03:37:46 --> Model "M_auth" initialized
INFO - 2023-11-18 03:37:46 --> Router Class Initialized
DEBUG - 2023-11-18 03:37:46 --> Total execution time: 0.0024
INFO - 2023-11-18 03:37:46 --> Output Class Initialized
INFO - 2023-11-18 03:37:46 --> Model "M_user" initialized
INFO - 2023-11-18 03:37:46 --> Security Class Initialized
INFO - 2023-11-18 03:37:46 --> Model "M_produk" initialized
DEBUG - 2023-11-18 03:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:37:46 --> Controller Class Initialized
INFO - 2023-11-18 03:37:46 --> Input Class Initialized
INFO - 2023-11-18 03:37:46 --> Language Class Initialized
INFO - 2023-11-18 03:37:46 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:37:46 --> Loader Class Initialized
INFO - 2023-11-18 03:37:46 --> Final output sent to browser
DEBUG - 2023-11-18 03:37:46 --> Total execution time: 0.0029
INFO - 2023-11-18 03:37:46 --> Helper loaded: url_helper
INFO - 2023-11-18 03:37:46 --> Helper loaded: form_helper
INFO - 2023-11-18 03:37:46 --> Helper loaded: file_helper
INFO - 2023-11-18 03:37:46 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:37:46 --> Form Validation Class Initialized
INFO - 2023-11-18 03:37:46 --> Upload Class Initialized
INFO - 2023-11-18 03:37:46 --> Model "M_auth" initialized
INFO - 2023-11-18 03:37:46 --> Model "M_user" initialized
INFO - 2023-11-18 03:37:46 --> Model "M_produk" initialized
INFO - 2023-11-18 03:37:46 --> Controller Class Initialized
INFO - 2023-11-18 03:37:46 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:37:46 --> Final output sent to browser
DEBUG - 2023-11-18 03:37:46 --> Total execution time: 0.0022
ERROR - 2023-11-18 03:38:02 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:02 --> Config Class Initialized
INFO - 2023-11-18 03:38:02 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:38:02 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:02 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:02 --> URI Class Initialized
INFO - 2023-11-18 03:38:02 --> Router Class Initialized
INFO - 2023-11-18 03:38:02 --> Output Class Initialized
INFO - 2023-11-18 03:38:02 --> Security Class Initialized
DEBUG - 2023-11-18 03:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:02 --> Input Class Initialized
INFO - 2023-11-18 03:38:02 --> Language Class Initialized
INFO - 2023-11-18 03:38:02 --> Loader Class Initialized
INFO - 2023-11-18 03:38:02 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:02 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:02 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:02 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:02 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:02 --> Upload Class Initialized
INFO - 2023-11-18 03:38:02 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:02 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:02 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:02 --> Controller Class Initialized
INFO - 2023-11-18 03:38:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:02 --> Final output sent to browser
DEBUG - 2023-11-18 03:38:02 --> Total execution time: 0.0040
ERROR - 2023-11-18 03:38:02 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:02 --> Config Class Initialized
INFO - 2023-11-18 03:38:02 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:38:02 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:02 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:02 --> URI Class Initialized
INFO - 2023-11-18 03:38:02 --> Router Class Initialized
INFO - 2023-11-18 03:38:02 --> Output Class Initialized
INFO - 2023-11-18 03:38:02 --> Security Class Initialized
DEBUG - 2023-11-18 03:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:02 --> Input Class Initialized
INFO - 2023-11-18 03:38:02 --> Language Class Initialized
INFO - 2023-11-18 03:38:02 --> Loader Class Initialized
INFO - 2023-11-18 03:38:02 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:02 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:02 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:02 --> Database Driver Class Initialized
ERROR - 2023-11-18 03:38:02 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:02 --> Config Class Initialized
INFO - 2023-11-18 03:38:02 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:38:02 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:02 --> Utf8 Class Initialized
DEBUG - 2023-11-18 03:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:02 --> URI Class Initialized
INFO - 2023-11-18 03:38:02 --> Router Class Initialized
INFO - 2023-11-18 03:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:02 --> Output Class Initialized
INFO - 2023-11-18 03:38:02 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:02 --> Security Class Initialized
INFO - 2023-11-18 03:38:02 --> Upload Class Initialized
DEBUG - 2023-11-18 03:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:02 --> Input Class Initialized
INFO - 2023-11-18 03:38:02 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:02 --> Language Class Initialized
INFO - 2023-11-18 03:38:02 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:02 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:02 --> Loader Class Initialized
INFO - 2023-11-18 03:38:02 --> Controller Class Initialized
INFO - 2023-11-18 03:38:02 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:02 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:02 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:02 --> Database Driver Class Initialized
INFO - 2023-11-18 03:38:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:02 --> Final output sent to browser
DEBUG - 2023-11-18 03:38:02 --> Total execution time: 0.0052
DEBUG - 2023-11-18 03:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:02 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:02 --> Upload Class Initialized
INFO - 2023-11-18 03:38:02 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:02 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:02 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:02 --> Controller Class Initialized
INFO - 2023-11-18 03:38:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:02 --> Final output sent to browser
DEBUG - 2023-11-18 03:38:02 --> Total execution time: 0.0036
ERROR - 2023-11-18 03:38:02 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:02 --> Config Class Initialized
INFO - 2023-11-18 03:38:02 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:38:02 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:02 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:02 --> URI Class Initialized
INFO - 2023-11-18 03:38:02 --> Router Class Initialized
INFO - 2023-11-18 03:38:02 --> Output Class Initialized
INFO - 2023-11-18 03:38:02 --> Security Class Initialized
DEBUG - 2023-11-18 03:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:02 --> Input Class Initialized
INFO - 2023-11-18 03:38:02 --> Language Class Initialized
INFO - 2023-11-18 03:38:02 --> Loader Class Initialized
INFO - 2023-11-18 03:38:02 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:02 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:02 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:02 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:02 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:02 --> Upload Class Initialized
INFO - 2023-11-18 03:38:02 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:02 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:02 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:02 --> Controller Class Initialized
INFO - 2023-11-18 03:38:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:02 --> Final output sent to browser
DEBUG - 2023-11-18 03:38:02 --> Total execution time: 0.0040
ERROR - 2023-11-18 03:38:02 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:02 --> Config Class Initialized
INFO - 2023-11-18 03:38:02 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:38:02 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:02 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:02 --> URI Class Initialized
INFO - 2023-11-18 03:38:02 --> Router Class Initialized
INFO - 2023-11-18 03:38:02 --> Output Class Initialized
INFO - 2023-11-18 03:38:02 --> Security Class Initialized
DEBUG - 2023-11-18 03:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:02 --> Input Class Initialized
INFO - 2023-11-18 03:38:02 --> Language Class Initialized
INFO - 2023-11-18 03:38:02 --> Loader Class Initialized
INFO - 2023-11-18 03:38:02 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:02 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:02 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:02 --> Database Driver Class Initialized
ERROR - 2023-11-18 03:38:02 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
DEBUG - 2023-11-18 03:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:02 --> Config Class Initialized
INFO - 2023-11-18 03:38:02 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:38:02 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:02 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:02 --> URI Class Initialized
INFO - 2023-11-18 03:38:02 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:02 --> Upload Class Initialized
INFO - 2023-11-18 03:38:02 --> Router Class Initialized
INFO - 2023-11-18 03:38:02 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:02 --> Output Class Initialized
INFO - 2023-11-18 03:38:02 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:02 --> Security Class Initialized
INFO - 2023-11-18 03:38:02 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:02 --> Controller Class Initialized
DEBUG - 2023-11-18 03:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:02 --> Input Class Initialized
INFO - 2023-11-18 03:38:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:02 --> Language Class Initialized
INFO - 2023-11-18 03:38:02 --> Final output sent to browser
DEBUG - 2023-11-18 03:38:02 --> Total execution time: 0.0026
INFO - 2023-11-18 03:38:02 --> Loader Class Initialized
INFO - 2023-11-18 03:38:02 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:02 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:02 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:02 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:02 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:02 --> Upload Class Initialized
INFO - 2023-11-18 03:38:02 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:02 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:02 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:02 --> Controller Class Initialized
INFO - 2023-11-18 03:38:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:02 --> Final output sent to browser
DEBUG - 2023-11-18 03:38:02 --> Total execution time: 0.0025
ERROR - 2023-11-18 03:38:02 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:02 --> Config Class Initialized
INFO - 2023-11-18 03:38:02 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:38:02 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:02 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:02 --> URI Class Initialized
INFO - 2023-11-18 03:38:02 --> Router Class Initialized
INFO - 2023-11-18 03:38:02 --> Output Class Initialized
INFO - 2023-11-18 03:38:02 --> Security Class Initialized
DEBUG - 2023-11-18 03:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:02 --> Input Class Initialized
INFO - 2023-11-18 03:38:02 --> Language Class Initialized
INFO - 2023-11-18 03:38:02 --> Loader Class Initialized
INFO - 2023-11-18 03:38:02 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:02 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:02 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:02 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:02 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:02 --> Upload Class Initialized
INFO - 2023-11-18 03:38:02 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:02 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:02 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:02 --> Controller Class Initialized
INFO - 2023-11-18 03:38:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:02 --> Final output sent to browser
DEBUG - 2023-11-18 03:38:02 --> Total execution time: 0.0025
ERROR - 2023-11-18 03:38:02 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:02 --> Config Class Initialized
INFO - 2023-11-18 03:38:02 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:38:02 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:02 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:02 --> URI Class Initialized
INFO - 2023-11-18 03:38:02 --> Router Class Initialized
INFO - 2023-11-18 03:38:02 --> Output Class Initialized
INFO - 2023-11-18 03:38:02 --> Security Class Initialized
DEBUG - 2023-11-18 03:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:02 --> Input Class Initialized
INFO - 2023-11-18 03:38:02 --> Language Class Initialized
INFO - 2023-11-18 03:38:02 --> Loader Class Initialized
INFO - 2023-11-18 03:38:02 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:02 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:02 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:02 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:02 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:02 --> Upload Class Initialized
INFO - 2023-11-18 03:38:02 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:02 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:02 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:02 --> Controller Class Initialized
INFO - 2023-11-18 03:38:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:02 --> Final output sent to browser
DEBUG - 2023-11-18 03:38:02 --> Total execution time: 0.0027
ERROR - 2023-11-18 03:38:02 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:02 --> Config Class Initialized
INFO - 2023-11-18 03:38:02 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:38:02 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:02 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:02 --> URI Class Initialized
INFO - 2023-11-18 03:38:02 --> Router Class Initialized
INFO - 2023-11-18 03:38:02 --> Output Class Initialized
INFO - 2023-11-18 03:38:02 --> Security Class Initialized
DEBUG - 2023-11-18 03:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:02 --> Input Class Initialized
INFO - 2023-11-18 03:38:02 --> Language Class Initialized
INFO - 2023-11-18 03:38:02 --> Loader Class Initialized
INFO - 2023-11-18 03:38:02 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:02 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:02 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:02 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:02 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:02 --> Upload Class Initialized
INFO - 2023-11-18 03:38:02 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:02 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:02 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:02 --> Controller Class Initialized
INFO - 2023-11-18 03:38:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:02 --> Final output sent to browser
DEBUG - 2023-11-18 03:38:02 --> Total execution time: 0.0026
ERROR - 2023-11-18 03:38:02 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:02 --> Config Class Initialized
INFO - 2023-11-18 03:38:02 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:38:02 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:02 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:02 --> URI Class Initialized
INFO - 2023-11-18 03:38:02 --> Router Class Initialized
INFO - 2023-11-18 03:38:02 --> Output Class Initialized
INFO - 2023-11-18 03:38:02 --> Security Class Initialized
DEBUG - 2023-11-18 03:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:02 --> Input Class Initialized
INFO - 2023-11-18 03:38:02 --> Language Class Initialized
INFO - 2023-11-18 03:38:02 --> Loader Class Initialized
INFO - 2023-11-18 03:38:02 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:02 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:02 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:02 --> Database Driver Class Initialized
ERROR - 2023-11-18 03:38:02 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:02 --> Config Class Initialized
INFO - 2023-11-18 03:38:02 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:38:02 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:02 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:02 --> URI Class Initialized
DEBUG - 2023-11-18 03:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:02 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:02 --> Upload Class Initialized
INFO - 2023-11-18 03:38:02 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:02 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:02 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:02 --> Controller Class Initialized
INFO - 2023-11-18 03:38:02 --> Router Class Initialized
INFO - 2023-11-18 03:38:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:02 --> Final output sent to browser
INFO - 2023-11-18 03:38:02 --> Output Class Initialized
DEBUG - 2023-11-18 03:38:02 --> Total execution time: 0.0034
INFO - 2023-11-18 03:38:02 --> Security Class Initialized
DEBUG - 2023-11-18 03:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:02 --> Input Class Initialized
INFO - 2023-11-18 03:38:02 --> Language Class Initialized
INFO - 2023-11-18 03:38:02 --> Loader Class Initialized
INFO - 2023-11-18 03:38:02 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:02 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:02 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:02 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:02 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:02 --> Upload Class Initialized
INFO - 2023-11-18 03:38:02 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:02 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:02 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:02 --> Controller Class Initialized
INFO - 2023-11-18 03:38:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:02 --> Final output sent to browser
DEBUG - 2023-11-18 03:38:02 --> Total execution time: 0.0040
ERROR - 2023-11-18 03:38:04 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:04 --> Config Class Initialized
INFO - 2023-11-18 03:38:04 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:38:04 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:04 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:04 --> URI Class Initialized
INFO - 2023-11-18 03:38:04 --> Router Class Initialized
INFO - 2023-11-18 03:38:04 --> Output Class Initialized
INFO - 2023-11-18 03:38:04 --> Security Class Initialized
DEBUG - 2023-11-18 03:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:04 --> Input Class Initialized
INFO - 2023-11-18 03:38:04 --> Language Class Initialized
INFO - 2023-11-18 03:38:04 --> Loader Class Initialized
INFO - 2023-11-18 03:38:04 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:04 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:04 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:04 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:04 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:04 --> Upload Class Initialized
INFO - 2023-11-18 03:38:04 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:04 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:04 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:04 --> Controller Class Initialized
INFO - 2023-11-18 03:38:04 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:04 --> Final output sent to browser
DEBUG - 2023-11-18 03:38:04 --> Total execution time: 0.0030
ERROR - 2023-11-18 03:38:17 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:17 --> Config Class Initialized
INFO - 2023-11-18 03:38:17 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:38:17 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:17 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:17 --> URI Class Initialized
INFO - 2023-11-18 03:38:17 --> Router Class Initialized
INFO - 2023-11-18 03:38:17 --> Output Class Initialized
INFO - 2023-11-18 03:38:17 --> Security Class Initialized
DEBUG - 2023-11-18 03:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:17 --> Input Class Initialized
ERROR - 2023-11-18 03:38:17 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:17 --> Language Class Initialized
INFO - 2023-11-18 03:38:17 --> Loader Class Initialized
INFO - 2023-11-18 03:38:17 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:17 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:17 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:17 --> Config Class Initialized
INFO - 2023-11-18 03:38:17 --> Database Driver Class Initialized
INFO - 2023-11-18 03:38:17 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:38:17 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:17 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:17 --> URI Class Initialized
INFO - 2023-11-18 03:38:17 --> Router Class Initialized
INFO - 2023-11-18 03:38:17 --> Output Class Initialized
DEBUG - 2023-11-18 03:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:17 --> Security Class Initialized
INFO - 2023-11-18 03:38:17 --> Form Validation Class Initialized
DEBUG - 2023-11-18 03:38:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-11-18 03:38:17 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:17 --> Input Class Initialized
INFO - 2023-11-18 03:38:17 --> Upload Class Initialized
INFO - 2023-11-18 03:38:17 --> Language Class Initialized
INFO - 2023-11-18 03:38:17 --> Config Class Initialized
INFO - 2023-11-18 03:38:17 --> Hooks Class Initialized
INFO - 2023-11-18 03:38:17 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:17 --> Loader Class Initialized
DEBUG - 2023-11-18 03:38:17 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:17 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:17 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:17 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:17 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:17 --> Controller Class Initialized
INFO - 2023-11-18 03:38:17 --> URI Class Initialized
INFO - 2023-11-18 03:38:17 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:17 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:17 --> Router Class Initialized
INFO - 2023-11-18 03:38:17 --> Final output sent to browser
DEBUG - 2023-11-18 03:38:17 --> Total execution time: 0.0039
INFO - 2023-11-18 03:38:17 --> Output Class Initialized
INFO - 2023-11-18 03:38:17 --> Database Driver Class Initialized
INFO - 2023-11-18 03:38:17 --> Security Class Initialized
DEBUG - 2023-11-18 03:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:17 --> Input Class Initialized
INFO - 2023-11-18 03:38:17 --> Language Class Initialized
INFO - 2023-11-18 03:38:17 --> Loader Class Initialized
INFO - 2023-11-18 03:38:17 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:17 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:17 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:17 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2023-11-18 03:38:17 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:17 --> Config Class Initialized
INFO - 2023-11-18 03:38:17 --> Hooks Class Initialized
INFO - 2023-11-18 03:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:17 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:17 --> Upload Class Initialized
DEBUG - 2023-11-18 03:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:17 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:17 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:17 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:17 --> Controller Class Initialized
INFO - 2023-11-18 03:38:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:17 --> Final output sent to browser
DEBUG - 2023-11-18 03:38:17 --> Total execution time: 0.0052
INFO - 2023-11-18 03:38:17 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:17 --> Upload Class Initialized
INFO - 2023-11-18 03:38:17 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:17 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:17 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:17 --> Controller Class Initialized
INFO - 2023-11-18 03:38:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:17 --> Final output sent to browser
DEBUG - 2023-11-18 03:38:17 --> Total execution time: 0.0035
DEBUG - 2023-11-18 03:38:17 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:17 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:17 --> URI Class Initialized
INFO - 2023-11-18 03:38:17 --> Router Class Initialized
INFO - 2023-11-18 03:38:17 --> Output Class Initialized
INFO - 2023-11-18 03:38:17 --> Security Class Initialized
DEBUG - 2023-11-18 03:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:17 --> Input Class Initialized
INFO - 2023-11-18 03:38:17 --> Language Class Initialized
INFO - 2023-11-18 03:38:17 --> Loader Class Initialized
INFO - 2023-11-18 03:38:17 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:17 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:17 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:17 --> Database Driver Class Initialized
ERROR - 2023-11-18 03:38:17 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:17 --> Config Class Initialized
INFO - 2023-11-18 03:38:17 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:38:17 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:17 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:17 --> URI Class Initialized
INFO - 2023-11-18 03:38:17 --> Router Class Initialized
INFO - 2023-11-18 03:38:17 --> Output Class Initialized
INFO - 2023-11-18 03:38:17 --> Security Class Initialized
DEBUG - 2023-11-18 03:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:17 --> Input Class Initialized
INFO - 2023-11-18 03:38:17 --> Language Class Initialized
DEBUG - 2023-11-18 03:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:17 --> Session: Class initialized using 'files' driver.
ERROR - 2023-11-18 03:38:17 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:17 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:17 --> Config Class Initialized
INFO - 2023-11-18 03:38:17 --> Loader Class Initialized
INFO - 2023-11-18 03:38:17 --> Upload Class Initialized
INFO - 2023-11-18 03:38:17 --> Hooks Class Initialized
INFO - 2023-11-18 03:38:17 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:17 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:17 --> Helper loaded: form_helper
DEBUG - 2023-11-18 03:38:17 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:17 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:17 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:17 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:17 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:17 --> Database Driver Class Initialized
INFO - 2023-11-18 03:38:17 --> Controller Class Initialized
INFO - 2023-11-18 03:38:17 --> URI Class Initialized
INFO - 2023-11-18 03:38:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:17 --> Router Class Initialized
INFO - 2023-11-18 03:38:17 --> Final output sent to browser
DEBUG - 2023-11-18 03:38:17 --> Total execution time: 0.0065
INFO - 2023-11-18 03:38:17 --> Output Class Initialized
INFO - 2023-11-18 03:38:17 --> Security Class Initialized
ERROR - 2023-11-18 03:38:17 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
DEBUG - 2023-11-18 03:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:17 --> Input Class Initialized
INFO - 2023-11-18 03:38:17 --> Config Class Initialized
INFO - 2023-11-18 03:38:17 --> Language Class Initialized
INFO - 2023-11-18 03:38:17 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:38:17 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:17 --> Loader Class Initialized
INFO - 2023-11-18 03:38:17 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:17 --> URI Class Initialized
INFO - 2023-11-18 03:38:17 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:17 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:17 --> Router Class Initialized
INFO - 2023-11-18 03:38:17 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:17 --> Output Class Initialized
INFO - 2023-11-18 03:38:17 --> Security Class Initialized
INFO - 2023-11-18 03:38:17 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:17 --> Input Class Initialized
INFO - 2023-11-18 03:38:17 --> Language Class Initialized
INFO - 2023-11-18 03:38:17 --> Loader Class Initialized
DEBUG - 2023-11-18 03:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:17 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:17 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:17 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:17 --> Database Driver Class Initialized
INFO - 2023-11-18 03:38:17 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:17 --> Upload Class Initialized
INFO - 2023-11-18 03:38:17 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:17 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:17 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:17 --> Controller Class Initialized
DEBUG - 2023-11-18 03:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:17 --> Final output sent to browser
DEBUG - 2023-11-18 03:38:17 --> Total execution time: 0.0037
INFO - 2023-11-18 03:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:17 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:17 --> Upload Class Initialized
INFO - 2023-11-18 03:38:17 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:17 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:17 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:17 --> Controller Class Initialized
DEBUG - 2023-11-18 03:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:17 --> Final output sent to browser
DEBUG - 2023-11-18 03:38:17 --> Total execution time: 0.0030
INFO - 2023-11-18 03:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:17 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:17 --> Upload Class Initialized
INFO - 2023-11-18 03:38:17 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:17 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:17 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:17 --> Controller Class Initialized
INFO - 2023-11-18 03:38:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:17 --> Final output sent to browser
DEBUG - 2023-11-18 03:38:17 --> Total execution time: 0.0032
ERROR - 2023-11-18 03:38:17 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:17 --> Config Class Initialized
INFO - 2023-11-18 03:38:17 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:38:17 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:17 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:17 --> URI Class Initialized
INFO - 2023-11-18 03:38:17 --> Router Class Initialized
INFO - 2023-11-18 03:38:17 --> Output Class Initialized
INFO - 2023-11-18 03:38:17 --> Security Class Initialized
DEBUG - 2023-11-18 03:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:17 --> Input Class Initialized
INFO - 2023-11-18 03:38:17 --> Language Class Initialized
INFO - 2023-11-18 03:38:17 --> Loader Class Initialized
INFO - 2023-11-18 03:38:17 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:17 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:17 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:17 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:17 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:17 --> Upload Class Initialized
INFO - 2023-11-18 03:38:17 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:17 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:17 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:17 --> Controller Class Initialized
INFO - 2023-11-18 03:38:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:17 --> Final output sent to browser
DEBUG - 2023-11-18 03:38:17 --> Total execution time: 0.0022
ERROR - 2023-11-18 03:38:18 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:18 --> Config Class Initialized
INFO - 2023-11-18 03:38:18 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:38:18 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:18 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:18 --> URI Class Initialized
INFO - 2023-11-18 03:38:18 --> Router Class Initialized
INFO - 2023-11-18 03:38:18 --> Output Class Initialized
INFO - 2023-11-18 03:38:18 --> Security Class Initialized
DEBUG - 2023-11-18 03:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:18 --> Input Class Initialized
INFO - 2023-11-18 03:38:18 --> Language Class Initialized
INFO - 2023-11-18 03:38:18 --> Loader Class Initialized
INFO - 2023-11-18 03:38:18 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:18 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:18 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:18 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2023-11-18 03:38:18 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:18 --> Config Class Initialized
INFO - 2023-11-18 03:38:18 --> Hooks Class Initialized
INFO - 2023-11-18 03:38:18 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:18 --> Upload Class Initialized
DEBUG - 2023-11-18 03:38:18 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:18 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:18 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:18 --> URI Class Initialized
INFO - 2023-11-18 03:38:18 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:18 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:18 --> Controller Class Initialized
INFO - 2023-11-18 03:38:18 --> Router Class Initialized
INFO - 2023-11-18 03:38:18 --> Output Class Initialized
INFO - 2023-11-18 03:38:18 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
ERROR - 2023-11-18 03:38:18 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:18 --> Final output sent to browser
INFO - 2023-11-18 03:38:18 --> Security Class Initialized
DEBUG - 2023-11-18 03:38:18 --> Total execution time: 0.0023
DEBUG - 2023-11-18 03:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:18 --> Config Class Initialized
INFO - 2023-11-18 03:38:18 --> Input Class Initialized
INFO - 2023-11-18 03:38:18 --> Hooks Class Initialized
INFO - 2023-11-18 03:38:18 --> Language Class Initialized
DEBUG - 2023-11-18 03:38:18 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:18 --> Loader Class Initialized
INFO - 2023-11-18 03:38:18 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:18 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:18 --> URI Class Initialized
INFO - 2023-11-18 03:38:18 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:18 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:18 --> Router Class Initialized
INFO - 2023-11-18 03:38:18 --> Database Driver Class Initialized
INFO - 2023-11-18 03:38:18 --> Output Class Initialized
INFO - 2023-11-18 03:38:18 --> Security Class Initialized
DEBUG - 2023-11-18 03:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:18 --> Input Class Initialized
INFO - 2023-11-18 03:38:18 --> Language Class Initialized
INFO - 2023-11-18 03:38:18 --> Loader Class Initialized
INFO - 2023-11-18 03:38:18 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:18 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:18 --> Helper loaded: file_helper
DEBUG - 2023-11-18 03:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:18 --> Database Driver Class Initialized
INFO - 2023-11-18 03:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:18 --> Form Validation Class Initialized
DEBUG - 2023-11-18 03:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:18 --> Upload Class Initialized
INFO - 2023-11-18 03:38:18 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:18 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:18 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:18 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:18 --> Controller Class Initialized
INFO - 2023-11-18 03:38:18 --> Upload Class Initialized
INFO - 2023-11-18 03:38:18 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:18 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:18 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:18 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:18 --> Final output sent to browser
INFO - 2023-11-18 03:38:18 --> Controller Class Initialized
DEBUG - 2023-11-18 03:38:18 --> Total execution time: 0.0029
INFO - 2023-11-18 03:38:18 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:18 --> Final output sent to browser
DEBUG - 2023-11-18 03:38:18 --> Total execution time: 0.0024
ERROR - 2023-11-18 03:38:19 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:19 --> Config Class Initialized
INFO - 2023-11-18 03:38:19 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:38:19 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:19 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:19 --> URI Class Initialized
INFO - 2023-11-18 03:38:19 --> Router Class Initialized
INFO - 2023-11-18 03:38:19 --> Output Class Initialized
INFO - 2023-11-18 03:38:19 --> Security Class Initialized
DEBUG - 2023-11-18 03:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:19 --> Input Class Initialized
INFO - 2023-11-18 03:38:19 --> Language Class Initialized
INFO - 2023-11-18 03:38:19 --> Loader Class Initialized
INFO - 2023-11-18 03:38:19 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:19 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:19 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:19 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:19 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:19 --> Upload Class Initialized
INFO - 2023-11-18 03:38:19 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:19 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:19 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:19 --> Controller Class Initialized
INFO - 2023-11-18 03:38:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:19 --> Final output sent to browser
DEBUG - 2023-11-18 03:38:19 --> Total execution time: 0.0031
ERROR - 2023-11-18 03:38:40 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:40 --> Config Class Initialized
INFO - 2023-11-18 03:38:40 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:38:40 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:40 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:40 --> URI Class Initialized
INFO - 2023-11-18 03:38:40 --> Router Class Initialized
INFO - 2023-11-18 03:38:40 --> Output Class Initialized
INFO - 2023-11-18 03:38:40 --> Security Class Initialized
DEBUG - 2023-11-18 03:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:40 --> Input Class Initialized
INFO - 2023-11-18 03:38:40 --> Language Class Initialized
INFO - 2023-11-18 03:38:40 --> Loader Class Initialized
INFO - 2023-11-18 03:38:40 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:40 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:40 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:40 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:40 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:40 --> Upload Class Initialized
INFO - 2023-11-18 03:38:40 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:40 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:40 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:40 --> Controller Class Initialized
INFO - 2023-11-18 03:38:40 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:40 --> Final output sent to browser
DEBUG - 2023-11-18 03:38:40 --> Total execution time: 0.0032
ERROR - 2023-11-18 03:38:41 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:41 --> Config Class Initialized
INFO - 2023-11-18 03:38:41 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:38:41 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:41 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:41 --> URI Class Initialized
INFO - 2023-11-18 03:38:41 --> Router Class Initialized
INFO - 2023-11-18 03:38:41 --> Output Class Initialized
INFO - 2023-11-18 03:38:41 --> Security Class Initialized
DEBUG - 2023-11-18 03:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:41 --> Input Class Initialized
INFO - 2023-11-18 03:38:41 --> Language Class Initialized
INFO - 2023-11-18 03:38:41 --> Loader Class Initialized
INFO - 2023-11-18 03:38:41 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:41 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:41 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:41 --> Database Driver Class Initialized
ERROR - 2023-11-18 03:38:41 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:41 --> Config Class Initialized
INFO - 2023-11-18 03:38:41 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:38:41 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:41 --> Utf8 Class Initialized
DEBUG - 2023-11-18 03:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:41 --> URI Class Initialized
INFO - 2023-11-18 03:38:41 --> Router Class Initialized
INFO - 2023-11-18 03:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:41 --> Output Class Initialized
INFO - 2023-11-18 03:38:41 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:41 --> Security Class Initialized
DEBUG - 2023-11-18 03:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:41 --> Upload Class Initialized
INFO - 2023-11-18 03:38:41 --> Input Class Initialized
INFO - 2023-11-18 03:38:41 --> Language Class Initialized
INFO - 2023-11-18 03:38:41 --> Model "M_auth" initialized
ERROR - 2023-11-18 03:38:41 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:41 --> Loader Class Initialized
INFO - 2023-11-18 03:38:41 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:41 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:41 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:41 --> Config Class Initialized
INFO - 2023-11-18 03:38:41 --> Controller Class Initialized
INFO - 2023-11-18 03:38:41 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:41 --> Hooks Class Initialized
INFO - 2023-11-18 03:38:41 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:41 --> Final output sent to browser
INFO - 2023-11-18 03:38:41 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:38:41 --> Total execution time: 0.0031
DEBUG - 2023-11-18 03:38:41 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:41 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:41 --> URI Class Initialized
INFO - 2023-11-18 03:38:41 --> Router Class Initialized
ERROR - 2023-11-18 03:38:41 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:41 --> Output Class Initialized
INFO - 2023-11-18 03:38:41 --> Security Class Initialized
INFO - 2023-11-18 03:38:41 --> Config Class Initialized
INFO - 2023-11-18 03:38:41 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:41 --> Input Class Initialized
INFO - 2023-11-18 03:38:41 --> Language Class Initialized
DEBUG - 2023-11-18 03:38:41 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:41 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:41 --> Loader Class Initialized
DEBUG - 2023-11-18 03:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:41 --> URI Class Initialized
INFO - 2023-11-18 03:38:41 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:41 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:41 --> Router Class Initialized
INFO - 2023-11-18 03:38:41 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:41 --> Output Class Initialized
INFO - 2023-11-18 03:38:41 --> Security Class Initialized
INFO - 2023-11-18 03:38:41 --> Database Driver Class Initialized
INFO - 2023-11-18 03:38:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2023-11-18 03:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:41 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:41 --> Input Class Initialized
INFO - 2023-11-18 03:38:41 --> Language Class Initialized
INFO - 2023-11-18 03:38:41 --> Upload Class Initialized
INFO - 2023-11-18 03:38:41 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:41 --> Loader Class Initialized
INFO - 2023-11-18 03:38:41 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:41 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:41 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:41 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:41 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:41 --> Controller Class Initialized
INFO - 2023-11-18 03:38:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:41 --> Database Driver Class Initialized
INFO - 2023-11-18 03:38:41 --> Final output sent to browser
DEBUG - 2023-11-18 03:38:41 --> Total execution time: 0.0036
DEBUG - 2023-11-18 03:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:41 --> Form Validation Class Initialized
DEBUG - 2023-11-18 03:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:41 --> Upload Class Initialized
INFO - 2023-11-18 03:38:41 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:41 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:41 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:41 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:41 --> Controller Class Initialized
INFO - 2023-11-18 03:38:41 --> Upload Class Initialized
INFO - 2023-11-18 03:38:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:41 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:41 --> Final output sent to browser
INFO - 2023-11-18 03:38:41 --> Model "M_user" initialized
DEBUG - 2023-11-18 03:38:41 --> Total execution time: 0.0041
INFO - 2023-11-18 03:38:41 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:41 --> Controller Class Initialized
INFO - 2023-11-18 03:38:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:41 --> Final output sent to browser
DEBUG - 2023-11-18 03:38:41 --> Total execution time: 0.0036
ERROR - 2023-11-18 03:38:41 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:41 --> Config Class Initialized
INFO - 2023-11-18 03:38:41 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:38:41 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:41 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:41 --> URI Class Initialized
INFO - 2023-11-18 03:38:41 --> Router Class Initialized
INFO - 2023-11-18 03:38:41 --> Output Class Initialized
INFO - 2023-11-18 03:38:41 --> Security Class Initialized
DEBUG - 2023-11-18 03:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:41 --> Input Class Initialized
INFO - 2023-11-18 03:38:41 --> Language Class Initialized
INFO - 2023-11-18 03:38:41 --> Loader Class Initialized
INFO - 2023-11-18 03:38:41 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:41 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:41 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:41 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:41 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:41 --> Upload Class Initialized
INFO - 2023-11-18 03:38:41 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:41 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:41 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:41 --> Controller Class Initialized
INFO - 2023-11-18 03:38:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:41 --> Final output sent to browser
DEBUG - 2023-11-18 03:38:41 --> Total execution time: 0.0022
ERROR - 2023-11-18 03:38:41 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:41 --> Config Class Initialized
INFO - 2023-11-18 03:38:41 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:38:41 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:41 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:41 --> URI Class Initialized
INFO - 2023-11-18 03:38:41 --> Router Class Initialized
INFO - 2023-11-18 03:38:41 --> Output Class Initialized
INFO - 2023-11-18 03:38:41 --> Security Class Initialized
DEBUG - 2023-11-18 03:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:41 --> Input Class Initialized
INFO - 2023-11-18 03:38:41 --> Language Class Initialized
INFO - 2023-11-18 03:38:41 --> Loader Class Initialized
INFO - 2023-11-18 03:38:41 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:41 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:41 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:41 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:41 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:41 --> Upload Class Initialized
INFO - 2023-11-18 03:38:41 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:41 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:41 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:41 --> Controller Class Initialized
INFO - 2023-11-18 03:38:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:41 --> Final output sent to browser
DEBUG - 2023-11-18 03:38:41 --> Total execution time: 0.0023
ERROR - 2023-11-18 03:38:42 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:42 --> Config Class Initialized
INFO - 2023-11-18 03:38:42 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:38:42 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:42 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:42 --> URI Class Initialized
INFO - 2023-11-18 03:38:42 --> Router Class Initialized
INFO - 2023-11-18 03:38:42 --> Output Class Initialized
INFO - 2023-11-18 03:38:42 --> Security Class Initialized
DEBUG - 2023-11-18 03:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:42 --> Input Class Initialized
INFO - 2023-11-18 03:38:42 --> Language Class Initialized
INFO - 2023-11-18 03:38:42 --> Loader Class Initialized
INFO - 2023-11-18 03:38:42 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:42 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:42 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:42 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:42 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:42 --> Upload Class Initialized
INFO - 2023-11-18 03:38:42 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:42 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:42 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:42 --> Controller Class Initialized
INFO - 2023-11-18 03:38:42 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:42 --> Final output sent to browser
DEBUG - 2023-11-18 03:38:42 --> Total execution time: 0.0025
ERROR - 2023-11-18 03:38:42 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:42 --> Config Class Initialized
INFO - 2023-11-18 03:38:42 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:38:42 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:42 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:42 --> URI Class Initialized
INFO - 2023-11-18 03:38:42 --> Router Class Initialized
INFO - 2023-11-18 03:38:42 --> Output Class Initialized
INFO - 2023-11-18 03:38:42 --> Security Class Initialized
DEBUG - 2023-11-18 03:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:42 --> Input Class Initialized
INFO - 2023-11-18 03:38:42 --> Language Class Initialized
INFO - 2023-11-18 03:38:42 --> Loader Class Initialized
INFO - 2023-11-18 03:38:42 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:42 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:42 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:42 --> Database Driver Class Initialized
ERROR - 2023-11-18 03:38:42 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:42 --> Config Class Initialized
INFO - 2023-11-18 03:38:42 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:38:42 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:42 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:42 --> URI Class Initialized
INFO - 2023-11-18 03:38:42 --> Router Class Initialized
INFO - 2023-11-18 03:38:42 --> Output Class Initialized
INFO - 2023-11-18 03:38:42 --> Security Class Initialized
DEBUG - 2023-11-18 03:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-11-18 03:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:42 --> Input Class Initialized
INFO - 2023-11-18 03:38:42 --> Language Class Initialized
INFO - 2023-11-18 03:38:42 --> Loader Class Initialized
INFO - 2023-11-18 03:38:42 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:42 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:42 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:42 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:42 --> Database Driver Class Initialized
INFO - 2023-11-18 03:38:42 --> Upload Class Initialized
INFO - 2023-11-18 03:38:42 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:42 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:42 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:42 --> Controller Class Initialized
INFO - 2023-11-18 03:38:42 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
DEBUG - 2023-11-18 03:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:42 --> Final output sent to browser
DEBUG - 2023-11-18 03:38:42 --> Total execution time: 0.0024
INFO - 2023-11-18 03:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:42 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:42 --> Upload Class Initialized
INFO - 2023-11-18 03:38:42 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:42 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:42 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:42 --> Controller Class Initialized
INFO - 2023-11-18 03:38:42 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:42 --> Final output sent to browser
DEBUG - 2023-11-18 03:38:42 --> Total execution time: 0.0019
ERROR - 2023-11-18 03:38:42 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:42 --> Config Class Initialized
INFO - 2023-11-18 03:38:42 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:38:42 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:42 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:42 --> URI Class Initialized
INFO - 2023-11-18 03:38:42 --> Router Class Initialized
INFO - 2023-11-18 03:38:42 --> Output Class Initialized
INFO - 2023-11-18 03:38:42 --> Security Class Initialized
DEBUG - 2023-11-18 03:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:42 --> Input Class Initialized
INFO - 2023-11-18 03:38:42 --> Language Class Initialized
INFO - 2023-11-18 03:38:42 --> Loader Class Initialized
INFO - 2023-11-18 03:38:42 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:42 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:42 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:42 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:42 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:42 --> Upload Class Initialized
INFO - 2023-11-18 03:38:42 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:42 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:42 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:42 --> Controller Class Initialized
INFO - 2023-11-18 03:38:42 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:42 --> Final output sent to browser
DEBUG - 2023-11-18 03:38:42 --> Total execution time: 0.0022
ERROR - 2023-11-18 03:38:42 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 03:38:42 --> Config Class Initialized
INFO - 2023-11-18 03:38:42 --> Hooks Class Initialized
DEBUG - 2023-11-18 03:38:42 --> UTF-8 Support Enabled
INFO - 2023-11-18 03:38:42 --> Utf8 Class Initialized
INFO - 2023-11-18 03:38:42 --> URI Class Initialized
INFO - 2023-11-18 03:38:42 --> Router Class Initialized
INFO - 2023-11-18 03:38:42 --> Output Class Initialized
INFO - 2023-11-18 03:38:42 --> Security Class Initialized
DEBUG - 2023-11-18 03:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 03:38:42 --> Input Class Initialized
INFO - 2023-11-18 03:38:42 --> Language Class Initialized
INFO - 2023-11-18 03:38:42 --> Loader Class Initialized
INFO - 2023-11-18 03:38:42 --> Helper loaded: url_helper
INFO - 2023-11-18 03:38:42 --> Helper loaded: form_helper
INFO - 2023-11-18 03:38:42 --> Helper loaded: file_helper
INFO - 2023-11-18 03:38:42 --> Database Driver Class Initialized
DEBUG - 2023-11-18 03:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 03:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 03:38:42 --> Form Validation Class Initialized
INFO - 2023-11-18 03:38:42 --> Upload Class Initialized
INFO - 2023-11-18 03:38:42 --> Model "M_auth" initialized
INFO - 2023-11-18 03:38:42 --> Model "M_user" initialized
INFO - 2023-11-18 03:38:42 --> Model "M_produk" initialized
INFO - 2023-11-18 03:38:42 --> Controller Class Initialized
INFO - 2023-11-18 03:38:42 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 03:38:42 --> Final output sent to browser
DEBUG - 2023-11-18 03:38:42 --> Total execution time: 0.0024
ERROR - 2023-11-18 05:05:17 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 05:05:17 --> Config Class Initialized
INFO - 2023-11-18 05:05:17 --> Hooks Class Initialized
DEBUG - 2023-11-18 05:05:17 --> UTF-8 Support Enabled
INFO - 2023-11-18 05:05:17 --> Utf8 Class Initialized
INFO - 2023-11-18 05:05:17 --> URI Class Initialized
INFO - 2023-11-18 05:05:17 --> Router Class Initialized
INFO - 2023-11-18 05:05:17 --> Output Class Initialized
INFO - 2023-11-18 05:05:17 --> Security Class Initialized
DEBUG - 2023-11-18 05:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 05:05:17 --> Input Class Initialized
INFO - 2023-11-18 05:05:17 --> Language Class Initialized
INFO - 2023-11-18 05:05:17 --> Loader Class Initialized
INFO - 2023-11-18 05:05:17 --> Helper loaded: url_helper
INFO - 2023-11-18 05:05:17 --> Helper loaded: form_helper
INFO - 2023-11-18 05:05:17 --> Helper loaded: file_helper
INFO - 2023-11-18 05:05:17 --> Database Driver Class Initialized
DEBUG - 2023-11-18 05:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 05:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 05:05:17 --> Form Validation Class Initialized
INFO - 2023-11-18 05:05:17 --> Upload Class Initialized
INFO - 2023-11-18 05:05:17 --> Model "M_auth" initialized
INFO - 2023-11-18 05:05:17 --> Model "M_user" initialized
INFO - 2023-11-18 05:05:17 --> Model "M_produk" initialized
INFO - 2023-11-18 05:05:17 --> Controller Class Initialized
INFO - 2023-11-18 05:05:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 05:05:17 --> Final output sent to browser
DEBUG - 2023-11-18 05:05:17 --> Total execution time: 0.0253
ERROR - 2023-11-18 05:05:21 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 05:05:21 --> Config Class Initialized
INFO - 2023-11-18 05:05:21 --> Hooks Class Initialized
DEBUG - 2023-11-18 05:05:21 --> UTF-8 Support Enabled
INFO - 2023-11-18 05:05:21 --> Utf8 Class Initialized
INFO - 2023-11-18 05:05:21 --> URI Class Initialized
DEBUG - 2023-11-18 05:05:21 --> No URI present. Default controller set.
INFO - 2023-11-18 05:05:21 --> Router Class Initialized
INFO - 2023-11-18 05:05:21 --> Output Class Initialized
INFO - 2023-11-18 05:05:21 --> Security Class Initialized
DEBUG - 2023-11-18 05:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 05:05:21 --> Input Class Initialized
INFO - 2023-11-18 05:05:21 --> Language Class Initialized
INFO - 2023-11-18 05:05:21 --> Loader Class Initialized
INFO - 2023-11-18 05:05:21 --> Helper loaded: url_helper
INFO - 2023-11-18 05:05:21 --> Helper loaded: form_helper
INFO - 2023-11-18 05:05:21 --> Helper loaded: file_helper
INFO - 2023-11-18 05:05:21 --> Database Driver Class Initialized
DEBUG - 2023-11-18 05:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 05:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 05:05:21 --> Form Validation Class Initialized
INFO - 2023-11-18 05:05:21 --> Upload Class Initialized
INFO - 2023-11-18 05:05:21 --> Model "M_auth" initialized
INFO - 2023-11-18 05:05:21 --> Model "M_user" initialized
INFO - 2023-11-18 05:05:21 --> Model "M_produk" initialized
INFO - 2023-11-18 05:05:21 --> Controller Class Initialized
INFO - 2023-11-18 05:05:21 --> Model "M_pelanggan" initialized
INFO - 2023-11-18 05:05:21 --> Model "M_produk" initialized
DEBUG - 2023-11-18 05:05:21 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-18 05:05:21 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-18 05:05:21 --> Model "M_transaksi" initialized
INFO - 2023-11-18 05:05:21 --> Model "M_bank" initialized
INFO - 2023-11-18 05:05:21 --> Model "M_pesan" initialized
DEBUG - 2023-11-18 05:05:21 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-18 05:05:21 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-18 05:05:21 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-18 05:05:21 --> Final output sent to browser
DEBUG - 2023-11-18 05:05:21 --> Total execution time: 0.0112
ERROR - 2023-11-18 09:28:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 09:28:45 --> Config Class Initialized
INFO - 2023-11-18 09:28:45 --> Hooks Class Initialized
DEBUG - 2023-11-18 09:28:45 --> UTF-8 Support Enabled
INFO - 2023-11-18 09:28:45 --> Utf8 Class Initialized
INFO - 2023-11-18 09:28:45 --> URI Class Initialized
INFO - 2023-11-18 09:28:45 --> Router Class Initialized
INFO - 2023-11-18 09:28:45 --> Output Class Initialized
INFO - 2023-11-18 09:28:45 --> Security Class Initialized
DEBUG - 2023-11-18 09:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 09:28:45 --> Input Class Initialized
INFO - 2023-11-18 09:28:45 --> Language Class Initialized
INFO - 2023-11-18 09:28:45 --> Loader Class Initialized
INFO - 2023-11-18 09:28:45 --> Helper loaded: url_helper
INFO - 2023-11-18 09:28:45 --> Helper loaded: form_helper
INFO - 2023-11-18 09:28:45 --> Helper loaded: file_helper
INFO - 2023-11-18 09:28:45 --> Database Driver Class Initialized
DEBUG - 2023-11-18 09:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 09:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 09:28:45 --> Form Validation Class Initialized
INFO - 2023-11-18 09:28:45 --> Upload Class Initialized
INFO - 2023-11-18 09:28:45 --> Model "M_auth" initialized
INFO - 2023-11-18 09:28:45 --> Model "M_user" initialized
INFO - 2023-11-18 09:28:45 --> Model "M_produk" initialized
INFO - 2023-11-18 09:28:45 --> Controller Class Initialized
INFO - 2023-11-18 09:28:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 09:28:45 --> Final output sent to browser
DEBUG - 2023-11-18 09:28:45 --> Total execution time: 0.0296
ERROR - 2023-11-18 09:29:10 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 09:29:10 --> Config Class Initialized
INFO - 2023-11-18 09:29:10 --> Hooks Class Initialized
DEBUG - 2023-11-18 09:29:10 --> UTF-8 Support Enabled
INFO - 2023-11-18 09:29:10 --> Utf8 Class Initialized
INFO - 2023-11-18 09:29:10 --> URI Class Initialized
DEBUG - 2023-11-18 09:29:10 --> No URI present. Default controller set.
INFO - 2023-11-18 09:29:10 --> Router Class Initialized
INFO - 2023-11-18 09:29:10 --> Output Class Initialized
INFO - 2023-11-18 09:29:10 --> Security Class Initialized
DEBUG - 2023-11-18 09:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 09:29:10 --> Input Class Initialized
INFO - 2023-11-18 09:29:10 --> Language Class Initialized
INFO - 2023-11-18 09:29:10 --> Loader Class Initialized
INFO - 2023-11-18 09:29:10 --> Helper loaded: url_helper
INFO - 2023-11-18 09:29:10 --> Helper loaded: form_helper
INFO - 2023-11-18 09:29:10 --> Helper loaded: file_helper
INFO - 2023-11-18 09:29:10 --> Database Driver Class Initialized
DEBUG - 2023-11-18 09:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 09:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 09:29:10 --> Form Validation Class Initialized
INFO - 2023-11-18 09:29:10 --> Upload Class Initialized
INFO - 2023-11-18 09:29:10 --> Model "M_auth" initialized
INFO - 2023-11-18 09:29:10 --> Model "M_user" initialized
INFO - 2023-11-18 09:29:10 --> Model "M_produk" initialized
INFO - 2023-11-18 09:29:10 --> Controller Class Initialized
INFO - 2023-11-18 09:29:10 --> Model "M_pelanggan" initialized
INFO - 2023-11-18 09:29:10 --> Model "M_produk" initialized
DEBUG - 2023-11-18 09:29:10 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-18 09:29:10 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-18 09:29:10 --> Model "M_transaksi" initialized
INFO - 2023-11-18 09:29:10 --> Model "M_bank" initialized
INFO - 2023-11-18 09:29:10 --> Model "M_pesan" initialized
DEBUG - 2023-11-18 09:29:10 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-18 09:29:10 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-18 09:29:10 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-18 09:29:10 --> Final output sent to browser
DEBUG - 2023-11-18 09:29:10 --> Total execution time: 0.0111
ERROR - 2023-11-18 11:37:05 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 11:37:05 --> Config Class Initialized
INFO - 2023-11-18 11:37:05 --> Hooks Class Initialized
DEBUG - 2023-11-18 11:37:05 --> UTF-8 Support Enabled
INFO - 2023-11-18 11:37:05 --> Utf8 Class Initialized
INFO - 2023-11-18 11:37:05 --> URI Class Initialized
DEBUG - 2023-11-18 11:37:05 --> No URI present. Default controller set.
INFO - 2023-11-18 11:37:05 --> Router Class Initialized
INFO - 2023-11-18 11:37:05 --> Output Class Initialized
INFO - 2023-11-18 11:37:05 --> Security Class Initialized
DEBUG - 2023-11-18 11:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 11:37:05 --> Input Class Initialized
INFO - 2023-11-18 11:37:05 --> Language Class Initialized
INFO - 2023-11-18 11:37:05 --> Loader Class Initialized
INFO - 2023-11-18 11:37:05 --> Helper loaded: url_helper
INFO - 2023-11-18 11:37:05 --> Helper loaded: form_helper
INFO - 2023-11-18 11:37:05 --> Helper loaded: file_helper
INFO - 2023-11-18 11:37:05 --> Database Driver Class Initialized
DEBUG - 2023-11-18 11:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 11:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 11:37:05 --> Form Validation Class Initialized
INFO - 2023-11-18 11:37:05 --> Upload Class Initialized
INFO - 2023-11-18 11:37:05 --> Model "M_auth" initialized
INFO - 2023-11-18 11:37:05 --> Model "M_user" initialized
INFO - 2023-11-18 11:37:05 --> Model "M_produk" initialized
INFO - 2023-11-18 11:37:05 --> Controller Class Initialized
INFO - 2023-11-18 11:37:05 --> Model "M_pelanggan" initialized
INFO - 2023-11-18 11:37:05 --> Model "M_produk" initialized
DEBUG - 2023-11-18 11:37:05 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-18 11:37:05 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-18 11:37:05 --> Model "M_transaksi" initialized
INFO - 2023-11-18 11:37:05 --> Model "M_bank" initialized
INFO - 2023-11-18 11:37:05 --> Model "M_pesan" initialized
DEBUG - 2023-11-18 11:37:05 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-18 11:37:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-18 11:37:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-18 11:37:05 --> Final output sent to browser
DEBUG - 2023-11-18 11:37:05 --> Total execution time: 0.0310
ERROR - 2023-11-18 11:44:17 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 11:44:17 --> Config Class Initialized
INFO - 2023-11-18 11:44:17 --> Hooks Class Initialized
DEBUG - 2023-11-18 11:44:17 --> UTF-8 Support Enabled
INFO - 2023-11-18 11:44:17 --> Utf8 Class Initialized
INFO - 2023-11-18 11:44:17 --> URI Class Initialized
INFO - 2023-11-18 11:44:17 --> Router Class Initialized
INFO - 2023-11-18 11:44:17 --> Output Class Initialized
INFO - 2023-11-18 11:44:17 --> Security Class Initialized
DEBUG - 2023-11-18 11:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 11:44:17 --> Input Class Initialized
INFO - 2023-11-18 11:44:17 --> Language Class Initialized
INFO - 2023-11-18 11:44:17 --> Loader Class Initialized
INFO - 2023-11-18 11:44:17 --> Helper loaded: url_helper
INFO - 2023-11-18 11:44:17 --> Helper loaded: form_helper
INFO - 2023-11-18 11:44:17 --> Helper loaded: file_helper
INFO - 2023-11-18 11:44:17 --> Database Driver Class Initialized
DEBUG - 2023-11-18 11:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 11:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 11:44:17 --> Form Validation Class Initialized
INFO - 2023-11-18 11:44:17 --> Upload Class Initialized
INFO - 2023-11-18 11:44:17 --> Model "M_auth" initialized
INFO - 2023-11-18 11:44:17 --> Model "M_user" initialized
INFO - 2023-11-18 11:44:17 --> Model "M_produk" initialized
INFO - 2023-11-18 11:44:17 --> Controller Class Initialized
INFO - 2023-11-18 11:44:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-18 11:44:17 --> Final output sent to browser
DEBUG - 2023-11-18 11:44:17 --> Total execution time: 0.0311
ERROR - 2023-11-18 11:44:25 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 11:44:25 --> Config Class Initialized
INFO - 2023-11-18 11:44:25 --> Hooks Class Initialized
DEBUG - 2023-11-18 11:44:25 --> UTF-8 Support Enabled
INFO - 2023-11-18 11:44:25 --> Utf8 Class Initialized
INFO - 2023-11-18 11:44:25 --> URI Class Initialized
DEBUG - 2023-11-18 11:44:25 --> No URI present. Default controller set.
INFO - 2023-11-18 11:44:25 --> Router Class Initialized
INFO - 2023-11-18 11:44:25 --> Output Class Initialized
INFO - 2023-11-18 11:44:25 --> Security Class Initialized
DEBUG - 2023-11-18 11:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 11:44:25 --> Input Class Initialized
INFO - 2023-11-18 11:44:25 --> Language Class Initialized
INFO - 2023-11-18 11:44:25 --> Loader Class Initialized
INFO - 2023-11-18 11:44:25 --> Helper loaded: url_helper
INFO - 2023-11-18 11:44:25 --> Helper loaded: form_helper
INFO - 2023-11-18 11:44:25 --> Helper loaded: file_helper
INFO - 2023-11-18 11:44:25 --> Database Driver Class Initialized
DEBUG - 2023-11-18 11:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 11:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 11:44:25 --> Form Validation Class Initialized
INFO - 2023-11-18 11:44:25 --> Upload Class Initialized
INFO - 2023-11-18 11:44:25 --> Model "M_auth" initialized
INFO - 2023-11-18 11:44:25 --> Model "M_user" initialized
INFO - 2023-11-18 11:44:25 --> Model "M_produk" initialized
INFO - 2023-11-18 11:44:25 --> Controller Class Initialized
INFO - 2023-11-18 11:44:25 --> Model "M_pelanggan" initialized
INFO - 2023-11-18 11:44:25 --> Model "M_produk" initialized
DEBUG - 2023-11-18 11:44:25 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-18 11:44:25 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-18 11:44:25 --> Model "M_transaksi" initialized
INFO - 2023-11-18 11:44:25 --> Model "M_bank" initialized
INFO - 2023-11-18 11:44:25 --> Model "M_pesan" initialized
DEBUG - 2023-11-18 11:44:25 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-18 11:44:25 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-18 11:44:25 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-18 11:44:25 --> Final output sent to browser
DEBUG - 2023-11-18 11:44:25 --> Total execution time: 0.0086
ERROR - 2023-11-18 12:52:27 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 12:52:27 --> Config Class Initialized
INFO - 2023-11-18 12:52:27 --> Hooks Class Initialized
DEBUG - 2023-11-18 12:52:27 --> UTF-8 Support Enabled
INFO - 2023-11-18 12:52:27 --> Utf8 Class Initialized
INFO - 2023-11-18 12:52:27 --> URI Class Initialized
DEBUG - 2023-11-18 12:52:27 --> No URI present. Default controller set.
INFO - 2023-11-18 12:52:27 --> Router Class Initialized
INFO - 2023-11-18 12:52:27 --> Output Class Initialized
INFO - 2023-11-18 12:52:27 --> Security Class Initialized
DEBUG - 2023-11-18 12:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 12:52:27 --> Input Class Initialized
INFO - 2023-11-18 12:52:27 --> Language Class Initialized
INFO - 2023-11-18 12:52:27 --> Loader Class Initialized
INFO - 2023-11-18 12:52:27 --> Helper loaded: url_helper
INFO - 2023-11-18 12:52:27 --> Helper loaded: form_helper
INFO - 2023-11-18 12:52:27 --> Helper loaded: file_helper
INFO - 2023-11-18 12:52:27 --> Database Driver Class Initialized
DEBUG - 2023-11-18 12:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 12:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 12:52:27 --> Form Validation Class Initialized
INFO - 2023-11-18 12:52:27 --> Upload Class Initialized
INFO - 2023-11-18 12:52:27 --> Model "M_auth" initialized
INFO - 2023-11-18 12:52:27 --> Model "M_user" initialized
INFO - 2023-11-18 12:52:27 --> Model "M_produk" initialized
INFO - 2023-11-18 12:52:27 --> Controller Class Initialized
INFO - 2023-11-18 12:52:27 --> Model "M_pelanggan" initialized
INFO - 2023-11-18 12:52:27 --> Model "M_produk" initialized
DEBUG - 2023-11-18 12:52:27 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-18 12:52:27 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-18 12:52:27 --> Model "M_transaksi" initialized
INFO - 2023-11-18 12:52:27 --> Model "M_bank" initialized
INFO - 2023-11-18 12:52:27 --> Model "M_pesan" initialized
DEBUG - 2023-11-18 12:52:27 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-18 12:52:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-18 12:52:27 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-18 12:52:27 --> Final output sent to browser
DEBUG - 2023-11-18 12:52:27 --> Total execution time: 0.0311
ERROR - 2023-11-18 12:53:08 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 12:53:08 --> Config Class Initialized
INFO - 2023-11-18 12:53:08 --> Hooks Class Initialized
DEBUG - 2023-11-18 12:53:08 --> UTF-8 Support Enabled
INFO - 2023-11-18 12:53:08 --> Utf8 Class Initialized
INFO - 2023-11-18 12:53:08 --> URI Class Initialized
DEBUG - 2023-11-18 12:53:08 --> No URI present. Default controller set.
INFO - 2023-11-18 12:53:08 --> Router Class Initialized
INFO - 2023-11-18 12:53:08 --> Output Class Initialized
INFO - 2023-11-18 12:53:08 --> Security Class Initialized
DEBUG - 2023-11-18 12:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 12:53:08 --> Input Class Initialized
INFO - 2023-11-18 12:53:08 --> Language Class Initialized
INFO - 2023-11-18 12:53:08 --> Loader Class Initialized
INFO - 2023-11-18 12:53:08 --> Helper loaded: url_helper
INFO - 2023-11-18 12:53:08 --> Helper loaded: form_helper
INFO - 2023-11-18 12:53:08 --> Helper loaded: file_helper
INFO - 2023-11-18 12:53:08 --> Database Driver Class Initialized
DEBUG - 2023-11-18 12:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 12:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 12:53:08 --> Form Validation Class Initialized
INFO - 2023-11-18 12:53:08 --> Upload Class Initialized
INFO - 2023-11-18 12:53:08 --> Model "M_auth" initialized
INFO - 2023-11-18 12:53:08 --> Model "M_user" initialized
INFO - 2023-11-18 12:53:08 --> Model "M_produk" initialized
INFO - 2023-11-18 12:53:08 --> Controller Class Initialized
INFO - 2023-11-18 12:53:08 --> Model "M_pelanggan" initialized
INFO - 2023-11-18 12:53:08 --> Model "M_produk" initialized
DEBUG - 2023-11-18 12:53:08 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-18 12:53:08 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-18 12:53:08 --> Model "M_transaksi" initialized
INFO - 2023-11-18 12:53:08 --> Model "M_bank" initialized
INFO - 2023-11-18 12:53:08 --> Model "M_pesan" initialized
DEBUG - 2023-11-18 12:53:08 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-18 12:53:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-18 12:53:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-18 12:53:08 --> Final output sent to browser
DEBUG - 2023-11-18 12:53:08 --> Total execution time: 0.0039
ERROR - 2023-11-18 14:19:19 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 14:19:19 --> Config Class Initialized
INFO - 2023-11-18 14:19:19 --> Hooks Class Initialized
DEBUG - 2023-11-18 14:19:19 --> UTF-8 Support Enabled
INFO - 2023-11-18 14:19:19 --> Utf8 Class Initialized
INFO - 2023-11-18 14:19:19 --> URI Class Initialized
DEBUG - 2023-11-18 14:19:19 --> No URI present. Default controller set.
INFO - 2023-11-18 14:19:19 --> Router Class Initialized
INFO - 2023-11-18 14:19:19 --> Output Class Initialized
INFO - 2023-11-18 14:19:19 --> Security Class Initialized
DEBUG - 2023-11-18 14:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 14:19:19 --> Input Class Initialized
INFO - 2023-11-18 14:19:19 --> Language Class Initialized
INFO - 2023-11-18 14:19:19 --> Loader Class Initialized
INFO - 2023-11-18 14:19:19 --> Helper loaded: url_helper
INFO - 2023-11-18 14:19:19 --> Helper loaded: form_helper
INFO - 2023-11-18 14:19:19 --> Helper loaded: file_helper
INFO - 2023-11-18 14:19:19 --> Database Driver Class Initialized
DEBUG - 2023-11-18 14:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 14:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 14:19:19 --> Form Validation Class Initialized
INFO - 2023-11-18 14:19:19 --> Upload Class Initialized
INFO - 2023-11-18 14:19:19 --> Model "M_auth" initialized
INFO - 2023-11-18 14:19:19 --> Model "M_user" initialized
INFO - 2023-11-18 14:19:19 --> Model "M_produk" initialized
INFO - 2023-11-18 14:19:19 --> Controller Class Initialized
INFO - 2023-11-18 14:19:19 --> Model "M_pelanggan" initialized
INFO - 2023-11-18 14:19:19 --> Model "M_produk" initialized
DEBUG - 2023-11-18 14:19:19 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-18 14:19:19 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-18 14:19:19 --> Model "M_transaksi" initialized
INFO - 2023-11-18 14:19:19 --> Model "M_bank" initialized
INFO - 2023-11-18 14:19:19 --> Model "M_pesan" initialized
DEBUG - 2023-11-18 14:19:19 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-18 14:19:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-18 14:19:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-18 14:19:19 --> Final output sent to browser
DEBUG - 2023-11-18 14:19:19 --> Total execution time: 0.0304
ERROR - 2023-11-18 16:24:53 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 16:24:53 --> Config Class Initialized
INFO - 2023-11-18 16:24:53 --> Hooks Class Initialized
DEBUG - 2023-11-18 16:24:53 --> UTF-8 Support Enabled
INFO - 2023-11-18 16:24:53 --> Utf8 Class Initialized
INFO - 2023-11-18 16:24:53 --> URI Class Initialized
DEBUG - 2023-11-18 16:24:53 --> No URI present. Default controller set.
INFO - 2023-11-18 16:24:53 --> Router Class Initialized
INFO - 2023-11-18 16:24:53 --> Output Class Initialized
INFO - 2023-11-18 16:24:53 --> Security Class Initialized
DEBUG - 2023-11-18 16:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 16:24:53 --> Input Class Initialized
INFO - 2023-11-18 16:24:53 --> Language Class Initialized
INFO - 2023-11-18 16:24:53 --> Loader Class Initialized
INFO - 2023-11-18 16:24:53 --> Helper loaded: url_helper
INFO - 2023-11-18 16:24:53 --> Helper loaded: form_helper
INFO - 2023-11-18 16:24:53 --> Helper loaded: file_helper
INFO - 2023-11-18 16:24:53 --> Database Driver Class Initialized
DEBUG - 2023-11-18 16:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 16:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 16:24:53 --> Form Validation Class Initialized
INFO - 2023-11-18 16:24:53 --> Upload Class Initialized
INFO - 2023-11-18 16:24:53 --> Model "M_auth" initialized
INFO - 2023-11-18 16:24:53 --> Model "M_user" initialized
INFO - 2023-11-18 16:24:53 --> Model "M_produk" initialized
INFO - 2023-11-18 16:24:53 --> Controller Class Initialized
INFO - 2023-11-18 16:24:53 --> Model "M_pelanggan" initialized
INFO - 2023-11-18 16:24:53 --> Model "M_produk" initialized
DEBUG - 2023-11-18 16:24:53 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-18 16:24:53 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-18 16:24:53 --> Model "M_transaksi" initialized
INFO - 2023-11-18 16:24:53 --> Model "M_bank" initialized
INFO - 2023-11-18 16:24:53 --> Model "M_pesan" initialized
DEBUG - 2023-11-18 16:24:53 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-18 16:24:53 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-18 16:24:53 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-18 16:24:53 --> Final output sent to browser
DEBUG - 2023-11-18 16:24:53 --> Total execution time: 0.0314
ERROR - 2023-11-18 18:51:07 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 18:51:07 --> Config Class Initialized
INFO - 2023-11-18 18:51:07 --> Hooks Class Initialized
DEBUG - 2023-11-18 18:51:07 --> UTF-8 Support Enabled
INFO - 2023-11-18 18:51:07 --> Utf8 Class Initialized
INFO - 2023-11-18 18:51:07 --> URI Class Initialized
DEBUG - 2023-11-18 18:51:07 --> No URI present. Default controller set.
INFO - 2023-11-18 18:51:07 --> Router Class Initialized
INFO - 2023-11-18 18:51:07 --> Output Class Initialized
INFO - 2023-11-18 18:51:07 --> Security Class Initialized
DEBUG - 2023-11-18 18:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 18:51:07 --> Input Class Initialized
INFO - 2023-11-18 18:51:07 --> Language Class Initialized
INFO - 2023-11-18 18:51:07 --> Loader Class Initialized
INFO - 2023-11-18 18:51:07 --> Helper loaded: url_helper
INFO - 2023-11-18 18:51:07 --> Helper loaded: form_helper
INFO - 2023-11-18 18:51:07 --> Helper loaded: file_helper
INFO - 2023-11-18 18:51:07 --> Database Driver Class Initialized
DEBUG - 2023-11-18 18:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 18:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 18:51:07 --> Form Validation Class Initialized
INFO - 2023-11-18 18:51:07 --> Upload Class Initialized
INFO - 2023-11-18 18:51:07 --> Model "M_auth" initialized
INFO - 2023-11-18 18:51:07 --> Model "M_user" initialized
INFO - 2023-11-18 18:51:07 --> Model "M_produk" initialized
INFO - 2023-11-18 18:51:07 --> Controller Class Initialized
INFO - 2023-11-18 18:51:07 --> Model "M_pelanggan" initialized
INFO - 2023-11-18 18:51:07 --> Model "M_produk" initialized
DEBUG - 2023-11-18 18:51:07 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-18 18:51:07 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-18 18:51:07 --> Model "M_transaksi" initialized
INFO - 2023-11-18 18:51:07 --> Model "M_bank" initialized
INFO - 2023-11-18 18:51:07 --> Model "M_pesan" initialized
DEBUG - 2023-11-18 18:51:07 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-18 18:51:07 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-18 18:51:07 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-18 18:51:07 --> Final output sent to browser
DEBUG - 2023-11-18 18:51:07 --> Total execution time: 0.0307
ERROR - 2023-11-18 19:15:47 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 19:15:47 --> Config Class Initialized
INFO - 2023-11-18 19:15:47 --> Hooks Class Initialized
DEBUG - 2023-11-18 19:15:47 --> UTF-8 Support Enabled
INFO - 2023-11-18 19:15:47 --> Utf8 Class Initialized
INFO - 2023-11-18 19:15:47 --> URI Class Initialized
DEBUG - 2023-11-18 19:15:47 --> No URI present. Default controller set.
INFO - 2023-11-18 19:15:47 --> Router Class Initialized
INFO - 2023-11-18 19:15:47 --> Output Class Initialized
INFO - 2023-11-18 19:15:47 --> Security Class Initialized
DEBUG - 2023-11-18 19:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 19:15:47 --> Input Class Initialized
INFO - 2023-11-18 19:15:47 --> Language Class Initialized
INFO - 2023-11-18 19:15:47 --> Loader Class Initialized
INFO - 2023-11-18 19:15:47 --> Helper loaded: url_helper
INFO - 2023-11-18 19:15:47 --> Helper loaded: form_helper
INFO - 2023-11-18 19:15:47 --> Helper loaded: file_helper
INFO - 2023-11-18 19:15:47 --> Database Driver Class Initialized
DEBUG - 2023-11-18 19:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 19:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 19:15:47 --> Form Validation Class Initialized
INFO - 2023-11-18 19:15:47 --> Upload Class Initialized
INFO - 2023-11-18 19:15:47 --> Model "M_auth" initialized
INFO - 2023-11-18 19:15:47 --> Model "M_user" initialized
INFO - 2023-11-18 19:15:47 --> Model "M_produk" initialized
INFO - 2023-11-18 19:15:47 --> Controller Class Initialized
INFO - 2023-11-18 19:15:47 --> Model "M_pelanggan" initialized
INFO - 2023-11-18 19:15:47 --> Model "M_produk" initialized
DEBUG - 2023-11-18 19:15:47 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-18 19:15:47 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-18 19:15:47 --> Model "M_transaksi" initialized
INFO - 2023-11-18 19:15:47 --> Model "M_bank" initialized
INFO - 2023-11-18 19:15:47 --> Model "M_pesan" initialized
DEBUG - 2023-11-18 19:15:47 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-18 19:15:47 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-18 19:15:47 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-18 19:15:47 --> Final output sent to browser
DEBUG - 2023-11-18 19:15:47 --> Total execution time: 0.0302
ERROR - 2023-11-18 21:33:15 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-18 21:33:15 --> Config Class Initialized
INFO - 2023-11-18 21:33:15 --> Hooks Class Initialized
DEBUG - 2023-11-18 21:33:15 --> UTF-8 Support Enabled
INFO - 2023-11-18 21:33:15 --> Utf8 Class Initialized
INFO - 2023-11-18 21:33:15 --> URI Class Initialized
DEBUG - 2023-11-18 21:33:15 --> No URI present. Default controller set.
INFO - 2023-11-18 21:33:15 --> Router Class Initialized
INFO - 2023-11-18 21:33:15 --> Output Class Initialized
INFO - 2023-11-18 21:33:15 --> Security Class Initialized
DEBUG - 2023-11-18 21:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-18 21:33:15 --> Input Class Initialized
INFO - 2023-11-18 21:33:15 --> Language Class Initialized
INFO - 2023-11-18 21:33:15 --> Loader Class Initialized
INFO - 2023-11-18 21:33:15 --> Helper loaded: url_helper
INFO - 2023-11-18 21:33:15 --> Helper loaded: form_helper
INFO - 2023-11-18 21:33:15 --> Helper loaded: file_helper
INFO - 2023-11-18 21:33:15 --> Database Driver Class Initialized
DEBUG - 2023-11-18 21:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-18 21:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-18 21:33:15 --> Form Validation Class Initialized
INFO - 2023-11-18 21:33:15 --> Upload Class Initialized
INFO - 2023-11-18 21:33:15 --> Model "M_auth" initialized
INFO - 2023-11-18 21:33:15 --> Model "M_user" initialized
INFO - 2023-11-18 21:33:15 --> Model "M_produk" initialized
INFO - 2023-11-18 21:33:15 --> Controller Class Initialized
INFO - 2023-11-18 21:33:15 --> Model "M_pelanggan" initialized
INFO - 2023-11-18 21:33:15 --> Model "M_produk" initialized
DEBUG - 2023-11-18 21:33:15 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-18 21:33:15 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-18 21:33:15 --> Model "M_transaksi" initialized
INFO - 2023-11-18 21:33:15 --> Model "M_bank" initialized
INFO - 2023-11-18 21:33:15 --> Model "M_pesan" initialized
DEBUG - 2023-11-18 21:33:15 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-18 21:33:15 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-18 21:33:15 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-18 21:33:15 --> Final output sent to browser
DEBUG - 2023-11-18 21:33:15 --> Total execution time: 0.0307
