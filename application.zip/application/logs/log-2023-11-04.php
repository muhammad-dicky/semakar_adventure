<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-04 01:46:46 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 01:46:46 --> Config Class Initialized
INFO - 2023-11-04 01:46:46 --> Hooks Class Initialized
DEBUG - 2023-11-04 01:46:46 --> UTF-8 Support Enabled
INFO - 2023-11-04 01:46:46 --> Utf8 Class Initialized
INFO - 2023-11-04 01:46:46 --> URI Class Initialized
INFO - 2023-11-04 01:46:46 --> Router Class Initialized
INFO - 2023-11-04 01:46:46 --> Output Class Initialized
INFO - 2023-11-04 01:46:46 --> Security Class Initialized
DEBUG - 2023-11-04 01:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 01:46:46 --> Input Class Initialized
INFO - 2023-11-04 01:46:46 --> Language Class Initialized
INFO - 2023-11-04 01:46:46 --> Loader Class Initialized
INFO - 2023-11-04 01:46:46 --> Helper loaded: url_helper
INFO - 2023-11-04 01:46:46 --> Helper loaded: form_helper
INFO - 2023-11-04 01:46:46 --> Helper loaded: file_helper
INFO - 2023-11-04 01:46:46 --> Database Driver Class Initialized
DEBUG - 2023-11-04 01:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 01:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 01:46:46 --> Form Validation Class Initialized
INFO - 2023-11-04 01:46:46 --> Upload Class Initialized
INFO - 2023-11-04 01:46:46 --> Model "M_auth" initialized
INFO - 2023-11-04 01:46:46 --> Model "M_user" initialized
INFO - 2023-11-04 01:46:46 --> Model "M_produk" initialized
INFO - 2023-11-04 01:46:46 --> Controller Class Initialized
INFO - 2023-11-04 01:46:46 --> Model "M_pelanggan" initialized
INFO - 2023-11-04 01:46:46 --> Model "M_produk" initialized
DEBUG - 2023-11-04 01:46:46 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-04 01:46:46 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-04 01:46:46 --> Model "M_transaksi" initialized
INFO - 2023-11-04 01:46:46 --> Model "M_bank" initialized
INFO - 2023-11-04 01:46:46 --> Model "M_pesan" initialized
DEBUG - 2023-11-04 01:46:46 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-04 01:46:46 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-04 01:46:46 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-04 01:46:46 --> Final output sent to browser
DEBUG - 2023-11-04 01:46:46 --> Total execution time: 0.0441
ERROR - 2023-11-04 03:20:10 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 03:20:10 --> Config Class Initialized
INFO - 2023-11-04 03:20:10 --> Hooks Class Initialized
DEBUG - 2023-11-04 03:20:10 --> UTF-8 Support Enabled
INFO - 2023-11-04 03:20:10 --> Utf8 Class Initialized
INFO - 2023-11-04 03:20:10 --> URI Class Initialized
DEBUG - 2023-11-04 03:20:10 --> No URI present. Default controller set.
INFO - 2023-11-04 03:20:10 --> Router Class Initialized
INFO - 2023-11-04 03:20:10 --> Output Class Initialized
INFO - 2023-11-04 03:20:10 --> Security Class Initialized
DEBUG - 2023-11-04 03:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 03:20:10 --> Input Class Initialized
INFO - 2023-11-04 03:20:10 --> Language Class Initialized
INFO - 2023-11-04 03:20:10 --> Loader Class Initialized
INFO - 2023-11-04 03:20:10 --> Helper loaded: url_helper
INFO - 2023-11-04 03:20:10 --> Helper loaded: form_helper
INFO - 2023-11-04 03:20:10 --> Helper loaded: file_helper
INFO - 2023-11-04 03:20:10 --> Database Driver Class Initialized
DEBUG - 2023-11-04 03:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 03:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 03:20:10 --> Form Validation Class Initialized
INFO - 2023-11-04 03:20:10 --> Upload Class Initialized
INFO - 2023-11-04 03:20:10 --> Model "M_auth" initialized
INFO - 2023-11-04 03:20:10 --> Model "M_user" initialized
INFO - 2023-11-04 03:20:10 --> Model "M_produk" initialized
INFO - 2023-11-04 03:20:10 --> Controller Class Initialized
INFO - 2023-11-04 03:20:10 --> Model "M_pelanggan" initialized
INFO - 2023-11-04 03:20:10 --> Model "M_produk" initialized
DEBUG - 2023-11-04 03:20:10 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-04 03:20:10 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-04 03:20:10 --> Model "M_transaksi" initialized
INFO - 2023-11-04 03:20:10 --> Model "M_bank" initialized
INFO - 2023-11-04 03:20:10 --> Model "M_pesan" initialized
DEBUG - 2023-11-04 03:20:10 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-04 03:20:10 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-04 03:20:10 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-04 03:20:10 --> Final output sent to browser
DEBUG - 2023-11-04 03:20:10 --> Total execution time: 0.0436
ERROR - 2023-11-04 03:33:19 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 03:33:19 --> Config Class Initialized
INFO - 2023-11-04 03:33:19 --> Hooks Class Initialized
DEBUG - 2023-11-04 03:33:19 --> UTF-8 Support Enabled
INFO - 2023-11-04 03:33:19 --> Utf8 Class Initialized
INFO - 2023-11-04 03:33:19 --> URI Class Initialized
INFO - 2023-11-04 03:33:19 --> Router Class Initialized
INFO - 2023-11-04 03:33:19 --> Output Class Initialized
INFO - 2023-11-04 03:33:19 --> Security Class Initialized
DEBUG - 2023-11-04 03:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 03:33:19 --> Input Class Initialized
INFO - 2023-11-04 03:33:19 --> Language Class Initialized
INFO - 2023-11-04 03:33:19 --> Loader Class Initialized
INFO - 2023-11-04 03:33:19 --> Helper loaded: url_helper
INFO - 2023-11-04 03:33:19 --> Helper loaded: form_helper
INFO - 2023-11-04 03:33:19 --> Helper loaded: file_helper
INFO - 2023-11-04 03:33:19 --> Database Driver Class Initialized
DEBUG - 2023-11-04 03:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 03:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 03:33:19 --> Form Validation Class Initialized
INFO - 2023-11-04 03:33:19 --> Upload Class Initialized
INFO - 2023-11-04 03:33:19 --> Model "M_auth" initialized
INFO - 2023-11-04 03:33:19 --> Model "M_user" initialized
INFO - 2023-11-04 03:33:19 --> Model "M_produk" initialized
INFO - 2023-11-04 03:33:19 --> Controller Class Initialized
INFO - 2023-11-04 03:33:19 --> Model "M_pelanggan" initialized
INFO - 2023-11-04 03:33:19 --> Model "M_produk" initialized
DEBUG - 2023-11-04 03:33:19 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-04 03:33:19 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-04 03:33:19 --> Model "M_transaksi" initialized
INFO - 2023-11-04 03:33:19 --> Model "M_bank" initialized
INFO - 2023-11-04 03:33:19 --> Model "M_pesan" initialized
DEBUG - 2023-11-04 03:33:19 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
ERROR - 2023-11-04 03:33:19 --> Severity: Warning --> Attempt to read property "nama_merek" on null /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_kategori_detail.php 112
INFO - 2023-11-04 03:33:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-04 03:33:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_kategori_detail.php
INFO - 2023-11-04 03:33:19 --> Final output sent to browser
DEBUG - 2023-11-04 03:33:19 --> Total execution time: 0.0469
ERROR - 2023-11-04 04:23:15 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 04:23:15 --> Config Class Initialized
INFO - 2023-11-04 04:23:15 --> Hooks Class Initialized
DEBUG - 2023-11-04 04:23:15 --> UTF-8 Support Enabled
INFO - 2023-11-04 04:23:15 --> Utf8 Class Initialized
INFO - 2023-11-04 04:23:15 --> URI Class Initialized
INFO - 2023-11-04 04:23:15 --> Router Class Initialized
INFO - 2023-11-04 04:23:15 --> Output Class Initialized
INFO - 2023-11-04 04:23:15 --> Security Class Initialized
DEBUG - 2023-11-04 04:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 04:23:15 --> Input Class Initialized
INFO - 2023-11-04 04:23:15 --> Language Class Initialized
INFO - 2023-11-04 04:23:15 --> Loader Class Initialized
INFO - 2023-11-04 04:23:15 --> Helper loaded: url_helper
INFO - 2023-11-04 04:23:15 --> Helper loaded: form_helper
INFO - 2023-11-04 04:23:15 --> Helper loaded: file_helper
INFO - 2023-11-04 04:23:15 --> Database Driver Class Initialized
DEBUG - 2023-11-04 04:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 04:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 04:23:15 --> Form Validation Class Initialized
INFO - 2023-11-04 04:23:15 --> Upload Class Initialized
INFO - 2023-11-04 04:23:15 --> Model "M_auth" initialized
INFO - 2023-11-04 04:23:15 --> Model "M_user" initialized
INFO - 2023-11-04 04:23:15 --> Model "M_produk" initialized
INFO - 2023-11-04 04:23:15 --> Controller Class Initialized
INFO - 2023-11-04 04:23:15 --> Model "M_pelanggan" initialized
INFO - 2023-11-04 04:23:15 --> Model "M_produk" initialized
DEBUG - 2023-11-04 04:23:15 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-04 04:23:15 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-04 04:23:15 --> Model "M_transaksi" initialized
INFO - 2023-11-04 04:23:15 --> Model "M_bank" initialized
INFO - 2023-11-04 04:23:15 --> Model "M_pesan" initialized
DEBUG - 2023-11-04 04:23:15 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-04 04:23:16 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-04 04:23:16 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_kategori_detail.php
INFO - 2023-11-04 04:23:16 --> Final output sent to browser
DEBUG - 2023-11-04 04:23:16 --> Total execution time: 0.0478
ERROR - 2023-11-04 06:05:14 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 06:05:14 --> Config Class Initialized
INFO - 2023-11-04 06:05:14 --> Hooks Class Initialized
DEBUG - 2023-11-04 06:05:14 --> UTF-8 Support Enabled
INFO - 2023-11-04 06:05:14 --> Utf8 Class Initialized
INFO - 2023-11-04 06:05:14 --> URI Class Initialized
DEBUG - 2023-11-04 06:05:14 --> No URI present. Default controller set.
INFO - 2023-11-04 06:05:14 --> Router Class Initialized
INFO - 2023-11-04 06:05:14 --> Output Class Initialized
INFO - 2023-11-04 06:05:14 --> Security Class Initialized
DEBUG - 2023-11-04 06:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 06:05:14 --> Input Class Initialized
INFO - 2023-11-04 06:05:14 --> Language Class Initialized
INFO - 2023-11-04 06:05:14 --> Loader Class Initialized
INFO - 2023-11-04 06:05:14 --> Helper loaded: url_helper
INFO - 2023-11-04 06:05:14 --> Helper loaded: form_helper
INFO - 2023-11-04 06:05:14 --> Helper loaded: file_helper
INFO - 2023-11-04 06:05:14 --> Database Driver Class Initialized
DEBUG - 2023-11-04 06:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 06:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 06:05:14 --> Form Validation Class Initialized
INFO - 2023-11-04 06:05:14 --> Upload Class Initialized
INFO - 2023-11-04 06:05:14 --> Model "M_auth" initialized
INFO - 2023-11-04 06:05:14 --> Model "M_user" initialized
INFO - 2023-11-04 06:05:14 --> Model "M_produk" initialized
INFO - 2023-11-04 06:05:14 --> Controller Class Initialized
INFO - 2023-11-04 06:05:14 --> Model "M_pelanggan" initialized
INFO - 2023-11-04 06:05:14 --> Model "M_produk" initialized
DEBUG - 2023-11-04 06:05:14 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-04 06:05:14 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-04 06:05:14 --> Model "M_transaksi" initialized
INFO - 2023-11-04 06:05:14 --> Model "M_bank" initialized
INFO - 2023-11-04 06:05:14 --> Model "M_pesan" initialized
DEBUG - 2023-11-04 06:05:14 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-04 06:05:14 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-04 06:05:14 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-04 06:05:14 --> Final output sent to browser
DEBUG - 2023-11-04 06:05:14 --> Total execution time: 0.0578
ERROR - 2023-11-04 12:17:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 12:17:45 --> Config Class Initialized
INFO - 2023-11-04 12:17:45 --> Hooks Class Initialized
DEBUG - 2023-11-04 12:17:45 --> UTF-8 Support Enabled
INFO - 2023-11-04 12:17:45 --> Utf8 Class Initialized
INFO - 2023-11-04 12:17:45 --> URI Class Initialized
DEBUG - 2023-11-04 12:17:45 --> No URI present. Default controller set.
INFO - 2023-11-04 12:17:45 --> Router Class Initialized
INFO - 2023-11-04 12:17:45 --> Output Class Initialized
INFO - 2023-11-04 12:17:45 --> Security Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 12:17:45 --> Input Class Initialized
INFO - 2023-11-04 12:17:45 --> Language Class Initialized
INFO - 2023-11-04 12:17:45 --> Loader Class Initialized
INFO - 2023-11-04 12:17:45 --> Helper loaded: url_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: form_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: file_helper
INFO - 2023-11-04 12:17:45 --> Database Driver Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 12:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 12:17:45 --> Form Validation Class Initialized
INFO - 2023-11-04 12:17:45 --> Upload Class Initialized
INFO - 2023-11-04 12:17:45 --> Model "M_auth" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_user" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_produk" initialized
INFO - 2023-11-04 12:17:45 --> Controller Class Initialized
INFO - 2023-11-04 12:17:45 --> Model "M_pelanggan" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_produk" initialized
DEBUG - 2023-11-04 12:17:45 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-04 12:17:45 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-04 12:17:45 --> Model "M_transaksi" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_bank" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_pesan" initialized
DEBUG - 2023-11-04 12:17:45 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-04 12:17:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-04 12:17:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-04 12:17:45 --> Final output sent to browser
DEBUG - 2023-11-04 12:17:45 --> Total execution time: 0.0415
ERROR - 2023-11-04 12:17:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 12:17:45 --> Config Class Initialized
INFO - 2023-11-04 12:17:45 --> Hooks Class Initialized
DEBUG - 2023-11-04 12:17:45 --> UTF-8 Support Enabled
INFO - 2023-11-04 12:17:45 --> Utf8 Class Initialized
INFO - 2023-11-04 12:17:45 --> URI Class Initialized
INFO - 2023-11-04 12:17:45 --> Router Class Initialized
INFO - 2023-11-04 12:17:45 --> Output Class Initialized
INFO - 2023-11-04 12:17:45 --> Security Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 12:17:45 --> Input Class Initialized
INFO - 2023-11-04 12:17:45 --> Language Class Initialized
INFO - 2023-11-04 12:17:45 --> Loader Class Initialized
INFO - 2023-11-04 12:17:45 --> Helper loaded: url_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: form_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: file_helper
INFO - 2023-11-04 12:17:45 --> Database Driver Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 12:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 12:17:45 --> Form Validation Class Initialized
INFO - 2023-11-04 12:17:45 --> Upload Class Initialized
INFO - 2023-11-04 12:17:45 --> Model "M_auth" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_user" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_produk" initialized
INFO - 2023-11-04 12:17:45 --> Controller Class Initialized
INFO - 2023-11-04 12:17:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-04 12:17:45 --> Final output sent to browser
DEBUG - 2023-11-04 12:17:45 --> Total execution time: 0.0028
ERROR - 2023-11-04 12:17:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 12:17:45 --> Config Class Initialized
INFO - 2023-11-04 12:17:45 --> Hooks Class Initialized
DEBUG - 2023-11-04 12:17:45 --> UTF-8 Support Enabled
INFO - 2023-11-04 12:17:45 --> Utf8 Class Initialized
INFO - 2023-11-04 12:17:45 --> URI Class Initialized
INFO - 2023-11-04 12:17:45 --> Router Class Initialized
INFO - 2023-11-04 12:17:45 --> Output Class Initialized
INFO - 2023-11-04 12:17:45 --> Security Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 12:17:45 --> Input Class Initialized
INFO - 2023-11-04 12:17:45 --> Language Class Initialized
INFO - 2023-11-04 12:17:45 --> Loader Class Initialized
INFO - 2023-11-04 12:17:45 --> Helper loaded: url_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: form_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: file_helper
INFO - 2023-11-04 12:17:45 --> Database Driver Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 12:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 12:17:45 --> Form Validation Class Initialized
INFO - 2023-11-04 12:17:45 --> Upload Class Initialized
INFO - 2023-11-04 12:17:45 --> Model "M_auth" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_user" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_produk" initialized
INFO - 2023-11-04 12:17:45 --> Controller Class Initialized
INFO - 2023-11-04 12:17:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-04 12:17:45 --> Final output sent to browser
DEBUG - 2023-11-04 12:17:45 --> Total execution time: 0.0016
ERROR - 2023-11-04 12:17:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 12:17:45 --> Config Class Initialized
INFO - 2023-11-04 12:17:45 --> Hooks Class Initialized
DEBUG - 2023-11-04 12:17:45 --> UTF-8 Support Enabled
INFO - 2023-11-04 12:17:45 --> Utf8 Class Initialized
INFO - 2023-11-04 12:17:45 --> URI Class Initialized
DEBUG - 2023-11-04 12:17:45 --> No URI present. Default controller set.
INFO - 2023-11-04 12:17:45 --> Router Class Initialized
INFO - 2023-11-04 12:17:45 --> Output Class Initialized
INFO - 2023-11-04 12:17:45 --> Security Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 12:17:45 --> Input Class Initialized
INFO - 2023-11-04 12:17:45 --> Language Class Initialized
INFO - 2023-11-04 12:17:45 --> Loader Class Initialized
INFO - 2023-11-04 12:17:45 --> Helper loaded: url_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: form_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: file_helper
INFO - 2023-11-04 12:17:45 --> Database Driver Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 12:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 12:17:45 --> Form Validation Class Initialized
INFO - 2023-11-04 12:17:45 --> Upload Class Initialized
INFO - 2023-11-04 12:17:45 --> Model "M_auth" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_user" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_produk" initialized
INFO - 2023-11-04 12:17:45 --> Controller Class Initialized
INFO - 2023-11-04 12:17:45 --> Model "M_pelanggan" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_produk" initialized
DEBUG - 2023-11-04 12:17:45 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-04 12:17:45 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-04 12:17:45 --> Model "M_transaksi" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_bank" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_pesan" initialized
DEBUG - 2023-11-04 12:17:45 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-04 12:17:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-04 12:17:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-04 12:17:45 --> Final output sent to browser
DEBUG - 2023-11-04 12:17:45 --> Total execution time: 0.0022
ERROR - 2023-11-04 12:17:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 12:17:45 --> Config Class Initialized
INFO - 2023-11-04 12:17:45 --> Hooks Class Initialized
DEBUG - 2023-11-04 12:17:45 --> UTF-8 Support Enabled
INFO - 2023-11-04 12:17:45 --> Utf8 Class Initialized
INFO - 2023-11-04 12:17:45 --> URI Class Initialized
INFO - 2023-11-04 12:17:45 --> Router Class Initialized
INFO - 2023-11-04 12:17:45 --> Output Class Initialized
INFO - 2023-11-04 12:17:45 --> Security Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 12:17:45 --> Input Class Initialized
INFO - 2023-11-04 12:17:45 --> Language Class Initialized
INFO - 2023-11-04 12:17:45 --> Loader Class Initialized
INFO - 2023-11-04 12:17:45 --> Helper loaded: url_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: form_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: file_helper
INFO - 2023-11-04 12:17:45 --> Database Driver Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 12:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 12:17:45 --> Form Validation Class Initialized
INFO - 2023-11-04 12:17:45 --> Upload Class Initialized
INFO - 2023-11-04 12:17:45 --> Model "M_auth" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_user" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_produk" initialized
INFO - 2023-11-04 12:17:45 --> Controller Class Initialized
INFO - 2023-11-04 12:17:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-04 12:17:45 --> Final output sent to browser
DEBUG - 2023-11-04 12:17:45 --> Total execution time: 0.0020
ERROR - 2023-11-04 12:17:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 12:17:45 --> Config Class Initialized
INFO - 2023-11-04 12:17:45 --> Hooks Class Initialized
DEBUG - 2023-11-04 12:17:45 --> UTF-8 Support Enabled
INFO - 2023-11-04 12:17:45 --> Utf8 Class Initialized
INFO - 2023-11-04 12:17:45 --> URI Class Initialized
INFO - 2023-11-04 12:17:45 --> Router Class Initialized
INFO - 2023-11-04 12:17:45 --> Output Class Initialized
INFO - 2023-11-04 12:17:45 --> Security Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 12:17:45 --> Input Class Initialized
INFO - 2023-11-04 12:17:45 --> Language Class Initialized
INFO - 2023-11-04 12:17:45 --> Loader Class Initialized
INFO - 2023-11-04 12:17:45 --> Helper loaded: url_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: form_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: file_helper
INFO - 2023-11-04 12:17:45 --> Database Driver Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 12:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 12:17:45 --> Form Validation Class Initialized
INFO - 2023-11-04 12:17:45 --> Upload Class Initialized
INFO - 2023-11-04 12:17:45 --> Model "M_auth" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_user" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_produk" initialized
INFO - 2023-11-04 12:17:45 --> Controller Class Initialized
INFO - 2023-11-04 12:17:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-04 12:17:45 --> Final output sent to browser
DEBUG - 2023-11-04 12:17:45 --> Total execution time: 0.0019
ERROR - 2023-11-04 12:17:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 12:17:45 --> Config Class Initialized
INFO - 2023-11-04 12:17:45 --> Hooks Class Initialized
DEBUG - 2023-11-04 12:17:45 --> UTF-8 Support Enabled
INFO - 2023-11-04 12:17:45 --> Utf8 Class Initialized
INFO - 2023-11-04 12:17:45 --> URI Class Initialized
INFO - 2023-11-04 12:17:45 --> Router Class Initialized
INFO - 2023-11-04 12:17:45 --> Output Class Initialized
INFO - 2023-11-04 12:17:45 --> Security Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 12:17:45 --> Input Class Initialized
INFO - 2023-11-04 12:17:45 --> Language Class Initialized
INFO - 2023-11-04 12:17:45 --> Loader Class Initialized
INFO - 2023-11-04 12:17:45 --> Helper loaded: url_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: form_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: file_helper
INFO - 2023-11-04 12:17:45 --> Database Driver Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 12:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 12:17:45 --> Form Validation Class Initialized
INFO - 2023-11-04 12:17:45 --> Upload Class Initialized
INFO - 2023-11-04 12:17:45 --> Model "M_auth" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_user" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_produk" initialized
INFO - 2023-11-04 12:17:45 --> Controller Class Initialized
INFO - 2023-11-04 12:17:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-04 12:17:45 --> Final output sent to browser
DEBUG - 2023-11-04 12:17:45 --> Total execution time: 0.0016
ERROR - 2023-11-04 12:17:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 12:17:45 --> Config Class Initialized
INFO - 2023-11-04 12:17:45 --> Hooks Class Initialized
DEBUG - 2023-11-04 12:17:45 --> UTF-8 Support Enabled
INFO - 2023-11-04 12:17:45 --> Utf8 Class Initialized
INFO - 2023-11-04 12:17:45 --> URI Class Initialized
INFO - 2023-11-04 12:17:45 --> Router Class Initialized
INFO - 2023-11-04 12:17:45 --> Output Class Initialized
INFO - 2023-11-04 12:17:45 --> Security Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 12:17:45 --> Input Class Initialized
INFO - 2023-11-04 12:17:45 --> Language Class Initialized
INFO - 2023-11-04 12:17:45 --> Loader Class Initialized
INFO - 2023-11-04 12:17:45 --> Helper loaded: url_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: form_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: file_helper
INFO - 2023-11-04 12:17:45 --> Database Driver Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 12:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 12:17:45 --> Form Validation Class Initialized
INFO - 2023-11-04 12:17:45 --> Upload Class Initialized
INFO - 2023-11-04 12:17:45 --> Model "M_auth" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_user" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_produk" initialized
INFO - 2023-11-04 12:17:45 --> Controller Class Initialized
INFO - 2023-11-04 12:17:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-04 12:17:45 --> Final output sent to browser
DEBUG - 2023-11-04 12:17:45 --> Total execution time: 0.0017
ERROR - 2023-11-04 12:17:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 12:17:45 --> Config Class Initialized
INFO - 2023-11-04 12:17:45 --> Hooks Class Initialized
DEBUG - 2023-11-04 12:17:45 --> UTF-8 Support Enabled
INFO - 2023-11-04 12:17:45 --> Utf8 Class Initialized
INFO - 2023-11-04 12:17:45 --> URI Class Initialized
INFO - 2023-11-04 12:17:45 --> Router Class Initialized
INFO - 2023-11-04 12:17:45 --> Output Class Initialized
INFO - 2023-11-04 12:17:45 --> Security Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 12:17:45 --> Input Class Initialized
INFO - 2023-11-04 12:17:45 --> Language Class Initialized
INFO - 2023-11-04 12:17:45 --> Loader Class Initialized
INFO - 2023-11-04 12:17:45 --> Helper loaded: url_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: form_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: file_helper
INFO - 2023-11-04 12:17:45 --> Database Driver Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 12:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 12:17:45 --> Form Validation Class Initialized
INFO - 2023-11-04 12:17:45 --> Upload Class Initialized
INFO - 2023-11-04 12:17:45 --> Model "M_auth" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_user" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_produk" initialized
INFO - 2023-11-04 12:17:45 --> Controller Class Initialized
INFO - 2023-11-04 12:17:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-04 12:17:45 --> Final output sent to browser
DEBUG - 2023-11-04 12:17:45 --> Total execution time: 0.0021
ERROR - 2023-11-04 12:17:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 12:17:45 --> Config Class Initialized
INFO - 2023-11-04 12:17:45 --> Hooks Class Initialized
DEBUG - 2023-11-04 12:17:45 --> UTF-8 Support Enabled
INFO - 2023-11-04 12:17:45 --> Utf8 Class Initialized
INFO - 2023-11-04 12:17:45 --> URI Class Initialized
INFO - 2023-11-04 12:17:45 --> Router Class Initialized
INFO - 2023-11-04 12:17:45 --> Output Class Initialized
INFO - 2023-11-04 12:17:45 --> Security Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 12:17:45 --> Input Class Initialized
INFO - 2023-11-04 12:17:45 --> Language Class Initialized
INFO - 2023-11-04 12:17:45 --> Loader Class Initialized
INFO - 2023-11-04 12:17:45 --> Helper loaded: url_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: form_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: file_helper
INFO - 2023-11-04 12:17:45 --> Database Driver Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 12:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 12:17:45 --> Form Validation Class Initialized
INFO - 2023-11-04 12:17:45 --> Upload Class Initialized
INFO - 2023-11-04 12:17:45 --> Model "M_auth" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_user" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_produk" initialized
INFO - 2023-11-04 12:17:45 --> Controller Class Initialized
INFO - 2023-11-04 12:17:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-04 12:17:45 --> Final output sent to browser
DEBUG - 2023-11-04 12:17:45 --> Total execution time: 0.0018
ERROR - 2023-11-04 12:17:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 12:17:45 --> Config Class Initialized
INFO - 2023-11-04 12:17:45 --> Hooks Class Initialized
DEBUG - 2023-11-04 12:17:45 --> UTF-8 Support Enabled
INFO - 2023-11-04 12:17:45 --> Utf8 Class Initialized
INFO - 2023-11-04 12:17:45 --> URI Class Initialized
INFO - 2023-11-04 12:17:45 --> Router Class Initialized
INFO - 2023-11-04 12:17:45 --> Output Class Initialized
INFO - 2023-11-04 12:17:45 --> Security Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 12:17:45 --> Input Class Initialized
INFO - 2023-11-04 12:17:45 --> Language Class Initialized
INFO - 2023-11-04 12:17:45 --> Loader Class Initialized
INFO - 2023-11-04 12:17:45 --> Helper loaded: url_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: form_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: file_helper
INFO - 2023-11-04 12:17:45 --> Database Driver Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 12:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 12:17:45 --> Form Validation Class Initialized
INFO - 2023-11-04 12:17:45 --> Upload Class Initialized
INFO - 2023-11-04 12:17:45 --> Model "M_auth" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_user" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_produk" initialized
INFO - 2023-11-04 12:17:45 --> Controller Class Initialized
INFO - 2023-11-04 12:17:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-04 12:17:45 --> Final output sent to browser
DEBUG - 2023-11-04 12:17:45 --> Total execution time: 0.0016
ERROR - 2023-11-04 12:17:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 12:17:45 --> Config Class Initialized
INFO - 2023-11-04 12:17:45 --> Hooks Class Initialized
DEBUG - 2023-11-04 12:17:45 --> UTF-8 Support Enabled
INFO - 2023-11-04 12:17:45 --> Utf8 Class Initialized
INFO - 2023-11-04 12:17:45 --> URI Class Initialized
INFO - 2023-11-04 12:17:45 --> Router Class Initialized
INFO - 2023-11-04 12:17:45 --> Output Class Initialized
INFO - 2023-11-04 12:17:45 --> Security Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 12:17:45 --> Input Class Initialized
INFO - 2023-11-04 12:17:45 --> Language Class Initialized
INFO - 2023-11-04 12:17:45 --> Loader Class Initialized
INFO - 2023-11-04 12:17:45 --> Helper loaded: url_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: form_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: file_helper
INFO - 2023-11-04 12:17:45 --> Database Driver Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 12:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 12:17:45 --> Form Validation Class Initialized
INFO - 2023-11-04 12:17:45 --> Upload Class Initialized
INFO - 2023-11-04 12:17:45 --> Model "M_auth" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_user" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_produk" initialized
INFO - 2023-11-04 12:17:45 --> Controller Class Initialized
INFO - 2023-11-04 12:17:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-04 12:17:45 --> Final output sent to browser
DEBUG - 2023-11-04 12:17:45 --> Total execution time: 0.0019
ERROR - 2023-11-04 12:17:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 12:17:45 --> Config Class Initialized
INFO - 2023-11-04 12:17:45 --> Hooks Class Initialized
DEBUG - 2023-11-04 12:17:45 --> UTF-8 Support Enabled
INFO - 2023-11-04 12:17:45 --> Utf8 Class Initialized
INFO - 2023-11-04 12:17:45 --> URI Class Initialized
INFO - 2023-11-04 12:17:45 --> Router Class Initialized
INFO - 2023-11-04 12:17:45 --> Output Class Initialized
INFO - 2023-11-04 12:17:45 --> Security Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 12:17:45 --> Input Class Initialized
INFO - 2023-11-04 12:17:45 --> Language Class Initialized
INFO - 2023-11-04 12:17:45 --> Loader Class Initialized
INFO - 2023-11-04 12:17:45 --> Helper loaded: url_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: form_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: file_helper
INFO - 2023-11-04 12:17:45 --> Database Driver Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 12:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 12:17:45 --> Form Validation Class Initialized
INFO - 2023-11-04 12:17:45 --> Upload Class Initialized
INFO - 2023-11-04 12:17:45 --> Model "M_auth" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_user" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_produk" initialized
INFO - 2023-11-04 12:17:45 --> Controller Class Initialized
INFO - 2023-11-04 12:17:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-04 12:17:45 --> Final output sent to browser
DEBUG - 2023-11-04 12:17:45 --> Total execution time: 0.0018
ERROR - 2023-11-04 12:17:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 12:17:45 --> Config Class Initialized
INFO - 2023-11-04 12:17:45 --> Hooks Class Initialized
DEBUG - 2023-11-04 12:17:45 --> UTF-8 Support Enabled
INFO - 2023-11-04 12:17:45 --> Utf8 Class Initialized
INFO - 2023-11-04 12:17:45 --> URI Class Initialized
INFO - 2023-11-04 12:17:45 --> Router Class Initialized
INFO - 2023-11-04 12:17:45 --> Output Class Initialized
INFO - 2023-11-04 12:17:45 --> Security Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 12:17:45 --> Input Class Initialized
INFO - 2023-11-04 12:17:45 --> Language Class Initialized
INFO - 2023-11-04 12:17:45 --> Loader Class Initialized
INFO - 2023-11-04 12:17:45 --> Helper loaded: url_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: form_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: file_helper
INFO - 2023-11-04 12:17:45 --> Database Driver Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 12:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 12:17:45 --> Form Validation Class Initialized
INFO - 2023-11-04 12:17:45 --> Upload Class Initialized
INFO - 2023-11-04 12:17:45 --> Model "M_auth" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_user" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_produk" initialized
INFO - 2023-11-04 12:17:45 --> Controller Class Initialized
INFO - 2023-11-04 12:17:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-04 12:17:45 --> Final output sent to browser
DEBUG - 2023-11-04 12:17:45 --> Total execution time: 0.0016
ERROR - 2023-11-04 12:17:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 12:17:45 --> Config Class Initialized
INFO - 2023-11-04 12:17:45 --> Hooks Class Initialized
DEBUG - 2023-11-04 12:17:45 --> UTF-8 Support Enabled
INFO - 2023-11-04 12:17:45 --> Utf8 Class Initialized
INFO - 2023-11-04 12:17:45 --> URI Class Initialized
INFO - 2023-11-04 12:17:45 --> Router Class Initialized
INFO - 2023-11-04 12:17:45 --> Output Class Initialized
INFO - 2023-11-04 12:17:45 --> Security Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 12:17:45 --> Input Class Initialized
INFO - 2023-11-04 12:17:45 --> Language Class Initialized
INFO - 2023-11-04 12:17:45 --> Loader Class Initialized
INFO - 2023-11-04 12:17:45 --> Helper loaded: url_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: form_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: file_helper
INFO - 2023-11-04 12:17:45 --> Database Driver Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 12:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 12:17:45 --> Form Validation Class Initialized
INFO - 2023-11-04 12:17:45 --> Upload Class Initialized
INFO - 2023-11-04 12:17:45 --> Model "M_auth" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_user" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_produk" initialized
INFO - 2023-11-04 12:17:45 --> Controller Class Initialized
INFO - 2023-11-04 12:17:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-04 12:17:45 --> Final output sent to browser
DEBUG - 2023-11-04 12:17:45 --> Total execution time: 0.0019
ERROR - 2023-11-04 12:17:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 12:17:45 --> Config Class Initialized
INFO - 2023-11-04 12:17:45 --> Hooks Class Initialized
DEBUG - 2023-11-04 12:17:45 --> UTF-8 Support Enabled
INFO - 2023-11-04 12:17:45 --> Utf8 Class Initialized
INFO - 2023-11-04 12:17:45 --> URI Class Initialized
INFO - 2023-11-04 12:17:45 --> Router Class Initialized
INFO - 2023-11-04 12:17:45 --> Output Class Initialized
INFO - 2023-11-04 12:17:45 --> Security Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 12:17:45 --> Input Class Initialized
INFO - 2023-11-04 12:17:45 --> Language Class Initialized
INFO - 2023-11-04 12:17:45 --> Loader Class Initialized
INFO - 2023-11-04 12:17:45 --> Helper loaded: url_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: form_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: file_helper
INFO - 2023-11-04 12:17:45 --> Database Driver Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 12:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 12:17:45 --> Form Validation Class Initialized
INFO - 2023-11-04 12:17:45 --> Upload Class Initialized
INFO - 2023-11-04 12:17:45 --> Model "M_auth" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_user" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_produk" initialized
INFO - 2023-11-04 12:17:45 --> Controller Class Initialized
INFO - 2023-11-04 12:17:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-04 12:17:45 --> Final output sent to browser
DEBUG - 2023-11-04 12:17:45 --> Total execution time: 0.0016
ERROR - 2023-11-04 12:17:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 12:17:45 --> Config Class Initialized
INFO - 2023-11-04 12:17:45 --> Hooks Class Initialized
DEBUG - 2023-11-04 12:17:45 --> UTF-8 Support Enabled
INFO - 2023-11-04 12:17:45 --> Utf8 Class Initialized
INFO - 2023-11-04 12:17:45 --> URI Class Initialized
INFO - 2023-11-04 12:17:45 --> Router Class Initialized
INFO - 2023-11-04 12:17:45 --> Output Class Initialized
INFO - 2023-11-04 12:17:45 --> Security Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 12:17:45 --> Input Class Initialized
INFO - 2023-11-04 12:17:45 --> Language Class Initialized
INFO - 2023-11-04 12:17:45 --> Loader Class Initialized
INFO - 2023-11-04 12:17:45 --> Helper loaded: url_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: form_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: file_helper
INFO - 2023-11-04 12:17:45 --> Database Driver Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 12:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 12:17:45 --> Form Validation Class Initialized
INFO - 2023-11-04 12:17:45 --> Upload Class Initialized
INFO - 2023-11-04 12:17:45 --> Model "M_auth" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_user" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_produk" initialized
INFO - 2023-11-04 12:17:45 --> Controller Class Initialized
INFO - 2023-11-04 12:17:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-04 12:17:45 --> Final output sent to browser
DEBUG - 2023-11-04 12:17:45 --> Total execution time: 0.0014
ERROR - 2023-11-04 12:17:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 12:17:45 --> Config Class Initialized
INFO - 2023-11-04 12:17:45 --> Hooks Class Initialized
DEBUG - 2023-11-04 12:17:45 --> UTF-8 Support Enabled
INFO - 2023-11-04 12:17:45 --> Utf8 Class Initialized
INFO - 2023-11-04 12:17:45 --> URI Class Initialized
INFO - 2023-11-04 12:17:45 --> Router Class Initialized
INFO - 2023-11-04 12:17:45 --> Output Class Initialized
INFO - 2023-11-04 12:17:45 --> Security Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 12:17:45 --> Input Class Initialized
INFO - 2023-11-04 12:17:45 --> Language Class Initialized
INFO - 2023-11-04 12:17:45 --> Loader Class Initialized
INFO - 2023-11-04 12:17:45 --> Helper loaded: url_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: form_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: file_helper
INFO - 2023-11-04 12:17:45 --> Database Driver Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 12:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 12:17:45 --> Form Validation Class Initialized
INFO - 2023-11-04 12:17:45 --> Upload Class Initialized
INFO - 2023-11-04 12:17:45 --> Model "M_auth" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_user" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_produk" initialized
INFO - 2023-11-04 12:17:45 --> Controller Class Initialized
INFO - 2023-11-04 12:17:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-04 12:17:45 --> Final output sent to browser
DEBUG - 2023-11-04 12:17:45 --> Total execution time: 0.0015
ERROR - 2023-11-04 12:17:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 12:17:45 --> Config Class Initialized
INFO - 2023-11-04 12:17:45 --> Hooks Class Initialized
DEBUG - 2023-11-04 12:17:45 --> UTF-8 Support Enabled
INFO - 2023-11-04 12:17:45 --> Utf8 Class Initialized
INFO - 2023-11-04 12:17:45 --> URI Class Initialized
INFO - 2023-11-04 12:17:45 --> Router Class Initialized
INFO - 2023-11-04 12:17:45 --> Output Class Initialized
INFO - 2023-11-04 12:17:45 --> Security Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 12:17:45 --> Input Class Initialized
INFO - 2023-11-04 12:17:45 --> Language Class Initialized
INFO - 2023-11-04 12:17:45 --> Loader Class Initialized
INFO - 2023-11-04 12:17:45 --> Helper loaded: url_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: form_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: file_helper
INFO - 2023-11-04 12:17:45 --> Database Driver Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 12:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 12:17:45 --> Form Validation Class Initialized
INFO - 2023-11-04 12:17:45 --> Upload Class Initialized
INFO - 2023-11-04 12:17:45 --> Model "M_auth" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_user" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_produk" initialized
INFO - 2023-11-04 12:17:45 --> Controller Class Initialized
INFO - 2023-11-04 12:17:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-04 12:17:45 --> Final output sent to browser
DEBUG - 2023-11-04 12:17:45 --> Total execution time: 0.0014
ERROR - 2023-11-04 12:17:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 12:17:45 --> Config Class Initialized
INFO - 2023-11-04 12:17:45 --> Hooks Class Initialized
DEBUG - 2023-11-04 12:17:45 --> UTF-8 Support Enabled
INFO - 2023-11-04 12:17:45 --> Utf8 Class Initialized
INFO - 2023-11-04 12:17:45 --> URI Class Initialized
INFO - 2023-11-04 12:17:45 --> Router Class Initialized
INFO - 2023-11-04 12:17:45 --> Output Class Initialized
INFO - 2023-11-04 12:17:45 --> Security Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 12:17:45 --> Input Class Initialized
INFO - 2023-11-04 12:17:45 --> Language Class Initialized
INFO - 2023-11-04 12:17:45 --> Loader Class Initialized
INFO - 2023-11-04 12:17:45 --> Helper loaded: url_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: form_helper
INFO - 2023-11-04 12:17:45 --> Helper loaded: file_helper
INFO - 2023-11-04 12:17:45 --> Database Driver Class Initialized
DEBUG - 2023-11-04 12:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 12:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 12:17:45 --> Form Validation Class Initialized
INFO - 2023-11-04 12:17:45 --> Upload Class Initialized
INFO - 2023-11-04 12:17:45 --> Model "M_auth" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_user" initialized
INFO - 2023-11-04 12:17:45 --> Model "M_produk" initialized
INFO - 2023-11-04 12:17:45 --> Controller Class Initialized
INFO - 2023-11-04 12:17:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-04 12:17:45 --> Final output sent to browser
DEBUG - 2023-11-04 12:17:45 --> Total execution time: 0.0018
ERROR - 2023-11-04 13:39:31 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 13:39:31 --> Config Class Initialized
INFO - 2023-11-04 13:39:31 --> Hooks Class Initialized
DEBUG - 2023-11-04 13:39:31 --> UTF-8 Support Enabled
INFO - 2023-11-04 13:39:31 --> Utf8 Class Initialized
INFO - 2023-11-04 13:39:31 --> URI Class Initialized
DEBUG - 2023-11-04 13:39:31 --> No URI present. Default controller set.
INFO - 2023-11-04 13:39:31 --> Router Class Initialized
INFO - 2023-11-04 13:39:31 --> Output Class Initialized
INFO - 2023-11-04 13:39:31 --> Security Class Initialized
DEBUG - 2023-11-04 13:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 13:39:31 --> Input Class Initialized
INFO - 2023-11-04 13:39:31 --> Language Class Initialized
INFO - 2023-11-04 13:39:31 --> Loader Class Initialized
INFO - 2023-11-04 13:39:31 --> Helper loaded: url_helper
INFO - 2023-11-04 13:39:31 --> Helper loaded: form_helper
INFO - 2023-11-04 13:39:31 --> Helper loaded: file_helper
INFO - 2023-11-04 13:39:31 --> Database Driver Class Initialized
DEBUG - 2023-11-04 13:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 13:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 13:39:31 --> Form Validation Class Initialized
INFO - 2023-11-04 13:39:31 --> Upload Class Initialized
INFO - 2023-11-04 13:39:31 --> Model "M_auth" initialized
INFO - 2023-11-04 13:39:31 --> Model "M_user" initialized
INFO - 2023-11-04 13:39:31 --> Model "M_produk" initialized
INFO - 2023-11-04 13:39:31 --> Controller Class Initialized
INFO - 2023-11-04 13:39:31 --> Model "M_pelanggan" initialized
INFO - 2023-11-04 13:39:31 --> Model "M_produk" initialized
DEBUG - 2023-11-04 13:39:31 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-04 13:39:31 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-04 13:39:31 --> Model "M_transaksi" initialized
INFO - 2023-11-04 13:39:31 --> Model "M_bank" initialized
INFO - 2023-11-04 13:39:31 --> Model "M_pesan" initialized
DEBUG - 2023-11-04 13:39:31 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-04 13:39:31 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-04 13:39:31 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-04 13:39:31 --> Final output sent to browser
DEBUG - 2023-11-04 13:39:31 --> Total execution time: 0.0421
ERROR - 2023-11-04 14:16:15 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 14:16:15 --> Config Class Initialized
INFO - 2023-11-04 14:16:15 --> Hooks Class Initialized
DEBUG - 2023-11-04 14:16:15 --> UTF-8 Support Enabled
INFO - 2023-11-04 14:16:15 --> Utf8 Class Initialized
INFO - 2023-11-04 14:16:15 --> URI Class Initialized
INFO - 2023-11-04 14:16:15 --> Router Class Initialized
INFO - 2023-11-04 14:16:15 --> Output Class Initialized
INFO - 2023-11-04 14:16:15 --> Security Class Initialized
DEBUG - 2023-11-04 14:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 14:16:15 --> Input Class Initialized
INFO - 2023-11-04 14:16:15 --> Language Class Initialized
INFO - 2023-11-04 14:16:15 --> Loader Class Initialized
INFO - 2023-11-04 14:16:15 --> Helper loaded: url_helper
INFO - 2023-11-04 14:16:15 --> Helper loaded: form_helper
INFO - 2023-11-04 14:16:15 --> Helper loaded: file_helper
INFO - 2023-11-04 14:16:15 --> Database Driver Class Initialized
DEBUG - 2023-11-04 14:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 14:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 14:16:15 --> Form Validation Class Initialized
INFO - 2023-11-04 14:16:15 --> Upload Class Initialized
INFO - 2023-11-04 14:16:15 --> Model "M_auth" initialized
INFO - 2023-11-04 14:16:15 --> Model "M_user" initialized
INFO - 2023-11-04 14:16:15 --> Model "M_produk" initialized
INFO - 2023-11-04 14:16:15 --> Controller Class Initialized
INFO - 2023-11-04 14:16:15 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-04 14:16:15 --> Final output sent to browser
DEBUG - 2023-11-04 14:16:15 --> Total execution time: 0.0499
ERROR - 2023-11-04 14:16:15 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 14:16:15 --> Config Class Initialized
INFO - 2023-11-04 14:16:15 --> Hooks Class Initialized
DEBUG - 2023-11-04 14:16:15 --> UTF-8 Support Enabled
INFO - 2023-11-04 14:16:15 --> Utf8 Class Initialized
INFO - 2023-11-04 14:16:15 --> URI Class Initialized
INFO - 2023-11-04 14:16:15 --> Router Class Initialized
INFO - 2023-11-04 14:16:15 --> Output Class Initialized
INFO - 2023-11-04 14:16:15 --> Security Class Initialized
DEBUG - 2023-11-04 14:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 14:16:15 --> Input Class Initialized
INFO - 2023-11-04 14:16:15 --> Language Class Initialized
INFO - 2023-11-04 14:16:15 --> Loader Class Initialized
INFO - 2023-11-04 14:16:15 --> Helper loaded: url_helper
INFO - 2023-11-04 14:16:15 --> Helper loaded: form_helper
INFO - 2023-11-04 14:16:15 --> Helper loaded: file_helper
INFO - 2023-11-04 14:16:15 --> Database Driver Class Initialized
DEBUG - 2023-11-04 14:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 14:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 14:16:15 --> Form Validation Class Initialized
INFO - 2023-11-04 14:16:15 --> Upload Class Initialized
INFO - 2023-11-04 14:16:15 --> Model "M_auth" initialized
INFO - 2023-11-04 14:16:15 --> Model "M_user" initialized
INFO - 2023-11-04 14:16:15 --> Model "M_produk" initialized
INFO - 2023-11-04 14:16:15 --> Controller Class Initialized
INFO - 2023-11-04 14:16:15 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-04 14:16:15 --> Final output sent to browser
DEBUG - 2023-11-04 14:16:15 --> Total execution time: 0.0033
ERROR - 2023-11-04 14:16:16 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 14:16:16 --> Config Class Initialized
INFO - 2023-11-04 14:16:16 --> Hooks Class Initialized
DEBUG - 2023-11-04 14:16:16 --> UTF-8 Support Enabled
INFO - 2023-11-04 14:16:16 --> Utf8 Class Initialized
INFO - 2023-11-04 14:16:16 --> URI Class Initialized
INFO - 2023-11-04 14:16:16 --> Router Class Initialized
INFO - 2023-11-04 14:16:16 --> Output Class Initialized
INFO - 2023-11-04 14:16:16 --> Security Class Initialized
DEBUG - 2023-11-04 14:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 14:16:16 --> Input Class Initialized
INFO - 2023-11-04 14:16:16 --> Language Class Initialized
INFO - 2023-11-04 14:16:16 --> Loader Class Initialized
INFO - 2023-11-04 14:16:16 --> Helper loaded: url_helper
INFO - 2023-11-04 14:16:16 --> Helper loaded: form_helper
INFO - 2023-11-04 14:16:16 --> Helper loaded: file_helper
INFO - 2023-11-04 14:16:16 --> Database Driver Class Initialized
DEBUG - 2023-11-04 14:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 14:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 14:16:16 --> Form Validation Class Initialized
INFO - 2023-11-04 14:16:16 --> Upload Class Initialized
INFO - 2023-11-04 14:16:16 --> Model "M_auth" initialized
INFO - 2023-11-04 14:16:16 --> Model "M_user" initialized
INFO - 2023-11-04 14:16:16 --> Model "M_produk" initialized
INFO - 2023-11-04 14:16:16 --> Controller Class Initialized
INFO - 2023-11-04 14:16:16 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-04 14:16:16 --> Final output sent to browser
DEBUG - 2023-11-04 14:16:16 --> Total execution time: 0.0032
ERROR - 2023-11-04 14:16:17 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 14:16:17 --> Config Class Initialized
INFO - 2023-11-04 14:16:17 --> Hooks Class Initialized
DEBUG - 2023-11-04 14:16:17 --> UTF-8 Support Enabled
INFO - 2023-11-04 14:16:17 --> Utf8 Class Initialized
INFO - 2023-11-04 14:16:17 --> URI Class Initialized
INFO - 2023-11-04 14:16:17 --> Router Class Initialized
INFO - 2023-11-04 14:16:17 --> Output Class Initialized
INFO - 2023-11-04 14:16:17 --> Security Class Initialized
DEBUG - 2023-11-04 14:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 14:16:17 --> Input Class Initialized
INFO - 2023-11-04 14:16:17 --> Language Class Initialized
INFO - 2023-11-04 14:16:17 --> Loader Class Initialized
INFO - 2023-11-04 14:16:17 --> Helper loaded: url_helper
INFO - 2023-11-04 14:16:17 --> Helper loaded: form_helper
INFO - 2023-11-04 14:16:17 --> Helper loaded: file_helper
INFO - 2023-11-04 14:16:17 --> Database Driver Class Initialized
DEBUG - 2023-11-04 14:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 14:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 14:16:17 --> Form Validation Class Initialized
INFO - 2023-11-04 14:16:17 --> Upload Class Initialized
INFO - 2023-11-04 14:16:17 --> Model "M_auth" initialized
INFO - 2023-11-04 14:16:17 --> Model "M_user" initialized
INFO - 2023-11-04 14:16:17 --> Model "M_produk" initialized
INFO - 2023-11-04 14:16:17 --> Controller Class Initialized
INFO - 2023-11-04 14:16:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-04 14:16:17 --> Final output sent to browser
DEBUG - 2023-11-04 14:16:17 --> Total execution time: 0.0026
ERROR - 2023-11-04 16:13:30 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 16:13:30 --> Config Class Initialized
INFO - 2023-11-04 16:13:30 --> Hooks Class Initialized
DEBUG - 2023-11-04 16:13:30 --> UTF-8 Support Enabled
INFO - 2023-11-04 16:13:30 --> Utf8 Class Initialized
INFO - 2023-11-04 16:13:30 --> URI Class Initialized
DEBUG - 2023-11-04 16:13:30 --> No URI present. Default controller set.
INFO - 2023-11-04 16:13:30 --> Router Class Initialized
INFO - 2023-11-04 16:13:30 --> Output Class Initialized
INFO - 2023-11-04 16:13:30 --> Security Class Initialized
DEBUG - 2023-11-04 16:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 16:13:30 --> Input Class Initialized
INFO - 2023-11-04 16:13:30 --> Language Class Initialized
INFO - 2023-11-04 16:13:30 --> Loader Class Initialized
INFO - 2023-11-04 16:13:30 --> Helper loaded: url_helper
INFO - 2023-11-04 16:13:30 --> Helper loaded: form_helper
INFO - 2023-11-04 16:13:30 --> Helper loaded: file_helper
INFO - 2023-11-04 16:13:30 --> Database Driver Class Initialized
DEBUG - 2023-11-04 16:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 16:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 16:13:30 --> Form Validation Class Initialized
INFO - 2023-11-04 16:13:30 --> Upload Class Initialized
INFO - 2023-11-04 16:13:30 --> Model "M_auth" initialized
INFO - 2023-11-04 16:13:30 --> Model "M_user" initialized
INFO - 2023-11-04 16:13:30 --> Model "M_produk" initialized
INFO - 2023-11-04 16:13:30 --> Controller Class Initialized
INFO - 2023-11-04 16:13:30 --> Model "M_pelanggan" initialized
INFO - 2023-11-04 16:13:30 --> Model "M_produk" initialized
DEBUG - 2023-11-04 16:13:30 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-04 16:13:30 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-04 16:13:30 --> Model "M_transaksi" initialized
INFO - 2023-11-04 16:13:30 --> Model "M_bank" initialized
INFO - 2023-11-04 16:13:30 --> Model "M_pesan" initialized
DEBUG - 2023-11-04 16:13:30 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-04 16:13:30 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-04 16:13:30 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-04 16:13:30 --> Final output sent to browser
DEBUG - 2023-11-04 16:13:30 --> Total execution time: 0.0545
ERROR - 2023-11-04 17:38:24 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 17:38:24 --> Config Class Initialized
INFO - 2023-11-04 17:38:24 --> Hooks Class Initialized
DEBUG - 2023-11-04 17:38:24 --> UTF-8 Support Enabled
INFO - 2023-11-04 17:38:24 --> Utf8 Class Initialized
INFO - 2023-11-04 17:38:24 --> URI Class Initialized
DEBUG - 2023-11-04 17:38:24 --> No URI present. Default controller set.
INFO - 2023-11-04 17:38:24 --> Router Class Initialized
INFO - 2023-11-04 17:38:24 --> Output Class Initialized
INFO - 2023-11-04 17:38:24 --> Security Class Initialized
DEBUG - 2023-11-04 17:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 17:38:24 --> Input Class Initialized
INFO - 2023-11-04 17:38:24 --> Language Class Initialized
INFO - 2023-11-04 17:38:24 --> Loader Class Initialized
INFO - 2023-11-04 17:38:24 --> Helper loaded: url_helper
INFO - 2023-11-04 17:38:24 --> Helper loaded: form_helper
INFO - 2023-11-04 17:38:24 --> Helper loaded: file_helper
INFO - 2023-11-04 17:38:24 --> Database Driver Class Initialized
DEBUG - 2023-11-04 17:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 17:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 17:38:24 --> Form Validation Class Initialized
INFO - 2023-11-04 17:38:24 --> Upload Class Initialized
INFO - 2023-11-04 17:38:24 --> Model "M_auth" initialized
INFO - 2023-11-04 17:38:24 --> Model "M_user" initialized
INFO - 2023-11-04 17:38:24 --> Model "M_produk" initialized
INFO - 2023-11-04 17:38:24 --> Controller Class Initialized
INFO - 2023-11-04 17:38:24 --> Model "M_pelanggan" initialized
INFO - 2023-11-04 17:38:24 --> Model "M_produk" initialized
DEBUG - 2023-11-04 17:38:24 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-04 17:38:24 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-04 17:38:24 --> Model "M_transaksi" initialized
INFO - 2023-11-04 17:38:24 --> Model "M_bank" initialized
INFO - 2023-11-04 17:38:24 --> Model "M_pesan" initialized
DEBUG - 2023-11-04 17:38:24 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-04 17:38:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-04 17:38:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-04 17:38:24 --> Final output sent to browser
DEBUG - 2023-11-04 17:38:24 --> Total execution time: 0.0424
ERROR - 2023-11-04 18:18:28 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 18:18:28 --> Config Class Initialized
INFO - 2023-11-04 18:18:28 --> Hooks Class Initialized
DEBUG - 2023-11-04 18:18:28 --> UTF-8 Support Enabled
INFO - 2023-11-04 18:18:28 --> Utf8 Class Initialized
INFO - 2023-11-04 18:18:28 --> URI Class Initialized
INFO - 2023-11-04 18:18:28 --> Router Class Initialized
INFO - 2023-11-04 18:18:28 --> Output Class Initialized
INFO - 2023-11-04 18:18:28 --> Security Class Initialized
DEBUG - 2023-11-04 18:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 18:18:28 --> Input Class Initialized
INFO - 2023-11-04 18:18:28 --> Language Class Initialized
INFO - 2023-11-04 18:18:28 --> Loader Class Initialized
INFO - 2023-11-04 18:18:28 --> Helper loaded: url_helper
INFO - 2023-11-04 18:18:28 --> Helper loaded: form_helper
INFO - 2023-11-04 18:18:28 --> Helper loaded: file_helper
INFO - 2023-11-04 18:18:28 --> Database Driver Class Initialized
DEBUG - 2023-11-04 18:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 18:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 18:18:28 --> Form Validation Class Initialized
INFO - 2023-11-04 18:18:28 --> Upload Class Initialized
INFO - 2023-11-04 18:18:28 --> Model "M_auth" initialized
INFO - 2023-11-04 18:18:28 --> Model "M_user" initialized
INFO - 2023-11-04 18:18:28 --> Model "M_produk" initialized
INFO - 2023-11-04 18:18:28 --> Controller Class Initialized
INFO - 2023-11-04 18:18:28 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-04 18:18:28 --> Final output sent to browser
DEBUG - 2023-11-04 18:18:28 --> Total execution time: 0.0367
ERROR - 2023-11-04 18:18:30 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 18:18:30 --> Config Class Initialized
INFO - 2023-11-04 18:18:30 --> Hooks Class Initialized
DEBUG - 2023-11-04 18:18:30 --> UTF-8 Support Enabled
INFO - 2023-11-04 18:18:30 --> Utf8 Class Initialized
INFO - 2023-11-04 18:18:30 --> URI Class Initialized
DEBUG - 2023-11-04 18:18:30 --> No URI present. Default controller set.
INFO - 2023-11-04 18:18:30 --> Router Class Initialized
INFO - 2023-11-04 18:18:30 --> Output Class Initialized
INFO - 2023-11-04 18:18:30 --> Security Class Initialized
DEBUG - 2023-11-04 18:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 18:18:30 --> Input Class Initialized
INFO - 2023-11-04 18:18:30 --> Language Class Initialized
INFO - 2023-11-04 18:18:30 --> Loader Class Initialized
INFO - 2023-11-04 18:18:30 --> Helper loaded: url_helper
INFO - 2023-11-04 18:18:30 --> Helper loaded: form_helper
INFO - 2023-11-04 18:18:30 --> Helper loaded: file_helper
INFO - 2023-11-04 18:18:30 --> Database Driver Class Initialized
DEBUG - 2023-11-04 18:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 18:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 18:18:30 --> Form Validation Class Initialized
INFO - 2023-11-04 18:18:30 --> Upload Class Initialized
INFO - 2023-11-04 18:18:30 --> Model "M_auth" initialized
INFO - 2023-11-04 18:18:30 --> Model "M_user" initialized
INFO - 2023-11-04 18:18:30 --> Model "M_produk" initialized
INFO - 2023-11-04 18:18:30 --> Controller Class Initialized
INFO - 2023-11-04 18:18:30 --> Model "M_pelanggan" initialized
INFO - 2023-11-04 18:18:30 --> Model "M_produk" initialized
DEBUG - 2023-11-04 18:18:30 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-04 18:18:30 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-04 18:18:30 --> Model "M_transaksi" initialized
INFO - 2023-11-04 18:18:30 --> Model "M_bank" initialized
INFO - 2023-11-04 18:18:30 --> Model "M_pesan" initialized
DEBUG - 2023-11-04 18:18:30 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-04 18:18:30 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-04 18:18:30 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-04 18:18:30 --> Final output sent to browser
DEBUG - 2023-11-04 18:18:30 --> Total execution time: 0.0130
ERROR - 2023-11-04 20:41:52 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-04 20:41:52 --> Config Class Initialized
INFO - 2023-11-04 20:41:52 --> Hooks Class Initialized
DEBUG - 2023-11-04 20:41:52 --> UTF-8 Support Enabled
INFO - 2023-11-04 20:41:52 --> Utf8 Class Initialized
INFO - 2023-11-04 20:41:52 --> URI Class Initialized
INFO - 2023-11-04 20:41:52 --> Router Class Initialized
INFO - 2023-11-04 20:41:52 --> Output Class Initialized
INFO - 2023-11-04 20:41:52 --> Security Class Initialized
DEBUG - 2023-11-04 20:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-04 20:41:52 --> Input Class Initialized
INFO - 2023-11-04 20:41:52 --> Language Class Initialized
INFO - 2023-11-04 20:41:52 --> Loader Class Initialized
INFO - 2023-11-04 20:41:52 --> Helper loaded: url_helper
INFO - 2023-11-04 20:41:52 --> Helper loaded: form_helper
INFO - 2023-11-04 20:41:52 --> Helper loaded: file_helper
INFO - 2023-11-04 20:41:52 --> Database Driver Class Initialized
DEBUG - 2023-11-04 20:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-04 20:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-04 20:41:52 --> Form Validation Class Initialized
INFO - 2023-11-04 20:41:52 --> Upload Class Initialized
INFO - 2023-11-04 20:41:52 --> Model "M_auth" initialized
INFO - 2023-11-04 20:41:52 --> Model "M_user" initialized
INFO - 2023-11-04 20:41:52 --> Model "M_produk" initialized
INFO - 2023-11-04 20:41:52 --> Controller Class Initialized
INFO - 2023-11-04 20:41:52 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-04 20:41:52 --> Final output sent to browser
DEBUG - 2023-11-04 20:41:52 --> Total execution time: 0.0324
