<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-06 15:21:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:21:38 --> Config Class Initialized
INFO - 2023-12-06 15:21:38 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:21:38 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:21:38 --> Utf8 Class Initialized
INFO - 2023-12-06 15:21:38 --> URI Class Initialized
DEBUG - 2023-12-06 15:21:39 --> No URI present. Default controller set.
INFO - 2023-12-06 15:21:39 --> Router Class Initialized
INFO - 2023-12-06 15:21:39 --> Output Class Initialized
INFO - 2023-12-06 15:21:39 --> Security Class Initialized
DEBUG - 2023-12-06 15:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:21:39 --> Input Class Initialized
INFO - 2023-12-06 15:21:39 --> Language Class Initialized
INFO - 2023-12-06 15:21:39 --> Loader Class Initialized
INFO - 2023-12-06 15:21:39 --> Helper loaded: url_helper
INFO - 2023-12-06 15:21:39 --> Helper loaded: form_helper
INFO - 2023-12-06 15:21:39 --> Helper loaded: file_helper
INFO - 2023-12-06 15:21:39 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:21:39 --> Form Validation Class Initialized
INFO - 2023-12-06 15:21:39 --> Upload Class Initialized
INFO - 2023-12-06 15:21:39 --> Model "M_auth" initialized
INFO - 2023-12-06 15:21:39 --> Model "M_user" initialized
INFO - 2023-12-06 15:21:39 --> Model "M_produk" initialized
INFO - 2023-12-06 15:21:39 --> Controller Class Initialized
INFO - 2023-12-06 15:21:39 --> Model "M_pelanggan" initialized
INFO - 2023-12-06 15:21:39 --> Model "M_produk" initialized
DEBUG - 2023-12-06 15:21:39 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-06 15:21:39 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-06 15:21:39 --> Model "M_transaksi" initialized
INFO - 2023-12-06 15:21:39 --> Model "M_bank" initialized
INFO - 2023-12-06 15:21:39 --> Model "M_pesan" initialized
DEBUG - 2023-12-06 15:21:39 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-06 15:21:40 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-06 15:21:40 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/index.php
INFO - 2023-12-06 15:21:40 --> Final output sent to browser
DEBUG - 2023-12-06 15:21:40 --> Total execution time: 1.2966
ERROR - 2023-12-06 15:21:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:21:52 --> Config Class Initialized
INFO - 2023-12-06 15:21:52 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:21:52 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:21:52 --> Utf8 Class Initialized
INFO - 2023-12-06 15:21:52 --> URI Class Initialized
DEBUG - 2023-12-06 15:21:52 --> No URI present. Default controller set.
INFO - 2023-12-06 15:21:52 --> Router Class Initialized
INFO - 2023-12-06 15:21:52 --> Output Class Initialized
INFO - 2023-12-06 15:21:52 --> Security Class Initialized
DEBUG - 2023-12-06 15:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:21:52 --> Input Class Initialized
INFO - 2023-12-06 15:21:52 --> Language Class Initialized
INFO - 2023-12-06 15:21:52 --> Loader Class Initialized
INFO - 2023-12-06 15:21:52 --> Helper loaded: url_helper
INFO - 2023-12-06 15:21:52 --> Helper loaded: form_helper
INFO - 2023-12-06 15:21:52 --> Helper loaded: file_helper
INFO - 2023-12-06 15:21:52 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:21:52 --> Form Validation Class Initialized
INFO - 2023-12-06 15:21:52 --> Upload Class Initialized
INFO - 2023-12-06 15:21:52 --> Model "M_auth" initialized
INFO - 2023-12-06 15:21:52 --> Model "M_user" initialized
INFO - 2023-12-06 15:21:52 --> Model "M_produk" initialized
INFO - 2023-12-06 15:21:52 --> Controller Class Initialized
INFO - 2023-12-06 15:21:52 --> Model "M_pelanggan" initialized
INFO - 2023-12-06 15:21:52 --> Model "M_produk" initialized
DEBUG - 2023-12-06 15:21:52 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-06 15:21:52 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-06 15:21:52 --> Model "M_transaksi" initialized
INFO - 2023-12-06 15:21:52 --> Model "M_bank" initialized
INFO - 2023-12-06 15:21:52 --> Model "M_pesan" initialized
DEBUG - 2023-12-06 15:21:52 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-06 15:21:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-12-06 15:21:53 --> Email Class Initialized
INFO - 2023-12-06 15:21:54 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-12-06 15:21:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:21:57 --> Config Class Initialized
INFO - 2023-12-06 15:21:57 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:21:57 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:21:57 --> Utf8 Class Initialized
INFO - 2023-12-06 15:21:57 --> URI Class Initialized
DEBUG - 2023-12-06 15:21:57 --> No URI present. Default controller set.
INFO - 2023-12-06 15:21:57 --> Router Class Initialized
INFO - 2023-12-06 15:21:58 --> Output Class Initialized
INFO - 2023-12-06 15:21:58 --> Security Class Initialized
DEBUG - 2023-12-06 15:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:21:58 --> Input Class Initialized
INFO - 2023-12-06 15:21:58 --> Language Class Initialized
INFO - 2023-12-06 15:21:58 --> Loader Class Initialized
INFO - 2023-12-06 15:21:58 --> Helper loaded: url_helper
INFO - 2023-12-06 15:21:58 --> Helper loaded: form_helper
INFO - 2023-12-06 15:21:58 --> Helper loaded: file_helper
INFO - 2023-12-06 15:21:58 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:21:58 --> Form Validation Class Initialized
INFO - 2023-12-06 15:21:58 --> Upload Class Initialized
INFO - 2023-12-06 15:21:58 --> Model "M_auth" initialized
INFO - 2023-12-06 15:21:58 --> Model "M_user" initialized
INFO - 2023-12-06 15:21:58 --> Model "M_produk" initialized
INFO - 2023-12-06 15:21:58 --> Controller Class Initialized
INFO - 2023-12-06 15:21:58 --> Model "M_pelanggan" initialized
INFO - 2023-12-06 15:21:58 --> Model "M_produk" initialized
DEBUG - 2023-12-06 15:21:58 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-06 15:21:58 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-06 15:21:58 --> Model "M_transaksi" initialized
INFO - 2023-12-06 15:21:58 --> Model "M_bank" initialized
INFO - 2023-12-06 15:21:58 --> Model "M_pesan" initialized
DEBUG - 2023-12-06 15:21:58 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-06 15:21:58 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-06 15:21:58 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/index.php
INFO - 2023-12-06 15:21:58 --> Final output sent to browser
DEBUG - 2023-12-06 15:21:58 --> Total execution time: 0.1022
ERROR - 2023-12-06 15:22:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:22:03 --> Config Class Initialized
INFO - 2023-12-06 15:22:03 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:22:03 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:22:03 --> Utf8 Class Initialized
INFO - 2023-12-06 15:22:03 --> URI Class Initialized
INFO - 2023-12-06 15:22:03 --> Router Class Initialized
INFO - 2023-12-06 15:22:03 --> Output Class Initialized
INFO - 2023-12-06 15:22:03 --> Security Class Initialized
DEBUG - 2023-12-06 15:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:22:03 --> Input Class Initialized
INFO - 2023-12-06 15:22:03 --> Language Class Initialized
INFO - 2023-12-06 15:22:03 --> Loader Class Initialized
INFO - 2023-12-06 15:22:03 --> Helper loaded: url_helper
INFO - 2023-12-06 15:22:03 --> Helper loaded: form_helper
INFO - 2023-12-06 15:22:03 --> Helper loaded: file_helper
INFO - 2023-12-06 15:22:03 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:22:03 --> Form Validation Class Initialized
INFO - 2023-12-06 15:22:03 --> Upload Class Initialized
INFO - 2023-12-06 15:22:03 --> Model "M_auth" initialized
INFO - 2023-12-06 15:22:03 --> Model "M_user" initialized
INFO - 2023-12-06 15:22:03 --> Model "M_produk" initialized
INFO - 2023-12-06 15:22:03 --> Controller Class Initialized
INFO - 2023-12-06 15:22:03 --> Model "M_pelanggan" initialized
INFO - 2023-12-06 15:22:03 --> Model "M_produk" initialized
DEBUG - 2023-12-06 15:22:03 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-06 15:22:03 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-06 15:22:03 --> Model "M_transaksi" initialized
INFO - 2023-12-06 15:22:03 --> Model "M_bank" initialized
INFO - 2023-12-06 15:22:03 --> Model "M_pesan" initialized
DEBUG - 2023-12-06 15:22:03 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-06 15:22:05 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-06 15:22:05 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-06 15:22:05 --> Final output sent to browser
DEBUG - 2023-12-06 15:22:05 --> Total execution time: 2.3401
ERROR - 2023-12-06 15:22:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:22:12 --> Config Class Initialized
INFO - 2023-12-06 15:22:12 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:22:12 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:22:12 --> Utf8 Class Initialized
INFO - 2023-12-06 15:22:12 --> URI Class Initialized
INFO - 2023-12-06 15:22:12 --> Router Class Initialized
INFO - 2023-12-06 15:22:12 --> Output Class Initialized
INFO - 2023-12-06 15:22:12 --> Security Class Initialized
DEBUG - 2023-12-06 15:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:22:12 --> Input Class Initialized
INFO - 2023-12-06 15:22:12 --> Language Class Initialized
INFO - 2023-12-06 15:22:12 --> Loader Class Initialized
INFO - 2023-12-06 15:22:12 --> Helper loaded: url_helper
INFO - 2023-12-06 15:22:12 --> Helper loaded: form_helper
INFO - 2023-12-06 15:22:12 --> Helper loaded: file_helper
INFO - 2023-12-06 15:22:12 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:22:12 --> Form Validation Class Initialized
INFO - 2023-12-06 15:22:12 --> Upload Class Initialized
INFO - 2023-12-06 15:22:12 --> Model "M_auth" initialized
INFO - 2023-12-06 15:22:12 --> Model "M_user" initialized
INFO - 2023-12-06 15:22:12 --> Model "M_produk" initialized
INFO - 2023-12-06 15:22:12 --> Controller Class Initialized
INFO - 2023-12-06 15:22:12 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-06 15:22:12 --> Final output sent to browser
DEBUG - 2023-12-06 15:22:12 --> Total execution time: 0.0467
ERROR - 2023-12-06 15:23:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:23:17 --> Config Class Initialized
INFO - 2023-12-06 15:23:17 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:23:17 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:23:17 --> Utf8 Class Initialized
INFO - 2023-12-06 15:23:17 --> URI Class Initialized
INFO - 2023-12-06 15:23:17 --> Router Class Initialized
INFO - 2023-12-06 15:23:17 --> Output Class Initialized
INFO - 2023-12-06 15:23:17 --> Security Class Initialized
DEBUG - 2023-12-06 15:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:23:17 --> Input Class Initialized
INFO - 2023-12-06 15:23:17 --> Language Class Initialized
INFO - 2023-12-06 15:23:17 --> Loader Class Initialized
INFO - 2023-12-06 15:23:17 --> Helper loaded: url_helper
INFO - 2023-12-06 15:23:17 --> Helper loaded: form_helper
INFO - 2023-12-06 15:23:17 --> Helper loaded: file_helper
INFO - 2023-12-06 15:23:17 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:23:17 --> Form Validation Class Initialized
INFO - 2023-12-06 15:23:17 --> Upload Class Initialized
INFO - 2023-12-06 15:23:17 --> Model "M_auth" initialized
INFO - 2023-12-06 15:23:17 --> Model "M_user" initialized
INFO - 2023-12-06 15:23:17 --> Model "M_produk" initialized
INFO - 2023-12-06 15:23:17 --> Controller Class Initialized
INFO - 2023-12-06 15:23:17 --> Model "M_pelanggan" initialized
INFO - 2023-12-06 15:23:17 --> Model "M_produk" initialized
DEBUG - 2023-12-06 15:23:17 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-06 15:23:17 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-06 15:23:17 --> Model "M_transaksi" initialized
INFO - 2023-12-06 15:23:17 --> Model "M_bank" initialized
INFO - 2023-12-06 15:23:17 --> Model "M_pesan" initialized
DEBUG - 2023-12-06 15:23:17 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-06 15:23:18 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-06 15:23:18 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-06 15:23:18 --> Final output sent to browser
DEBUG - 2023-12-06 15:23:18 --> Total execution time: 0.8804
ERROR - 2023-12-06 15:23:19 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:23:19 --> Config Class Initialized
INFO - 2023-12-06 15:23:19 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:23:19 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:23:19 --> Utf8 Class Initialized
INFO - 2023-12-06 15:23:19 --> URI Class Initialized
INFO - 2023-12-06 15:23:19 --> Router Class Initialized
INFO - 2023-12-06 15:23:19 --> Output Class Initialized
INFO - 2023-12-06 15:23:19 --> Security Class Initialized
DEBUG - 2023-12-06 15:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:23:19 --> Input Class Initialized
INFO - 2023-12-06 15:23:19 --> Language Class Initialized
INFO - 2023-12-06 15:23:19 --> Loader Class Initialized
INFO - 2023-12-06 15:23:19 --> Helper loaded: url_helper
INFO - 2023-12-06 15:23:19 --> Helper loaded: form_helper
INFO - 2023-12-06 15:23:19 --> Helper loaded: file_helper
INFO - 2023-12-06 15:23:19 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:23:19 --> Form Validation Class Initialized
INFO - 2023-12-06 15:23:19 --> Upload Class Initialized
INFO - 2023-12-06 15:23:19 --> Model "M_auth" initialized
INFO - 2023-12-06 15:23:19 --> Model "M_user" initialized
INFO - 2023-12-06 15:23:19 --> Model "M_produk" initialized
INFO - 2023-12-06 15:23:19 --> Controller Class Initialized
INFO - 2023-12-06 15:23:19 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-06 15:23:19 --> Final output sent to browser
DEBUG - 2023-12-06 15:23:19 --> Total execution time: 0.0239
ERROR - 2023-12-06 15:23:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:23:24 --> Config Class Initialized
INFO - 2023-12-06 15:23:24 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:23:24 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:23:24 --> Utf8 Class Initialized
INFO - 2023-12-06 15:23:24 --> URI Class Initialized
INFO - 2023-12-06 15:23:24 --> Router Class Initialized
INFO - 2023-12-06 15:23:24 --> Output Class Initialized
INFO - 2023-12-06 15:23:24 --> Security Class Initialized
DEBUG - 2023-12-06 15:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:23:24 --> Input Class Initialized
INFO - 2023-12-06 15:23:24 --> Language Class Initialized
INFO - 2023-12-06 15:23:24 --> Loader Class Initialized
INFO - 2023-12-06 15:23:24 --> Helper loaded: url_helper
INFO - 2023-12-06 15:23:24 --> Helper loaded: form_helper
INFO - 2023-12-06 15:23:24 --> Helper loaded: file_helper
INFO - 2023-12-06 15:23:24 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:23:25 --> Form Validation Class Initialized
INFO - 2023-12-06 15:23:25 --> Upload Class Initialized
INFO - 2023-12-06 15:23:25 --> Model "M_auth" initialized
INFO - 2023-12-06 15:23:25 --> Model "M_user" initialized
INFO - 2023-12-06 15:23:25 --> Model "M_produk" initialized
INFO - 2023-12-06 15:23:25 --> Controller Class Initialized
INFO - 2023-12-06 15:23:25 --> Model "M_pelanggan" initialized
INFO - 2023-12-06 15:23:25 --> Model "M_produk" initialized
DEBUG - 2023-12-06 15:23:25 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-06 15:23:25 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-06 15:23:25 --> Model "M_transaksi" initialized
INFO - 2023-12-06 15:23:25 --> Model "M_bank" initialized
INFO - 2023-12-06 15:23:25 --> Model "M_pesan" initialized
DEBUG - 2023-12-06 15:23:25 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-06 15:23:25 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-06 15:23:25 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-06 15:23:25 --> Final output sent to browser
DEBUG - 2023-12-06 15:23:25 --> Total execution time: 0.5684
ERROR - 2023-12-06 15:23:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:23:26 --> Config Class Initialized
INFO - 2023-12-06 15:23:26 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:23:26 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:23:26 --> Utf8 Class Initialized
INFO - 2023-12-06 15:23:26 --> URI Class Initialized
INFO - 2023-12-06 15:23:26 --> Router Class Initialized
INFO - 2023-12-06 15:23:26 --> Output Class Initialized
INFO - 2023-12-06 15:23:26 --> Security Class Initialized
DEBUG - 2023-12-06 15:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:23:26 --> Input Class Initialized
INFO - 2023-12-06 15:23:26 --> Language Class Initialized
INFO - 2023-12-06 15:23:26 --> Loader Class Initialized
INFO - 2023-12-06 15:23:26 --> Helper loaded: url_helper
INFO - 2023-12-06 15:23:26 --> Helper loaded: form_helper
INFO - 2023-12-06 15:23:26 --> Helper loaded: file_helper
INFO - 2023-12-06 15:23:26 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:23:26 --> Form Validation Class Initialized
INFO - 2023-12-06 15:23:26 --> Upload Class Initialized
INFO - 2023-12-06 15:23:26 --> Model "M_auth" initialized
INFO - 2023-12-06 15:23:26 --> Model "M_user" initialized
INFO - 2023-12-06 15:23:26 --> Model "M_produk" initialized
INFO - 2023-12-06 15:23:26 --> Controller Class Initialized
INFO - 2023-12-06 15:23:26 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-06 15:23:26 --> Final output sent to browser
DEBUG - 2023-12-06 15:23:26 --> Total execution time: 0.0286
ERROR - 2023-12-06 15:29:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:29:42 --> Config Class Initialized
INFO - 2023-12-06 15:29:42 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:29:42 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:29:42 --> Utf8 Class Initialized
INFO - 2023-12-06 15:29:42 --> URI Class Initialized
INFO - 2023-12-06 15:29:42 --> Router Class Initialized
INFO - 2023-12-06 15:29:42 --> Output Class Initialized
INFO - 2023-12-06 15:29:42 --> Security Class Initialized
DEBUG - 2023-12-06 15:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:29:42 --> Input Class Initialized
INFO - 2023-12-06 15:29:42 --> Language Class Initialized
INFO - 2023-12-06 15:29:42 --> Loader Class Initialized
INFO - 2023-12-06 15:29:42 --> Helper loaded: url_helper
INFO - 2023-12-06 15:29:42 --> Helper loaded: form_helper
INFO - 2023-12-06 15:29:42 --> Helper loaded: file_helper
INFO - 2023-12-06 15:29:42 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:29:42 --> Form Validation Class Initialized
INFO - 2023-12-06 15:29:42 --> Upload Class Initialized
INFO - 2023-12-06 15:29:42 --> Model "M_auth" initialized
INFO - 2023-12-06 15:29:42 --> Model "M_user" initialized
INFO - 2023-12-06 15:29:42 --> Model "M_produk" initialized
INFO - 2023-12-06 15:29:42 --> Controller Class Initialized
INFO - 2023-12-06 15:29:42 --> Model "M_pelanggan" initialized
INFO - 2023-12-06 15:29:42 --> Model "M_produk" initialized
DEBUG - 2023-12-06 15:29:42 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-06 15:29:42 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-06 15:29:42 --> Model "M_transaksi" initialized
INFO - 2023-12-06 15:29:42 --> Model "M_bank" initialized
INFO - 2023-12-06 15:29:42 --> Model "M_pesan" initialized
DEBUG - 2023-12-06 15:29:42 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
ERROR - 2023-12-06 15:29:44 --> Severity: Warning --> Undefined variable $snapToken C:\xampp\htdocs\semakar_adventure_new\application\controllers\Home.php 587
INFO - 2023-12-06 15:29:44 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-06 15:29:44 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-06 15:29:44 --> Final output sent to browser
DEBUG - 2023-12-06 15:29:44 --> Total execution time: 1.5215
ERROR - 2023-12-06 15:29:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:29:44 --> Config Class Initialized
INFO - 2023-12-06 15:29:44 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:29:44 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:29:44 --> Utf8 Class Initialized
INFO - 2023-12-06 15:29:44 --> URI Class Initialized
INFO - 2023-12-06 15:29:44 --> Router Class Initialized
INFO - 2023-12-06 15:29:44 --> Output Class Initialized
INFO - 2023-12-06 15:29:44 --> Security Class Initialized
DEBUG - 2023-12-06 15:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:29:44 --> Input Class Initialized
INFO - 2023-12-06 15:29:44 --> Language Class Initialized
INFO - 2023-12-06 15:29:44 --> Loader Class Initialized
INFO - 2023-12-06 15:29:44 --> Helper loaded: url_helper
INFO - 2023-12-06 15:29:44 --> Helper loaded: form_helper
INFO - 2023-12-06 15:29:44 --> Helper loaded: file_helper
INFO - 2023-12-06 15:29:44 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:29:44 --> Form Validation Class Initialized
INFO - 2023-12-06 15:29:44 --> Upload Class Initialized
INFO - 2023-12-06 15:29:44 --> Model "M_auth" initialized
INFO - 2023-12-06 15:29:44 --> Model "M_user" initialized
INFO - 2023-12-06 15:29:44 --> Model "M_produk" initialized
INFO - 2023-12-06 15:29:44 --> Controller Class Initialized
INFO - 2023-12-06 15:29:44 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-06 15:29:44 --> Final output sent to browser
DEBUG - 2023-12-06 15:29:44 --> Total execution time: 0.0274
ERROR - 2023-12-06 15:29:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:29:57 --> Config Class Initialized
INFO - 2023-12-06 15:29:57 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:29:57 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:29:57 --> Utf8 Class Initialized
INFO - 2023-12-06 15:29:57 --> URI Class Initialized
INFO - 2023-12-06 15:29:57 --> Router Class Initialized
INFO - 2023-12-06 15:29:57 --> Output Class Initialized
INFO - 2023-12-06 15:29:57 --> Security Class Initialized
DEBUG - 2023-12-06 15:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:29:57 --> Input Class Initialized
INFO - 2023-12-06 15:29:57 --> Language Class Initialized
INFO - 2023-12-06 15:29:57 --> Loader Class Initialized
INFO - 2023-12-06 15:29:57 --> Helper loaded: url_helper
INFO - 2023-12-06 15:29:57 --> Helper loaded: form_helper
INFO - 2023-12-06 15:29:57 --> Helper loaded: file_helper
INFO - 2023-12-06 15:29:57 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:29:57 --> Form Validation Class Initialized
INFO - 2023-12-06 15:29:57 --> Upload Class Initialized
INFO - 2023-12-06 15:29:57 --> Model "M_auth" initialized
INFO - 2023-12-06 15:29:57 --> Model "M_user" initialized
INFO - 2023-12-06 15:29:57 --> Model "M_produk" initialized
INFO - 2023-12-06 15:29:57 --> Controller Class Initialized
INFO - 2023-12-06 15:29:57 --> Model "M_pelanggan" initialized
INFO - 2023-12-06 15:29:57 --> Model "M_produk" initialized
DEBUG - 2023-12-06 15:29:57 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-06 15:29:57 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-06 15:29:57 --> Model "M_transaksi" initialized
INFO - 2023-12-06 15:29:57 --> Model "M_bank" initialized
INFO - 2023-12-06 15:29:57 --> Model "M_pesan" initialized
DEBUG - 2023-12-06 15:29:57 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-06 15:29:58 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-06 15:29:58 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-06 15:29:58 --> Final output sent to browser
DEBUG - 2023-12-06 15:29:58 --> Total execution time: 0.8368
ERROR - 2023-12-06 15:29:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:29:59 --> Config Class Initialized
INFO - 2023-12-06 15:29:59 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:29:59 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:29:59 --> Utf8 Class Initialized
INFO - 2023-12-06 15:29:59 --> URI Class Initialized
INFO - 2023-12-06 15:29:59 --> Router Class Initialized
INFO - 2023-12-06 15:29:59 --> Output Class Initialized
INFO - 2023-12-06 15:29:59 --> Security Class Initialized
DEBUG - 2023-12-06 15:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:29:59 --> Input Class Initialized
INFO - 2023-12-06 15:29:59 --> Language Class Initialized
INFO - 2023-12-06 15:29:59 --> Loader Class Initialized
INFO - 2023-12-06 15:29:59 --> Helper loaded: url_helper
INFO - 2023-12-06 15:29:59 --> Helper loaded: form_helper
INFO - 2023-12-06 15:29:59 --> Helper loaded: file_helper
INFO - 2023-12-06 15:29:59 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:29:59 --> Form Validation Class Initialized
INFO - 2023-12-06 15:29:59 --> Upload Class Initialized
INFO - 2023-12-06 15:29:59 --> Model "M_auth" initialized
INFO - 2023-12-06 15:29:59 --> Model "M_user" initialized
INFO - 2023-12-06 15:29:59 --> Model "M_produk" initialized
INFO - 2023-12-06 15:29:59 --> Controller Class Initialized
INFO - 2023-12-06 15:29:59 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-06 15:29:59 --> Final output sent to browser
DEBUG - 2023-12-06 15:29:59 --> Total execution time: 0.0352
ERROR - 2023-12-06 15:31:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:31:41 --> Config Class Initialized
INFO - 2023-12-06 15:31:41 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:31:41 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:31:41 --> Utf8 Class Initialized
INFO - 2023-12-06 15:31:41 --> URI Class Initialized
INFO - 2023-12-06 15:31:41 --> Router Class Initialized
INFO - 2023-12-06 15:31:41 --> Output Class Initialized
INFO - 2023-12-06 15:31:41 --> Security Class Initialized
DEBUG - 2023-12-06 15:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:31:41 --> Input Class Initialized
INFO - 2023-12-06 15:31:41 --> Language Class Initialized
INFO - 2023-12-06 15:31:41 --> Loader Class Initialized
INFO - 2023-12-06 15:31:41 --> Helper loaded: url_helper
INFO - 2023-12-06 15:31:41 --> Helper loaded: form_helper
INFO - 2023-12-06 15:31:41 --> Helper loaded: file_helper
INFO - 2023-12-06 15:31:41 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:31:41 --> Form Validation Class Initialized
INFO - 2023-12-06 15:31:41 --> Upload Class Initialized
INFO - 2023-12-06 15:31:41 --> Model "M_auth" initialized
INFO - 2023-12-06 15:31:41 --> Model "M_user" initialized
INFO - 2023-12-06 15:31:41 --> Model "M_produk" initialized
INFO - 2023-12-06 15:31:41 --> Controller Class Initialized
INFO - 2023-12-06 15:31:41 --> Model "M_pelanggan" initialized
INFO - 2023-12-06 15:31:41 --> Model "M_produk" initialized
DEBUG - 2023-12-06 15:31:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-06 15:31:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-06 15:31:41 --> Model "M_transaksi" initialized
INFO - 2023-12-06 15:31:41 --> Model "M_bank" initialized
INFO - 2023-12-06 15:31:41 --> Model "M_pesan" initialized
DEBUG - 2023-12-06 15:31:41 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-06 15:31:43 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-06 15:31:43 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-06 15:31:43 --> Final output sent to browser
DEBUG - 2023-12-06 15:31:43 --> Total execution time: 1.9088
ERROR - 2023-12-06 15:31:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:31:44 --> Config Class Initialized
INFO - 2023-12-06 15:31:44 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:31:44 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:31:44 --> Utf8 Class Initialized
INFO - 2023-12-06 15:31:44 --> URI Class Initialized
INFO - 2023-12-06 15:31:44 --> Router Class Initialized
INFO - 2023-12-06 15:31:44 --> Output Class Initialized
INFO - 2023-12-06 15:31:44 --> Security Class Initialized
DEBUG - 2023-12-06 15:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:31:44 --> Input Class Initialized
INFO - 2023-12-06 15:31:44 --> Language Class Initialized
INFO - 2023-12-06 15:31:44 --> Loader Class Initialized
INFO - 2023-12-06 15:31:44 --> Helper loaded: url_helper
INFO - 2023-12-06 15:31:44 --> Helper loaded: form_helper
INFO - 2023-12-06 15:31:44 --> Helper loaded: file_helper
INFO - 2023-12-06 15:31:44 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:31:44 --> Form Validation Class Initialized
INFO - 2023-12-06 15:31:44 --> Upload Class Initialized
INFO - 2023-12-06 15:31:44 --> Model "M_auth" initialized
INFO - 2023-12-06 15:31:44 --> Model "M_user" initialized
INFO - 2023-12-06 15:31:44 --> Model "M_produk" initialized
INFO - 2023-12-06 15:31:44 --> Controller Class Initialized
INFO - 2023-12-06 15:31:44 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-06 15:31:44 --> Final output sent to browser
DEBUG - 2023-12-06 15:31:44 --> Total execution time: 0.0245
ERROR - 2023-12-06 15:31:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:31:54 --> Config Class Initialized
INFO - 2023-12-06 15:31:54 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:31:54 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:31:54 --> Utf8 Class Initialized
INFO - 2023-12-06 15:31:54 --> URI Class Initialized
DEBUG - 2023-12-06 15:31:54 --> No URI present. Default controller set.
INFO - 2023-12-06 15:31:54 --> Router Class Initialized
INFO - 2023-12-06 15:31:54 --> Output Class Initialized
INFO - 2023-12-06 15:31:54 --> Security Class Initialized
DEBUG - 2023-12-06 15:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:31:54 --> Input Class Initialized
INFO - 2023-12-06 15:31:54 --> Language Class Initialized
INFO - 2023-12-06 15:31:54 --> Loader Class Initialized
INFO - 2023-12-06 15:31:54 --> Helper loaded: url_helper
INFO - 2023-12-06 15:31:54 --> Helper loaded: form_helper
INFO - 2023-12-06 15:31:54 --> Helper loaded: file_helper
INFO - 2023-12-06 15:31:54 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:31:54 --> Form Validation Class Initialized
INFO - 2023-12-06 15:31:54 --> Upload Class Initialized
INFO - 2023-12-06 15:31:54 --> Model "M_auth" initialized
INFO - 2023-12-06 15:31:54 --> Model "M_user" initialized
INFO - 2023-12-06 15:31:54 --> Model "M_produk" initialized
INFO - 2023-12-06 15:31:54 --> Controller Class Initialized
INFO - 2023-12-06 15:31:54 --> Model "M_pelanggan" initialized
INFO - 2023-12-06 15:31:54 --> Model "M_produk" initialized
DEBUG - 2023-12-06 15:31:54 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-06 15:31:54 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-06 15:31:54 --> Model "M_transaksi" initialized
INFO - 2023-12-06 15:31:54 --> Model "M_bank" initialized
INFO - 2023-12-06 15:31:54 --> Model "M_pesan" initialized
DEBUG - 2023-12-06 15:31:54 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-06 15:31:54 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-06 15:31:54 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/index.php
INFO - 2023-12-06 15:31:54 --> Final output sent to browser
DEBUG - 2023-12-06 15:31:54 --> Total execution time: 0.0592
ERROR - 2023-12-06 15:31:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:31:54 --> Config Class Initialized
INFO - 2023-12-06 15:31:54 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:31:54 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:31:54 --> Utf8 Class Initialized
INFO - 2023-12-06 15:31:54 --> URI Class Initialized
INFO - 2023-12-06 15:31:54 --> Router Class Initialized
INFO - 2023-12-06 15:31:54 --> Output Class Initialized
INFO - 2023-12-06 15:31:54 --> Security Class Initialized
DEBUG - 2023-12-06 15:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:31:54 --> Input Class Initialized
INFO - 2023-12-06 15:31:54 --> Language Class Initialized
INFO - 2023-12-06 15:31:54 --> Loader Class Initialized
INFO - 2023-12-06 15:31:54 --> Helper loaded: url_helper
INFO - 2023-12-06 15:31:54 --> Helper loaded: form_helper
INFO - 2023-12-06 15:31:54 --> Helper loaded: file_helper
INFO - 2023-12-06 15:31:54 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:31:54 --> Form Validation Class Initialized
INFO - 2023-12-06 15:31:54 --> Upload Class Initialized
INFO - 2023-12-06 15:31:54 --> Model "M_auth" initialized
INFO - 2023-12-06 15:31:54 --> Model "M_user" initialized
INFO - 2023-12-06 15:31:54 --> Model "M_produk" initialized
INFO - 2023-12-06 15:31:54 --> Controller Class Initialized
INFO - 2023-12-06 15:31:54 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-06 15:31:54 --> Final output sent to browser
DEBUG - 2023-12-06 15:31:54 --> Total execution time: 0.0460
ERROR - 2023-12-06 15:31:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:31:57 --> Config Class Initialized
INFO - 2023-12-06 15:31:57 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:31:57 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:31:57 --> Utf8 Class Initialized
INFO - 2023-12-06 15:31:57 --> URI Class Initialized
INFO - 2023-12-06 15:31:57 --> Router Class Initialized
INFO - 2023-12-06 15:31:57 --> Output Class Initialized
INFO - 2023-12-06 15:31:57 --> Security Class Initialized
DEBUG - 2023-12-06 15:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:31:57 --> Input Class Initialized
INFO - 2023-12-06 15:31:57 --> Language Class Initialized
INFO - 2023-12-06 15:31:57 --> Loader Class Initialized
INFO - 2023-12-06 15:31:57 --> Helper loaded: url_helper
INFO - 2023-12-06 15:31:57 --> Helper loaded: form_helper
INFO - 2023-12-06 15:31:57 --> Helper loaded: file_helper
INFO - 2023-12-06 15:31:57 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:31:57 --> Form Validation Class Initialized
INFO - 2023-12-06 15:31:57 --> Upload Class Initialized
INFO - 2023-12-06 15:31:57 --> Model "M_auth" initialized
INFO - 2023-12-06 15:31:57 --> Model "M_user" initialized
INFO - 2023-12-06 15:31:57 --> Model "M_produk" initialized
INFO - 2023-12-06 15:31:57 --> Controller Class Initialized
INFO - 2023-12-06 15:31:57 --> Model "M_pelanggan" initialized
INFO - 2023-12-06 15:31:57 --> Model "M_produk" initialized
DEBUG - 2023-12-06 15:31:57 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-06 15:31:57 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-06 15:31:57 --> Model "M_transaksi" initialized
INFO - 2023-12-06 15:31:57 --> Model "M_bank" initialized
INFO - 2023-12-06 15:31:57 --> Model "M_pesan" initialized
DEBUG - 2023-12-06 15:31:57 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-06 15:31:57 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-06 15:31:57 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_produk_detail.php
INFO - 2023-12-06 15:31:57 --> Final output sent to browser
DEBUG - 2023-12-06 15:31:57 --> Total execution time: 0.0602
ERROR - 2023-12-06 15:31:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:31:57 --> Config Class Initialized
INFO - 2023-12-06 15:31:57 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:31:57 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:31:57 --> Utf8 Class Initialized
INFO - 2023-12-06 15:31:57 --> URI Class Initialized
INFO - 2023-12-06 15:31:57 --> Router Class Initialized
INFO - 2023-12-06 15:31:57 --> Output Class Initialized
INFO - 2023-12-06 15:31:57 --> Security Class Initialized
DEBUG - 2023-12-06 15:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:31:57 --> Input Class Initialized
INFO - 2023-12-06 15:31:57 --> Language Class Initialized
INFO - 2023-12-06 15:31:57 --> Loader Class Initialized
INFO - 2023-12-06 15:31:57 --> Helper loaded: url_helper
INFO - 2023-12-06 15:31:57 --> Helper loaded: form_helper
INFO - 2023-12-06 15:31:57 --> Helper loaded: file_helper
INFO - 2023-12-06 15:31:57 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:31:57 --> Form Validation Class Initialized
INFO - 2023-12-06 15:31:57 --> Upload Class Initialized
INFO - 2023-12-06 15:31:57 --> Model "M_auth" initialized
INFO - 2023-12-06 15:31:57 --> Model "M_user" initialized
INFO - 2023-12-06 15:31:57 --> Model "M_produk" initialized
INFO - 2023-12-06 15:31:57 --> Controller Class Initialized
INFO - 2023-12-06 15:31:57 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-06 15:31:57 --> Final output sent to browser
DEBUG - 2023-12-06 15:31:57 --> Total execution time: 0.0267
ERROR - 2023-12-06 15:31:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:31:57 --> Config Class Initialized
INFO - 2023-12-06 15:31:57 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:31:57 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:31:57 --> Utf8 Class Initialized
INFO - 2023-12-06 15:31:57 --> URI Class Initialized
INFO - 2023-12-06 15:31:58 --> Router Class Initialized
INFO - 2023-12-06 15:31:58 --> Output Class Initialized
INFO - 2023-12-06 15:31:58 --> Security Class Initialized
DEBUG - 2023-12-06 15:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:31:58 --> Input Class Initialized
INFO - 2023-12-06 15:31:58 --> Language Class Initialized
INFO - 2023-12-06 15:31:58 --> Loader Class Initialized
INFO - 2023-12-06 15:31:58 --> Helper loaded: url_helper
INFO - 2023-12-06 15:31:58 --> Helper loaded: form_helper
INFO - 2023-12-06 15:31:58 --> Helper loaded: file_helper
INFO - 2023-12-06 15:31:58 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:31:58 --> Form Validation Class Initialized
INFO - 2023-12-06 15:31:58 --> Upload Class Initialized
INFO - 2023-12-06 15:31:58 --> Model "M_auth" initialized
INFO - 2023-12-06 15:31:58 --> Model "M_user" initialized
INFO - 2023-12-06 15:31:58 --> Model "M_produk" initialized
INFO - 2023-12-06 15:31:58 --> Controller Class Initialized
INFO - 2023-12-06 15:31:58 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-06 15:31:58 --> Final output sent to browser
DEBUG - 2023-12-06 15:31:58 --> Total execution time: 0.0333
ERROR - 2023-12-06 15:32:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:32:07 --> Config Class Initialized
INFO - 2023-12-06 15:32:07 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:32:07 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:32:07 --> Utf8 Class Initialized
INFO - 2023-12-06 15:32:07 --> URI Class Initialized
INFO - 2023-12-06 15:32:07 --> Router Class Initialized
INFO - 2023-12-06 15:32:07 --> Output Class Initialized
INFO - 2023-12-06 15:32:07 --> Security Class Initialized
DEBUG - 2023-12-06 15:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:32:07 --> Input Class Initialized
INFO - 2023-12-06 15:32:07 --> Language Class Initialized
INFO - 2023-12-06 15:32:07 --> Loader Class Initialized
INFO - 2023-12-06 15:32:07 --> Helper loaded: url_helper
INFO - 2023-12-06 15:32:07 --> Helper loaded: form_helper
INFO - 2023-12-06 15:32:07 --> Helper loaded: file_helper
INFO - 2023-12-06 15:32:07 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:32:07 --> Form Validation Class Initialized
INFO - 2023-12-06 15:32:07 --> Upload Class Initialized
INFO - 2023-12-06 15:32:07 --> Model "M_auth" initialized
INFO - 2023-12-06 15:32:07 --> Model "M_user" initialized
INFO - 2023-12-06 15:32:07 --> Model "M_produk" initialized
INFO - 2023-12-06 15:32:07 --> Controller Class Initialized
INFO - 2023-12-06 15:32:07 --> Model "M_pelanggan" initialized
INFO - 2023-12-06 15:32:07 --> Model "M_produk" initialized
DEBUG - 2023-12-06 15:32:07 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-06 15:32:07 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-06 15:32:07 --> Model "M_transaksi" initialized
INFO - 2023-12-06 15:32:07 --> Model "M_bank" initialized
INFO - 2023-12-06 15:32:07 --> Model "M_pesan" initialized
DEBUG - 2023-12-06 15:32:07 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-06 15:32:07 --> Email Class Initialized
INFO - 2023-12-06 15:32:08 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-12-06 15:32:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:32:12 --> Config Class Initialized
INFO - 2023-12-06 15:32:12 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:32:12 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:32:12 --> Utf8 Class Initialized
INFO - 2023-12-06 15:32:12 --> URI Class Initialized
INFO - 2023-12-06 15:32:12 --> Router Class Initialized
INFO - 2023-12-06 15:32:12 --> Output Class Initialized
INFO - 2023-12-06 15:32:12 --> Security Class Initialized
DEBUG - 2023-12-06 15:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:32:12 --> Input Class Initialized
INFO - 2023-12-06 15:32:12 --> Language Class Initialized
INFO - 2023-12-06 15:32:12 --> Loader Class Initialized
INFO - 2023-12-06 15:32:12 --> Helper loaded: url_helper
INFO - 2023-12-06 15:32:12 --> Helper loaded: form_helper
INFO - 2023-12-06 15:32:12 --> Helper loaded: file_helper
INFO - 2023-12-06 15:32:12 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:32:12 --> Form Validation Class Initialized
INFO - 2023-12-06 15:32:12 --> Upload Class Initialized
INFO - 2023-12-06 15:32:12 --> Model "M_auth" initialized
INFO - 2023-12-06 15:32:12 --> Model "M_user" initialized
INFO - 2023-12-06 15:32:12 --> Model "M_produk" initialized
INFO - 2023-12-06 15:32:12 --> Controller Class Initialized
INFO - 2023-12-06 15:32:12 --> Model "M_pelanggan" initialized
INFO - 2023-12-06 15:32:12 --> Model "M_produk" initialized
DEBUG - 2023-12-06 15:32:12 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-06 15:32:12 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-06 15:32:12 --> Model "M_transaksi" initialized
INFO - 2023-12-06 15:32:12 --> Model "M_bank" initialized
INFO - 2023-12-06 15:32:12 --> Model "M_pesan" initialized
DEBUG - 2023-12-06 15:32:12 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-06 15:32:13 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-06 15:32:13 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-06 15:32:13 --> Final output sent to browser
DEBUG - 2023-12-06 15:32:13 --> Total execution time: 0.7571
ERROR - 2023-12-06 15:32:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:32:14 --> Config Class Initialized
INFO - 2023-12-06 15:32:14 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:32:14 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:32:14 --> Utf8 Class Initialized
INFO - 2023-12-06 15:32:14 --> URI Class Initialized
INFO - 2023-12-06 15:32:14 --> Router Class Initialized
INFO - 2023-12-06 15:32:14 --> Output Class Initialized
INFO - 2023-12-06 15:32:14 --> Security Class Initialized
DEBUG - 2023-12-06 15:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:32:14 --> Input Class Initialized
INFO - 2023-12-06 15:32:14 --> Language Class Initialized
INFO - 2023-12-06 15:32:14 --> Loader Class Initialized
INFO - 2023-12-06 15:32:14 --> Helper loaded: url_helper
INFO - 2023-12-06 15:32:14 --> Helper loaded: form_helper
INFO - 2023-12-06 15:32:14 --> Helper loaded: file_helper
INFO - 2023-12-06 15:32:14 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:32:14 --> Form Validation Class Initialized
INFO - 2023-12-06 15:32:14 --> Upload Class Initialized
INFO - 2023-12-06 15:32:14 --> Model "M_auth" initialized
INFO - 2023-12-06 15:32:14 --> Model "M_user" initialized
INFO - 2023-12-06 15:32:14 --> Model "M_produk" initialized
INFO - 2023-12-06 15:32:14 --> Controller Class Initialized
INFO - 2023-12-06 15:32:14 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-06 15:32:14 --> Final output sent to browser
DEBUG - 2023-12-06 15:32:14 --> Total execution time: 0.0304
ERROR - 2023-12-06 15:32:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:32:55 --> Config Class Initialized
INFO - 2023-12-06 15:32:55 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:32:55 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:32:55 --> Utf8 Class Initialized
INFO - 2023-12-06 15:32:55 --> URI Class Initialized
INFO - 2023-12-06 15:32:55 --> Router Class Initialized
INFO - 2023-12-06 15:32:55 --> Output Class Initialized
INFO - 2023-12-06 15:32:55 --> Security Class Initialized
DEBUG - 2023-12-06 15:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:32:55 --> Input Class Initialized
INFO - 2023-12-06 15:32:55 --> Language Class Initialized
INFO - 2023-12-06 15:32:55 --> Loader Class Initialized
INFO - 2023-12-06 15:32:55 --> Helper loaded: url_helper
INFO - 2023-12-06 15:32:55 --> Helper loaded: form_helper
INFO - 2023-12-06 15:32:55 --> Helper loaded: file_helper
INFO - 2023-12-06 15:32:55 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:32:55 --> Form Validation Class Initialized
INFO - 2023-12-06 15:32:55 --> Upload Class Initialized
INFO - 2023-12-06 15:32:55 --> Model "M_auth" initialized
INFO - 2023-12-06 15:32:55 --> Model "M_user" initialized
INFO - 2023-12-06 15:32:55 --> Model "M_produk" initialized
INFO - 2023-12-06 15:32:55 --> Controller Class Initialized
INFO - 2023-12-06 15:32:55 --> Model "M_pelanggan" initialized
INFO - 2023-12-06 15:32:55 --> Model "M_produk" initialized
DEBUG - 2023-12-06 15:32:55 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-06 15:32:55 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-06 15:32:55 --> Model "M_transaksi" initialized
INFO - 2023-12-06 15:32:55 --> Model "M_bank" initialized
INFO - 2023-12-06 15:32:55 --> Model "M_pesan" initialized
DEBUG - 2023-12-06 15:32:55 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-06 15:32:56 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-06 15:32:56 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-06 15:32:56 --> Final output sent to browser
DEBUG - 2023-12-06 15:32:56 --> Total execution time: 1.3647
ERROR - 2023-12-06 15:32:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:32:57 --> Config Class Initialized
INFO - 2023-12-06 15:32:57 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:32:57 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:32:57 --> Utf8 Class Initialized
INFO - 2023-12-06 15:32:57 --> URI Class Initialized
INFO - 2023-12-06 15:32:57 --> Router Class Initialized
INFO - 2023-12-06 15:32:57 --> Output Class Initialized
INFO - 2023-12-06 15:32:57 --> Security Class Initialized
DEBUG - 2023-12-06 15:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:32:57 --> Input Class Initialized
INFO - 2023-12-06 15:32:57 --> Language Class Initialized
INFO - 2023-12-06 15:32:57 --> Loader Class Initialized
INFO - 2023-12-06 15:32:57 --> Helper loaded: url_helper
INFO - 2023-12-06 15:32:57 --> Helper loaded: form_helper
INFO - 2023-12-06 15:32:57 --> Helper loaded: file_helper
INFO - 2023-12-06 15:32:57 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:32:57 --> Form Validation Class Initialized
INFO - 2023-12-06 15:32:57 --> Upload Class Initialized
INFO - 2023-12-06 15:32:57 --> Model "M_auth" initialized
INFO - 2023-12-06 15:32:57 --> Model "M_user" initialized
INFO - 2023-12-06 15:32:57 --> Model "M_produk" initialized
INFO - 2023-12-06 15:32:57 --> Controller Class Initialized
INFO - 2023-12-06 15:32:57 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-06 15:32:57 --> Final output sent to browser
DEBUG - 2023-12-06 15:32:57 --> Total execution time: 0.0263
ERROR - 2023-12-06 15:32:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:32:59 --> Config Class Initialized
INFO - 2023-12-06 15:32:59 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:32:59 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:32:59 --> Utf8 Class Initialized
INFO - 2023-12-06 15:32:59 --> URI Class Initialized
DEBUG - 2023-12-06 15:32:59 --> No URI present. Default controller set.
INFO - 2023-12-06 15:32:59 --> Router Class Initialized
INFO - 2023-12-06 15:32:59 --> Output Class Initialized
INFO - 2023-12-06 15:32:59 --> Security Class Initialized
DEBUG - 2023-12-06 15:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:32:59 --> Input Class Initialized
INFO - 2023-12-06 15:32:59 --> Language Class Initialized
INFO - 2023-12-06 15:32:59 --> Loader Class Initialized
INFO - 2023-12-06 15:32:59 --> Helper loaded: url_helper
INFO - 2023-12-06 15:32:59 --> Helper loaded: form_helper
INFO - 2023-12-06 15:32:59 --> Helper loaded: file_helper
INFO - 2023-12-06 15:32:59 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:32:59 --> Form Validation Class Initialized
INFO - 2023-12-06 15:32:59 --> Upload Class Initialized
INFO - 2023-12-06 15:32:59 --> Model "M_auth" initialized
INFO - 2023-12-06 15:32:59 --> Model "M_user" initialized
INFO - 2023-12-06 15:32:59 --> Model "M_produk" initialized
INFO - 2023-12-06 15:32:59 --> Controller Class Initialized
INFO - 2023-12-06 15:32:59 --> Model "M_pelanggan" initialized
INFO - 2023-12-06 15:32:59 --> Model "M_produk" initialized
DEBUG - 2023-12-06 15:32:59 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-06 15:32:59 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-06 15:32:59 --> Model "M_transaksi" initialized
INFO - 2023-12-06 15:32:59 --> Model "M_bank" initialized
INFO - 2023-12-06 15:32:59 --> Model "M_pesan" initialized
DEBUG - 2023-12-06 15:32:59 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-06 15:32:59 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-06 15:32:59 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/index.php
INFO - 2023-12-06 15:32:59 --> Final output sent to browser
DEBUG - 2023-12-06 15:32:59 --> Total execution time: 0.1039
ERROR - 2023-12-06 15:33:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:33:00 --> Config Class Initialized
INFO - 2023-12-06 15:33:00 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:33:00 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:33:00 --> Utf8 Class Initialized
INFO - 2023-12-06 15:33:00 --> URI Class Initialized
INFO - 2023-12-06 15:33:00 --> Router Class Initialized
INFO - 2023-12-06 15:33:00 --> Output Class Initialized
INFO - 2023-12-06 15:33:00 --> Security Class Initialized
DEBUG - 2023-12-06 15:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:33:00 --> Input Class Initialized
INFO - 2023-12-06 15:33:00 --> Language Class Initialized
INFO - 2023-12-06 15:33:00 --> Loader Class Initialized
INFO - 2023-12-06 15:33:00 --> Helper loaded: url_helper
INFO - 2023-12-06 15:33:00 --> Helper loaded: form_helper
INFO - 2023-12-06 15:33:00 --> Helper loaded: file_helper
INFO - 2023-12-06 15:33:00 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:33:00 --> Form Validation Class Initialized
INFO - 2023-12-06 15:33:00 --> Upload Class Initialized
INFO - 2023-12-06 15:33:00 --> Model "M_auth" initialized
INFO - 2023-12-06 15:33:00 --> Model "M_user" initialized
INFO - 2023-12-06 15:33:00 --> Model "M_produk" initialized
INFO - 2023-12-06 15:33:00 --> Controller Class Initialized
INFO - 2023-12-06 15:33:00 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-06 15:33:00 --> Final output sent to browser
DEBUG - 2023-12-06 15:33:00 --> Total execution time: 0.0369
ERROR - 2023-12-06 15:33:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:33:02 --> Config Class Initialized
INFO - 2023-12-06 15:33:02 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:33:02 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:33:02 --> Utf8 Class Initialized
INFO - 2023-12-06 15:33:02 --> URI Class Initialized
INFO - 2023-12-06 15:33:02 --> Router Class Initialized
INFO - 2023-12-06 15:33:02 --> Output Class Initialized
INFO - 2023-12-06 15:33:02 --> Security Class Initialized
DEBUG - 2023-12-06 15:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:33:02 --> Input Class Initialized
INFO - 2023-12-06 15:33:02 --> Language Class Initialized
INFO - 2023-12-06 15:33:02 --> Loader Class Initialized
INFO - 2023-12-06 15:33:02 --> Helper loaded: url_helper
INFO - 2023-12-06 15:33:02 --> Helper loaded: form_helper
INFO - 2023-12-06 15:33:02 --> Helper loaded: file_helper
INFO - 2023-12-06 15:33:02 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:33:02 --> Form Validation Class Initialized
INFO - 2023-12-06 15:33:02 --> Upload Class Initialized
INFO - 2023-12-06 15:33:02 --> Model "M_auth" initialized
INFO - 2023-12-06 15:33:02 --> Model "M_user" initialized
INFO - 2023-12-06 15:33:02 --> Model "M_produk" initialized
INFO - 2023-12-06 15:33:02 --> Controller Class Initialized
INFO - 2023-12-06 15:33:02 --> Model "M_pelanggan" initialized
INFO - 2023-12-06 15:33:02 --> Model "M_produk" initialized
DEBUG - 2023-12-06 15:33:02 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-06 15:33:03 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-06 15:33:03 --> Model "M_transaksi" initialized
INFO - 2023-12-06 15:33:03 --> Model "M_bank" initialized
INFO - 2023-12-06 15:33:03 --> Model "M_pesan" initialized
DEBUG - 2023-12-06 15:33:03 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-06 15:33:03 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-06 15:33:03 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_produk_detail.php
INFO - 2023-12-06 15:33:03 --> Final output sent to browser
DEBUG - 2023-12-06 15:33:03 --> Total execution time: 0.1056
ERROR - 2023-12-06 15:33:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:33:03 --> Config Class Initialized
INFO - 2023-12-06 15:33:03 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:33:03 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:33:03 --> Utf8 Class Initialized
INFO - 2023-12-06 15:33:03 --> URI Class Initialized
INFO - 2023-12-06 15:33:03 --> Router Class Initialized
INFO - 2023-12-06 15:33:03 --> Output Class Initialized
INFO - 2023-12-06 15:33:03 --> Security Class Initialized
DEBUG - 2023-12-06 15:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:33:03 --> Input Class Initialized
INFO - 2023-12-06 15:33:03 --> Language Class Initialized
INFO - 2023-12-06 15:33:03 --> Loader Class Initialized
INFO - 2023-12-06 15:33:03 --> Helper loaded: url_helper
INFO - 2023-12-06 15:33:03 --> Helper loaded: form_helper
INFO - 2023-12-06 15:33:03 --> Helper loaded: file_helper
INFO - 2023-12-06 15:33:03 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:33:03 --> Form Validation Class Initialized
INFO - 2023-12-06 15:33:03 --> Upload Class Initialized
INFO - 2023-12-06 15:33:03 --> Model "M_auth" initialized
INFO - 2023-12-06 15:33:03 --> Model "M_user" initialized
INFO - 2023-12-06 15:33:03 --> Model "M_produk" initialized
INFO - 2023-12-06 15:33:03 --> Controller Class Initialized
INFO - 2023-12-06 15:33:03 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-06 15:33:03 --> Final output sent to browser
DEBUG - 2023-12-06 15:33:03 --> Total execution time: 0.0251
ERROR - 2023-12-06 15:33:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:33:03 --> Config Class Initialized
INFO - 2023-12-06 15:33:03 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:33:03 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:33:03 --> Utf8 Class Initialized
INFO - 2023-12-06 15:33:03 --> URI Class Initialized
INFO - 2023-12-06 15:33:03 --> Router Class Initialized
INFO - 2023-12-06 15:33:03 --> Output Class Initialized
INFO - 2023-12-06 15:33:03 --> Security Class Initialized
DEBUG - 2023-12-06 15:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:33:03 --> Input Class Initialized
INFO - 2023-12-06 15:33:03 --> Language Class Initialized
INFO - 2023-12-06 15:33:03 --> Loader Class Initialized
INFO - 2023-12-06 15:33:03 --> Helper loaded: url_helper
INFO - 2023-12-06 15:33:03 --> Helper loaded: form_helper
INFO - 2023-12-06 15:33:03 --> Helper loaded: file_helper
INFO - 2023-12-06 15:33:03 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:33:03 --> Form Validation Class Initialized
INFO - 2023-12-06 15:33:03 --> Upload Class Initialized
INFO - 2023-12-06 15:33:03 --> Model "M_auth" initialized
INFO - 2023-12-06 15:33:03 --> Model "M_user" initialized
INFO - 2023-12-06 15:33:03 --> Model "M_produk" initialized
INFO - 2023-12-06 15:33:03 --> Controller Class Initialized
INFO - 2023-12-06 15:33:03 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-06 15:33:03 --> Final output sent to browser
DEBUG - 2023-12-06 15:33:03 --> Total execution time: 0.0300
ERROR - 2023-12-06 15:33:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:33:11 --> Config Class Initialized
INFO - 2023-12-06 15:33:11 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:33:11 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:33:11 --> Utf8 Class Initialized
INFO - 2023-12-06 15:33:11 --> URI Class Initialized
INFO - 2023-12-06 15:33:11 --> Router Class Initialized
INFO - 2023-12-06 15:33:11 --> Output Class Initialized
INFO - 2023-12-06 15:33:11 --> Security Class Initialized
DEBUG - 2023-12-06 15:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:33:11 --> Input Class Initialized
INFO - 2023-12-06 15:33:11 --> Language Class Initialized
INFO - 2023-12-06 15:33:11 --> Loader Class Initialized
INFO - 2023-12-06 15:33:11 --> Helper loaded: url_helper
INFO - 2023-12-06 15:33:11 --> Helper loaded: form_helper
INFO - 2023-12-06 15:33:11 --> Helper loaded: file_helper
INFO - 2023-12-06 15:33:11 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:33:11 --> Form Validation Class Initialized
INFO - 2023-12-06 15:33:11 --> Upload Class Initialized
INFO - 2023-12-06 15:33:11 --> Model "M_auth" initialized
INFO - 2023-12-06 15:33:11 --> Model "M_user" initialized
INFO - 2023-12-06 15:33:11 --> Model "M_produk" initialized
INFO - 2023-12-06 15:33:11 --> Controller Class Initialized
INFO - 2023-12-06 15:33:11 --> Model "M_pelanggan" initialized
INFO - 2023-12-06 15:33:11 --> Model "M_produk" initialized
DEBUG - 2023-12-06 15:33:11 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-06 15:33:11 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-06 15:33:11 --> Model "M_transaksi" initialized
INFO - 2023-12-06 15:33:11 --> Model "M_bank" initialized
INFO - 2023-12-06 15:33:11 --> Model "M_pesan" initialized
DEBUG - 2023-12-06 15:33:11 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-06 15:33:11 --> Email Class Initialized
INFO - 2023-12-06 15:33:12 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-12-06 15:33:14 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:33:15 --> Config Class Initialized
INFO - 2023-12-06 15:33:15 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:33:15 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:33:15 --> Utf8 Class Initialized
INFO - 2023-12-06 15:33:15 --> URI Class Initialized
INFO - 2023-12-06 15:33:15 --> Router Class Initialized
INFO - 2023-12-06 15:33:15 --> Output Class Initialized
INFO - 2023-12-06 15:33:15 --> Security Class Initialized
DEBUG - 2023-12-06 15:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:33:15 --> Input Class Initialized
INFO - 2023-12-06 15:33:15 --> Language Class Initialized
INFO - 2023-12-06 15:33:15 --> Loader Class Initialized
INFO - 2023-12-06 15:33:15 --> Helper loaded: url_helper
INFO - 2023-12-06 15:33:15 --> Helper loaded: form_helper
INFO - 2023-12-06 15:33:15 --> Helper loaded: file_helper
INFO - 2023-12-06 15:33:15 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:33:15 --> Form Validation Class Initialized
INFO - 2023-12-06 15:33:15 --> Upload Class Initialized
INFO - 2023-12-06 15:33:15 --> Model "M_auth" initialized
INFO - 2023-12-06 15:33:15 --> Model "M_user" initialized
INFO - 2023-12-06 15:33:15 --> Model "M_produk" initialized
INFO - 2023-12-06 15:33:15 --> Controller Class Initialized
INFO - 2023-12-06 15:33:15 --> Model "M_pelanggan" initialized
INFO - 2023-12-06 15:33:15 --> Model "M_produk" initialized
DEBUG - 2023-12-06 15:33:15 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-06 15:33:15 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-06 15:33:15 --> Model "M_transaksi" initialized
INFO - 2023-12-06 15:33:15 --> Model "M_bank" initialized
INFO - 2023-12-06 15:33:15 --> Model "M_pesan" initialized
DEBUG - 2023-12-06 15:33:15 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-06 15:33:16 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-06 15:33:16 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-06 15:33:16 --> Final output sent to browser
DEBUG - 2023-12-06 15:33:16 --> Total execution time: 1.2866
ERROR - 2023-12-06 15:33:16 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:33:16 --> Config Class Initialized
INFO - 2023-12-06 15:33:16 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:33:16 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:33:16 --> Utf8 Class Initialized
INFO - 2023-12-06 15:33:16 --> URI Class Initialized
INFO - 2023-12-06 15:33:16 --> Router Class Initialized
INFO - 2023-12-06 15:33:16 --> Output Class Initialized
INFO - 2023-12-06 15:33:16 --> Security Class Initialized
DEBUG - 2023-12-06 15:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:33:16 --> Input Class Initialized
INFO - 2023-12-06 15:33:16 --> Language Class Initialized
INFO - 2023-12-06 15:33:16 --> Loader Class Initialized
INFO - 2023-12-06 15:33:16 --> Helper loaded: url_helper
INFO - 2023-12-06 15:33:16 --> Helper loaded: form_helper
INFO - 2023-12-06 15:33:16 --> Helper loaded: file_helper
INFO - 2023-12-06 15:33:16 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:33:16 --> Form Validation Class Initialized
INFO - 2023-12-06 15:33:16 --> Upload Class Initialized
INFO - 2023-12-06 15:33:16 --> Model "M_auth" initialized
INFO - 2023-12-06 15:33:16 --> Model "M_user" initialized
INFO - 2023-12-06 15:33:16 --> Model "M_produk" initialized
INFO - 2023-12-06 15:33:16 --> Controller Class Initialized
INFO - 2023-12-06 15:33:16 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-06 15:33:16 --> Final output sent to browser
DEBUG - 2023-12-06 15:33:16 --> Total execution time: 0.0276
ERROR - 2023-12-06 15:33:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:33:52 --> Config Class Initialized
INFO - 2023-12-06 15:33:52 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:33:52 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:33:52 --> Utf8 Class Initialized
INFO - 2023-12-06 15:33:52 --> URI Class Initialized
INFO - 2023-12-06 15:33:52 --> Router Class Initialized
INFO - 2023-12-06 15:33:52 --> Output Class Initialized
INFO - 2023-12-06 15:33:52 --> Security Class Initialized
DEBUG - 2023-12-06 15:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:33:52 --> Input Class Initialized
INFO - 2023-12-06 15:33:52 --> Language Class Initialized
INFO - 2023-12-06 15:33:52 --> Loader Class Initialized
INFO - 2023-12-06 15:33:52 --> Helper loaded: url_helper
INFO - 2023-12-06 15:33:52 --> Helper loaded: form_helper
INFO - 2023-12-06 15:33:52 --> Helper loaded: file_helper
INFO - 2023-12-06 15:33:52 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:33:52 --> Form Validation Class Initialized
INFO - 2023-12-06 15:33:52 --> Upload Class Initialized
INFO - 2023-12-06 15:33:52 --> Model "M_auth" initialized
INFO - 2023-12-06 15:33:52 --> Model "M_user" initialized
INFO - 2023-12-06 15:33:52 --> Model "M_produk" initialized
INFO - 2023-12-06 15:33:52 --> Controller Class Initialized
INFO - 2023-12-06 15:33:52 --> Model "M_pelanggan" initialized
INFO - 2023-12-06 15:33:52 --> Model "M_produk" initialized
DEBUG - 2023-12-06 15:33:52 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-06 15:33:52 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-06 15:33:52 --> Model "M_transaksi" initialized
INFO - 2023-12-06 15:33:52 --> Model "M_bank" initialized
INFO - 2023-12-06 15:33:52 --> Model "M_pesan" initialized
DEBUG - 2023-12-06 15:33:52 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-06 15:33:53 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-06 15:33:53 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-06 15:33:53 --> Final output sent to browser
DEBUG - 2023-12-06 15:33:53 --> Total execution time: 1.3825
ERROR - 2023-12-06 15:33:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:33:54 --> Config Class Initialized
INFO - 2023-12-06 15:33:54 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:33:54 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:33:54 --> Utf8 Class Initialized
INFO - 2023-12-06 15:33:54 --> URI Class Initialized
INFO - 2023-12-06 15:33:54 --> Router Class Initialized
INFO - 2023-12-06 15:33:54 --> Output Class Initialized
INFO - 2023-12-06 15:33:54 --> Security Class Initialized
DEBUG - 2023-12-06 15:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:33:54 --> Input Class Initialized
INFO - 2023-12-06 15:33:54 --> Language Class Initialized
INFO - 2023-12-06 15:33:54 --> Loader Class Initialized
INFO - 2023-12-06 15:33:54 --> Helper loaded: url_helper
INFO - 2023-12-06 15:33:54 --> Helper loaded: form_helper
INFO - 2023-12-06 15:33:54 --> Helper loaded: file_helper
INFO - 2023-12-06 15:33:54 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:33:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:33:54 --> Form Validation Class Initialized
INFO - 2023-12-06 15:33:54 --> Upload Class Initialized
INFO - 2023-12-06 15:33:54 --> Model "M_auth" initialized
INFO - 2023-12-06 15:33:54 --> Model "M_user" initialized
INFO - 2023-12-06 15:33:54 --> Model "M_produk" initialized
INFO - 2023-12-06 15:33:54 --> Controller Class Initialized
INFO - 2023-12-06 15:33:54 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-06 15:33:54 --> Final output sent to browser
DEBUG - 2023-12-06 15:33:54 --> Total execution time: 0.0277
ERROR - 2023-12-06 15:33:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:33:56 --> Config Class Initialized
INFO - 2023-12-06 15:33:56 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:33:56 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:33:56 --> Utf8 Class Initialized
INFO - 2023-12-06 15:33:56 --> URI Class Initialized
DEBUG - 2023-12-06 15:33:56 --> No URI present. Default controller set.
INFO - 2023-12-06 15:33:56 --> Router Class Initialized
INFO - 2023-12-06 15:33:56 --> Output Class Initialized
INFO - 2023-12-06 15:33:56 --> Security Class Initialized
DEBUG - 2023-12-06 15:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:33:56 --> Input Class Initialized
INFO - 2023-12-06 15:33:56 --> Language Class Initialized
INFO - 2023-12-06 15:33:56 --> Loader Class Initialized
INFO - 2023-12-06 15:33:56 --> Helper loaded: url_helper
INFO - 2023-12-06 15:33:56 --> Helper loaded: form_helper
INFO - 2023-12-06 15:33:56 --> Helper loaded: file_helper
INFO - 2023-12-06 15:33:56 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:33:56 --> Form Validation Class Initialized
INFO - 2023-12-06 15:33:56 --> Upload Class Initialized
INFO - 2023-12-06 15:33:56 --> Model "M_auth" initialized
INFO - 2023-12-06 15:33:56 --> Model "M_user" initialized
INFO - 2023-12-06 15:33:56 --> Model "M_produk" initialized
INFO - 2023-12-06 15:33:56 --> Controller Class Initialized
INFO - 2023-12-06 15:33:56 --> Model "M_pelanggan" initialized
INFO - 2023-12-06 15:33:56 --> Model "M_produk" initialized
DEBUG - 2023-12-06 15:33:56 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-06 15:33:56 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-06 15:33:56 --> Model "M_transaksi" initialized
INFO - 2023-12-06 15:33:56 --> Model "M_bank" initialized
INFO - 2023-12-06 15:33:56 --> Model "M_pesan" initialized
DEBUG - 2023-12-06 15:33:56 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-06 15:33:56 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-06 15:33:56 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/index.php
INFO - 2023-12-06 15:33:56 --> Final output sent to browser
DEBUG - 2023-12-06 15:33:56 --> Total execution time: 0.0318
ERROR - 2023-12-06 15:33:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:33:56 --> Config Class Initialized
INFO - 2023-12-06 15:33:56 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:33:56 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:33:56 --> Utf8 Class Initialized
INFO - 2023-12-06 15:33:56 --> URI Class Initialized
INFO - 2023-12-06 15:33:56 --> Router Class Initialized
INFO - 2023-12-06 15:33:56 --> Output Class Initialized
INFO - 2023-12-06 15:33:56 --> Security Class Initialized
DEBUG - 2023-12-06 15:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:33:56 --> Input Class Initialized
INFO - 2023-12-06 15:33:56 --> Language Class Initialized
INFO - 2023-12-06 15:33:56 --> Loader Class Initialized
INFO - 2023-12-06 15:33:56 --> Helper loaded: url_helper
INFO - 2023-12-06 15:33:56 --> Helper loaded: form_helper
INFO - 2023-12-06 15:33:56 --> Helper loaded: file_helper
INFO - 2023-12-06 15:33:56 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:33:56 --> Form Validation Class Initialized
INFO - 2023-12-06 15:33:56 --> Upload Class Initialized
INFO - 2023-12-06 15:33:56 --> Model "M_auth" initialized
INFO - 2023-12-06 15:33:56 --> Model "M_user" initialized
INFO - 2023-12-06 15:33:56 --> Model "M_produk" initialized
INFO - 2023-12-06 15:33:56 --> Controller Class Initialized
INFO - 2023-12-06 15:33:56 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-06 15:33:56 --> Final output sent to browser
DEBUG - 2023-12-06 15:33:56 --> Total execution time: 0.0335
ERROR - 2023-12-06 15:33:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:33:59 --> Config Class Initialized
INFO - 2023-12-06 15:33:59 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:33:59 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:33:59 --> Utf8 Class Initialized
INFO - 2023-12-06 15:33:59 --> URI Class Initialized
INFO - 2023-12-06 15:33:59 --> Router Class Initialized
INFO - 2023-12-06 15:33:59 --> Output Class Initialized
INFO - 2023-12-06 15:33:59 --> Security Class Initialized
DEBUG - 2023-12-06 15:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:33:59 --> Input Class Initialized
INFO - 2023-12-06 15:33:59 --> Language Class Initialized
INFO - 2023-12-06 15:33:59 --> Loader Class Initialized
INFO - 2023-12-06 15:33:59 --> Helper loaded: url_helper
INFO - 2023-12-06 15:33:59 --> Helper loaded: form_helper
INFO - 2023-12-06 15:33:59 --> Helper loaded: file_helper
INFO - 2023-12-06 15:33:59 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:33:59 --> Form Validation Class Initialized
INFO - 2023-12-06 15:33:59 --> Upload Class Initialized
INFO - 2023-12-06 15:33:59 --> Model "M_auth" initialized
INFO - 2023-12-06 15:33:59 --> Model "M_user" initialized
INFO - 2023-12-06 15:33:59 --> Model "M_produk" initialized
INFO - 2023-12-06 15:33:59 --> Controller Class Initialized
INFO - 2023-12-06 15:33:59 --> Model "M_pelanggan" initialized
INFO - 2023-12-06 15:33:59 --> Model "M_produk" initialized
DEBUG - 2023-12-06 15:33:59 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-06 15:33:59 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-06 15:33:59 --> Model "M_transaksi" initialized
INFO - 2023-12-06 15:33:59 --> Model "M_bank" initialized
INFO - 2023-12-06 15:33:59 --> Model "M_pesan" initialized
DEBUG - 2023-12-06 15:33:59 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-06 15:33:59 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-06 15:33:59 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_produk_detail.php
INFO - 2023-12-06 15:33:59 --> Final output sent to browser
DEBUG - 2023-12-06 15:33:59 --> Total execution time: 0.0648
ERROR - 2023-12-06 15:33:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:33:59 --> Config Class Initialized
INFO - 2023-12-06 15:33:59 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:33:59 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:33:59 --> Utf8 Class Initialized
INFO - 2023-12-06 15:33:59 --> URI Class Initialized
INFO - 2023-12-06 15:33:59 --> Router Class Initialized
ERROR - 2023-12-06 15:33:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:33:59 --> Output Class Initialized
INFO - 2023-12-06 15:33:59 --> Security Class Initialized
INFO - 2023-12-06 15:33:59 --> Config Class Initialized
INFO - 2023-12-06 15:33:59 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:33:59 --> Input Class Initialized
INFO - 2023-12-06 15:33:59 --> Language Class Initialized
DEBUG - 2023-12-06 15:33:59 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:33:59 --> Utf8 Class Initialized
INFO - 2023-12-06 15:33:59 --> URI Class Initialized
INFO - 2023-12-06 15:33:59 --> Loader Class Initialized
INFO - 2023-12-06 15:33:59 --> Router Class Initialized
INFO - 2023-12-06 15:33:59 --> Helper loaded: url_helper
INFO - 2023-12-06 15:33:59 --> Output Class Initialized
INFO - 2023-12-06 15:33:59 --> Helper loaded: form_helper
INFO - 2023-12-06 15:33:59 --> Security Class Initialized
INFO - 2023-12-06 15:33:59 --> Helper loaded: file_helper
DEBUG - 2023-12-06 15:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:33:59 --> Input Class Initialized
INFO - 2023-12-06 15:33:59 --> Language Class Initialized
INFO - 2023-12-06 15:33:59 --> Loader Class Initialized
INFO - 2023-12-06 15:33:59 --> Database Driver Class Initialized
INFO - 2023-12-06 15:33:59 --> Helper loaded: url_helper
INFO - 2023-12-06 15:33:59 --> Helper loaded: form_helper
INFO - 2023-12-06 15:33:59 --> Helper loaded: file_helper
DEBUG - 2023-12-06 15:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:33:59 --> Form Validation Class Initialized
INFO - 2023-12-06 15:33:59 --> Database Driver Class Initialized
INFO - 2023-12-06 15:33:59 --> Upload Class Initialized
INFO - 2023-12-06 15:33:59 --> Model "M_auth" initialized
INFO - 2023-12-06 15:33:59 --> Model "M_user" initialized
INFO - 2023-12-06 15:33:59 --> Model "M_produk" initialized
INFO - 2023-12-06 15:33:59 --> Controller Class Initialized
DEBUG - 2023-12-06 15:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:33:59 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-06 15:33:59 --> Final output sent to browser
DEBUG - 2023-12-06 15:33:59 --> Total execution time: 0.0257
INFO - 2023-12-06 15:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:33:59 --> Form Validation Class Initialized
INFO - 2023-12-06 15:33:59 --> Upload Class Initialized
INFO - 2023-12-06 15:33:59 --> Model "M_auth" initialized
INFO - 2023-12-06 15:33:59 --> Model "M_user" initialized
INFO - 2023-12-06 15:33:59 --> Model "M_produk" initialized
INFO - 2023-12-06 15:33:59 --> Controller Class Initialized
INFO - 2023-12-06 15:33:59 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-06 15:33:59 --> Final output sent to browser
DEBUG - 2023-12-06 15:33:59 --> Total execution time: 0.0251
ERROR - 2023-12-06 15:34:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:34:07 --> Config Class Initialized
INFO - 2023-12-06 15:34:07 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:34:07 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:34:07 --> Utf8 Class Initialized
INFO - 2023-12-06 15:34:07 --> URI Class Initialized
INFO - 2023-12-06 15:34:07 --> Router Class Initialized
INFO - 2023-12-06 15:34:07 --> Output Class Initialized
INFO - 2023-12-06 15:34:07 --> Security Class Initialized
DEBUG - 2023-12-06 15:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:34:07 --> Input Class Initialized
INFO - 2023-12-06 15:34:07 --> Language Class Initialized
INFO - 2023-12-06 15:34:07 --> Loader Class Initialized
INFO - 2023-12-06 15:34:07 --> Helper loaded: url_helper
INFO - 2023-12-06 15:34:07 --> Helper loaded: form_helper
INFO - 2023-12-06 15:34:07 --> Helper loaded: file_helper
INFO - 2023-12-06 15:34:07 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:34:07 --> Form Validation Class Initialized
INFO - 2023-12-06 15:34:07 --> Upload Class Initialized
INFO - 2023-12-06 15:34:07 --> Model "M_auth" initialized
INFO - 2023-12-06 15:34:07 --> Model "M_user" initialized
INFO - 2023-12-06 15:34:07 --> Model "M_produk" initialized
INFO - 2023-12-06 15:34:07 --> Controller Class Initialized
INFO - 2023-12-06 15:34:07 --> Model "M_pelanggan" initialized
INFO - 2023-12-06 15:34:07 --> Model "M_produk" initialized
DEBUG - 2023-12-06 15:34:07 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-06 15:34:07 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-06 15:34:07 --> Model "M_transaksi" initialized
INFO - 2023-12-06 15:34:07 --> Model "M_bank" initialized
INFO - 2023-12-06 15:34:07 --> Model "M_pesan" initialized
DEBUG - 2023-12-06 15:34:07 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-06 15:34:07 --> Email Class Initialized
INFO - 2023-12-06 15:34:08 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-12-06 15:34:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:34:11 --> Config Class Initialized
INFO - 2023-12-06 15:34:11 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:34:11 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:34:11 --> Utf8 Class Initialized
INFO - 2023-12-06 15:34:11 --> URI Class Initialized
INFO - 2023-12-06 15:34:11 --> Router Class Initialized
INFO - 2023-12-06 15:34:11 --> Output Class Initialized
INFO - 2023-12-06 15:34:11 --> Security Class Initialized
DEBUG - 2023-12-06 15:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:34:11 --> Input Class Initialized
INFO - 2023-12-06 15:34:11 --> Language Class Initialized
INFO - 2023-12-06 15:34:11 --> Loader Class Initialized
INFO - 2023-12-06 15:34:11 --> Helper loaded: url_helper
INFO - 2023-12-06 15:34:11 --> Helper loaded: form_helper
INFO - 2023-12-06 15:34:11 --> Helper loaded: file_helper
INFO - 2023-12-06 15:34:11 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:34:11 --> Form Validation Class Initialized
INFO - 2023-12-06 15:34:11 --> Upload Class Initialized
INFO - 2023-12-06 15:34:11 --> Model "M_auth" initialized
INFO - 2023-12-06 15:34:11 --> Model "M_user" initialized
INFO - 2023-12-06 15:34:11 --> Model "M_produk" initialized
INFO - 2023-12-06 15:34:11 --> Controller Class Initialized
INFO - 2023-12-06 15:34:11 --> Model "M_pelanggan" initialized
INFO - 2023-12-06 15:34:11 --> Model "M_produk" initialized
DEBUG - 2023-12-06 15:34:11 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-06 15:34:11 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-06 15:34:11 --> Model "M_transaksi" initialized
INFO - 2023-12-06 15:34:11 --> Model "M_bank" initialized
INFO - 2023-12-06 15:34:11 --> Model "M_pesan" initialized
DEBUG - 2023-12-06 15:34:11 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-06 15:34:12 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-06 15:34:12 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-06 15:34:12 --> Final output sent to browser
DEBUG - 2023-12-06 15:34:12 --> Total execution time: 0.7435
ERROR - 2023-12-06 15:34:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:34:12 --> Config Class Initialized
INFO - 2023-12-06 15:34:12 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:34:12 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:34:12 --> Utf8 Class Initialized
INFO - 2023-12-06 15:34:12 --> URI Class Initialized
INFO - 2023-12-06 15:34:12 --> Router Class Initialized
INFO - 2023-12-06 15:34:12 --> Output Class Initialized
INFO - 2023-12-06 15:34:12 --> Security Class Initialized
DEBUG - 2023-12-06 15:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:34:12 --> Input Class Initialized
INFO - 2023-12-06 15:34:12 --> Language Class Initialized
INFO - 2023-12-06 15:34:12 --> Loader Class Initialized
INFO - 2023-12-06 15:34:12 --> Helper loaded: url_helper
INFO - 2023-12-06 15:34:12 --> Helper loaded: form_helper
INFO - 2023-12-06 15:34:12 --> Helper loaded: file_helper
INFO - 2023-12-06 15:34:12 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:34:12 --> Form Validation Class Initialized
INFO - 2023-12-06 15:34:12 --> Upload Class Initialized
INFO - 2023-12-06 15:34:12 --> Model "M_auth" initialized
INFO - 2023-12-06 15:34:12 --> Model "M_user" initialized
INFO - 2023-12-06 15:34:12 --> Model "M_produk" initialized
INFO - 2023-12-06 15:34:12 --> Controller Class Initialized
INFO - 2023-12-06 15:34:12 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-06 15:34:12 --> Final output sent to browser
DEBUG - 2023-12-06 15:34:12 --> Total execution time: 0.0372
ERROR - 2023-12-06 15:34:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:34:40 --> Config Class Initialized
INFO - 2023-12-06 15:34:40 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:34:40 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:34:40 --> Utf8 Class Initialized
INFO - 2023-12-06 15:34:40 --> URI Class Initialized
INFO - 2023-12-06 15:34:40 --> Router Class Initialized
INFO - 2023-12-06 15:34:40 --> Output Class Initialized
INFO - 2023-12-06 15:34:40 --> Security Class Initialized
DEBUG - 2023-12-06 15:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:34:40 --> Input Class Initialized
INFO - 2023-12-06 15:34:40 --> Language Class Initialized
INFO - 2023-12-06 15:34:40 --> Loader Class Initialized
INFO - 2023-12-06 15:34:40 --> Helper loaded: url_helper
INFO - 2023-12-06 15:34:40 --> Helper loaded: form_helper
INFO - 2023-12-06 15:34:40 --> Helper loaded: file_helper
INFO - 2023-12-06 15:34:40 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:34:40 --> Form Validation Class Initialized
INFO - 2023-12-06 15:34:40 --> Upload Class Initialized
INFO - 2023-12-06 15:34:40 --> Model "M_auth" initialized
INFO - 2023-12-06 15:34:40 --> Model "M_user" initialized
INFO - 2023-12-06 15:34:40 --> Model "M_produk" initialized
INFO - 2023-12-06 15:34:40 --> Controller Class Initialized
INFO - 2023-12-06 15:34:40 --> Model "M_pelanggan" initialized
INFO - 2023-12-06 15:34:40 --> Model "M_produk" initialized
DEBUG - 2023-12-06 15:34:40 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-06 15:34:40 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-06 15:34:40 --> Model "M_transaksi" initialized
INFO - 2023-12-06 15:34:40 --> Model "M_bank" initialized
INFO - 2023-12-06 15:34:40 --> Model "M_pesan" initialized
DEBUG - 2023-12-06 15:34:40 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-06 15:34:42 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-06 15:34:42 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-06 15:34:42 --> Final output sent to browser
DEBUG - 2023-12-06 15:34:42 --> Total execution time: 1.5388
ERROR - 2023-12-06 15:34:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:34:43 --> Config Class Initialized
INFO - 2023-12-06 15:34:43 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:34:43 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:34:43 --> Utf8 Class Initialized
INFO - 2023-12-06 15:34:43 --> URI Class Initialized
INFO - 2023-12-06 15:34:43 --> Router Class Initialized
INFO - 2023-12-06 15:34:43 --> Output Class Initialized
INFO - 2023-12-06 15:34:43 --> Security Class Initialized
DEBUG - 2023-12-06 15:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:34:43 --> Input Class Initialized
INFO - 2023-12-06 15:34:43 --> Language Class Initialized
INFO - 2023-12-06 15:34:43 --> Loader Class Initialized
INFO - 2023-12-06 15:34:43 --> Helper loaded: url_helper
INFO - 2023-12-06 15:34:43 --> Helper loaded: form_helper
INFO - 2023-12-06 15:34:43 --> Helper loaded: file_helper
INFO - 2023-12-06 15:34:43 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:34:43 --> Form Validation Class Initialized
INFO - 2023-12-06 15:34:43 --> Upload Class Initialized
INFO - 2023-12-06 15:34:43 --> Model "M_auth" initialized
INFO - 2023-12-06 15:34:43 --> Model "M_user" initialized
INFO - 2023-12-06 15:34:43 --> Model "M_produk" initialized
INFO - 2023-12-06 15:34:43 --> Controller Class Initialized
INFO - 2023-12-06 15:34:43 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-06 15:34:43 --> Final output sent to browser
DEBUG - 2023-12-06 15:34:43 --> Total execution time: 0.0774
ERROR - 2023-12-06 15:36:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:36:32 --> Config Class Initialized
INFO - 2023-12-06 15:36:32 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:36:32 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:36:32 --> Utf8 Class Initialized
INFO - 2023-12-06 15:36:32 --> URI Class Initialized
DEBUG - 2023-12-06 15:36:32 --> No URI present. Default controller set.
INFO - 2023-12-06 15:36:32 --> Router Class Initialized
INFO - 2023-12-06 15:36:32 --> Output Class Initialized
INFO - 2023-12-06 15:36:32 --> Security Class Initialized
DEBUG - 2023-12-06 15:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:36:32 --> Input Class Initialized
INFO - 2023-12-06 15:36:32 --> Language Class Initialized
INFO - 2023-12-06 15:36:32 --> Loader Class Initialized
INFO - 2023-12-06 15:36:32 --> Helper loaded: url_helper
INFO - 2023-12-06 15:36:32 --> Helper loaded: form_helper
INFO - 2023-12-06 15:36:32 --> Helper loaded: file_helper
INFO - 2023-12-06 15:36:32 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:36:32 --> Form Validation Class Initialized
INFO - 2023-12-06 15:36:32 --> Upload Class Initialized
INFO - 2023-12-06 15:36:32 --> Model "M_auth" initialized
INFO - 2023-12-06 15:36:32 --> Model "M_user" initialized
INFO - 2023-12-06 15:36:32 --> Model "M_produk" initialized
INFO - 2023-12-06 15:36:32 --> Controller Class Initialized
INFO - 2023-12-06 15:36:32 --> Model "M_pelanggan" initialized
INFO - 2023-12-06 15:36:32 --> Model "M_produk" initialized
DEBUG - 2023-12-06 15:36:32 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-06 15:36:32 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-06 15:36:32 --> Model "M_transaksi" initialized
INFO - 2023-12-06 15:36:32 --> Model "M_bank" initialized
INFO - 2023-12-06 15:36:32 --> Model "M_pesan" initialized
DEBUG - 2023-12-06 15:36:32 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-06 15:36:32 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-06 15:36:32 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/index.php
INFO - 2023-12-06 15:36:32 --> Final output sent to browser
DEBUG - 2023-12-06 15:36:32 --> Total execution time: 0.0384
ERROR - 2023-12-06 15:36:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:36:32 --> Config Class Initialized
INFO - 2023-12-06 15:36:32 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:36:32 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:36:32 --> Utf8 Class Initialized
INFO - 2023-12-06 15:36:32 --> URI Class Initialized
INFO - 2023-12-06 15:36:32 --> Router Class Initialized
INFO - 2023-12-06 15:36:32 --> Output Class Initialized
INFO - 2023-12-06 15:36:32 --> Security Class Initialized
DEBUG - 2023-12-06 15:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:36:32 --> Input Class Initialized
INFO - 2023-12-06 15:36:32 --> Language Class Initialized
INFO - 2023-12-06 15:36:32 --> Loader Class Initialized
INFO - 2023-12-06 15:36:32 --> Helper loaded: url_helper
INFO - 2023-12-06 15:36:32 --> Helper loaded: form_helper
INFO - 2023-12-06 15:36:32 --> Helper loaded: file_helper
INFO - 2023-12-06 15:36:32 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:36:32 --> Form Validation Class Initialized
INFO - 2023-12-06 15:36:32 --> Upload Class Initialized
INFO - 2023-12-06 15:36:32 --> Model "M_auth" initialized
INFO - 2023-12-06 15:36:32 --> Model "M_user" initialized
INFO - 2023-12-06 15:36:32 --> Model "M_produk" initialized
INFO - 2023-12-06 15:36:32 --> Controller Class Initialized
INFO - 2023-12-06 15:36:32 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-06 15:36:32 --> Final output sent to browser
DEBUG - 2023-12-06 15:36:32 --> Total execution time: 0.0275
ERROR - 2023-12-06 15:36:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:36:45 --> Config Class Initialized
INFO - 2023-12-06 15:36:45 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:36:45 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:36:45 --> Utf8 Class Initialized
INFO - 2023-12-06 15:36:45 --> URI Class Initialized
INFO - 2023-12-06 15:36:45 --> Router Class Initialized
INFO - 2023-12-06 15:36:45 --> Output Class Initialized
INFO - 2023-12-06 15:36:45 --> Security Class Initialized
DEBUG - 2023-12-06 15:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:36:45 --> Input Class Initialized
INFO - 2023-12-06 15:36:45 --> Language Class Initialized
INFO - 2023-12-06 15:36:45 --> Loader Class Initialized
INFO - 2023-12-06 15:36:45 --> Helper loaded: url_helper
INFO - 2023-12-06 15:36:45 --> Helper loaded: form_helper
INFO - 2023-12-06 15:36:45 --> Helper loaded: file_helper
INFO - 2023-12-06 15:36:45 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:36:45 --> Form Validation Class Initialized
INFO - 2023-12-06 15:36:45 --> Upload Class Initialized
INFO - 2023-12-06 15:36:45 --> Model "M_auth" initialized
INFO - 2023-12-06 15:36:45 --> Model "M_user" initialized
INFO - 2023-12-06 15:36:45 --> Model "M_produk" initialized
INFO - 2023-12-06 15:36:45 --> Controller Class Initialized
INFO - 2023-12-06 15:36:45 --> Model "M_pelanggan" initialized
INFO - 2023-12-06 15:36:45 --> Model "M_produk" initialized
DEBUG - 2023-12-06 15:36:45 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-06 15:36:45 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-06 15:36:45 --> Model "M_transaksi" initialized
INFO - 2023-12-06 15:36:45 --> Model "M_bank" initialized
INFO - 2023-12-06 15:36:45 --> Model "M_pesan" initialized
DEBUG - 2023-12-06 15:36:45 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-06 15:36:46 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-06 15:36:46 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_produk_detail.php
INFO - 2023-12-06 15:36:46 --> Final output sent to browser
DEBUG - 2023-12-06 15:36:46 --> Total execution time: 0.0795
ERROR - 2023-12-06 15:36:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:36:46 --> Config Class Initialized
INFO - 2023-12-06 15:36:46 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:36:46 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:36:46 --> Utf8 Class Initialized
INFO - 2023-12-06 15:36:46 --> URI Class Initialized
INFO - 2023-12-06 15:36:46 --> Router Class Initialized
INFO - 2023-12-06 15:36:46 --> Output Class Initialized
INFO - 2023-12-06 15:36:46 --> Security Class Initialized
DEBUG - 2023-12-06 15:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:36:46 --> Input Class Initialized
INFO - 2023-12-06 15:36:46 --> Language Class Initialized
INFO - 2023-12-06 15:36:46 --> Loader Class Initialized
INFO - 2023-12-06 15:36:46 --> Helper loaded: url_helper
INFO - 2023-12-06 15:36:46 --> Helper loaded: form_helper
INFO - 2023-12-06 15:36:46 --> Helper loaded: file_helper
INFO - 2023-12-06 15:36:46 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:36:46 --> Form Validation Class Initialized
INFO - 2023-12-06 15:36:46 --> Upload Class Initialized
INFO - 2023-12-06 15:36:46 --> Model "M_auth" initialized
INFO - 2023-12-06 15:36:46 --> Model "M_user" initialized
INFO - 2023-12-06 15:36:46 --> Model "M_produk" initialized
INFO - 2023-12-06 15:36:46 --> Controller Class Initialized
INFO - 2023-12-06 15:36:46 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-06 15:36:46 --> Final output sent to browser
DEBUG - 2023-12-06 15:36:46 --> Total execution time: 0.0351
ERROR - 2023-12-06 15:36:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:36:53 --> Config Class Initialized
INFO - 2023-12-06 15:36:53 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:36:53 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:36:53 --> Utf8 Class Initialized
INFO - 2023-12-06 15:36:53 --> URI Class Initialized
INFO - 2023-12-06 15:36:53 --> Router Class Initialized
INFO - 2023-12-06 15:36:53 --> Output Class Initialized
INFO - 2023-12-06 15:36:53 --> Security Class Initialized
DEBUG - 2023-12-06 15:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:36:53 --> Input Class Initialized
INFO - 2023-12-06 15:36:53 --> Language Class Initialized
INFO - 2023-12-06 15:36:53 --> Loader Class Initialized
INFO - 2023-12-06 15:36:53 --> Helper loaded: url_helper
INFO - 2023-12-06 15:36:53 --> Helper loaded: form_helper
INFO - 2023-12-06 15:36:53 --> Helper loaded: file_helper
INFO - 2023-12-06 15:36:53 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:36:53 --> Form Validation Class Initialized
INFO - 2023-12-06 15:36:53 --> Upload Class Initialized
INFO - 2023-12-06 15:36:53 --> Model "M_auth" initialized
INFO - 2023-12-06 15:36:53 --> Model "M_user" initialized
INFO - 2023-12-06 15:36:53 --> Model "M_produk" initialized
INFO - 2023-12-06 15:36:53 --> Controller Class Initialized
INFO - 2023-12-06 15:36:53 --> Model "M_pelanggan" initialized
INFO - 2023-12-06 15:36:53 --> Model "M_produk" initialized
DEBUG - 2023-12-06 15:36:53 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-06 15:36:53 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-06 15:36:53 --> Model "M_transaksi" initialized
INFO - 2023-12-06 15:36:53 --> Model "M_bank" initialized
INFO - 2023-12-06 15:36:53 --> Model "M_pesan" initialized
DEBUG - 2023-12-06 15:36:53 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-06 15:36:53 --> Email Class Initialized
INFO - 2023-12-06 15:36:54 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-12-06 15:36:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-06 15:36:57 --> Config Class Initialized
INFO - 2023-12-06 15:36:57 --> Hooks Class Initialized
DEBUG - 2023-12-06 15:36:57 --> UTF-8 Support Enabled
INFO - 2023-12-06 15:36:57 --> Utf8 Class Initialized
INFO - 2023-12-06 15:36:57 --> URI Class Initialized
INFO - 2023-12-06 15:36:57 --> Router Class Initialized
INFO - 2023-12-06 15:36:57 --> Output Class Initialized
INFO - 2023-12-06 15:36:57 --> Security Class Initialized
DEBUG - 2023-12-06 15:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 15:36:57 --> Input Class Initialized
INFO - 2023-12-06 15:36:57 --> Language Class Initialized
INFO - 2023-12-06 15:36:57 --> Loader Class Initialized
INFO - 2023-12-06 15:36:57 --> Helper loaded: url_helper
INFO - 2023-12-06 15:36:57 --> Helper loaded: form_helper
INFO - 2023-12-06 15:36:57 --> Helper loaded: file_helper
INFO - 2023-12-06 15:36:57 --> Database Driver Class Initialized
DEBUG - 2023-12-06 15:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-06 15:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 15:36:57 --> Form Validation Class Initialized
INFO - 2023-12-06 15:36:57 --> Upload Class Initialized
INFO - 2023-12-06 15:36:57 --> Model "M_auth" initialized
INFO - 2023-12-06 15:36:57 --> Model "M_user" initialized
INFO - 2023-12-06 15:36:57 --> Model "M_produk" initialized
INFO - 2023-12-06 15:36:57 --> Controller Class Initialized
INFO - 2023-12-06 15:36:57 --> Model "M_pelanggan" initialized
INFO - 2023-12-06 15:36:57 --> Model "M_produk" initialized
DEBUG - 2023-12-06 15:36:57 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-06 15:36:57 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-06 15:36:57 --> Model "M_transaksi" initialized
INFO - 2023-12-06 15:36:57 --> Model "M_bank" initialized
INFO - 2023-12-06 15:36:57 --> Model "M_pesan" initialized
DEBUG - 2023-12-06 15:36:57 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-06 15:36:57 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-06 15:36:57 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-06 15:36:57 --> Final output sent to browser
DEBUG - 2023-12-06 15:36:57 --> Total execution time: 0.5678
