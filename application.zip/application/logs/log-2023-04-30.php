<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-04-30 16:03:56 --> Config Class Initialized
INFO - 2023-04-30 16:03:56 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:03:56 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:03:56 --> Utf8 Class Initialized
INFO - 2023-04-30 16:03:56 --> URI Class Initialized
DEBUG - 2023-04-30 16:03:56 --> No URI present. Default controller set.
INFO - 2023-04-30 16:03:56 --> Router Class Initialized
INFO - 2023-04-30 16:03:57 --> Output Class Initialized
INFO - 2023-04-30 16:03:57 --> Security Class Initialized
DEBUG - 2023-04-30 16:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:03:57 --> Input Class Initialized
INFO - 2023-04-30 16:03:57 --> Language Class Initialized
INFO - 2023-04-30 16:03:57 --> Loader Class Initialized
INFO - 2023-04-30 16:03:57 --> Helper loaded: url_helper
INFO - 2023-04-30 16:03:57 --> Helper loaded: form_helper
INFO - 2023-04-30 16:03:57 --> Helper loaded: file_helper
INFO - 2023-04-30 16:03:57 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:03:57 --> Form Validation Class Initialized
INFO - 2023-04-30 16:03:57 --> Upload Class Initialized
INFO - 2023-04-30 16:03:57 --> Model "M_auth" initialized
INFO - 2023-04-30 16:03:57 --> Model "M_user" initialized
INFO - 2023-04-30 16:03:57 --> Model "M_produk" initialized
INFO - 2023-04-30 16:03:57 --> Controller Class Initialized
INFO - 2023-04-30 16:03:57 --> Model "M_pelanggan" initialized
INFO - 2023-04-30 16:03:57 --> Model "M_produk" initialized
DEBUG - 2023-04-30 16:03:57 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-30 16:03:57 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-30 16:03:57 --> Model "M_transaksi" initialized
INFO - 2023-04-30 16:03:57 --> Model "M_bank" initialized
INFO - 2023-04-30 16:03:57 --> Model "M_pesan" initialized
INFO - 2023-04-30 16:03:58 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-30 16:03:58 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-04-30 16:03:58 --> Final output sent to browser
DEBUG - 2023-04-30 16:03:58 --> Total execution time: 1.4083
INFO - 2023-04-30 16:05:37 --> Config Class Initialized
INFO - 2023-04-30 16:05:37 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:05:37 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:05:37 --> Utf8 Class Initialized
INFO - 2023-04-30 16:05:37 --> URI Class Initialized
DEBUG - 2023-04-30 16:05:37 --> No URI present. Default controller set.
INFO - 2023-04-30 16:05:37 --> Router Class Initialized
INFO - 2023-04-30 16:05:37 --> Output Class Initialized
INFO - 2023-04-30 16:05:37 --> Security Class Initialized
DEBUG - 2023-04-30 16:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:05:37 --> Input Class Initialized
INFO - 2023-04-30 16:05:37 --> Language Class Initialized
INFO - 2023-04-30 16:05:37 --> Loader Class Initialized
INFO - 2023-04-30 16:05:38 --> Helper loaded: url_helper
INFO - 2023-04-30 16:05:38 --> Helper loaded: form_helper
INFO - 2023-04-30 16:05:38 --> Helper loaded: file_helper
INFO - 2023-04-30 16:05:38 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:05:38 --> Form Validation Class Initialized
INFO - 2023-04-30 16:05:38 --> Upload Class Initialized
INFO - 2023-04-30 16:05:38 --> Model "M_auth" initialized
INFO - 2023-04-30 16:05:38 --> Model "M_user" initialized
INFO - 2023-04-30 16:05:38 --> Model "M_produk" initialized
INFO - 2023-04-30 16:05:38 --> Controller Class Initialized
INFO - 2023-04-30 16:05:38 --> Model "M_pelanggan" initialized
INFO - 2023-04-30 16:05:38 --> Model "M_produk" initialized
DEBUG - 2023-04-30 16:05:38 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-30 16:05:38 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-30 16:05:38 --> Model "M_transaksi" initialized
INFO - 2023-04-30 16:05:38 --> Model "M_bank" initialized
INFO - 2023-04-30 16:05:38 --> Model "M_pesan" initialized
INFO - 2023-04-30 16:05:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-04-30 16:05:38 --> Email Class Initialized
ERROR - 2023-04-30 16:05:43 --> Severity: Warning --> fsockopen(): Unable to connect to ssl://smtp.googlemail.com:465 (A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond) C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\system\libraries\Email.php 2070
INFO - 2023-04-30 16:05:43 --> Language file loaded: language/english/email_lang.php
INFO - 2023-04-30 16:05:43 --> Config Class Initialized
INFO - 2023-04-30 16:05:43 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:05:43 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:05:43 --> Utf8 Class Initialized
INFO - 2023-04-30 16:05:43 --> URI Class Initialized
DEBUG - 2023-04-30 16:05:43 --> No URI present. Default controller set.
INFO - 2023-04-30 16:05:43 --> Router Class Initialized
INFO - 2023-04-30 16:05:43 --> Output Class Initialized
INFO - 2023-04-30 16:05:43 --> Security Class Initialized
DEBUG - 2023-04-30 16:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:05:43 --> Input Class Initialized
INFO - 2023-04-30 16:05:43 --> Language Class Initialized
INFO - 2023-04-30 16:05:43 --> Loader Class Initialized
INFO - 2023-04-30 16:05:43 --> Helper loaded: url_helper
INFO - 2023-04-30 16:05:43 --> Helper loaded: form_helper
INFO - 2023-04-30 16:05:43 --> Helper loaded: file_helper
INFO - 2023-04-30 16:05:43 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:05:43 --> Form Validation Class Initialized
INFO - 2023-04-30 16:05:43 --> Upload Class Initialized
INFO - 2023-04-30 16:05:43 --> Model "M_auth" initialized
INFO - 2023-04-30 16:05:43 --> Model "M_user" initialized
INFO - 2023-04-30 16:05:43 --> Model "M_produk" initialized
INFO - 2023-04-30 16:05:43 --> Controller Class Initialized
INFO - 2023-04-30 16:05:43 --> Model "M_pelanggan" initialized
INFO - 2023-04-30 16:05:43 --> Model "M_produk" initialized
DEBUG - 2023-04-30 16:05:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-30 16:05:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-30 16:05:43 --> Model "M_transaksi" initialized
INFO - 2023-04-30 16:05:43 --> Model "M_bank" initialized
INFO - 2023-04-30 16:05:43 --> Model "M_pesan" initialized
INFO - 2023-04-30 16:05:43 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-30 16:05:43 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-04-30 16:05:43 --> Final output sent to browser
DEBUG - 2023-04-30 16:05:43 --> Total execution time: 0.1588
INFO - 2023-04-30 16:05:56 --> Config Class Initialized
INFO - 2023-04-30 16:05:56 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:05:56 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:05:56 --> Utf8 Class Initialized
INFO - 2023-04-30 16:05:56 --> URI Class Initialized
INFO - 2023-04-30 16:05:56 --> Router Class Initialized
INFO - 2023-04-30 16:05:56 --> Output Class Initialized
INFO - 2023-04-30 16:05:56 --> Security Class Initialized
DEBUG - 2023-04-30 16:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:05:56 --> Input Class Initialized
INFO - 2023-04-30 16:05:56 --> Language Class Initialized
INFO - 2023-04-30 16:05:57 --> Loader Class Initialized
INFO - 2023-04-30 16:05:57 --> Helper loaded: url_helper
INFO - 2023-04-30 16:05:57 --> Helper loaded: form_helper
INFO - 2023-04-30 16:05:57 --> Helper loaded: file_helper
INFO - 2023-04-30 16:05:57 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:05:57 --> Form Validation Class Initialized
INFO - 2023-04-30 16:05:57 --> Upload Class Initialized
INFO - 2023-04-30 16:05:57 --> Model "M_auth" initialized
INFO - 2023-04-30 16:05:57 --> Model "M_user" initialized
INFO - 2023-04-30 16:05:57 --> Model "M_produk" initialized
INFO - 2023-04-30 16:05:57 --> Controller Class Initialized
INFO - 2023-04-30 16:05:57 --> Model "M_pelanggan" initialized
INFO - 2023-04-30 16:05:57 --> Model "M_produk" initialized
DEBUG - 2023-04-30 16:05:57 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-30 16:05:57 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-30 16:05:57 --> Model "M_transaksi" initialized
INFO - 2023-04-30 16:05:57 --> Model "M_bank" initialized
INFO - 2023-04-30 16:05:57 --> Model "M_pesan" initialized
INFO - 2023-04-30 16:05:57 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-30 16:05:57 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/v_produk_detail.php
INFO - 2023-04-30 16:05:57 --> Final output sent to browser
DEBUG - 2023-04-30 16:05:57 --> Total execution time: 0.1855
INFO - 2023-04-30 16:06:07 --> Config Class Initialized
INFO - 2023-04-30 16:06:07 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:06:07 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:06:07 --> Utf8 Class Initialized
INFO - 2023-04-30 16:06:07 --> URI Class Initialized
INFO - 2023-04-30 16:06:07 --> Router Class Initialized
INFO - 2023-04-30 16:06:07 --> Output Class Initialized
INFO - 2023-04-30 16:06:07 --> Security Class Initialized
DEBUG - 2023-04-30 16:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:06:07 --> Input Class Initialized
INFO - 2023-04-30 16:06:07 --> Language Class Initialized
INFO - 2023-04-30 16:06:07 --> Loader Class Initialized
INFO - 2023-04-30 16:06:07 --> Helper loaded: url_helper
INFO - 2023-04-30 16:06:07 --> Helper loaded: form_helper
INFO - 2023-04-30 16:06:07 --> Helper loaded: file_helper
INFO - 2023-04-30 16:06:07 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:06:07 --> Form Validation Class Initialized
INFO - 2023-04-30 16:06:07 --> Upload Class Initialized
INFO - 2023-04-30 16:06:07 --> Model "M_auth" initialized
INFO - 2023-04-30 16:06:07 --> Model "M_user" initialized
INFO - 2023-04-30 16:06:07 --> Model "M_produk" initialized
INFO - 2023-04-30 16:06:07 --> Controller Class Initialized
INFO - 2023-04-30 16:06:07 --> Model "M_pelanggan" initialized
INFO - 2023-04-30 16:06:07 --> Model "M_produk" initialized
DEBUG - 2023-04-30 16:06:07 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-30 16:06:07 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-30 16:06:07 --> Model "M_transaksi" initialized
INFO - 2023-04-30 16:06:07 --> Model "M_bank" initialized
INFO - 2023-04-30 16:06:07 --> Model "M_pesan" initialized
INFO - 2023-04-30 16:06:07 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-30 16:06:07 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/v_booking_saya.php
INFO - 2023-04-30 16:06:07 --> Final output sent to browser
DEBUG - 2023-04-30 16:06:07 --> Total execution time: 0.2433
INFO - 2023-04-30 16:07:10 --> Config Class Initialized
INFO - 2023-04-30 16:07:10 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:07:10 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:07:10 --> Utf8 Class Initialized
INFO - 2023-04-30 16:07:10 --> URI Class Initialized
INFO - 2023-04-30 16:07:10 --> Router Class Initialized
INFO - 2023-04-30 16:07:10 --> Output Class Initialized
INFO - 2023-04-30 16:07:10 --> Security Class Initialized
DEBUG - 2023-04-30 16:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:07:10 --> Input Class Initialized
INFO - 2023-04-30 16:07:10 --> Language Class Initialized
INFO - 2023-04-30 16:07:10 --> Loader Class Initialized
INFO - 2023-04-30 16:07:10 --> Helper loaded: url_helper
INFO - 2023-04-30 16:07:10 --> Helper loaded: form_helper
INFO - 2023-04-30 16:07:10 --> Helper loaded: file_helper
INFO - 2023-04-30 16:07:10 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:07:10 --> Form Validation Class Initialized
INFO - 2023-04-30 16:07:10 --> Upload Class Initialized
INFO - 2023-04-30 16:07:10 --> Model "M_auth" initialized
INFO - 2023-04-30 16:07:10 --> Model "M_user" initialized
INFO - 2023-04-30 16:07:10 --> Model "M_produk" initialized
INFO - 2023-04-30 16:07:10 --> Controller Class Initialized
INFO - 2023-04-30 16:07:10 --> Model "M_pelanggan" initialized
INFO - 2023-04-30 16:07:10 --> Model "M_produk" initialized
DEBUG - 2023-04-30 16:07:10 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-30 16:07:10 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-30 16:07:10 --> Model "M_transaksi" initialized
INFO - 2023-04-30 16:07:10 --> Model "M_bank" initialized
INFO - 2023-04-30 16:07:10 --> Model "M_pesan" initialized
INFO - 2023-04-30 16:07:10 --> Config Class Initialized
INFO - 2023-04-30 16:07:10 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:07:10 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:07:10 --> Utf8 Class Initialized
INFO - 2023-04-30 16:07:10 --> URI Class Initialized
DEBUG - 2023-04-30 16:07:10 --> No URI present. Default controller set.
INFO - 2023-04-30 16:07:10 --> Router Class Initialized
INFO - 2023-04-30 16:07:10 --> Output Class Initialized
INFO - 2023-04-30 16:07:10 --> Security Class Initialized
DEBUG - 2023-04-30 16:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:07:10 --> Input Class Initialized
INFO - 2023-04-30 16:07:10 --> Language Class Initialized
INFO - 2023-04-30 16:07:10 --> Loader Class Initialized
INFO - 2023-04-30 16:07:10 --> Helper loaded: url_helper
INFO - 2023-04-30 16:07:10 --> Helper loaded: form_helper
INFO - 2023-04-30 16:07:10 --> Helper loaded: file_helper
INFO - 2023-04-30 16:07:10 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:07:11 --> Form Validation Class Initialized
INFO - 2023-04-30 16:07:11 --> Upload Class Initialized
INFO - 2023-04-30 16:07:11 --> Model "M_auth" initialized
INFO - 2023-04-30 16:07:11 --> Model "M_user" initialized
INFO - 2023-04-30 16:07:11 --> Model "M_produk" initialized
INFO - 2023-04-30 16:07:11 --> Controller Class Initialized
INFO - 2023-04-30 16:07:11 --> Model "M_pelanggan" initialized
INFO - 2023-04-30 16:07:11 --> Model "M_produk" initialized
DEBUG - 2023-04-30 16:07:11 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-30 16:07:11 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-30 16:07:11 --> Model "M_transaksi" initialized
INFO - 2023-04-30 16:07:11 --> Model "M_bank" initialized
INFO - 2023-04-30 16:07:11 --> Model "M_pesan" initialized
INFO - 2023-04-30 16:07:11 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-30 16:07:11 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-04-30 16:07:11 --> Final output sent to browser
DEBUG - 2023-04-30 16:07:11 --> Total execution time: 0.1584
INFO - 2023-04-30 16:07:14 --> Config Class Initialized
INFO - 2023-04-30 16:07:14 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:07:14 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:07:14 --> Utf8 Class Initialized
INFO - 2023-04-30 16:07:14 --> URI Class Initialized
INFO - 2023-04-30 16:07:14 --> Router Class Initialized
INFO - 2023-04-30 16:07:14 --> Output Class Initialized
INFO - 2023-04-30 16:07:14 --> Security Class Initialized
DEBUG - 2023-04-30 16:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:07:14 --> Input Class Initialized
INFO - 2023-04-30 16:07:14 --> Language Class Initialized
INFO - 2023-04-30 16:07:14 --> Loader Class Initialized
INFO - 2023-04-30 16:07:14 --> Helper loaded: url_helper
INFO - 2023-04-30 16:07:14 --> Helper loaded: form_helper
INFO - 2023-04-30 16:07:14 --> Helper loaded: file_helper
INFO - 2023-04-30 16:07:14 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:07:14 --> Form Validation Class Initialized
INFO - 2023-04-30 16:07:14 --> Upload Class Initialized
INFO - 2023-04-30 16:07:14 --> Model "M_auth" initialized
INFO - 2023-04-30 16:07:14 --> Model "M_user" initialized
INFO - 2023-04-30 16:07:14 --> Model "M_produk" initialized
INFO - 2023-04-30 16:07:14 --> Controller Class Initialized
INFO - 2023-04-30 16:07:14 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-04-30 16:07:14 --> Final output sent to browser
DEBUG - 2023-04-30 16:07:14 --> Total execution time: 0.1574
INFO - 2023-04-30 16:07:24 --> Config Class Initialized
INFO - 2023-04-30 16:07:24 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:07:24 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:07:24 --> Utf8 Class Initialized
INFO - 2023-04-30 16:07:24 --> URI Class Initialized
INFO - 2023-04-30 16:07:24 --> Router Class Initialized
INFO - 2023-04-30 16:07:24 --> Output Class Initialized
INFO - 2023-04-30 16:07:24 --> Security Class Initialized
DEBUG - 2023-04-30 16:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:07:24 --> Input Class Initialized
INFO - 2023-04-30 16:07:24 --> Language Class Initialized
INFO - 2023-04-30 16:07:24 --> Loader Class Initialized
INFO - 2023-04-30 16:07:24 --> Helper loaded: url_helper
INFO - 2023-04-30 16:07:24 --> Helper loaded: form_helper
INFO - 2023-04-30 16:07:24 --> Helper loaded: file_helper
INFO - 2023-04-30 16:07:24 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:07:24 --> Form Validation Class Initialized
INFO - 2023-04-30 16:07:24 --> Upload Class Initialized
INFO - 2023-04-30 16:07:24 --> Model "M_auth" initialized
INFO - 2023-04-30 16:07:24 --> Model "M_user" initialized
INFO - 2023-04-30 16:07:24 --> Model "M_produk" initialized
INFO - 2023-04-30 16:07:24 --> Controller Class Initialized
INFO - 2023-04-30 16:07:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-04-30 16:07:24 --> Config Class Initialized
INFO - 2023-04-30 16:07:24 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:07:24 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:07:24 --> Utf8 Class Initialized
INFO - 2023-04-30 16:07:24 --> URI Class Initialized
INFO - 2023-04-30 16:07:24 --> Router Class Initialized
INFO - 2023-04-30 16:07:24 --> Output Class Initialized
INFO - 2023-04-30 16:07:24 --> Security Class Initialized
DEBUG - 2023-04-30 16:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:07:24 --> Input Class Initialized
INFO - 2023-04-30 16:07:25 --> Language Class Initialized
INFO - 2023-04-30 16:07:25 --> Loader Class Initialized
INFO - 2023-04-30 16:07:25 --> Helper loaded: url_helper
INFO - 2023-04-30 16:07:25 --> Helper loaded: form_helper
INFO - 2023-04-30 16:07:25 --> Helper loaded: file_helper
INFO - 2023-04-30 16:07:25 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:07:25 --> Form Validation Class Initialized
INFO - 2023-04-30 16:07:25 --> Upload Class Initialized
INFO - 2023-04-30 16:07:25 --> Model "M_auth" initialized
INFO - 2023-04-30 16:07:25 --> Model "M_user" initialized
INFO - 2023-04-30 16:07:25 --> Model "M_produk" initialized
INFO - 2023-04-30 16:07:25 --> Controller Class Initialized
INFO - 2023-04-30 16:07:25 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-30 16:07:25 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-30 16:07:25 --> Final output sent to browser
DEBUG - 2023-04-30 16:07:25 --> Total execution time: 0.2334
INFO - 2023-04-30 16:08:53 --> Config Class Initialized
INFO - 2023-04-30 16:08:53 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:08:53 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:08:53 --> Utf8 Class Initialized
INFO - 2023-04-30 16:08:53 --> URI Class Initialized
INFO - 2023-04-30 16:08:53 --> Router Class Initialized
INFO - 2023-04-30 16:08:53 --> Output Class Initialized
INFO - 2023-04-30 16:08:53 --> Security Class Initialized
DEBUG - 2023-04-30 16:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:08:53 --> Input Class Initialized
INFO - 2023-04-30 16:08:53 --> Language Class Initialized
INFO - 2023-04-30 16:08:53 --> Loader Class Initialized
INFO - 2023-04-30 16:08:53 --> Helper loaded: url_helper
INFO - 2023-04-30 16:08:53 --> Helper loaded: form_helper
INFO - 2023-04-30 16:08:53 --> Helper loaded: file_helper
INFO - 2023-04-30 16:08:53 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:08:53 --> Form Validation Class Initialized
INFO - 2023-04-30 16:08:53 --> Upload Class Initialized
INFO - 2023-04-30 16:08:53 --> Model "M_auth" initialized
INFO - 2023-04-30 16:08:53 --> Model "M_user" initialized
INFO - 2023-04-30 16:08:53 --> Model "M_produk" initialized
INFO - 2023-04-30 16:08:53 --> Controller Class Initialized
INFO - 2023-04-30 16:08:53 --> Model "M_pelanggan" initialized
INFO - 2023-04-30 16:08:53 --> Model "M_produk" initialized
DEBUG - 2023-04-30 16:08:53 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-30 16:08:53 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-30 16:08:53 --> Model "M_transaksi" initialized
INFO - 2023-04-30 16:08:53 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_transaksi_all.php
INFO - 2023-04-30 16:08:53 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-30 16:08:53 --> Final output sent to browser
DEBUG - 2023-04-30 16:08:53 --> Total execution time: 0.2717
INFO - 2023-04-30 16:09:01 --> Config Class Initialized
INFO - 2023-04-30 16:09:01 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:09:01 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:09:01 --> Utf8 Class Initialized
INFO - 2023-04-30 16:09:01 --> URI Class Initialized
INFO - 2023-04-30 16:09:01 --> Router Class Initialized
INFO - 2023-04-30 16:09:01 --> Output Class Initialized
INFO - 2023-04-30 16:09:01 --> Security Class Initialized
DEBUG - 2023-04-30 16:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:09:01 --> Input Class Initialized
INFO - 2023-04-30 16:09:01 --> Language Class Initialized
INFO - 2023-04-30 16:09:01 --> Loader Class Initialized
INFO - 2023-04-30 16:09:01 --> Helper loaded: url_helper
INFO - 2023-04-30 16:09:01 --> Helper loaded: form_helper
INFO - 2023-04-30 16:09:01 --> Helper loaded: file_helper
INFO - 2023-04-30 16:09:01 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:09:01 --> Form Validation Class Initialized
INFO - 2023-04-30 16:09:01 --> Upload Class Initialized
INFO - 2023-04-30 16:09:01 --> Model "M_auth" initialized
INFO - 2023-04-30 16:09:01 --> Model "M_user" initialized
INFO - 2023-04-30 16:09:01 --> Model "M_produk" initialized
INFO - 2023-04-30 16:09:01 --> Controller Class Initialized
INFO - 2023-04-30 16:09:01 --> Model "M_pelanggan" initialized
INFO - 2023-04-30 16:09:01 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_pelanggan.php
INFO - 2023-04-30 16:09:01 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-30 16:09:01 --> Final output sent to browser
DEBUG - 2023-04-30 16:09:01 --> Total execution time: 0.1708
INFO - 2023-04-30 16:12:20 --> Config Class Initialized
INFO - 2023-04-30 16:12:20 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:12:20 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:12:20 --> Utf8 Class Initialized
INFO - 2023-04-30 16:12:20 --> URI Class Initialized
INFO - 2023-04-30 16:12:20 --> Router Class Initialized
INFO - 2023-04-30 16:12:20 --> Output Class Initialized
INFO - 2023-04-30 16:12:20 --> Security Class Initialized
DEBUG - 2023-04-30 16:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:12:20 --> Input Class Initialized
INFO - 2023-04-30 16:12:20 --> Language Class Initialized
INFO - 2023-04-30 16:12:20 --> Loader Class Initialized
INFO - 2023-04-30 16:12:20 --> Helper loaded: url_helper
INFO - 2023-04-30 16:12:20 --> Helper loaded: form_helper
INFO - 2023-04-30 16:12:20 --> Helper loaded: file_helper
INFO - 2023-04-30 16:12:20 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:12:20 --> Form Validation Class Initialized
INFO - 2023-04-30 16:12:20 --> Upload Class Initialized
INFO - 2023-04-30 16:12:20 --> Model "M_auth" initialized
INFO - 2023-04-30 16:12:20 --> Model "M_user" initialized
INFO - 2023-04-30 16:12:20 --> Model "M_produk" initialized
INFO - 2023-04-30 16:12:20 --> Controller Class Initialized
INFO - 2023-04-30 16:12:20 --> Model "M_pelanggan" initialized
INFO - 2023-04-30 16:12:20 --> Model "M_produk" initialized
DEBUG - 2023-04-30 16:12:20 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-30 16:12:20 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-30 16:12:20 --> Model "M_transaksi" initialized
INFO - 2023-04-30 16:12:20 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_transaksi_all.php
INFO - 2023-04-30 16:12:20 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-30 16:12:20 --> Final output sent to browser
DEBUG - 2023-04-30 16:12:20 --> Total execution time: 0.1630
INFO - 2023-04-30 16:12:44 --> Config Class Initialized
INFO - 2023-04-30 16:12:44 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:12:44 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:12:44 --> Utf8 Class Initialized
INFO - 2023-04-30 16:12:44 --> URI Class Initialized
INFO - 2023-04-30 16:12:44 --> Router Class Initialized
INFO - 2023-04-30 16:12:44 --> Output Class Initialized
INFO - 2023-04-30 16:12:44 --> Security Class Initialized
DEBUG - 2023-04-30 16:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:12:44 --> Input Class Initialized
INFO - 2023-04-30 16:12:44 --> Language Class Initialized
INFO - 2023-04-30 16:12:44 --> Loader Class Initialized
INFO - 2023-04-30 16:12:44 --> Helper loaded: url_helper
INFO - 2023-04-30 16:12:44 --> Helper loaded: form_helper
INFO - 2023-04-30 16:12:44 --> Helper loaded: file_helper
INFO - 2023-04-30 16:12:44 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:12:44 --> Form Validation Class Initialized
INFO - 2023-04-30 16:12:44 --> Upload Class Initialized
INFO - 2023-04-30 16:12:44 --> Model "M_auth" initialized
INFO - 2023-04-30 16:12:44 --> Model "M_user" initialized
INFO - 2023-04-30 16:12:44 --> Model "M_produk" initialized
INFO - 2023-04-30 16:12:44 --> Controller Class Initialized
INFO - 2023-04-30 16:12:44 --> Model "M_pesan" initialized
INFO - 2023-04-30 16:12:44 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_pengaduan.php
INFO - 2023-04-30 16:12:44 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-30 16:12:44 --> Final output sent to browser
DEBUG - 2023-04-30 16:12:44 --> Total execution time: 0.1789
INFO - 2023-04-30 16:12:52 --> Config Class Initialized
INFO - 2023-04-30 16:12:52 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:12:52 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:12:52 --> Utf8 Class Initialized
INFO - 2023-04-30 16:12:52 --> URI Class Initialized
INFO - 2023-04-30 16:12:52 --> Router Class Initialized
INFO - 2023-04-30 16:12:52 --> Output Class Initialized
INFO - 2023-04-30 16:12:52 --> Security Class Initialized
DEBUG - 2023-04-30 16:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:12:52 --> Input Class Initialized
INFO - 2023-04-30 16:12:52 --> Language Class Initialized
INFO - 2023-04-30 16:12:52 --> Loader Class Initialized
INFO - 2023-04-30 16:12:52 --> Helper loaded: url_helper
INFO - 2023-04-30 16:12:52 --> Helper loaded: form_helper
INFO - 2023-04-30 16:12:52 --> Helper loaded: file_helper
INFO - 2023-04-30 16:12:52 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:12:52 --> Form Validation Class Initialized
INFO - 2023-04-30 16:12:52 --> Upload Class Initialized
INFO - 2023-04-30 16:12:52 --> Model "M_auth" initialized
INFO - 2023-04-30 16:12:52 --> Model "M_user" initialized
INFO - 2023-04-30 16:12:52 --> Model "M_produk" initialized
INFO - 2023-04-30 16:12:52 --> Controller Class Initialized
INFO - 2023-04-30 16:12:52 --> Config Class Initialized
INFO - 2023-04-30 16:12:52 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:12:52 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:12:52 --> Utf8 Class Initialized
INFO - 2023-04-30 16:12:52 --> URI Class Initialized
INFO - 2023-04-30 16:12:52 --> Router Class Initialized
INFO - 2023-04-30 16:12:52 --> Output Class Initialized
INFO - 2023-04-30 16:12:52 --> Security Class Initialized
DEBUG - 2023-04-30 16:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:12:52 --> Input Class Initialized
INFO - 2023-04-30 16:12:52 --> Language Class Initialized
INFO - 2023-04-30 16:12:52 --> Loader Class Initialized
INFO - 2023-04-30 16:12:52 --> Helper loaded: url_helper
INFO - 2023-04-30 16:12:52 --> Helper loaded: form_helper
INFO - 2023-04-30 16:12:52 --> Helper loaded: file_helper
INFO - 2023-04-30 16:12:52 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:12:52 --> Form Validation Class Initialized
INFO - 2023-04-30 16:12:52 --> Upload Class Initialized
INFO - 2023-04-30 16:12:52 --> Model "M_auth" initialized
INFO - 2023-04-30 16:12:52 --> Model "M_user" initialized
INFO - 2023-04-30 16:12:52 --> Model "M_produk" initialized
INFO - 2023-04-30 16:12:52 --> Controller Class Initialized
INFO - 2023-04-30 16:12:52 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-04-30 16:12:52 --> Final output sent to browser
DEBUG - 2023-04-30 16:12:52 --> Total execution time: 0.1110
INFO - 2023-04-30 16:12:56 --> Config Class Initialized
INFO - 2023-04-30 16:12:56 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:12:56 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:12:56 --> Utf8 Class Initialized
INFO - 2023-04-30 16:12:56 --> URI Class Initialized
DEBUG - 2023-04-30 16:12:56 --> No URI present. Default controller set.
INFO - 2023-04-30 16:12:56 --> Router Class Initialized
INFO - 2023-04-30 16:12:56 --> Output Class Initialized
INFO - 2023-04-30 16:12:56 --> Security Class Initialized
DEBUG - 2023-04-30 16:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:12:56 --> Input Class Initialized
INFO - 2023-04-30 16:12:56 --> Language Class Initialized
INFO - 2023-04-30 16:12:56 --> Loader Class Initialized
INFO - 2023-04-30 16:12:56 --> Helper loaded: url_helper
INFO - 2023-04-30 16:12:56 --> Helper loaded: form_helper
INFO - 2023-04-30 16:12:56 --> Helper loaded: file_helper
INFO - 2023-04-30 16:12:56 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:12:56 --> Form Validation Class Initialized
INFO - 2023-04-30 16:12:56 --> Upload Class Initialized
INFO - 2023-04-30 16:12:56 --> Model "M_auth" initialized
INFO - 2023-04-30 16:12:56 --> Model "M_user" initialized
INFO - 2023-04-30 16:12:56 --> Model "M_produk" initialized
INFO - 2023-04-30 16:12:56 --> Controller Class Initialized
INFO - 2023-04-30 16:12:56 --> Model "M_pelanggan" initialized
INFO - 2023-04-30 16:12:56 --> Model "M_produk" initialized
DEBUG - 2023-04-30 16:12:56 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-30 16:12:56 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-30 16:12:56 --> Model "M_transaksi" initialized
INFO - 2023-04-30 16:12:56 --> Model "M_bank" initialized
INFO - 2023-04-30 16:12:56 --> Model "M_pesan" initialized
INFO - 2023-04-30 16:12:56 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-30 16:12:56 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-04-30 16:12:56 --> Final output sent to browser
DEBUG - 2023-04-30 16:12:56 --> Total execution time: 0.1678
INFO - 2023-04-30 16:14:43 --> Config Class Initialized
INFO - 2023-04-30 16:14:43 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:14:43 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:14:43 --> Utf8 Class Initialized
INFO - 2023-04-30 16:14:43 --> URI Class Initialized
INFO - 2023-04-30 16:14:43 --> Router Class Initialized
INFO - 2023-04-30 16:14:43 --> Output Class Initialized
INFO - 2023-04-30 16:14:43 --> Security Class Initialized
DEBUG - 2023-04-30 16:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:14:43 --> Input Class Initialized
INFO - 2023-04-30 16:14:43 --> Language Class Initialized
INFO - 2023-04-30 16:14:43 --> Loader Class Initialized
INFO - 2023-04-30 16:14:43 --> Helper loaded: url_helper
INFO - 2023-04-30 16:14:43 --> Helper loaded: form_helper
INFO - 2023-04-30 16:14:43 --> Helper loaded: file_helper
INFO - 2023-04-30 16:14:43 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:14:43 --> Form Validation Class Initialized
INFO - 2023-04-30 16:14:43 --> Upload Class Initialized
INFO - 2023-04-30 16:14:43 --> Model "M_auth" initialized
INFO - 2023-04-30 16:14:43 --> Model "M_user" initialized
INFO - 2023-04-30 16:14:43 --> Model "M_produk" initialized
INFO - 2023-04-30 16:14:43 --> Controller Class Initialized
INFO - 2023-04-30 16:14:43 --> Model "M_pelanggan" initialized
INFO - 2023-04-30 16:14:43 --> Model "M_produk" initialized
DEBUG - 2023-04-30 16:14:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-30 16:14:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-30 16:14:43 --> Model "M_transaksi" initialized
INFO - 2023-04-30 16:14:43 --> Model "M_bank" initialized
INFO - 2023-04-30 16:14:43 --> Model "M_pesan" initialized
INFO - 2023-04-30 16:14:43 --> Email Class Initialized
ERROR - 2023-04-30 16:14:48 --> Severity: Warning --> fsockopen(): Unable to connect to ssl://smtp.googlemail.com:465 (A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond) C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\system\libraries\Email.php 2070
INFO - 2023-04-30 16:14:48 --> Language file loaded: language/english/email_lang.php
INFO - 2023-04-30 16:14:48 --> Config Class Initialized
INFO - 2023-04-30 16:14:48 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:14:48 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:14:48 --> Utf8 Class Initialized
INFO - 2023-04-30 16:14:48 --> URI Class Initialized
DEBUG - 2023-04-30 16:14:48 --> No URI present. Default controller set.
INFO - 2023-04-30 16:14:48 --> Router Class Initialized
INFO - 2023-04-30 16:14:48 --> Output Class Initialized
INFO - 2023-04-30 16:14:48 --> Security Class Initialized
DEBUG - 2023-04-30 16:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:14:48 --> Input Class Initialized
INFO - 2023-04-30 16:14:48 --> Language Class Initialized
INFO - 2023-04-30 16:14:48 --> Loader Class Initialized
INFO - 2023-04-30 16:14:48 --> Helper loaded: url_helper
INFO - 2023-04-30 16:14:48 --> Helper loaded: form_helper
INFO - 2023-04-30 16:14:48 --> Helper loaded: file_helper
INFO - 2023-04-30 16:14:48 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:14:48 --> Form Validation Class Initialized
INFO - 2023-04-30 16:14:48 --> Upload Class Initialized
INFO - 2023-04-30 16:14:48 --> Model "M_auth" initialized
INFO - 2023-04-30 16:14:48 --> Model "M_user" initialized
INFO - 2023-04-30 16:14:48 --> Model "M_produk" initialized
INFO - 2023-04-30 16:14:48 --> Controller Class Initialized
INFO - 2023-04-30 16:14:48 --> Model "M_pelanggan" initialized
INFO - 2023-04-30 16:14:48 --> Model "M_produk" initialized
DEBUG - 2023-04-30 16:14:48 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-30 16:14:48 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-30 16:14:48 --> Model "M_transaksi" initialized
INFO - 2023-04-30 16:14:48 --> Model "M_bank" initialized
INFO - 2023-04-30 16:14:48 --> Model "M_pesan" initialized
INFO - 2023-04-30 16:14:48 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-30 16:14:48 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-04-30 16:14:48 --> Final output sent to browser
DEBUG - 2023-04-30 16:14:48 --> Total execution time: 0.1293
INFO - 2023-04-30 16:23:15 --> Config Class Initialized
INFO - 2023-04-30 16:23:15 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:23:15 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:23:15 --> Utf8 Class Initialized
INFO - 2023-04-30 16:23:15 --> URI Class Initialized
INFO - 2023-04-30 16:23:15 --> Router Class Initialized
INFO - 2023-04-30 16:23:15 --> Output Class Initialized
INFO - 2023-04-30 16:23:15 --> Security Class Initialized
DEBUG - 2023-04-30 16:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:23:15 --> Input Class Initialized
INFO - 2023-04-30 16:23:15 --> Language Class Initialized
INFO - 2023-04-30 16:23:15 --> Loader Class Initialized
INFO - 2023-04-30 16:23:15 --> Helper loaded: url_helper
INFO - 2023-04-30 16:23:15 --> Helper loaded: form_helper
INFO - 2023-04-30 16:23:15 --> Helper loaded: file_helper
INFO - 2023-04-30 16:23:15 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:23:15 --> Form Validation Class Initialized
INFO - 2023-04-30 16:23:15 --> Upload Class Initialized
INFO - 2023-04-30 16:23:15 --> Model "M_auth" initialized
INFO - 2023-04-30 16:23:15 --> Model "M_user" initialized
INFO - 2023-04-30 16:23:15 --> Model "M_produk" initialized
INFO - 2023-04-30 16:23:15 --> Controller Class Initialized
INFO - 2023-04-30 16:23:15 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-04-30 16:23:15 --> Final output sent to browser
DEBUG - 2023-04-30 16:23:15 --> Total execution time: 0.1334
INFO - 2023-04-30 16:23:22 --> Config Class Initialized
INFO - 2023-04-30 16:23:22 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:23:22 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:23:22 --> Utf8 Class Initialized
INFO - 2023-04-30 16:23:22 --> URI Class Initialized
INFO - 2023-04-30 16:23:22 --> Router Class Initialized
INFO - 2023-04-30 16:23:22 --> Output Class Initialized
INFO - 2023-04-30 16:23:22 --> Security Class Initialized
DEBUG - 2023-04-30 16:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:23:22 --> Input Class Initialized
INFO - 2023-04-30 16:23:22 --> Language Class Initialized
INFO - 2023-04-30 16:23:22 --> Loader Class Initialized
INFO - 2023-04-30 16:23:22 --> Helper loaded: url_helper
INFO - 2023-04-30 16:23:22 --> Helper loaded: form_helper
INFO - 2023-04-30 16:23:22 --> Helper loaded: file_helper
INFO - 2023-04-30 16:23:22 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:23:22 --> Form Validation Class Initialized
INFO - 2023-04-30 16:23:22 --> Upload Class Initialized
INFO - 2023-04-30 16:23:22 --> Model "M_auth" initialized
INFO - 2023-04-30 16:23:22 --> Model "M_user" initialized
INFO - 2023-04-30 16:23:22 --> Model "M_produk" initialized
INFO - 2023-04-30 16:23:22 --> Controller Class Initialized
INFO - 2023-04-30 16:23:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-04-30 16:23:22 --> Config Class Initialized
INFO - 2023-04-30 16:23:22 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:23:22 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:23:22 --> Utf8 Class Initialized
INFO - 2023-04-30 16:23:22 --> URI Class Initialized
INFO - 2023-04-30 16:23:22 --> Router Class Initialized
INFO - 2023-04-30 16:23:22 --> Output Class Initialized
INFO - 2023-04-30 16:23:22 --> Security Class Initialized
DEBUG - 2023-04-30 16:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:23:22 --> Input Class Initialized
INFO - 2023-04-30 16:23:22 --> Language Class Initialized
INFO - 2023-04-30 16:23:22 --> Loader Class Initialized
INFO - 2023-04-30 16:23:22 --> Helper loaded: url_helper
INFO - 2023-04-30 16:23:22 --> Helper loaded: form_helper
INFO - 2023-04-30 16:23:22 --> Helper loaded: file_helper
INFO - 2023-04-30 16:23:22 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:23:22 --> Form Validation Class Initialized
INFO - 2023-04-30 16:23:22 --> Upload Class Initialized
INFO - 2023-04-30 16:23:22 --> Model "M_auth" initialized
INFO - 2023-04-30 16:23:22 --> Model "M_user" initialized
INFO - 2023-04-30 16:23:22 --> Model "M_produk" initialized
INFO - 2023-04-30 16:23:22 --> Controller Class Initialized
INFO - 2023-04-30 16:23:22 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-30 16:23:22 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-30 16:23:22 --> Final output sent to browser
DEBUG - 2023-04-30 16:23:22 --> Total execution time: 0.2004
INFO - 2023-04-30 16:23:26 --> Config Class Initialized
INFO - 2023-04-30 16:23:26 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:23:26 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:23:26 --> Utf8 Class Initialized
INFO - 2023-04-30 16:23:26 --> URI Class Initialized
INFO - 2023-04-30 16:23:26 --> Router Class Initialized
INFO - 2023-04-30 16:23:26 --> Output Class Initialized
INFO - 2023-04-30 16:23:26 --> Security Class Initialized
DEBUG - 2023-04-30 16:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:23:26 --> Input Class Initialized
INFO - 2023-04-30 16:23:26 --> Language Class Initialized
INFO - 2023-04-30 16:23:26 --> Loader Class Initialized
INFO - 2023-04-30 16:23:26 --> Helper loaded: url_helper
INFO - 2023-04-30 16:23:26 --> Helper loaded: form_helper
INFO - 2023-04-30 16:23:26 --> Helper loaded: file_helper
INFO - 2023-04-30 16:23:26 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:23:26 --> Form Validation Class Initialized
INFO - 2023-04-30 16:23:26 --> Upload Class Initialized
INFO - 2023-04-30 16:23:26 --> Model "M_auth" initialized
INFO - 2023-04-30 16:23:26 --> Model "M_user" initialized
INFO - 2023-04-30 16:23:26 --> Model "M_produk" initialized
INFO - 2023-04-30 16:23:26 --> Controller Class Initialized
INFO - 2023-04-30 16:23:26 --> Model "M_pesan" initialized
INFO - 2023-04-30 16:23:26 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_pengaduan.php
INFO - 2023-04-30 16:23:26 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-30 16:23:26 --> Final output sent to browser
DEBUG - 2023-04-30 16:23:26 --> Total execution time: 0.1084
INFO - 2023-04-30 16:29:15 --> Config Class Initialized
INFO - 2023-04-30 16:29:15 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:29:15 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:29:15 --> Utf8 Class Initialized
INFO - 2023-04-30 16:29:15 --> URI Class Initialized
INFO - 2023-04-30 16:29:15 --> Router Class Initialized
INFO - 2023-04-30 16:29:15 --> Output Class Initialized
INFO - 2023-04-30 16:29:15 --> Security Class Initialized
DEBUG - 2023-04-30 16:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:29:15 --> Input Class Initialized
INFO - 2023-04-30 16:29:15 --> Language Class Initialized
INFO - 2023-04-30 16:29:15 --> Loader Class Initialized
INFO - 2023-04-30 16:29:15 --> Helper loaded: url_helper
INFO - 2023-04-30 16:29:15 --> Helper loaded: form_helper
INFO - 2023-04-30 16:29:15 --> Helper loaded: file_helper
INFO - 2023-04-30 16:29:15 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:29:15 --> Form Validation Class Initialized
INFO - 2023-04-30 16:29:15 --> Upload Class Initialized
INFO - 2023-04-30 16:29:15 --> Model "M_auth" initialized
INFO - 2023-04-30 16:29:15 --> Model "M_user" initialized
INFO - 2023-04-30 16:29:15 --> Model "M_produk" initialized
INFO - 2023-04-30 16:29:15 --> Controller Class Initialized
INFO - 2023-04-30 16:29:15 --> Model "M_pesan" initialized
INFO - 2023-04-30 16:29:15 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_pengaduan.php
INFO - 2023-04-30 16:29:15 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-30 16:29:15 --> Final output sent to browser
DEBUG - 2023-04-30 16:29:15 --> Total execution time: 0.1438
INFO - 2023-04-30 16:29:28 --> Config Class Initialized
INFO - 2023-04-30 16:29:28 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:29:28 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:29:28 --> Utf8 Class Initialized
INFO - 2023-04-30 16:29:28 --> URI Class Initialized
INFO - 2023-04-30 16:29:28 --> Router Class Initialized
INFO - 2023-04-30 16:29:28 --> Output Class Initialized
INFO - 2023-04-30 16:29:28 --> Security Class Initialized
DEBUG - 2023-04-30 16:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:29:28 --> Input Class Initialized
INFO - 2023-04-30 16:29:28 --> Language Class Initialized
INFO - 2023-04-30 16:29:28 --> Loader Class Initialized
INFO - 2023-04-30 16:29:28 --> Helper loaded: url_helper
INFO - 2023-04-30 16:29:28 --> Helper loaded: form_helper
INFO - 2023-04-30 16:29:28 --> Helper loaded: file_helper
INFO - 2023-04-30 16:29:28 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:29:28 --> Form Validation Class Initialized
INFO - 2023-04-30 16:29:28 --> Upload Class Initialized
INFO - 2023-04-30 16:29:28 --> Model "M_auth" initialized
INFO - 2023-04-30 16:29:28 --> Model "M_user" initialized
INFO - 2023-04-30 16:29:28 --> Model "M_produk" initialized
INFO - 2023-04-30 16:29:28 --> Controller Class Initialized
INFO - 2023-04-30 16:29:28 --> Model "M_produk" initialized
INFO - 2023-04-30 16:29:28 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-04-30 16:29:28 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-30 16:29:28 --> Final output sent to browser
DEBUG - 2023-04-30 16:29:28 --> Total execution time: 0.1290
INFO - 2023-04-30 16:29:32 --> Config Class Initialized
INFO - 2023-04-30 16:29:32 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:29:32 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:29:32 --> Utf8 Class Initialized
INFO - 2023-04-30 16:29:32 --> URI Class Initialized
INFO - 2023-04-30 16:29:32 --> Router Class Initialized
INFO - 2023-04-30 16:29:32 --> Output Class Initialized
INFO - 2023-04-30 16:29:32 --> Security Class Initialized
DEBUG - 2023-04-30 16:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:29:32 --> Input Class Initialized
INFO - 2023-04-30 16:29:32 --> Language Class Initialized
INFO - 2023-04-30 16:29:32 --> Loader Class Initialized
INFO - 2023-04-30 16:29:32 --> Helper loaded: url_helper
INFO - 2023-04-30 16:29:32 --> Helper loaded: form_helper
INFO - 2023-04-30 16:29:32 --> Helper loaded: file_helper
INFO - 2023-04-30 16:29:32 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:29:32 --> Form Validation Class Initialized
INFO - 2023-04-30 16:29:32 --> Upload Class Initialized
INFO - 2023-04-30 16:29:32 --> Model "M_auth" initialized
INFO - 2023-04-30 16:29:32 --> Model "M_user" initialized
INFO - 2023-04-30 16:29:32 --> Model "M_produk" initialized
INFO - 2023-04-30 16:29:32 --> Controller Class Initialized
INFO - 2023-04-30 16:29:32 --> Model "M_produk" initialized
INFO - 2023-04-30 16:29:32 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_type_merek.php
INFO - 2023-04-30 16:29:32 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-30 16:29:32 --> Final output sent to browser
DEBUG - 2023-04-30 16:29:32 --> Total execution time: 0.1235
INFO - 2023-04-30 16:29:35 --> Config Class Initialized
INFO - 2023-04-30 16:29:35 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:29:35 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:29:35 --> Utf8 Class Initialized
INFO - 2023-04-30 16:29:35 --> URI Class Initialized
INFO - 2023-04-30 16:29:35 --> Router Class Initialized
INFO - 2023-04-30 16:29:35 --> Output Class Initialized
INFO - 2023-04-30 16:29:35 --> Security Class Initialized
DEBUG - 2023-04-30 16:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:29:35 --> Input Class Initialized
INFO - 2023-04-30 16:29:35 --> Language Class Initialized
INFO - 2023-04-30 16:29:35 --> Loader Class Initialized
INFO - 2023-04-30 16:29:35 --> Helper loaded: url_helper
INFO - 2023-04-30 16:29:35 --> Helper loaded: form_helper
INFO - 2023-04-30 16:29:35 --> Helper loaded: file_helper
INFO - 2023-04-30 16:29:35 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:29:35 --> Form Validation Class Initialized
INFO - 2023-04-30 16:29:35 --> Upload Class Initialized
INFO - 2023-04-30 16:29:35 --> Model "M_auth" initialized
INFO - 2023-04-30 16:29:35 --> Model "M_user" initialized
INFO - 2023-04-30 16:29:35 --> Model "M_produk" initialized
INFO - 2023-04-30 16:29:35 --> Controller Class Initialized
INFO - 2023-04-30 16:29:35 --> Model "M_produk" initialized
INFO - 2023-04-30 16:29:35 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_typeproduk.php
INFO - 2023-04-30 16:29:35 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-30 16:29:35 --> Final output sent to browser
DEBUG - 2023-04-30 16:29:35 --> Total execution time: 0.1130
INFO - 2023-04-30 16:29:47 --> Config Class Initialized
INFO - 2023-04-30 16:29:47 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:29:47 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:29:47 --> Utf8 Class Initialized
INFO - 2023-04-30 16:29:47 --> URI Class Initialized
INFO - 2023-04-30 16:29:47 --> Router Class Initialized
INFO - 2023-04-30 16:29:47 --> Output Class Initialized
INFO - 2023-04-30 16:29:47 --> Security Class Initialized
DEBUG - 2023-04-30 16:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:29:47 --> Input Class Initialized
INFO - 2023-04-30 16:29:47 --> Language Class Initialized
INFO - 2023-04-30 16:29:47 --> Loader Class Initialized
INFO - 2023-04-30 16:29:47 --> Helper loaded: url_helper
INFO - 2023-04-30 16:29:47 --> Helper loaded: form_helper
INFO - 2023-04-30 16:29:47 --> Helper loaded: file_helper
INFO - 2023-04-30 16:29:47 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:29:48 --> Form Validation Class Initialized
INFO - 2023-04-30 16:29:48 --> Upload Class Initialized
INFO - 2023-04-30 16:29:48 --> Model "M_auth" initialized
INFO - 2023-04-30 16:29:48 --> Model "M_user" initialized
INFO - 2023-04-30 16:29:48 --> Model "M_produk" initialized
INFO - 2023-04-30 16:29:48 --> Controller Class Initialized
INFO - 2023-04-30 16:29:48 --> Config Class Initialized
INFO - 2023-04-30 16:29:48 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:29:48 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:29:48 --> Utf8 Class Initialized
INFO - 2023-04-30 16:29:48 --> URI Class Initialized
INFO - 2023-04-30 16:29:48 --> Router Class Initialized
INFO - 2023-04-30 16:29:48 --> Output Class Initialized
INFO - 2023-04-30 16:29:48 --> Security Class Initialized
DEBUG - 2023-04-30 16:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:29:48 --> Input Class Initialized
INFO - 2023-04-30 16:29:48 --> Language Class Initialized
INFO - 2023-04-30 16:29:48 --> Loader Class Initialized
INFO - 2023-04-30 16:29:48 --> Helper loaded: url_helper
INFO - 2023-04-30 16:29:48 --> Helper loaded: form_helper
INFO - 2023-04-30 16:29:48 --> Helper loaded: file_helper
INFO - 2023-04-30 16:29:48 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:29:48 --> Form Validation Class Initialized
INFO - 2023-04-30 16:29:48 --> Upload Class Initialized
INFO - 2023-04-30 16:29:48 --> Model "M_auth" initialized
INFO - 2023-04-30 16:29:48 --> Model "M_user" initialized
INFO - 2023-04-30 16:29:48 --> Model "M_produk" initialized
INFO - 2023-04-30 16:29:48 --> Controller Class Initialized
INFO - 2023-04-30 16:29:48 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-04-30 16:29:48 --> Final output sent to browser
DEBUG - 2023-04-30 16:29:48 --> Total execution time: 0.1423
INFO - 2023-04-30 16:29:50 --> Config Class Initialized
INFO - 2023-04-30 16:29:50 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:29:50 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:29:50 --> Utf8 Class Initialized
INFO - 2023-04-30 16:29:50 --> URI Class Initialized
DEBUG - 2023-04-30 16:29:50 --> No URI present. Default controller set.
INFO - 2023-04-30 16:29:50 --> Router Class Initialized
INFO - 2023-04-30 16:29:50 --> Output Class Initialized
INFO - 2023-04-30 16:29:50 --> Security Class Initialized
DEBUG - 2023-04-30 16:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:29:50 --> Input Class Initialized
INFO - 2023-04-30 16:29:50 --> Language Class Initialized
INFO - 2023-04-30 16:29:50 --> Loader Class Initialized
INFO - 2023-04-30 16:29:50 --> Helper loaded: url_helper
INFO - 2023-04-30 16:29:50 --> Helper loaded: form_helper
INFO - 2023-04-30 16:29:50 --> Helper loaded: file_helper
INFO - 2023-04-30 16:29:50 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:29:50 --> Form Validation Class Initialized
INFO - 2023-04-30 16:29:50 --> Upload Class Initialized
INFO - 2023-04-30 16:29:50 --> Model "M_auth" initialized
INFO - 2023-04-30 16:29:50 --> Model "M_user" initialized
INFO - 2023-04-30 16:29:50 --> Model "M_produk" initialized
INFO - 2023-04-30 16:29:50 --> Controller Class Initialized
INFO - 2023-04-30 16:29:50 --> Model "M_pelanggan" initialized
INFO - 2023-04-30 16:29:50 --> Model "M_produk" initialized
DEBUG - 2023-04-30 16:29:50 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-30 16:29:50 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-30 16:29:50 --> Model "M_transaksi" initialized
INFO - 2023-04-30 16:29:50 --> Model "M_bank" initialized
INFO - 2023-04-30 16:29:50 --> Model "M_pesan" initialized
INFO - 2023-04-30 16:29:50 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-30 16:29:50 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-04-30 16:29:50 --> Final output sent to browser
DEBUG - 2023-04-30 16:29:50 --> Total execution time: 0.1564
INFO - 2023-04-30 16:30:26 --> Config Class Initialized
INFO - 2023-04-30 16:30:26 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:30:26 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:30:26 --> Utf8 Class Initialized
INFO - 2023-04-30 16:30:26 --> URI Class Initialized
INFO - 2023-04-30 16:30:26 --> Router Class Initialized
INFO - 2023-04-30 16:30:26 --> Output Class Initialized
INFO - 2023-04-30 16:30:26 --> Security Class Initialized
DEBUG - 2023-04-30 16:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:30:26 --> Input Class Initialized
INFO - 2023-04-30 16:30:26 --> Language Class Initialized
INFO - 2023-04-30 16:30:26 --> Loader Class Initialized
INFO - 2023-04-30 16:30:26 --> Helper loaded: url_helper
INFO - 2023-04-30 16:30:26 --> Helper loaded: form_helper
INFO - 2023-04-30 16:30:26 --> Helper loaded: file_helper
INFO - 2023-04-30 16:30:26 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:30:26 --> Form Validation Class Initialized
INFO - 2023-04-30 16:30:26 --> Upload Class Initialized
INFO - 2023-04-30 16:30:26 --> Model "M_auth" initialized
INFO - 2023-04-30 16:30:26 --> Model "M_user" initialized
INFO - 2023-04-30 16:30:26 --> Model "M_produk" initialized
INFO - 2023-04-30 16:30:26 --> Controller Class Initialized
INFO - 2023-04-30 16:30:26 --> Model "M_pelanggan" initialized
INFO - 2023-04-30 16:30:26 --> Model "M_produk" initialized
DEBUG - 2023-04-30 16:30:26 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-30 16:30:26 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-30 16:30:26 --> Model "M_transaksi" initialized
INFO - 2023-04-30 16:30:26 --> Model "M_bank" initialized
INFO - 2023-04-30 16:30:26 --> Model "M_pesan" initialized
INFO - 2023-04-30 16:30:26 --> Email Class Initialized
INFO - 2023-04-30 16:30:27 --> Language file loaded: language/english/email_lang.php
INFO - 2023-04-30 16:30:31 --> Config Class Initialized
INFO - 2023-04-30 16:30:31 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:30:31 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:30:31 --> Utf8 Class Initialized
INFO - 2023-04-30 16:30:31 --> URI Class Initialized
DEBUG - 2023-04-30 16:30:31 --> No URI present. Default controller set.
INFO - 2023-04-30 16:30:31 --> Router Class Initialized
INFO - 2023-04-30 16:30:31 --> Output Class Initialized
INFO - 2023-04-30 16:30:31 --> Security Class Initialized
DEBUG - 2023-04-30 16:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:30:31 --> Input Class Initialized
INFO - 2023-04-30 16:30:31 --> Language Class Initialized
INFO - 2023-04-30 16:30:31 --> Loader Class Initialized
INFO - 2023-04-30 16:30:31 --> Helper loaded: url_helper
INFO - 2023-04-30 16:30:31 --> Helper loaded: form_helper
INFO - 2023-04-30 16:30:31 --> Helper loaded: file_helper
INFO - 2023-04-30 16:30:31 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:30:31 --> Form Validation Class Initialized
INFO - 2023-04-30 16:30:31 --> Upload Class Initialized
INFO - 2023-04-30 16:30:31 --> Model "M_auth" initialized
INFO - 2023-04-30 16:30:31 --> Model "M_user" initialized
INFO - 2023-04-30 16:30:31 --> Model "M_produk" initialized
INFO - 2023-04-30 16:30:31 --> Controller Class Initialized
INFO - 2023-04-30 16:30:31 --> Model "M_pelanggan" initialized
INFO - 2023-04-30 16:30:31 --> Model "M_produk" initialized
DEBUG - 2023-04-30 16:30:31 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-30 16:30:31 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-30 16:30:31 --> Model "M_transaksi" initialized
INFO - 2023-04-30 16:30:31 --> Model "M_bank" initialized
INFO - 2023-04-30 16:30:31 --> Model "M_pesan" initialized
INFO - 2023-04-30 16:30:31 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-30 16:30:31 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-04-30 16:30:31 --> Final output sent to browser
DEBUG - 2023-04-30 16:30:31 --> Total execution time: 0.1391
INFO - 2023-04-30 16:48:31 --> Config Class Initialized
INFO - 2023-04-30 16:48:31 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:48:31 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:48:31 --> Utf8 Class Initialized
INFO - 2023-04-30 16:48:31 --> URI Class Initialized
INFO - 2023-04-30 16:48:31 --> Router Class Initialized
INFO - 2023-04-30 16:48:31 --> Output Class Initialized
INFO - 2023-04-30 16:48:31 --> Security Class Initialized
DEBUG - 2023-04-30 16:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:48:31 --> Input Class Initialized
INFO - 2023-04-30 16:48:31 --> Language Class Initialized
INFO - 2023-04-30 16:48:31 --> Loader Class Initialized
INFO - 2023-04-30 16:48:31 --> Helper loaded: url_helper
INFO - 2023-04-30 16:48:31 --> Helper loaded: form_helper
INFO - 2023-04-30 16:48:31 --> Helper loaded: file_helper
INFO - 2023-04-30 16:48:31 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:48:31 --> Form Validation Class Initialized
INFO - 2023-04-30 16:48:31 --> Upload Class Initialized
INFO - 2023-04-30 16:48:31 --> Model "M_auth" initialized
INFO - 2023-04-30 16:48:31 --> Model "M_user" initialized
INFO - 2023-04-30 16:48:31 --> Model "M_produk" initialized
INFO - 2023-04-30 16:48:31 --> Controller Class Initialized
INFO - 2023-04-30 16:48:31 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_login.php
INFO - 2023-04-30 16:48:31 --> Final output sent to browser
DEBUG - 2023-04-30 16:48:31 --> Total execution time: 0.1196
INFO - 2023-04-30 16:48:39 --> Config Class Initialized
INFO - 2023-04-30 16:48:39 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:48:39 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:48:39 --> Utf8 Class Initialized
INFO - 2023-04-30 16:48:39 --> URI Class Initialized
INFO - 2023-04-30 16:48:39 --> Router Class Initialized
INFO - 2023-04-30 16:48:39 --> Output Class Initialized
INFO - 2023-04-30 16:48:39 --> Security Class Initialized
DEBUG - 2023-04-30 16:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:48:39 --> Input Class Initialized
INFO - 2023-04-30 16:48:39 --> Language Class Initialized
INFO - 2023-04-30 16:48:39 --> Loader Class Initialized
INFO - 2023-04-30 16:48:39 --> Helper loaded: url_helper
INFO - 2023-04-30 16:48:39 --> Helper loaded: form_helper
INFO - 2023-04-30 16:48:39 --> Helper loaded: file_helper
INFO - 2023-04-30 16:48:39 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:48:39 --> Form Validation Class Initialized
INFO - 2023-04-30 16:48:39 --> Upload Class Initialized
INFO - 2023-04-30 16:48:39 --> Model "M_auth" initialized
INFO - 2023-04-30 16:48:39 --> Model "M_user" initialized
INFO - 2023-04-30 16:48:39 --> Model "M_produk" initialized
INFO - 2023-04-30 16:48:39 --> Controller Class Initialized
INFO - 2023-04-30 16:48:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-04-30 16:48:39 --> Config Class Initialized
INFO - 2023-04-30 16:48:39 --> Hooks Class Initialized
DEBUG - 2023-04-30 16:48:39 --> UTF-8 Support Enabled
INFO - 2023-04-30 16:48:39 --> Utf8 Class Initialized
INFO - 2023-04-30 16:48:39 --> URI Class Initialized
INFO - 2023-04-30 16:48:39 --> Router Class Initialized
INFO - 2023-04-30 16:48:39 --> Output Class Initialized
INFO - 2023-04-30 16:48:39 --> Security Class Initialized
DEBUG - 2023-04-30 16:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 16:48:39 --> Input Class Initialized
INFO - 2023-04-30 16:48:39 --> Language Class Initialized
INFO - 2023-04-30 16:48:39 --> Loader Class Initialized
INFO - 2023-04-30 16:48:39 --> Helper loaded: url_helper
INFO - 2023-04-30 16:48:39 --> Helper loaded: form_helper
INFO - 2023-04-30 16:48:39 --> Helper loaded: file_helper
INFO - 2023-04-30 16:48:39 --> Database Driver Class Initialized
DEBUG - 2023-04-30 16:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 16:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 16:48:39 --> Form Validation Class Initialized
INFO - 2023-04-30 16:48:39 --> Upload Class Initialized
INFO - 2023-04-30 16:48:39 --> Model "M_auth" initialized
INFO - 2023-04-30 16:48:39 --> Model "M_user" initialized
INFO - 2023-04-30 16:48:39 --> Model "M_produk" initialized
INFO - 2023-04-30 16:48:39 --> Controller Class Initialized
INFO - 2023-04-30 16:48:39 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_dashboard.php
INFO - 2023-04-30 16:48:39 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-30 16:48:39 --> Final output sent to browser
DEBUG - 2023-04-30 16:48:39 --> Total execution time: 0.1108
INFO - 2023-04-30 17:02:45 --> Config Class Initialized
INFO - 2023-04-30 17:02:45 --> Hooks Class Initialized
DEBUG - 2023-04-30 17:02:45 --> UTF-8 Support Enabled
INFO - 2023-04-30 17:02:45 --> Utf8 Class Initialized
INFO - 2023-04-30 17:02:45 --> URI Class Initialized
INFO - 2023-04-30 17:02:45 --> Router Class Initialized
INFO - 2023-04-30 17:02:45 --> Output Class Initialized
INFO - 2023-04-30 17:02:45 --> Security Class Initialized
DEBUG - 2023-04-30 17:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 17:02:45 --> Input Class Initialized
INFO - 2023-04-30 17:02:45 --> Language Class Initialized
INFO - 2023-04-30 17:02:45 --> Loader Class Initialized
INFO - 2023-04-30 17:02:45 --> Helper loaded: url_helper
INFO - 2023-04-30 17:02:45 --> Helper loaded: form_helper
INFO - 2023-04-30 17:02:45 --> Helper loaded: file_helper
INFO - 2023-04-30 17:02:45 --> Database Driver Class Initialized
DEBUG - 2023-04-30 17:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 17:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 17:02:45 --> Form Validation Class Initialized
INFO - 2023-04-30 17:02:45 --> Upload Class Initialized
INFO - 2023-04-30 17:02:45 --> Model "M_auth" initialized
INFO - 2023-04-30 17:02:45 --> Model "M_user" initialized
INFO - 2023-04-30 17:02:45 --> Model "M_produk" initialized
INFO - 2023-04-30 17:02:45 --> Controller Class Initialized
INFO - 2023-04-30 17:02:45 --> Model "M_pelanggan" initialized
INFO - 2023-04-30 17:02:45 --> Model "M_produk" initialized
DEBUG - 2023-04-30 17:02:45 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-30 17:02:45 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-30 17:02:45 --> Model "M_transaksi" initialized
INFO - 2023-04-30 17:02:45 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_transaksi_all.php
INFO - 2023-04-30 17:02:45 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-30 17:02:45 --> Final output sent to browser
DEBUG - 2023-04-30 17:02:45 --> Total execution time: 0.1320
INFO - 2023-04-30 17:13:31 --> Config Class Initialized
INFO - 2023-04-30 17:13:31 --> Hooks Class Initialized
DEBUG - 2023-04-30 17:13:31 --> UTF-8 Support Enabled
INFO - 2023-04-30 17:13:31 --> Utf8 Class Initialized
INFO - 2023-04-30 17:13:31 --> URI Class Initialized
INFO - 2023-04-30 17:13:31 --> Router Class Initialized
INFO - 2023-04-30 17:13:31 --> Output Class Initialized
INFO - 2023-04-30 17:13:31 --> Security Class Initialized
DEBUG - 2023-04-30 17:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 17:13:31 --> Input Class Initialized
INFO - 2023-04-30 17:13:31 --> Language Class Initialized
INFO - 2023-04-30 17:13:31 --> Loader Class Initialized
INFO - 2023-04-30 17:13:31 --> Helper loaded: url_helper
INFO - 2023-04-30 17:13:31 --> Helper loaded: form_helper
INFO - 2023-04-30 17:13:31 --> Helper loaded: file_helper
INFO - 2023-04-30 17:13:31 --> Database Driver Class Initialized
DEBUG - 2023-04-30 17:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 17:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 17:13:31 --> Form Validation Class Initialized
INFO - 2023-04-30 17:13:31 --> Upload Class Initialized
INFO - 2023-04-30 17:13:31 --> Model "M_auth" initialized
INFO - 2023-04-30 17:13:31 --> Model "M_user" initialized
INFO - 2023-04-30 17:13:31 --> Model "M_produk" initialized
INFO - 2023-04-30 17:13:31 --> Controller Class Initialized
INFO - 2023-04-30 17:13:31 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_user_profile.php
INFO - 2023-04-30 17:13:31 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-30 17:13:31 --> Final output sent to browser
DEBUG - 2023-04-30 17:13:31 --> Total execution time: 0.1299
INFO - 2023-04-30 17:13:36 --> Config Class Initialized
INFO - 2023-04-30 17:13:36 --> Hooks Class Initialized
DEBUG - 2023-04-30 17:13:36 --> UTF-8 Support Enabled
INFO - 2023-04-30 17:13:36 --> Utf8 Class Initialized
INFO - 2023-04-30 17:13:36 --> URI Class Initialized
INFO - 2023-04-30 17:13:36 --> Router Class Initialized
INFO - 2023-04-30 17:13:36 --> Output Class Initialized
INFO - 2023-04-30 17:13:36 --> Security Class Initialized
DEBUG - 2023-04-30 17:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 17:13:36 --> Input Class Initialized
INFO - 2023-04-30 17:13:36 --> Language Class Initialized
INFO - 2023-04-30 17:13:36 --> Loader Class Initialized
INFO - 2023-04-30 17:13:36 --> Helper loaded: url_helper
INFO - 2023-04-30 17:13:36 --> Helper loaded: form_helper
INFO - 2023-04-30 17:13:36 --> Helper loaded: file_helper
INFO - 2023-04-30 17:13:36 --> Database Driver Class Initialized
DEBUG - 2023-04-30 17:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 17:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 17:13:36 --> Form Validation Class Initialized
INFO - 2023-04-30 17:13:36 --> Upload Class Initialized
INFO - 2023-04-30 17:13:36 --> Model "M_auth" initialized
INFO - 2023-04-30 17:13:36 --> Model "M_user" initialized
INFO - 2023-04-30 17:13:36 --> Model "M_produk" initialized
INFO - 2023-04-30 17:13:36 --> Controller Class Initialized
INFO - 2023-04-30 17:13:36 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_ganti_password.php
INFO - 2023-04-30 17:13:36 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-30 17:13:36 --> Final output sent to browser
DEBUG - 2023-04-30 17:13:36 --> Total execution time: 0.1025
INFO - 2023-04-30 17:14:13 --> Config Class Initialized
INFO - 2023-04-30 17:14:13 --> Hooks Class Initialized
DEBUG - 2023-04-30 17:14:13 --> UTF-8 Support Enabled
INFO - 2023-04-30 17:14:13 --> Utf8 Class Initialized
INFO - 2023-04-30 17:14:13 --> URI Class Initialized
INFO - 2023-04-30 17:14:13 --> Router Class Initialized
INFO - 2023-04-30 17:14:13 --> Output Class Initialized
INFO - 2023-04-30 17:14:13 --> Security Class Initialized
DEBUG - 2023-04-30 17:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 17:14:13 --> Input Class Initialized
INFO - 2023-04-30 17:14:13 --> Language Class Initialized
INFO - 2023-04-30 17:14:13 --> Loader Class Initialized
INFO - 2023-04-30 17:14:13 --> Helper loaded: url_helper
INFO - 2023-04-30 17:14:13 --> Helper loaded: form_helper
INFO - 2023-04-30 17:14:13 --> Helper loaded: file_helper
INFO - 2023-04-30 17:14:13 --> Database Driver Class Initialized
DEBUG - 2023-04-30 17:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 17:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 17:14:13 --> Form Validation Class Initialized
INFO - 2023-04-30 17:14:13 --> Upload Class Initialized
INFO - 2023-04-30 17:14:13 --> Model "M_auth" initialized
INFO - 2023-04-30 17:14:13 --> Model "M_user" initialized
INFO - 2023-04-30 17:14:13 --> Model "M_produk" initialized
INFO - 2023-04-30 17:14:13 --> Controller Class Initialized
INFO - 2023-04-30 17:14:13 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_user_profile.php
INFO - 2023-04-30 17:14:13 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-30 17:14:13 --> Final output sent to browser
DEBUG - 2023-04-30 17:14:13 --> Total execution time: 0.1191
INFO - 2023-04-30 17:15:01 --> Config Class Initialized
INFO - 2023-04-30 17:15:01 --> Hooks Class Initialized
DEBUG - 2023-04-30 17:15:01 --> UTF-8 Support Enabled
INFO - 2023-04-30 17:15:01 --> Utf8 Class Initialized
INFO - 2023-04-30 17:15:01 --> URI Class Initialized
INFO - 2023-04-30 17:15:01 --> Router Class Initialized
INFO - 2023-04-30 17:15:01 --> Output Class Initialized
INFO - 2023-04-30 17:15:01 --> Security Class Initialized
DEBUG - 2023-04-30 17:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 17:15:01 --> Input Class Initialized
INFO - 2023-04-30 17:15:01 --> Language Class Initialized
INFO - 2023-04-30 17:15:01 --> Loader Class Initialized
INFO - 2023-04-30 17:15:01 --> Helper loaded: url_helper
INFO - 2023-04-30 17:15:01 --> Helper loaded: form_helper
INFO - 2023-04-30 17:15:01 --> Helper loaded: file_helper
INFO - 2023-04-30 17:15:01 --> Database Driver Class Initialized
DEBUG - 2023-04-30 17:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 17:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 17:15:01 --> Form Validation Class Initialized
INFO - 2023-04-30 17:15:01 --> Upload Class Initialized
INFO - 2023-04-30 17:15:01 --> Model "M_auth" initialized
INFO - 2023-04-30 17:15:01 --> Model "M_user" initialized
INFO - 2023-04-30 17:15:01 --> Model "M_produk" initialized
INFO - 2023-04-30 17:15:01 --> Controller Class Initialized
INFO - 2023-04-30 17:15:01 --> Model "M_produk" initialized
INFO - 2023-04-30 17:15:01 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_produk.php
INFO - 2023-04-30 17:15:01 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-30 17:15:01 --> Final output sent to browser
DEBUG - 2023-04-30 17:15:01 --> Total execution time: 0.1292
INFO - 2023-04-30 17:15:03 --> Config Class Initialized
INFO - 2023-04-30 17:15:03 --> Hooks Class Initialized
DEBUG - 2023-04-30 17:15:03 --> UTF-8 Support Enabled
INFO - 2023-04-30 17:15:03 --> Utf8 Class Initialized
INFO - 2023-04-30 17:15:03 --> URI Class Initialized
INFO - 2023-04-30 17:15:03 --> Router Class Initialized
INFO - 2023-04-30 17:15:03 --> Output Class Initialized
INFO - 2023-04-30 17:15:03 --> Security Class Initialized
DEBUG - 2023-04-30 17:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 17:15:03 --> Input Class Initialized
INFO - 2023-04-30 17:15:03 --> Language Class Initialized
INFO - 2023-04-30 17:15:03 --> Loader Class Initialized
INFO - 2023-04-30 17:15:03 --> Helper loaded: url_helper
INFO - 2023-04-30 17:15:03 --> Helper loaded: form_helper
INFO - 2023-04-30 17:15:03 --> Helper loaded: file_helper
INFO - 2023-04-30 17:15:03 --> Database Driver Class Initialized
DEBUG - 2023-04-30 17:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 17:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 17:15:03 --> Form Validation Class Initialized
INFO - 2023-04-30 17:15:03 --> Upload Class Initialized
INFO - 2023-04-30 17:15:03 --> Model "M_auth" initialized
INFO - 2023-04-30 17:15:03 --> Model "M_user" initialized
INFO - 2023-04-30 17:15:03 --> Model "M_produk" initialized
INFO - 2023-04-30 17:15:03 --> Controller Class Initialized
INFO - 2023-04-30 17:15:03 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_ganti_password.php
INFO - 2023-04-30 17:15:03 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\back/v_wrapper.php
INFO - 2023-04-30 17:15:03 --> Final output sent to browser
DEBUG - 2023-04-30 17:15:03 --> Total execution time: 0.1122
INFO - 2023-04-30 17:18:14 --> Config Class Initialized
INFO - 2023-04-30 17:18:14 --> Hooks Class Initialized
DEBUG - 2023-04-30 17:18:14 --> UTF-8 Support Enabled
INFO - 2023-04-30 17:18:14 --> Utf8 Class Initialized
INFO - 2023-04-30 17:18:14 --> URI Class Initialized
DEBUG - 2023-04-30 17:18:14 --> No URI present. Default controller set.
INFO - 2023-04-30 17:18:14 --> Router Class Initialized
INFO - 2023-04-30 17:18:14 --> Output Class Initialized
INFO - 2023-04-30 17:18:14 --> Security Class Initialized
DEBUG - 2023-04-30 17:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-30 17:18:14 --> Input Class Initialized
INFO - 2023-04-30 17:18:14 --> Language Class Initialized
INFO - 2023-04-30 17:18:14 --> Loader Class Initialized
INFO - 2023-04-30 17:18:14 --> Helper loaded: url_helper
INFO - 2023-04-30 17:18:14 --> Helper loaded: form_helper
INFO - 2023-04-30 17:18:14 --> Helper loaded: file_helper
INFO - 2023-04-30 17:18:14 --> Database Driver Class Initialized
DEBUG - 2023-04-30 17:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-30 17:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-30 17:18:14 --> Form Validation Class Initialized
INFO - 2023-04-30 17:18:14 --> Upload Class Initialized
INFO - 2023-04-30 17:18:14 --> Model "M_auth" initialized
INFO - 2023-04-30 17:18:14 --> Model "M_user" initialized
INFO - 2023-04-30 17:18:14 --> Model "M_produk" initialized
INFO - 2023-04-30 17:18:14 --> Controller Class Initialized
INFO - 2023-04-30 17:18:14 --> Model "M_pelanggan" initialized
INFO - 2023-04-30 17:18:14 --> Model "M_produk" initialized
DEBUG - 2023-04-30 17:18:14 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-04-30 17:18:14 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-04-30 17:18:14 --> Model "M_transaksi" initialized
INFO - 2023-04-30 17:18:14 --> Model "M_bank" initialized
INFO - 2023-04-30 17:18:14 --> Model "M_pesan" initialized
INFO - 2023-04-30 17:18:14 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-04-30 17:18:14 --> File loaded: C:\xampp\htdocs\SKRIPSI4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-04-30 17:18:14 --> Final output sent to browser
DEBUG - 2023-04-30 17:18:14 --> Total execution time: 0.1621
