<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-16 01:20:12 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-16 01:20:12 --> Config Class Initialized
INFO - 2023-11-16 01:20:12 --> Hooks Class Initialized
DEBUG - 2023-11-16 01:20:12 --> UTF-8 Support Enabled
INFO - 2023-11-16 01:20:12 --> Utf8 Class Initialized
INFO - 2023-11-16 01:20:12 --> URI Class Initialized
DEBUG - 2023-11-16 01:20:12 --> No URI present. Default controller set.
INFO - 2023-11-16 01:20:12 --> Router Class Initialized
INFO - 2023-11-16 01:20:12 --> Output Class Initialized
INFO - 2023-11-16 01:20:12 --> Security Class Initialized
DEBUG - 2023-11-16 01:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-16 01:20:12 --> Input Class Initialized
INFO - 2023-11-16 01:20:12 --> Language Class Initialized
INFO - 2023-11-16 01:20:12 --> Loader Class Initialized
INFO - 2023-11-16 01:20:12 --> Helper loaded: url_helper
INFO - 2023-11-16 01:20:12 --> Helper loaded: form_helper
INFO - 2023-11-16 01:20:12 --> Helper loaded: file_helper
INFO - 2023-11-16 01:20:12 --> Database Driver Class Initialized
DEBUG - 2023-11-16 01:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-16 01:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-16 01:20:12 --> Form Validation Class Initialized
INFO - 2023-11-16 01:20:12 --> Upload Class Initialized
INFO - 2023-11-16 01:20:12 --> Model "M_auth" initialized
INFO - 2023-11-16 01:20:12 --> Model "M_user" initialized
INFO - 2023-11-16 01:20:12 --> Model "M_produk" initialized
INFO - 2023-11-16 01:20:12 --> Controller Class Initialized
INFO - 2023-11-16 01:20:12 --> Model "M_pelanggan" initialized
INFO - 2023-11-16 01:20:12 --> Model "M_produk" initialized
DEBUG - 2023-11-16 01:20:12 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-16 01:20:12 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-16 01:20:12 --> Model "M_transaksi" initialized
INFO - 2023-11-16 01:20:12 --> Model "M_bank" initialized
INFO - 2023-11-16 01:20:12 --> Model "M_pesan" initialized
DEBUG - 2023-11-16 01:20:12 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-16 01:20:12 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-16 01:20:12 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-16 01:20:12 --> Final output sent to browser
DEBUG - 2023-11-16 01:20:12 --> Total execution time: 0.0421
ERROR - 2023-11-16 03:00:18 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-16 03:00:18 --> Config Class Initialized
INFO - 2023-11-16 03:00:18 --> Hooks Class Initialized
DEBUG - 2023-11-16 03:00:18 --> UTF-8 Support Enabled
INFO - 2023-11-16 03:00:18 --> Utf8 Class Initialized
INFO - 2023-11-16 03:00:18 --> URI Class Initialized
INFO - 2023-11-16 03:00:18 --> Router Class Initialized
INFO - 2023-11-16 03:00:18 --> Output Class Initialized
INFO - 2023-11-16 03:00:18 --> Security Class Initialized
DEBUG - 2023-11-16 03:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-16 03:00:18 --> Input Class Initialized
INFO - 2023-11-16 03:00:18 --> Language Class Initialized
INFO - 2023-11-16 03:00:18 --> Loader Class Initialized
INFO - 2023-11-16 03:00:18 --> Helper loaded: url_helper
INFO - 2023-11-16 03:00:18 --> Helper loaded: form_helper
INFO - 2023-11-16 03:00:18 --> Helper loaded: file_helper
INFO - 2023-11-16 03:00:18 --> Database Driver Class Initialized
DEBUG - 2023-11-16 03:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-16 03:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-16 03:00:18 --> Form Validation Class Initialized
INFO - 2023-11-16 03:00:18 --> Upload Class Initialized
INFO - 2023-11-16 03:00:18 --> Model "M_auth" initialized
INFO - 2023-11-16 03:00:18 --> Model "M_user" initialized
INFO - 2023-11-16 03:00:18 --> Model "M_produk" initialized
INFO - 2023-11-16 03:00:18 --> Controller Class Initialized
INFO - 2023-11-16 03:00:18 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-16 03:00:18 --> Final output sent to browser
DEBUG - 2023-11-16 03:00:18 --> Total execution time: 0.0318
ERROR - 2023-11-16 07:26:39 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-16 07:26:39 --> Config Class Initialized
INFO - 2023-11-16 07:26:39 --> Hooks Class Initialized
DEBUG - 2023-11-16 07:26:39 --> UTF-8 Support Enabled
INFO - 2023-11-16 07:26:39 --> Utf8 Class Initialized
INFO - 2023-11-16 07:26:39 --> URI Class Initialized
DEBUG - 2023-11-16 07:26:39 --> No URI present. Default controller set.
INFO - 2023-11-16 07:26:39 --> Router Class Initialized
INFO - 2023-11-16 07:26:39 --> Output Class Initialized
INFO - 2023-11-16 07:26:39 --> Security Class Initialized
DEBUG - 2023-11-16 07:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-16 07:26:39 --> Input Class Initialized
INFO - 2023-11-16 07:26:39 --> Language Class Initialized
INFO - 2023-11-16 07:26:39 --> Loader Class Initialized
INFO - 2023-11-16 07:26:39 --> Helper loaded: url_helper
INFO - 2023-11-16 07:26:39 --> Helper loaded: form_helper
INFO - 2023-11-16 07:26:39 --> Helper loaded: file_helper
INFO - 2023-11-16 07:26:39 --> Database Driver Class Initialized
DEBUG - 2023-11-16 07:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-16 07:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-16 07:26:39 --> Form Validation Class Initialized
INFO - 2023-11-16 07:26:39 --> Upload Class Initialized
INFO - 2023-11-16 07:26:39 --> Model "M_auth" initialized
INFO - 2023-11-16 07:26:39 --> Model "M_user" initialized
INFO - 2023-11-16 07:26:39 --> Model "M_produk" initialized
INFO - 2023-11-16 07:26:39 --> Controller Class Initialized
INFO - 2023-11-16 07:26:39 --> Model "M_pelanggan" initialized
INFO - 2023-11-16 07:26:39 --> Model "M_produk" initialized
DEBUG - 2023-11-16 07:26:39 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-16 07:26:39 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-16 07:26:39 --> Model "M_transaksi" initialized
INFO - 2023-11-16 07:26:39 --> Model "M_bank" initialized
INFO - 2023-11-16 07:26:39 --> Model "M_pesan" initialized
DEBUG - 2023-11-16 07:26:39 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-16 07:26:39 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-16 07:26:39 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-16 07:26:39 --> Final output sent to browser
DEBUG - 2023-11-16 07:26:39 --> Total execution time: 0.0395
ERROR - 2023-11-16 08:54:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-16 08:54:45 --> Config Class Initialized
INFO - 2023-11-16 08:54:45 --> Hooks Class Initialized
DEBUG - 2023-11-16 08:54:45 --> UTF-8 Support Enabled
INFO - 2023-11-16 08:54:45 --> Utf8 Class Initialized
INFO - 2023-11-16 08:54:45 --> URI Class Initialized
DEBUG - 2023-11-16 08:54:45 --> No URI present. Default controller set.
INFO - 2023-11-16 08:54:45 --> Router Class Initialized
INFO - 2023-11-16 08:54:45 --> Output Class Initialized
INFO - 2023-11-16 08:54:45 --> Security Class Initialized
DEBUG - 2023-11-16 08:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-16 08:54:45 --> Input Class Initialized
INFO - 2023-11-16 08:54:45 --> Language Class Initialized
INFO - 2023-11-16 08:54:45 --> Loader Class Initialized
INFO - 2023-11-16 08:54:45 --> Helper loaded: url_helper
INFO - 2023-11-16 08:54:45 --> Helper loaded: form_helper
INFO - 2023-11-16 08:54:45 --> Helper loaded: file_helper
INFO - 2023-11-16 08:54:45 --> Database Driver Class Initialized
DEBUG - 2023-11-16 08:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-16 08:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-16 08:54:45 --> Form Validation Class Initialized
INFO - 2023-11-16 08:54:45 --> Upload Class Initialized
INFO - 2023-11-16 08:54:45 --> Model "M_auth" initialized
INFO - 2023-11-16 08:54:45 --> Model "M_user" initialized
INFO - 2023-11-16 08:54:45 --> Model "M_produk" initialized
INFO - 2023-11-16 08:54:45 --> Controller Class Initialized
INFO - 2023-11-16 08:54:45 --> Model "M_pelanggan" initialized
INFO - 2023-11-16 08:54:45 --> Model "M_produk" initialized
DEBUG - 2023-11-16 08:54:45 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-16 08:54:45 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-16 08:54:45 --> Model "M_transaksi" initialized
INFO - 2023-11-16 08:54:45 --> Model "M_bank" initialized
INFO - 2023-11-16 08:54:45 --> Model "M_pesan" initialized
DEBUG - 2023-11-16 08:54:45 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-16 08:54:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-16 08:54:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-16 08:54:45 --> Final output sent to browser
DEBUG - 2023-11-16 08:54:45 --> Total execution time: 0.0356
ERROR - 2023-11-16 09:00:24 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-16 09:00:24 --> Config Class Initialized
INFO - 2023-11-16 09:00:24 --> Hooks Class Initialized
DEBUG - 2023-11-16 09:00:24 --> UTF-8 Support Enabled
INFO - 2023-11-16 09:00:24 --> Utf8 Class Initialized
INFO - 2023-11-16 09:00:24 --> URI Class Initialized
DEBUG - 2023-11-16 09:00:24 --> No URI present. Default controller set.
INFO - 2023-11-16 09:00:24 --> Router Class Initialized
INFO - 2023-11-16 09:00:24 --> Output Class Initialized
INFO - 2023-11-16 09:00:24 --> Security Class Initialized
DEBUG - 2023-11-16 09:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-16 09:00:24 --> Input Class Initialized
INFO - 2023-11-16 09:00:24 --> Language Class Initialized
INFO - 2023-11-16 09:00:24 --> Loader Class Initialized
INFO - 2023-11-16 09:00:24 --> Helper loaded: url_helper
INFO - 2023-11-16 09:00:24 --> Helper loaded: form_helper
INFO - 2023-11-16 09:00:24 --> Helper loaded: file_helper
INFO - 2023-11-16 09:00:24 --> Database Driver Class Initialized
DEBUG - 2023-11-16 09:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-16 09:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-16 09:00:24 --> Form Validation Class Initialized
INFO - 2023-11-16 09:00:24 --> Upload Class Initialized
INFO - 2023-11-16 09:00:24 --> Model "M_auth" initialized
INFO - 2023-11-16 09:00:24 --> Model "M_user" initialized
INFO - 2023-11-16 09:00:24 --> Model "M_produk" initialized
INFO - 2023-11-16 09:00:24 --> Controller Class Initialized
INFO - 2023-11-16 09:00:24 --> Model "M_pelanggan" initialized
INFO - 2023-11-16 09:00:24 --> Model "M_produk" initialized
DEBUG - 2023-11-16 09:00:24 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-16 09:00:24 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-16 09:00:24 --> Model "M_transaksi" initialized
INFO - 2023-11-16 09:00:24 --> Model "M_bank" initialized
INFO - 2023-11-16 09:00:24 --> Model "M_pesan" initialized
DEBUG - 2023-11-16 09:00:24 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-16 09:00:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-16 09:00:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-16 09:00:24 --> Final output sent to browser
DEBUG - 2023-11-16 09:00:24 --> Total execution time: 0.0308
ERROR - 2023-11-16 09:05:59 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-16 09:05:59 --> Config Class Initialized
INFO - 2023-11-16 09:05:59 --> Hooks Class Initialized
DEBUG - 2023-11-16 09:05:59 --> UTF-8 Support Enabled
INFO - 2023-11-16 09:05:59 --> Utf8 Class Initialized
INFO - 2023-11-16 09:05:59 --> URI Class Initialized
DEBUG - 2023-11-16 09:05:59 --> No URI present. Default controller set.
INFO - 2023-11-16 09:05:59 --> Router Class Initialized
INFO - 2023-11-16 09:05:59 --> Output Class Initialized
INFO - 2023-11-16 09:05:59 --> Security Class Initialized
DEBUG - 2023-11-16 09:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-16 09:05:59 --> Input Class Initialized
INFO - 2023-11-16 09:05:59 --> Language Class Initialized
INFO - 2023-11-16 09:05:59 --> Loader Class Initialized
INFO - 2023-11-16 09:05:59 --> Helper loaded: url_helper
INFO - 2023-11-16 09:05:59 --> Helper loaded: form_helper
INFO - 2023-11-16 09:05:59 --> Helper loaded: file_helper
INFO - 2023-11-16 09:05:59 --> Database Driver Class Initialized
DEBUG - 2023-11-16 09:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-16 09:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-16 09:05:59 --> Form Validation Class Initialized
INFO - 2023-11-16 09:05:59 --> Upload Class Initialized
INFO - 2023-11-16 09:05:59 --> Model "M_auth" initialized
INFO - 2023-11-16 09:05:59 --> Model "M_user" initialized
INFO - 2023-11-16 09:05:59 --> Model "M_produk" initialized
INFO - 2023-11-16 09:05:59 --> Controller Class Initialized
INFO - 2023-11-16 09:05:59 --> Model "M_pelanggan" initialized
INFO - 2023-11-16 09:05:59 --> Model "M_produk" initialized
DEBUG - 2023-11-16 09:05:59 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-16 09:05:59 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-16 09:05:59 --> Model "M_transaksi" initialized
INFO - 2023-11-16 09:05:59 --> Model "M_bank" initialized
INFO - 2023-11-16 09:05:59 --> Model "M_pesan" initialized
DEBUG - 2023-11-16 09:05:59 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-16 09:05:59 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-16 09:05:59 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-16 09:05:59 --> Final output sent to browser
DEBUG - 2023-11-16 09:05:59 --> Total execution time: 0.0347
ERROR - 2023-11-16 09:32:57 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-16 09:32:57 --> Config Class Initialized
INFO - 2023-11-16 09:32:57 --> Hooks Class Initialized
DEBUG - 2023-11-16 09:32:57 --> UTF-8 Support Enabled
INFO - 2023-11-16 09:32:57 --> Utf8 Class Initialized
INFO - 2023-11-16 09:32:57 --> URI Class Initialized
DEBUG - 2023-11-16 09:32:57 --> No URI present. Default controller set.
INFO - 2023-11-16 09:32:57 --> Router Class Initialized
INFO - 2023-11-16 09:32:57 --> Output Class Initialized
INFO - 2023-11-16 09:32:57 --> Security Class Initialized
DEBUG - 2023-11-16 09:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-16 09:32:57 --> Input Class Initialized
INFO - 2023-11-16 09:32:57 --> Language Class Initialized
INFO - 2023-11-16 09:32:57 --> Loader Class Initialized
INFO - 2023-11-16 09:32:57 --> Helper loaded: url_helper
INFO - 2023-11-16 09:32:57 --> Helper loaded: form_helper
INFO - 2023-11-16 09:32:57 --> Helper loaded: file_helper
INFO - 2023-11-16 09:32:57 --> Database Driver Class Initialized
DEBUG - 2023-11-16 09:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-16 09:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-16 09:32:57 --> Form Validation Class Initialized
INFO - 2023-11-16 09:32:57 --> Upload Class Initialized
INFO - 2023-11-16 09:32:57 --> Model "M_auth" initialized
INFO - 2023-11-16 09:32:57 --> Model "M_user" initialized
INFO - 2023-11-16 09:32:57 --> Model "M_produk" initialized
INFO - 2023-11-16 09:32:57 --> Controller Class Initialized
INFO - 2023-11-16 09:32:57 --> Model "M_pelanggan" initialized
INFO - 2023-11-16 09:32:57 --> Model "M_produk" initialized
DEBUG - 2023-11-16 09:32:57 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-16 09:32:57 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-16 09:32:57 --> Model "M_transaksi" initialized
INFO - 2023-11-16 09:32:57 --> Model "M_bank" initialized
INFO - 2023-11-16 09:32:57 --> Model "M_pesan" initialized
DEBUG - 2023-11-16 09:32:57 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-16 09:32:57 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-16 09:32:57 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-16 09:32:57 --> Final output sent to browser
DEBUG - 2023-11-16 09:32:57 --> Total execution time: 0.0299
ERROR - 2023-11-16 09:32:58 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-16 09:32:58 --> Config Class Initialized
INFO - 2023-11-16 09:32:58 --> Hooks Class Initialized
DEBUG - 2023-11-16 09:32:58 --> UTF-8 Support Enabled
INFO - 2023-11-16 09:32:58 --> Utf8 Class Initialized
INFO - 2023-11-16 09:32:58 --> URI Class Initialized
DEBUG - 2023-11-16 09:32:58 --> No URI present. Default controller set.
INFO - 2023-11-16 09:32:58 --> Router Class Initialized
INFO - 2023-11-16 09:32:58 --> Output Class Initialized
INFO - 2023-11-16 09:32:58 --> Security Class Initialized
DEBUG - 2023-11-16 09:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-16 09:32:58 --> Input Class Initialized
INFO - 2023-11-16 09:32:58 --> Language Class Initialized
INFO - 2023-11-16 09:32:58 --> Loader Class Initialized
INFO - 2023-11-16 09:32:58 --> Helper loaded: url_helper
INFO - 2023-11-16 09:32:58 --> Helper loaded: form_helper
INFO - 2023-11-16 09:32:58 --> Helper loaded: file_helper
INFO - 2023-11-16 09:32:58 --> Database Driver Class Initialized
DEBUG - 2023-11-16 09:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-16 09:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-16 09:32:58 --> Form Validation Class Initialized
INFO - 2023-11-16 09:32:58 --> Upload Class Initialized
INFO - 2023-11-16 09:32:58 --> Model "M_auth" initialized
INFO - 2023-11-16 09:32:58 --> Model "M_user" initialized
INFO - 2023-11-16 09:32:58 --> Model "M_produk" initialized
INFO - 2023-11-16 09:32:58 --> Controller Class Initialized
INFO - 2023-11-16 09:32:58 --> Model "M_pelanggan" initialized
INFO - 2023-11-16 09:32:58 --> Model "M_produk" initialized
DEBUG - 2023-11-16 09:32:58 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-16 09:32:58 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-16 09:32:58 --> Model "M_transaksi" initialized
INFO - 2023-11-16 09:32:58 --> Model "M_bank" initialized
INFO - 2023-11-16 09:32:58 --> Model "M_pesan" initialized
DEBUG - 2023-11-16 09:32:58 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-16 09:32:58 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-16 09:32:58 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-16 09:32:58 --> Final output sent to browser
DEBUG - 2023-11-16 09:32:58 --> Total execution time: 0.0041
ERROR - 2023-11-16 09:33:01 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-16 09:33:01 --> Config Class Initialized
INFO - 2023-11-16 09:33:01 --> Hooks Class Initialized
DEBUG - 2023-11-16 09:33:01 --> UTF-8 Support Enabled
INFO - 2023-11-16 09:33:01 --> Utf8 Class Initialized
INFO - 2023-11-16 09:33:01 --> URI Class Initialized
DEBUG - 2023-11-16 09:33:01 --> No URI present. Default controller set.
INFO - 2023-11-16 09:33:01 --> Router Class Initialized
INFO - 2023-11-16 09:33:01 --> Output Class Initialized
INFO - 2023-11-16 09:33:01 --> Security Class Initialized
DEBUG - 2023-11-16 09:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-16 09:33:01 --> Input Class Initialized
INFO - 2023-11-16 09:33:01 --> Language Class Initialized
INFO - 2023-11-16 09:33:01 --> Loader Class Initialized
INFO - 2023-11-16 09:33:01 --> Helper loaded: url_helper
INFO - 2023-11-16 09:33:01 --> Helper loaded: form_helper
INFO - 2023-11-16 09:33:01 --> Helper loaded: file_helper
INFO - 2023-11-16 09:33:01 --> Database Driver Class Initialized
DEBUG - 2023-11-16 09:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-16 09:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-16 09:33:01 --> Form Validation Class Initialized
INFO - 2023-11-16 09:33:01 --> Upload Class Initialized
INFO - 2023-11-16 09:33:01 --> Model "M_auth" initialized
INFO - 2023-11-16 09:33:01 --> Model "M_user" initialized
INFO - 2023-11-16 09:33:01 --> Model "M_produk" initialized
INFO - 2023-11-16 09:33:01 --> Controller Class Initialized
INFO - 2023-11-16 09:33:01 --> Model "M_pelanggan" initialized
INFO - 2023-11-16 09:33:01 --> Model "M_produk" initialized
DEBUG - 2023-11-16 09:33:01 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-16 09:33:01 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-16 09:33:01 --> Model "M_transaksi" initialized
INFO - 2023-11-16 09:33:01 --> Model "M_bank" initialized
INFO - 2023-11-16 09:33:01 --> Model "M_pesan" initialized
DEBUG - 2023-11-16 09:33:01 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-16 09:33:01 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-16 09:33:01 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-16 09:33:01 --> Final output sent to browser
DEBUG - 2023-11-16 09:33:01 --> Total execution time: 0.0031
ERROR - 2023-11-16 11:37:05 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-16 11:37:05 --> Config Class Initialized
INFO - 2023-11-16 11:37:05 --> Hooks Class Initialized
DEBUG - 2023-11-16 11:37:05 --> UTF-8 Support Enabled
INFO - 2023-11-16 11:37:05 --> Utf8 Class Initialized
INFO - 2023-11-16 11:37:05 --> URI Class Initialized
DEBUG - 2023-11-16 11:37:05 --> No URI present. Default controller set.
INFO - 2023-11-16 11:37:05 --> Router Class Initialized
INFO - 2023-11-16 11:37:05 --> Output Class Initialized
INFO - 2023-11-16 11:37:05 --> Security Class Initialized
DEBUG - 2023-11-16 11:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-16 11:37:05 --> Input Class Initialized
INFO - 2023-11-16 11:37:05 --> Language Class Initialized
INFO - 2023-11-16 11:37:05 --> Loader Class Initialized
INFO - 2023-11-16 11:37:05 --> Helper loaded: url_helper
INFO - 2023-11-16 11:37:05 --> Helper loaded: form_helper
INFO - 2023-11-16 11:37:05 --> Helper loaded: file_helper
INFO - 2023-11-16 11:37:05 --> Database Driver Class Initialized
DEBUG - 2023-11-16 11:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-16 11:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-16 11:37:05 --> Form Validation Class Initialized
INFO - 2023-11-16 11:37:05 --> Upload Class Initialized
INFO - 2023-11-16 11:37:05 --> Model "M_auth" initialized
INFO - 2023-11-16 11:37:05 --> Model "M_user" initialized
INFO - 2023-11-16 11:37:05 --> Model "M_produk" initialized
INFO - 2023-11-16 11:37:05 --> Controller Class Initialized
INFO - 2023-11-16 11:37:05 --> Model "M_pelanggan" initialized
INFO - 2023-11-16 11:37:05 --> Model "M_produk" initialized
DEBUG - 2023-11-16 11:37:05 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-16 11:37:05 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-16 11:37:05 --> Model "M_transaksi" initialized
INFO - 2023-11-16 11:37:05 --> Model "M_bank" initialized
INFO - 2023-11-16 11:37:05 --> Model "M_pesan" initialized
DEBUG - 2023-11-16 11:37:05 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-16 11:37:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-16 11:37:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-16 11:37:05 --> Final output sent to browser
DEBUG - 2023-11-16 11:37:05 --> Total execution time: 0.0418
ERROR - 2023-11-16 12:28:44 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-16 12:28:44 --> Config Class Initialized
INFO - 2023-11-16 12:28:44 --> Hooks Class Initialized
DEBUG - 2023-11-16 12:28:44 --> UTF-8 Support Enabled
INFO - 2023-11-16 12:28:44 --> Utf8 Class Initialized
INFO - 2023-11-16 12:28:44 --> URI Class Initialized
DEBUG - 2023-11-16 12:28:44 --> No URI present. Default controller set.
INFO - 2023-11-16 12:28:44 --> Router Class Initialized
INFO - 2023-11-16 12:28:44 --> Output Class Initialized
INFO - 2023-11-16 12:28:44 --> Security Class Initialized
DEBUG - 2023-11-16 12:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-16 12:28:44 --> Input Class Initialized
INFO - 2023-11-16 12:28:44 --> Language Class Initialized
INFO - 2023-11-16 12:28:44 --> Loader Class Initialized
INFO - 2023-11-16 12:28:44 --> Helper loaded: url_helper
INFO - 2023-11-16 12:28:44 --> Helper loaded: form_helper
INFO - 2023-11-16 12:28:44 --> Helper loaded: file_helper
INFO - 2023-11-16 12:28:44 --> Database Driver Class Initialized
DEBUG - 2023-11-16 12:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-16 12:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-16 12:28:44 --> Form Validation Class Initialized
INFO - 2023-11-16 12:28:44 --> Upload Class Initialized
INFO - 2023-11-16 12:28:44 --> Model "M_auth" initialized
INFO - 2023-11-16 12:28:44 --> Model "M_user" initialized
INFO - 2023-11-16 12:28:44 --> Model "M_produk" initialized
INFO - 2023-11-16 12:28:44 --> Controller Class Initialized
INFO - 2023-11-16 12:28:44 --> Model "M_pelanggan" initialized
INFO - 2023-11-16 12:28:44 --> Model "M_produk" initialized
DEBUG - 2023-11-16 12:28:44 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-16 12:28:44 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-16 12:28:44 --> Model "M_transaksi" initialized
INFO - 2023-11-16 12:28:44 --> Model "M_bank" initialized
INFO - 2023-11-16 12:28:44 --> Model "M_pesan" initialized
DEBUG - 2023-11-16 12:28:44 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-16 12:28:44 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-16 12:28:44 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-16 12:28:44 --> Final output sent to browser
DEBUG - 2023-11-16 12:28:44 --> Total execution time: 0.0420
ERROR - 2023-11-16 12:29:02 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-16 12:29:02 --> Config Class Initialized
INFO - 2023-11-16 12:29:02 --> Hooks Class Initialized
DEBUG - 2023-11-16 12:29:02 --> UTF-8 Support Enabled
INFO - 2023-11-16 12:29:02 --> Utf8 Class Initialized
INFO - 2023-11-16 12:29:02 --> URI Class Initialized
DEBUG - 2023-11-16 12:29:02 --> No URI present. Default controller set.
INFO - 2023-11-16 12:29:02 --> Router Class Initialized
INFO - 2023-11-16 12:29:02 --> Output Class Initialized
INFO - 2023-11-16 12:29:02 --> Security Class Initialized
DEBUG - 2023-11-16 12:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-16 12:29:02 --> Input Class Initialized
INFO - 2023-11-16 12:29:02 --> Language Class Initialized
INFO - 2023-11-16 12:29:02 --> Loader Class Initialized
INFO - 2023-11-16 12:29:02 --> Helper loaded: url_helper
INFO - 2023-11-16 12:29:02 --> Helper loaded: form_helper
INFO - 2023-11-16 12:29:02 --> Helper loaded: file_helper
INFO - 2023-11-16 12:29:02 --> Database Driver Class Initialized
DEBUG - 2023-11-16 12:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-16 12:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-16 12:29:02 --> Form Validation Class Initialized
INFO - 2023-11-16 12:29:02 --> Upload Class Initialized
INFO - 2023-11-16 12:29:02 --> Model "M_auth" initialized
INFO - 2023-11-16 12:29:02 --> Model "M_user" initialized
INFO - 2023-11-16 12:29:02 --> Model "M_produk" initialized
INFO - 2023-11-16 12:29:02 --> Controller Class Initialized
INFO - 2023-11-16 12:29:02 --> Model "M_pelanggan" initialized
INFO - 2023-11-16 12:29:02 --> Model "M_produk" initialized
DEBUG - 2023-11-16 12:29:02 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-16 12:29:02 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-16 12:29:02 --> Model "M_transaksi" initialized
INFO - 2023-11-16 12:29:02 --> Model "M_bank" initialized
INFO - 2023-11-16 12:29:02 --> Model "M_pesan" initialized
DEBUG - 2023-11-16 12:29:02 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-16 12:29:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-16 12:29:02 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-16 12:29:02 --> Final output sent to browser
DEBUG - 2023-11-16 12:29:02 --> Total execution time: 0.0056
ERROR - 2023-11-16 12:31:26 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-16 12:31:26 --> Config Class Initialized
INFO - 2023-11-16 12:31:26 --> Hooks Class Initialized
DEBUG - 2023-11-16 12:31:26 --> UTF-8 Support Enabled
INFO - 2023-11-16 12:31:26 --> Utf8 Class Initialized
INFO - 2023-11-16 12:31:26 --> URI Class Initialized
DEBUG - 2023-11-16 12:31:26 --> No URI present. Default controller set.
INFO - 2023-11-16 12:31:26 --> Router Class Initialized
INFO - 2023-11-16 12:31:26 --> Output Class Initialized
INFO - 2023-11-16 12:31:26 --> Security Class Initialized
DEBUG - 2023-11-16 12:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-16 12:31:26 --> Input Class Initialized
INFO - 2023-11-16 12:31:26 --> Language Class Initialized
INFO - 2023-11-16 12:31:26 --> Loader Class Initialized
INFO - 2023-11-16 12:31:26 --> Helper loaded: url_helper
INFO - 2023-11-16 12:31:26 --> Helper loaded: form_helper
INFO - 2023-11-16 12:31:26 --> Helper loaded: file_helper
INFO - 2023-11-16 12:31:26 --> Database Driver Class Initialized
DEBUG - 2023-11-16 12:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-16 12:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-16 12:31:26 --> Form Validation Class Initialized
INFO - 2023-11-16 12:31:26 --> Upload Class Initialized
INFO - 2023-11-16 12:31:26 --> Model "M_auth" initialized
INFO - 2023-11-16 12:31:26 --> Model "M_user" initialized
INFO - 2023-11-16 12:31:26 --> Model "M_produk" initialized
INFO - 2023-11-16 12:31:26 --> Controller Class Initialized
INFO - 2023-11-16 12:31:26 --> Model "M_pelanggan" initialized
INFO - 2023-11-16 12:31:26 --> Model "M_produk" initialized
DEBUG - 2023-11-16 12:31:26 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-16 12:31:26 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-16 12:31:26 --> Model "M_transaksi" initialized
INFO - 2023-11-16 12:31:26 --> Model "M_bank" initialized
INFO - 2023-11-16 12:31:26 --> Model "M_pesan" initialized
DEBUG - 2023-11-16 12:31:26 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-16 12:31:26 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-16 12:31:26 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-16 12:31:26 --> Final output sent to browser
DEBUG - 2023-11-16 12:31:26 --> Total execution time: 0.0043
ERROR - 2023-11-16 12:51:41 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-16 12:51:41 --> Config Class Initialized
INFO - 2023-11-16 12:51:41 --> Hooks Class Initialized
DEBUG - 2023-11-16 12:51:41 --> UTF-8 Support Enabled
INFO - 2023-11-16 12:51:41 --> Utf8 Class Initialized
INFO - 2023-11-16 12:51:41 --> URI Class Initialized
DEBUG - 2023-11-16 12:51:41 --> No URI present. Default controller set.
INFO - 2023-11-16 12:51:41 --> Router Class Initialized
INFO - 2023-11-16 12:51:41 --> Output Class Initialized
INFO - 2023-11-16 12:51:41 --> Security Class Initialized
DEBUG - 2023-11-16 12:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-16 12:51:41 --> Input Class Initialized
INFO - 2023-11-16 12:51:41 --> Language Class Initialized
INFO - 2023-11-16 12:51:41 --> Loader Class Initialized
INFO - 2023-11-16 12:51:41 --> Helper loaded: url_helper
INFO - 2023-11-16 12:51:41 --> Helper loaded: form_helper
INFO - 2023-11-16 12:51:41 --> Helper loaded: file_helper
INFO - 2023-11-16 12:51:41 --> Database Driver Class Initialized
DEBUG - 2023-11-16 12:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-16 12:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-16 12:51:41 --> Form Validation Class Initialized
INFO - 2023-11-16 12:51:41 --> Upload Class Initialized
INFO - 2023-11-16 12:51:41 --> Model "M_auth" initialized
INFO - 2023-11-16 12:51:41 --> Model "M_user" initialized
INFO - 2023-11-16 12:51:41 --> Model "M_produk" initialized
INFO - 2023-11-16 12:51:41 --> Controller Class Initialized
INFO - 2023-11-16 12:51:41 --> Model "M_pelanggan" initialized
INFO - 2023-11-16 12:51:41 --> Model "M_produk" initialized
DEBUG - 2023-11-16 12:51:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-16 12:51:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-16 12:51:41 --> Model "M_transaksi" initialized
INFO - 2023-11-16 12:51:41 --> Model "M_bank" initialized
INFO - 2023-11-16 12:51:41 --> Model "M_pesan" initialized
DEBUG - 2023-11-16 12:51:41 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-16 12:51:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-16 12:51:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-16 12:51:41 --> Final output sent to browser
DEBUG - 2023-11-16 12:51:41 --> Total execution time: 0.0455
ERROR - 2023-11-16 12:55:23 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-16 12:55:23 --> Config Class Initialized
INFO - 2023-11-16 12:55:23 --> Hooks Class Initialized
DEBUG - 2023-11-16 12:55:23 --> UTF-8 Support Enabled
INFO - 2023-11-16 12:55:23 --> Utf8 Class Initialized
INFO - 2023-11-16 12:55:23 --> URI Class Initialized
INFO - 2023-11-16 12:55:23 --> Router Class Initialized
INFO - 2023-11-16 12:55:23 --> Output Class Initialized
INFO - 2023-11-16 12:55:23 --> Security Class Initialized
DEBUG - 2023-11-16 12:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-16 12:55:23 --> Input Class Initialized
INFO - 2023-11-16 12:55:23 --> Language Class Initialized
INFO - 2023-11-16 12:55:23 --> Loader Class Initialized
INFO - 2023-11-16 12:55:23 --> Helper loaded: url_helper
INFO - 2023-11-16 12:55:23 --> Helper loaded: form_helper
INFO - 2023-11-16 12:55:23 --> Helper loaded: file_helper
INFO - 2023-11-16 12:55:23 --> Database Driver Class Initialized
DEBUG - 2023-11-16 12:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-16 12:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-16 12:55:23 --> Form Validation Class Initialized
INFO - 2023-11-16 12:55:23 --> Upload Class Initialized
INFO - 2023-11-16 12:55:23 --> Model "M_auth" initialized
INFO - 2023-11-16 12:55:23 --> Model "M_user" initialized
INFO - 2023-11-16 12:55:23 --> Model "M_produk" initialized
INFO - 2023-11-16 12:55:23 --> Controller Class Initialized
INFO - 2023-11-16 12:55:23 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-16 12:55:23 --> Final output sent to browser
DEBUG - 2023-11-16 12:55:23 --> Total execution time: 0.0039
ERROR - 2023-11-16 12:55:24 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-16 12:55:24 --> Config Class Initialized
INFO - 2023-11-16 12:55:24 --> Hooks Class Initialized
DEBUG - 2023-11-16 12:55:24 --> UTF-8 Support Enabled
INFO - 2023-11-16 12:55:24 --> Utf8 Class Initialized
INFO - 2023-11-16 12:55:24 --> URI Class Initialized
INFO - 2023-11-16 12:55:24 --> Router Class Initialized
INFO - 2023-11-16 12:55:24 --> Output Class Initialized
INFO - 2023-11-16 12:55:24 --> Security Class Initialized
DEBUG - 2023-11-16 12:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-16 12:55:24 --> Input Class Initialized
INFO - 2023-11-16 12:55:24 --> Language Class Initialized
INFO - 2023-11-16 12:55:24 --> Loader Class Initialized
INFO - 2023-11-16 12:55:24 --> Helper loaded: url_helper
INFO - 2023-11-16 12:55:24 --> Helper loaded: form_helper
INFO - 2023-11-16 12:55:24 --> Helper loaded: file_helper
INFO - 2023-11-16 12:55:24 --> Database Driver Class Initialized
DEBUG - 2023-11-16 12:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-16 12:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-16 12:55:24 --> Form Validation Class Initialized
INFO - 2023-11-16 12:55:24 --> Upload Class Initialized
INFO - 2023-11-16 12:55:24 --> Model "M_auth" initialized
INFO - 2023-11-16 12:55:24 --> Model "M_user" initialized
INFO - 2023-11-16 12:55:24 --> Model "M_produk" initialized
INFO - 2023-11-16 12:55:24 --> Controller Class Initialized
INFO - 2023-11-16 12:55:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-16 12:55:24 --> Final output sent to browser
DEBUG - 2023-11-16 12:55:24 --> Total execution time: 0.0024
ERROR - 2023-11-16 14:21:31 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-16 14:21:31 --> Config Class Initialized
INFO - 2023-11-16 14:21:31 --> Hooks Class Initialized
DEBUG - 2023-11-16 14:21:31 --> UTF-8 Support Enabled
INFO - 2023-11-16 14:21:31 --> Utf8 Class Initialized
INFO - 2023-11-16 14:21:31 --> URI Class Initialized
INFO - 2023-11-16 14:21:31 --> Router Class Initialized
INFO - 2023-11-16 14:21:31 --> Output Class Initialized
INFO - 2023-11-16 14:21:31 --> Security Class Initialized
DEBUG - 2023-11-16 14:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-16 14:21:31 --> Input Class Initialized
INFO - 2023-11-16 14:21:31 --> Language Class Initialized
INFO - 2023-11-16 14:21:31 --> Loader Class Initialized
INFO - 2023-11-16 14:21:31 --> Helper loaded: url_helper
INFO - 2023-11-16 14:21:31 --> Helper loaded: form_helper
INFO - 2023-11-16 14:21:31 --> Helper loaded: file_helper
INFO - 2023-11-16 14:21:31 --> Database Driver Class Initialized
DEBUG - 2023-11-16 14:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-16 14:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-16 14:21:31 --> Form Validation Class Initialized
INFO - 2023-11-16 14:21:31 --> Upload Class Initialized
INFO - 2023-11-16 14:21:31 --> Model "M_auth" initialized
INFO - 2023-11-16 14:21:31 --> Model "M_user" initialized
INFO - 2023-11-16 14:21:31 --> Model "M_produk" initialized
INFO - 2023-11-16 14:21:31 --> Controller Class Initialized
INFO - 2023-11-16 14:21:31 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-16 14:21:31 --> Final output sent to browser
DEBUG - 2023-11-16 14:21:31 --> Total execution time: 0.0290
ERROR - 2023-11-16 14:21:33 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-16 14:21:33 --> Config Class Initialized
INFO - 2023-11-16 14:21:33 --> Hooks Class Initialized
DEBUG - 2023-11-16 14:21:33 --> UTF-8 Support Enabled
INFO - 2023-11-16 14:21:33 --> Utf8 Class Initialized
INFO - 2023-11-16 14:21:33 --> URI Class Initialized
DEBUG - 2023-11-16 14:21:33 --> No URI present. Default controller set.
INFO - 2023-11-16 14:21:33 --> Router Class Initialized
INFO - 2023-11-16 14:21:33 --> Output Class Initialized
INFO - 2023-11-16 14:21:33 --> Security Class Initialized
DEBUG - 2023-11-16 14:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-16 14:21:33 --> Input Class Initialized
INFO - 2023-11-16 14:21:33 --> Language Class Initialized
INFO - 2023-11-16 14:21:33 --> Loader Class Initialized
INFO - 2023-11-16 14:21:33 --> Helper loaded: url_helper
INFO - 2023-11-16 14:21:33 --> Helper loaded: form_helper
INFO - 2023-11-16 14:21:33 --> Helper loaded: file_helper
INFO - 2023-11-16 14:21:33 --> Database Driver Class Initialized
DEBUG - 2023-11-16 14:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-16 14:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-16 14:21:33 --> Form Validation Class Initialized
INFO - 2023-11-16 14:21:33 --> Upload Class Initialized
INFO - 2023-11-16 14:21:33 --> Model "M_auth" initialized
INFO - 2023-11-16 14:21:33 --> Model "M_user" initialized
INFO - 2023-11-16 14:21:33 --> Model "M_produk" initialized
INFO - 2023-11-16 14:21:33 --> Controller Class Initialized
INFO - 2023-11-16 14:21:33 --> Model "M_pelanggan" initialized
INFO - 2023-11-16 14:21:33 --> Model "M_produk" initialized
DEBUG - 2023-11-16 14:21:33 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-16 14:21:33 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-16 14:21:33 --> Model "M_transaksi" initialized
INFO - 2023-11-16 14:21:33 --> Model "M_bank" initialized
INFO - 2023-11-16 14:21:33 --> Model "M_pesan" initialized
DEBUG - 2023-11-16 14:21:33 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-16 14:21:33 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-16 14:21:33 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-16 14:21:33 --> Final output sent to browser
DEBUG - 2023-11-16 14:21:33 --> Total execution time: 0.0120
ERROR - 2023-11-16 15:22:41 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-16 15:22:41 --> Config Class Initialized
INFO - 2023-11-16 15:22:41 --> Hooks Class Initialized
DEBUG - 2023-11-16 15:22:41 --> UTF-8 Support Enabled
INFO - 2023-11-16 15:22:41 --> Utf8 Class Initialized
INFO - 2023-11-16 15:22:41 --> URI Class Initialized
INFO - 2023-11-16 15:22:41 --> Router Class Initialized
INFO - 2023-11-16 15:22:41 --> Output Class Initialized
INFO - 2023-11-16 15:22:41 --> Security Class Initialized
DEBUG - 2023-11-16 15:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-16 15:22:41 --> Input Class Initialized
INFO - 2023-11-16 15:22:41 --> Language Class Initialized
INFO - 2023-11-16 15:22:41 --> Loader Class Initialized
INFO - 2023-11-16 15:22:41 --> Helper loaded: url_helper
INFO - 2023-11-16 15:22:41 --> Helper loaded: form_helper
INFO - 2023-11-16 15:22:41 --> Helper loaded: file_helper
INFO - 2023-11-16 15:22:41 --> Database Driver Class Initialized
DEBUG - 2023-11-16 15:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-16 15:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-16 15:22:41 --> Form Validation Class Initialized
INFO - 2023-11-16 15:22:41 --> Upload Class Initialized
INFO - 2023-11-16 15:22:41 --> Model "M_auth" initialized
INFO - 2023-11-16 15:22:41 --> Model "M_user" initialized
INFO - 2023-11-16 15:22:41 --> Model "M_produk" initialized
INFO - 2023-11-16 15:22:41 --> Controller Class Initialized
INFO - 2023-11-16 15:22:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-16 15:22:41 --> Final output sent to browser
DEBUG - 2023-11-16 15:22:41 --> Total execution time: 0.0268
ERROR - 2023-11-16 15:22:42 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-16 15:22:42 --> Config Class Initialized
INFO - 2023-11-16 15:22:42 --> Hooks Class Initialized
DEBUG - 2023-11-16 15:22:42 --> UTF-8 Support Enabled
INFO - 2023-11-16 15:22:42 --> Utf8 Class Initialized
INFO - 2023-11-16 15:22:42 --> URI Class Initialized
DEBUG - 2023-11-16 15:22:42 --> No URI present. Default controller set.
INFO - 2023-11-16 15:22:42 --> Router Class Initialized
INFO - 2023-11-16 15:22:42 --> Output Class Initialized
INFO - 2023-11-16 15:22:42 --> Security Class Initialized
DEBUG - 2023-11-16 15:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-16 15:22:42 --> Input Class Initialized
INFO - 2023-11-16 15:22:42 --> Language Class Initialized
INFO - 2023-11-16 15:22:42 --> Loader Class Initialized
INFO - 2023-11-16 15:22:42 --> Helper loaded: url_helper
INFO - 2023-11-16 15:22:42 --> Helper loaded: form_helper
INFO - 2023-11-16 15:22:42 --> Helper loaded: file_helper
INFO - 2023-11-16 15:22:42 --> Database Driver Class Initialized
DEBUG - 2023-11-16 15:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-16 15:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-16 15:22:42 --> Form Validation Class Initialized
INFO - 2023-11-16 15:22:42 --> Upload Class Initialized
INFO - 2023-11-16 15:22:42 --> Model "M_auth" initialized
INFO - 2023-11-16 15:22:42 --> Model "M_user" initialized
INFO - 2023-11-16 15:22:42 --> Model "M_produk" initialized
INFO - 2023-11-16 15:22:42 --> Controller Class Initialized
INFO - 2023-11-16 15:22:42 --> Model "M_pelanggan" initialized
INFO - 2023-11-16 15:22:42 --> Model "M_produk" initialized
DEBUG - 2023-11-16 15:22:42 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-16 15:22:42 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-16 15:22:42 --> Model "M_transaksi" initialized
INFO - 2023-11-16 15:22:42 --> Model "M_bank" initialized
INFO - 2023-11-16 15:22:42 --> Model "M_pesan" initialized
DEBUG - 2023-11-16 15:22:42 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-16 15:22:42 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-16 15:22:42 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-16 15:22:42 --> Final output sent to browser
DEBUG - 2023-11-16 15:22:42 --> Total execution time: 0.0090
ERROR - 2023-11-16 16:15:57 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-16 16:15:57 --> Config Class Initialized
INFO - 2023-11-16 16:15:57 --> Hooks Class Initialized
DEBUG - 2023-11-16 16:15:57 --> UTF-8 Support Enabled
INFO - 2023-11-16 16:15:57 --> Utf8 Class Initialized
INFO - 2023-11-16 16:15:57 --> URI Class Initialized
INFO - 2023-11-16 16:15:57 --> Router Class Initialized
INFO - 2023-11-16 16:15:57 --> Output Class Initialized
INFO - 2023-11-16 16:15:57 --> Security Class Initialized
DEBUG - 2023-11-16 16:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-16 16:15:57 --> Input Class Initialized
INFO - 2023-11-16 16:15:57 --> Language Class Initialized
INFO - 2023-11-16 16:15:57 --> Loader Class Initialized
INFO - 2023-11-16 16:15:57 --> Helper loaded: url_helper
INFO - 2023-11-16 16:15:57 --> Helper loaded: form_helper
INFO - 2023-11-16 16:15:57 --> Helper loaded: file_helper
INFO - 2023-11-16 16:15:57 --> Database Driver Class Initialized
DEBUG - 2023-11-16 16:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-16 16:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-16 16:15:57 --> Form Validation Class Initialized
INFO - 2023-11-16 16:15:57 --> Upload Class Initialized
INFO - 2023-11-16 16:15:57 --> Model "M_auth" initialized
INFO - 2023-11-16 16:15:57 --> Model "M_user" initialized
INFO - 2023-11-16 16:15:57 --> Model "M_produk" initialized
INFO - 2023-11-16 16:15:57 --> Controller Class Initialized
INFO - 2023-11-16 16:15:57 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-16 16:15:57 --> Final output sent to browser
DEBUG - 2023-11-16 16:15:57 --> Total execution time: 0.0258
ERROR - 2023-11-16 16:15:59 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-16 16:15:59 --> Config Class Initialized
INFO - 2023-11-16 16:15:59 --> Hooks Class Initialized
DEBUG - 2023-11-16 16:15:59 --> UTF-8 Support Enabled
INFO - 2023-11-16 16:15:59 --> Utf8 Class Initialized
INFO - 2023-11-16 16:15:59 --> URI Class Initialized
DEBUG - 2023-11-16 16:15:59 --> No URI present. Default controller set.
INFO - 2023-11-16 16:15:59 --> Router Class Initialized
INFO - 2023-11-16 16:15:59 --> Output Class Initialized
INFO - 2023-11-16 16:15:59 --> Security Class Initialized
DEBUG - 2023-11-16 16:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-16 16:15:59 --> Input Class Initialized
INFO - 2023-11-16 16:15:59 --> Language Class Initialized
INFO - 2023-11-16 16:15:59 --> Loader Class Initialized
INFO - 2023-11-16 16:15:59 --> Helper loaded: url_helper
INFO - 2023-11-16 16:15:59 --> Helper loaded: form_helper
INFO - 2023-11-16 16:15:59 --> Helper loaded: file_helper
INFO - 2023-11-16 16:15:59 --> Database Driver Class Initialized
DEBUG - 2023-11-16 16:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-16 16:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-16 16:15:59 --> Form Validation Class Initialized
INFO - 2023-11-16 16:15:59 --> Upload Class Initialized
INFO - 2023-11-16 16:15:59 --> Model "M_auth" initialized
INFO - 2023-11-16 16:15:59 --> Model "M_user" initialized
INFO - 2023-11-16 16:15:59 --> Model "M_produk" initialized
INFO - 2023-11-16 16:15:59 --> Controller Class Initialized
INFO - 2023-11-16 16:15:59 --> Model "M_pelanggan" initialized
INFO - 2023-11-16 16:15:59 --> Model "M_produk" initialized
DEBUG - 2023-11-16 16:15:59 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-16 16:15:59 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-16 16:15:59 --> Model "M_transaksi" initialized
INFO - 2023-11-16 16:15:59 --> Model "M_bank" initialized
INFO - 2023-11-16 16:15:59 --> Model "M_pesan" initialized
DEBUG - 2023-11-16 16:15:59 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-16 16:15:59 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-16 16:15:59 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-16 16:15:59 --> Final output sent to browser
DEBUG - 2023-11-16 16:15:59 --> Total execution time: 0.0082
ERROR - 2023-11-16 16:17:04 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-16 16:17:04 --> Config Class Initialized
INFO - 2023-11-16 16:17:04 --> Hooks Class Initialized
DEBUG - 2023-11-16 16:17:04 --> UTF-8 Support Enabled
INFO - 2023-11-16 16:17:04 --> Utf8 Class Initialized
INFO - 2023-11-16 16:17:04 --> URI Class Initialized
DEBUG - 2023-11-16 16:17:04 --> No URI present. Default controller set.
INFO - 2023-11-16 16:17:04 --> Router Class Initialized
INFO - 2023-11-16 16:17:04 --> Output Class Initialized
INFO - 2023-11-16 16:17:04 --> Security Class Initialized
DEBUG - 2023-11-16 16:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-16 16:17:04 --> Input Class Initialized
INFO - 2023-11-16 16:17:04 --> Language Class Initialized
INFO - 2023-11-16 16:17:04 --> Loader Class Initialized
INFO - 2023-11-16 16:17:04 --> Helper loaded: url_helper
INFO - 2023-11-16 16:17:04 --> Helper loaded: form_helper
INFO - 2023-11-16 16:17:04 --> Helper loaded: file_helper
INFO - 2023-11-16 16:17:04 --> Database Driver Class Initialized
DEBUG - 2023-11-16 16:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-16 16:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-16 16:17:04 --> Form Validation Class Initialized
INFO - 2023-11-16 16:17:04 --> Upload Class Initialized
INFO - 2023-11-16 16:17:04 --> Model "M_auth" initialized
INFO - 2023-11-16 16:17:04 --> Model "M_user" initialized
INFO - 2023-11-16 16:17:04 --> Model "M_produk" initialized
INFO - 2023-11-16 16:17:04 --> Controller Class Initialized
INFO - 2023-11-16 16:17:04 --> Model "M_pelanggan" initialized
INFO - 2023-11-16 16:17:04 --> Model "M_produk" initialized
DEBUG - 2023-11-16 16:17:04 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-16 16:17:04 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-16 16:17:04 --> Model "M_transaksi" initialized
INFO - 2023-11-16 16:17:04 --> Model "M_bank" initialized
INFO - 2023-11-16 16:17:04 --> Model "M_pesan" initialized
DEBUG - 2023-11-16 16:17:04 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-16 16:17:04 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-16 16:17:04 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-16 16:17:04 --> Final output sent to browser
DEBUG - 2023-11-16 16:17:04 --> Total execution time: 0.0046
ERROR - 2023-11-16 17:40:48 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-16 17:40:48 --> Config Class Initialized
INFO - 2023-11-16 17:40:48 --> Hooks Class Initialized
DEBUG - 2023-11-16 17:40:48 --> UTF-8 Support Enabled
INFO - 2023-11-16 17:40:48 --> Utf8 Class Initialized
INFO - 2023-11-16 17:40:48 --> URI Class Initialized
DEBUG - 2023-11-16 17:40:48 --> No URI present. Default controller set.
INFO - 2023-11-16 17:40:48 --> Router Class Initialized
INFO - 2023-11-16 17:40:48 --> Output Class Initialized
INFO - 2023-11-16 17:40:48 --> Security Class Initialized
DEBUG - 2023-11-16 17:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-16 17:40:48 --> Input Class Initialized
INFO - 2023-11-16 17:40:48 --> Language Class Initialized
INFO - 2023-11-16 17:40:48 --> Loader Class Initialized
INFO - 2023-11-16 17:40:48 --> Helper loaded: url_helper
INFO - 2023-11-16 17:40:48 --> Helper loaded: form_helper
INFO - 2023-11-16 17:40:48 --> Helper loaded: file_helper
INFO - 2023-11-16 17:40:48 --> Database Driver Class Initialized
DEBUG - 2023-11-16 17:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-16 17:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-16 17:40:48 --> Form Validation Class Initialized
INFO - 2023-11-16 17:40:48 --> Upload Class Initialized
INFO - 2023-11-16 17:40:48 --> Model "M_auth" initialized
INFO - 2023-11-16 17:40:48 --> Model "M_user" initialized
INFO - 2023-11-16 17:40:48 --> Model "M_produk" initialized
INFO - 2023-11-16 17:40:48 --> Controller Class Initialized
INFO - 2023-11-16 17:40:48 --> Model "M_pelanggan" initialized
INFO - 2023-11-16 17:40:48 --> Model "M_produk" initialized
DEBUG - 2023-11-16 17:40:48 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-16 17:40:48 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-16 17:40:48 --> Model "M_transaksi" initialized
INFO - 2023-11-16 17:40:48 --> Model "M_bank" initialized
INFO - 2023-11-16 17:40:48 --> Model "M_pesan" initialized
DEBUG - 2023-11-16 17:40:48 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-16 17:40:48 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-16 17:40:48 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-16 17:40:48 --> Final output sent to browser
DEBUG - 2023-11-16 17:40:48 --> Total execution time: 0.0328
ERROR - 2023-11-16 19:11:33 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-16 19:11:33 --> Config Class Initialized
INFO - 2023-11-16 19:11:33 --> Hooks Class Initialized
DEBUG - 2023-11-16 19:11:33 --> UTF-8 Support Enabled
INFO - 2023-11-16 19:11:33 --> Utf8 Class Initialized
INFO - 2023-11-16 19:11:33 --> URI Class Initialized
DEBUG - 2023-11-16 19:11:33 --> No URI present. Default controller set.
INFO - 2023-11-16 19:11:33 --> Router Class Initialized
INFO - 2023-11-16 19:11:33 --> Output Class Initialized
INFO - 2023-11-16 19:11:33 --> Security Class Initialized
DEBUG - 2023-11-16 19:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-16 19:11:33 --> Input Class Initialized
INFO - 2023-11-16 19:11:33 --> Language Class Initialized
INFO - 2023-11-16 19:11:33 --> Loader Class Initialized
INFO - 2023-11-16 19:11:33 --> Helper loaded: url_helper
INFO - 2023-11-16 19:11:33 --> Helper loaded: form_helper
INFO - 2023-11-16 19:11:33 --> Helper loaded: file_helper
INFO - 2023-11-16 19:11:33 --> Database Driver Class Initialized
DEBUG - 2023-11-16 19:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-16 19:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-16 19:11:33 --> Form Validation Class Initialized
INFO - 2023-11-16 19:11:33 --> Upload Class Initialized
INFO - 2023-11-16 19:11:33 --> Model "M_auth" initialized
INFO - 2023-11-16 19:11:33 --> Model "M_user" initialized
INFO - 2023-11-16 19:11:33 --> Model "M_produk" initialized
INFO - 2023-11-16 19:11:33 --> Controller Class Initialized
INFO - 2023-11-16 19:11:33 --> Model "M_pelanggan" initialized
INFO - 2023-11-16 19:11:33 --> Model "M_produk" initialized
DEBUG - 2023-11-16 19:11:33 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-16 19:11:33 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-16 19:11:33 --> Model "M_transaksi" initialized
INFO - 2023-11-16 19:11:33 --> Model "M_bank" initialized
INFO - 2023-11-16 19:11:33 --> Model "M_pesan" initialized
DEBUG - 2023-11-16 19:11:33 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-16 19:11:33 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-16 19:11:33 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-16 19:11:33 --> Final output sent to browser
DEBUG - 2023-11-16 19:11:33 --> Total execution time: 0.0349
ERROR - 2023-11-16 19:24:15 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-16 19:24:15 --> Config Class Initialized
INFO - 2023-11-16 19:24:15 --> Hooks Class Initialized
DEBUG - 2023-11-16 19:24:15 --> UTF-8 Support Enabled
INFO - 2023-11-16 19:24:15 --> Utf8 Class Initialized
INFO - 2023-11-16 19:24:15 --> URI Class Initialized
INFO - 2023-11-16 19:24:15 --> Router Class Initialized
INFO - 2023-11-16 19:24:15 --> Output Class Initialized
INFO - 2023-11-16 19:24:15 --> Security Class Initialized
DEBUG - 2023-11-16 19:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-16 19:24:15 --> Input Class Initialized
INFO - 2023-11-16 19:24:15 --> Language Class Initialized
INFO - 2023-11-16 19:24:15 --> Loader Class Initialized
INFO - 2023-11-16 19:24:15 --> Helper loaded: url_helper
INFO - 2023-11-16 19:24:15 --> Helper loaded: form_helper
INFO - 2023-11-16 19:24:15 --> Helper loaded: file_helper
INFO - 2023-11-16 19:24:15 --> Database Driver Class Initialized
DEBUG - 2023-11-16 19:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-16 19:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-16 19:24:15 --> Form Validation Class Initialized
INFO - 2023-11-16 19:24:15 --> Upload Class Initialized
INFO - 2023-11-16 19:24:15 --> Model "M_auth" initialized
INFO - 2023-11-16 19:24:15 --> Model "M_user" initialized
INFO - 2023-11-16 19:24:15 --> Model "M_produk" initialized
INFO - 2023-11-16 19:24:15 --> Controller Class Initialized
INFO - 2023-11-16 19:24:15 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-16 19:24:15 --> Final output sent to browser
DEBUG - 2023-11-16 19:24:15 --> Total execution time: 0.0263
ERROR - 2023-11-16 19:24:21 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-16 19:24:21 --> Config Class Initialized
INFO - 2023-11-16 19:24:21 --> Hooks Class Initialized
DEBUG - 2023-11-16 19:24:21 --> UTF-8 Support Enabled
INFO - 2023-11-16 19:24:21 --> Utf8 Class Initialized
INFO - 2023-11-16 19:24:21 --> URI Class Initialized
DEBUG - 2023-11-16 19:24:21 --> No URI present. Default controller set.
INFO - 2023-11-16 19:24:21 --> Router Class Initialized
INFO - 2023-11-16 19:24:21 --> Output Class Initialized
INFO - 2023-11-16 19:24:21 --> Security Class Initialized
DEBUG - 2023-11-16 19:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-16 19:24:21 --> Input Class Initialized
INFO - 2023-11-16 19:24:21 --> Language Class Initialized
INFO - 2023-11-16 19:24:21 --> Loader Class Initialized
INFO - 2023-11-16 19:24:21 --> Helper loaded: url_helper
INFO - 2023-11-16 19:24:21 --> Helper loaded: form_helper
INFO - 2023-11-16 19:24:21 --> Helper loaded: file_helper
INFO - 2023-11-16 19:24:21 --> Database Driver Class Initialized
DEBUG - 2023-11-16 19:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-16 19:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-16 19:24:21 --> Form Validation Class Initialized
INFO - 2023-11-16 19:24:21 --> Upload Class Initialized
INFO - 2023-11-16 19:24:21 --> Model "M_auth" initialized
INFO - 2023-11-16 19:24:21 --> Model "M_user" initialized
INFO - 2023-11-16 19:24:21 --> Model "M_produk" initialized
INFO - 2023-11-16 19:24:21 --> Controller Class Initialized
INFO - 2023-11-16 19:24:21 --> Model "M_pelanggan" initialized
INFO - 2023-11-16 19:24:21 --> Model "M_produk" initialized
DEBUG - 2023-11-16 19:24:21 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-16 19:24:21 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-16 19:24:21 --> Model "M_transaksi" initialized
INFO - 2023-11-16 19:24:21 --> Model "M_bank" initialized
INFO - 2023-11-16 19:24:21 --> Model "M_pesan" initialized
DEBUG - 2023-11-16 19:24:21 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-16 19:24:21 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-16 19:24:21 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-16 19:24:21 --> Final output sent to browser
DEBUG - 2023-11-16 19:24:21 --> Total execution time: 0.0081
ERROR - 2023-11-16 19:24:41 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-16 19:24:41 --> Config Class Initialized
INFO - 2023-11-16 19:24:41 --> Hooks Class Initialized
DEBUG - 2023-11-16 19:24:41 --> UTF-8 Support Enabled
INFO - 2023-11-16 19:24:41 --> Utf8 Class Initialized
INFO - 2023-11-16 19:24:41 --> URI Class Initialized
DEBUG - 2023-11-16 19:24:41 --> No URI present. Default controller set.
INFO - 2023-11-16 19:24:41 --> Router Class Initialized
INFO - 2023-11-16 19:24:41 --> Output Class Initialized
INFO - 2023-11-16 19:24:41 --> Security Class Initialized
DEBUG - 2023-11-16 19:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-16 19:24:41 --> Input Class Initialized
INFO - 2023-11-16 19:24:41 --> Language Class Initialized
INFO - 2023-11-16 19:24:41 --> Loader Class Initialized
INFO - 2023-11-16 19:24:41 --> Helper loaded: url_helper
INFO - 2023-11-16 19:24:41 --> Helper loaded: form_helper
INFO - 2023-11-16 19:24:41 --> Helper loaded: file_helper
INFO - 2023-11-16 19:24:41 --> Database Driver Class Initialized
DEBUG - 2023-11-16 19:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-16 19:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-16 19:24:41 --> Form Validation Class Initialized
INFO - 2023-11-16 19:24:41 --> Upload Class Initialized
INFO - 2023-11-16 19:24:41 --> Model "M_auth" initialized
INFO - 2023-11-16 19:24:41 --> Model "M_user" initialized
INFO - 2023-11-16 19:24:41 --> Model "M_produk" initialized
INFO - 2023-11-16 19:24:41 --> Controller Class Initialized
INFO - 2023-11-16 19:24:41 --> Model "M_pelanggan" initialized
INFO - 2023-11-16 19:24:41 --> Model "M_produk" initialized
DEBUG - 2023-11-16 19:24:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-16 19:24:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-16 19:24:41 --> Model "M_transaksi" initialized
INFO - 2023-11-16 19:24:41 --> Model "M_bank" initialized
INFO - 2023-11-16 19:24:41 --> Model "M_pesan" initialized
DEBUG - 2023-11-16 19:24:41 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-16 19:24:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-16 19:24:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-16 19:24:41 --> Final output sent to browser
DEBUG - 2023-11-16 19:24:41 --> Total execution time: 0.0038
