<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-25 02:15:48 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-25 02:15:48 --> Config Class Initialized
INFO - 2023-11-25 02:15:48 --> Hooks Class Initialized
DEBUG - 2023-11-25 02:15:48 --> UTF-8 Support Enabled
INFO - 2023-11-25 02:15:48 --> Utf8 Class Initialized
INFO - 2023-11-25 02:15:48 --> URI Class Initialized
DEBUG - 2023-11-25 02:15:48 --> No URI present. Default controller set.
INFO - 2023-11-25 02:15:48 --> Router Class Initialized
INFO - 2023-11-25 02:15:48 --> Output Class Initialized
INFO - 2023-11-25 02:15:48 --> Security Class Initialized
DEBUG - 2023-11-25 02:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 02:15:48 --> Input Class Initialized
INFO - 2023-11-25 02:15:48 --> Language Class Initialized
INFO - 2023-11-25 02:15:48 --> Loader Class Initialized
INFO - 2023-11-25 02:15:48 --> Helper loaded: url_helper
INFO - 2023-11-25 02:15:48 --> Helper loaded: form_helper
INFO - 2023-11-25 02:15:48 --> Helper loaded: file_helper
INFO - 2023-11-25 02:15:48 --> Database Driver Class Initialized
DEBUG - 2023-11-25 02:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-25 02:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-25 02:15:48 --> Form Validation Class Initialized
INFO - 2023-11-25 02:15:48 --> Upload Class Initialized
INFO - 2023-11-25 02:15:48 --> Model "M_auth" initialized
INFO - 2023-11-25 02:15:48 --> Model "M_user" initialized
INFO - 2023-11-25 02:15:48 --> Model "M_produk" initialized
INFO - 2023-11-25 02:15:48 --> Controller Class Initialized
INFO - 2023-11-25 02:15:48 --> Model "M_pelanggan" initialized
INFO - 2023-11-25 02:15:48 --> Model "M_produk" initialized
DEBUG - 2023-11-25 02:15:48 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-25 02:15:48 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-25 02:15:48 --> Model "M_transaksi" initialized
INFO - 2023-11-25 02:15:48 --> Model "M_bank" initialized
INFO - 2023-11-25 02:15:48 --> Model "M_pesan" initialized
DEBUG - 2023-11-25 02:15:48 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-25 02:15:48 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-25 02:15:48 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-25 02:15:48 --> Final output sent to browser
DEBUG - 2023-11-25 02:15:48 --> Total execution time: 0.0367
ERROR - 2023-11-25 03:18:12 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-25 03:18:12 --> Config Class Initialized
INFO - 2023-11-25 03:18:12 --> Hooks Class Initialized
DEBUG - 2023-11-25 03:18:12 --> UTF-8 Support Enabled
INFO - 2023-11-25 03:18:12 --> Utf8 Class Initialized
INFO - 2023-11-25 03:18:12 --> URI Class Initialized
DEBUG - 2023-11-25 03:18:12 --> No URI present. Default controller set.
INFO - 2023-11-25 03:18:12 --> Router Class Initialized
INFO - 2023-11-25 03:18:12 --> Output Class Initialized
INFO - 2023-11-25 03:18:12 --> Security Class Initialized
DEBUG - 2023-11-25 03:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 03:18:12 --> Input Class Initialized
INFO - 2023-11-25 03:18:12 --> Language Class Initialized
INFO - 2023-11-25 03:18:12 --> Loader Class Initialized
INFO - 2023-11-25 03:18:12 --> Helper loaded: url_helper
INFO - 2023-11-25 03:18:12 --> Helper loaded: form_helper
INFO - 2023-11-25 03:18:12 --> Helper loaded: file_helper
INFO - 2023-11-25 03:18:12 --> Database Driver Class Initialized
DEBUG - 2023-11-25 03:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-25 03:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-25 03:18:12 --> Form Validation Class Initialized
INFO - 2023-11-25 03:18:12 --> Upload Class Initialized
INFO - 2023-11-25 03:18:12 --> Model "M_auth" initialized
INFO - 2023-11-25 03:18:12 --> Model "M_user" initialized
INFO - 2023-11-25 03:18:12 --> Model "M_produk" initialized
INFO - 2023-11-25 03:18:12 --> Controller Class Initialized
INFO - 2023-11-25 03:18:12 --> Model "M_pelanggan" initialized
INFO - 2023-11-25 03:18:12 --> Model "M_produk" initialized
DEBUG - 2023-11-25 03:18:12 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-25 03:18:12 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-25 03:18:12 --> Model "M_transaksi" initialized
INFO - 2023-11-25 03:18:12 --> Model "M_bank" initialized
INFO - 2023-11-25 03:18:12 --> Model "M_pesan" initialized
DEBUG - 2023-11-25 03:18:12 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-25 03:18:12 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-25 03:18:12 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-25 03:18:12 --> Final output sent to browser
DEBUG - 2023-11-25 03:18:12 --> Total execution time: 0.0345
ERROR - 2023-11-25 04:33:25 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-25 04:33:25 --> Config Class Initialized
INFO - 2023-11-25 04:33:25 --> Hooks Class Initialized
DEBUG - 2023-11-25 04:33:25 --> UTF-8 Support Enabled
INFO - 2023-11-25 04:33:25 --> Utf8 Class Initialized
INFO - 2023-11-25 04:33:25 --> URI Class Initialized
DEBUG - 2023-11-25 04:33:25 --> No URI present. Default controller set.
INFO - 2023-11-25 04:33:25 --> Router Class Initialized
INFO - 2023-11-25 04:33:25 --> Output Class Initialized
INFO - 2023-11-25 04:33:25 --> Security Class Initialized
DEBUG - 2023-11-25 04:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 04:33:25 --> Input Class Initialized
INFO - 2023-11-25 04:33:25 --> Language Class Initialized
INFO - 2023-11-25 04:33:25 --> Loader Class Initialized
INFO - 2023-11-25 04:33:25 --> Helper loaded: url_helper
INFO - 2023-11-25 04:33:25 --> Helper loaded: form_helper
INFO - 2023-11-25 04:33:25 --> Helper loaded: file_helper
INFO - 2023-11-25 04:33:25 --> Database Driver Class Initialized
DEBUG - 2023-11-25 04:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-25 04:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-25 04:33:25 --> Form Validation Class Initialized
INFO - 2023-11-25 04:33:25 --> Upload Class Initialized
INFO - 2023-11-25 04:33:25 --> Model "M_auth" initialized
INFO - 2023-11-25 04:33:25 --> Model "M_user" initialized
INFO - 2023-11-25 04:33:25 --> Model "M_produk" initialized
INFO - 2023-11-25 04:33:25 --> Controller Class Initialized
INFO - 2023-11-25 04:33:25 --> Model "M_pelanggan" initialized
INFO - 2023-11-25 04:33:25 --> Model "M_produk" initialized
DEBUG - 2023-11-25 04:33:25 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-25 04:33:25 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-25 04:33:25 --> Model "M_transaksi" initialized
INFO - 2023-11-25 04:33:25 --> Model "M_bank" initialized
INFO - 2023-11-25 04:33:25 --> Model "M_pesan" initialized
DEBUG - 2023-11-25 04:33:25 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-25 04:33:25 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-25 04:33:25 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-25 04:33:25 --> Final output sent to browser
DEBUG - 2023-11-25 04:33:25 --> Total execution time: 0.0310
ERROR - 2023-11-25 06:00:22 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-25 06:00:22 --> Config Class Initialized
INFO - 2023-11-25 06:00:22 --> Hooks Class Initialized
DEBUG - 2023-11-25 06:00:22 --> UTF-8 Support Enabled
INFO - 2023-11-25 06:00:22 --> Utf8 Class Initialized
INFO - 2023-11-25 06:00:22 --> URI Class Initialized
INFO - 2023-11-25 06:00:22 --> Router Class Initialized
INFO - 2023-11-25 06:00:22 --> Output Class Initialized
INFO - 2023-11-25 06:00:22 --> Security Class Initialized
DEBUG - 2023-11-25 06:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 06:00:22 --> Input Class Initialized
INFO - 2023-11-25 06:00:22 --> Language Class Initialized
INFO - 2023-11-25 06:00:22 --> Loader Class Initialized
INFO - 2023-11-25 06:00:22 --> Helper loaded: url_helper
INFO - 2023-11-25 06:00:22 --> Helper loaded: form_helper
INFO - 2023-11-25 06:00:22 --> Helper loaded: file_helper
INFO - 2023-11-25 06:00:22 --> Database Driver Class Initialized
DEBUG - 2023-11-25 06:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-25 06:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-25 06:00:22 --> Form Validation Class Initialized
INFO - 2023-11-25 06:00:22 --> Upload Class Initialized
INFO - 2023-11-25 06:00:22 --> Model "M_auth" initialized
INFO - 2023-11-25 06:00:22 --> Model "M_user" initialized
INFO - 2023-11-25 06:00:22 --> Model "M_produk" initialized
INFO - 2023-11-25 06:00:22 --> Controller Class Initialized
INFO - 2023-11-25 06:00:22 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-25 06:00:22 --> Final output sent to browser
DEBUG - 2023-11-25 06:00:22 --> Total execution time: 0.0257
ERROR - 2023-11-25 06:00:24 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-25 06:00:24 --> Config Class Initialized
INFO - 2023-11-25 06:00:24 --> Hooks Class Initialized
DEBUG - 2023-11-25 06:00:24 --> UTF-8 Support Enabled
INFO - 2023-11-25 06:00:24 --> Utf8 Class Initialized
INFO - 2023-11-25 06:00:24 --> URI Class Initialized
DEBUG - 2023-11-25 06:00:24 --> No URI present. Default controller set.
INFO - 2023-11-25 06:00:24 --> Router Class Initialized
INFO - 2023-11-25 06:00:24 --> Output Class Initialized
INFO - 2023-11-25 06:00:24 --> Security Class Initialized
DEBUG - 2023-11-25 06:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 06:00:24 --> Input Class Initialized
INFO - 2023-11-25 06:00:24 --> Language Class Initialized
INFO - 2023-11-25 06:00:24 --> Loader Class Initialized
INFO - 2023-11-25 06:00:24 --> Helper loaded: url_helper
INFO - 2023-11-25 06:00:24 --> Helper loaded: form_helper
INFO - 2023-11-25 06:00:24 --> Helper loaded: file_helper
INFO - 2023-11-25 06:00:24 --> Database Driver Class Initialized
DEBUG - 2023-11-25 06:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-25 06:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-25 06:00:24 --> Form Validation Class Initialized
INFO - 2023-11-25 06:00:24 --> Upload Class Initialized
INFO - 2023-11-25 06:00:24 --> Model "M_auth" initialized
INFO - 2023-11-25 06:00:24 --> Model "M_user" initialized
INFO - 2023-11-25 06:00:24 --> Model "M_produk" initialized
INFO - 2023-11-25 06:00:24 --> Controller Class Initialized
INFO - 2023-11-25 06:00:24 --> Model "M_pelanggan" initialized
INFO - 2023-11-25 06:00:24 --> Model "M_produk" initialized
DEBUG - 2023-11-25 06:00:24 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-25 06:00:24 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-25 06:00:24 --> Model "M_transaksi" initialized
INFO - 2023-11-25 06:00:24 --> Model "M_bank" initialized
INFO - 2023-11-25 06:00:24 --> Model "M_pesan" initialized
DEBUG - 2023-11-25 06:00:24 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-25 06:00:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-25 06:00:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-25 06:00:24 --> Final output sent to browser
DEBUG - 2023-11-25 06:00:24 --> Total execution time: 0.0096
ERROR - 2023-11-25 08:38:12 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-25 08:38:12 --> Config Class Initialized
INFO - 2023-11-25 08:38:12 --> Hooks Class Initialized
DEBUG - 2023-11-25 08:38:12 --> UTF-8 Support Enabled
INFO - 2023-11-25 08:38:12 --> Utf8 Class Initialized
INFO - 2023-11-25 08:38:12 --> URI Class Initialized
DEBUG - 2023-11-25 08:38:12 --> No URI present. Default controller set.
INFO - 2023-11-25 08:38:12 --> Router Class Initialized
INFO - 2023-11-25 08:38:12 --> Output Class Initialized
INFO - 2023-11-25 08:38:12 --> Security Class Initialized
DEBUG - 2023-11-25 08:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 08:38:12 --> Input Class Initialized
INFO - 2023-11-25 08:38:12 --> Language Class Initialized
INFO - 2023-11-25 08:38:12 --> Loader Class Initialized
INFO - 2023-11-25 08:38:12 --> Helper loaded: url_helper
INFO - 2023-11-25 08:38:12 --> Helper loaded: form_helper
INFO - 2023-11-25 08:38:12 --> Helper loaded: file_helper
INFO - 2023-11-25 08:38:12 --> Database Driver Class Initialized
DEBUG - 2023-11-25 08:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-25 08:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-25 08:38:12 --> Form Validation Class Initialized
INFO - 2023-11-25 08:38:12 --> Upload Class Initialized
INFO - 2023-11-25 08:38:12 --> Model "M_auth" initialized
INFO - 2023-11-25 08:38:12 --> Model "M_user" initialized
INFO - 2023-11-25 08:38:12 --> Model "M_produk" initialized
INFO - 2023-11-25 08:38:12 --> Controller Class Initialized
INFO - 2023-11-25 08:38:12 --> Model "M_pelanggan" initialized
INFO - 2023-11-25 08:38:12 --> Model "M_produk" initialized
DEBUG - 2023-11-25 08:38:12 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-25 08:38:12 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-25 08:38:12 --> Model "M_transaksi" initialized
INFO - 2023-11-25 08:38:12 --> Model "M_bank" initialized
INFO - 2023-11-25 08:38:12 --> Model "M_pesan" initialized
DEBUG - 2023-11-25 08:38:12 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-25 08:38:12 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-25 08:38:12 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-25 08:38:12 --> Final output sent to browser
DEBUG - 2023-11-25 08:38:12 --> Total execution time: 0.0302
ERROR - 2023-11-25 09:40:41 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-25 09:40:41 --> Config Class Initialized
INFO - 2023-11-25 09:40:41 --> Hooks Class Initialized
DEBUG - 2023-11-25 09:40:41 --> UTF-8 Support Enabled
INFO - 2023-11-25 09:40:41 --> Utf8 Class Initialized
INFO - 2023-11-25 09:40:41 --> URI Class Initialized
DEBUG - 2023-11-25 09:40:41 --> No URI present. Default controller set.
INFO - 2023-11-25 09:40:41 --> Router Class Initialized
INFO - 2023-11-25 09:40:41 --> Output Class Initialized
INFO - 2023-11-25 09:40:41 --> Security Class Initialized
DEBUG - 2023-11-25 09:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 09:40:41 --> Input Class Initialized
INFO - 2023-11-25 09:40:41 --> Language Class Initialized
INFO - 2023-11-25 09:40:41 --> Loader Class Initialized
INFO - 2023-11-25 09:40:41 --> Helper loaded: url_helper
INFO - 2023-11-25 09:40:41 --> Helper loaded: form_helper
INFO - 2023-11-25 09:40:41 --> Helper loaded: file_helper
INFO - 2023-11-25 09:40:41 --> Database Driver Class Initialized
DEBUG - 2023-11-25 09:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-25 09:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-25 09:40:41 --> Form Validation Class Initialized
INFO - 2023-11-25 09:40:41 --> Upload Class Initialized
INFO - 2023-11-25 09:40:41 --> Model "M_auth" initialized
INFO - 2023-11-25 09:40:41 --> Model "M_user" initialized
INFO - 2023-11-25 09:40:41 --> Model "M_produk" initialized
INFO - 2023-11-25 09:40:41 --> Controller Class Initialized
INFO - 2023-11-25 09:40:41 --> Model "M_pelanggan" initialized
INFO - 2023-11-25 09:40:41 --> Model "M_produk" initialized
DEBUG - 2023-11-25 09:40:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-25 09:40:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-25 09:40:41 --> Model "M_transaksi" initialized
INFO - 2023-11-25 09:40:41 --> Model "M_bank" initialized
INFO - 2023-11-25 09:40:41 --> Model "M_pesan" initialized
DEBUG - 2023-11-25 09:40:41 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-25 09:40:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-25 09:40:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-25 09:40:41 --> Final output sent to browser
DEBUG - 2023-11-25 09:40:41 --> Total execution time: 0.0313
ERROR - 2023-11-25 10:06:33 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-25 10:06:33 --> Config Class Initialized
INFO - 2023-11-25 10:06:33 --> Hooks Class Initialized
DEBUG - 2023-11-25 10:06:33 --> UTF-8 Support Enabled
INFO - 2023-11-25 10:06:33 --> Utf8 Class Initialized
INFO - 2023-11-25 10:06:33 --> URI Class Initialized
DEBUG - 2023-11-25 10:06:33 --> No URI present. Default controller set.
INFO - 2023-11-25 10:06:33 --> Router Class Initialized
INFO - 2023-11-25 10:06:33 --> Output Class Initialized
INFO - 2023-11-25 10:06:33 --> Security Class Initialized
DEBUG - 2023-11-25 10:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 10:06:33 --> Input Class Initialized
INFO - 2023-11-25 10:06:33 --> Language Class Initialized
INFO - 2023-11-25 10:06:33 --> Loader Class Initialized
INFO - 2023-11-25 10:06:33 --> Helper loaded: url_helper
INFO - 2023-11-25 10:06:33 --> Helper loaded: form_helper
INFO - 2023-11-25 10:06:33 --> Helper loaded: file_helper
INFO - 2023-11-25 10:06:33 --> Database Driver Class Initialized
DEBUG - 2023-11-25 10:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-25 10:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-25 10:06:33 --> Form Validation Class Initialized
INFO - 2023-11-25 10:06:33 --> Upload Class Initialized
INFO - 2023-11-25 10:06:33 --> Model "M_auth" initialized
INFO - 2023-11-25 10:06:33 --> Model "M_user" initialized
INFO - 2023-11-25 10:06:33 --> Model "M_produk" initialized
INFO - 2023-11-25 10:06:33 --> Controller Class Initialized
INFO - 2023-11-25 10:06:33 --> Model "M_pelanggan" initialized
INFO - 2023-11-25 10:06:33 --> Model "M_produk" initialized
DEBUG - 2023-11-25 10:06:33 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-25 10:06:33 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-25 10:06:33 --> Model "M_transaksi" initialized
INFO - 2023-11-25 10:06:33 --> Model "M_bank" initialized
INFO - 2023-11-25 10:06:33 --> Model "M_pesan" initialized
DEBUG - 2023-11-25 10:06:33 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-25 10:06:33 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-25 10:06:33 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-25 10:06:33 --> Final output sent to browser
DEBUG - 2023-11-25 10:06:33 --> Total execution time: 0.0310
ERROR - 2023-11-25 14:46:34 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-25 14:46:34 --> Config Class Initialized
INFO - 2023-11-25 14:46:34 --> Hooks Class Initialized
DEBUG - 2023-11-25 14:46:34 --> UTF-8 Support Enabled
INFO - 2023-11-25 14:46:34 --> Utf8 Class Initialized
INFO - 2023-11-25 14:46:34 --> URI Class Initialized
INFO - 2023-11-25 14:46:34 --> Router Class Initialized
INFO - 2023-11-25 14:46:34 --> Output Class Initialized
INFO - 2023-11-25 14:46:34 --> Security Class Initialized
DEBUG - 2023-11-25 14:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 14:46:34 --> Input Class Initialized
INFO - 2023-11-25 14:46:34 --> Language Class Initialized
INFO - 2023-11-25 14:46:34 --> Loader Class Initialized
INFO - 2023-11-25 14:46:34 --> Helper loaded: url_helper
INFO - 2023-11-25 14:46:34 --> Helper loaded: form_helper
INFO - 2023-11-25 14:46:34 --> Helper loaded: file_helper
INFO - 2023-11-25 14:46:34 --> Database Driver Class Initialized
DEBUG - 2023-11-25 14:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-25 14:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-25 14:46:34 --> Form Validation Class Initialized
INFO - 2023-11-25 14:46:34 --> Upload Class Initialized
INFO - 2023-11-25 14:46:34 --> Model "M_auth" initialized
INFO - 2023-11-25 14:46:34 --> Model "M_user" initialized
INFO - 2023-11-25 14:46:34 --> Model "M_produk" initialized
INFO - 2023-11-25 14:46:34 --> Controller Class Initialized
INFO - 2023-11-25 14:46:34 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-25 14:46:34 --> Final output sent to browser
DEBUG - 2023-11-25 14:46:34 --> Total execution time: 0.0246
ERROR - 2023-11-25 14:46:36 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-25 14:46:36 --> Config Class Initialized
INFO - 2023-11-25 14:46:36 --> Hooks Class Initialized
DEBUG - 2023-11-25 14:46:36 --> UTF-8 Support Enabled
INFO - 2023-11-25 14:46:36 --> Utf8 Class Initialized
INFO - 2023-11-25 14:46:36 --> URI Class Initialized
DEBUG - 2023-11-25 14:46:36 --> No URI present. Default controller set.
INFO - 2023-11-25 14:46:36 --> Router Class Initialized
INFO - 2023-11-25 14:46:36 --> Output Class Initialized
INFO - 2023-11-25 14:46:36 --> Security Class Initialized
DEBUG - 2023-11-25 14:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 14:46:36 --> Input Class Initialized
INFO - 2023-11-25 14:46:36 --> Language Class Initialized
INFO - 2023-11-25 14:46:36 --> Loader Class Initialized
INFO - 2023-11-25 14:46:36 --> Helper loaded: url_helper
INFO - 2023-11-25 14:46:36 --> Helper loaded: form_helper
INFO - 2023-11-25 14:46:36 --> Helper loaded: file_helper
INFO - 2023-11-25 14:46:36 --> Database Driver Class Initialized
DEBUG - 2023-11-25 14:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-25 14:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-25 14:46:36 --> Form Validation Class Initialized
INFO - 2023-11-25 14:46:36 --> Upload Class Initialized
INFO - 2023-11-25 14:46:36 --> Model "M_auth" initialized
INFO - 2023-11-25 14:46:36 --> Model "M_user" initialized
INFO - 2023-11-25 14:46:36 --> Model "M_produk" initialized
INFO - 2023-11-25 14:46:36 --> Controller Class Initialized
INFO - 2023-11-25 14:46:36 --> Model "M_pelanggan" initialized
INFO - 2023-11-25 14:46:36 --> Model "M_produk" initialized
DEBUG - 2023-11-25 14:46:36 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-25 14:46:36 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-25 14:46:36 --> Model "M_transaksi" initialized
INFO - 2023-11-25 14:46:36 --> Model "M_bank" initialized
INFO - 2023-11-25 14:46:36 --> Model "M_pesan" initialized
DEBUG - 2023-11-25 14:46:36 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-25 14:46:36 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-25 14:46:36 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-25 14:46:36 --> Final output sent to browser
DEBUG - 2023-11-25 14:46:36 --> Total execution time: 0.0102
ERROR - 2023-11-25 18:21:09 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-25 18:21:09 --> Config Class Initialized
INFO - 2023-11-25 18:21:09 --> Hooks Class Initialized
DEBUG - 2023-11-25 18:21:09 --> UTF-8 Support Enabled
INFO - 2023-11-25 18:21:09 --> Utf8 Class Initialized
INFO - 2023-11-25 18:21:09 --> URI Class Initialized
DEBUG - 2023-11-25 18:21:09 --> No URI present. Default controller set.
INFO - 2023-11-25 18:21:09 --> Router Class Initialized
INFO - 2023-11-25 18:21:09 --> Output Class Initialized
INFO - 2023-11-25 18:21:09 --> Security Class Initialized
DEBUG - 2023-11-25 18:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 18:21:09 --> Input Class Initialized
INFO - 2023-11-25 18:21:09 --> Language Class Initialized
INFO - 2023-11-25 18:21:09 --> Loader Class Initialized
INFO - 2023-11-25 18:21:09 --> Helper loaded: url_helper
INFO - 2023-11-25 18:21:09 --> Helper loaded: form_helper
INFO - 2023-11-25 18:21:09 --> Helper loaded: file_helper
INFO - 2023-11-25 18:21:09 --> Database Driver Class Initialized
DEBUG - 2023-11-25 18:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-25 18:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-25 18:21:09 --> Form Validation Class Initialized
INFO - 2023-11-25 18:21:09 --> Upload Class Initialized
INFO - 2023-11-25 18:21:09 --> Model "M_auth" initialized
INFO - 2023-11-25 18:21:09 --> Model "M_user" initialized
INFO - 2023-11-25 18:21:09 --> Model "M_produk" initialized
INFO - 2023-11-25 18:21:09 --> Controller Class Initialized
INFO - 2023-11-25 18:21:09 --> Model "M_pelanggan" initialized
INFO - 2023-11-25 18:21:09 --> Model "M_produk" initialized
DEBUG - 2023-11-25 18:21:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-25 18:21:09 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-25 18:21:09 --> Model "M_transaksi" initialized
INFO - 2023-11-25 18:21:09 --> Model "M_bank" initialized
INFO - 2023-11-25 18:21:09 --> Model "M_pesan" initialized
DEBUG - 2023-11-25 18:21:09 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-25 18:21:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-25 18:21:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-25 18:21:09 --> Final output sent to browser
DEBUG - 2023-11-25 18:21:09 --> Total execution time: 0.0321
ERROR - 2023-11-25 19:22:19 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-25 19:22:19 --> Config Class Initialized
INFO - 2023-11-25 19:22:19 --> Hooks Class Initialized
DEBUG - 2023-11-25 19:22:19 --> UTF-8 Support Enabled
INFO - 2023-11-25 19:22:19 --> Utf8 Class Initialized
INFO - 2023-11-25 19:22:19 --> URI Class Initialized
DEBUG - 2023-11-25 19:22:19 --> No URI present. Default controller set.
INFO - 2023-11-25 19:22:19 --> Router Class Initialized
INFO - 2023-11-25 19:22:19 --> Output Class Initialized
INFO - 2023-11-25 19:22:19 --> Security Class Initialized
DEBUG - 2023-11-25 19:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 19:22:19 --> Input Class Initialized
INFO - 2023-11-25 19:22:19 --> Language Class Initialized
INFO - 2023-11-25 19:22:19 --> Loader Class Initialized
INFO - 2023-11-25 19:22:19 --> Helper loaded: url_helper
INFO - 2023-11-25 19:22:19 --> Helper loaded: form_helper
INFO - 2023-11-25 19:22:19 --> Helper loaded: file_helper
INFO - 2023-11-25 19:22:19 --> Database Driver Class Initialized
DEBUG - 2023-11-25 19:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-25 19:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-25 19:22:19 --> Form Validation Class Initialized
INFO - 2023-11-25 19:22:19 --> Upload Class Initialized
INFO - 2023-11-25 19:22:19 --> Model "M_auth" initialized
INFO - 2023-11-25 19:22:19 --> Model "M_user" initialized
INFO - 2023-11-25 19:22:19 --> Model "M_produk" initialized
INFO - 2023-11-25 19:22:19 --> Controller Class Initialized
INFO - 2023-11-25 19:22:19 --> Model "M_pelanggan" initialized
INFO - 2023-11-25 19:22:19 --> Model "M_produk" initialized
DEBUG - 2023-11-25 19:22:19 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-25 19:22:19 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-25 19:22:19 --> Model "M_transaksi" initialized
INFO - 2023-11-25 19:22:19 --> Model "M_bank" initialized
INFO - 2023-11-25 19:22:19 --> Model "M_pesan" initialized
DEBUG - 2023-11-25 19:22:19 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-25 19:22:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-25 19:22:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-25 19:22:19 --> Final output sent to browser
DEBUG - 2023-11-25 19:22:19 --> Total execution time: 0.0334
ERROR - 2023-11-25 19:48:03 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-25 19:48:03 --> Config Class Initialized
INFO - 2023-11-25 19:48:03 --> Hooks Class Initialized
DEBUG - 2023-11-25 19:48:03 --> UTF-8 Support Enabled
INFO - 2023-11-25 19:48:03 --> Utf8 Class Initialized
INFO - 2023-11-25 19:48:03 --> URI Class Initialized
DEBUG - 2023-11-25 19:48:03 --> No URI present. Default controller set.
INFO - 2023-11-25 19:48:03 --> Router Class Initialized
INFO - 2023-11-25 19:48:03 --> Output Class Initialized
INFO - 2023-11-25 19:48:03 --> Security Class Initialized
DEBUG - 2023-11-25 19:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 19:48:03 --> Input Class Initialized
INFO - 2023-11-25 19:48:03 --> Language Class Initialized
INFO - 2023-11-25 19:48:03 --> Loader Class Initialized
INFO - 2023-11-25 19:48:03 --> Helper loaded: url_helper
INFO - 2023-11-25 19:48:03 --> Helper loaded: form_helper
INFO - 2023-11-25 19:48:03 --> Helper loaded: file_helper
INFO - 2023-11-25 19:48:03 --> Database Driver Class Initialized
DEBUG - 2023-11-25 19:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-25 19:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-25 19:48:03 --> Form Validation Class Initialized
INFO - 2023-11-25 19:48:03 --> Upload Class Initialized
INFO - 2023-11-25 19:48:03 --> Model "M_auth" initialized
INFO - 2023-11-25 19:48:03 --> Model "M_user" initialized
INFO - 2023-11-25 19:48:03 --> Model "M_produk" initialized
INFO - 2023-11-25 19:48:03 --> Controller Class Initialized
INFO - 2023-11-25 19:48:03 --> Model "M_pelanggan" initialized
INFO - 2023-11-25 19:48:03 --> Model "M_produk" initialized
DEBUG - 2023-11-25 19:48:03 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-25 19:48:03 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-25 19:48:03 --> Model "M_transaksi" initialized
INFO - 2023-11-25 19:48:03 --> Model "M_bank" initialized
INFO - 2023-11-25 19:48:03 --> Model "M_pesan" initialized
DEBUG - 2023-11-25 19:48:03 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-25 19:48:03 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-25 19:48:03 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-25 19:48:03 --> Final output sent to browser
DEBUG - 2023-11-25 19:48:03 --> Total execution time: 0.0307
ERROR - 2023-11-25 22:14:56 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-25 22:14:56 --> Config Class Initialized
INFO - 2023-11-25 22:14:56 --> Hooks Class Initialized
DEBUG - 2023-11-25 22:14:56 --> UTF-8 Support Enabled
INFO - 2023-11-25 22:14:56 --> Utf8 Class Initialized
INFO - 2023-11-25 22:14:56 --> URI Class Initialized
INFO - 2023-11-25 22:14:56 --> Router Class Initialized
INFO - 2023-11-25 22:14:56 --> Output Class Initialized
INFO - 2023-11-25 22:14:56 --> Security Class Initialized
DEBUG - 2023-11-25 22:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 22:14:56 --> Input Class Initialized
INFO - 2023-11-25 22:14:56 --> Language Class Initialized
INFO - 2023-11-25 22:14:56 --> Loader Class Initialized
INFO - 2023-11-25 22:14:56 --> Helper loaded: url_helper
INFO - 2023-11-25 22:14:56 --> Helper loaded: form_helper
INFO - 2023-11-25 22:14:56 --> Helper loaded: file_helper
INFO - 2023-11-25 22:14:56 --> Database Driver Class Initialized
DEBUG - 2023-11-25 22:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-25 22:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-25 22:14:56 --> Form Validation Class Initialized
INFO - 2023-11-25 22:14:56 --> Upload Class Initialized
INFO - 2023-11-25 22:14:56 --> Model "M_auth" initialized
INFO - 2023-11-25 22:14:56 --> Model "M_user" initialized
INFO - 2023-11-25 22:14:56 --> Model "M_produk" initialized
INFO - 2023-11-25 22:14:56 --> Controller Class Initialized
INFO - 2023-11-25 22:14:56 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-25 22:14:56 --> Final output sent to browser
DEBUG - 2023-11-25 22:14:56 --> Total execution time: 0.0251
