<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-20 01:29:14 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 01:29:14 --> Config Class Initialized
INFO - 2023-11-20 01:29:14 --> Hooks Class Initialized
DEBUG - 2023-11-20 01:29:14 --> UTF-8 Support Enabled
INFO - 2023-11-20 01:29:14 --> Utf8 Class Initialized
INFO - 2023-11-20 01:29:14 --> URI Class Initialized
DEBUG - 2023-11-20 01:29:14 --> No URI present. Default controller set.
INFO - 2023-11-20 01:29:14 --> Router Class Initialized
INFO - 2023-11-20 01:29:14 --> Output Class Initialized
INFO - 2023-11-20 01:29:14 --> Security Class Initialized
DEBUG - 2023-11-20 01:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 01:29:14 --> Input Class Initialized
INFO - 2023-11-20 01:29:14 --> Language Class Initialized
INFO - 2023-11-20 01:29:14 --> Loader Class Initialized
INFO - 2023-11-20 01:29:14 --> Helper loaded: url_helper
INFO - 2023-11-20 01:29:14 --> Helper loaded: form_helper
INFO - 2023-11-20 01:29:14 --> Helper loaded: file_helper
INFO - 2023-11-20 01:29:14 --> Database Driver Class Initialized
DEBUG - 2023-11-20 01:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 01:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 01:29:14 --> Form Validation Class Initialized
INFO - 2023-11-20 01:29:14 --> Upload Class Initialized
INFO - 2023-11-20 01:29:14 --> Model "M_auth" initialized
INFO - 2023-11-20 01:29:14 --> Model "M_user" initialized
INFO - 2023-11-20 01:29:14 --> Model "M_produk" initialized
INFO - 2023-11-20 01:29:14 --> Controller Class Initialized
INFO - 2023-11-20 01:29:14 --> Model "M_pelanggan" initialized
INFO - 2023-11-20 01:29:14 --> Model "M_produk" initialized
DEBUG - 2023-11-20 01:29:14 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-20 01:29:14 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-20 01:29:14 --> Model "M_transaksi" initialized
INFO - 2023-11-20 01:29:14 --> Model "M_bank" initialized
INFO - 2023-11-20 01:29:14 --> Model "M_pesan" initialized
DEBUG - 2023-11-20 01:29:14 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-20 01:29:14 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-20 01:29:14 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-20 01:29:14 --> Final output sent to browser
DEBUG - 2023-11-20 01:29:14 --> Total execution time: 0.0326
ERROR - 2023-11-20 01:35:32 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 01:35:32 --> Config Class Initialized
INFO - 2023-11-20 01:35:32 --> Hooks Class Initialized
DEBUG - 2023-11-20 01:35:32 --> UTF-8 Support Enabled
INFO - 2023-11-20 01:35:32 --> Utf8 Class Initialized
INFO - 2023-11-20 01:35:32 --> URI Class Initialized
INFO - 2023-11-20 01:35:32 --> Router Class Initialized
INFO - 2023-11-20 01:35:32 --> Output Class Initialized
INFO - 2023-11-20 01:35:32 --> Security Class Initialized
DEBUG - 2023-11-20 01:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 01:35:32 --> Input Class Initialized
INFO - 2023-11-20 01:35:32 --> Language Class Initialized
INFO - 2023-11-20 01:35:32 --> Loader Class Initialized
INFO - 2023-11-20 01:35:32 --> Helper loaded: url_helper
INFO - 2023-11-20 01:35:32 --> Helper loaded: form_helper
INFO - 2023-11-20 01:35:32 --> Helper loaded: file_helper
INFO - 2023-11-20 01:35:32 --> Database Driver Class Initialized
DEBUG - 2023-11-20 01:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 01:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 01:35:32 --> Form Validation Class Initialized
INFO - 2023-11-20 01:35:32 --> Upload Class Initialized
INFO - 2023-11-20 01:35:32 --> Model "M_auth" initialized
INFO - 2023-11-20 01:35:32 --> Model "M_user" initialized
INFO - 2023-11-20 01:35:32 --> Model "M_produk" initialized
INFO - 2023-11-20 01:35:32 --> Controller Class Initialized
INFO - 2023-11-20 01:35:32 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-20 01:35:32 --> Final output sent to browser
DEBUG - 2023-11-20 01:35:32 --> Total execution time: 0.0245
ERROR - 2023-11-20 01:35:32 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 01:35:32 --> Config Class Initialized
INFO - 2023-11-20 01:35:32 --> Hooks Class Initialized
DEBUG - 2023-11-20 01:35:32 --> UTF-8 Support Enabled
INFO - 2023-11-20 01:35:32 --> Utf8 Class Initialized
INFO - 2023-11-20 01:35:32 --> URI Class Initialized
INFO - 2023-11-20 01:35:32 --> Router Class Initialized
INFO - 2023-11-20 01:35:32 --> Output Class Initialized
INFO - 2023-11-20 01:35:32 --> Security Class Initialized
DEBUG - 2023-11-20 01:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 01:35:32 --> Input Class Initialized
INFO - 2023-11-20 01:35:32 --> Language Class Initialized
INFO - 2023-11-20 01:35:32 --> Loader Class Initialized
INFO - 2023-11-20 01:35:32 --> Helper loaded: url_helper
INFO - 2023-11-20 01:35:32 --> Helper loaded: form_helper
INFO - 2023-11-20 01:35:32 --> Helper loaded: file_helper
INFO - 2023-11-20 01:35:32 --> Database Driver Class Initialized
DEBUG - 2023-11-20 01:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 01:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 01:35:32 --> Form Validation Class Initialized
INFO - 2023-11-20 01:35:32 --> Upload Class Initialized
INFO - 2023-11-20 01:35:32 --> Model "M_auth" initialized
INFO - 2023-11-20 01:35:32 --> Model "M_user" initialized
INFO - 2023-11-20 01:35:32 --> Model "M_produk" initialized
INFO - 2023-11-20 01:35:32 --> Controller Class Initialized
INFO - 2023-11-20 01:35:32 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-20 01:35:32 --> Final output sent to browser
DEBUG - 2023-11-20 01:35:32 --> Total execution time: 0.0023
ERROR - 2023-11-20 02:30:07 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 02:30:07 --> Config Class Initialized
INFO - 2023-11-20 02:30:07 --> Hooks Class Initialized
DEBUG - 2023-11-20 02:30:07 --> UTF-8 Support Enabled
INFO - 2023-11-20 02:30:07 --> Utf8 Class Initialized
INFO - 2023-11-20 02:30:07 --> URI Class Initialized
DEBUG - 2023-11-20 02:30:07 --> No URI present. Default controller set.
INFO - 2023-11-20 02:30:07 --> Router Class Initialized
INFO - 2023-11-20 02:30:07 --> Output Class Initialized
INFO - 2023-11-20 02:30:07 --> Security Class Initialized
DEBUG - 2023-11-20 02:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 02:30:07 --> Input Class Initialized
INFO - 2023-11-20 02:30:07 --> Language Class Initialized
INFO - 2023-11-20 02:30:07 --> Loader Class Initialized
INFO - 2023-11-20 02:30:07 --> Helper loaded: url_helper
INFO - 2023-11-20 02:30:07 --> Helper loaded: form_helper
INFO - 2023-11-20 02:30:07 --> Helper loaded: file_helper
INFO - 2023-11-20 02:30:07 --> Database Driver Class Initialized
DEBUG - 2023-11-20 02:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 02:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 02:30:07 --> Form Validation Class Initialized
INFO - 2023-11-20 02:30:07 --> Upload Class Initialized
INFO - 2023-11-20 02:30:07 --> Model "M_auth" initialized
INFO - 2023-11-20 02:30:07 --> Model "M_user" initialized
INFO - 2023-11-20 02:30:07 --> Model "M_produk" initialized
INFO - 2023-11-20 02:30:07 --> Controller Class Initialized
INFO - 2023-11-20 02:30:07 --> Model "M_pelanggan" initialized
INFO - 2023-11-20 02:30:07 --> Model "M_produk" initialized
DEBUG - 2023-11-20 02:30:07 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-20 02:30:07 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-20 02:30:07 --> Model "M_transaksi" initialized
INFO - 2023-11-20 02:30:07 --> Model "M_bank" initialized
INFO - 2023-11-20 02:30:07 --> Model "M_pesan" initialized
DEBUG - 2023-11-20 02:30:07 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-20 02:30:07 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-20 02:30:07 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-20 02:30:07 --> Final output sent to browser
DEBUG - 2023-11-20 02:30:07 --> Total execution time: 0.0391
ERROR - 2023-11-20 03:14:10 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 03:14:10 --> Config Class Initialized
INFO - 2023-11-20 03:14:10 --> Hooks Class Initialized
DEBUG - 2023-11-20 03:14:10 --> UTF-8 Support Enabled
INFO - 2023-11-20 03:14:10 --> Utf8 Class Initialized
INFO - 2023-11-20 03:14:10 --> URI Class Initialized
DEBUG - 2023-11-20 03:14:10 --> No URI present. Default controller set.
INFO - 2023-11-20 03:14:10 --> Router Class Initialized
INFO - 2023-11-20 03:14:10 --> Output Class Initialized
INFO - 2023-11-20 03:14:10 --> Security Class Initialized
DEBUG - 2023-11-20 03:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 03:14:10 --> Input Class Initialized
INFO - 2023-11-20 03:14:10 --> Language Class Initialized
INFO - 2023-11-20 03:14:10 --> Loader Class Initialized
INFO - 2023-11-20 03:14:10 --> Helper loaded: url_helper
INFO - 2023-11-20 03:14:10 --> Helper loaded: form_helper
INFO - 2023-11-20 03:14:10 --> Helper loaded: file_helper
INFO - 2023-11-20 03:14:10 --> Database Driver Class Initialized
DEBUG - 2023-11-20 03:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 03:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 03:14:10 --> Form Validation Class Initialized
INFO - 2023-11-20 03:14:10 --> Upload Class Initialized
INFO - 2023-11-20 03:14:10 --> Model "M_auth" initialized
INFO - 2023-11-20 03:14:10 --> Model "M_user" initialized
INFO - 2023-11-20 03:14:10 --> Model "M_produk" initialized
INFO - 2023-11-20 03:14:10 --> Controller Class Initialized
INFO - 2023-11-20 03:14:10 --> Model "M_pelanggan" initialized
INFO - 2023-11-20 03:14:10 --> Model "M_produk" initialized
DEBUG - 2023-11-20 03:14:10 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-20 03:14:10 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-20 03:14:10 --> Model "M_transaksi" initialized
INFO - 2023-11-20 03:14:10 --> Model "M_bank" initialized
INFO - 2023-11-20 03:14:10 --> Model "M_pesan" initialized
DEBUG - 2023-11-20 03:14:10 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-20 03:14:10 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-20 03:14:10 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-20 03:14:10 --> Final output sent to browser
DEBUG - 2023-11-20 03:14:10 --> Total execution time: 0.0312
ERROR - 2023-11-20 05:44:11 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 05:44:11 --> Config Class Initialized
INFO - 2023-11-20 05:44:11 --> Hooks Class Initialized
DEBUG - 2023-11-20 05:44:11 --> UTF-8 Support Enabled
INFO - 2023-11-20 05:44:11 --> Utf8 Class Initialized
INFO - 2023-11-20 05:44:11 --> URI Class Initialized
DEBUG - 2023-11-20 05:44:11 --> No URI present. Default controller set.
INFO - 2023-11-20 05:44:11 --> Router Class Initialized
INFO - 2023-11-20 05:44:11 --> Output Class Initialized
INFO - 2023-11-20 05:44:11 --> Security Class Initialized
DEBUG - 2023-11-20 05:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 05:44:11 --> Input Class Initialized
INFO - 2023-11-20 05:44:11 --> Language Class Initialized
INFO - 2023-11-20 05:44:11 --> Loader Class Initialized
INFO - 2023-11-20 05:44:11 --> Helper loaded: url_helper
INFO - 2023-11-20 05:44:11 --> Helper loaded: form_helper
INFO - 2023-11-20 05:44:11 --> Helper loaded: file_helper
INFO - 2023-11-20 05:44:11 --> Database Driver Class Initialized
DEBUG - 2023-11-20 05:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 05:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 05:44:11 --> Form Validation Class Initialized
INFO - 2023-11-20 05:44:11 --> Upload Class Initialized
INFO - 2023-11-20 05:44:11 --> Model "M_auth" initialized
INFO - 2023-11-20 05:44:11 --> Model "M_user" initialized
INFO - 2023-11-20 05:44:11 --> Model "M_produk" initialized
INFO - 2023-11-20 05:44:11 --> Controller Class Initialized
INFO - 2023-11-20 05:44:11 --> Model "M_pelanggan" initialized
INFO - 2023-11-20 05:44:11 --> Model "M_produk" initialized
DEBUG - 2023-11-20 05:44:11 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-20 05:44:11 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-20 05:44:11 --> Model "M_transaksi" initialized
INFO - 2023-11-20 05:44:11 --> Model "M_bank" initialized
INFO - 2023-11-20 05:44:11 --> Model "M_pesan" initialized
DEBUG - 2023-11-20 05:44:11 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-20 05:44:11 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-20 05:44:11 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-20 05:44:11 --> Final output sent to browser
DEBUG - 2023-11-20 05:44:11 --> Total execution time: 0.0367
ERROR - 2023-11-20 09:22:00 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 09:22:00 --> Config Class Initialized
INFO - 2023-11-20 09:22:00 --> Hooks Class Initialized
DEBUG - 2023-11-20 09:22:00 --> UTF-8 Support Enabled
INFO - 2023-11-20 09:22:00 --> Utf8 Class Initialized
INFO - 2023-11-20 09:22:00 --> URI Class Initialized
DEBUG - 2023-11-20 09:22:00 --> No URI present. Default controller set.
INFO - 2023-11-20 09:22:00 --> Router Class Initialized
INFO - 2023-11-20 09:22:00 --> Output Class Initialized
INFO - 2023-11-20 09:22:00 --> Security Class Initialized
DEBUG - 2023-11-20 09:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 09:22:00 --> Input Class Initialized
INFO - 2023-11-20 09:22:00 --> Language Class Initialized
INFO - 2023-11-20 09:22:00 --> Loader Class Initialized
INFO - 2023-11-20 09:22:00 --> Helper loaded: url_helper
INFO - 2023-11-20 09:22:00 --> Helper loaded: form_helper
INFO - 2023-11-20 09:22:00 --> Helper loaded: file_helper
INFO - 2023-11-20 09:22:01 --> Database Driver Class Initialized
DEBUG - 2023-11-20 09:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 09:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 09:22:01 --> Form Validation Class Initialized
INFO - 2023-11-20 09:22:01 --> Upload Class Initialized
INFO - 2023-11-20 09:22:01 --> Model "M_auth" initialized
INFO - 2023-11-20 09:22:01 --> Model "M_user" initialized
INFO - 2023-11-20 09:22:01 --> Model "M_produk" initialized
INFO - 2023-11-20 09:22:01 --> Controller Class Initialized
INFO - 2023-11-20 09:22:01 --> Model "M_pelanggan" initialized
INFO - 2023-11-20 09:22:01 --> Model "M_produk" initialized
DEBUG - 2023-11-20 09:22:01 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-20 09:22:01 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-20 09:22:01 --> Model "M_transaksi" initialized
INFO - 2023-11-20 09:22:01 --> Model "M_bank" initialized
INFO - 2023-11-20 09:22:01 --> Model "M_pesan" initialized
DEBUG - 2023-11-20 09:22:01 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-20 09:22:01 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-20 09:22:01 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-20 09:22:01 --> Final output sent to browser
DEBUG - 2023-11-20 09:22:01 --> Total execution time: 0.0318
ERROR - 2023-11-20 09:40:41 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 09:40:41 --> Config Class Initialized
INFO - 2023-11-20 09:40:41 --> Hooks Class Initialized
DEBUG - 2023-11-20 09:40:41 --> UTF-8 Support Enabled
INFO - 2023-11-20 09:40:41 --> Utf8 Class Initialized
INFO - 2023-11-20 09:40:41 --> URI Class Initialized
DEBUG - 2023-11-20 09:40:41 --> No URI present. Default controller set.
INFO - 2023-11-20 09:40:41 --> Router Class Initialized
INFO - 2023-11-20 09:40:41 --> Output Class Initialized
INFO - 2023-11-20 09:40:41 --> Security Class Initialized
DEBUG - 2023-11-20 09:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 09:40:41 --> Input Class Initialized
INFO - 2023-11-20 09:40:41 --> Language Class Initialized
INFO - 2023-11-20 09:40:41 --> Loader Class Initialized
INFO - 2023-11-20 09:40:41 --> Helper loaded: url_helper
INFO - 2023-11-20 09:40:41 --> Helper loaded: form_helper
INFO - 2023-11-20 09:40:41 --> Helper loaded: file_helper
INFO - 2023-11-20 09:40:41 --> Database Driver Class Initialized
DEBUG - 2023-11-20 09:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 09:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 09:40:41 --> Form Validation Class Initialized
INFO - 2023-11-20 09:40:41 --> Upload Class Initialized
INFO - 2023-11-20 09:40:41 --> Model "M_auth" initialized
INFO - 2023-11-20 09:40:41 --> Model "M_user" initialized
INFO - 2023-11-20 09:40:41 --> Model "M_produk" initialized
INFO - 2023-11-20 09:40:41 --> Controller Class Initialized
INFO - 2023-11-20 09:40:41 --> Model "M_pelanggan" initialized
INFO - 2023-11-20 09:40:41 --> Model "M_produk" initialized
DEBUG - 2023-11-20 09:40:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-20 09:40:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-20 09:40:41 --> Model "M_transaksi" initialized
INFO - 2023-11-20 09:40:41 --> Model "M_bank" initialized
INFO - 2023-11-20 09:40:41 --> Model "M_pesan" initialized
DEBUG - 2023-11-20 09:40:41 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-20 09:40:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-20 09:40:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-20 09:40:41 --> Final output sent to browser
DEBUG - 2023-11-20 09:40:41 --> Total execution time: 0.0392
ERROR - 2023-11-20 12:22:03 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 12:22:03 --> Config Class Initialized
INFO - 2023-11-20 12:22:03 --> Hooks Class Initialized
DEBUG - 2023-11-20 12:22:03 --> UTF-8 Support Enabled
INFO - 2023-11-20 12:22:03 --> Utf8 Class Initialized
INFO - 2023-11-20 12:22:03 --> URI Class Initialized
INFO - 2023-11-20 12:22:03 --> Router Class Initialized
INFO - 2023-11-20 12:22:03 --> Output Class Initialized
INFO - 2023-11-20 12:22:03 --> Security Class Initialized
DEBUG - 2023-11-20 12:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 12:22:03 --> Input Class Initialized
INFO - 2023-11-20 12:22:03 --> Language Class Initialized
INFO - 2023-11-20 12:22:03 --> Loader Class Initialized
INFO - 2023-11-20 12:22:03 --> Helper loaded: url_helper
INFO - 2023-11-20 12:22:03 --> Helper loaded: form_helper
INFO - 2023-11-20 12:22:03 --> Helper loaded: file_helper
INFO - 2023-11-20 12:22:03 --> Database Driver Class Initialized
DEBUG - 2023-11-20 12:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 12:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 12:22:03 --> Form Validation Class Initialized
INFO - 2023-11-20 12:22:03 --> Upload Class Initialized
INFO - 2023-11-20 12:22:03 --> Model "M_auth" initialized
INFO - 2023-11-20 12:22:03 --> Model "M_user" initialized
INFO - 2023-11-20 12:22:03 --> Model "M_produk" initialized
INFO - 2023-11-20 12:22:03 --> Controller Class Initialized
INFO - 2023-11-20 12:22:03 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-20 12:22:03 --> Final output sent to browser
DEBUG - 2023-11-20 12:22:03 --> Total execution time: 0.0293
ERROR - 2023-11-20 12:22:08 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 12:22:08 --> Config Class Initialized
INFO - 2023-11-20 12:22:08 --> Hooks Class Initialized
DEBUG - 2023-11-20 12:22:08 --> UTF-8 Support Enabled
INFO - 2023-11-20 12:22:08 --> Utf8 Class Initialized
INFO - 2023-11-20 12:22:08 --> URI Class Initialized
INFO - 2023-11-20 12:22:08 --> Router Class Initialized
INFO - 2023-11-20 12:22:08 --> Output Class Initialized
INFO - 2023-11-20 12:22:08 --> Security Class Initialized
DEBUG - 2023-11-20 12:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 12:22:08 --> Input Class Initialized
INFO - 2023-11-20 12:22:08 --> Language Class Initialized
INFO - 2023-11-20 12:22:08 --> Loader Class Initialized
INFO - 2023-11-20 12:22:08 --> Helper loaded: url_helper
INFO - 2023-11-20 12:22:08 --> Helper loaded: form_helper
INFO - 2023-11-20 12:22:08 --> Helper loaded: file_helper
INFO - 2023-11-20 12:22:08 --> Database Driver Class Initialized
DEBUG - 2023-11-20 12:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 12:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 12:22:08 --> Form Validation Class Initialized
INFO - 2023-11-20 12:22:08 --> Upload Class Initialized
INFO - 2023-11-20 12:22:08 --> Model "M_auth" initialized
INFO - 2023-11-20 12:22:08 --> Model "M_user" initialized
INFO - 2023-11-20 12:22:08 --> Model "M_produk" initialized
INFO - 2023-11-20 12:22:08 --> Controller Class Initialized
INFO - 2023-11-20 12:22:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-20 12:22:08 --> Final output sent to browser
DEBUG - 2023-11-20 12:22:08 --> Total execution time: 0.0028
ERROR - 2023-11-20 12:22:08 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 12:22:08 --> Config Class Initialized
INFO - 2023-11-20 12:22:08 --> Hooks Class Initialized
DEBUG - 2023-11-20 12:22:08 --> UTF-8 Support Enabled
INFO - 2023-11-20 12:22:08 --> Utf8 Class Initialized
INFO - 2023-11-20 12:22:08 --> URI Class Initialized
INFO - 2023-11-20 12:22:08 --> Router Class Initialized
INFO - 2023-11-20 12:22:08 --> Output Class Initialized
INFO - 2023-11-20 12:22:08 --> Security Class Initialized
DEBUG - 2023-11-20 12:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 12:22:08 --> Input Class Initialized
INFO - 2023-11-20 12:22:08 --> Language Class Initialized
INFO - 2023-11-20 12:22:08 --> Loader Class Initialized
INFO - 2023-11-20 12:22:08 --> Helper loaded: url_helper
INFO - 2023-11-20 12:22:08 --> Helper loaded: form_helper
INFO - 2023-11-20 12:22:08 --> Helper loaded: file_helper
INFO - 2023-11-20 12:22:08 --> Database Driver Class Initialized
DEBUG - 2023-11-20 12:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 12:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 12:22:08 --> Form Validation Class Initialized
INFO - 2023-11-20 12:22:08 --> Upload Class Initialized
INFO - 2023-11-20 12:22:08 --> Model "M_auth" initialized
INFO - 2023-11-20 12:22:08 --> Model "M_user" initialized
INFO - 2023-11-20 12:22:08 --> Model "M_produk" initialized
INFO - 2023-11-20 12:22:08 --> Controller Class Initialized
INFO - 2023-11-20 12:22:08 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-20 12:22:08 --> Final output sent to browser
DEBUG - 2023-11-20 12:22:08 --> Total execution time: 0.0025
ERROR - 2023-11-20 12:37:46 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 12:37:46 --> Config Class Initialized
INFO - 2023-11-20 12:37:46 --> Hooks Class Initialized
DEBUG - 2023-11-20 12:37:46 --> UTF-8 Support Enabled
INFO - 2023-11-20 12:37:46 --> Utf8 Class Initialized
INFO - 2023-11-20 12:37:46 --> URI Class Initialized
DEBUG - 2023-11-20 12:37:46 --> No URI present. Default controller set.
INFO - 2023-11-20 12:37:46 --> Router Class Initialized
INFO - 2023-11-20 12:37:46 --> Output Class Initialized
INFO - 2023-11-20 12:37:46 --> Security Class Initialized
DEBUG - 2023-11-20 12:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 12:37:46 --> Input Class Initialized
INFO - 2023-11-20 12:37:46 --> Language Class Initialized
INFO - 2023-11-20 12:37:46 --> Loader Class Initialized
INFO - 2023-11-20 12:37:46 --> Helper loaded: url_helper
INFO - 2023-11-20 12:37:46 --> Helper loaded: form_helper
INFO - 2023-11-20 12:37:46 --> Helper loaded: file_helper
INFO - 2023-11-20 12:37:46 --> Database Driver Class Initialized
DEBUG - 2023-11-20 12:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 12:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 12:37:46 --> Form Validation Class Initialized
INFO - 2023-11-20 12:37:46 --> Upload Class Initialized
INFO - 2023-11-20 12:37:46 --> Model "M_auth" initialized
INFO - 2023-11-20 12:37:46 --> Model "M_user" initialized
INFO - 2023-11-20 12:37:46 --> Model "M_produk" initialized
INFO - 2023-11-20 12:37:46 --> Controller Class Initialized
INFO - 2023-11-20 12:37:46 --> Model "M_pelanggan" initialized
INFO - 2023-11-20 12:37:46 --> Model "M_produk" initialized
DEBUG - 2023-11-20 12:37:46 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-20 12:37:46 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-20 12:37:46 --> Model "M_transaksi" initialized
INFO - 2023-11-20 12:37:46 --> Model "M_bank" initialized
INFO - 2023-11-20 12:37:46 --> Model "M_pesan" initialized
DEBUG - 2023-11-20 12:37:46 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-20 12:37:46 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-20 12:37:46 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-20 12:37:46 --> Final output sent to browser
DEBUG - 2023-11-20 12:37:46 --> Total execution time: 0.0316
ERROR - 2023-11-20 12:39:12 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 12:39:12 --> Config Class Initialized
INFO - 2023-11-20 12:39:12 --> Hooks Class Initialized
DEBUG - 2023-11-20 12:39:12 --> UTF-8 Support Enabled
INFO - 2023-11-20 12:39:12 --> Utf8 Class Initialized
INFO - 2023-11-20 12:39:12 --> URI Class Initialized
DEBUG - 2023-11-20 12:39:12 --> No URI present. Default controller set.
INFO - 2023-11-20 12:39:12 --> Router Class Initialized
INFO - 2023-11-20 12:39:12 --> Output Class Initialized
INFO - 2023-11-20 12:39:12 --> Security Class Initialized
DEBUG - 2023-11-20 12:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 12:39:12 --> Input Class Initialized
INFO - 2023-11-20 12:39:12 --> Language Class Initialized
INFO - 2023-11-20 12:39:12 --> Loader Class Initialized
INFO - 2023-11-20 12:39:12 --> Helper loaded: url_helper
INFO - 2023-11-20 12:39:12 --> Helper loaded: form_helper
INFO - 2023-11-20 12:39:12 --> Helper loaded: file_helper
INFO - 2023-11-20 12:39:12 --> Database Driver Class Initialized
DEBUG - 2023-11-20 12:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 12:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 12:39:12 --> Form Validation Class Initialized
INFO - 2023-11-20 12:39:12 --> Upload Class Initialized
INFO - 2023-11-20 12:39:12 --> Model "M_auth" initialized
INFO - 2023-11-20 12:39:12 --> Model "M_user" initialized
INFO - 2023-11-20 12:39:12 --> Model "M_produk" initialized
INFO - 2023-11-20 12:39:12 --> Controller Class Initialized
INFO - 2023-11-20 12:39:12 --> Model "M_pelanggan" initialized
INFO - 2023-11-20 12:39:12 --> Model "M_produk" initialized
DEBUG - 2023-11-20 12:39:12 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-20 12:39:12 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-20 12:39:12 --> Model "M_transaksi" initialized
INFO - 2023-11-20 12:39:12 --> Model "M_bank" initialized
INFO - 2023-11-20 12:39:12 --> Model "M_pesan" initialized
DEBUG - 2023-11-20 12:39:12 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-20 12:39:12 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-20 12:39:12 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-20 12:39:12 --> Final output sent to browser
DEBUG - 2023-11-20 12:39:12 --> Total execution time: 0.0038
ERROR - 2023-11-20 12:39:41 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 12:39:41 --> Config Class Initialized
INFO - 2023-11-20 12:39:41 --> Hooks Class Initialized
DEBUG - 2023-11-20 12:39:41 --> UTF-8 Support Enabled
INFO - 2023-11-20 12:39:41 --> Utf8 Class Initialized
INFO - 2023-11-20 12:39:41 --> URI Class Initialized
DEBUG - 2023-11-20 12:39:41 --> No URI present. Default controller set.
INFO - 2023-11-20 12:39:41 --> Router Class Initialized
INFO - 2023-11-20 12:39:41 --> Output Class Initialized
INFO - 2023-11-20 12:39:41 --> Security Class Initialized
DEBUG - 2023-11-20 12:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 12:39:41 --> Input Class Initialized
INFO - 2023-11-20 12:39:41 --> Language Class Initialized
INFO - 2023-11-20 12:39:41 --> Loader Class Initialized
INFO - 2023-11-20 12:39:41 --> Helper loaded: url_helper
INFO - 2023-11-20 12:39:41 --> Helper loaded: form_helper
INFO - 2023-11-20 12:39:41 --> Helper loaded: file_helper
INFO - 2023-11-20 12:39:41 --> Database Driver Class Initialized
DEBUG - 2023-11-20 12:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 12:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 12:39:41 --> Form Validation Class Initialized
INFO - 2023-11-20 12:39:41 --> Upload Class Initialized
INFO - 2023-11-20 12:39:41 --> Model "M_auth" initialized
INFO - 2023-11-20 12:39:41 --> Model "M_user" initialized
INFO - 2023-11-20 12:39:41 --> Model "M_produk" initialized
INFO - 2023-11-20 12:39:41 --> Controller Class Initialized
INFO - 2023-11-20 12:39:41 --> Model "M_pelanggan" initialized
INFO - 2023-11-20 12:39:41 --> Model "M_produk" initialized
DEBUG - 2023-11-20 12:39:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-20 12:39:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-20 12:39:41 --> Model "M_transaksi" initialized
INFO - 2023-11-20 12:39:41 --> Model "M_bank" initialized
INFO - 2023-11-20 12:39:41 --> Model "M_pesan" initialized
DEBUG - 2023-11-20 12:39:41 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-20 12:39:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-20 12:39:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-20 12:39:41 --> Final output sent to browser
DEBUG - 2023-11-20 12:39:41 --> Total execution time: 0.0041
ERROR - 2023-11-20 13:24:19 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 13:24:19 --> Config Class Initialized
INFO - 2023-11-20 13:24:19 --> Hooks Class Initialized
DEBUG - 2023-11-20 13:24:19 --> UTF-8 Support Enabled
INFO - 2023-11-20 13:24:19 --> Utf8 Class Initialized
INFO - 2023-11-20 13:24:19 --> URI Class Initialized
INFO - 2023-11-20 13:24:19 --> Router Class Initialized
INFO - 2023-11-20 13:24:19 --> Output Class Initialized
INFO - 2023-11-20 13:24:19 --> Security Class Initialized
DEBUG - 2023-11-20 13:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 13:24:19 --> Input Class Initialized
INFO - 2023-11-20 13:24:19 --> Language Class Initialized
INFO - 2023-11-20 13:24:19 --> Loader Class Initialized
INFO - 2023-11-20 13:24:19 --> Helper loaded: url_helper
INFO - 2023-11-20 13:24:19 --> Helper loaded: form_helper
INFO - 2023-11-20 13:24:19 --> Helper loaded: file_helper
INFO - 2023-11-20 13:24:19 --> Database Driver Class Initialized
DEBUG - 2023-11-20 13:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 13:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 13:24:19 --> Form Validation Class Initialized
INFO - 2023-11-20 13:24:19 --> Upload Class Initialized
INFO - 2023-11-20 13:24:19 --> Model "M_auth" initialized
INFO - 2023-11-20 13:24:19 --> Model "M_user" initialized
INFO - 2023-11-20 13:24:19 --> Model "M_produk" initialized
INFO - 2023-11-20 13:24:19 --> Controller Class Initialized
INFO - 2023-11-20 13:24:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-20 13:24:19 --> Final output sent to browser
DEBUG - 2023-11-20 13:24:19 --> Total execution time: 0.0274
ERROR - 2023-11-20 13:24:21 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 13:24:21 --> Config Class Initialized
INFO - 2023-11-20 13:24:21 --> Hooks Class Initialized
DEBUG - 2023-11-20 13:24:21 --> UTF-8 Support Enabled
INFO - 2023-11-20 13:24:21 --> Utf8 Class Initialized
INFO - 2023-11-20 13:24:21 --> URI Class Initialized
DEBUG - 2023-11-20 13:24:21 --> No URI present. Default controller set.
INFO - 2023-11-20 13:24:21 --> Router Class Initialized
INFO - 2023-11-20 13:24:21 --> Output Class Initialized
INFO - 2023-11-20 13:24:21 --> Security Class Initialized
DEBUG - 2023-11-20 13:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 13:24:21 --> Input Class Initialized
INFO - 2023-11-20 13:24:21 --> Language Class Initialized
INFO - 2023-11-20 13:24:21 --> Loader Class Initialized
INFO - 2023-11-20 13:24:21 --> Helper loaded: url_helper
INFO - 2023-11-20 13:24:21 --> Helper loaded: form_helper
INFO - 2023-11-20 13:24:21 --> Helper loaded: file_helper
INFO - 2023-11-20 13:24:21 --> Database Driver Class Initialized
DEBUG - 2023-11-20 13:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 13:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 13:24:21 --> Form Validation Class Initialized
INFO - 2023-11-20 13:24:21 --> Upload Class Initialized
INFO - 2023-11-20 13:24:21 --> Model "M_auth" initialized
INFO - 2023-11-20 13:24:21 --> Model "M_user" initialized
INFO - 2023-11-20 13:24:21 --> Model "M_produk" initialized
INFO - 2023-11-20 13:24:21 --> Controller Class Initialized
INFO - 2023-11-20 13:24:21 --> Model "M_pelanggan" initialized
INFO - 2023-11-20 13:24:21 --> Model "M_produk" initialized
DEBUG - 2023-11-20 13:24:21 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-20 13:24:21 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-20 13:24:21 --> Model "M_transaksi" initialized
INFO - 2023-11-20 13:24:21 --> Model "M_bank" initialized
INFO - 2023-11-20 13:24:21 --> Model "M_pesan" initialized
DEBUG - 2023-11-20 13:24:21 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-20 13:24:21 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-20 13:24:21 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-20 13:24:21 --> Final output sent to browser
DEBUG - 2023-11-20 13:24:21 --> Total execution time: 0.0103
ERROR - 2023-11-20 13:27:13 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 13:27:13 --> Config Class Initialized
INFO - 2023-11-20 13:27:13 --> Hooks Class Initialized
DEBUG - 2023-11-20 13:27:13 --> UTF-8 Support Enabled
INFO - 2023-11-20 13:27:13 --> Utf8 Class Initialized
INFO - 2023-11-20 13:27:13 --> URI Class Initialized
DEBUG - 2023-11-20 13:27:13 --> No URI present. Default controller set.
INFO - 2023-11-20 13:27:13 --> Router Class Initialized
INFO - 2023-11-20 13:27:13 --> Output Class Initialized
INFO - 2023-11-20 13:27:13 --> Security Class Initialized
DEBUG - 2023-11-20 13:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 13:27:13 --> Input Class Initialized
INFO - 2023-11-20 13:27:13 --> Language Class Initialized
INFO - 2023-11-20 13:27:13 --> Loader Class Initialized
INFO - 2023-11-20 13:27:13 --> Helper loaded: url_helper
INFO - 2023-11-20 13:27:13 --> Helper loaded: form_helper
INFO - 2023-11-20 13:27:13 --> Helper loaded: file_helper
INFO - 2023-11-20 13:27:13 --> Database Driver Class Initialized
DEBUG - 2023-11-20 13:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 13:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 13:27:13 --> Form Validation Class Initialized
INFO - 2023-11-20 13:27:13 --> Upload Class Initialized
INFO - 2023-11-20 13:27:13 --> Model "M_auth" initialized
INFO - 2023-11-20 13:27:13 --> Model "M_user" initialized
INFO - 2023-11-20 13:27:13 --> Model "M_produk" initialized
INFO - 2023-11-20 13:27:13 --> Controller Class Initialized
INFO - 2023-11-20 13:27:13 --> Model "M_pelanggan" initialized
INFO - 2023-11-20 13:27:13 --> Model "M_produk" initialized
DEBUG - 2023-11-20 13:27:13 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-20 13:27:13 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-20 13:27:13 --> Model "M_transaksi" initialized
INFO - 2023-11-20 13:27:13 --> Model "M_bank" initialized
INFO - 2023-11-20 13:27:13 --> Model "M_pesan" initialized
DEBUG - 2023-11-20 13:27:13 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-20 13:27:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-20 13:27:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-20 13:27:13 --> Final output sent to browser
DEBUG - 2023-11-20 13:27:13 --> Total execution time: 0.0049
ERROR - 2023-11-20 15:53:13 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 15:53:13 --> Config Class Initialized
INFO - 2023-11-20 15:53:13 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:53:13 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:53:13 --> Utf8 Class Initialized
INFO - 2023-11-20 15:53:13 --> URI Class Initialized
DEBUG - 2023-11-20 15:53:13 --> No URI present. Default controller set.
INFO - 2023-11-20 15:53:13 --> Router Class Initialized
INFO - 2023-11-20 15:53:13 --> Output Class Initialized
INFO - 2023-11-20 15:53:13 --> Security Class Initialized
DEBUG - 2023-11-20 15:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:53:13 --> Input Class Initialized
INFO - 2023-11-20 15:53:13 --> Language Class Initialized
INFO - 2023-11-20 15:53:13 --> Loader Class Initialized
INFO - 2023-11-20 15:53:13 --> Helper loaded: url_helper
INFO - 2023-11-20 15:53:13 --> Helper loaded: form_helper
INFO - 2023-11-20 15:53:13 --> Helper loaded: file_helper
INFO - 2023-11-20 15:53:13 --> Database Driver Class Initialized
DEBUG - 2023-11-20 15:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 15:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:53:13 --> Form Validation Class Initialized
INFO - 2023-11-20 15:53:13 --> Upload Class Initialized
INFO - 2023-11-20 15:53:13 --> Model "M_auth" initialized
INFO - 2023-11-20 15:53:13 --> Model "M_user" initialized
INFO - 2023-11-20 15:53:13 --> Model "M_produk" initialized
INFO - 2023-11-20 15:53:13 --> Controller Class Initialized
INFO - 2023-11-20 15:53:13 --> Model "M_pelanggan" initialized
INFO - 2023-11-20 15:53:13 --> Model "M_produk" initialized
DEBUG - 2023-11-20 15:53:13 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-20 15:53:13 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-20 15:53:13 --> Model "M_transaksi" initialized
INFO - 2023-11-20 15:53:13 --> Model "M_bank" initialized
INFO - 2023-11-20 15:53:13 --> Model "M_pesan" initialized
DEBUG - 2023-11-20 15:53:13 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-20 15:53:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-20 15:53:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-20 15:53:13 --> Final output sent to browser
DEBUG - 2023-11-20 15:53:13 --> Total execution time: 0.0382
ERROR - 2023-11-20 15:57:11 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 15:57:11 --> Config Class Initialized
INFO - 2023-11-20 15:57:11 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:57:11 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:57:11 --> Utf8 Class Initialized
INFO - 2023-11-20 15:57:11 --> URI Class Initialized
INFO - 2023-11-20 15:57:11 --> Router Class Initialized
INFO - 2023-11-20 15:57:11 --> Output Class Initialized
INFO - 2023-11-20 15:57:11 --> Security Class Initialized
DEBUG - 2023-11-20 15:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:57:11 --> Input Class Initialized
INFO - 2023-11-20 15:57:11 --> Language Class Initialized
INFO - 2023-11-20 15:57:11 --> Loader Class Initialized
INFO - 2023-11-20 15:57:11 --> Helper loaded: url_helper
INFO - 2023-11-20 15:57:11 --> Helper loaded: form_helper
INFO - 2023-11-20 15:57:11 --> Helper loaded: file_helper
INFO - 2023-11-20 15:57:11 --> Database Driver Class Initialized
DEBUG - 2023-11-20 15:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 15:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:57:11 --> Form Validation Class Initialized
INFO - 2023-11-20 15:57:11 --> Upload Class Initialized
INFO - 2023-11-20 15:57:11 --> Model "M_auth" initialized
INFO - 2023-11-20 15:57:11 --> Model "M_user" initialized
INFO - 2023-11-20 15:57:11 --> Model "M_produk" initialized
INFO - 2023-11-20 15:57:11 --> Controller Class Initialized
INFO - 2023-11-20 15:57:11 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-20 15:57:11 --> Final output sent to browser
DEBUG - 2023-11-20 15:57:11 --> Total execution time: 0.0034
ERROR - 2023-11-20 15:57:11 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 15:57:11 --> Config Class Initialized
INFO - 2023-11-20 15:57:11 --> Hooks Class Initialized
DEBUG - 2023-11-20 15:57:11 --> UTF-8 Support Enabled
INFO - 2023-11-20 15:57:11 --> Utf8 Class Initialized
INFO - 2023-11-20 15:57:11 --> URI Class Initialized
INFO - 2023-11-20 15:57:11 --> Router Class Initialized
INFO - 2023-11-20 15:57:11 --> Output Class Initialized
INFO - 2023-11-20 15:57:11 --> Security Class Initialized
DEBUG - 2023-11-20 15:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 15:57:11 --> Input Class Initialized
INFO - 2023-11-20 15:57:11 --> Language Class Initialized
INFO - 2023-11-20 15:57:11 --> Loader Class Initialized
INFO - 2023-11-20 15:57:11 --> Helper loaded: url_helper
INFO - 2023-11-20 15:57:11 --> Helper loaded: form_helper
INFO - 2023-11-20 15:57:11 --> Helper loaded: file_helper
INFO - 2023-11-20 15:57:11 --> Database Driver Class Initialized
DEBUG - 2023-11-20 15:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 15:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 15:57:11 --> Form Validation Class Initialized
INFO - 2023-11-20 15:57:11 --> Upload Class Initialized
INFO - 2023-11-20 15:57:11 --> Model "M_auth" initialized
INFO - 2023-11-20 15:57:11 --> Model "M_user" initialized
INFO - 2023-11-20 15:57:11 --> Model "M_produk" initialized
INFO - 2023-11-20 15:57:11 --> Controller Class Initialized
INFO - 2023-11-20 15:57:11 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-20 15:57:11 --> Final output sent to browser
DEBUG - 2023-11-20 15:57:11 --> Total execution time: 0.0023
ERROR - 2023-11-20 16:16:40 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 16:16:40 --> Config Class Initialized
INFO - 2023-11-20 16:16:40 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:16:40 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:16:40 --> Utf8 Class Initialized
INFO - 2023-11-20 16:16:40 --> URI Class Initialized
INFO - 2023-11-20 16:16:40 --> Router Class Initialized
INFO - 2023-11-20 16:16:40 --> Output Class Initialized
INFO - 2023-11-20 16:16:40 --> Security Class Initialized
DEBUG - 2023-11-20 16:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:16:40 --> Input Class Initialized
INFO - 2023-11-20 16:16:40 --> Language Class Initialized
INFO - 2023-11-20 16:16:40 --> Loader Class Initialized
INFO - 2023-11-20 16:16:40 --> Helper loaded: url_helper
INFO - 2023-11-20 16:16:40 --> Helper loaded: form_helper
INFO - 2023-11-20 16:16:40 --> Helper loaded: file_helper
INFO - 2023-11-20 16:16:40 --> Database Driver Class Initialized
DEBUG - 2023-11-20 16:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 16:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:16:40 --> Form Validation Class Initialized
INFO - 2023-11-20 16:16:40 --> Upload Class Initialized
INFO - 2023-11-20 16:16:40 --> Model "M_auth" initialized
INFO - 2023-11-20 16:16:40 --> Model "M_user" initialized
INFO - 2023-11-20 16:16:40 --> Model "M_produk" initialized
INFO - 2023-11-20 16:16:40 --> Controller Class Initialized
INFO - 2023-11-20 16:16:40 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-20 16:16:40 --> Final output sent to browser
DEBUG - 2023-11-20 16:16:40 --> Total execution time: 0.0257
ERROR - 2023-11-20 16:16:41 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 16:16:41 --> Config Class Initialized
INFO - 2023-11-20 16:16:41 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:16:41 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:16:41 --> Utf8 Class Initialized
INFO - 2023-11-20 16:16:41 --> URI Class Initialized
DEBUG - 2023-11-20 16:16:41 --> No URI present. Default controller set.
INFO - 2023-11-20 16:16:41 --> Router Class Initialized
INFO - 2023-11-20 16:16:41 --> Output Class Initialized
INFO - 2023-11-20 16:16:41 --> Security Class Initialized
DEBUG - 2023-11-20 16:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:16:41 --> Input Class Initialized
INFO - 2023-11-20 16:16:41 --> Language Class Initialized
INFO - 2023-11-20 16:16:41 --> Loader Class Initialized
INFO - 2023-11-20 16:16:41 --> Helper loaded: url_helper
INFO - 2023-11-20 16:16:41 --> Helper loaded: form_helper
INFO - 2023-11-20 16:16:41 --> Helper loaded: file_helper
INFO - 2023-11-20 16:16:41 --> Database Driver Class Initialized
DEBUG - 2023-11-20 16:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 16:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:16:41 --> Form Validation Class Initialized
INFO - 2023-11-20 16:16:41 --> Upload Class Initialized
INFO - 2023-11-20 16:16:41 --> Model "M_auth" initialized
INFO - 2023-11-20 16:16:41 --> Model "M_user" initialized
INFO - 2023-11-20 16:16:41 --> Model "M_produk" initialized
INFO - 2023-11-20 16:16:41 --> Controller Class Initialized
INFO - 2023-11-20 16:16:41 --> Model "M_pelanggan" initialized
INFO - 2023-11-20 16:16:41 --> Model "M_produk" initialized
DEBUG - 2023-11-20 16:16:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-20 16:16:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-20 16:16:41 --> Model "M_transaksi" initialized
INFO - 2023-11-20 16:16:41 --> Model "M_bank" initialized
INFO - 2023-11-20 16:16:41 --> Model "M_pesan" initialized
DEBUG - 2023-11-20 16:16:41 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-20 16:16:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-20 16:16:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-20 16:16:41 --> Final output sent to browser
DEBUG - 2023-11-20 16:16:41 --> Total execution time: 0.0080
ERROR - 2023-11-20 16:36:52 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 16:36:52 --> Config Class Initialized
INFO - 2023-11-20 16:36:52 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:36:52 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:36:52 --> Utf8 Class Initialized
INFO - 2023-11-20 16:36:52 --> URI Class Initialized
DEBUG - 2023-11-20 16:36:52 --> No URI present. Default controller set.
INFO - 2023-11-20 16:36:52 --> Router Class Initialized
INFO - 2023-11-20 16:36:52 --> Output Class Initialized
INFO - 2023-11-20 16:36:52 --> Security Class Initialized
DEBUG - 2023-11-20 16:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:36:52 --> Input Class Initialized
INFO - 2023-11-20 16:36:52 --> Language Class Initialized
INFO - 2023-11-20 16:36:52 --> Loader Class Initialized
INFO - 2023-11-20 16:36:52 --> Helper loaded: url_helper
INFO - 2023-11-20 16:36:52 --> Helper loaded: form_helper
INFO - 2023-11-20 16:36:52 --> Helper loaded: file_helper
INFO - 2023-11-20 16:36:52 --> Database Driver Class Initialized
DEBUG - 2023-11-20 16:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 16:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:36:52 --> Form Validation Class Initialized
INFO - 2023-11-20 16:36:52 --> Upload Class Initialized
INFO - 2023-11-20 16:36:52 --> Model "M_auth" initialized
INFO - 2023-11-20 16:36:52 --> Model "M_user" initialized
INFO - 2023-11-20 16:36:52 --> Model "M_produk" initialized
INFO - 2023-11-20 16:36:52 --> Controller Class Initialized
INFO - 2023-11-20 16:36:52 --> Model "M_pelanggan" initialized
INFO - 2023-11-20 16:36:52 --> Model "M_produk" initialized
DEBUG - 2023-11-20 16:36:52 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-20 16:36:52 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-20 16:36:52 --> Model "M_transaksi" initialized
INFO - 2023-11-20 16:36:52 --> Model "M_bank" initialized
INFO - 2023-11-20 16:36:52 --> Model "M_pesan" initialized
DEBUG - 2023-11-20 16:36:52 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-20 16:36:52 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-20 16:36:52 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-20 16:36:52 --> Final output sent to browser
DEBUG - 2023-11-20 16:36:52 --> Total execution time: 0.0312
ERROR - 2023-11-20 16:43:54 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 16:43:54 --> Config Class Initialized
INFO - 2023-11-20 16:43:54 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:43:54 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:43:54 --> Utf8 Class Initialized
INFO - 2023-11-20 16:43:54 --> URI Class Initialized
INFO - 2023-11-20 16:43:54 --> Router Class Initialized
INFO - 2023-11-20 16:43:54 --> Output Class Initialized
INFO - 2023-11-20 16:43:54 --> Security Class Initialized
DEBUG - 2023-11-20 16:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:43:54 --> Input Class Initialized
INFO - 2023-11-20 16:43:54 --> Language Class Initialized
INFO - 2023-11-20 16:43:54 --> Loader Class Initialized
INFO - 2023-11-20 16:43:54 --> Helper loaded: url_helper
INFO - 2023-11-20 16:43:54 --> Helper loaded: form_helper
INFO - 2023-11-20 16:43:54 --> Helper loaded: file_helper
INFO - 2023-11-20 16:43:54 --> Database Driver Class Initialized
DEBUG - 2023-11-20 16:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 16:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:43:54 --> Form Validation Class Initialized
INFO - 2023-11-20 16:43:54 --> Upload Class Initialized
INFO - 2023-11-20 16:43:54 --> Model "M_auth" initialized
INFO - 2023-11-20 16:43:54 --> Model "M_user" initialized
INFO - 2023-11-20 16:43:54 --> Model "M_produk" initialized
INFO - 2023-11-20 16:43:54 --> Controller Class Initialized
INFO - 2023-11-20 16:43:54 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-20 16:43:54 --> Final output sent to browser
DEBUG - 2023-11-20 16:43:54 --> Total execution time: 0.0254
ERROR - 2023-11-20 16:46:16 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 16:46:16 --> Config Class Initialized
INFO - 2023-11-20 16:46:16 --> Hooks Class Initialized
DEBUG - 2023-11-20 16:46:16 --> UTF-8 Support Enabled
INFO - 2023-11-20 16:46:16 --> Utf8 Class Initialized
INFO - 2023-11-20 16:46:16 --> URI Class Initialized
DEBUG - 2023-11-20 16:46:16 --> No URI present. Default controller set.
INFO - 2023-11-20 16:46:16 --> Router Class Initialized
INFO - 2023-11-20 16:46:16 --> Output Class Initialized
INFO - 2023-11-20 16:46:16 --> Security Class Initialized
DEBUG - 2023-11-20 16:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 16:46:16 --> Input Class Initialized
INFO - 2023-11-20 16:46:16 --> Language Class Initialized
INFO - 2023-11-20 16:46:16 --> Loader Class Initialized
INFO - 2023-11-20 16:46:16 --> Helper loaded: url_helper
INFO - 2023-11-20 16:46:16 --> Helper loaded: form_helper
INFO - 2023-11-20 16:46:16 --> Helper loaded: file_helper
INFO - 2023-11-20 16:46:16 --> Database Driver Class Initialized
DEBUG - 2023-11-20 16:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 16:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 16:46:16 --> Form Validation Class Initialized
INFO - 2023-11-20 16:46:16 --> Upload Class Initialized
INFO - 2023-11-20 16:46:16 --> Model "M_auth" initialized
INFO - 2023-11-20 16:46:16 --> Model "M_user" initialized
INFO - 2023-11-20 16:46:16 --> Model "M_produk" initialized
INFO - 2023-11-20 16:46:16 --> Controller Class Initialized
INFO - 2023-11-20 16:46:16 --> Model "M_pelanggan" initialized
INFO - 2023-11-20 16:46:16 --> Model "M_produk" initialized
DEBUG - 2023-11-20 16:46:16 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-20 16:46:16 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-20 16:46:16 --> Model "M_transaksi" initialized
INFO - 2023-11-20 16:46:16 --> Model "M_bank" initialized
INFO - 2023-11-20 16:46:16 --> Model "M_pesan" initialized
DEBUG - 2023-11-20 16:46:16 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-20 16:46:16 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-20 16:46:16 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-20 16:46:16 --> Final output sent to browser
DEBUG - 2023-11-20 16:46:16 --> Total execution time: 0.0136
ERROR - 2023-11-20 17:52:39 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 17:52:39 --> Config Class Initialized
INFO - 2023-11-20 17:52:39 --> Hooks Class Initialized
DEBUG - 2023-11-20 17:52:39 --> UTF-8 Support Enabled
INFO - 2023-11-20 17:52:39 --> Utf8 Class Initialized
INFO - 2023-11-20 17:52:39 --> URI Class Initialized
INFO - 2023-11-20 17:52:39 --> Router Class Initialized
INFO - 2023-11-20 17:52:39 --> Output Class Initialized
INFO - 2023-11-20 17:52:39 --> Security Class Initialized
DEBUG - 2023-11-20 17:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 17:52:39 --> Input Class Initialized
INFO - 2023-11-20 17:52:39 --> Language Class Initialized
INFO - 2023-11-20 17:52:39 --> Loader Class Initialized
INFO - 2023-11-20 17:52:39 --> Helper loaded: url_helper
INFO - 2023-11-20 17:52:39 --> Helper loaded: form_helper
INFO - 2023-11-20 17:52:39 --> Helper loaded: file_helper
INFO - 2023-11-20 17:52:39 --> Database Driver Class Initialized
DEBUG - 2023-11-20 17:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 17:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 17:52:39 --> Form Validation Class Initialized
INFO - 2023-11-20 17:52:39 --> Upload Class Initialized
INFO - 2023-11-20 17:52:39 --> Model "M_auth" initialized
INFO - 2023-11-20 17:52:39 --> Model "M_user" initialized
INFO - 2023-11-20 17:52:39 --> Model "M_produk" initialized
INFO - 2023-11-20 17:52:39 --> Controller Class Initialized
INFO - 2023-11-20 17:52:39 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-20 17:52:39 --> Final output sent to browser
DEBUG - 2023-11-20 17:52:39 --> Total execution time: 0.0258
ERROR - 2023-11-20 17:52:39 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 17:52:39 --> Config Class Initialized
INFO - 2023-11-20 17:52:39 --> Hooks Class Initialized
DEBUG - 2023-11-20 17:52:39 --> UTF-8 Support Enabled
INFO - 2023-11-20 17:52:39 --> Utf8 Class Initialized
INFO - 2023-11-20 17:52:39 --> URI Class Initialized
INFO - 2023-11-20 17:52:39 --> Router Class Initialized
INFO - 2023-11-20 17:52:39 --> Output Class Initialized
INFO - 2023-11-20 17:52:39 --> Security Class Initialized
DEBUG - 2023-11-20 17:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 17:52:39 --> Input Class Initialized
INFO - 2023-11-20 17:52:39 --> Language Class Initialized
INFO - 2023-11-20 17:52:39 --> Loader Class Initialized
INFO - 2023-11-20 17:52:39 --> Helper loaded: url_helper
INFO - 2023-11-20 17:52:39 --> Helper loaded: form_helper
INFO - 2023-11-20 17:52:39 --> Helper loaded: file_helper
INFO - 2023-11-20 17:52:39 --> Database Driver Class Initialized
DEBUG - 2023-11-20 17:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 17:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 17:52:39 --> Form Validation Class Initialized
INFO - 2023-11-20 17:52:39 --> Upload Class Initialized
INFO - 2023-11-20 17:52:39 --> Model "M_auth" initialized
INFO - 2023-11-20 17:52:39 --> Model "M_user" initialized
INFO - 2023-11-20 17:52:39 --> Model "M_produk" initialized
INFO - 2023-11-20 17:52:39 --> Controller Class Initialized
INFO - 2023-11-20 17:52:39 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-20 17:52:39 --> Final output sent to browser
DEBUG - 2023-11-20 17:52:39 --> Total execution time: 0.0025
ERROR - 2023-11-20 18:33:58 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 18:33:58 --> Config Class Initialized
INFO - 2023-11-20 18:33:58 --> Hooks Class Initialized
DEBUG - 2023-11-20 18:33:58 --> UTF-8 Support Enabled
INFO - 2023-11-20 18:33:58 --> Utf8 Class Initialized
INFO - 2023-11-20 18:33:58 --> URI Class Initialized
DEBUG - 2023-11-20 18:33:58 --> No URI present. Default controller set.
INFO - 2023-11-20 18:33:58 --> Router Class Initialized
INFO - 2023-11-20 18:33:58 --> Output Class Initialized
INFO - 2023-11-20 18:33:58 --> Security Class Initialized
DEBUG - 2023-11-20 18:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 18:33:58 --> Input Class Initialized
INFO - 2023-11-20 18:33:58 --> Language Class Initialized
INFO - 2023-11-20 18:33:58 --> Loader Class Initialized
INFO - 2023-11-20 18:33:58 --> Helper loaded: url_helper
INFO - 2023-11-20 18:33:58 --> Helper loaded: form_helper
INFO - 2023-11-20 18:33:58 --> Helper loaded: file_helper
INFO - 2023-11-20 18:33:58 --> Database Driver Class Initialized
DEBUG - 2023-11-20 18:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 18:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 18:33:58 --> Form Validation Class Initialized
INFO - 2023-11-20 18:33:58 --> Upload Class Initialized
INFO - 2023-11-20 18:33:58 --> Model "M_auth" initialized
INFO - 2023-11-20 18:33:58 --> Model "M_user" initialized
INFO - 2023-11-20 18:33:58 --> Model "M_produk" initialized
INFO - 2023-11-20 18:33:58 --> Controller Class Initialized
INFO - 2023-11-20 18:33:58 --> Model "M_pelanggan" initialized
INFO - 2023-11-20 18:33:58 --> Model "M_produk" initialized
DEBUG - 2023-11-20 18:33:58 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-20 18:33:58 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-20 18:33:58 --> Model "M_transaksi" initialized
INFO - 2023-11-20 18:33:58 --> Model "M_bank" initialized
INFO - 2023-11-20 18:33:58 --> Model "M_pesan" initialized
DEBUG - 2023-11-20 18:33:58 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-20 18:33:58 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-20 18:33:58 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-20 18:33:58 --> Final output sent to browser
DEBUG - 2023-11-20 18:33:58 --> Total execution time: 0.0307
ERROR - 2023-11-20 19:21:38 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 19:21:38 --> Config Class Initialized
INFO - 2023-11-20 19:21:38 --> Hooks Class Initialized
DEBUG - 2023-11-20 19:21:38 --> UTF-8 Support Enabled
INFO - 2023-11-20 19:21:38 --> Utf8 Class Initialized
INFO - 2023-11-20 19:21:38 --> URI Class Initialized
DEBUG - 2023-11-20 19:21:38 --> No URI present. Default controller set.
INFO - 2023-11-20 19:21:38 --> Router Class Initialized
INFO - 2023-11-20 19:21:38 --> Output Class Initialized
INFO - 2023-11-20 19:21:38 --> Security Class Initialized
DEBUG - 2023-11-20 19:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 19:21:38 --> Input Class Initialized
INFO - 2023-11-20 19:21:38 --> Language Class Initialized
INFO - 2023-11-20 19:21:38 --> Loader Class Initialized
INFO - 2023-11-20 19:21:38 --> Helper loaded: url_helper
INFO - 2023-11-20 19:21:38 --> Helper loaded: form_helper
INFO - 2023-11-20 19:21:38 --> Helper loaded: file_helper
INFO - 2023-11-20 19:21:38 --> Database Driver Class Initialized
DEBUG - 2023-11-20 19:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 19:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 19:21:39 --> Form Validation Class Initialized
INFO - 2023-11-20 19:21:39 --> Upload Class Initialized
INFO - 2023-11-20 19:21:39 --> Model "M_auth" initialized
INFO - 2023-11-20 19:21:39 --> Model "M_user" initialized
INFO - 2023-11-20 19:21:39 --> Model "M_produk" initialized
INFO - 2023-11-20 19:21:39 --> Controller Class Initialized
INFO - 2023-11-20 19:21:39 --> Model "M_pelanggan" initialized
INFO - 2023-11-20 19:21:39 --> Model "M_produk" initialized
DEBUG - 2023-11-20 19:21:39 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-20 19:21:39 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-20 19:21:39 --> Model "M_transaksi" initialized
INFO - 2023-11-20 19:21:39 --> Model "M_bank" initialized
INFO - 2023-11-20 19:21:39 --> Model "M_pesan" initialized
DEBUG - 2023-11-20 19:21:39 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-20 19:21:39 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-20 19:21:39 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-20 19:21:39 --> Final output sent to browser
DEBUG - 2023-11-20 19:21:39 --> Total execution time: 0.0328
ERROR - 2023-11-20 19:35:14 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 19:35:14 --> Config Class Initialized
INFO - 2023-11-20 19:35:14 --> Hooks Class Initialized
DEBUG - 2023-11-20 19:35:14 --> UTF-8 Support Enabled
INFO - 2023-11-20 19:35:14 --> Utf8 Class Initialized
INFO - 2023-11-20 19:35:14 --> URI Class Initialized
INFO - 2023-11-20 19:35:14 --> Router Class Initialized
INFO - 2023-11-20 19:35:14 --> Output Class Initialized
INFO - 2023-11-20 19:35:14 --> Security Class Initialized
DEBUG - 2023-11-20 19:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 19:35:14 --> Input Class Initialized
INFO - 2023-11-20 19:35:14 --> Language Class Initialized
INFO - 2023-11-20 19:35:14 --> Loader Class Initialized
INFO - 2023-11-20 19:35:14 --> Helper loaded: url_helper
INFO - 2023-11-20 19:35:14 --> Helper loaded: form_helper
INFO - 2023-11-20 19:35:14 --> Helper loaded: file_helper
INFO - 2023-11-20 19:35:14 --> Database Driver Class Initialized
DEBUG - 2023-11-20 19:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 19:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 19:35:14 --> Form Validation Class Initialized
INFO - 2023-11-20 19:35:14 --> Upload Class Initialized
INFO - 2023-11-20 19:35:14 --> Model "M_auth" initialized
INFO - 2023-11-20 19:35:14 --> Model "M_user" initialized
INFO - 2023-11-20 19:35:14 --> Model "M_produk" initialized
INFO - 2023-11-20 19:35:14 --> Controller Class Initialized
INFO - 2023-11-20 19:35:14 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-20 19:35:14 --> Final output sent to browser
DEBUG - 2023-11-20 19:35:14 --> Total execution time: 0.0274
ERROR - 2023-11-20 19:35:14 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 19:35:14 --> Config Class Initialized
INFO - 2023-11-20 19:35:14 --> Hooks Class Initialized
DEBUG - 2023-11-20 19:35:14 --> UTF-8 Support Enabled
INFO - 2023-11-20 19:35:14 --> Utf8 Class Initialized
INFO - 2023-11-20 19:35:14 --> URI Class Initialized
INFO - 2023-11-20 19:35:14 --> Router Class Initialized
INFO - 2023-11-20 19:35:14 --> Output Class Initialized
INFO - 2023-11-20 19:35:14 --> Security Class Initialized
DEBUG - 2023-11-20 19:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 19:35:14 --> Input Class Initialized
INFO - 2023-11-20 19:35:14 --> Language Class Initialized
INFO - 2023-11-20 19:35:14 --> Loader Class Initialized
INFO - 2023-11-20 19:35:14 --> Helper loaded: url_helper
INFO - 2023-11-20 19:35:14 --> Helper loaded: form_helper
INFO - 2023-11-20 19:35:14 --> Helper loaded: file_helper
INFO - 2023-11-20 19:35:14 --> Database Driver Class Initialized
DEBUG - 2023-11-20 19:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 19:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 19:35:14 --> Form Validation Class Initialized
INFO - 2023-11-20 19:35:14 --> Upload Class Initialized
INFO - 2023-11-20 19:35:14 --> Model "M_auth" initialized
INFO - 2023-11-20 19:35:14 --> Model "M_user" initialized
INFO - 2023-11-20 19:35:14 --> Model "M_produk" initialized
INFO - 2023-11-20 19:35:14 --> Controller Class Initialized
INFO - 2023-11-20 19:35:14 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-20 19:35:14 --> Final output sent to browser
DEBUG - 2023-11-20 19:35:14 --> Total execution time: 0.0021
ERROR - 2023-11-20 20:38:15 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 20:38:15 --> Config Class Initialized
INFO - 2023-11-20 20:38:15 --> Hooks Class Initialized
DEBUG - 2023-11-20 20:38:15 --> UTF-8 Support Enabled
INFO - 2023-11-20 20:38:15 --> Utf8 Class Initialized
INFO - 2023-11-20 20:38:15 --> URI Class Initialized
INFO - 2023-11-20 20:38:15 --> Router Class Initialized
INFO - 2023-11-20 20:38:15 --> Output Class Initialized
INFO - 2023-11-20 20:38:15 --> Security Class Initialized
DEBUG - 2023-11-20 20:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 20:38:15 --> Input Class Initialized
INFO - 2023-11-20 20:38:15 --> Language Class Initialized
INFO - 2023-11-20 20:38:15 --> Loader Class Initialized
INFO - 2023-11-20 20:38:15 --> Helper loaded: url_helper
INFO - 2023-11-20 20:38:15 --> Helper loaded: form_helper
INFO - 2023-11-20 20:38:15 --> Helper loaded: file_helper
INFO - 2023-11-20 20:38:15 --> Database Driver Class Initialized
DEBUG - 2023-11-20 20:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 20:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 20:38:15 --> Form Validation Class Initialized
INFO - 2023-11-20 20:38:15 --> Upload Class Initialized
INFO - 2023-11-20 20:38:15 --> Model "M_auth" initialized
INFO - 2023-11-20 20:38:15 --> Model "M_user" initialized
INFO - 2023-11-20 20:38:15 --> Model "M_produk" initialized
INFO - 2023-11-20 20:38:15 --> Controller Class Initialized
INFO - 2023-11-20 20:38:15 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-20 20:38:15 --> Final output sent to browser
DEBUG - 2023-11-20 20:38:15 --> Total execution time: 0.0260
ERROR - 2023-11-20 20:38:21 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 20:38:21 --> Config Class Initialized
INFO - 2023-11-20 20:38:21 --> Hooks Class Initialized
DEBUG - 2023-11-20 20:38:21 --> UTF-8 Support Enabled
INFO - 2023-11-20 20:38:21 --> Utf8 Class Initialized
INFO - 2023-11-20 20:38:21 --> URI Class Initialized
INFO - 2023-11-20 20:38:21 --> Router Class Initialized
INFO - 2023-11-20 20:38:21 --> Output Class Initialized
INFO - 2023-11-20 20:38:21 --> Security Class Initialized
DEBUG - 2023-11-20 20:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 20:38:21 --> Input Class Initialized
INFO - 2023-11-20 20:38:21 --> Language Class Initialized
INFO - 2023-11-20 20:38:21 --> Loader Class Initialized
INFO - 2023-11-20 20:38:21 --> Helper loaded: url_helper
INFO - 2023-11-20 20:38:21 --> Helper loaded: form_helper
INFO - 2023-11-20 20:38:21 --> Helper loaded: file_helper
INFO - 2023-11-20 20:38:21 --> Database Driver Class Initialized
DEBUG - 2023-11-20 20:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 20:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 20:38:21 --> Form Validation Class Initialized
INFO - 2023-11-20 20:38:21 --> Upload Class Initialized
INFO - 2023-11-20 20:38:21 --> Model "M_auth" initialized
INFO - 2023-11-20 20:38:21 --> Model "M_user" initialized
INFO - 2023-11-20 20:38:21 --> Model "M_produk" initialized
INFO - 2023-11-20 20:38:21 --> Controller Class Initialized
INFO - 2023-11-20 20:38:21 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-20 20:38:21 --> Final output sent to browser
DEBUG - 2023-11-20 20:38:21 --> Total execution time: 0.0029
ERROR - 2023-11-20 20:43:47 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 20:43:47 --> Config Class Initialized
INFO - 2023-11-20 20:43:47 --> Hooks Class Initialized
DEBUG - 2023-11-20 20:43:47 --> UTF-8 Support Enabled
INFO - 2023-11-20 20:43:47 --> Utf8 Class Initialized
INFO - 2023-11-20 20:43:47 --> URI Class Initialized
INFO - 2023-11-20 20:43:47 --> Router Class Initialized
INFO - 2023-11-20 20:43:47 --> Output Class Initialized
INFO - 2023-11-20 20:43:47 --> Security Class Initialized
DEBUG - 2023-11-20 20:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 20:43:47 --> Input Class Initialized
INFO - 2023-11-20 20:43:47 --> Language Class Initialized
INFO - 2023-11-20 20:43:47 --> Loader Class Initialized
INFO - 2023-11-20 20:43:47 --> Helper loaded: url_helper
INFO - 2023-11-20 20:43:47 --> Helper loaded: form_helper
INFO - 2023-11-20 20:43:47 --> Helper loaded: file_helper
INFO - 2023-11-20 20:43:47 --> Database Driver Class Initialized
DEBUG - 2023-11-20 20:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 20:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 20:43:47 --> Form Validation Class Initialized
INFO - 2023-11-20 20:43:47 --> Upload Class Initialized
INFO - 2023-11-20 20:43:47 --> Model "M_auth" initialized
INFO - 2023-11-20 20:43:47 --> Model "M_user" initialized
INFO - 2023-11-20 20:43:47 --> Model "M_produk" initialized
INFO - 2023-11-20 20:43:47 --> Controller Class Initialized
INFO - 2023-11-20 20:43:47 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-20 20:43:47 --> Final output sent to browser
DEBUG - 2023-11-20 20:43:47 --> Total execution time: 0.0270
ERROR - 2023-11-20 20:43:49 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-20 20:43:49 --> Config Class Initialized
INFO - 2023-11-20 20:43:49 --> Hooks Class Initialized
DEBUG - 2023-11-20 20:43:49 --> UTF-8 Support Enabled
INFO - 2023-11-20 20:43:49 --> Utf8 Class Initialized
INFO - 2023-11-20 20:43:49 --> URI Class Initialized
DEBUG - 2023-11-20 20:43:49 --> No URI present. Default controller set.
INFO - 2023-11-20 20:43:49 --> Router Class Initialized
INFO - 2023-11-20 20:43:49 --> Output Class Initialized
INFO - 2023-11-20 20:43:49 --> Security Class Initialized
DEBUG - 2023-11-20 20:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-20 20:43:49 --> Input Class Initialized
INFO - 2023-11-20 20:43:49 --> Language Class Initialized
INFO - 2023-11-20 20:43:49 --> Loader Class Initialized
INFO - 2023-11-20 20:43:49 --> Helper loaded: url_helper
INFO - 2023-11-20 20:43:49 --> Helper loaded: form_helper
INFO - 2023-11-20 20:43:49 --> Helper loaded: file_helper
INFO - 2023-11-20 20:43:49 --> Database Driver Class Initialized
DEBUG - 2023-11-20 20:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-20 20:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-20 20:43:49 --> Form Validation Class Initialized
INFO - 2023-11-20 20:43:49 --> Upload Class Initialized
INFO - 2023-11-20 20:43:49 --> Model "M_auth" initialized
INFO - 2023-11-20 20:43:49 --> Model "M_user" initialized
INFO - 2023-11-20 20:43:49 --> Model "M_produk" initialized
INFO - 2023-11-20 20:43:49 --> Controller Class Initialized
INFO - 2023-11-20 20:43:49 --> Model "M_pelanggan" initialized
INFO - 2023-11-20 20:43:49 --> Model "M_produk" initialized
DEBUG - 2023-11-20 20:43:49 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-20 20:43:49 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-20 20:43:49 --> Model "M_transaksi" initialized
INFO - 2023-11-20 20:43:49 --> Model "M_bank" initialized
INFO - 2023-11-20 20:43:49 --> Model "M_pesan" initialized
DEBUG - 2023-11-20 20:43:49 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-20 20:43:49 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-20 20:43:49 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-20 20:43:49 --> Final output sent to browser
DEBUG - 2023-11-20 20:43:49 --> Total execution time: 0.0085
