<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-26 03:03:49 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 03:03:49 --> Config Class Initialized
INFO - 2023-11-26 03:03:49 --> Hooks Class Initialized
DEBUG - 2023-11-26 03:03:49 --> UTF-8 Support Enabled
INFO - 2023-11-26 03:03:49 --> Utf8 Class Initialized
INFO - 2023-11-26 03:03:49 --> URI Class Initialized
DEBUG - 2023-11-26 03:03:49 --> No URI present. Default controller set.
INFO - 2023-11-26 03:03:49 --> Router Class Initialized
INFO - 2023-11-26 03:03:49 --> Output Class Initialized
INFO - 2023-11-26 03:03:49 --> Security Class Initialized
DEBUG - 2023-11-26 03:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 03:03:49 --> Input Class Initialized
INFO - 2023-11-26 03:03:49 --> Language Class Initialized
INFO - 2023-11-26 03:03:49 --> Loader Class Initialized
INFO - 2023-11-26 03:03:49 --> Helper loaded: url_helper
INFO - 2023-11-26 03:03:49 --> Helper loaded: form_helper
INFO - 2023-11-26 03:03:49 --> Helper loaded: file_helper
INFO - 2023-11-26 03:03:49 --> Database Driver Class Initialized
DEBUG - 2023-11-26 03:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 03:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 03:03:49 --> Form Validation Class Initialized
INFO - 2023-11-26 03:03:49 --> Upload Class Initialized
INFO - 2023-11-26 03:03:49 --> Model "M_auth" initialized
INFO - 2023-11-26 03:03:49 --> Model "M_user" initialized
INFO - 2023-11-26 03:03:49 --> Model "M_produk" initialized
INFO - 2023-11-26 03:03:49 --> Controller Class Initialized
INFO - 2023-11-26 03:03:49 --> Model "M_pelanggan" initialized
INFO - 2023-11-26 03:03:49 --> Model "M_produk" initialized
DEBUG - 2023-11-26 03:03:49 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-26 03:03:49 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-26 03:03:49 --> Model "M_transaksi" initialized
INFO - 2023-11-26 03:03:49 --> Model "M_bank" initialized
INFO - 2023-11-26 03:03:49 --> Model "M_pesan" initialized
DEBUG - 2023-11-26 03:03:49 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-26 03:03:49 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-26 03:03:49 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-26 03:03:49 --> Final output sent to browser
DEBUG - 2023-11-26 03:03:49 --> Total execution time: 0.0347
ERROR - 2023-11-26 04:15:23 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 04:15:23 --> Config Class Initialized
INFO - 2023-11-26 04:15:23 --> Hooks Class Initialized
DEBUG - 2023-11-26 04:15:23 --> UTF-8 Support Enabled
INFO - 2023-11-26 04:15:23 --> Utf8 Class Initialized
INFO - 2023-11-26 04:15:23 --> URI Class Initialized
DEBUG - 2023-11-26 04:15:23 --> No URI present. Default controller set.
INFO - 2023-11-26 04:15:23 --> Router Class Initialized
INFO - 2023-11-26 04:15:23 --> Output Class Initialized
INFO - 2023-11-26 04:15:23 --> Security Class Initialized
DEBUG - 2023-11-26 04:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 04:15:23 --> Input Class Initialized
INFO - 2023-11-26 04:15:23 --> Language Class Initialized
INFO - 2023-11-26 04:15:23 --> Loader Class Initialized
INFO - 2023-11-26 04:15:23 --> Helper loaded: url_helper
INFO - 2023-11-26 04:15:23 --> Helper loaded: form_helper
INFO - 2023-11-26 04:15:23 --> Helper loaded: file_helper
INFO - 2023-11-26 04:15:23 --> Database Driver Class Initialized
DEBUG - 2023-11-26 04:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 04:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 04:15:23 --> Form Validation Class Initialized
INFO - 2023-11-26 04:15:23 --> Upload Class Initialized
INFO - 2023-11-26 04:15:23 --> Model "M_auth" initialized
INFO - 2023-11-26 04:15:23 --> Model "M_user" initialized
INFO - 2023-11-26 04:15:23 --> Model "M_produk" initialized
INFO - 2023-11-26 04:15:23 --> Controller Class Initialized
INFO - 2023-11-26 04:15:23 --> Model "M_pelanggan" initialized
INFO - 2023-11-26 04:15:23 --> Model "M_produk" initialized
DEBUG - 2023-11-26 04:15:23 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-26 04:15:23 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-26 04:15:23 --> Model "M_transaksi" initialized
INFO - 2023-11-26 04:15:23 --> Model "M_bank" initialized
INFO - 2023-11-26 04:15:23 --> Model "M_pesan" initialized
DEBUG - 2023-11-26 04:15:23 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-26 04:15:23 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-26 04:15:23 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-26 04:15:23 --> Final output sent to browser
DEBUG - 2023-11-26 04:15:23 --> Total execution time: 0.0311
ERROR - 2023-11-26 05:02:34 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 05:02:34 --> Config Class Initialized
INFO - 2023-11-26 05:02:34 --> Hooks Class Initialized
DEBUG - 2023-11-26 05:02:34 --> UTF-8 Support Enabled
INFO - 2023-11-26 05:02:34 --> Utf8 Class Initialized
INFO - 2023-11-26 05:02:34 --> URI Class Initialized
DEBUG - 2023-11-26 05:02:34 --> No URI present. Default controller set.
INFO - 2023-11-26 05:02:34 --> Router Class Initialized
INFO - 2023-11-26 05:02:34 --> Output Class Initialized
INFO - 2023-11-26 05:02:34 --> Security Class Initialized
DEBUG - 2023-11-26 05:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 05:02:34 --> Input Class Initialized
INFO - 2023-11-26 05:02:34 --> Language Class Initialized
INFO - 2023-11-26 05:02:34 --> Loader Class Initialized
INFO - 2023-11-26 05:02:34 --> Helper loaded: url_helper
INFO - 2023-11-26 05:02:34 --> Helper loaded: form_helper
INFO - 2023-11-26 05:02:34 --> Helper loaded: file_helper
INFO - 2023-11-26 05:02:34 --> Database Driver Class Initialized
DEBUG - 2023-11-26 05:02:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 05:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 05:02:34 --> Form Validation Class Initialized
INFO - 2023-11-26 05:02:34 --> Upload Class Initialized
INFO - 2023-11-26 05:02:34 --> Model "M_auth" initialized
INFO - 2023-11-26 05:02:34 --> Model "M_user" initialized
INFO - 2023-11-26 05:02:34 --> Model "M_produk" initialized
INFO - 2023-11-26 05:02:34 --> Controller Class Initialized
INFO - 2023-11-26 05:02:34 --> Model "M_pelanggan" initialized
INFO - 2023-11-26 05:02:34 --> Model "M_produk" initialized
DEBUG - 2023-11-26 05:02:34 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-26 05:02:34 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-26 05:02:34 --> Model "M_transaksi" initialized
INFO - 2023-11-26 05:02:34 --> Model "M_bank" initialized
INFO - 2023-11-26 05:02:34 --> Model "M_pesan" initialized
DEBUG - 2023-11-26 05:02:34 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-26 05:02:34 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-26 05:02:34 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-26 05:02:34 --> Final output sent to browser
DEBUG - 2023-11-26 05:02:34 --> Total execution time: 0.0337
ERROR - 2023-11-26 05:02:35 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 05:02:35 --> Config Class Initialized
INFO - 2023-11-26 05:02:35 --> Hooks Class Initialized
DEBUG - 2023-11-26 05:02:35 --> UTF-8 Support Enabled
INFO - 2023-11-26 05:02:35 --> Utf8 Class Initialized
INFO - 2023-11-26 05:02:35 --> URI Class Initialized
INFO - 2023-11-26 05:02:35 --> Router Class Initialized
INFO - 2023-11-26 05:02:35 --> Output Class Initialized
INFO - 2023-11-26 05:02:35 --> Security Class Initialized
DEBUG - 2023-11-26 05:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 05:02:35 --> Input Class Initialized
INFO - 2023-11-26 05:02:35 --> Language Class Initialized
INFO - 2023-11-26 05:02:35 --> Loader Class Initialized
INFO - 2023-11-26 05:02:35 --> Helper loaded: url_helper
INFO - 2023-11-26 05:02:35 --> Helper loaded: form_helper
INFO - 2023-11-26 05:02:35 --> Helper loaded: file_helper
INFO - 2023-11-26 05:02:35 --> Database Driver Class Initialized
DEBUG - 2023-11-26 05:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 05:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 05:02:35 --> Form Validation Class Initialized
INFO - 2023-11-26 05:02:35 --> Upload Class Initialized
INFO - 2023-11-26 05:02:35 --> Model "M_auth" initialized
INFO - 2023-11-26 05:02:35 --> Model "M_user" initialized
INFO - 2023-11-26 05:02:35 --> Model "M_produk" initialized
INFO - 2023-11-26 05:02:35 --> Controller Class Initialized
INFO - 2023-11-26 05:02:35 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-26 05:02:35 --> Final output sent to browser
DEBUG - 2023-11-26 05:02:35 --> Total execution time: 0.0025
ERROR - 2023-11-26 05:02:36 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 05:02:36 --> Config Class Initialized
INFO - 2023-11-26 05:02:36 --> Hooks Class Initialized
DEBUG - 2023-11-26 05:02:36 --> UTF-8 Support Enabled
INFO - 2023-11-26 05:02:36 --> Utf8 Class Initialized
INFO - 2023-11-26 05:02:36 --> URI Class Initialized
INFO - 2023-11-26 05:02:36 --> Router Class Initialized
INFO - 2023-11-26 05:02:36 --> Output Class Initialized
INFO - 2023-11-26 05:02:36 --> Security Class Initialized
DEBUG - 2023-11-26 05:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 05:02:36 --> Input Class Initialized
INFO - 2023-11-26 05:02:36 --> Language Class Initialized
INFO - 2023-11-26 05:02:36 --> Loader Class Initialized
INFO - 2023-11-26 05:02:36 --> Helper loaded: url_helper
INFO - 2023-11-26 05:02:36 --> Helper loaded: form_helper
INFO - 2023-11-26 05:02:36 --> Helper loaded: file_helper
INFO - 2023-11-26 05:02:36 --> Database Driver Class Initialized
DEBUG - 2023-11-26 05:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 05:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 05:02:36 --> Form Validation Class Initialized
INFO - 2023-11-26 05:02:36 --> Upload Class Initialized
INFO - 2023-11-26 05:02:36 --> Model "M_auth" initialized
INFO - 2023-11-26 05:02:36 --> Model "M_user" initialized
INFO - 2023-11-26 05:02:36 --> Model "M_produk" initialized
INFO - 2023-11-26 05:02:36 --> Controller Class Initialized
INFO - 2023-11-26 05:02:36 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-26 05:02:36 --> Final output sent to browser
DEBUG - 2023-11-26 05:02:36 --> Total execution time: 0.0026
ERROR - 2023-11-26 05:02:37 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 05:02:37 --> Config Class Initialized
INFO - 2023-11-26 05:02:37 --> Hooks Class Initialized
DEBUG - 2023-11-26 05:02:37 --> UTF-8 Support Enabled
INFO - 2023-11-26 05:02:37 --> Utf8 Class Initialized
INFO - 2023-11-26 05:02:37 --> URI Class Initialized
DEBUG - 2023-11-26 05:02:37 --> No URI present. Default controller set.
INFO - 2023-11-26 05:02:37 --> Router Class Initialized
INFO - 2023-11-26 05:02:37 --> Output Class Initialized
INFO - 2023-11-26 05:02:37 --> Security Class Initialized
DEBUG - 2023-11-26 05:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 05:02:37 --> Input Class Initialized
INFO - 2023-11-26 05:02:37 --> Language Class Initialized
INFO - 2023-11-26 05:02:37 --> Loader Class Initialized
INFO - 2023-11-26 05:02:37 --> Helper loaded: url_helper
INFO - 2023-11-26 05:02:37 --> Helper loaded: form_helper
INFO - 2023-11-26 05:02:37 --> Helper loaded: file_helper
INFO - 2023-11-26 05:02:37 --> Database Driver Class Initialized
DEBUG - 2023-11-26 05:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 05:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 05:02:37 --> Form Validation Class Initialized
INFO - 2023-11-26 05:02:37 --> Upload Class Initialized
INFO - 2023-11-26 05:02:37 --> Model "M_auth" initialized
INFO - 2023-11-26 05:02:37 --> Model "M_user" initialized
INFO - 2023-11-26 05:02:37 --> Model "M_produk" initialized
INFO - 2023-11-26 05:02:37 --> Controller Class Initialized
INFO - 2023-11-26 05:02:37 --> Model "M_pelanggan" initialized
INFO - 2023-11-26 05:02:37 --> Model "M_produk" initialized
DEBUG - 2023-11-26 05:02:37 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-26 05:02:37 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-26 05:02:37 --> Model "M_transaksi" initialized
INFO - 2023-11-26 05:02:37 --> Model "M_bank" initialized
INFO - 2023-11-26 05:02:37 --> Model "M_pesan" initialized
DEBUG - 2023-11-26 05:02:37 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-26 05:02:37 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-26 05:02:37 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-26 05:02:37 --> Final output sent to browser
DEBUG - 2023-11-26 05:02:37 --> Total execution time: 0.0035
ERROR - 2023-11-26 05:02:38 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 05:02:38 --> Config Class Initialized
INFO - 2023-11-26 05:02:38 --> Hooks Class Initialized
DEBUG - 2023-11-26 05:02:38 --> UTF-8 Support Enabled
INFO - 2023-11-26 05:02:38 --> Utf8 Class Initialized
INFO - 2023-11-26 05:02:38 --> URI Class Initialized
INFO - 2023-11-26 05:02:38 --> Router Class Initialized
INFO - 2023-11-26 05:02:38 --> Output Class Initialized
INFO - 2023-11-26 05:02:38 --> Security Class Initialized
DEBUG - 2023-11-26 05:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 05:02:38 --> Input Class Initialized
INFO - 2023-11-26 05:02:38 --> Language Class Initialized
INFO - 2023-11-26 05:02:38 --> Loader Class Initialized
INFO - 2023-11-26 05:02:38 --> Helper loaded: url_helper
INFO - 2023-11-26 05:02:38 --> Helper loaded: form_helper
INFO - 2023-11-26 05:02:38 --> Helper loaded: file_helper
INFO - 2023-11-26 05:02:38 --> Database Driver Class Initialized
DEBUG - 2023-11-26 05:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 05:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 05:02:38 --> Form Validation Class Initialized
INFO - 2023-11-26 05:02:38 --> Upload Class Initialized
INFO - 2023-11-26 05:02:38 --> Model "M_auth" initialized
INFO - 2023-11-26 05:02:38 --> Model "M_user" initialized
INFO - 2023-11-26 05:02:38 --> Model "M_produk" initialized
INFO - 2023-11-26 05:02:38 --> Controller Class Initialized
INFO - 2023-11-26 05:02:38 --> Model "M_pelanggan" initialized
INFO - 2023-11-26 05:02:38 --> Model "M_produk" initialized
DEBUG - 2023-11-26 05:02:38 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-26 05:02:38 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-26 05:02:38 --> Model "M_transaksi" initialized
INFO - 2023-11-26 05:02:38 --> Model "M_bank" initialized
INFO - 2023-11-26 05:02:38 --> Model "M_pesan" initialized
DEBUG - 2023-11-26 05:02:38 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-26 05:02:38 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-26 05:02:38 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-26 05:02:38 --> Final output sent to browser
DEBUG - 2023-11-26 05:02:38 --> Total execution time: 0.0051
ERROR - 2023-11-26 05:02:39 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 05:02:39 --> Config Class Initialized
INFO - 2023-11-26 05:02:39 --> Hooks Class Initialized
DEBUG - 2023-11-26 05:02:39 --> UTF-8 Support Enabled
INFO - 2023-11-26 05:02:39 --> Utf8 Class Initialized
INFO - 2023-11-26 05:02:39 --> URI Class Initialized
INFO - 2023-11-26 05:02:39 --> Router Class Initialized
INFO - 2023-11-26 05:02:39 --> Output Class Initialized
INFO - 2023-11-26 05:02:39 --> Security Class Initialized
DEBUG - 2023-11-26 05:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 05:02:39 --> Input Class Initialized
INFO - 2023-11-26 05:02:39 --> Language Class Initialized
INFO - 2023-11-26 05:02:39 --> Loader Class Initialized
INFO - 2023-11-26 05:02:39 --> Helper loaded: url_helper
INFO - 2023-11-26 05:02:39 --> Helper loaded: form_helper
INFO - 2023-11-26 05:02:39 --> Helper loaded: file_helper
INFO - 2023-11-26 05:02:39 --> Database Driver Class Initialized
DEBUG - 2023-11-26 05:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 05:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 05:02:39 --> Form Validation Class Initialized
INFO - 2023-11-26 05:02:39 --> Upload Class Initialized
INFO - 2023-11-26 05:02:39 --> Model "M_auth" initialized
INFO - 2023-11-26 05:02:39 --> Model "M_user" initialized
INFO - 2023-11-26 05:02:39 --> Model "M_produk" initialized
INFO - 2023-11-26 05:02:39 --> Controller Class Initialized
INFO - 2023-11-26 05:02:39 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-26 05:02:39 --> Final output sent to browser
DEBUG - 2023-11-26 05:02:39 --> Total execution time: 0.0023
ERROR - 2023-11-26 05:02:40 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 05:02:40 --> Config Class Initialized
INFO - 2023-11-26 05:02:40 --> Hooks Class Initialized
DEBUG - 2023-11-26 05:02:40 --> UTF-8 Support Enabled
INFO - 2023-11-26 05:02:40 --> Utf8 Class Initialized
INFO - 2023-11-26 05:02:40 --> URI Class Initialized
INFO - 2023-11-26 05:02:40 --> Router Class Initialized
INFO - 2023-11-26 05:02:40 --> Output Class Initialized
INFO - 2023-11-26 05:02:40 --> Security Class Initialized
DEBUG - 2023-11-26 05:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 05:02:40 --> Input Class Initialized
INFO - 2023-11-26 05:02:40 --> Language Class Initialized
INFO - 2023-11-26 05:02:40 --> Loader Class Initialized
INFO - 2023-11-26 05:02:40 --> Helper loaded: url_helper
INFO - 2023-11-26 05:02:40 --> Helper loaded: form_helper
INFO - 2023-11-26 05:02:40 --> Helper loaded: file_helper
INFO - 2023-11-26 05:02:40 --> Database Driver Class Initialized
DEBUG - 2023-11-26 05:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 05:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 05:02:40 --> Form Validation Class Initialized
INFO - 2023-11-26 05:02:40 --> Upload Class Initialized
INFO - 2023-11-26 05:02:40 --> Model "M_auth" initialized
INFO - 2023-11-26 05:02:40 --> Model "M_user" initialized
INFO - 2023-11-26 05:02:40 --> Model "M_produk" initialized
INFO - 2023-11-26 05:02:40 --> Controller Class Initialized
INFO - 2023-11-26 05:02:40 --> Model "M_pelanggan" initialized
INFO - 2023-11-26 05:02:40 --> Model "M_produk" initialized
DEBUG - 2023-11-26 05:02:40 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-26 05:02:40 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-26 05:02:40 --> Model "M_transaksi" initialized
INFO - 2023-11-26 05:02:40 --> Model "M_bank" initialized
INFO - 2023-11-26 05:02:40 --> Model "M_pesan" initialized
DEBUG - 2023-11-26 05:02:40 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-26 05:02:40 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-26 05:02:40 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_kategori_detail.php
INFO - 2023-11-26 05:02:40 --> Final output sent to browser
DEBUG - 2023-11-26 05:02:40 --> Total execution time: 0.0049
ERROR - 2023-11-26 05:02:41 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 05:02:41 --> Config Class Initialized
INFO - 2023-11-26 05:02:41 --> Hooks Class Initialized
DEBUG - 2023-11-26 05:02:41 --> UTF-8 Support Enabled
INFO - 2023-11-26 05:02:41 --> Utf8 Class Initialized
INFO - 2023-11-26 05:02:41 --> URI Class Initialized
INFO - 2023-11-26 05:02:41 --> Router Class Initialized
INFO - 2023-11-26 05:02:41 --> Output Class Initialized
INFO - 2023-11-26 05:02:41 --> Security Class Initialized
DEBUG - 2023-11-26 05:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 05:02:41 --> Input Class Initialized
INFO - 2023-11-26 05:02:41 --> Language Class Initialized
INFO - 2023-11-26 05:02:41 --> Loader Class Initialized
INFO - 2023-11-26 05:02:41 --> Helper loaded: url_helper
INFO - 2023-11-26 05:02:41 --> Helper loaded: form_helper
INFO - 2023-11-26 05:02:41 --> Helper loaded: file_helper
INFO - 2023-11-26 05:02:41 --> Database Driver Class Initialized
DEBUG - 2023-11-26 05:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 05:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 05:02:41 --> Form Validation Class Initialized
INFO - 2023-11-26 05:02:41 --> Upload Class Initialized
INFO - 2023-11-26 05:02:41 --> Model "M_auth" initialized
INFO - 2023-11-26 05:02:41 --> Model "M_user" initialized
INFO - 2023-11-26 05:02:41 --> Model "M_produk" initialized
INFO - 2023-11-26 05:02:41 --> Controller Class Initialized
INFO - 2023-11-26 05:02:41 --> Model "M_pelanggan" initialized
INFO - 2023-11-26 05:02:41 --> Model "M_produk" initialized
DEBUG - 2023-11-26 05:02:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-26 05:02:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-26 05:02:41 --> Model "M_transaksi" initialized
INFO - 2023-11-26 05:02:41 --> Model "M_bank" initialized
INFO - 2023-11-26 05:02:41 --> Model "M_pesan" initialized
DEBUG - 2023-11-26 05:02:41 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
ERROR - 2023-11-26 05:02:41 --> Severity: Warning --> Attempt to read property "nama_merek" on null /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_kategori_detail.php 112
INFO - 2023-11-26 05:02:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-26 05:02:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_kategori_detail.php
INFO - 2023-11-26 05:02:41 --> Final output sent to browser
DEBUG - 2023-11-26 05:02:41 --> Total execution time: 0.0043
ERROR - 2023-11-26 05:02:42 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 05:02:42 --> Config Class Initialized
INFO - 2023-11-26 05:02:42 --> Hooks Class Initialized
DEBUG - 2023-11-26 05:02:42 --> UTF-8 Support Enabled
INFO - 2023-11-26 05:02:42 --> Utf8 Class Initialized
INFO - 2023-11-26 05:02:42 --> URI Class Initialized
INFO - 2023-11-26 05:02:42 --> Router Class Initialized
INFO - 2023-11-26 05:02:42 --> Output Class Initialized
INFO - 2023-11-26 05:02:42 --> Security Class Initialized
DEBUG - 2023-11-26 05:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 05:02:42 --> Input Class Initialized
INFO - 2023-11-26 05:02:42 --> Language Class Initialized
INFO - 2023-11-26 05:02:42 --> Loader Class Initialized
INFO - 2023-11-26 05:02:42 --> Helper loaded: url_helper
INFO - 2023-11-26 05:02:42 --> Helper loaded: form_helper
INFO - 2023-11-26 05:02:42 --> Helper loaded: file_helper
INFO - 2023-11-26 05:02:42 --> Database Driver Class Initialized
DEBUG - 2023-11-26 05:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 05:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 05:02:42 --> Form Validation Class Initialized
INFO - 2023-11-26 05:02:42 --> Upload Class Initialized
INFO - 2023-11-26 05:02:42 --> Model "M_auth" initialized
INFO - 2023-11-26 05:02:42 --> Model "M_user" initialized
INFO - 2023-11-26 05:02:42 --> Model "M_produk" initialized
INFO - 2023-11-26 05:02:42 --> Controller Class Initialized
INFO - 2023-11-26 05:02:42 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-26 05:02:42 --> Final output sent to browser
DEBUG - 2023-11-26 05:02:42 --> Total execution time: 0.0026
ERROR - 2023-11-26 05:02:43 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 05:02:43 --> Config Class Initialized
INFO - 2023-11-26 05:02:43 --> Hooks Class Initialized
DEBUG - 2023-11-26 05:02:43 --> UTF-8 Support Enabled
INFO - 2023-11-26 05:02:43 --> Utf8 Class Initialized
INFO - 2023-11-26 05:02:43 --> URI Class Initialized
DEBUG - 2023-11-26 05:02:43 --> No URI present. Default controller set.
INFO - 2023-11-26 05:02:43 --> Router Class Initialized
INFO - 2023-11-26 05:02:43 --> Output Class Initialized
INFO - 2023-11-26 05:02:43 --> Security Class Initialized
DEBUG - 2023-11-26 05:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 05:02:43 --> Input Class Initialized
INFO - 2023-11-26 05:02:43 --> Language Class Initialized
INFO - 2023-11-26 05:02:43 --> Loader Class Initialized
INFO - 2023-11-26 05:02:43 --> Helper loaded: url_helper
INFO - 2023-11-26 05:02:43 --> Helper loaded: form_helper
INFO - 2023-11-26 05:02:43 --> Helper loaded: file_helper
INFO - 2023-11-26 05:02:43 --> Database Driver Class Initialized
DEBUG - 2023-11-26 05:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 05:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 05:02:43 --> Form Validation Class Initialized
INFO - 2023-11-26 05:02:43 --> Upload Class Initialized
INFO - 2023-11-26 05:02:43 --> Model "M_auth" initialized
INFO - 2023-11-26 05:02:43 --> Model "M_user" initialized
INFO - 2023-11-26 05:02:43 --> Model "M_produk" initialized
INFO - 2023-11-26 05:02:43 --> Controller Class Initialized
INFO - 2023-11-26 05:02:43 --> Model "M_pelanggan" initialized
INFO - 2023-11-26 05:02:43 --> Model "M_produk" initialized
DEBUG - 2023-11-26 05:02:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-26 05:02:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-26 05:02:43 --> Model "M_transaksi" initialized
INFO - 2023-11-26 05:02:43 --> Model "M_bank" initialized
INFO - 2023-11-26 05:02:43 --> Model "M_pesan" initialized
DEBUG - 2023-11-26 05:02:43 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-26 05:02:43 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-26 05:02:43 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-26 05:02:43 --> Final output sent to browser
DEBUG - 2023-11-26 05:02:43 --> Total execution time: 0.0040
ERROR - 2023-11-26 05:02:43 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 05:02:43 --> Config Class Initialized
INFO - 2023-11-26 05:02:43 --> Hooks Class Initialized
DEBUG - 2023-11-26 05:02:43 --> UTF-8 Support Enabled
INFO - 2023-11-26 05:02:43 --> Utf8 Class Initialized
INFO - 2023-11-26 05:02:43 --> URI Class Initialized
INFO - 2023-11-26 05:02:43 --> Router Class Initialized
INFO - 2023-11-26 05:02:43 --> Output Class Initialized
INFO - 2023-11-26 05:02:43 --> Security Class Initialized
DEBUG - 2023-11-26 05:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 05:02:43 --> Input Class Initialized
INFO - 2023-11-26 05:02:43 --> Language Class Initialized
INFO - 2023-11-26 05:02:43 --> Loader Class Initialized
INFO - 2023-11-26 05:02:43 --> Helper loaded: url_helper
INFO - 2023-11-26 05:02:43 --> Helper loaded: form_helper
INFO - 2023-11-26 05:02:43 --> Helper loaded: file_helper
INFO - 2023-11-26 05:02:43 --> Database Driver Class Initialized
DEBUG - 2023-11-26 05:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 05:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 05:02:43 --> Form Validation Class Initialized
INFO - 2023-11-26 05:02:43 --> Upload Class Initialized
INFO - 2023-11-26 05:02:43 --> Model "M_auth" initialized
INFO - 2023-11-26 05:02:43 --> Model "M_user" initialized
INFO - 2023-11-26 05:02:43 --> Model "M_produk" initialized
INFO - 2023-11-26 05:02:43 --> Controller Class Initialized
INFO - 2023-11-26 05:02:43 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-26 05:02:43 --> Final output sent to browser
DEBUG - 2023-11-26 05:02:43 --> Total execution time: 0.0022
ERROR - 2023-11-26 05:02:44 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 05:02:44 --> Config Class Initialized
INFO - 2023-11-26 05:02:44 --> Hooks Class Initialized
DEBUG - 2023-11-26 05:02:44 --> UTF-8 Support Enabled
INFO - 2023-11-26 05:02:44 --> Utf8 Class Initialized
INFO - 2023-11-26 05:02:44 --> URI Class Initialized
INFO - 2023-11-26 05:02:44 --> Router Class Initialized
INFO - 2023-11-26 05:02:44 --> Output Class Initialized
INFO - 2023-11-26 05:02:44 --> Security Class Initialized
DEBUG - 2023-11-26 05:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 05:02:44 --> Input Class Initialized
INFO - 2023-11-26 05:02:44 --> Language Class Initialized
INFO - 2023-11-26 05:02:44 --> Loader Class Initialized
INFO - 2023-11-26 05:02:44 --> Helper loaded: url_helper
INFO - 2023-11-26 05:02:44 --> Helper loaded: form_helper
INFO - 2023-11-26 05:02:44 --> Helper loaded: file_helper
INFO - 2023-11-26 05:02:44 --> Database Driver Class Initialized
DEBUG - 2023-11-26 05:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 05:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 05:02:44 --> Form Validation Class Initialized
INFO - 2023-11-26 05:02:44 --> Upload Class Initialized
INFO - 2023-11-26 05:02:44 --> Model "M_auth" initialized
INFO - 2023-11-26 05:02:44 --> Model "M_user" initialized
INFO - 2023-11-26 05:02:44 --> Model "M_produk" initialized
INFO - 2023-11-26 05:02:44 --> Controller Class Initialized
INFO - 2023-11-26 05:02:44 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-26 05:02:44 --> Final output sent to browser
DEBUG - 2023-11-26 05:02:44 --> Total execution time: 0.0025
ERROR - 2023-11-26 05:03:13 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 05:03:13 --> Config Class Initialized
INFO - 2023-11-26 05:03:13 --> Hooks Class Initialized
DEBUG - 2023-11-26 05:03:13 --> UTF-8 Support Enabled
INFO - 2023-11-26 05:03:13 --> Utf8 Class Initialized
INFO - 2023-11-26 05:03:13 --> URI Class Initialized
DEBUG - 2023-11-26 05:03:13 --> No URI present. Default controller set.
INFO - 2023-11-26 05:03:13 --> Router Class Initialized
INFO - 2023-11-26 05:03:13 --> Output Class Initialized
INFO - 2023-11-26 05:03:13 --> Security Class Initialized
DEBUG - 2023-11-26 05:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 05:03:13 --> Input Class Initialized
INFO - 2023-11-26 05:03:13 --> Language Class Initialized
INFO - 2023-11-26 05:03:13 --> Loader Class Initialized
INFO - 2023-11-26 05:03:13 --> Helper loaded: url_helper
INFO - 2023-11-26 05:03:13 --> Helper loaded: form_helper
INFO - 2023-11-26 05:03:13 --> Helper loaded: file_helper
INFO - 2023-11-26 05:03:13 --> Database Driver Class Initialized
DEBUG - 2023-11-26 05:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 05:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 05:03:13 --> Form Validation Class Initialized
INFO - 2023-11-26 05:03:13 --> Upload Class Initialized
INFO - 2023-11-26 05:03:13 --> Model "M_auth" initialized
INFO - 2023-11-26 05:03:13 --> Model "M_user" initialized
INFO - 2023-11-26 05:03:13 --> Model "M_produk" initialized
INFO - 2023-11-26 05:03:13 --> Controller Class Initialized
INFO - 2023-11-26 05:03:13 --> Model "M_pelanggan" initialized
INFO - 2023-11-26 05:03:13 --> Model "M_produk" initialized
DEBUG - 2023-11-26 05:03:13 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-26 05:03:13 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-26 05:03:13 --> Model "M_transaksi" initialized
INFO - 2023-11-26 05:03:13 --> Model "M_bank" initialized
INFO - 2023-11-26 05:03:13 --> Model "M_pesan" initialized
DEBUG - 2023-11-26 05:03:13 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-26 05:03:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-26 05:03:13 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-26 05:03:13 --> Final output sent to browser
DEBUG - 2023-11-26 05:03:13 --> Total execution time: 0.0038
ERROR - 2023-11-26 05:50:19 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 05:50:19 --> Config Class Initialized
INFO - 2023-11-26 05:50:19 --> Hooks Class Initialized
DEBUG - 2023-11-26 05:50:19 --> UTF-8 Support Enabled
INFO - 2023-11-26 05:50:19 --> Utf8 Class Initialized
INFO - 2023-11-26 05:50:19 --> URI Class Initialized
DEBUG - 2023-11-26 05:50:19 --> No URI present. Default controller set.
INFO - 2023-11-26 05:50:19 --> Router Class Initialized
INFO - 2023-11-26 05:50:19 --> Output Class Initialized
INFO - 2023-11-26 05:50:19 --> Security Class Initialized
DEBUG - 2023-11-26 05:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 05:50:19 --> Input Class Initialized
INFO - 2023-11-26 05:50:19 --> Language Class Initialized
INFO - 2023-11-26 05:50:19 --> Loader Class Initialized
INFO - 2023-11-26 05:50:19 --> Helper loaded: url_helper
INFO - 2023-11-26 05:50:19 --> Helper loaded: form_helper
INFO - 2023-11-26 05:50:19 --> Helper loaded: file_helper
INFO - 2023-11-26 05:50:19 --> Database Driver Class Initialized
DEBUG - 2023-11-26 05:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 05:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 05:50:19 --> Form Validation Class Initialized
INFO - 2023-11-26 05:50:19 --> Upload Class Initialized
INFO - 2023-11-26 05:50:19 --> Model "M_auth" initialized
INFO - 2023-11-26 05:50:19 --> Model "M_user" initialized
INFO - 2023-11-26 05:50:19 --> Model "M_produk" initialized
INFO - 2023-11-26 05:50:19 --> Controller Class Initialized
INFO - 2023-11-26 05:50:19 --> Model "M_pelanggan" initialized
INFO - 2023-11-26 05:50:19 --> Model "M_produk" initialized
DEBUG - 2023-11-26 05:50:19 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-26 05:50:19 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-26 05:50:19 --> Model "M_transaksi" initialized
INFO - 2023-11-26 05:50:19 --> Model "M_bank" initialized
INFO - 2023-11-26 05:50:19 --> Model "M_pesan" initialized
DEBUG - 2023-11-26 05:50:19 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-26 05:50:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-26 05:50:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-26 05:50:19 --> Final output sent to browser
DEBUG - 2023-11-26 05:50:19 --> Total execution time: 0.0303
ERROR - 2023-11-26 06:27:59 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 06:27:59 --> Config Class Initialized
INFO - 2023-11-26 06:27:59 --> Hooks Class Initialized
DEBUG - 2023-11-26 06:27:59 --> UTF-8 Support Enabled
INFO - 2023-11-26 06:27:59 --> Utf8 Class Initialized
INFO - 2023-11-26 06:27:59 --> URI Class Initialized
INFO - 2023-11-26 06:27:59 --> Router Class Initialized
INFO - 2023-11-26 06:27:59 --> Output Class Initialized
INFO - 2023-11-26 06:27:59 --> Security Class Initialized
DEBUG - 2023-11-26 06:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 06:27:59 --> Input Class Initialized
INFO - 2023-11-26 06:27:59 --> Language Class Initialized
INFO - 2023-11-26 06:27:59 --> Loader Class Initialized
INFO - 2023-11-26 06:27:59 --> Helper loaded: url_helper
INFO - 2023-11-26 06:27:59 --> Helper loaded: form_helper
INFO - 2023-11-26 06:27:59 --> Helper loaded: file_helper
INFO - 2023-11-26 06:27:59 --> Database Driver Class Initialized
DEBUG - 2023-11-26 06:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 06:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 06:27:59 --> Form Validation Class Initialized
INFO - 2023-11-26 06:27:59 --> Upload Class Initialized
INFO - 2023-11-26 06:27:59 --> Model "M_auth" initialized
INFO - 2023-11-26 06:27:59 --> Model "M_user" initialized
INFO - 2023-11-26 06:27:59 --> Model "M_produk" initialized
INFO - 2023-11-26 06:27:59 --> Controller Class Initialized
INFO - 2023-11-26 06:27:59 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-26 06:27:59 --> Final output sent to browser
DEBUG - 2023-11-26 06:27:59 --> Total execution time: 0.0248
ERROR - 2023-11-26 07:22:23 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 07:22:23 --> Config Class Initialized
INFO - 2023-11-26 07:22:23 --> Hooks Class Initialized
DEBUG - 2023-11-26 07:22:23 --> UTF-8 Support Enabled
INFO - 2023-11-26 07:22:23 --> Utf8 Class Initialized
INFO - 2023-11-26 07:22:24 --> URI Class Initialized
INFO - 2023-11-26 07:22:24 --> Router Class Initialized
INFO - 2023-11-26 07:22:24 --> Output Class Initialized
INFO - 2023-11-26 07:22:24 --> Security Class Initialized
DEBUG - 2023-11-26 07:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 07:22:24 --> Input Class Initialized
INFO - 2023-11-26 07:22:24 --> Language Class Initialized
INFO - 2023-11-26 07:22:24 --> Loader Class Initialized
INFO - 2023-11-26 07:22:24 --> Helper loaded: url_helper
INFO - 2023-11-26 07:22:24 --> Helper loaded: form_helper
INFO - 2023-11-26 07:22:24 --> Helper loaded: file_helper
INFO - 2023-11-26 07:22:24 --> Database Driver Class Initialized
DEBUG - 2023-11-26 07:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 07:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 07:22:24 --> Form Validation Class Initialized
INFO - 2023-11-26 07:22:24 --> Upload Class Initialized
INFO - 2023-11-26 07:22:24 --> Model "M_auth" initialized
INFO - 2023-11-26 07:22:24 --> Model "M_user" initialized
INFO - 2023-11-26 07:22:24 --> Model "M_produk" initialized
INFO - 2023-11-26 07:22:24 --> Controller Class Initialized
INFO - 2023-11-26 07:22:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-26 07:22:24 --> Final output sent to browser
DEBUG - 2023-11-26 07:22:24 --> Total execution time: 0.0246
ERROR - 2023-11-26 07:22:24 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 07:22:24 --> Config Class Initialized
INFO - 2023-11-26 07:22:24 --> Hooks Class Initialized
DEBUG - 2023-11-26 07:22:24 --> UTF-8 Support Enabled
INFO - 2023-11-26 07:22:24 --> Utf8 Class Initialized
INFO - 2023-11-26 07:22:24 --> URI Class Initialized
DEBUG - 2023-11-26 07:22:24 --> No URI present. Default controller set.
INFO - 2023-11-26 07:22:24 --> Router Class Initialized
INFO - 2023-11-26 07:22:24 --> Output Class Initialized
INFO - 2023-11-26 07:22:24 --> Security Class Initialized
DEBUG - 2023-11-26 07:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 07:22:24 --> Input Class Initialized
INFO - 2023-11-26 07:22:24 --> Language Class Initialized
INFO - 2023-11-26 07:22:24 --> Loader Class Initialized
INFO - 2023-11-26 07:22:24 --> Helper loaded: url_helper
INFO - 2023-11-26 07:22:24 --> Helper loaded: form_helper
INFO - 2023-11-26 07:22:24 --> Helper loaded: file_helper
INFO - 2023-11-26 07:22:24 --> Database Driver Class Initialized
DEBUG - 2023-11-26 07:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 07:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 07:22:24 --> Form Validation Class Initialized
INFO - 2023-11-26 07:22:24 --> Upload Class Initialized
INFO - 2023-11-26 07:22:24 --> Model "M_auth" initialized
INFO - 2023-11-26 07:22:24 --> Model "M_user" initialized
INFO - 2023-11-26 07:22:24 --> Model "M_produk" initialized
INFO - 2023-11-26 07:22:24 --> Controller Class Initialized
INFO - 2023-11-26 07:22:24 --> Model "M_pelanggan" initialized
INFO - 2023-11-26 07:22:24 --> Model "M_produk" initialized
DEBUG - 2023-11-26 07:22:24 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-26 07:22:24 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-26 07:22:24 --> Model "M_transaksi" initialized
INFO - 2023-11-26 07:22:24 --> Model "M_bank" initialized
INFO - 2023-11-26 07:22:24 --> Model "M_pesan" initialized
DEBUG - 2023-11-26 07:22:24 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-26 07:22:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-26 07:22:24 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-26 07:22:24 --> Final output sent to browser
DEBUG - 2023-11-26 07:22:24 --> Total execution time: 0.0093
ERROR - 2023-11-26 08:48:28 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 08:48:28 --> Config Class Initialized
INFO - 2023-11-26 08:48:28 --> Hooks Class Initialized
DEBUG - 2023-11-26 08:48:28 --> UTF-8 Support Enabled
INFO - 2023-11-26 08:48:28 --> Utf8 Class Initialized
INFO - 2023-11-26 08:48:28 --> URI Class Initialized
DEBUG - 2023-11-26 08:48:28 --> No URI present. Default controller set.
INFO - 2023-11-26 08:48:28 --> Router Class Initialized
INFO - 2023-11-26 08:48:28 --> Output Class Initialized
INFO - 2023-11-26 08:48:28 --> Security Class Initialized
DEBUG - 2023-11-26 08:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 08:48:28 --> Input Class Initialized
INFO - 2023-11-26 08:48:28 --> Language Class Initialized
INFO - 2023-11-26 08:48:28 --> Loader Class Initialized
INFO - 2023-11-26 08:48:28 --> Helper loaded: url_helper
INFO - 2023-11-26 08:48:28 --> Helper loaded: form_helper
INFO - 2023-11-26 08:48:28 --> Helper loaded: file_helper
INFO - 2023-11-26 08:48:28 --> Database Driver Class Initialized
DEBUG - 2023-11-26 08:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 08:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 08:48:28 --> Form Validation Class Initialized
INFO - 2023-11-26 08:48:28 --> Upload Class Initialized
INFO - 2023-11-26 08:48:28 --> Model "M_auth" initialized
INFO - 2023-11-26 08:48:28 --> Model "M_user" initialized
INFO - 2023-11-26 08:48:28 --> Model "M_produk" initialized
INFO - 2023-11-26 08:48:28 --> Controller Class Initialized
INFO - 2023-11-26 08:48:28 --> Model "M_pelanggan" initialized
INFO - 2023-11-26 08:48:28 --> Model "M_produk" initialized
DEBUG - 2023-11-26 08:48:28 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-26 08:48:28 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-26 08:48:28 --> Model "M_transaksi" initialized
INFO - 2023-11-26 08:48:28 --> Model "M_bank" initialized
INFO - 2023-11-26 08:48:28 --> Model "M_pesan" initialized
DEBUG - 2023-11-26 08:48:28 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-26 08:48:28 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-26 08:48:28 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-26 08:48:28 --> Final output sent to browser
DEBUG - 2023-11-26 08:48:28 --> Total execution time: 0.0338
ERROR - 2023-11-26 09:20:28 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 09:20:28 --> Config Class Initialized
INFO - 2023-11-26 09:20:28 --> Hooks Class Initialized
DEBUG - 2023-11-26 09:20:28 --> UTF-8 Support Enabled
INFO - 2023-11-26 09:20:28 --> Utf8 Class Initialized
INFO - 2023-11-26 09:20:28 --> URI Class Initialized
DEBUG - 2023-11-26 09:20:28 --> No URI present. Default controller set.
INFO - 2023-11-26 09:20:28 --> Router Class Initialized
INFO - 2023-11-26 09:20:28 --> Output Class Initialized
INFO - 2023-11-26 09:20:28 --> Security Class Initialized
DEBUG - 2023-11-26 09:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 09:20:28 --> Input Class Initialized
INFO - 2023-11-26 09:20:28 --> Language Class Initialized
INFO - 2023-11-26 09:20:28 --> Loader Class Initialized
INFO - 2023-11-26 09:20:28 --> Helper loaded: url_helper
INFO - 2023-11-26 09:20:28 --> Helper loaded: form_helper
INFO - 2023-11-26 09:20:28 --> Helper loaded: file_helper
INFO - 2023-11-26 09:20:28 --> Database Driver Class Initialized
DEBUG - 2023-11-26 09:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 09:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 09:20:28 --> Form Validation Class Initialized
INFO - 2023-11-26 09:20:28 --> Upload Class Initialized
INFO - 2023-11-26 09:20:28 --> Model "M_auth" initialized
INFO - 2023-11-26 09:20:28 --> Model "M_user" initialized
INFO - 2023-11-26 09:20:28 --> Model "M_produk" initialized
INFO - 2023-11-26 09:20:28 --> Controller Class Initialized
INFO - 2023-11-26 09:20:28 --> Model "M_pelanggan" initialized
INFO - 2023-11-26 09:20:28 --> Model "M_produk" initialized
DEBUG - 2023-11-26 09:20:28 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-26 09:20:28 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-26 09:20:28 --> Model "M_transaksi" initialized
INFO - 2023-11-26 09:20:28 --> Model "M_bank" initialized
INFO - 2023-11-26 09:20:28 --> Model "M_pesan" initialized
DEBUG - 2023-11-26 09:20:28 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-26 09:20:28 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-26 09:20:28 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-26 09:20:28 --> Final output sent to browser
DEBUG - 2023-11-26 09:20:28 --> Total execution time: 0.0318
ERROR - 2023-11-26 09:20:33 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 09:20:33 --> Config Class Initialized
INFO - 2023-11-26 09:20:33 --> Hooks Class Initialized
DEBUG - 2023-11-26 09:20:33 --> UTF-8 Support Enabled
INFO - 2023-11-26 09:20:33 --> Utf8 Class Initialized
INFO - 2023-11-26 09:20:33 --> URI Class Initialized
INFO - 2023-11-26 09:20:33 --> Router Class Initialized
INFO - 2023-11-26 09:20:33 --> Output Class Initialized
INFO - 2023-11-26 09:20:33 --> Security Class Initialized
DEBUG - 2023-11-26 09:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 09:20:33 --> Input Class Initialized
INFO - 2023-11-26 09:20:33 --> Language Class Initialized
INFO - 2023-11-26 09:20:33 --> Loader Class Initialized
INFO - 2023-11-26 09:20:33 --> Helper loaded: url_helper
INFO - 2023-11-26 09:20:33 --> Helper loaded: form_helper
INFO - 2023-11-26 09:20:33 --> Helper loaded: file_helper
INFO - 2023-11-26 09:20:33 --> Database Driver Class Initialized
DEBUG - 2023-11-26 09:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 09:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 09:20:33 --> Form Validation Class Initialized
INFO - 2023-11-26 09:20:33 --> Upload Class Initialized
INFO - 2023-11-26 09:20:33 --> Model "M_auth" initialized
INFO - 2023-11-26 09:20:33 --> Model "M_user" initialized
INFO - 2023-11-26 09:20:33 --> Model "M_produk" initialized
INFO - 2023-11-26 09:20:33 --> Controller Class Initialized
INFO - 2023-11-26 09:20:33 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-26 09:20:33 --> Final output sent to browser
DEBUG - 2023-11-26 09:20:33 --> Total execution time: 0.0027
ERROR - 2023-11-26 09:20:38 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 09:20:38 --> Config Class Initialized
INFO - 2023-11-26 09:20:38 --> Hooks Class Initialized
DEBUG - 2023-11-26 09:20:38 --> UTF-8 Support Enabled
INFO - 2023-11-26 09:20:38 --> Utf8 Class Initialized
INFO - 2023-11-26 09:20:38 --> URI Class Initialized
INFO - 2023-11-26 09:20:38 --> Router Class Initialized
INFO - 2023-11-26 09:20:38 --> Output Class Initialized
INFO - 2023-11-26 09:20:38 --> Security Class Initialized
DEBUG - 2023-11-26 09:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 09:20:38 --> Input Class Initialized
INFO - 2023-11-26 09:20:38 --> Language Class Initialized
INFO - 2023-11-26 09:20:38 --> Loader Class Initialized
INFO - 2023-11-26 09:20:38 --> Helper loaded: url_helper
INFO - 2023-11-26 09:20:38 --> Helper loaded: form_helper
INFO - 2023-11-26 09:20:38 --> Helper loaded: file_helper
INFO - 2023-11-26 09:20:38 --> Database Driver Class Initialized
DEBUG - 2023-11-26 09:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 09:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 09:20:38 --> Form Validation Class Initialized
INFO - 2023-11-26 09:20:38 --> Upload Class Initialized
INFO - 2023-11-26 09:20:38 --> Model "M_auth" initialized
INFO - 2023-11-26 09:20:38 --> Model "M_user" initialized
INFO - 2023-11-26 09:20:38 --> Model "M_produk" initialized
INFO - 2023-11-26 09:20:38 --> Controller Class Initialized
INFO - 2023-11-26 09:20:38 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-26 09:20:38 --> Final output sent to browser
DEBUG - 2023-11-26 09:20:38 --> Total execution time: 0.0025
ERROR - 2023-11-26 15:16:15 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 15:16:15 --> Config Class Initialized
INFO - 2023-11-26 15:16:15 --> Hooks Class Initialized
DEBUG - 2023-11-26 15:16:15 --> UTF-8 Support Enabled
INFO - 2023-11-26 15:16:15 --> Utf8 Class Initialized
INFO - 2023-11-26 15:16:15 --> URI Class Initialized
DEBUG - 2023-11-26 15:16:15 --> No URI present. Default controller set.
INFO - 2023-11-26 15:16:15 --> Router Class Initialized
INFO - 2023-11-26 15:16:15 --> Output Class Initialized
INFO - 2023-11-26 15:16:15 --> Security Class Initialized
DEBUG - 2023-11-26 15:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 15:16:15 --> Input Class Initialized
INFO - 2023-11-26 15:16:15 --> Language Class Initialized
INFO - 2023-11-26 15:16:15 --> Loader Class Initialized
INFO - 2023-11-26 15:16:15 --> Helper loaded: url_helper
INFO - 2023-11-26 15:16:15 --> Helper loaded: form_helper
INFO - 2023-11-26 15:16:15 --> Helper loaded: file_helper
INFO - 2023-11-26 15:16:15 --> Database Driver Class Initialized
DEBUG - 2023-11-26 15:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 15:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 15:16:15 --> Form Validation Class Initialized
INFO - 2023-11-26 15:16:15 --> Upload Class Initialized
INFO - 2023-11-26 15:16:15 --> Model "M_auth" initialized
INFO - 2023-11-26 15:16:15 --> Model "M_user" initialized
INFO - 2023-11-26 15:16:15 --> Model "M_produk" initialized
INFO - 2023-11-26 15:16:15 --> Controller Class Initialized
INFO - 2023-11-26 15:16:15 --> Model "M_pelanggan" initialized
INFO - 2023-11-26 15:16:15 --> Model "M_produk" initialized
DEBUG - 2023-11-26 15:16:15 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-26 15:16:15 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-26 15:16:15 --> Model "M_transaksi" initialized
INFO - 2023-11-26 15:16:15 --> Model "M_bank" initialized
INFO - 2023-11-26 15:16:15 --> Model "M_pesan" initialized
DEBUG - 2023-11-26 15:16:15 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-26 15:16:15 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-26 15:16:15 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-26 15:16:15 --> Final output sent to browser
DEBUG - 2023-11-26 15:16:15 --> Total execution time: 0.0310
ERROR - 2023-11-26 18:00:11 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 18:00:11 --> Config Class Initialized
INFO - 2023-11-26 18:00:11 --> Hooks Class Initialized
DEBUG - 2023-11-26 18:00:11 --> UTF-8 Support Enabled
INFO - 2023-11-26 18:00:11 --> Utf8 Class Initialized
INFO - 2023-11-26 18:00:11 --> URI Class Initialized
DEBUG - 2023-11-26 18:00:11 --> No URI present. Default controller set.
INFO - 2023-11-26 18:00:11 --> Router Class Initialized
INFO - 2023-11-26 18:00:11 --> Output Class Initialized
INFO - 2023-11-26 18:00:11 --> Security Class Initialized
DEBUG - 2023-11-26 18:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 18:00:11 --> Input Class Initialized
INFO - 2023-11-26 18:00:11 --> Language Class Initialized
INFO - 2023-11-26 18:00:11 --> Loader Class Initialized
INFO - 2023-11-26 18:00:11 --> Helper loaded: url_helper
INFO - 2023-11-26 18:00:11 --> Helper loaded: form_helper
INFO - 2023-11-26 18:00:11 --> Helper loaded: file_helper
INFO - 2023-11-26 18:00:11 --> Database Driver Class Initialized
DEBUG - 2023-11-26 18:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 18:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 18:00:11 --> Form Validation Class Initialized
INFO - 2023-11-26 18:00:11 --> Upload Class Initialized
INFO - 2023-11-26 18:00:11 --> Model "M_auth" initialized
INFO - 2023-11-26 18:00:11 --> Model "M_user" initialized
INFO - 2023-11-26 18:00:11 --> Model "M_produk" initialized
INFO - 2023-11-26 18:00:11 --> Controller Class Initialized
INFO - 2023-11-26 18:00:11 --> Model "M_pelanggan" initialized
INFO - 2023-11-26 18:00:11 --> Model "M_produk" initialized
DEBUG - 2023-11-26 18:00:11 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-26 18:00:11 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-26 18:00:11 --> Model "M_transaksi" initialized
INFO - 2023-11-26 18:00:11 --> Model "M_bank" initialized
INFO - 2023-11-26 18:00:11 --> Model "M_pesan" initialized
DEBUG - 2023-11-26 18:00:11 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-26 18:00:11 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-26 18:00:11 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-26 18:00:11 --> Final output sent to browser
DEBUG - 2023-11-26 18:00:11 --> Total execution time: 0.0437
ERROR - 2023-11-26 19:19:09 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 19:19:09 --> Config Class Initialized
INFO - 2023-11-26 19:19:09 --> Hooks Class Initialized
DEBUG - 2023-11-26 19:19:09 --> UTF-8 Support Enabled
INFO - 2023-11-26 19:19:09 --> Utf8 Class Initialized
INFO - 2023-11-26 19:19:09 --> URI Class Initialized
INFO - 2023-11-26 19:19:09 --> Router Class Initialized
INFO - 2023-11-26 19:19:09 --> Output Class Initialized
INFO - 2023-11-26 19:19:09 --> Security Class Initialized
DEBUG - 2023-11-26 19:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 19:19:09 --> Input Class Initialized
INFO - 2023-11-26 19:19:09 --> Language Class Initialized
INFO - 2023-11-26 19:19:09 --> Loader Class Initialized
INFO - 2023-11-26 19:19:09 --> Helper loaded: url_helper
INFO - 2023-11-26 19:19:09 --> Helper loaded: form_helper
INFO - 2023-11-26 19:19:09 --> Helper loaded: file_helper
INFO - 2023-11-26 19:19:09 --> Database Driver Class Initialized
DEBUG - 2023-11-26 19:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 19:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 19:19:09 --> Form Validation Class Initialized
INFO - 2023-11-26 19:19:09 --> Upload Class Initialized
INFO - 2023-11-26 19:19:09 --> Model "M_auth" initialized
INFO - 2023-11-26 19:19:09 --> Model "M_user" initialized
INFO - 2023-11-26 19:19:09 --> Model "M_produk" initialized
INFO - 2023-11-26 19:19:09 --> Controller Class Initialized
INFO - 2023-11-26 19:19:09 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-26 19:19:09 --> Final output sent to browser
DEBUG - 2023-11-26 19:19:09 --> Total execution time: 0.0268
ERROR - 2023-11-26 19:19:10 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 19:19:10 --> Config Class Initialized
INFO - 2023-11-26 19:19:10 --> Hooks Class Initialized
DEBUG - 2023-11-26 19:19:10 --> UTF-8 Support Enabled
INFO - 2023-11-26 19:19:10 --> Utf8 Class Initialized
INFO - 2023-11-26 19:19:10 --> URI Class Initialized
DEBUG - 2023-11-26 19:19:10 --> No URI present. Default controller set.
INFO - 2023-11-26 19:19:10 --> Router Class Initialized
INFO - 2023-11-26 19:19:10 --> Output Class Initialized
INFO - 2023-11-26 19:19:10 --> Security Class Initialized
DEBUG - 2023-11-26 19:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 19:19:10 --> Input Class Initialized
INFO - 2023-11-26 19:19:10 --> Language Class Initialized
INFO - 2023-11-26 19:19:10 --> Loader Class Initialized
INFO - 2023-11-26 19:19:10 --> Helper loaded: url_helper
INFO - 2023-11-26 19:19:10 --> Helper loaded: form_helper
INFO - 2023-11-26 19:19:10 --> Helper loaded: file_helper
INFO - 2023-11-26 19:19:10 --> Database Driver Class Initialized
DEBUG - 2023-11-26 19:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 19:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 19:19:10 --> Form Validation Class Initialized
INFO - 2023-11-26 19:19:10 --> Upload Class Initialized
INFO - 2023-11-26 19:19:10 --> Model "M_auth" initialized
INFO - 2023-11-26 19:19:10 --> Model "M_user" initialized
INFO - 2023-11-26 19:19:10 --> Model "M_produk" initialized
INFO - 2023-11-26 19:19:10 --> Controller Class Initialized
INFO - 2023-11-26 19:19:10 --> Model "M_pelanggan" initialized
INFO - 2023-11-26 19:19:10 --> Model "M_produk" initialized
DEBUG - 2023-11-26 19:19:10 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-26 19:19:10 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-26 19:19:10 --> Model "M_transaksi" initialized
INFO - 2023-11-26 19:19:10 --> Model "M_bank" initialized
INFO - 2023-11-26 19:19:10 --> Model "M_pesan" initialized
DEBUG - 2023-11-26 19:19:10 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-26 19:19:10 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-26 19:19:10 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-26 19:19:10 --> Final output sent to browser
DEBUG - 2023-11-26 19:19:10 --> Total execution time: 0.0090
ERROR - 2023-11-26 21:08:28 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 21:08:28 --> Config Class Initialized
INFO - 2023-11-26 21:08:28 --> Hooks Class Initialized
DEBUG - 2023-11-26 21:08:28 --> UTF-8 Support Enabled
INFO - 2023-11-26 21:08:28 --> Utf8 Class Initialized
INFO - 2023-11-26 21:08:28 --> URI Class Initialized
DEBUG - 2023-11-26 21:08:28 --> No URI present. Default controller set.
INFO - 2023-11-26 21:08:28 --> Router Class Initialized
INFO - 2023-11-26 21:08:28 --> Output Class Initialized
INFO - 2023-11-26 21:08:28 --> Security Class Initialized
DEBUG - 2023-11-26 21:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 21:08:28 --> Input Class Initialized
INFO - 2023-11-26 21:08:28 --> Language Class Initialized
INFO - 2023-11-26 21:08:28 --> Loader Class Initialized
INFO - 2023-11-26 21:08:28 --> Helper loaded: url_helper
INFO - 2023-11-26 21:08:28 --> Helper loaded: form_helper
INFO - 2023-11-26 21:08:28 --> Helper loaded: file_helper
INFO - 2023-11-26 21:08:28 --> Database Driver Class Initialized
DEBUG - 2023-11-26 21:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 21:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 21:08:28 --> Form Validation Class Initialized
INFO - 2023-11-26 21:08:28 --> Upload Class Initialized
INFO - 2023-11-26 21:08:28 --> Model "M_auth" initialized
INFO - 2023-11-26 21:08:28 --> Model "M_user" initialized
INFO - 2023-11-26 21:08:28 --> Model "M_produk" initialized
INFO - 2023-11-26 21:08:28 --> Controller Class Initialized
INFO - 2023-11-26 21:08:28 --> Model "M_pelanggan" initialized
INFO - 2023-11-26 21:08:28 --> Model "M_produk" initialized
DEBUG - 2023-11-26 21:08:28 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-26 21:08:28 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-26 21:08:28 --> Model "M_transaksi" initialized
INFO - 2023-11-26 21:08:28 --> Model "M_bank" initialized
INFO - 2023-11-26 21:08:28 --> Model "M_pesan" initialized
DEBUG - 2023-11-26 21:08:28 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-26 21:08:28 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-26 21:08:28 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-26 21:08:28 --> Final output sent to browser
DEBUG - 2023-11-26 21:08:28 --> Total execution time: 0.0342
ERROR - 2023-11-26 21:35:17 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 21:35:17 --> Config Class Initialized
INFO - 2023-11-26 21:35:17 --> Hooks Class Initialized
DEBUG - 2023-11-26 21:35:17 --> UTF-8 Support Enabled
INFO - 2023-11-26 21:35:17 --> Utf8 Class Initialized
INFO - 2023-11-26 21:35:17 --> URI Class Initialized
INFO - 2023-11-26 21:35:17 --> Router Class Initialized
INFO - 2023-11-26 21:35:17 --> Output Class Initialized
INFO - 2023-11-26 21:35:17 --> Security Class Initialized
DEBUG - 2023-11-26 21:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 21:35:17 --> Input Class Initialized
INFO - 2023-11-26 21:35:17 --> Language Class Initialized
INFO - 2023-11-26 21:35:17 --> Loader Class Initialized
INFO - 2023-11-26 21:35:17 --> Helper loaded: url_helper
INFO - 2023-11-26 21:35:17 --> Helper loaded: form_helper
INFO - 2023-11-26 21:35:17 --> Helper loaded: file_helper
INFO - 2023-11-26 21:35:17 --> Database Driver Class Initialized
DEBUG - 2023-11-26 21:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 21:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 21:35:17 --> Form Validation Class Initialized
INFO - 2023-11-26 21:35:17 --> Upload Class Initialized
INFO - 2023-11-26 21:35:17 --> Model "M_auth" initialized
INFO - 2023-11-26 21:35:17 --> Model "M_user" initialized
INFO - 2023-11-26 21:35:17 --> Model "M_produk" initialized
INFO - 2023-11-26 21:35:17 --> Controller Class Initialized
INFO - 2023-11-26 21:35:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-26 21:35:17 --> Final output sent to browser
DEBUG - 2023-11-26 21:35:17 --> Total execution time: 0.0244
ERROR - 2023-11-26 21:35:19 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 21:35:19 --> Config Class Initialized
INFO - 2023-11-26 21:35:19 --> Hooks Class Initialized
DEBUG - 2023-11-26 21:35:19 --> UTF-8 Support Enabled
INFO - 2023-11-26 21:35:19 --> Utf8 Class Initialized
INFO - 2023-11-26 21:35:19 --> URI Class Initialized
INFO - 2023-11-26 21:35:19 --> Router Class Initialized
INFO - 2023-11-26 21:35:19 --> Output Class Initialized
INFO - 2023-11-26 21:35:19 --> Security Class Initialized
DEBUG - 2023-11-26 21:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 21:35:19 --> Input Class Initialized
INFO - 2023-11-26 21:35:19 --> Language Class Initialized
INFO - 2023-11-26 21:35:19 --> Loader Class Initialized
INFO - 2023-11-26 21:35:19 --> Helper loaded: url_helper
INFO - 2023-11-26 21:35:19 --> Helper loaded: form_helper
INFO - 2023-11-26 21:35:19 --> Helper loaded: file_helper
INFO - 2023-11-26 21:35:19 --> Database Driver Class Initialized
DEBUG - 2023-11-26 21:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 21:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 21:35:19 --> Form Validation Class Initialized
INFO - 2023-11-26 21:35:19 --> Upload Class Initialized
INFO - 2023-11-26 21:35:19 --> Model "M_auth" initialized
INFO - 2023-11-26 21:35:19 --> Model "M_user" initialized
INFO - 2023-11-26 21:35:19 --> Model "M_produk" initialized
INFO - 2023-11-26 21:35:19 --> Controller Class Initialized
INFO - 2023-11-26 21:35:19 --> Model "M_pelanggan" initialized
INFO - 2023-11-26 21:35:19 --> Model "M_produk" initialized
DEBUG - 2023-11-26 21:35:19 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-26 21:35:19 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-26 21:35:19 --> Model "M_transaksi" initialized
INFO - 2023-11-26 21:35:19 --> Model "M_bank" initialized
INFO - 2023-11-26 21:35:19 --> Model "M_pesan" initialized
DEBUG - 2023-11-26 21:35:19 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-26 21:35:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-26 21:35:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/v_produk_detail.php
INFO - 2023-11-26 21:35:19 --> Final output sent to browser
DEBUG - 2023-11-26 21:35:19 --> Total execution time: 0.0089
ERROR - 2023-11-26 23:18:41 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 23:18:41 --> Config Class Initialized
INFO - 2023-11-26 23:18:41 --> Hooks Class Initialized
DEBUG - 2023-11-26 23:18:41 --> UTF-8 Support Enabled
INFO - 2023-11-26 23:18:41 --> Utf8 Class Initialized
INFO - 2023-11-26 23:18:41 --> URI Class Initialized
INFO - 2023-11-26 23:18:41 --> Router Class Initialized
INFO - 2023-11-26 23:18:41 --> Output Class Initialized
INFO - 2023-11-26 23:18:41 --> Security Class Initialized
DEBUG - 2023-11-26 23:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 23:18:41 --> Input Class Initialized
INFO - 2023-11-26 23:18:41 --> Language Class Initialized
INFO - 2023-11-26 23:18:41 --> Loader Class Initialized
INFO - 2023-11-26 23:18:41 --> Helper loaded: url_helper
INFO - 2023-11-26 23:18:41 --> Helper loaded: form_helper
INFO - 2023-11-26 23:18:41 --> Helper loaded: file_helper
INFO - 2023-11-26 23:18:41 --> Database Driver Class Initialized
DEBUG - 2023-11-26 23:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 23:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 23:18:41 --> Form Validation Class Initialized
INFO - 2023-11-26 23:18:41 --> Upload Class Initialized
INFO - 2023-11-26 23:18:41 --> Model "M_auth" initialized
INFO - 2023-11-26 23:18:41 --> Model "M_user" initialized
INFO - 2023-11-26 23:18:41 --> Model "M_produk" initialized
INFO - 2023-11-26 23:18:41 --> Controller Class Initialized
INFO - 2023-11-26 23:18:41 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-26 23:18:41 --> Final output sent to browser
DEBUG - 2023-11-26 23:18:41 --> Total execution time: 0.0259
ERROR - 2023-11-26 23:18:43 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 23:18:43 --> Config Class Initialized
INFO - 2023-11-26 23:18:43 --> Hooks Class Initialized
DEBUG - 2023-11-26 23:18:43 --> UTF-8 Support Enabled
INFO - 2023-11-26 23:18:43 --> Utf8 Class Initialized
INFO - 2023-11-26 23:18:43 --> URI Class Initialized
DEBUG - 2023-11-26 23:18:43 --> No URI present. Default controller set.
INFO - 2023-11-26 23:18:43 --> Router Class Initialized
INFO - 2023-11-26 23:18:43 --> Output Class Initialized
INFO - 2023-11-26 23:18:43 --> Security Class Initialized
DEBUG - 2023-11-26 23:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 23:18:43 --> Input Class Initialized
INFO - 2023-11-26 23:18:43 --> Language Class Initialized
INFO - 2023-11-26 23:18:43 --> Loader Class Initialized
INFO - 2023-11-26 23:18:43 --> Helper loaded: url_helper
INFO - 2023-11-26 23:18:43 --> Helper loaded: form_helper
INFO - 2023-11-26 23:18:43 --> Helper loaded: file_helper
INFO - 2023-11-26 23:18:43 --> Database Driver Class Initialized
DEBUG - 2023-11-26 23:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 23:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 23:18:43 --> Form Validation Class Initialized
INFO - 2023-11-26 23:18:43 --> Upload Class Initialized
INFO - 2023-11-26 23:18:43 --> Model "M_auth" initialized
INFO - 2023-11-26 23:18:43 --> Model "M_user" initialized
INFO - 2023-11-26 23:18:43 --> Model "M_produk" initialized
INFO - 2023-11-26 23:18:43 --> Controller Class Initialized
INFO - 2023-11-26 23:18:43 --> Model "M_pelanggan" initialized
INFO - 2023-11-26 23:18:43 --> Model "M_produk" initialized
DEBUG - 2023-11-26 23:18:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-26 23:18:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-26 23:18:43 --> Model "M_transaksi" initialized
INFO - 2023-11-26 23:18:43 --> Model "M_bank" initialized
INFO - 2023-11-26 23:18:43 --> Model "M_pesan" initialized
DEBUG - 2023-11-26 23:18:43 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-26 23:18:43 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-26 23:18:43 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-26 23:18:43 --> Final output sent to browser
DEBUG - 2023-11-26 23:18:43 --> Total execution time: 0.0110
ERROR - 2023-11-26 23:57:26 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-26 23:57:26 --> Config Class Initialized
INFO - 2023-11-26 23:57:26 --> Hooks Class Initialized
DEBUG - 2023-11-26 23:57:26 --> UTF-8 Support Enabled
INFO - 2023-11-26 23:57:26 --> Utf8 Class Initialized
INFO - 2023-11-26 23:57:26 --> URI Class Initialized
DEBUG - 2023-11-26 23:57:26 --> No URI present. Default controller set.
INFO - 2023-11-26 23:57:26 --> Router Class Initialized
INFO - 2023-11-26 23:57:26 --> Output Class Initialized
INFO - 2023-11-26 23:57:26 --> Security Class Initialized
DEBUG - 2023-11-26 23:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-26 23:57:26 --> Input Class Initialized
INFO - 2023-11-26 23:57:26 --> Language Class Initialized
INFO - 2023-11-26 23:57:26 --> Loader Class Initialized
INFO - 2023-11-26 23:57:26 --> Helper loaded: url_helper
INFO - 2023-11-26 23:57:26 --> Helper loaded: form_helper
INFO - 2023-11-26 23:57:26 --> Helper loaded: file_helper
INFO - 2023-11-26 23:57:26 --> Database Driver Class Initialized
DEBUG - 2023-11-26 23:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-26 23:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-26 23:57:26 --> Form Validation Class Initialized
INFO - 2023-11-26 23:57:26 --> Upload Class Initialized
INFO - 2023-11-26 23:57:26 --> Model "M_auth" initialized
INFO - 2023-11-26 23:57:26 --> Model "M_user" initialized
INFO - 2023-11-26 23:57:26 --> Model "M_produk" initialized
INFO - 2023-11-26 23:57:26 --> Controller Class Initialized
INFO - 2023-11-26 23:57:26 --> Model "M_pelanggan" initialized
INFO - 2023-11-26 23:57:26 --> Model "M_produk" initialized
DEBUG - 2023-11-26 23:57:26 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-26 23:57:26 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-26 23:57:26 --> Model "M_transaksi" initialized
INFO - 2023-11-26 23:57:26 --> Model "M_bank" initialized
INFO - 2023-11-26 23:57:26 --> Model "M_pesan" initialized
DEBUG - 2023-11-26 23:57:26 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-26 23:57:26 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-26 23:57:26 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-26 23:57:26 --> Final output sent to browser
DEBUG - 2023-11-26 23:57:26 --> Total execution time: 0.0308
