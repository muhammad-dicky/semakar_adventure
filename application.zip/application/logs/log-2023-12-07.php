<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-07 14:34:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:34:48 --> Config Class Initialized
INFO - 2023-12-07 14:34:48 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:34:48 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:34:48 --> Utf8 Class Initialized
INFO - 2023-12-07 14:34:48 --> URI Class Initialized
DEBUG - 2023-12-07 14:34:48 --> No URI present. Default controller set.
INFO - 2023-12-07 14:34:48 --> Router Class Initialized
INFO - 2023-12-07 14:34:48 --> Output Class Initialized
INFO - 2023-12-07 14:34:48 --> Security Class Initialized
DEBUG - 2023-12-07 14:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:34:48 --> Input Class Initialized
INFO - 2023-12-07 14:34:48 --> Language Class Initialized
INFO - 2023-12-07 14:34:48 --> Loader Class Initialized
INFO - 2023-12-07 14:34:48 --> Helper loaded: url_helper
INFO - 2023-12-07 14:34:48 --> Helper loaded: form_helper
INFO - 2023-12-07 14:34:48 --> Helper loaded: file_helper
INFO - 2023-12-07 14:34:48 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:34:48 --> Form Validation Class Initialized
INFO - 2023-12-07 14:34:49 --> Upload Class Initialized
INFO - 2023-12-07 14:34:49 --> Model "M_auth" initialized
INFO - 2023-12-07 14:34:49 --> Model "M_user" initialized
INFO - 2023-12-07 14:34:49 --> Model "M_produk" initialized
INFO - 2023-12-07 14:34:49 --> Controller Class Initialized
INFO - 2023-12-07 14:34:49 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:34:49 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:34:49 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:34:49 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:34:49 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:34:49 --> Model "M_bank" initialized
INFO - 2023-12-07 14:34:49 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:34:49 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 14:34:50 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 14:34:50 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/index.php
INFO - 2023-12-07 14:34:50 --> Final output sent to browser
DEBUG - 2023-12-07 14:34:50 --> Total execution time: 2.2506
ERROR - 2023-12-07 14:34:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:34:58 --> Config Class Initialized
INFO - 2023-12-07 14:34:58 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:34:58 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:34:58 --> Utf8 Class Initialized
INFO - 2023-12-07 14:34:58 --> URI Class Initialized
DEBUG - 2023-12-07 14:34:58 --> No URI present. Default controller set.
INFO - 2023-12-07 14:34:58 --> Router Class Initialized
INFO - 2023-12-07 14:34:58 --> Output Class Initialized
INFO - 2023-12-07 14:34:58 --> Security Class Initialized
DEBUG - 2023-12-07 14:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:34:58 --> Input Class Initialized
INFO - 2023-12-07 14:34:58 --> Language Class Initialized
INFO - 2023-12-07 14:34:58 --> Loader Class Initialized
INFO - 2023-12-07 14:34:58 --> Helper loaded: url_helper
INFO - 2023-12-07 14:34:58 --> Helper loaded: form_helper
INFO - 2023-12-07 14:34:58 --> Helper loaded: file_helper
INFO - 2023-12-07 14:34:58 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:34:58 --> Form Validation Class Initialized
INFO - 2023-12-07 14:34:58 --> Upload Class Initialized
INFO - 2023-12-07 14:34:58 --> Model "M_auth" initialized
INFO - 2023-12-07 14:34:58 --> Model "M_user" initialized
INFO - 2023-12-07 14:34:58 --> Model "M_produk" initialized
INFO - 2023-12-07 14:34:58 --> Controller Class Initialized
INFO - 2023-12-07 14:34:58 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:34:58 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:34:58 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:34:58 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:34:58 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:34:58 --> Model "M_bank" initialized
INFO - 2023-12-07 14:34:58 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:34:58 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 14:34:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-12-07 14:34:58 --> Email Class Initialized
INFO - 2023-12-07 14:35:00 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-12-07 14:35:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:35:03 --> Config Class Initialized
INFO - 2023-12-07 14:35:03 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:35:03 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:35:03 --> Utf8 Class Initialized
INFO - 2023-12-07 14:35:03 --> URI Class Initialized
DEBUG - 2023-12-07 14:35:03 --> No URI present. Default controller set.
INFO - 2023-12-07 14:35:03 --> Router Class Initialized
INFO - 2023-12-07 14:35:03 --> Output Class Initialized
INFO - 2023-12-07 14:35:03 --> Security Class Initialized
DEBUG - 2023-12-07 14:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:35:03 --> Input Class Initialized
INFO - 2023-12-07 14:35:03 --> Language Class Initialized
INFO - 2023-12-07 14:35:03 --> Loader Class Initialized
INFO - 2023-12-07 14:35:03 --> Helper loaded: url_helper
INFO - 2023-12-07 14:35:03 --> Helper loaded: form_helper
INFO - 2023-12-07 14:35:03 --> Helper loaded: file_helper
INFO - 2023-12-07 14:35:03 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:35:03 --> Form Validation Class Initialized
INFO - 2023-12-07 14:35:03 --> Upload Class Initialized
INFO - 2023-12-07 14:35:03 --> Model "M_auth" initialized
INFO - 2023-12-07 14:35:03 --> Model "M_user" initialized
INFO - 2023-12-07 14:35:03 --> Model "M_produk" initialized
INFO - 2023-12-07 14:35:03 --> Controller Class Initialized
INFO - 2023-12-07 14:35:03 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:35:03 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:35:03 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:35:03 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:35:03 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:35:03 --> Model "M_bank" initialized
INFO - 2023-12-07 14:35:03 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:35:03 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 14:35:03 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 14:35:03 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/index.php
INFO - 2023-12-07 14:35:03 --> Final output sent to browser
DEBUG - 2023-12-07 14:35:03 --> Total execution time: 0.0780
ERROR - 2023-12-07 14:35:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:35:06 --> Config Class Initialized
INFO - 2023-12-07 14:35:06 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:35:06 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:35:06 --> Utf8 Class Initialized
INFO - 2023-12-07 14:35:06 --> URI Class Initialized
INFO - 2023-12-07 14:35:06 --> Router Class Initialized
INFO - 2023-12-07 14:35:06 --> Output Class Initialized
INFO - 2023-12-07 14:35:06 --> Security Class Initialized
DEBUG - 2023-12-07 14:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:35:06 --> Input Class Initialized
INFO - 2023-12-07 14:35:06 --> Language Class Initialized
INFO - 2023-12-07 14:35:06 --> Loader Class Initialized
INFO - 2023-12-07 14:35:06 --> Helper loaded: url_helper
INFO - 2023-12-07 14:35:06 --> Helper loaded: form_helper
INFO - 2023-12-07 14:35:06 --> Helper loaded: file_helper
INFO - 2023-12-07 14:35:06 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:35:06 --> Form Validation Class Initialized
INFO - 2023-12-07 14:35:06 --> Upload Class Initialized
INFO - 2023-12-07 14:35:06 --> Model "M_auth" initialized
INFO - 2023-12-07 14:35:06 --> Model "M_user" initialized
INFO - 2023-12-07 14:35:06 --> Model "M_produk" initialized
INFO - 2023-12-07 14:35:06 --> Controller Class Initialized
INFO - 2023-12-07 14:35:06 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:35:06 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:35:06 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:35:06 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:35:06 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:35:06 --> Model "M_bank" initialized
INFO - 2023-12-07 14:35:06 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:35:06 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 14:35:07 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 14:35:07 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 14:35:07 --> Final output sent to browser
DEBUG - 2023-12-07 14:35:07 --> Total execution time: 0.8015
ERROR - 2023-12-07 14:36:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:36:03 --> Config Class Initialized
INFO - 2023-12-07 14:36:03 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:36:03 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:36:03 --> Utf8 Class Initialized
INFO - 2023-12-07 14:36:03 --> URI Class Initialized
INFO - 2023-12-07 14:36:03 --> Router Class Initialized
INFO - 2023-12-07 14:36:03 --> Output Class Initialized
INFO - 2023-12-07 14:36:03 --> Security Class Initialized
DEBUG - 2023-12-07 14:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:36:03 --> Input Class Initialized
INFO - 2023-12-07 14:36:03 --> Language Class Initialized
INFO - 2023-12-07 14:36:03 --> Loader Class Initialized
INFO - 2023-12-07 14:36:03 --> Helper loaded: url_helper
INFO - 2023-12-07 14:36:03 --> Helper loaded: form_helper
INFO - 2023-12-07 14:36:03 --> Helper loaded: file_helper
INFO - 2023-12-07 14:36:03 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:36:03 --> Form Validation Class Initialized
INFO - 2023-12-07 14:36:03 --> Upload Class Initialized
INFO - 2023-12-07 14:36:03 --> Model "M_auth" initialized
INFO - 2023-12-07 14:36:03 --> Model "M_user" initialized
INFO - 2023-12-07 14:36:03 --> Model "M_produk" initialized
INFO - 2023-12-07 14:36:03 --> Controller Class Initialized
INFO - 2023-12-07 14:36:03 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:36:03 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:36:03 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:36:03 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:36:03 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:36:03 --> Model "M_bank" initialized
INFO - 2023-12-07 14:36:03 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:36:03 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 14:36:04 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 14:36:04 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 14:36:04 --> Final output sent to browser
DEBUG - 2023-12-07 14:36:04 --> Total execution time: 0.5354
ERROR - 2023-12-07 14:36:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:36:30 --> Config Class Initialized
INFO - 2023-12-07 14:36:30 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:36:30 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:36:30 --> Utf8 Class Initialized
INFO - 2023-12-07 14:36:30 --> URI Class Initialized
DEBUG - 2023-12-07 14:36:30 --> No URI present. Default controller set.
INFO - 2023-12-07 14:36:30 --> Router Class Initialized
INFO - 2023-12-07 14:36:30 --> Output Class Initialized
INFO - 2023-12-07 14:36:30 --> Security Class Initialized
DEBUG - 2023-12-07 14:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:36:30 --> Input Class Initialized
INFO - 2023-12-07 14:36:30 --> Language Class Initialized
INFO - 2023-12-07 14:36:30 --> Loader Class Initialized
INFO - 2023-12-07 14:36:30 --> Helper loaded: url_helper
INFO - 2023-12-07 14:36:30 --> Helper loaded: form_helper
INFO - 2023-12-07 14:36:30 --> Helper loaded: file_helper
INFO - 2023-12-07 14:36:30 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:36:30 --> Form Validation Class Initialized
INFO - 2023-12-07 14:36:30 --> Upload Class Initialized
INFO - 2023-12-07 14:36:30 --> Model "M_auth" initialized
INFO - 2023-12-07 14:36:30 --> Model "M_user" initialized
INFO - 2023-12-07 14:36:30 --> Model "M_produk" initialized
INFO - 2023-12-07 14:36:30 --> Controller Class Initialized
INFO - 2023-12-07 14:36:30 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:36:30 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:36:30 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:36:30 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:36:30 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:36:30 --> Model "M_bank" initialized
INFO - 2023-12-07 14:36:30 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:36:30 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 14:36:30 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 14:36:30 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/index.php
INFO - 2023-12-07 14:36:30 --> Final output sent to browser
DEBUG - 2023-12-07 14:36:30 --> Total execution time: 0.0801
ERROR - 2023-12-07 14:36:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:36:39 --> Config Class Initialized
INFO - 2023-12-07 14:36:39 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:36:39 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:36:39 --> Utf8 Class Initialized
INFO - 2023-12-07 14:36:39 --> URI Class Initialized
INFO - 2023-12-07 14:36:39 --> Router Class Initialized
INFO - 2023-12-07 14:36:39 --> Output Class Initialized
INFO - 2023-12-07 14:36:39 --> Security Class Initialized
DEBUG - 2023-12-07 14:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:36:39 --> Input Class Initialized
INFO - 2023-12-07 14:36:39 --> Language Class Initialized
INFO - 2023-12-07 14:36:39 --> Loader Class Initialized
INFO - 2023-12-07 14:36:39 --> Helper loaded: url_helper
INFO - 2023-12-07 14:36:39 --> Helper loaded: form_helper
INFO - 2023-12-07 14:36:39 --> Helper loaded: file_helper
INFO - 2023-12-07 14:36:40 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:36:40 --> Form Validation Class Initialized
INFO - 2023-12-07 14:36:40 --> Upload Class Initialized
INFO - 2023-12-07 14:36:40 --> Model "M_auth" initialized
INFO - 2023-12-07 14:36:40 --> Model "M_user" initialized
INFO - 2023-12-07 14:36:40 --> Model "M_produk" initialized
INFO - 2023-12-07 14:36:40 --> Controller Class Initialized
INFO - 2023-12-07 14:36:40 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:36:40 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:36:40 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:36:40 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:36:40 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:36:40 --> Model "M_bank" initialized
INFO - 2023-12-07 14:36:40 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:36:40 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
ERROR - 2023-12-07 14:36:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:36:40 --> Config Class Initialized
INFO - 2023-12-07 14:36:40 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:36:40 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:36:40 --> Utf8 Class Initialized
INFO - 2023-12-07 14:36:40 --> URI Class Initialized
DEBUG - 2023-12-07 14:36:40 --> No URI present. Default controller set.
INFO - 2023-12-07 14:36:40 --> Router Class Initialized
INFO - 2023-12-07 14:36:40 --> Output Class Initialized
INFO - 2023-12-07 14:36:40 --> Security Class Initialized
DEBUG - 2023-12-07 14:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:36:40 --> Input Class Initialized
INFO - 2023-12-07 14:36:40 --> Language Class Initialized
INFO - 2023-12-07 14:36:40 --> Loader Class Initialized
INFO - 2023-12-07 14:36:40 --> Helper loaded: url_helper
INFO - 2023-12-07 14:36:40 --> Helper loaded: form_helper
INFO - 2023-12-07 14:36:40 --> Helper loaded: file_helper
INFO - 2023-12-07 14:36:40 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:36:40 --> Form Validation Class Initialized
INFO - 2023-12-07 14:36:40 --> Upload Class Initialized
INFO - 2023-12-07 14:36:40 --> Model "M_auth" initialized
INFO - 2023-12-07 14:36:40 --> Model "M_user" initialized
INFO - 2023-12-07 14:36:40 --> Model "M_produk" initialized
INFO - 2023-12-07 14:36:40 --> Controller Class Initialized
INFO - 2023-12-07 14:36:40 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:36:40 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:36:40 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:36:40 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:36:40 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:36:40 --> Model "M_bank" initialized
INFO - 2023-12-07 14:36:40 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:36:40 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 14:36:40 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 14:36:40 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/index.php
INFO - 2023-12-07 14:36:40 --> Final output sent to browser
DEBUG - 2023-12-07 14:36:40 --> Total execution time: 0.0432
ERROR - 2023-12-07 14:36:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:36:42 --> Config Class Initialized
INFO - 2023-12-07 14:36:42 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:36:42 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:36:42 --> Utf8 Class Initialized
INFO - 2023-12-07 14:36:42 --> URI Class Initialized
INFO - 2023-12-07 14:36:42 --> Router Class Initialized
INFO - 2023-12-07 14:36:42 --> Output Class Initialized
INFO - 2023-12-07 14:36:42 --> Security Class Initialized
DEBUG - 2023-12-07 14:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:36:42 --> Input Class Initialized
INFO - 2023-12-07 14:36:42 --> Language Class Initialized
INFO - 2023-12-07 14:36:43 --> Loader Class Initialized
INFO - 2023-12-07 14:36:43 --> Helper loaded: url_helper
INFO - 2023-12-07 14:36:43 --> Helper loaded: form_helper
INFO - 2023-12-07 14:36:43 --> Helper loaded: file_helper
INFO - 2023-12-07 14:36:43 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:36:43 --> Form Validation Class Initialized
INFO - 2023-12-07 14:36:43 --> Upload Class Initialized
INFO - 2023-12-07 14:36:43 --> Model "M_auth" initialized
INFO - 2023-12-07 14:36:43 --> Model "M_user" initialized
INFO - 2023-12-07 14:36:43 --> Model "M_produk" initialized
INFO - 2023-12-07 14:36:43 --> Controller Class Initialized
INFO - 2023-12-07 14:36:43 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 14:36:43 --> Final output sent to browser
DEBUG - 2023-12-07 14:36:43 --> Total execution time: 0.1272
ERROR - 2023-12-07 14:36:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:36:50 --> Config Class Initialized
INFO - 2023-12-07 14:36:50 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:36:50 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:36:50 --> Utf8 Class Initialized
INFO - 2023-12-07 14:36:50 --> URI Class Initialized
INFO - 2023-12-07 14:36:50 --> Router Class Initialized
INFO - 2023-12-07 14:36:50 --> Output Class Initialized
INFO - 2023-12-07 14:36:50 --> Security Class Initialized
DEBUG - 2023-12-07 14:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:36:50 --> Input Class Initialized
INFO - 2023-12-07 14:36:50 --> Language Class Initialized
INFO - 2023-12-07 14:36:50 --> Loader Class Initialized
INFO - 2023-12-07 14:36:50 --> Helper loaded: url_helper
INFO - 2023-12-07 14:36:50 --> Helper loaded: form_helper
INFO - 2023-12-07 14:36:50 --> Helper loaded: file_helper
INFO - 2023-12-07 14:36:50 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:36:50 --> Form Validation Class Initialized
INFO - 2023-12-07 14:36:50 --> Upload Class Initialized
INFO - 2023-12-07 14:36:50 --> Model "M_auth" initialized
INFO - 2023-12-07 14:36:50 --> Model "M_user" initialized
INFO - 2023-12-07 14:36:50 --> Model "M_produk" initialized
INFO - 2023-12-07 14:36:50 --> Controller Class Initialized
INFO - 2023-12-07 14:36:50 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 14:36:50 --> Final output sent to browser
DEBUG - 2023-12-07 14:36:50 --> Total execution time: 0.0820
ERROR - 2023-12-07 14:36:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:36:53 --> Config Class Initialized
INFO - 2023-12-07 14:36:53 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:36:53 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:36:53 --> Utf8 Class Initialized
INFO - 2023-12-07 14:36:53 --> URI Class Initialized
DEBUG - 2023-12-07 14:36:53 --> No URI present. Default controller set.
INFO - 2023-12-07 14:36:53 --> Router Class Initialized
INFO - 2023-12-07 14:36:53 --> Output Class Initialized
INFO - 2023-12-07 14:36:53 --> Security Class Initialized
DEBUG - 2023-12-07 14:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:36:53 --> Input Class Initialized
INFO - 2023-12-07 14:36:53 --> Language Class Initialized
INFO - 2023-12-07 14:36:53 --> Loader Class Initialized
INFO - 2023-12-07 14:36:53 --> Helper loaded: url_helper
INFO - 2023-12-07 14:36:53 --> Helper loaded: form_helper
INFO - 2023-12-07 14:36:53 --> Helper loaded: file_helper
INFO - 2023-12-07 14:36:53 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:36:53 --> Form Validation Class Initialized
INFO - 2023-12-07 14:36:53 --> Upload Class Initialized
INFO - 2023-12-07 14:36:53 --> Model "M_auth" initialized
INFO - 2023-12-07 14:36:53 --> Model "M_user" initialized
INFO - 2023-12-07 14:36:53 --> Model "M_produk" initialized
INFO - 2023-12-07 14:36:53 --> Controller Class Initialized
INFO - 2023-12-07 14:36:53 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:36:53 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:36:53 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:36:53 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:36:53 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:36:53 --> Model "M_bank" initialized
INFO - 2023-12-07 14:36:53 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:36:53 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 14:36:53 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 14:36:53 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/index.php
INFO - 2023-12-07 14:36:53 --> Final output sent to browser
DEBUG - 2023-12-07 14:36:53 --> Total execution time: 0.0841
ERROR - 2023-12-07 14:37:02 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:37:02 --> Config Class Initialized
INFO - 2023-12-07 14:37:02 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:37:02 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:37:02 --> Utf8 Class Initialized
INFO - 2023-12-07 14:37:02 --> URI Class Initialized
DEBUG - 2023-12-07 14:37:02 --> No URI present. Default controller set.
INFO - 2023-12-07 14:37:02 --> Router Class Initialized
INFO - 2023-12-07 14:37:02 --> Output Class Initialized
INFO - 2023-12-07 14:37:02 --> Security Class Initialized
DEBUG - 2023-12-07 14:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:37:02 --> Input Class Initialized
INFO - 2023-12-07 14:37:02 --> Language Class Initialized
INFO - 2023-12-07 14:37:02 --> Loader Class Initialized
INFO - 2023-12-07 14:37:02 --> Helper loaded: url_helper
INFO - 2023-12-07 14:37:02 --> Helper loaded: form_helper
INFO - 2023-12-07 14:37:02 --> Helper loaded: file_helper
INFO - 2023-12-07 14:37:02 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:37:02 --> Form Validation Class Initialized
INFO - 2023-12-07 14:37:02 --> Upload Class Initialized
INFO - 2023-12-07 14:37:02 --> Model "M_auth" initialized
INFO - 2023-12-07 14:37:02 --> Model "M_user" initialized
INFO - 2023-12-07 14:37:02 --> Model "M_produk" initialized
INFO - 2023-12-07 14:37:02 --> Controller Class Initialized
INFO - 2023-12-07 14:37:02 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:37:02 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:37:02 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:37:02 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:37:02 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:37:02 --> Model "M_bank" initialized
INFO - 2023-12-07 14:37:02 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:37:02 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 14:37:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-12-07 14:37:02 --> Email Class Initialized
INFO - 2023-12-07 14:37:04 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-12-07 14:37:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:37:07 --> Config Class Initialized
INFO - 2023-12-07 14:37:07 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:37:07 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:37:07 --> Utf8 Class Initialized
INFO - 2023-12-07 14:37:07 --> URI Class Initialized
DEBUG - 2023-12-07 14:37:07 --> No URI present. Default controller set.
INFO - 2023-12-07 14:37:07 --> Router Class Initialized
INFO - 2023-12-07 14:37:07 --> Output Class Initialized
INFO - 2023-12-07 14:37:07 --> Security Class Initialized
DEBUG - 2023-12-07 14:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:37:07 --> Input Class Initialized
INFO - 2023-12-07 14:37:07 --> Language Class Initialized
INFO - 2023-12-07 14:37:07 --> Loader Class Initialized
INFO - 2023-12-07 14:37:07 --> Helper loaded: url_helper
INFO - 2023-12-07 14:37:07 --> Helper loaded: form_helper
INFO - 2023-12-07 14:37:07 --> Helper loaded: file_helper
INFO - 2023-12-07 14:37:07 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:37:07 --> Form Validation Class Initialized
INFO - 2023-12-07 14:37:07 --> Upload Class Initialized
INFO - 2023-12-07 14:37:07 --> Model "M_auth" initialized
INFO - 2023-12-07 14:37:07 --> Model "M_user" initialized
INFO - 2023-12-07 14:37:07 --> Model "M_produk" initialized
INFO - 2023-12-07 14:37:07 --> Controller Class Initialized
INFO - 2023-12-07 14:37:07 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:37:07 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:37:07 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:37:07 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:37:07 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:37:07 --> Model "M_bank" initialized
INFO - 2023-12-07 14:37:07 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:37:07 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 14:37:07 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 14:37:07 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/index.php
INFO - 2023-12-07 14:37:07 --> Final output sent to browser
DEBUG - 2023-12-07 14:37:07 --> Total execution time: 0.1010
ERROR - 2023-12-07 14:37:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:37:17 --> Config Class Initialized
INFO - 2023-12-07 14:37:17 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:37:17 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:37:17 --> Utf8 Class Initialized
INFO - 2023-12-07 14:37:17 --> URI Class Initialized
INFO - 2023-12-07 14:37:17 --> Router Class Initialized
INFO - 2023-12-07 14:37:17 --> Output Class Initialized
INFO - 2023-12-07 14:37:17 --> Security Class Initialized
DEBUG - 2023-12-07 14:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:37:17 --> Input Class Initialized
INFO - 2023-12-07 14:37:17 --> Language Class Initialized
INFO - 2023-12-07 14:37:17 --> Loader Class Initialized
INFO - 2023-12-07 14:37:17 --> Helper loaded: url_helper
INFO - 2023-12-07 14:37:17 --> Helper loaded: form_helper
INFO - 2023-12-07 14:37:17 --> Helper loaded: file_helper
INFO - 2023-12-07 14:37:17 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:37:17 --> Form Validation Class Initialized
INFO - 2023-12-07 14:37:17 --> Upload Class Initialized
INFO - 2023-12-07 14:37:17 --> Model "M_auth" initialized
INFO - 2023-12-07 14:37:17 --> Model "M_user" initialized
INFO - 2023-12-07 14:37:17 --> Model "M_produk" initialized
INFO - 2023-12-07 14:37:17 --> Controller Class Initialized
INFO - 2023-12-07 14:37:17 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:37:17 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:37:17 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:37:17 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:37:17 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:37:17 --> Model "M_bank" initialized
INFO - 2023-12-07 14:37:17 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:37:17 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 14:37:17 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 14:37:17 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 14:37:17 --> Final output sent to browser
DEBUG - 2023-12-07 14:37:17 --> Total execution time: 0.9382
ERROR - 2023-12-07 14:37:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:37:39 --> Config Class Initialized
INFO - 2023-12-07 14:37:39 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:37:39 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:37:39 --> Utf8 Class Initialized
INFO - 2023-12-07 14:37:39 --> URI Class Initialized
INFO - 2023-12-07 14:37:39 --> Router Class Initialized
INFO - 2023-12-07 14:37:39 --> Output Class Initialized
INFO - 2023-12-07 14:37:39 --> Security Class Initialized
DEBUG - 2023-12-07 14:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:37:39 --> Input Class Initialized
INFO - 2023-12-07 14:37:39 --> Language Class Initialized
INFO - 2023-12-07 14:37:39 --> Loader Class Initialized
INFO - 2023-12-07 14:37:39 --> Helper loaded: url_helper
INFO - 2023-12-07 14:37:39 --> Helper loaded: form_helper
INFO - 2023-12-07 14:37:39 --> Helper loaded: file_helper
INFO - 2023-12-07 14:37:39 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:37:39 --> Form Validation Class Initialized
INFO - 2023-12-07 14:37:39 --> Upload Class Initialized
INFO - 2023-12-07 14:37:39 --> Model "M_auth" initialized
INFO - 2023-12-07 14:37:39 --> Model "M_user" initialized
INFO - 2023-12-07 14:37:39 --> Model "M_produk" initialized
INFO - 2023-12-07 14:37:39 --> Controller Class Initialized
INFO - 2023-12-07 14:37:39 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:37:39 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:37:39 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:37:39 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:37:39 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:37:39 --> Model "M_bank" initialized
INFO - 2023-12-07 14:37:39 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:37:39 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 14:37:40 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 14:37:40 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 14:37:40 --> Final output sent to browser
DEBUG - 2023-12-07 14:37:40 --> Total execution time: 1.3135
ERROR - 2023-12-07 14:37:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:37:52 --> Config Class Initialized
INFO - 2023-12-07 14:37:52 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:37:52 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:37:52 --> Utf8 Class Initialized
INFO - 2023-12-07 14:37:52 --> URI Class Initialized
INFO - 2023-12-07 14:37:52 --> Router Class Initialized
INFO - 2023-12-07 14:37:52 --> Output Class Initialized
INFO - 2023-12-07 14:37:52 --> Security Class Initialized
DEBUG - 2023-12-07 14:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:37:52 --> Input Class Initialized
INFO - 2023-12-07 14:37:52 --> Language Class Initialized
INFO - 2023-12-07 14:37:52 --> Loader Class Initialized
INFO - 2023-12-07 14:37:52 --> Helper loaded: url_helper
INFO - 2023-12-07 14:37:52 --> Helper loaded: form_helper
INFO - 2023-12-07 14:37:52 --> Helper loaded: file_helper
INFO - 2023-12-07 14:37:52 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:37:52 --> Form Validation Class Initialized
INFO - 2023-12-07 14:37:52 --> Upload Class Initialized
INFO - 2023-12-07 14:37:52 --> Model "M_auth" initialized
INFO - 2023-12-07 14:37:52 --> Model "M_user" initialized
INFO - 2023-12-07 14:37:52 --> Model "M_produk" initialized
INFO - 2023-12-07 14:37:52 --> Controller Class Initialized
INFO - 2023-12-07 14:37:52 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:37:52 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:37:52 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:37:52 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:37:52 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:37:52 --> Model "M_bank" initialized
INFO - 2023-12-07 14:37:52 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:37:52 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 14:37:52 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 14:37:52 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 14:37:52 --> Final output sent to browser
DEBUG - 2023-12-07 14:37:52 --> Total execution time: 0.5278
ERROR - 2023-12-07 14:38:01 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:38:01 --> Config Class Initialized
INFO - 2023-12-07 14:38:01 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:38:01 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:38:01 --> Utf8 Class Initialized
INFO - 2023-12-07 14:38:01 --> URI Class Initialized
INFO - 2023-12-07 14:38:01 --> Router Class Initialized
INFO - 2023-12-07 14:38:01 --> Output Class Initialized
INFO - 2023-12-07 14:38:01 --> Security Class Initialized
DEBUG - 2023-12-07 14:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:38:01 --> Input Class Initialized
INFO - 2023-12-07 14:38:01 --> Language Class Initialized
INFO - 2023-12-07 14:38:01 --> Loader Class Initialized
INFO - 2023-12-07 14:38:01 --> Helper loaded: url_helper
INFO - 2023-12-07 14:38:01 --> Helper loaded: form_helper
INFO - 2023-12-07 14:38:01 --> Helper loaded: file_helper
INFO - 2023-12-07 14:38:01 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:38:01 --> Form Validation Class Initialized
INFO - 2023-12-07 14:38:01 --> Upload Class Initialized
INFO - 2023-12-07 14:38:01 --> Model "M_auth" initialized
INFO - 2023-12-07 14:38:01 --> Model "M_user" initialized
INFO - 2023-12-07 14:38:01 --> Model "M_produk" initialized
INFO - 2023-12-07 14:38:01 --> Controller Class Initialized
INFO - 2023-12-07 14:38:01 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:38:01 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:38:01 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:38:01 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:38:01 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:38:01 --> Model "M_bank" initialized
INFO - 2023-12-07 14:38:01 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:38:01 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 14:38:02 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 14:38:02 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 14:38:02 --> Final output sent to browser
DEBUG - 2023-12-07 14:38:02 --> Total execution time: 1.4616
ERROR - 2023-12-07 14:39:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:39:04 --> Config Class Initialized
INFO - 2023-12-07 14:39:04 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:39:04 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:39:04 --> Utf8 Class Initialized
INFO - 2023-12-07 14:39:04 --> URI Class Initialized
DEBUG - 2023-12-07 14:39:04 --> No URI present. Default controller set.
INFO - 2023-12-07 14:39:04 --> Router Class Initialized
INFO - 2023-12-07 14:39:04 --> Output Class Initialized
INFO - 2023-12-07 14:39:04 --> Security Class Initialized
DEBUG - 2023-12-07 14:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:39:04 --> Input Class Initialized
INFO - 2023-12-07 14:39:04 --> Language Class Initialized
INFO - 2023-12-07 14:39:04 --> Loader Class Initialized
INFO - 2023-12-07 14:39:04 --> Helper loaded: url_helper
INFO - 2023-12-07 14:39:04 --> Helper loaded: form_helper
INFO - 2023-12-07 14:39:04 --> Helper loaded: file_helper
INFO - 2023-12-07 14:39:04 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:39:04 --> Form Validation Class Initialized
INFO - 2023-12-07 14:39:04 --> Upload Class Initialized
INFO - 2023-12-07 14:39:04 --> Model "M_auth" initialized
INFO - 2023-12-07 14:39:04 --> Model "M_user" initialized
INFO - 2023-12-07 14:39:04 --> Model "M_produk" initialized
INFO - 2023-12-07 14:39:04 --> Controller Class Initialized
INFO - 2023-12-07 14:39:04 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:39:04 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:39:04 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:39:04 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:39:04 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:39:04 --> Model "M_bank" initialized
INFO - 2023-12-07 14:39:04 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:39:04 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 14:39:04 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 14:39:04 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/index.php
INFO - 2023-12-07 14:39:04 --> Final output sent to browser
DEBUG - 2023-12-07 14:39:04 --> Total execution time: 0.0519
ERROR - 2023-12-07 14:50:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:50:21 --> Config Class Initialized
INFO - 2023-12-07 14:50:21 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:50:21 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:50:21 --> Utf8 Class Initialized
INFO - 2023-12-07 14:50:21 --> URI Class Initialized
INFO - 2023-12-07 14:50:21 --> Router Class Initialized
INFO - 2023-12-07 14:50:21 --> Output Class Initialized
INFO - 2023-12-07 14:50:21 --> Security Class Initialized
DEBUG - 2023-12-07 14:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:50:21 --> Input Class Initialized
INFO - 2023-12-07 14:50:21 --> Language Class Initialized
INFO - 2023-12-07 14:50:21 --> Loader Class Initialized
INFO - 2023-12-07 14:50:21 --> Helper loaded: url_helper
INFO - 2023-12-07 14:50:21 --> Helper loaded: form_helper
INFO - 2023-12-07 14:50:21 --> Helper loaded: file_helper
INFO - 2023-12-07 14:50:21 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:50:21 --> Form Validation Class Initialized
INFO - 2023-12-07 14:50:21 --> Upload Class Initialized
INFO - 2023-12-07 14:50:21 --> Model "M_auth" initialized
INFO - 2023-12-07 14:50:21 --> Model "M_user" initialized
INFO - 2023-12-07 14:50:21 --> Model "M_produk" initialized
INFO - 2023-12-07 14:50:21 --> Controller Class Initialized
INFO - 2023-12-07 14:50:21 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\back/v_login.php
INFO - 2023-12-07 14:50:21 --> Final output sent to browser
DEBUG - 2023-12-07 14:50:21 --> Total execution time: 0.0994
ERROR - 2023-12-07 14:50:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:50:24 --> Config Class Initialized
INFO - 2023-12-07 14:50:24 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:50:24 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:50:24 --> Utf8 Class Initialized
INFO - 2023-12-07 14:50:24 --> URI Class Initialized
DEBUG - 2023-12-07 14:50:24 --> No URI present. Default controller set.
INFO - 2023-12-07 14:50:24 --> Router Class Initialized
INFO - 2023-12-07 14:50:24 --> Output Class Initialized
INFO - 2023-12-07 14:50:24 --> Security Class Initialized
DEBUG - 2023-12-07 14:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:50:24 --> Input Class Initialized
INFO - 2023-12-07 14:50:24 --> Language Class Initialized
INFO - 2023-12-07 14:50:24 --> Loader Class Initialized
INFO - 2023-12-07 14:50:24 --> Helper loaded: url_helper
INFO - 2023-12-07 14:50:24 --> Helper loaded: form_helper
INFO - 2023-12-07 14:50:24 --> Helper loaded: file_helper
INFO - 2023-12-07 14:50:24 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:50:24 --> Form Validation Class Initialized
INFO - 2023-12-07 14:50:24 --> Upload Class Initialized
INFO - 2023-12-07 14:50:24 --> Model "M_auth" initialized
INFO - 2023-12-07 14:50:24 --> Model "M_user" initialized
INFO - 2023-12-07 14:50:24 --> Model "M_produk" initialized
INFO - 2023-12-07 14:50:24 --> Controller Class Initialized
INFO - 2023-12-07 14:50:24 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:50:24 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:50:24 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:50:24 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:50:24 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:50:24 --> Model "M_bank" initialized
INFO - 2023-12-07 14:50:24 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:50:24 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 14:50:24 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 14:50:24 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/index.php
INFO - 2023-12-07 14:50:24 --> Final output sent to browser
DEBUG - 2023-12-07 14:50:24 --> Total execution time: 0.1051
ERROR - 2023-12-07 14:52:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:52:28 --> Config Class Initialized
INFO - 2023-12-07 14:52:28 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:52:28 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:52:28 --> Utf8 Class Initialized
INFO - 2023-12-07 14:52:28 --> URI Class Initialized
DEBUG - 2023-12-07 14:52:28 --> No URI present. Default controller set.
INFO - 2023-12-07 14:52:28 --> Router Class Initialized
INFO - 2023-12-07 14:52:28 --> Output Class Initialized
INFO - 2023-12-07 14:52:28 --> Security Class Initialized
DEBUG - 2023-12-07 14:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:52:28 --> Input Class Initialized
INFO - 2023-12-07 14:52:28 --> Language Class Initialized
INFO - 2023-12-07 14:52:28 --> Loader Class Initialized
INFO - 2023-12-07 14:52:28 --> Helper loaded: url_helper
INFO - 2023-12-07 14:52:28 --> Helper loaded: form_helper
INFO - 2023-12-07 14:52:28 --> Helper loaded: file_helper
INFO - 2023-12-07 14:52:28 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:52:28 --> Form Validation Class Initialized
INFO - 2023-12-07 14:52:28 --> Upload Class Initialized
INFO - 2023-12-07 14:52:28 --> Model "M_auth" initialized
INFO - 2023-12-07 14:52:28 --> Model "M_user" initialized
INFO - 2023-12-07 14:52:28 --> Model "M_produk" initialized
INFO - 2023-12-07 14:52:28 --> Controller Class Initialized
INFO - 2023-12-07 14:52:28 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:52:28 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:52:28 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:52:28 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:52:28 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:52:28 --> Model "M_bank" initialized
INFO - 2023-12-07 14:52:28 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:52:28 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 14:52:28 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 14:52:28 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/index.php
INFO - 2023-12-07 14:52:28 --> Final output sent to browser
DEBUG - 2023-12-07 14:52:28 --> Total execution time: 0.0896
ERROR - 2023-12-07 14:52:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:52:32 --> Config Class Initialized
INFO - 2023-12-07 14:52:32 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:52:32 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:52:32 --> Utf8 Class Initialized
INFO - 2023-12-07 14:52:32 --> URI Class Initialized
INFO - 2023-12-07 14:52:32 --> Router Class Initialized
INFO - 2023-12-07 14:52:32 --> Output Class Initialized
INFO - 2023-12-07 14:52:32 --> Security Class Initialized
DEBUG - 2023-12-07 14:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:52:32 --> Input Class Initialized
INFO - 2023-12-07 14:52:32 --> Language Class Initialized
INFO - 2023-12-07 14:52:32 --> Loader Class Initialized
INFO - 2023-12-07 14:52:32 --> Helper loaded: url_helper
INFO - 2023-12-07 14:52:32 --> Helper loaded: form_helper
INFO - 2023-12-07 14:52:32 --> Helper loaded: file_helper
INFO - 2023-12-07 14:52:32 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:52:32 --> Form Validation Class Initialized
INFO - 2023-12-07 14:52:32 --> Upload Class Initialized
INFO - 2023-12-07 14:52:32 --> Model "M_auth" initialized
INFO - 2023-12-07 14:52:32 --> Model "M_user" initialized
INFO - 2023-12-07 14:52:32 --> Model "M_produk" initialized
INFO - 2023-12-07 14:52:32 --> Controller Class Initialized
INFO - 2023-12-07 14:52:32 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:52:32 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:52:32 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:52:32 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:52:32 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:52:32 --> Model "M_bank" initialized
INFO - 2023-12-07 14:52:32 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:52:32 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
ERROR - 2023-12-07 14:52:33 --> Severity: Warning --> Undefined variable $transaksi_item C:\xampp\htdocs\semakar_adventure_new\application\views\front\v_booking_saya.php 262
ERROR - 2023-12-07 14:52:33 --> Severity: Warning --> Attempt to read property "id_transaksi" on null C:\xampp\htdocs\semakar_adventure_new\application\views\front\v_booking_saya.php 262
ERROR - 2023-12-07 14:52:33 --> Severity: Warning --> Undefined variable $transaksi_item C:\xampp\htdocs\semakar_adventure_new\application\views\front\v_booking_saya.php 262
ERROR - 2023-12-07 14:52:33 --> Severity: Warning --> Attempt to read property "id_transaksi" on null C:\xampp\htdocs\semakar_adventure_new\application\views\front\v_booking_saya.php 262
INFO - 2023-12-07 14:52:33 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 14:52:33 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 14:52:33 --> Final output sent to browser
DEBUG - 2023-12-07 14:52:33 --> Total execution time: 0.6739
ERROR - 2023-12-07 14:52:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:52:50 --> Config Class Initialized
INFO - 2023-12-07 14:52:50 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:52:50 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:52:50 --> Utf8 Class Initialized
INFO - 2023-12-07 14:52:50 --> URI Class Initialized
INFO - 2023-12-07 14:52:50 --> Router Class Initialized
INFO - 2023-12-07 14:52:50 --> Output Class Initialized
INFO - 2023-12-07 14:52:50 --> Security Class Initialized
DEBUG - 2023-12-07 14:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:52:50 --> Input Class Initialized
INFO - 2023-12-07 14:52:50 --> Language Class Initialized
INFO - 2023-12-07 14:52:50 --> Loader Class Initialized
INFO - 2023-12-07 14:52:50 --> Helper loaded: url_helper
INFO - 2023-12-07 14:52:50 --> Helper loaded: form_helper
INFO - 2023-12-07 14:52:50 --> Helper loaded: file_helper
INFO - 2023-12-07 14:52:50 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:52:50 --> Form Validation Class Initialized
INFO - 2023-12-07 14:52:50 --> Upload Class Initialized
INFO - 2023-12-07 14:52:50 --> Model "M_auth" initialized
INFO - 2023-12-07 14:52:50 --> Model "M_user" initialized
INFO - 2023-12-07 14:52:50 --> Model "M_produk" initialized
INFO - 2023-12-07 14:52:50 --> Controller Class Initialized
INFO - 2023-12-07 14:52:50 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:52:50 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:52:50 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:52:50 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:52:50 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:52:50 --> Model "M_bank" initialized
INFO - 2023-12-07 14:52:50 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:52:50 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 14:52:50 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 14:52:50 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 14:52:50 --> Final output sent to browser
DEBUG - 2023-12-07 14:52:50 --> Total execution time: 0.4646
ERROR - 2023-12-07 14:52:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:52:56 --> Config Class Initialized
INFO - 2023-12-07 14:52:56 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:52:56 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:52:56 --> Utf8 Class Initialized
INFO - 2023-12-07 14:52:56 --> URI Class Initialized
INFO - 2023-12-07 14:52:56 --> Router Class Initialized
INFO - 2023-12-07 14:52:56 --> Output Class Initialized
INFO - 2023-12-07 14:52:56 --> Security Class Initialized
DEBUG - 2023-12-07 14:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:52:56 --> Input Class Initialized
INFO - 2023-12-07 14:52:56 --> Language Class Initialized
INFO - 2023-12-07 14:52:56 --> Loader Class Initialized
INFO - 2023-12-07 14:52:56 --> Helper loaded: url_helper
INFO - 2023-12-07 14:52:56 --> Helper loaded: form_helper
INFO - 2023-12-07 14:52:56 --> Helper loaded: file_helper
INFO - 2023-12-07 14:52:56 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:52:56 --> Form Validation Class Initialized
INFO - 2023-12-07 14:52:56 --> Upload Class Initialized
INFO - 2023-12-07 14:52:56 --> Model "M_auth" initialized
INFO - 2023-12-07 14:52:56 --> Model "M_user" initialized
INFO - 2023-12-07 14:52:56 --> Model "M_produk" initialized
INFO - 2023-12-07 14:52:56 --> Controller Class Initialized
INFO - 2023-12-07 14:52:56 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:52:56 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:52:56 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:52:56 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:52:56 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:52:56 --> Model "M_bank" initialized
INFO - 2023-12-07 14:52:56 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:52:56 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 14:52:56 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 14:52:56 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 14:52:56 --> Final output sent to browser
DEBUG - 2023-12-07 14:52:56 --> Total execution time: 0.4379
ERROR - 2023-12-07 14:53:10 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:53:10 --> Config Class Initialized
INFO - 2023-12-07 14:53:10 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:53:10 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:53:10 --> Utf8 Class Initialized
INFO - 2023-12-07 14:53:10 --> URI Class Initialized
INFO - 2023-12-07 14:53:10 --> Router Class Initialized
INFO - 2023-12-07 14:53:10 --> Output Class Initialized
INFO - 2023-12-07 14:53:10 --> Security Class Initialized
DEBUG - 2023-12-07 14:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:53:10 --> Input Class Initialized
INFO - 2023-12-07 14:53:10 --> Language Class Initialized
INFO - 2023-12-07 14:53:10 --> Loader Class Initialized
INFO - 2023-12-07 14:53:10 --> Helper loaded: url_helper
INFO - 2023-12-07 14:53:10 --> Helper loaded: form_helper
INFO - 2023-12-07 14:53:10 --> Helper loaded: file_helper
INFO - 2023-12-07 14:53:10 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:53:10 --> Form Validation Class Initialized
INFO - 2023-12-07 14:53:10 --> Upload Class Initialized
INFO - 2023-12-07 14:53:10 --> Model "M_auth" initialized
INFO - 2023-12-07 14:53:10 --> Model "M_user" initialized
INFO - 2023-12-07 14:53:10 --> Model "M_produk" initialized
INFO - 2023-12-07 14:53:10 --> Controller Class Initialized
INFO - 2023-12-07 14:53:10 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:53:10 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:53:10 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:53:10 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:53:10 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:53:10 --> Model "M_bank" initialized
INFO - 2023-12-07 14:53:10 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:53:10 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 14:53:10 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 14:53:10 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 14:53:10 --> Final output sent to browser
DEBUG - 2023-12-07 14:53:10 --> Total execution time: 0.4050
ERROR - 2023-12-07 14:53:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:53:11 --> Config Class Initialized
INFO - 2023-12-07 14:53:11 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:53:11 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:53:11 --> Utf8 Class Initialized
INFO - 2023-12-07 14:53:11 --> URI Class Initialized
INFO - 2023-12-07 14:53:11 --> Router Class Initialized
INFO - 2023-12-07 14:53:11 --> Output Class Initialized
INFO - 2023-12-07 14:53:11 --> Security Class Initialized
DEBUG - 2023-12-07 14:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:53:11 --> Input Class Initialized
INFO - 2023-12-07 14:53:11 --> Language Class Initialized
INFO - 2023-12-07 14:53:11 --> Loader Class Initialized
INFO - 2023-12-07 14:53:11 --> Helper loaded: url_helper
INFO - 2023-12-07 14:53:11 --> Helper loaded: form_helper
INFO - 2023-12-07 14:53:11 --> Helper loaded: file_helper
INFO - 2023-12-07 14:53:11 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:53:11 --> Form Validation Class Initialized
INFO - 2023-12-07 14:53:11 --> Upload Class Initialized
INFO - 2023-12-07 14:53:11 --> Model "M_auth" initialized
INFO - 2023-12-07 14:53:11 --> Model "M_user" initialized
INFO - 2023-12-07 14:53:11 --> Model "M_produk" initialized
INFO - 2023-12-07 14:53:11 --> Controller Class Initialized
INFO - 2023-12-07 14:53:11 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:53:11 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:53:11 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:53:11 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:53:11 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:53:11 --> Model "M_bank" initialized
INFO - 2023-12-07 14:53:11 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:53:11 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 14:53:11 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 14:53:11 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_edit_profile_pelanggan.php
INFO - 2023-12-07 14:53:11 --> Final output sent to browser
DEBUG - 2023-12-07 14:53:11 --> Total execution time: 0.1387
ERROR - 2023-12-07 14:53:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:53:17 --> Config Class Initialized
INFO - 2023-12-07 14:53:17 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:53:17 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:53:17 --> Utf8 Class Initialized
INFO - 2023-12-07 14:53:17 --> URI Class Initialized
INFO - 2023-12-07 14:53:17 --> Router Class Initialized
INFO - 2023-12-07 14:53:17 --> Output Class Initialized
INFO - 2023-12-07 14:53:17 --> Security Class Initialized
DEBUG - 2023-12-07 14:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:53:17 --> Input Class Initialized
INFO - 2023-12-07 14:53:17 --> Language Class Initialized
INFO - 2023-12-07 14:53:17 --> Loader Class Initialized
INFO - 2023-12-07 14:53:17 --> Helper loaded: url_helper
INFO - 2023-12-07 14:53:17 --> Helper loaded: form_helper
INFO - 2023-12-07 14:53:17 --> Helper loaded: file_helper
INFO - 2023-12-07 14:53:17 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:53:17 --> Form Validation Class Initialized
INFO - 2023-12-07 14:53:17 --> Upload Class Initialized
INFO - 2023-12-07 14:53:17 --> Model "M_auth" initialized
INFO - 2023-12-07 14:53:17 --> Model "M_user" initialized
INFO - 2023-12-07 14:53:17 --> Model "M_produk" initialized
INFO - 2023-12-07 14:53:17 --> Controller Class Initialized
INFO - 2023-12-07 14:53:17 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:53:17 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:53:17 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:53:17 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:53:17 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:53:17 --> Model "M_bank" initialized
INFO - 2023-12-07 14:53:17 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:53:17 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
ERROR - 2023-12-07 14:53:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:53:17 --> Config Class Initialized
INFO - 2023-12-07 14:53:17 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:53:17 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:53:17 --> Utf8 Class Initialized
INFO - 2023-12-07 14:53:17 --> URI Class Initialized
DEBUG - 2023-12-07 14:53:17 --> No URI present. Default controller set.
INFO - 2023-12-07 14:53:17 --> Router Class Initialized
INFO - 2023-12-07 14:53:17 --> Output Class Initialized
INFO - 2023-12-07 14:53:17 --> Security Class Initialized
DEBUG - 2023-12-07 14:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:53:17 --> Input Class Initialized
INFO - 2023-12-07 14:53:17 --> Language Class Initialized
INFO - 2023-12-07 14:53:17 --> Loader Class Initialized
INFO - 2023-12-07 14:53:17 --> Helper loaded: url_helper
INFO - 2023-12-07 14:53:17 --> Helper loaded: form_helper
INFO - 2023-12-07 14:53:17 --> Helper loaded: file_helper
INFO - 2023-12-07 14:53:17 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:53:17 --> Form Validation Class Initialized
INFO - 2023-12-07 14:53:17 --> Upload Class Initialized
INFO - 2023-12-07 14:53:17 --> Model "M_auth" initialized
INFO - 2023-12-07 14:53:17 --> Model "M_user" initialized
INFO - 2023-12-07 14:53:17 --> Model "M_produk" initialized
INFO - 2023-12-07 14:53:17 --> Controller Class Initialized
INFO - 2023-12-07 14:53:17 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:53:17 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:53:17 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:53:17 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:53:17 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:53:17 --> Model "M_bank" initialized
INFO - 2023-12-07 14:53:17 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:53:17 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 14:53:17 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 14:53:17 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/index.php
INFO - 2023-12-07 14:53:17 --> Final output sent to browser
DEBUG - 2023-12-07 14:53:17 --> Total execution time: 0.0319
ERROR - 2023-12-07 14:53:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:53:21 --> Config Class Initialized
INFO - 2023-12-07 14:53:21 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:53:21 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:53:21 --> Utf8 Class Initialized
INFO - 2023-12-07 14:53:21 --> URI Class Initialized
INFO - 2023-12-07 14:53:21 --> Router Class Initialized
INFO - 2023-12-07 14:53:21 --> Output Class Initialized
INFO - 2023-12-07 14:53:21 --> Security Class Initialized
DEBUG - 2023-12-07 14:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:53:21 --> Input Class Initialized
INFO - 2023-12-07 14:53:21 --> Language Class Initialized
INFO - 2023-12-07 14:53:21 --> Loader Class Initialized
INFO - 2023-12-07 14:53:21 --> Helper loaded: url_helper
INFO - 2023-12-07 14:53:21 --> Helper loaded: form_helper
INFO - 2023-12-07 14:53:21 --> Helper loaded: file_helper
INFO - 2023-12-07 14:53:21 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:53:21 --> Form Validation Class Initialized
INFO - 2023-12-07 14:53:21 --> Upload Class Initialized
INFO - 2023-12-07 14:53:21 --> Model "M_auth" initialized
INFO - 2023-12-07 14:53:21 --> Model "M_user" initialized
INFO - 2023-12-07 14:53:21 --> Model "M_produk" initialized
INFO - 2023-12-07 14:53:21 --> Controller Class Initialized
INFO - 2023-12-07 14:53:21 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\back/v_login.php
INFO - 2023-12-07 14:53:21 --> Final output sent to browser
DEBUG - 2023-12-07 14:53:21 --> Total execution time: 0.0439
ERROR - 2023-12-07 14:53:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:53:23 --> Config Class Initialized
INFO - 2023-12-07 14:53:23 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:53:23 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:53:23 --> Utf8 Class Initialized
INFO - 2023-12-07 14:53:23 --> URI Class Initialized
INFO - 2023-12-07 14:53:23 --> Router Class Initialized
INFO - 2023-12-07 14:53:23 --> Output Class Initialized
INFO - 2023-12-07 14:53:23 --> Security Class Initialized
DEBUG - 2023-12-07 14:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:53:23 --> Input Class Initialized
INFO - 2023-12-07 14:53:23 --> Language Class Initialized
INFO - 2023-12-07 14:53:23 --> Loader Class Initialized
INFO - 2023-12-07 14:53:23 --> Helper loaded: url_helper
INFO - 2023-12-07 14:53:23 --> Helper loaded: form_helper
INFO - 2023-12-07 14:53:23 --> Helper loaded: file_helper
INFO - 2023-12-07 14:53:23 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:53:23 --> Form Validation Class Initialized
INFO - 2023-12-07 14:53:23 --> Upload Class Initialized
INFO - 2023-12-07 14:53:23 --> Model "M_auth" initialized
INFO - 2023-12-07 14:53:23 --> Model "M_user" initialized
INFO - 2023-12-07 14:53:23 --> Model "M_produk" initialized
INFO - 2023-12-07 14:53:23 --> Controller Class Initialized
INFO - 2023-12-07 14:53:23 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2023-12-07 14:53:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:53:23 --> Config Class Initialized
INFO - 2023-12-07 14:53:23 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:53:23 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:53:23 --> Utf8 Class Initialized
INFO - 2023-12-07 14:53:23 --> URI Class Initialized
INFO - 2023-12-07 14:53:23 --> Router Class Initialized
INFO - 2023-12-07 14:53:23 --> Output Class Initialized
INFO - 2023-12-07 14:53:23 --> Security Class Initialized
DEBUG - 2023-12-07 14:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:53:23 --> Input Class Initialized
INFO - 2023-12-07 14:53:23 --> Language Class Initialized
INFO - 2023-12-07 14:53:23 --> Loader Class Initialized
INFO - 2023-12-07 14:53:23 --> Helper loaded: url_helper
INFO - 2023-12-07 14:53:23 --> Helper loaded: form_helper
INFO - 2023-12-07 14:53:23 --> Helper loaded: file_helper
INFO - 2023-12-07 14:53:23 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:53:23 --> Form Validation Class Initialized
INFO - 2023-12-07 14:53:23 --> Upload Class Initialized
INFO - 2023-12-07 14:53:23 --> Model "M_auth" initialized
INFO - 2023-12-07 14:53:23 --> Model "M_user" initialized
INFO - 2023-12-07 14:53:23 --> Model "M_produk" initialized
INFO - 2023-12-07 14:53:23 --> Controller Class Initialized
INFO - 2023-12-07 14:53:23 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\back/v_login.php
INFO - 2023-12-07 14:53:23 --> Final output sent to browser
DEBUG - 2023-12-07 14:53:23 --> Total execution time: 0.0648
ERROR - 2023-12-07 14:53:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:53:26 --> Config Class Initialized
INFO - 2023-12-07 14:53:26 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:53:26 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:53:26 --> Utf8 Class Initialized
INFO - 2023-12-07 14:53:26 --> URI Class Initialized
INFO - 2023-12-07 14:53:26 --> Router Class Initialized
INFO - 2023-12-07 14:53:26 --> Output Class Initialized
INFO - 2023-12-07 14:53:26 --> Security Class Initialized
DEBUG - 2023-12-07 14:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:53:26 --> Input Class Initialized
INFO - 2023-12-07 14:53:26 --> Language Class Initialized
INFO - 2023-12-07 14:53:26 --> Loader Class Initialized
INFO - 2023-12-07 14:53:26 --> Helper loaded: url_helper
INFO - 2023-12-07 14:53:26 --> Helper loaded: form_helper
INFO - 2023-12-07 14:53:26 --> Helper loaded: file_helper
INFO - 2023-12-07 14:53:26 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:53:26 --> Form Validation Class Initialized
INFO - 2023-12-07 14:53:26 --> Upload Class Initialized
INFO - 2023-12-07 14:53:26 --> Model "M_auth" initialized
INFO - 2023-12-07 14:53:26 --> Model "M_user" initialized
INFO - 2023-12-07 14:53:26 --> Model "M_produk" initialized
INFO - 2023-12-07 14:53:26 --> Controller Class Initialized
INFO - 2023-12-07 14:53:26 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2023-12-07 14:53:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:53:26 --> Config Class Initialized
INFO - 2023-12-07 14:53:26 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:53:26 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:53:26 --> Utf8 Class Initialized
INFO - 2023-12-07 14:53:26 --> URI Class Initialized
INFO - 2023-12-07 14:53:26 --> Router Class Initialized
INFO - 2023-12-07 14:53:26 --> Output Class Initialized
INFO - 2023-12-07 14:53:26 --> Security Class Initialized
DEBUG - 2023-12-07 14:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:53:26 --> Input Class Initialized
INFO - 2023-12-07 14:53:26 --> Language Class Initialized
INFO - 2023-12-07 14:53:26 --> Loader Class Initialized
INFO - 2023-12-07 14:53:26 --> Helper loaded: url_helper
INFO - 2023-12-07 14:53:26 --> Helper loaded: form_helper
INFO - 2023-12-07 14:53:26 --> Helper loaded: file_helper
INFO - 2023-12-07 14:53:26 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:53:26 --> Form Validation Class Initialized
INFO - 2023-12-07 14:53:26 --> Upload Class Initialized
INFO - 2023-12-07 14:53:26 --> Model "M_auth" initialized
INFO - 2023-12-07 14:53:26 --> Model "M_user" initialized
INFO - 2023-12-07 14:53:26 --> Model "M_produk" initialized
INFO - 2023-12-07 14:53:26 --> Controller Class Initialized
INFO - 2023-12-07 14:53:26 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\back/v_login.php
INFO - 2023-12-07 14:53:26 --> Final output sent to browser
DEBUG - 2023-12-07 14:53:26 --> Total execution time: 0.0609
ERROR - 2023-12-07 14:53:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:53:28 --> Config Class Initialized
INFO - 2023-12-07 14:53:28 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:53:28 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:53:28 --> Utf8 Class Initialized
INFO - 2023-12-07 14:53:28 --> URI Class Initialized
INFO - 2023-12-07 14:53:28 --> Router Class Initialized
INFO - 2023-12-07 14:53:28 --> Output Class Initialized
INFO - 2023-12-07 14:53:28 --> Security Class Initialized
DEBUG - 2023-12-07 14:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:53:28 --> Input Class Initialized
INFO - 2023-12-07 14:53:28 --> Language Class Initialized
INFO - 2023-12-07 14:53:28 --> Loader Class Initialized
INFO - 2023-12-07 14:53:28 --> Helper loaded: url_helper
INFO - 2023-12-07 14:53:28 --> Helper loaded: form_helper
INFO - 2023-12-07 14:53:28 --> Helper loaded: file_helper
INFO - 2023-12-07 14:53:28 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:53:28 --> Form Validation Class Initialized
INFO - 2023-12-07 14:53:28 --> Upload Class Initialized
INFO - 2023-12-07 14:53:28 --> Model "M_auth" initialized
INFO - 2023-12-07 14:53:28 --> Model "M_user" initialized
INFO - 2023-12-07 14:53:28 --> Model "M_produk" initialized
INFO - 2023-12-07 14:53:28 --> Controller Class Initialized
INFO - 2023-12-07 14:53:28 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2023-12-07 14:53:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:53:28 --> Config Class Initialized
INFO - 2023-12-07 14:53:28 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:53:28 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:53:28 --> Utf8 Class Initialized
INFO - 2023-12-07 14:53:28 --> URI Class Initialized
INFO - 2023-12-07 14:53:28 --> Router Class Initialized
INFO - 2023-12-07 14:53:28 --> Output Class Initialized
INFO - 2023-12-07 14:53:28 --> Security Class Initialized
DEBUG - 2023-12-07 14:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:53:28 --> Input Class Initialized
INFO - 2023-12-07 14:53:28 --> Language Class Initialized
INFO - 2023-12-07 14:53:28 --> Loader Class Initialized
INFO - 2023-12-07 14:53:28 --> Helper loaded: url_helper
INFO - 2023-12-07 14:53:28 --> Helper loaded: form_helper
INFO - 2023-12-07 14:53:28 --> Helper loaded: file_helper
INFO - 2023-12-07 14:53:28 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:53:28 --> Form Validation Class Initialized
INFO - 2023-12-07 14:53:28 --> Upload Class Initialized
INFO - 2023-12-07 14:53:28 --> Model "M_auth" initialized
INFO - 2023-12-07 14:53:28 --> Model "M_user" initialized
INFO - 2023-12-07 14:53:28 --> Model "M_produk" initialized
INFO - 2023-12-07 14:53:28 --> Controller Class Initialized
INFO - 2023-12-07 14:53:28 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\back/v_login.php
INFO - 2023-12-07 14:53:28 --> Final output sent to browser
DEBUG - 2023-12-07 14:53:28 --> Total execution time: 0.0281
ERROR - 2023-12-07 14:53:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:53:31 --> Config Class Initialized
INFO - 2023-12-07 14:53:31 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:53:31 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:53:31 --> Utf8 Class Initialized
INFO - 2023-12-07 14:53:31 --> URI Class Initialized
INFO - 2023-12-07 14:53:31 --> Router Class Initialized
INFO - 2023-12-07 14:53:31 --> Output Class Initialized
INFO - 2023-12-07 14:53:31 --> Security Class Initialized
DEBUG - 2023-12-07 14:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:53:31 --> Input Class Initialized
INFO - 2023-12-07 14:53:31 --> Language Class Initialized
INFO - 2023-12-07 14:53:31 --> Loader Class Initialized
INFO - 2023-12-07 14:53:31 --> Helper loaded: url_helper
INFO - 2023-12-07 14:53:31 --> Helper loaded: form_helper
INFO - 2023-12-07 14:53:31 --> Helper loaded: file_helper
INFO - 2023-12-07 14:53:31 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:53:31 --> Form Validation Class Initialized
INFO - 2023-12-07 14:53:31 --> Upload Class Initialized
INFO - 2023-12-07 14:53:31 --> Model "M_auth" initialized
INFO - 2023-12-07 14:53:31 --> Model "M_user" initialized
INFO - 2023-12-07 14:53:31 --> Model "M_produk" initialized
INFO - 2023-12-07 14:53:31 --> Controller Class Initialized
INFO - 2023-12-07 14:53:31 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2023-12-07 14:53:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:53:31 --> Config Class Initialized
INFO - 2023-12-07 14:53:31 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:53:31 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:53:31 --> Utf8 Class Initialized
INFO - 2023-12-07 14:53:31 --> URI Class Initialized
INFO - 2023-12-07 14:53:31 --> Router Class Initialized
INFO - 2023-12-07 14:53:31 --> Output Class Initialized
INFO - 2023-12-07 14:53:31 --> Security Class Initialized
DEBUG - 2023-12-07 14:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:53:31 --> Input Class Initialized
INFO - 2023-12-07 14:53:31 --> Language Class Initialized
INFO - 2023-12-07 14:53:31 --> Loader Class Initialized
INFO - 2023-12-07 14:53:31 --> Helper loaded: url_helper
INFO - 2023-12-07 14:53:31 --> Helper loaded: form_helper
INFO - 2023-12-07 14:53:31 --> Helper loaded: file_helper
INFO - 2023-12-07 14:53:31 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:53:31 --> Form Validation Class Initialized
INFO - 2023-12-07 14:53:31 --> Upload Class Initialized
INFO - 2023-12-07 14:53:31 --> Model "M_auth" initialized
INFO - 2023-12-07 14:53:31 --> Model "M_user" initialized
INFO - 2023-12-07 14:53:31 --> Model "M_produk" initialized
INFO - 2023-12-07 14:53:31 --> Controller Class Initialized
INFO - 2023-12-07 14:53:31 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\back/v_login.php
INFO - 2023-12-07 14:53:31 --> Final output sent to browser
DEBUG - 2023-12-07 14:53:31 --> Total execution time: 0.0451
ERROR - 2023-12-07 14:53:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:53:46 --> Config Class Initialized
INFO - 2023-12-07 14:53:46 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:53:46 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:53:46 --> Utf8 Class Initialized
INFO - 2023-12-07 14:53:46 --> URI Class Initialized
INFO - 2023-12-07 14:53:46 --> Router Class Initialized
INFO - 2023-12-07 14:53:46 --> Output Class Initialized
INFO - 2023-12-07 14:53:46 --> Security Class Initialized
DEBUG - 2023-12-07 14:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:53:46 --> Input Class Initialized
INFO - 2023-12-07 14:53:46 --> Language Class Initialized
INFO - 2023-12-07 14:53:46 --> Loader Class Initialized
INFO - 2023-12-07 14:53:46 --> Helper loaded: url_helper
INFO - 2023-12-07 14:53:46 --> Helper loaded: form_helper
INFO - 2023-12-07 14:53:46 --> Helper loaded: file_helper
INFO - 2023-12-07 14:53:46 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:53:46 --> Form Validation Class Initialized
INFO - 2023-12-07 14:53:46 --> Upload Class Initialized
INFO - 2023-12-07 14:53:46 --> Model "M_auth" initialized
INFO - 2023-12-07 14:53:46 --> Model "M_user" initialized
INFO - 2023-12-07 14:53:46 --> Model "M_produk" initialized
INFO - 2023-12-07 14:53:46 --> Controller Class Initialized
INFO - 2023-12-07 14:53:46 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2023-12-07 14:53:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:53:46 --> Config Class Initialized
INFO - 2023-12-07 14:53:46 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:53:46 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:53:46 --> Utf8 Class Initialized
INFO - 2023-12-07 14:53:46 --> URI Class Initialized
INFO - 2023-12-07 14:53:46 --> Router Class Initialized
INFO - 2023-12-07 14:53:46 --> Output Class Initialized
INFO - 2023-12-07 14:53:46 --> Security Class Initialized
DEBUG - 2023-12-07 14:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:53:46 --> Input Class Initialized
INFO - 2023-12-07 14:53:46 --> Language Class Initialized
INFO - 2023-12-07 14:53:46 --> Loader Class Initialized
INFO - 2023-12-07 14:53:46 --> Helper loaded: url_helper
INFO - 2023-12-07 14:53:46 --> Helper loaded: form_helper
INFO - 2023-12-07 14:53:46 --> Helper loaded: file_helper
INFO - 2023-12-07 14:53:46 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:53:46 --> Form Validation Class Initialized
INFO - 2023-12-07 14:53:46 --> Upload Class Initialized
INFO - 2023-12-07 14:53:46 --> Model "M_auth" initialized
INFO - 2023-12-07 14:53:46 --> Model "M_user" initialized
INFO - 2023-12-07 14:53:46 --> Model "M_produk" initialized
INFO - 2023-12-07 14:53:46 --> Controller Class Initialized
INFO - 2023-12-07 14:53:46 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\back/v_dashboard.php
INFO - 2023-12-07 14:53:46 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\back/v_wrapper.php
INFO - 2023-12-07 14:53:46 --> Final output sent to browser
DEBUG - 2023-12-07 14:53:46 --> Total execution time: 0.0715
ERROR - 2023-12-07 14:53:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:53:52 --> Config Class Initialized
INFO - 2023-12-07 14:53:52 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:53:52 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:53:52 --> Utf8 Class Initialized
INFO - 2023-12-07 14:53:52 --> URI Class Initialized
INFO - 2023-12-07 14:53:52 --> Router Class Initialized
INFO - 2023-12-07 14:53:52 --> Output Class Initialized
INFO - 2023-12-07 14:53:52 --> Security Class Initialized
DEBUG - 2023-12-07 14:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:53:52 --> Input Class Initialized
INFO - 2023-12-07 14:53:52 --> Language Class Initialized
INFO - 2023-12-07 14:53:52 --> Loader Class Initialized
INFO - 2023-12-07 14:53:52 --> Helper loaded: url_helper
INFO - 2023-12-07 14:53:52 --> Helper loaded: form_helper
INFO - 2023-12-07 14:53:52 --> Helper loaded: file_helper
INFO - 2023-12-07 14:53:52 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:53:52 --> Form Validation Class Initialized
INFO - 2023-12-07 14:53:52 --> Upload Class Initialized
INFO - 2023-12-07 14:53:52 --> Model "M_auth" initialized
INFO - 2023-12-07 14:53:52 --> Model "M_user" initialized
INFO - 2023-12-07 14:53:52 --> Model "M_produk" initialized
INFO - 2023-12-07 14:53:52 --> Controller Class Initialized
INFO - 2023-12-07 14:53:52 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\back/v_user_profile.php
INFO - 2023-12-07 14:53:52 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\back/v_wrapper.php
INFO - 2023-12-07 14:53:52 --> Final output sent to browser
DEBUG - 2023-12-07 14:53:52 --> Total execution time: 0.1723
ERROR - 2023-12-07 14:53:55 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:53:55 --> Config Class Initialized
INFO - 2023-12-07 14:53:55 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:53:55 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:53:55 --> Utf8 Class Initialized
INFO - 2023-12-07 14:53:55 --> URI Class Initialized
INFO - 2023-12-07 14:53:55 --> Router Class Initialized
INFO - 2023-12-07 14:53:55 --> Output Class Initialized
INFO - 2023-12-07 14:53:55 --> Security Class Initialized
DEBUG - 2023-12-07 14:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:53:55 --> Input Class Initialized
INFO - 2023-12-07 14:53:55 --> Language Class Initialized
INFO - 2023-12-07 14:53:55 --> Loader Class Initialized
INFO - 2023-12-07 14:53:55 --> Helper loaded: url_helper
INFO - 2023-12-07 14:53:55 --> Helper loaded: form_helper
INFO - 2023-12-07 14:53:55 --> Helper loaded: file_helper
INFO - 2023-12-07 14:53:55 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:53:55 --> Form Validation Class Initialized
INFO - 2023-12-07 14:53:55 --> Upload Class Initialized
INFO - 2023-12-07 14:53:55 --> Model "M_auth" initialized
INFO - 2023-12-07 14:53:55 --> Model "M_user" initialized
INFO - 2023-12-07 14:53:55 --> Model "M_produk" initialized
INFO - 2023-12-07 14:53:55 --> Controller Class Initialized
INFO - 2023-12-07 14:53:55 --> Model "M_produk" initialized
INFO - 2023-12-07 14:53:55 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\back/v_typeproduk.php
INFO - 2023-12-07 14:53:55 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\back/v_wrapper.php
INFO - 2023-12-07 14:53:55 --> Final output sent to browser
DEBUG - 2023-12-07 14:53:55 --> Total execution time: 0.2203
ERROR - 2023-12-07 14:53:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:53:59 --> Config Class Initialized
INFO - 2023-12-07 14:53:59 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:53:59 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:53:59 --> Utf8 Class Initialized
INFO - 2023-12-07 14:53:59 --> URI Class Initialized
INFO - 2023-12-07 14:53:59 --> Router Class Initialized
INFO - 2023-12-07 14:53:59 --> Output Class Initialized
INFO - 2023-12-07 14:53:59 --> Security Class Initialized
DEBUG - 2023-12-07 14:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:53:59 --> Input Class Initialized
INFO - 2023-12-07 14:53:59 --> Language Class Initialized
INFO - 2023-12-07 14:53:59 --> Loader Class Initialized
INFO - 2023-12-07 14:53:59 --> Helper loaded: url_helper
INFO - 2023-12-07 14:53:59 --> Helper loaded: form_helper
INFO - 2023-12-07 14:53:59 --> Helper loaded: file_helper
INFO - 2023-12-07 14:53:59 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:53:59 --> Form Validation Class Initialized
INFO - 2023-12-07 14:53:59 --> Upload Class Initialized
INFO - 2023-12-07 14:53:59 --> Model "M_auth" initialized
INFO - 2023-12-07 14:53:59 --> Model "M_user" initialized
INFO - 2023-12-07 14:53:59 --> Model "M_produk" initialized
INFO - 2023-12-07 14:53:59 --> Controller Class Initialized
INFO - 2023-12-07 14:53:59 --> Model "M_produk" initialized
INFO - 2023-12-07 14:53:59 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\back/v_produk.php
INFO - 2023-12-07 14:53:59 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\back/v_wrapper.php
INFO - 2023-12-07 14:53:59 --> Final output sent to browser
DEBUG - 2023-12-07 14:53:59 --> Total execution time: 0.0941
ERROR - 2023-12-07 14:55:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:55:44 --> Config Class Initialized
INFO - 2023-12-07 14:55:44 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:55:44 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:55:44 --> Utf8 Class Initialized
INFO - 2023-12-07 14:55:44 --> URI Class Initialized
INFO - 2023-12-07 14:55:44 --> Router Class Initialized
INFO - 2023-12-07 14:55:44 --> Output Class Initialized
INFO - 2023-12-07 14:55:44 --> Security Class Initialized
DEBUG - 2023-12-07 14:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:55:44 --> Input Class Initialized
INFO - 2023-12-07 14:55:44 --> Language Class Initialized
INFO - 2023-12-07 14:55:44 --> Loader Class Initialized
INFO - 2023-12-07 14:55:44 --> Helper loaded: url_helper
INFO - 2023-12-07 14:55:44 --> Helper loaded: form_helper
INFO - 2023-12-07 14:55:44 --> Helper loaded: file_helper
INFO - 2023-12-07 14:55:44 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:55:45 --> Form Validation Class Initialized
INFO - 2023-12-07 14:55:45 --> Upload Class Initialized
INFO - 2023-12-07 14:55:45 --> Model "M_auth" initialized
INFO - 2023-12-07 14:55:45 --> Model "M_user" initialized
INFO - 2023-12-07 14:55:45 --> Model "M_produk" initialized
INFO - 2023-12-07 14:55:45 --> Controller Class Initialized
INFO - 2023-12-07 14:55:45 --> Model "M_produk" initialized
INFO - 2023-12-07 14:55:45 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\back/v_produk.php
INFO - 2023-12-07 14:55:45 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\back/v_wrapper.php
INFO - 2023-12-07 14:55:45 --> Final output sent to browser
DEBUG - 2023-12-07 14:55:45 --> Total execution time: 0.1000
ERROR - 2023-12-07 14:55:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:55:48 --> Config Class Initialized
INFO - 2023-12-07 14:55:48 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:55:48 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:55:48 --> Utf8 Class Initialized
INFO - 2023-12-07 14:55:48 --> URI Class Initialized
INFO - 2023-12-07 14:55:48 --> Router Class Initialized
INFO - 2023-12-07 14:55:48 --> Output Class Initialized
INFO - 2023-12-07 14:55:48 --> Security Class Initialized
DEBUG - 2023-12-07 14:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:55:48 --> Input Class Initialized
INFO - 2023-12-07 14:55:48 --> Language Class Initialized
INFO - 2023-12-07 14:55:48 --> Loader Class Initialized
INFO - 2023-12-07 14:55:48 --> Helper loaded: url_helper
INFO - 2023-12-07 14:55:48 --> Helper loaded: form_helper
INFO - 2023-12-07 14:55:48 --> Helper loaded: file_helper
INFO - 2023-12-07 14:55:48 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:55:48 --> Form Validation Class Initialized
INFO - 2023-12-07 14:55:48 --> Upload Class Initialized
INFO - 2023-12-07 14:55:48 --> Model "M_auth" initialized
INFO - 2023-12-07 14:55:48 --> Model "M_user" initialized
INFO - 2023-12-07 14:55:48 --> Model "M_produk" initialized
INFO - 2023-12-07 14:55:48 --> Controller Class Initialized
INFO - 2023-12-07 14:55:48 --> Model "M_produk" initialized
INFO - 2023-12-07 14:55:48 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\back/v_produk.php
INFO - 2023-12-07 14:55:48 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\back/v_wrapper.php
INFO - 2023-12-07 14:55:48 --> Final output sent to browser
DEBUG - 2023-12-07 14:55:48 --> Total execution time: 0.0819
ERROR - 2023-12-07 14:56:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:56:21 --> Config Class Initialized
INFO - 2023-12-07 14:56:21 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:56:21 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:56:21 --> Utf8 Class Initialized
INFO - 2023-12-07 14:56:21 --> URI Class Initialized
INFO - 2023-12-07 14:56:21 --> Router Class Initialized
INFO - 2023-12-07 14:56:21 --> Output Class Initialized
INFO - 2023-12-07 14:56:21 --> Security Class Initialized
DEBUG - 2023-12-07 14:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:56:21 --> Input Class Initialized
INFO - 2023-12-07 14:56:21 --> Language Class Initialized
INFO - 2023-12-07 14:56:21 --> Loader Class Initialized
INFO - 2023-12-07 14:56:21 --> Helper loaded: url_helper
INFO - 2023-12-07 14:56:21 --> Helper loaded: form_helper
INFO - 2023-12-07 14:56:21 --> Helper loaded: file_helper
INFO - 2023-12-07 14:56:21 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:56:21 --> Form Validation Class Initialized
INFO - 2023-12-07 14:56:21 --> Upload Class Initialized
INFO - 2023-12-07 14:56:21 --> Model "M_auth" initialized
INFO - 2023-12-07 14:56:21 --> Model "M_user" initialized
INFO - 2023-12-07 14:56:21 --> Model "M_produk" initialized
INFO - 2023-12-07 14:56:21 --> Controller Class Initialized
ERROR - 2023-12-07 14:56:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:56:21 --> Config Class Initialized
INFO - 2023-12-07 14:56:21 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:56:21 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:56:21 --> Utf8 Class Initialized
INFO - 2023-12-07 14:56:21 --> URI Class Initialized
INFO - 2023-12-07 14:56:21 --> Router Class Initialized
INFO - 2023-12-07 14:56:21 --> Output Class Initialized
INFO - 2023-12-07 14:56:21 --> Security Class Initialized
DEBUG - 2023-12-07 14:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:56:21 --> Input Class Initialized
INFO - 2023-12-07 14:56:21 --> Language Class Initialized
INFO - 2023-12-07 14:56:21 --> Loader Class Initialized
INFO - 2023-12-07 14:56:21 --> Helper loaded: url_helper
INFO - 2023-12-07 14:56:21 --> Helper loaded: form_helper
INFO - 2023-12-07 14:56:21 --> Helper loaded: file_helper
INFO - 2023-12-07 14:56:21 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:56:21 --> Form Validation Class Initialized
INFO - 2023-12-07 14:56:21 --> Upload Class Initialized
INFO - 2023-12-07 14:56:21 --> Model "M_auth" initialized
INFO - 2023-12-07 14:56:21 --> Model "M_user" initialized
INFO - 2023-12-07 14:56:21 --> Model "M_produk" initialized
INFO - 2023-12-07 14:56:21 --> Controller Class Initialized
INFO - 2023-12-07 14:56:21 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\back/v_login.php
INFO - 2023-12-07 14:56:21 --> Final output sent to browser
DEBUG - 2023-12-07 14:56:21 --> Total execution time: 0.0228
ERROR - 2023-12-07 14:56:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:56:26 --> Config Class Initialized
INFO - 2023-12-07 14:56:26 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:56:26 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:56:26 --> Utf8 Class Initialized
INFO - 2023-12-07 14:56:26 --> URI Class Initialized
DEBUG - 2023-12-07 14:56:26 --> No URI present. Default controller set.
INFO - 2023-12-07 14:56:26 --> Router Class Initialized
INFO - 2023-12-07 14:56:26 --> Output Class Initialized
INFO - 2023-12-07 14:56:26 --> Security Class Initialized
DEBUG - 2023-12-07 14:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:56:26 --> Input Class Initialized
INFO - 2023-12-07 14:56:26 --> Language Class Initialized
INFO - 2023-12-07 14:56:26 --> Loader Class Initialized
INFO - 2023-12-07 14:56:26 --> Helper loaded: url_helper
INFO - 2023-12-07 14:56:26 --> Helper loaded: form_helper
INFO - 2023-12-07 14:56:26 --> Helper loaded: file_helper
INFO - 2023-12-07 14:56:26 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:56:26 --> Form Validation Class Initialized
INFO - 2023-12-07 14:56:26 --> Upload Class Initialized
INFO - 2023-12-07 14:56:26 --> Model "M_auth" initialized
INFO - 2023-12-07 14:56:26 --> Model "M_user" initialized
INFO - 2023-12-07 14:56:26 --> Model "M_produk" initialized
INFO - 2023-12-07 14:56:26 --> Controller Class Initialized
INFO - 2023-12-07 14:56:26 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:56:26 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:56:26 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:56:26 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:56:26 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:56:26 --> Model "M_bank" initialized
INFO - 2023-12-07 14:56:26 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:56:26 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 14:56:26 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 14:56:26 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/index.php
INFO - 2023-12-07 14:56:26 --> Final output sent to browser
DEBUG - 2023-12-07 14:56:26 --> Total execution time: 0.0591
ERROR - 2023-12-07 14:56:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:56:33 --> Config Class Initialized
INFO - 2023-12-07 14:56:33 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:56:33 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:56:33 --> Utf8 Class Initialized
INFO - 2023-12-07 14:56:33 --> URI Class Initialized
DEBUG - 2023-12-07 14:56:33 --> No URI present. Default controller set.
INFO - 2023-12-07 14:56:33 --> Router Class Initialized
INFO - 2023-12-07 14:56:33 --> Output Class Initialized
INFO - 2023-12-07 14:56:33 --> Security Class Initialized
DEBUG - 2023-12-07 14:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:56:33 --> Input Class Initialized
INFO - 2023-12-07 14:56:33 --> Language Class Initialized
INFO - 2023-12-07 14:56:33 --> Loader Class Initialized
INFO - 2023-12-07 14:56:33 --> Helper loaded: url_helper
INFO - 2023-12-07 14:56:33 --> Helper loaded: form_helper
INFO - 2023-12-07 14:56:33 --> Helper loaded: file_helper
INFO - 2023-12-07 14:56:33 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:56:33 --> Form Validation Class Initialized
INFO - 2023-12-07 14:56:33 --> Upload Class Initialized
INFO - 2023-12-07 14:56:33 --> Model "M_auth" initialized
INFO - 2023-12-07 14:56:33 --> Model "M_user" initialized
INFO - 2023-12-07 14:56:33 --> Model "M_produk" initialized
INFO - 2023-12-07 14:56:33 --> Controller Class Initialized
INFO - 2023-12-07 14:56:33 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:56:33 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:56:33 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:56:33 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:56:33 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:56:33 --> Model "M_bank" initialized
INFO - 2023-12-07 14:56:33 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:56:33 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 14:56:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-12-07 14:56:33 --> Email Class Initialized
INFO - 2023-12-07 14:56:34 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-12-07 14:56:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:56:37 --> Config Class Initialized
INFO - 2023-12-07 14:56:37 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:56:37 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:56:37 --> Utf8 Class Initialized
INFO - 2023-12-07 14:56:37 --> URI Class Initialized
DEBUG - 2023-12-07 14:56:37 --> No URI present. Default controller set.
INFO - 2023-12-07 14:56:37 --> Router Class Initialized
INFO - 2023-12-07 14:56:37 --> Output Class Initialized
INFO - 2023-12-07 14:56:37 --> Security Class Initialized
DEBUG - 2023-12-07 14:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:56:37 --> Input Class Initialized
INFO - 2023-12-07 14:56:37 --> Language Class Initialized
INFO - 2023-12-07 14:56:37 --> Loader Class Initialized
INFO - 2023-12-07 14:56:37 --> Helper loaded: url_helper
INFO - 2023-12-07 14:56:37 --> Helper loaded: form_helper
INFO - 2023-12-07 14:56:37 --> Helper loaded: file_helper
INFO - 2023-12-07 14:56:37 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:56:37 --> Form Validation Class Initialized
INFO - 2023-12-07 14:56:37 --> Upload Class Initialized
INFO - 2023-12-07 14:56:37 --> Model "M_auth" initialized
INFO - 2023-12-07 14:56:37 --> Model "M_user" initialized
INFO - 2023-12-07 14:56:37 --> Model "M_produk" initialized
INFO - 2023-12-07 14:56:37 --> Controller Class Initialized
INFO - 2023-12-07 14:56:37 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:56:37 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:56:37 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:56:37 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:56:37 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:56:37 --> Model "M_bank" initialized
INFO - 2023-12-07 14:56:37 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:56:37 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 14:56:37 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 14:56:37 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/index.php
INFO - 2023-12-07 14:56:37 --> Final output sent to browser
DEBUG - 2023-12-07 14:56:37 --> Total execution time: 0.1174
ERROR - 2023-12-07 14:56:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:56:42 --> Config Class Initialized
INFO - 2023-12-07 14:56:42 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:56:42 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:56:42 --> Utf8 Class Initialized
INFO - 2023-12-07 14:56:42 --> URI Class Initialized
INFO - 2023-12-07 14:56:42 --> Router Class Initialized
INFO - 2023-12-07 14:56:42 --> Output Class Initialized
INFO - 2023-12-07 14:56:42 --> Security Class Initialized
DEBUG - 2023-12-07 14:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:56:42 --> Input Class Initialized
INFO - 2023-12-07 14:56:42 --> Language Class Initialized
INFO - 2023-12-07 14:56:42 --> Loader Class Initialized
INFO - 2023-12-07 14:56:42 --> Helper loaded: url_helper
INFO - 2023-12-07 14:56:42 --> Helper loaded: form_helper
INFO - 2023-12-07 14:56:42 --> Helper loaded: file_helper
INFO - 2023-12-07 14:56:42 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:56:42 --> Form Validation Class Initialized
INFO - 2023-12-07 14:56:42 --> Upload Class Initialized
INFO - 2023-12-07 14:56:42 --> Model "M_auth" initialized
INFO - 2023-12-07 14:56:42 --> Model "M_user" initialized
INFO - 2023-12-07 14:56:42 --> Model "M_produk" initialized
INFO - 2023-12-07 14:56:42 --> Controller Class Initialized
INFO - 2023-12-07 14:56:42 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:56:42 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:56:42 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:56:42 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:56:42 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:56:42 --> Model "M_bank" initialized
INFO - 2023-12-07 14:56:42 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:56:42 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 14:56:42 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 14:56:42 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 14:56:42 --> Final output sent to browser
DEBUG - 2023-12-07 14:56:42 --> Total execution time: 0.4542
ERROR - 2023-12-07 14:57:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:57:04 --> Config Class Initialized
INFO - 2023-12-07 14:57:04 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:57:04 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:57:04 --> Utf8 Class Initialized
INFO - 2023-12-07 14:57:04 --> URI Class Initialized
INFO - 2023-12-07 14:57:04 --> Router Class Initialized
INFO - 2023-12-07 14:57:04 --> Output Class Initialized
INFO - 2023-12-07 14:57:04 --> Security Class Initialized
DEBUG - 2023-12-07 14:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:57:04 --> Input Class Initialized
INFO - 2023-12-07 14:57:04 --> Language Class Initialized
INFO - 2023-12-07 14:57:04 --> Loader Class Initialized
INFO - 2023-12-07 14:57:04 --> Helper loaded: url_helper
INFO - 2023-12-07 14:57:04 --> Helper loaded: form_helper
INFO - 2023-12-07 14:57:04 --> Helper loaded: file_helper
INFO - 2023-12-07 14:57:04 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:57:04 --> Form Validation Class Initialized
INFO - 2023-12-07 14:57:04 --> Upload Class Initialized
INFO - 2023-12-07 14:57:04 --> Model "M_auth" initialized
INFO - 2023-12-07 14:57:04 --> Model "M_user" initialized
INFO - 2023-12-07 14:57:04 --> Model "M_produk" initialized
INFO - 2023-12-07 14:57:04 --> Controller Class Initialized
INFO - 2023-12-07 14:57:04 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:57:04 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:57:04 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:57:04 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:57:04 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:57:04 --> Model "M_bank" initialized
INFO - 2023-12-07 14:57:04 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:57:04 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 14:57:05 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 14:57:05 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 14:57:05 --> Final output sent to browser
DEBUG - 2023-12-07 14:57:05 --> Total execution time: 0.4298
ERROR - 2023-12-07 14:57:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:57:09 --> Config Class Initialized
INFO - 2023-12-07 14:57:09 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:57:09 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:57:09 --> Utf8 Class Initialized
INFO - 2023-12-07 14:57:09 --> URI Class Initialized
INFO - 2023-12-07 14:57:09 --> Router Class Initialized
INFO - 2023-12-07 14:57:09 --> Output Class Initialized
INFO - 2023-12-07 14:57:09 --> Security Class Initialized
DEBUG - 2023-12-07 14:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:57:09 --> Input Class Initialized
INFO - 2023-12-07 14:57:09 --> Language Class Initialized
INFO - 2023-12-07 14:57:09 --> Loader Class Initialized
INFO - 2023-12-07 14:57:09 --> Helper loaded: url_helper
INFO - 2023-12-07 14:57:09 --> Helper loaded: form_helper
INFO - 2023-12-07 14:57:09 --> Helper loaded: file_helper
INFO - 2023-12-07 14:57:09 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:57:09 --> Form Validation Class Initialized
INFO - 2023-12-07 14:57:09 --> Upload Class Initialized
INFO - 2023-12-07 14:57:09 --> Model "M_auth" initialized
INFO - 2023-12-07 14:57:09 --> Model "M_user" initialized
INFO - 2023-12-07 14:57:09 --> Model "M_produk" initialized
INFO - 2023-12-07 14:57:09 --> Controller Class Initialized
INFO - 2023-12-07 14:57:09 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:57:09 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:57:09 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:57:09 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:57:09 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:57:09 --> Model "M_bank" initialized
INFO - 2023-12-07 14:57:09 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:57:09 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 14:57:09 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 14:57:09 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 14:57:09 --> Final output sent to browser
DEBUG - 2023-12-07 14:57:09 --> Total execution time: 0.4195
ERROR - 2023-12-07 14:57:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:57:44 --> Config Class Initialized
INFO - 2023-12-07 14:57:44 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:57:44 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:57:44 --> Utf8 Class Initialized
INFO - 2023-12-07 14:57:44 --> URI Class Initialized
INFO - 2023-12-07 14:57:44 --> Router Class Initialized
INFO - 2023-12-07 14:57:44 --> Output Class Initialized
INFO - 2023-12-07 14:57:44 --> Security Class Initialized
DEBUG - 2023-12-07 14:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:57:44 --> Input Class Initialized
INFO - 2023-12-07 14:57:44 --> Language Class Initialized
INFO - 2023-12-07 14:57:44 --> Loader Class Initialized
INFO - 2023-12-07 14:57:44 --> Helper loaded: url_helper
INFO - 2023-12-07 14:57:44 --> Helper loaded: form_helper
INFO - 2023-12-07 14:57:44 --> Helper loaded: file_helper
INFO - 2023-12-07 14:57:44 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:57:44 --> Form Validation Class Initialized
INFO - 2023-12-07 14:57:44 --> Upload Class Initialized
INFO - 2023-12-07 14:57:44 --> Model "M_auth" initialized
INFO - 2023-12-07 14:57:44 --> Model "M_user" initialized
INFO - 2023-12-07 14:57:44 --> Model "M_produk" initialized
INFO - 2023-12-07 14:57:44 --> Controller Class Initialized
INFO - 2023-12-07 14:57:44 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:57:44 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:57:44 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:57:44 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:57:44 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:57:44 --> Model "M_bank" initialized
INFO - 2023-12-07 14:57:44 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:57:44 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 14:57:46 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 14:57:46 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 14:57:46 --> Final output sent to browser
DEBUG - 2023-12-07 14:57:46 --> Total execution time: 2.3762
ERROR - 2023-12-07 14:57:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:57:54 --> Config Class Initialized
INFO - 2023-12-07 14:57:54 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:57:54 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:57:54 --> Utf8 Class Initialized
INFO - 2023-12-07 14:57:54 --> URI Class Initialized
INFO - 2023-12-07 14:57:54 --> Router Class Initialized
INFO - 2023-12-07 14:57:54 --> Output Class Initialized
INFO - 2023-12-07 14:57:54 --> Security Class Initialized
DEBUG - 2023-12-07 14:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:57:54 --> Input Class Initialized
INFO - 2023-12-07 14:57:54 --> Language Class Initialized
INFO - 2023-12-07 14:57:54 --> Loader Class Initialized
INFO - 2023-12-07 14:57:54 --> Helper loaded: url_helper
INFO - 2023-12-07 14:57:54 --> Helper loaded: form_helper
INFO - 2023-12-07 14:57:54 --> Helper loaded: file_helper
INFO - 2023-12-07 14:57:54 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:57:54 --> Form Validation Class Initialized
INFO - 2023-12-07 14:57:54 --> Upload Class Initialized
INFO - 2023-12-07 14:57:54 --> Model "M_auth" initialized
INFO - 2023-12-07 14:57:54 --> Model "M_user" initialized
INFO - 2023-12-07 14:57:54 --> Model "M_produk" initialized
INFO - 2023-12-07 14:57:54 --> Controller Class Initialized
INFO - 2023-12-07 14:57:54 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:57:54 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:57:54 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:57:54 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:57:54 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:57:54 --> Model "M_bank" initialized
INFO - 2023-12-07 14:57:54 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:57:54 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 14:57:55 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 14:57:55 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 14:57:55 --> Final output sent to browser
DEBUG - 2023-12-07 14:57:55 --> Total execution time: 0.7597
ERROR - 2023-12-07 14:59:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:59:30 --> Config Class Initialized
INFO - 2023-12-07 14:59:30 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:59:30 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:59:30 --> Utf8 Class Initialized
INFO - 2023-12-07 14:59:30 --> URI Class Initialized
INFO - 2023-12-07 14:59:30 --> Router Class Initialized
INFO - 2023-12-07 14:59:30 --> Output Class Initialized
INFO - 2023-12-07 14:59:30 --> Security Class Initialized
DEBUG - 2023-12-07 14:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:59:30 --> Input Class Initialized
INFO - 2023-12-07 14:59:30 --> Language Class Initialized
INFO - 2023-12-07 14:59:30 --> Loader Class Initialized
INFO - 2023-12-07 14:59:30 --> Helper loaded: url_helper
INFO - 2023-12-07 14:59:30 --> Helper loaded: form_helper
INFO - 2023-12-07 14:59:30 --> Helper loaded: file_helper
INFO - 2023-12-07 14:59:30 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:59:30 --> Form Validation Class Initialized
INFO - 2023-12-07 14:59:30 --> Upload Class Initialized
INFO - 2023-12-07 14:59:30 --> Model "M_auth" initialized
INFO - 2023-12-07 14:59:30 --> Model "M_user" initialized
INFO - 2023-12-07 14:59:30 --> Model "M_produk" initialized
INFO - 2023-12-07 14:59:30 --> Controller Class Initialized
INFO - 2023-12-07 14:59:30 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:59:30 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:59:30 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:59:30 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:59:30 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:59:30 --> Model "M_bank" initialized
INFO - 2023-12-07 14:59:30 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:59:30 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 14:59:31 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 14:59:31 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 14:59:31 --> Final output sent to browser
DEBUG - 2023-12-07 14:59:31 --> Total execution time: 0.4842
ERROR - 2023-12-07 14:59:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 14:59:36 --> Config Class Initialized
INFO - 2023-12-07 14:59:37 --> Hooks Class Initialized
DEBUG - 2023-12-07 14:59:37 --> UTF-8 Support Enabled
INFO - 2023-12-07 14:59:37 --> Utf8 Class Initialized
INFO - 2023-12-07 14:59:37 --> URI Class Initialized
INFO - 2023-12-07 14:59:37 --> Router Class Initialized
INFO - 2023-12-07 14:59:37 --> Output Class Initialized
INFO - 2023-12-07 14:59:37 --> Security Class Initialized
DEBUG - 2023-12-07 14:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 14:59:37 --> Input Class Initialized
INFO - 2023-12-07 14:59:37 --> Language Class Initialized
INFO - 2023-12-07 14:59:37 --> Loader Class Initialized
INFO - 2023-12-07 14:59:37 --> Helper loaded: url_helper
INFO - 2023-12-07 14:59:37 --> Helper loaded: form_helper
INFO - 2023-12-07 14:59:37 --> Helper loaded: file_helper
INFO - 2023-12-07 14:59:37 --> Database Driver Class Initialized
DEBUG - 2023-12-07 14:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 14:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 14:59:37 --> Form Validation Class Initialized
INFO - 2023-12-07 14:59:37 --> Upload Class Initialized
INFO - 2023-12-07 14:59:37 --> Model "M_auth" initialized
INFO - 2023-12-07 14:59:37 --> Model "M_user" initialized
INFO - 2023-12-07 14:59:37 --> Model "M_produk" initialized
INFO - 2023-12-07 14:59:37 --> Controller Class Initialized
INFO - 2023-12-07 14:59:37 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 14:59:37 --> Model "M_produk" initialized
DEBUG - 2023-12-07 14:59:37 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 14:59:37 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 14:59:37 --> Model "M_transaksi" initialized
INFO - 2023-12-07 14:59:37 --> Model "M_bank" initialized
INFO - 2023-12-07 14:59:37 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 14:59:37 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 14:59:37 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 14:59:37 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 14:59:37 --> Final output sent to browser
DEBUG - 2023-12-07 14:59:37 --> Total execution time: 0.4758
ERROR - 2023-12-07 15:00:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:00:20 --> Config Class Initialized
INFO - 2023-12-07 15:00:20 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:00:20 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:00:20 --> Utf8 Class Initialized
INFO - 2023-12-07 15:00:20 --> URI Class Initialized
INFO - 2023-12-07 15:00:20 --> Router Class Initialized
INFO - 2023-12-07 15:00:20 --> Output Class Initialized
INFO - 2023-12-07 15:00:20 --> Security Class Initialized
DEBUG - 2023-12-07 15:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:00:20 --> Input Class Initialized
INFO - 2023-12-07 15:00:20 --> Language Class Initialized
INFO - 2023-12-07 15:00:20 --> Loader Class Initialized
INFO - 2023-12-07 15:00:20 --> Helper loaded: url_helper
INFO - 2023-12-07 15:00:20 --> Helper loaded: form_helper
INFO - 2023-12-07 15:00:20 --> Helper loaded: file_helper
INFO - 2023-12-07 15:00:20 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:00:20 --> Form Validation Class Initialized
INFO - 2023-12-07 15:00:20 --> Upload Class Initialized
INFO - 2023-12-07 15:00:20 --> Model "M_auth" initialized
INFO - 2023-12-07 15:00:20 --> Model "M_user" initialized
INFO - 2023-12-07 15:00:20 --> Model "M_produk" initialized
INFO - 2023-12-07 15:00:20 --> Controller Class Initialized
INFO - 2023-12-07 15:00:20 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:00:20 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:00:20 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:00:20 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:00:20 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:00:20 --> Model "M_bank" initialized
INFO - 2023-12-07 15:00:20 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:00:20 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:00:21 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:00:21 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:00:21 --> Final output sent to browser
DEBUG - 2023-12-07 15:00:21 --> Total execution time: 0.5791
ERROR - 2023-12-07 15:00:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:00:23 --> Config Class Initialized
INFO - 2023-12-07 15:00:23 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:00:23 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:00:23 --> Utf8 Class Initialized
INFO - 2023-12-07 15:00:23 --> URI Class Initialized
INFO - 2023-12-07 15:00:23 --> Router Class Initialized
INFO - 2023-12-07 15:00:23 --> Output Class Initialized
INFO - 2023-12-07 15:00:23 --> Security Class Initialized
DEBUG - 2023-12-07 15:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:00:23 --> Input Class Initialized
INFO - 2023-12-07 15:00:23 --> Language Class Initialized
INFO - 2023-12-07 15:00:23 --> Loader Class Initialized
INFO - 2023-12-07 15:00:23 --> Helper loaded: url_helper
INFO - 2023-12-07 15:00:23 --> Helper loaded: form_helper
INFO - 2023-12-07 15:00:23 --> Helper loaded: file_helper
INFO - 2023-12-07 15:00:23 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:00:23 --> Form Validation Class Initialized
INFO - 2023-12-07 15:00:23 --> Upload Class Initialized
INFO - 2023-12-07 15:00:23 --> Model "M_auth" initialized
INFO - 2023-12-07 15:00:23 --> Model "M_user" initialized
INFO - 2023-12-07 15:00:23 --> Model "M_produk" initialized
INFO - 2023-12-07 15:00:23 --> Controller Class Initialized
INFO - 2023-12-07 15:00:23 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:00:23 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:00:23 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:00:23 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:00:23 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:00:23 --> Model "M_bank" initialized
INFO - 2023-12-07 15:00:23 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:00:23 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:00:23 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:00:23 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:00:23 --> Final output sent to browser
DEBUG - 2023-12-07 15:00:23 --> Total execution time: 0.5920
ERROR - 2023-12-07 15:01:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:01:37 --> Config Class Initialized
INFO - 2023-12-07 15:01:37 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:01:37 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:01:37 --> Utf8 Class Initialized
INFO - 2023-12-07 15:01:37 --> URI Class Initialized
INFO - 2023-12-07 15:01:37 --> Router Class Initialized
INFO - 2023-12-07 15:01:37 --> Output Class Initialized
INFO - 2023-12-07 15:01:37 --> Security Class Initialized
DEBUG - 2023-12-07 15:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:01:37 --> Input Class Initialized
INFO - 2023-12-07 15:01:37 --> Language Class Initialized
INFO - 2023-12-07 15:01:37 --> Loader Class Initialized
INFO - 2023-12-07 15:01:37 --> Helper loaded: url_helper
INFO - 2023-12-07 15:01:37 --> Helper loaded: form_helper
INFO - 2023-12-07 15:01:37 --> Helper loaded: file_helper
INFO - 2023-12-07 15:01:37 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:01:37 --> Form Validation Class Initialized
INFO - 2023-12-07 15:01:37 --> Upload Class Initialized
INFO - 2023-12-07 15:01:37 --> Model "M_auth" initialized
INFO - 2023-12-07 15:01:37 --> Model "M_user" initialized
INFO - 2023-12-07 15:01:37 --> Model "M_produk" initialized
INFO - 2023-12-07 15:01:37 --> Controller Class Initialized
INFO - 2023-12-07 15:01:37 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:01:37 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:01:37 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:01:37 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:01:37 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:01:37 --> Model "M_bank" initialized
INFO - 2023-12-07 15:01:37 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:01:37 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:01:38 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:01:38 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:01:38 --> Final output sent to browser
DEBUG - 2023-12-07 15:01:38 --> Total execution time: 0.4162
ERROR - 2023-12-07 15:01:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:01:41 --> Config Class Initialized
INFO - 2023-12-07 15:01:41 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:01:41 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:01:41 --> Utf8 Class Initialized
INFO - 2023-12-07 15:01:41 --> URI Class Initialized
INFO - 2023-12-07 15:01:41 --> Router Class Initialized
INFO - 2023-12-07 15:01:41 --> Output Class Initialized
INFO - 2023-12-07 15:01:41 --> Security Class Initialized
DEBUG - 2023-12-07 15:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:01:41 --> Input Class Initialized
INFO - 2023-12-07 15:01:41 --> Language Class Initialized
INFO - 2023-12-07 15:01:41 --> Loader Class Initialized
INFO - 2023-12-07 15:01:41 --> Helper loaded: url_helper
INFO - 2023-12-07 15:01:41 --> Helper loaded: form_helper
INFO - 2023-12-07 15:01:41 --> Helper loaded: file_helper
INFO - 2023-12-07 15:01:41 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:01:41 --> Form Validation Class Initialized
INFO - 2023-12-07 15:01:41 --> Upload Class Initialized
INFO - 2023-12-07 15:01:41 --> Model "M_auth" initialized
INFO - 2023-12-07 15:01:41 --> Model "M_user" initialized
INFO - 2023-12-07 15:01:41 --> Model "M_produk" initialized
INFO - 2023-12-07 15:01:41 --> Controller Class Initialized
INFO - 2023-12-07 15:01:41 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:01:41 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:01:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:01:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:01:41 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:01:41 --> Model "M_bank" initialized
INFO - 2023-12-07 15:01:41 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:01:41 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:01:41 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:01:41 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:01:41 --> Final output sent to browser
DEBUG - 2023-12-07 15:01:41 --> Total execution time: 0.5073
ERROR - 2023-12-07 15:03:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:03:15 --> Config Class Initialized
INFO - 2023-12-07 15:03:15 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:03:15 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:03:15 --> Utf8 Class Initialized
INFO - 2023-12-07 15:03:15 --> URI Class Initialized
INFO - 2023-12-07 15:03:15 --> Router Class Initialized
INFO - 2023-12-07 15:03:15 --> Output Class Initialized
INFO - 2023-12-07 15:03:15 --> Security Class Initialized
DEBUG - 2023-12-07 15:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:03:15 --> Input Class Initialized
INFO - 2023-12-07 15:03:15 --> Language Class Initialized
INFO - 2023-12-07 15:03:15 --> Loader Class Initialized
INFO - 2023-12-07 15:03:15 --> Helper loaded: url_helper
INFO - 2023-12-07 15:03:15 --> Helper loaded: form_helper
INFO - 2023-12-07 15:03:15 --> Helper loaded: file_helper
INFO - 2023-12-07 15:03:15 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:03:15 --> Form Validation Class Initialized
INFO - 2023-12-07 15:03:15 --> Upload Class Initialized
INFO - 2023-12-07 15:03:15 --> Model "M_auth" initialized
INFO - 2023-12-07 15:03:15 --> Model "M_user" initialized
INFO - 2023-12-07 15:03:15 --> Model "M_produk" initialized
INFO - 2023-12-07 15:03:15 --> Controller Class Initialized
INFO - 2023-12-07 15:03:15 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:03:15 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:03:15 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:03:15 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:03:15 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:03:15 --> Model "M_bank" initialized
INFO - 2023-12-07 15:03:15 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:03:15 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
ERROR - 2023-12-07 15:03:15 --> Severity: Warning --> Undefined variable $transaksi_item C:\xampp\htdocs\semakar_adventure_new\application\views\front\v_booking_saya.php 268
ERROR - 2023-12-07 15:03:15 --> Severity: Warning --> Attempt to read property "id_transaksi" on null C:\xampp\htdocs\semakar_adventure_new\application\views\front\v_booking_saya.php 268
ERROR - 2023-12-07 15:03:15 --> Severity: Warning --> Undefined variable $transaksi_item C:\xampp\htdocs\semakar_adventure_new\application\views\front\v_booking_saya.php 268
ERROR - 2023-12-07 15:03:15 --> Severity: Warning --> Attempt to read property "id_transaksi" on null C:\xampp\htdocs\semakar_adventure_new\application\views\front\v_booking_saya.php 268
INFO - 2023-12-07 15:03:15 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:03:15 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:03:15 --> Final output sent to browser
DEBUG - 2023-12-07 15:03:15 --> Total execution time: 0.4888
ERROR - 2023-12-07 15:03:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:03:37 --> Config Class Initialized
INFO - 2023-12-07 15:03:37 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:03:37 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:03:37 --> Utf8 Class Initialized
INFO - 2023-12-07 15:03:37 --> URI Class Initialized
INFO - 2023-12-07 15:03:37 --> Router Class Initialized
INFO - 2023-12-07 15:03:37 --> Output Class Initialized
INFO - 2023-12-07 15:03:37 --> Security Class Initialized
DEBUG - 2023-12-07 15:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:03:37 --> Input Class Initialized
INFO - 2023-12-07 15:03:37 --> Language Class Initialized
INFO - 2023-12-07 15:03:37 --> Loader Class Initialized
INFO - 2023-12-07 15:03:37 --> Helper loaded: url_helper
INFO - 2023-12-07 15:03:37 --> Helper loaded: form_helper
INFO - 2023-12-07 15:03:37 --> Helper loaded: file_helper
INFO - 2023-12-07 15:03:37 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:03:37 --> Form Validation Class Initialized
INFO - 2023-12-07 15:03:37 --> Upload Class Initialized
INFO - 2023-12-07 15:03:37 --> Model "M_auth" initialized
INFO - 2023-12-07 15:03:37 --> Model "M_user" initialized
INFO - 2023-12-07 15:03:37 --> Model "M_produk" initialized
INFO - 2023-12-07 15:03:37 --> Controller Class Initialized
INFO - 2023-12-07 15:03:37 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:03:37 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:03:37 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:03:37 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:03:37 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:03:37 --> Model "M_bank" initialized
INFO - 2023-12-07 15:03:37 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:03:37 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
ERROR - 2023-12-07 15:03:37 --> Severity: error --> Exception: Undefined constant "id_transaksi" C:\xampp\htdocs\semakar_adventure_new\application\views\front\v_booking_saya.php 268
ERROR - 2023-12-07 15:03:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:03:41 --> Config Class Initialized
INFO - 2023-12-07 15:03:41 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:03:41 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:03:41 --> Utf8 Class Initialized
INFO - 2023-12-07 15:03:41 --> URI Class Initialized
INFO - 2023-12-07 15:03:41 --> Router Class Initialized
INFO - 2023-12-07 15:03:41 --> Output Class Initialized
INFO - 2023-12-07 15:03:41 --> Security Class Initialized
DEBUG - 2023-12-07 15:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:03:41 --> Input Class Initialized
INFO - 2023-12-07 15:03:41 --> Language Class Initialized
INFO - 2023-12-07 15:03:41 --> Loader Class Initialized
INFO - 2023-12-07 15:03:41 --> Helper loaded: url_helper
INFO - 2023-12-07 15:03:41 --> Helper loaded: form_helper
INFO - 2023-12-07 15:03:41 --> Helper loaded: file_helper
INFO - 2023-12-07 15:03:41 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:03:41 --> Form Validation Class Initialized
INFO - 2023-12-07 15:03:41 --> Upload Class Initialized
INFO - 2023-12-07 15:03:41 --> Model "M_auth" initialized
INFO - 2023-12-07 15:03:41 --> Model "M_user" initialized
INFO - 2023-12-07 15:03:41 --> Model "M_produk" initialized
INFO - 2023-12-07 15:03:41 --> Controller Class Initialized
INFO - 2023-12-07 15:03:41 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:03:41 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:03:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:03:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:03:41 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:03:41 --> Model "M_bank" initialized
INFO - 2023-12-07 15:03:41 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:03:41 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
ERROR - 2023-12-07 15:03:42 --> Severity: error --> Exception: Undefined constant "id_transaksi" C:\xampp\htdocs\semakar_adventure_new\application\views\front\v_booking_saya.php 268
ERROR - 2023-12-07 15:03:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:03:43 --> Config Class Initialized
INFO - 2023-12-07 15:03:43 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:03:43 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:03:43 --> Utf8 Class Initialized
INFO - 2023-12-07 15:03:43 --> URI Class Initialized
INFO - 2023-12-07 15:03:43 --> Router Class Initialized
INFO - 2023-12-07 15:03:43 --> Output Class Initialized
INFO - 2023-12-07 15:03:43 --> Security Class Initialized
DEBUG - 2023-12-07 15:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:03:43 --> Input Class Initialized
INFO - 2023-12-07 15:03:43 --> Language Class Initialized
INFO - 2023-12-07 15:03:43 --> Loader Class Initialized
INFO - 2023-12-07 15:03:43 --> Helper loaded: url_helper
INFO - 2023-12-07 15:03:43 --> Helper loaded: form_helper
INFO - 2023-12-07 15:03:43 --> Helper loaded: file_helper
INFO - 2023-12-07 15:03:43 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:03:43 --> Form Validation Class Initialized
INFO - 2023-12-07 15:03:43 --> Upload Class Initialized
INFO - 2023-12-07 15:03:43 --> Model "M_auth" initialized
INFO - 2023-12-07 15:03:43 --> Model "M_user" initialized
INFO - 2023-12-07 15:03:43 --> Model "M_produk" initialized
INFO - 2023-12-07 15:03:43 --> Controller Class Initialized
INFO - 2023-12-07 15:03:43 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:03:43 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:03:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:03:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:03:43 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:03:43 --> Model "M_bank" initialized
INFO - 2023-12-07 15:03:43 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:03:43 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
ERROR - 2023-12-07 15:03:43 --> Severity: error --> Exception: Undefined constant "id_transaksi" C:\xampp\htdocs\semakar_adventure_new\application\views\front\v_booking_saya.php 268
ERROR - 2023-12-07 15:03:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:03:50 --> Config Class Initialized
INFO - 2023-12-07 15:03:50 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:03:50 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:03:50 --> Utf8 Class Initialized
INFO - 2023-12-07 15:03:50 --> URI Class Initialized
INFO - 2023-12-07 15:03:50 --> Router Class Initialized
INFO - 2023-12-07 15:03:50 --> Output Class Initialized
INFO - 2023-12-07 15:03:50 --> Security Class Initialized
DEBUG - 2023-12-07 15:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:03:50 --> Input Class Initialized
INFO - 2023-12-07 15:03:50 --> Language Class Initialized
INFO - 2023-12-07 15:03:50 --> Loader Class Initialized
INFO - 2023-12-07 15:03:50 --> Helper loaded: url_helper
INFO - 2023-12-07 15:03:50 --> Helper loaded: form_helper
INFO - 2023-12-07 15:03:50 --> Helper loaded: file_helper
INFO - 2023-12-07 15:03:50 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:03:50 --> Form Validation Class Initialized
INFO - 2023-12-07 15:03:50 --> Upload Class Initialized
INFO - 2023-12-07 15:03:50 --> Model "M_auth" initialized
INFO - 2023-12-07 15:03:50 --> Model "M_user" initialized
INFO - 2023-12-07 15:03:50 --> Model "M_produk" initialized
INFO - 2023-12-07 15:03:50 --> Controller Class Initialized
INFO - 2023-12-07 15:03:50 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:03:50 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:03:50 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:03:50 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:03:50 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:03:50 --> Model "M_bank" initialized
INFO - 2023-12-07 15:03:50 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:03:50 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
ERROR - 2023-12-07 15:03:51 --> Severity: error --> Exception: Undefined constant "id_transaksi" C:\xampp\htdocs\semakar_adventure_new\application\views\front\v_booking_saya.php 268
ERROR - 2023-12-07 15:03:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:03:56 --> Config Class Initialized
INFO - 2023-12-07 15:03:56 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:03:56 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:03:56 --> Utf8 Class Initialized
INFO - 2023-12-07 15:03:56 --> URI Class Initialized
INFO - 2023-12-07 15:03:56 --> Router Class Initialized
INFO - 2023-12-07 15:03:56 --> Output Class Initialized
INFO - 2023-12-07 15:03:56 --> Security Class Initialized
DEBUG - 2023-12-07 15:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:03:56 --> Input Class Initialized
INFO - 2023-12-07 15:03:56 --> Language Class Initialized
INFO - 2023-12-07 15:03:56 --> Loader Class Initialized
INFO - 2023-12-07 15:03:56 --> Helper loaded: url_helper
INFO - 2023-12-07 15:03:56 --> Helper loaded: form_helper
INFO - 2023-12-07 15:03:56 --> Helper loaded: file_helper
INFO - 2023-12-07 15:03:56 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:03:56 --> Form Validation Class Initialized
INFO - 2023-12-07 15:03:56 --> Upload Class Initialized
INFO - 2023-12-07 15:03:56 --> Model "M_auth" initialized
INFO - 2023-12-07 15:03:56 --> Model "M_user" initialized
INFO - 2023-12-07 15:03:56 --> Model "M_produk" initialized
INFO - 2023-12-07 15:03:56 --> Controller Class Initialized
INFO - 2023-12-07 15:03:56 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:03:56 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:03:56 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:03:56 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:03:56 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:03:56 --> Model "M_bank" initialized
INFO - 2023-12-07 15:03:56 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:03:56 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:03:56 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:03:56 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:03:56 --> Final output sent to browser
DEBUG - 2023-12-07 15:03:56 --> Total execution time: 0.4708
ERROR - 2023-12-07 15:04:00 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:04:00 --> Config Class Initialized
INFO - 2023-12-07 15:04:00 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:04:00 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:04:00 --> Utf8 Class Initialized
INFO - 2023-12-07 15:04:00 --> URI Class Initialized
INFO - 2023-12-07 15:04:00 --> Router Class Initialized
INFO - 2023-12-07 15:04:00 --> Output Class Initialized
INFO - 2023-12-07 15:04:00 --> Security Class Initialized
DEBUG - 2023-12-07 15:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:04:00 --> Input Class Initialized
INFO - 2023-12-07 15:04:00 --> Language Class Initialized
INFO - 2023-12-07 15:04:00 --> Loader Class Initialized
INFO - 2023-12-07 15:04:00 --> Helper loaded: url_helper
INFO - 2023-12-07 15:04:00 --> Helper loaded: form_helper
INFO - 2023-12-07 15:04:00 --> Helper loaded: file_helper
INFO - 2023-12-07 15:04:00 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:04:00 --> Form Validation Class Initialized
INFO - 2023-12-07 15:04:00 --> Upload Class Initialized
INFO - 2023-12-07 15:04:00 --> Model "M_auth" initialized
INFO - 2023-12-07 15:04:00 --> Model "M_user" initialized
INFO - 2023-12-07 15:04:00 --> Model "M_produk" initialized
INFO - 2023-12-07 15:04:00 --> Controller Class Initialized
INFO - 2023-12-07 15:04:00 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:04:00 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:04:00 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:04:00 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:04:00 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:04:00 --> Model "M_bank" initialized
INFO - 2023-12-07 15:04:00 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:04:00 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:04:01 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:04:01 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:04:01 --> Final output sent to browser
DEBUG - 2023-12-07 15:04:01 --> Total execution time: 0.4388
ERROR - 2023-12-07 15:04:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:04:30 --> Config Class Initialized
INFO - 2023-12-07 15:04:30 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:04:30 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:04:30 --> Utf8 Class Initialized
INFO - 2023-12-07 15:04:30 --> URI Class Initialized
DEBUG - 2023-12-07 15:04:30 --> No URI present. Default controller set.
INFO - 2023-12-07 15:04:30 --> Router Class Initialized
INFO - 2023-12-07 15:04:30 --> Output Class Initialized
INFO - 2023-12-07 15:04:30 --> Security Class Initialized
DEBUG - 2023-12-07 15:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:04:30 --> Input Class Initialized
INFO - 2023-12-07 15:04:30 --> Language Class Initialized
INFO - 2023-12-07 15:04:30 --> Loader Class Initialized
INFO - 2023-12-07 15:04:30 --> Helper loaded: url_helper
INFO - 2023-12-07 15:04:30 --> Helper loaded: form_helper
INFO - 2023-12-07 15:04:30 --> Helper loaded: file_helper
INFO - 2023-12-07 15:04:30 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:04:30 --> Form Validation Class Initialized
INFO - 2023-12-07 15:04:30 --> Upload Class Initialized
INFO - 2023-12-07 15:04:30 --> Model "M_auth" initialized
INFO - 2023-12-07 15:04:30 --> Model "M_user" initialized
INFO - 2023-12-07 15:04:30 --> Model "M_produk" initialized
INFO - 2023-12-07 15:04:30 --> Controller Class Initialized
INFO - 2023-12-07 15:04:30 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:04:30 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:04:30 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:04:30 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:04:30 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:04:30 --> Model "M_bank" initialized
INFO - 2023-12-07 15:04:30 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:04:30 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:04:30 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:04:30 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/index.php
INFO - 2023-12-07 15:04:30 --> Final output sent to browser
DEBUG - 2023-12-07 15:04:30 --> Total execution time: 0.1004
ERROR - 2023-12-07 15:04:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:04:33 --> Config Class Initialized
INFO - 2023-12-07 15:04:33 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:04:33 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:04:33 --> Utf8 Class Initialized
INFO - 2023-12-07 15:04:33 --> URI Class Initialized
INFO - 2023-12-07 15:04:33 --> Router Class Initialized
INFO - 2023-12-07 15:04:33 --> Output Class Initialized
INFO - 2023-12-07 15:04:33 --> Security Class Initialized
DEBUG - 2023-12-07 15:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:04:33 --> Input Class Initialized
INFO - 2023-12-07 15:04:33 --> Language Class Initialized
INFO - 2023-12-07 15:04:33 --> Loader Class Initialized
INFO - 2023-12-07 15:04:33 --> Helper loaded: url_helper
INFO - 2023-12-07 15:04:33 --> Helper loaded: form_helper
INFO - 2023-12-07 15:04:33 --> Helper loaded: file_helper
INFO - 2023-12-07 15:04:33 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:04:33 --> Form Validation Class Initialized
INFO - 2023-12-07 15:04:33 --> Upload Class Initialized
INFO - 2023-12-07 15:04:33 --> Model "M_auth" initialized
INFO - 2023-12-07 15:04:33 --> Model "M_user" initialized
INFO - 2023-12-07 15:04:33 --> Model "M_produk" initialized
INFO - 2023-12-07 15:04:33 --> Controller Class Initialized
INFO - 2023-12-07 15:04:33 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:04:33 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:04:33 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:04:33 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:04:33 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:04:33 --> Model "M_bank" initialized
INFO - 2023-12-07 15:04:33 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:04:33 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:04:33 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:04:33 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_produk_detail.php
INFO - 2023-12-07 15:04:33 --> Final output sent to browser
DEBUG - 2023-12-07 15:04:33 --> Total execution time: 0.2148
ERROR - 2023-12-07 15:04:33 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:04:33 --> Config Class Initialized
INFO - 2023-12-07 15:04:33 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:04:33 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:04:33 --> Utf8 Class Initialized
INFO - 2023-12-07 15:04:33 --> URI Class Initialized
INFO - 2023-12-07 15:04:33 --> Router Class Initialized
INFO - 2023-12-07 15:04:33 --> Output Class Initialized
INFO - 2023-12-07 15:04:33 --> Security Class Initialized
DEBUG - 2023-12-07 15:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:04:33 --> Input Class Initialized
INFO - 2023-12-07 15:04:33 --> Language Class Initialized
INFO - 2023-12-07 15:04:33 --> Loader Class Initialized
INFO - 2023-12-07 15:04:33 --> Helper loaded: url_helper
INFO - 2023-12-07 15:04:33 --> Helper loaded: form_helper
INFO - 2023-12-07 15:04:33 --> Helper loaded: file_helper
INFO - 2023-12-07 15:04:33 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:04:33 --> Form Validation Class Initialized
INFO - 2023-12-07 15:04:33 --> Upload Class Initialized
INFO - 2023-12-07 15:04:33 --> Model "M_auth" initialized
INFO - 2023-12-07 15:04:33 --> Model "M_user" initialized
INFO - 2023-12-07 15:04:33 --> Model "M_produk" initialized
INFO - 2023-12-07 15:04:33 --> Controller Class Initialized
INFO - 2023-12-07 15:04:33 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:04:33 --> Final output sent to browser
DEBUG - 2023-12-07 15:04:33 --> Total execution time: 0.0223
ERROR - 2023-12-07 15:08:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:08:50 --> Config Class Initialized
INFO - 2023-12-07 15:08:50 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:08:50 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:08:50 --> Utf8 Class Initialized
INFO - 2023-12-07 15:08:50 --> URI Class Initialized
INFO - 2023-12-07 15:08:50 --> Router Class Initialized
INFO - 2023-12-07 15:08:50 --> Output Class Initialized
INFO - 2023-12-07 15:08:50 --> Security Class Initialized
DEBUG - 2023-12-07 15:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:08:50 --> Input Class Initialized
INFO - 2023-12-07 15:08:50 --> Language Class Initialized
INFO - 2023-12-07 15:08:50 --> Loader Class Initialized
INFO - 2023-12-07 15:08:50 --> Helper loaded: url_helper
INFO - 2023-12-07 15:08:50 --> Helper loaded: form_helper
INFO - 2023-12-07 15:08:50 --> Helper loaded: file_helper
INFO - 2023-12-07 15:08:50 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:08:50 --> Form Validation Class Initialized
INFO - 2023-12-07 15:08:50 --> Upload Class Initialized
INFO - 2023-12-07 15:08:50 --> Model "M_auth" initialized
INFO - 2023-12-07 15:08:50 --> Model "M_user" initialized
INFO - 2023-12-07 15:08:50 --> Model "M_produk" initialized
INFO - 2023-12-07 15:08:50 --> Controller Class Initialized
INFO - 2023-12-07 15:08:50 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:08:50 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:08:50 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:08:50 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:08:50 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:08:50 --> Model "M_bank" initialized
INFO - 2023-12-07 15:08:50 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:08:50 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:08:50 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:08:50 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_produk_detail.php
INFO - 2023-12-07 15:08:50 --> Final output sent to browser
DEBUG - 2023-12-07 15:08:50 --> Total execution time: 0.0959
ERROR - 2023-12-07 15:08:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:08:50 --> Config Class Initialized
INFO - 2023-12-07 15:08:50 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:08:50 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:08:50 --> Utf8 Class Initialized
INFO - 2023-12-07 15:08:50 --> URI Class Initialized
INFO - 2023-12-07 15:08:50 --> Router Class Initialized
INFO - 2023-12-07 15:08:50 --> Output Class Initialized
INFO - 2023-12-07 15:08:50 --> Security Class Initialized
DEBUG - 2023-12-07 15:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:08:50 --> Input Class Initialized
INFO - 2023-12-07 15:08:50 --> Language Class Initialized
INFO - 2023-12-07 15:08:50 --> Loader Class Initialized
INFO - 2023-12-07 15:08:50 --> Helper loaded: url_helper
INFO - 2023-12-07 15:08:50 --> Helper loaded: form_helper
INFO - 2023-12-07 15:08:50 --> Helper loaded: file_helper
INFO - 2023-12-07 15:08:50 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:08:50 --> Form Validation Class Initialized
INFO - 2023-12-07 15:08:50 --> Upload Class Initialized
INFO - 2023-12-07 15:08:50 --> Model "M_auth" initialized
INFO - 2023-12-07 15:08:50 --> Model "M_user" initialized
INFO - 2023-12-07 15:08:50 --> Model "M_produk" initialized
INFO - 2023-12-07 15:08:50 --> Controller Class Initialized
INFO - 2023-12-07 15:08:50 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:08:50 --> Final output sent to browser
DEBUG - 2023-12-07 15:08:50 --> Total execution time: 0.0367
ERROR - 2023-12-07 15:08:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:08:54 --> Config Class Initialized
INFO - 2023-12-07 15:08:54 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:08:54 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:08:54 --> Utf8 Class Initialized
INFO - 2023-12-07 15:08:54 --> URI Class Initialized
INFO - 2023-12-07 15:08:54 --> Router Class Initialized
INFO - 2023-12-07 15:08:54 --> Output Class Initialized
INFO - 2023-12-07 15:08:54 --> Security Class Initialized
DEBUG - 2023-12-07 15:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:08:54 --> Input Class Initialized
INFO - 2023-12-07 15:08:54 --> Language Class Initialized
INFO - 2023-12-07 15:08:54 --> Loader Class Initialized
INFO - 2023-12-07 15:08:54 --> Helper loaded: url_helper
INFO - 2023-12-07 15:08:54 --> Helper loaded: form_helper
INFO - 2023-12-07 15:08:54 --> Helper loaded: file_helper
INFO - 2023-12-07 15:08:54 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:08:54 --> Form Validation Class Initialized
INFO - 2023-12-07 15:08:54 --> Upload Class Initialized
INFO - 2023-12-07 15:08:54 --> Model "M_auth" initialized
INFO - 2023-12-07 15:08:54 --> Model "M_user" initialized
INFO - 2023-12-07 15:08:54 --> Model "M_produk" initialized
INFO - 2023-12-07 15:08:54 --> Controller Class Initialized
INFO - 2023-12-07 15:08:54 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:08:54 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:08:54 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:08:54 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:08:54 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:08:54 --> Model "M_bank" initialized
INFO - 2023-12-07 15:08:54 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:08:54 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:08:54 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:08:54 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:08:54 --> Final output sent to browser
DEBUG - 2023-12-07 15:08:54 --> Total execution time: 0.4806
ERROR - 2023-12-07 15:09:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:09:22 --> Config Class Initialized
INFO - 2023-12-07 15:09:22 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:09:22 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:09:22 --> Utf8 Class Initialized
INFO - 2023-12-07 15:09:22 --> URI Class Initialized
INFO - 2023-12-07 15:09:22 --> Router Class Initialized
INFO - 2023-12-07 15:09:22 --> Output Class Initialized
INFO - 2023-12-07 15:09:22 --> Security Class Initialized
DEBUG - 2023-12-07 15:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:09:22 --> Input Class Initialized
INFO - 2023-12-07 15:09:22 --> Language Class Initialized
INFO - 2023-12-07 15:09:22 --> Loader Class Initialized
INFO - 2023-12-07 15:09:22 --> Helper loaded: url_helper
INFO - 2023-12-07 15:09:22 --> Helper loaded: form_helper
INFO - 2023-12-07 15:09:22 --> Helper loaded: file_helper
INFO - 2023-12-07 15:09:22 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:09:22 --> Form Validation Class Initialized
INFO - 2023-12-07 15:09:22 --> Upload Class Initialized
INFO - 2023-12-07 15:09:22 --> Model "M_auth" initialized
INFO - 2023-12-07 15:09:22 --> Model "M_user" initialized
INFO - 2023-12-07 15:09:22 --> Model "M_produk" initialized
INFO - 2023-12-07 15:09:22 --> Controller Class Initialized
INFO - 2023-12-07 15:09:22 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:09:22 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:09:22 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:09:22 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:09:22 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:09:22 --> Model "M_bank" initialized
INFO - 2023-12-07 15:09:22 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:09:22 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:09:23 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:09:23 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:09:23 --> Final output sent to browser
DEBUG - 2023-12-07 15:09:23 --> Total execution time: 0.4034
ERROR - 2023-12-07 15:09:27 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:09:27 --> Config Class Initialized
INFO - 2023-12-07 15:09:27 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:09:27 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:09:27 --> Utf8 Class Initialized
INFO - 2023-12-07 15:09:27 --> URI Class Initialized
INFO - 2023-12-07 15:09:27 --> Router Class Initialized
INFO - 2023-12-07 15:09:27 --> Output Class Initialized
INFO - 2023-12-07 15:09:27 --> Security Class Initialized
DEBUG - 2023-12-07 15:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:09:27 --> Input Class Initialized
INFO - 2023-12-07 15:09:27 --> Language Class Initialized
INFO - 2023-12-07 15:09:27 --> Loader Class Initialized
INFO - 2023-12-07 15:09:27 --> Helper loaded: url_helper
INFO - 2023-12-07 15:09:27 --> Helper loaded: form_helper
INFO - 2023-12-07 15:09:27 --> Helper loaded: file_helper
INFO - 2023-12-07 15:09:27 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:09:28 --> Form Validation Class Initialized
INFO - 2023-12-07 15:09:28 --> Upload Class Initialized
INFO - 2023-12-07 15:09:28 --> Model "M_auth" initialized
INFO - 2023-12-07 15:09:28 --> Model "M_user" initialized
INFO - 2023-12-07 15:09:28 --> Model "M_produk" initialized
INFO - 2023-12-07 15:09:28 --> Controller Class Initialized
INFO - 2023-12-07 15:09:28 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:09:28 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:09:28 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:09:28 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:09:28 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:09:28 --> Model "M_bank" initialized
INFO - 2023-12-07 15:09:28 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:09:28 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:09:29 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:09:29 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:09:29 --> Final output sent to browser
DEBUG - 2023-12-07 15:09:29 --> Total execution time: 1.7273
ERROR - 2023-12-07 15:09:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:09:36 --> Config Class Initialized
INFO - 2023-12-07 15:09:36 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:09:36 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:09:36 --> Utf8 Class Initialized
INFO - 2023-12-07 15:09:36 --> URI Class Initialized
INFO - 2023-12-07 15:09:36 --> Router Class Initialized
INFO - 2023-12-07 15:09:36 --> Output Class Initialized
INFO - 2023-12-07 15:09:36 --> Security Class Initialized
DEBUG - 2023-12-07 15:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:09:36 --> Input Class Initialized
INFO - 2023-12-07 15:09:36 --> Language Class Initialized
INFO - 2023-12-07 15:09:36 --> Loader Class Initialized
INFO - 2023-12-07 15:09:36 --> Helper loaded: url_helper
INFO - 2023-12-07 15:09:36 --> Helper loaded: form_helper
INFO - 2023-12-07 15:09:36 --> Helper loaded: file_helper
INFO - 2023-12-07 15:09:36 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:09:36 --> Form Validation Class Initialized
INFO - 2023-12-07 15:09:36 --> Upload Class Initialized
INFO - 2023-12-07 15:09:36 --> Model "M_auth" initialized
INFO - 2023-12-07 15:09:36 --> Model "M_user" initialized
INFO - 2023-12-07 15:09:36 --> Model "M_produk" initialized
INFO - 2023-12-07 15:09:36 --> Controller Class Initialized
INFO - 2023-12-07 15:09:36 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:09:36 --> Final output sent to browser
DEBUG - 2023-12-07 15:09:36 --> Total execution time: 0.0377
ERROR - 2023-12-07 15:09:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:09:46 --> Config Class Initialized
INFO - 2023-12-07 15:09:46 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:09:46 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:09:46 --> Utf8 Class Initialized
INFO - 2023-12-07 15:09:46 --> URI Class Initialized
INFO - 2023-12-07 15:09:46 --> Router Class Initialized
INFO - 2023-12-07 15:09:46 --> Output Class Initialized
INFO - 2023-12-07 15:09:46 --> Security Class Initialized
DEBUG - 2023-12-07 15:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:09:46 --> Input Class Initialized
INFO - 2023-12-07 15:09:46 --> Language Class Initialized
INFO - 2023-12-07 15:09:46 --> Loader Class Initialized
INFO - 2023-12-07 15:09:46 --> Helper loaded: url_helper
INFO - 2023-12-07 15:09:46 --> Helper loaded: form_helper
INFO - 2023-12-07 15:09:46 --> Helper loaded: file_helper
INFO - 2023-12-07 15:09:46 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:09:46 --> Form Validation Class Initialized
INFO - 2023-12-07 15:09:46 --> Upload Class Initialized
INFO - 2023-12-07 15:09:46 --> Model "M_auth" initialized
INFO - 2023-12-07 15:09:46 --> Model "M_user" initialized
INFO - 2023-12-07 15:09:46 --> Model "M_produk" initialized
INFO - 2023-12-07 15:09:46 --> Controller Class Initialized
INFO - 2023-12-07 15:09:46 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:09:46 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:09:46 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:09:46 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:09:46 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:09:46 --> Model "M_bank" initialized
INFO - 2023-12-07 15:09:46 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:09:46 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:09:47 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:09:47 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:09:47 --> Final output sent to browser
DEBUG - 2023-12-07 15:09:47 --> Total execution time: 0.5078
ERROR - 2023-12-07 15:09:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:09:47 --> Config Class Initialized
INFO - 2023-12-07 15:09:47 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:09:47 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:09:47 --> Utf8 Class Initialized
INFO - 2023-12-07 15:09:47 --> URI Class Initialized
INFO - 2023-12-07 15:09:47 --> Router Class Initialized
INFO - 2023-12-07 15:09:47 --> Output Class Initialized
INFO - 2023-12-07 15:09:47 --> Security Class Initialized
DEBUG - 2023-12-07 15:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:09:47 --> Input Class Initialized
INFO - 2023-12-07 15:09:47 --> Language Class Initialized
INFO - 2023-12-07 15:09:47 --> Loader Class Initialized
INFO - 2023-12-07 15:09:47 --> Helper loaded: url_helper
INFO - 2023-12-07 15:09:47 --> Helper loaded: form_helper
INFO - 2023-12-07 15:09:47 --> Helper loaded: file_helper
INFO - 2023-12-07 15:09:47 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:09:47 --> Form Validation Class Initialized
INFO - 2023-12-07 15:09:47 --> Upload Class Initialized
INFO - 2023-12-07 15:09:47 --> Model "M_auth" initialized
INFO - 2023-12-07 15:09:47 --> Model "M_user" initialized
INFO - 2023-12-07 15:09:47 --> Model "M_produk" initialized
INFO - 2023-12-07 15:09:47 --> Controller Class Initialized
INFO - 2023-12-07 15:09:47 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:09:47 --> Final output sent to browser
DEBUG - 2023-12-07 15:09:47 --> Total execution time: 0.0288
ERROR - 2023-12-07 15:12:15 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:12:15 --> Config Class Initialized
INFO - 2023-12-07 15:12:15 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:12:15 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:12:15 --> Utf8 Class Initialized
INFO - 2023-12-07 15:12:15 --> URI Class Initialized
INFO - 2023-12-07 15:12:15 --> Router Class Initialized
INFO - 2023-12-07 15:12:15 --> Output Class Initialized
INFO - 2023-12-07 15:12:15 --> Security Class Initialized
DEBUG - 2023-12-07 15:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:12:15 --> Input Class Initialized
INFO - 2023-12-07 15:12:15 --> Language Class Initialized
INFO - 2023-12-07 15:12:15 --> Loader Class Initialized
INFO - 2023-12-07 15:12:15 --> Helper loaded: url_helper
INFO - 2023-12-07 15:12:15 --> Helper loaded: form_helper
INFO - 2023-12-07 15:12:15 --> Helper loaded: file_helper
INFO - 2023-12-07 15:12:15 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:12:15 --> Form Validation Class Initialized
INFO - 2023-12-07 15:12:15 --> Upload Class Initialized
INFO - 2023-12-07 15:12:15 --> Model "M_auth" initialized
INFO - 2023-12-07 15:12:15 --> Model "M_user" initialized
INFO - 2023-12-07 15:12:15 --> Model "M_produk" initialized
INFO - 2023-12-07 15:12:15 --> Controller Class Initialized
INFO - 2023-12-07 15:12:15 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:12:15 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:12:15 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:12:15 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:12:15 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:12:15 --> Model "M_bank" initialized
INFO - 2023-12-07 15:12:15 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:12:15 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:12:16 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:12:16 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:12:16 --> Final output sent to browser
DEBUG - 2023-12-07 15:12:16 --> Total execution time: 0.4188
ERROR - 2023-12-07 15:12:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:12:17 --> Config Class Initialized
INFO - 2023-12-07 15:12:17 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:12:17 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:12:17 --> Utf8 Class Initialized
INFO - 2023-12-07 15:12:17 --> URI Class Initialized
INFO - 2023-12-07 15:12:17 --> Router Class Initialized
INFO - 2023-12-07 15:12:17 --> Output Class Initialized
INFO - 2023-12-07 15:12:17 --> Security Class Initialized
DEBUG - 2023-12-07 15:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:12:17 --> Input Class Initialized
INFO - 2023-12-07 15:12:17 --> Language Class Initialized
INFO - 2023-12-07 15:12:17 --> Loader Class Initialized
INFO - 2023-12-07 15:12:17 --> Helper loaded: url_helper
INFO - 2023-12-07 15:12:17 --> Helper loaded: form_helper
INFO - 2023-12-07 15:12:17 --> Helper loaded: file_helper
INFO - 2023-12-07 15:12:17 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:12:17 --> Form Validation Class Initialized
INFO - 2023-12-07 15:12:17 --> Upload Class Initialized
INFO - 2023-12-07 15:12:17 --> Model "M_auth" initialized
INFO - 2023-12-07 15:12:17 --> Model "M_user" initialized
INFO - 2023-12-07 15:12:17 --> Model "M_produk" initialized
INFO - 2023-12-07 15:12:17 --> Controller Class Initialized
INFO - 2023-12-07 15:12:17 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:12:17 --> Final output sent to browser
DEBUG - 2023-12-07 15:12:17 --> Total execution time: 0.0297
ERROR - 2023-12-07 15:12:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:12:22 --> Config Class Initialized
INFO - 2023-12-07 15:12:22 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:12:22 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:12:22 --> Utf8 Class Initialized
INFO - 2023-12-07 15:12:22 --> URI Class Initialized
INFO - 2023-12-07 15:12:22 --> Router Class Initialized
INFO - 2023-12-07 15:12:22 --> Output Class Initialized
INFO - 2023-12-07 15:12:22 --> Security Class Initialized
DEBUG - 2023-12-07 15:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:12:22 --> Input Class Initialized
INFO - 2023-12-07 15:12:22 --> Language Class Initialized
INFO - 2023-12-07 15:12:22 --> Loader Class Initialized
INFO - 2023-12-07 15:12:22 --> Helper loaded: url_helper
INFO - 2023-12-07 15:12:22 --> Helper loaded: form_helper
INFO - 2023-12-07 15:12:22 --> Helper loaded: file_helper
INFO - 2023-12-07 15:12:22 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:12:22 --> Form Validation Class Initialized
INFO - 2023-12-07 15:12:22 --> Upload Class Initialized
INFO - 2023-12-07 15:12:22 --> Model "M_auth" initialized
INFO - 2023-12-07 15:12:22 --> Model "M_user" initialized
INFO - 2023-12-07 15:12:22 --> Model "M_produk" initialized
INFO - 2023-12-07 15:12:22 --> Controller Class Initialized
INFO - 2023-12-07 15:12:22 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:12:22 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:12:22 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:12:22 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:12:22 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:12:22 --> Model "M_bank" initialized
INFO - 2023-12-07 15:12:22 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:12:22 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:12:23 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:12:23 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:12:23 --> Final output sent to browser
DEBUG - 2023-12-07 15:12:23 --> Total execution time: 0.4883
ERROR - 2023-12-07 15:12:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:12:23 --> Config Class Initialized
INFO - 2023-12-07 15:12:23 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:12:23 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:12:23 --> Utf8 Class Initialized
INFO - 2023-12-07 15:12:23 --> URI Class Initialized
INFO - 2023-12-07 15:12:23 --> Router Class Initialized
INFO - 2023-12-07 15:12:23 --> Output Class Initialized
INFO - 2023-12-07 15:12:23 --> Security Class Initialized
DEBUG - 2023-12-07 15:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:12:23 --> Input Class Initialized
INFO - 2023-12-07 15:12:23 --> Language Class Initialized
INFO - 2023-12-07 15:12:23 --> Loader Class Initialized
INFO - 2023-12-07 15:12:23 --> Helper loaded: url_helper
INFO - 2023-12-07 15:12:23 --> Helper loaded: form_helper
INFO - 2023-12-07 15:12:23 --> Helper loaded: file_helper
INFO - 2023-12-07 15:12:23 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:12:23 --> Form Validation Class Initialized
INFO - 2023-12-07 15:12:23 --> Upload Class Initialized
INFO - 2023-12-07 15:12:23 --> Model "M_auth" initialized
INFO - 2023-12-07 15:12:23 --> Model "M_user" initialized
INFO - 2023-12-07 15:12:23 --> Model "M_produk" initialized
INFO - 2023-12-07 15:12:23 --> Controller Class Initialized
INFO - 2023-12-07 15:12:23 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:12:23 --> Final output sent to browser
DEBUG - 2023-12-07 15:12:23 --> Total execution time: 0.0309
ERROR - 2023-12-07 15:12:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:12:37 --> Config Class Initialized
INFO - 2023-12-07 15:12:37 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:12:37 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:12:37 --> Utf8 Class Initialized
INFO - 2023-12-07 15:12:37 --> URI Class Initialized
INFO - 2023-12-07 15:12:37 --> Router Class Initialized
INFO - 2023-12-07 15:12:37 --> Output Class Initialized
INFO - 2023-12-07 15:12:37 --> Security Class Initialized
DEBUG - 2023-12-07 15:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:12:37 --> Input Class Initialized
INFO - 2023-12-07 15:12:37 --> Language Class Initialized
INFO - 2023-12-07 15:12:37 --> Loader Class Initialized
INFO - 2023-12-07 15:12:37 --> Helper loaded: url_helper
INFO - 2023-12-07 15:12:37 --> Helper loaded: form_helper
INFO - 2023-12-07 15:12:37 --> Helper loaded: file_helper
INFO - 2023-12-07 15:12:37 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:12:37 --> Form Validation Class Initialized
INFO - 2023-12-07 15:12:37 --> Upload Class Initialized
INFO - 2023-12-07 15:12:37 --> Model "M_auth" initialized
INFO - 2023-12-07 15:12:37 --> Model "M_user" initialized
INFO - 2023-12-07 15:12:37 --> Model "M_produk" initialized
INFO - 2023-12-07 15:12:37 --> Controller Class Initialized
INFO - 2023-12-07 15:12:37 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:12:37 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:12:37 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:12:37 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:12:37 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:12:37 --> Model "M_bank" initialized
INFO - 2023-12-07 15:12:37 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:12:37 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:12:38 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:12:38 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:12:38 --> Final output sent to browser
DEBUG - 2023-12-07 15:12:38 --> Total execution time: 0.4438
ERROR - 2023-12-07 15:12:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:12:38 --> Config Class Initialized
INFO - 2023-12-07 15:12:38 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:12:38 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:12:38 --> Utf8 Class Initialized
INFO - 2023-12-07 15:12:38 --> URI Class Initialized
INFO - 2023-12-07 15:12:38 --> Router Class Initialized
INFO - 2023-12-07 15:12:38 --> Output Class Initialized
INFO - 2023-12-07 15:12:38 --> Security Class Initialized
DEBUG - 2023-12-07 15:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:12:38 --> Input Class Initialized
INFO - 2023-12-07 15:12:38 --> Language Class Initialized
INFO - 2023-12-07 15:12:38 --> Loader Class Initialized
INFO - 2023-12-07 15:12:38 --> Helper loaded: url_helper
INFO - 2023-12-07 15:12:38 --> Helper loaded: form_helper
INFO - 2023-12-07 15:12:38 --> Helper loaded: file_helper
INFO - 2023-12-07 15:12:38 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:12:38 --> Form Validation Class Initialized
INFO - 2023-12-07 15:12:38 --> Upload Class Initialized
INFO - 2023-12-07 15:12:38 --> Model "M_auth" initialized
INFO - 2023-12-07 15:12:38 --> Model "M_user" initialized
INFO - 2023-12-07 15:12:38 --> Model "M_produk" initialized
INFO - 2023-12-07 15:12:38 --> Controller Class Initialized
INFO - 2023-12-07 15:12:38 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:12:38 --> Final output sent to browser
DEBUG - 2023-12-07 15:12:38 --> Total execution time: 0.0328
ERROR - 2023-12-07 15:13:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:13:36 --> Config Class Initialized
INFO - 2023-12-07 15:13:36 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:13:36 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:13:36 --> Utf8 Class Initialized
INFO - 2023-12-07 15:13:36 --> URI Class Initialized
INFO - 2023-12-07 15:13:36 --> Router Class Initialized
INFO - 2023-12-07 15:13:36 --> Output Class Initialized
INFO - 2023-12-07 15:13:36 --> Security Class Initialized
DEBUG - 2023-12-07 15:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:13:36 --> Input Class Initialized
INFO - 2023-12-07 15:13:36 --> Language Class Initialized
INFO - 2023-12-07 15:13:36 --> Loader Class Initialized
INFO - 2023-12-07 15:13:36 --> Helper loaded: url_helper
INFO - 2023-12-07 15:13:36 --> Helper loaded: form_helper
INFO - 2023-12-07 15:13:36 --> Helper loaded: file_helper
INFO - 2023-12-07 15:13:36 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:13:36 --> Form Validation Class Initialized
INFO - 2023-12-07 15:13:36 --> Upload Class Initialized
INFO - 2023-12-07 15:13:36 --> Model "M_auth" initialized
INFO - 2023-12-07 15:13:36 --> Model "M_user" initialized
INFO - 2023-12-07 15:13:36 --> Model "M_produk" initialized
INFO - 2023-12-07 15:13:36 --> Controller Class Initialized
INFO - 2023-12-07 15:13:36 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:13:36 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:13:36 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:13:36 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:13:36 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:13:36 --> Model "M_bank" initialized
INFO - 2023-12-07 15:13:36 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:13:36 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:13:37 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:13:37 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:13:37 --> Final output sent to browser
DEBUG - 2023-12-07 15:13:37 --> Total execution time: 0.4674
ERROR - 2023-12-07 15:13:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:13:37 --> Config Class Initialized
INFO - 2023-12-07 15:13:37 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:13:37 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:13:37 --> Utf8 Class Initialized
INFO - 2023-12-07 15:13:37 --> URI Class Initialized
INFO - 2023-12-07 15:13:37 --> Router Class Initialized
INFO - 2023-12-07 15:13:37 --> Output Class Initialized
INFO - 2023-12-07 15:13:37 --> Security Class Initialized
DEBUG - 2023-12-07 15:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:13:37 --> Input Class Initialized
INFO - 2023-12-07 15:13:37 --> Language Class Initialized
INFO - 2023-12-07 15:13:37 --> Loader Class Initialized
INFO - 2023-12-07 15:13:37 --> Helper loaded: url_helper
INFO - 2023-12-07 15:13:37 --> Helper loaded: form_helper
INFO - 2023-12-07 15:13:37 --> Helper loaded: file_helper
INFO - 2023-12-07 15:13:37 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:13:37 --> Form Validation Class Initialized
INFO - 2023-12-07 15:13:37 --> Upload Class Initialized
INFO - 2023-12-07 15:13:37 --> Model "M_auth" initialized
INFO - 2023-12-07 15:13:37 --> Model "M_user" initialized
INFO - 2023-12-07 15:13:37 --> Model "M_produk" initialized
INFO - 2023-12-07 15:13:37 --> Controller Class Initialized
INFO - 2023-12-07 15:13:37 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:13:37 --> Final output sent to browser
DEBUG - 2023-12-07 15:13:37 --> Total execution time: 0.0305
ERROR - 2023-12-07 15:13:45 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:13:45 --> Config Class Initialized
INFO - 2023-12-07 15:13:45 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:13:45 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:13:45 --> Utf8 Class Initialized
INFO - 2023-12-07 15:13:45 --> URI Class Initialized
INFO - 2023-12-07 15:13:45 --> Router Class Initialized
INFO - 2023-12-07 15:13:45 --> Output Class Initialized
INFO - 2023-12-07 15:13:45 --> Security Class Initialized
DEBUG - 2023-12-07 15:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:13:45 --> Input Class Initialized
INFO - 2023-12-07 15:13:45 --> Language Class Initialized
INFO - 2023-12-07 15:13:45 --> Loader Class Initialized
INFO - 2023-12-07 15:13:45 --> Helper loaded: url_helper
INFO - 2023-12-07 15:13:45 --> Helper loaded: form_helper
INFO - 2023-12-07 15:13:45 --> Helper loaded: file_helper
INFO - 2023-12-07 15:13:45 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:13:45 --> Form Validation Class Initialized
INFO - 2023-12-07 15:13:45 --> Upload Class Initialized
INFO - 2023-12-07 15:13:45 --> Model "M_auth" initialized
INFO - 2023-12-07 15:13:45 --> Model "M_user" initialized
INFO - 2023-12-07 15:13:45 --> Model "M_produk" initialized
INFO - 2023-12-07 15:13:45 --> Controller Class Initialized
INFO - 2023-12-07 15:13:45 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:13:45 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:13:45 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:13:45 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:13:45 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:13:45 --> Model "M_bank" initialized
INFO - 2023-12-07 15:13:45 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:13:45 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:13:46 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:13:46 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:13:46 --> Final output sent to browser
DEBUG - 2023-12-07 15:13:46 --> Total execution time: 0.3538
ERROR - 2023-12-07 15:13:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:13:46 --> Config Class Initialized
INFO - 2023-12-07 15:13:46 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:13:46 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:13:46 --> Utf8 Class Initialized
INFO - 2023-12-07 15:13:46 --> URI Class Initialized
INFO - 2023-12-07 15:13:46 --> Router Class Initialized
INFO - 2023-12-07 15:13:46 --> Output Class Initialized
INFO - 2023-12-07 15:13:46 --> Security Class Initialized
DEBUG - 2023-12-07 15:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:13:46 --> Input Class Initialized
INFO - 2023-12-07 15:13:46 --> Language Class Initialized
INFO - 2023-12-07 15:13:46 --> Loader Class Initialized
INFO - 2023-12-07 15:13:46 --> Helper loaded: url_helper
INFO - 2023-12-07 15:13:46 --> Helper loaded: form_helper
INFO - 2023-12-07 15:13:46 --> Helper loaded: file_helper
INFO - 2023-12-07 15:13:46 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:13:46 --> Form Validation Class Initialized
INFO - 2023-12-07 15:13:46 --> Upload Class Initialized
INFO - 2023-12-07 15:13:46 --> Model "M_auth" initialized
INFO - 2023-12-07 15:13:46 --> Model "M_user" initialized
INFO - 2023-12-07 15:13:46 --> Model "M_produk" initialized
INFO - 2023-12-07 15:13:46 --> Controller Class Initialized
INFO - 2023-12-07 15:13:46 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:13:46 --> Final output sent to browser
DEBUG - 2023-12-07 15:13:46 --> Total execution time: 0.0409
ERROR - 2023-12-07 15:14:06 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:14:06 --> Config Class Initialized
INFO - 2023-12-07 15:14:06 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:14:06 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:14:06 --> Utf8 Class Initialized
INFO - 2023-12-07 15:14:06 --> URI Class Initialized
INFO - 2023-12-07 15:14:06 --> Router Class Initialized
INFO - 2023-12-07 15:14:06 --> Output Class Initialized
INFO - 2023-12-07 15:14:06 --> Security Class Initialized
DEBUG - 2023-12-07 15:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:14:06 --> Input Class Initialized
INFO - 2023-12-07 15:14:06 --> Language Class Initialized
INFO - 2023-12-07 15:14:06 --> Loader Class Initialized
INFO - 2023-12-07 15:14:06 --> Helper loaded: url_helper
INFO - 2023-12-07 15:14:06 --> Helper loaded: form_helper
INFO - 2023-12-07 15:14:06 --> Helper loaded: file_helper
INFO - 2023-12-07 15:14:06 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:14:07 --> Form Validation Class Initialized
INFO - 2023-12-07 15:14:07 --> Upload Class Initialized
INFO - 2023-12-07 15:14:07 --> Model "M_auth" initialized
INFO - 2023-12-07 15:14:07 --> Model "M_user" initialized
INFO - 2023-12-07 15:14:07 --> Model "M_produk" initialized
INFO - 2023-12-07 15:14:07 --> Controller Class Initialized
INFO - 2023-12-07 15:14:07 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:14:07 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:14:07 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:14:07 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:14:07 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:14:07 --> Model "M_bank" initialized
INFO - 2023-12-07 15:14:07 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:14:07 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
ERROR - 2023-12-07 15:14:07 --> Severity: Warning --> Undefined variable $id_transaksi C:\xampp\htdocs\semakar_adventure_new\application\views\front\v_booking_saya.php 262
ERROR - 2023-12-07 15:14:07 --> Severity: Warning --> Undefined variable $id_transaksi C:\xampp\htdocs\semakar_adventure_new\application\views\front\v_booking_saya.php 262
INFO - 2023-12-07 15:14:07 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:14:07 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:14:07 --> Final output sent to browser
DEBUG - 2023-12-07 15:14:07 --> Total execution time: 0.3623
ERROR - 2023-12-07 15:14:07 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:14:07 --> Config Class Initialized
INFO - 2023-12-07 15:14:07 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:14:07 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:14:07 --> Utf8 Class Initialized
INFO - 2023-12-07 15:14:07 --> URI Class Initialized
INFO - 2023-12-07 15:14:07 --> Router Class Initialized
INFO - 2023-12-07 15:14:07 --> Output Class Initialized
INFO - 2023-12-07 15:14:07 --> Security Class Initialized
DEBUG - 2023-12-07 15:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:14:07 --> Input Class Initialized
INFO - 2023-12-07 15:14:07 --> Language Class Initialized
INFO - 2023-12-07 15:14:07 --> Loader Class Initialized
INFO - 2023-12-07 15:14:07 --> Helper loaded: url_helper
INFO - 2023-12-07 15:14:07 --> Helper loaded: form_helper
INFO - 2023-12-07 15:14:07 --> Helper loaded: file_helper
INFO - 2023-12-07 15:14:07 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:14:07 --> Form Validation Class Initialized
INFO - 2023-12-07 15:14:07 --> Upload Class Initialized
INFO - 2023-12-07 15:14:07 --> Model "M_auth" initialized
INFO - 2023-12-07 15:14:07 --> Model "M_user" initialized
INFO - 2023-12-07 15:14:07 --> Model "M_produk" initialized
INFO - 2023-12-07 15:14:07 --> Controller Class Initialized
INFO - 2023-12-07 15:14:07 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:14:07 --> Final output sent to browser
DEBUG - 2023-12-07 15:14:07 --> Total execution time: 0.0327
ERROR - 2023-12-07 15:18:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:18:30 --> Config Class Initialized
INFO - 2023-12-07 15:18:31 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:18:31 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:18:31 --> Utf8 Class Initialized
INFO - 2023-12-07 15:18:31 --> URI Class Initialized
INFO - 2023-12-07 15:18:31 --> Router Class Initialized
INFO - 2023-12-07 15:18:31 --> Output Class Initialized
INFO - 2023-12-07 15:18:31 --> Security Class Initialized
DEBUG - 2023-12-07 15:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:18:31 --> Input Class Initialized
INFO - 2023-12-07 15:18:31 --> Language Class Initialized
INFO - 2023-12-07 15:18:31 --> Loader Class Initialized
INFO - 2023-12-07 15:18:31 --> Helper loaded: url_helper
INFO - 2023-12-07 15:18:31 --> Helper loaded: form_helper
INFO - 2023-12-07 15:18:31 --> Helper loaded: file_helper
INFO - 2023-12-07 15:18:31 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:18:31 --> Form Validation Class Initialized
INFO - 2023-12-07 15:18:31 --> Upload Class Initialized
INFO - 2023-12-07 15:18:31 --> Model "M_auth" initialized
INFO - 2023-12-07 15:18:31 --> Model "M_user" initialized
INFO - 2023-12-07 15:18:31 --> Model "M_produk" initialized
INFO - 2023-12-07 15:18:31 --> Controller Class Initialized
INFO - 2023-12-07 15:18:31 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:18:31 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:18:31 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:18:31 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:18:31 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:18:31 --> Model "M_bank" initialized
INFO - 2023-12-07 15:18:31 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:18:31 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:18:32 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:18:32 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:18:32 --> Final output sent to browser
DEBUG - 2023-12-07 15:18:32 --> Total execution time: 1.0972
ERROR - 2023-12-07 15:18:32 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:18:32 --> Config Class Initialized
INFO - 2023-12-07 15:18:32 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:18:32 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:18:32 --> Utf8 Class Initialized
INFO - 2023-12-07 15:18:32 --> URI Class Initialized
INFO - 2023-12-07 15:18:32 --> Router Class Initialized
INFO - 2023-12-07 15:18:32 --> Output Class Initialized
INFO - 2023-12-07 15:18:32 --> Security Class Initialized
DEBUG - 2023-12-07 15:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:18:32 --> Input Class Initialized
INFO - 2023-12-07 15:18:32 --> Language Class Initialized
INFO - 2023-12-07 15:18:32 --> Loader Class Initialized
INFO - 2023-12-07 15:18:32 --> Helper loaded: url_helper
INFO - 2023-12-07 15:18:32 --> Helper loaded: form_helper
INFO - 2023-12-07 15:18:32 --> Helper loaded: file_helper
INFO - 2023-12-07 15:18:32 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:18:32 --> Form Validation Class Initialized
INFO - 2023-12-07 15:18:32 --> Upload Class Initialized
INFO - 2023-12-07 15:18:32 --> Model "M_auth" initialized
INFO - 2023-12-07 15:18:32 --> Model "M_user" initialized
INFO - 2023-12-07 15:18:32 --> Model "M_produk" initialized
INFO - 2023-12-07 15:18:32 --> Controller Class Initialized
INFO - 2023-12-07 15:18:32 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:18:32 --> Final output sent to browser
DEBUG - 2023-12-07 15:18:32 --> Total execution time: 0.0341
ERROR - 2023-12-07 15:18:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:18:41 --> Config Class Initialized
INFO - 2023-12-07 15:18:41 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:18:41 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:18:41 --> Utf8 Class Initialized
INFO - 2023-12-07 15:18:41 --> URI Class Initialized
INFO - 2023-12-07 15:18:41 --> Router Class Initialized
INFO - 2023-12-07 15:18:41 --> Output Class Initialized
INFO - 2023-12-07 15:18:41 --> Security Class Initialized
DEBUG - 2023-12-07 15:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:18:41 --> Input Class Initialized
INFO - 2023-12-07 15:18:41 --> Language Class Initialized
INFO - 2023-12-07 15:18:41 --> Loader Class Initialized
INFO - 2023-12-07 15:18:41 --> Helper loaded: url_helper
INFO - 2023-12-07 15:18:41 --> Helper loaded: form_helper
INFO - 2023-12-07 15:18:41 --> Helper loaded: file_helper
INFO - 2023-12-07 15:18:41 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:18:41 --> Form Validation Class Initialized
INFO - 2023-12-07 15:18:41 --> Upload Class Initialized
INFO - 2023-12-07 15:18:41 --> Model "M_auth" initialized
INFO - 2023-12-07 15:18:41 --> Model "M_user" initialized
INFO - 2023-12-07 15:18:41 --> Model "M_produk" initialized
INFO - 2023-12-07 15:18:41 --> Controller Class Initialized
INFO - 2023-12-07 15:18:41 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:18:41 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:18:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:18:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:18:41 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:18:41 --> Model "M_bank" initialized
INFO - 2023-12-07 15:18:41 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:18:41 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:18:42 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:18:42 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:18:42 --> Final output sent to browser
DEBUG - 2023-12-07 15:18:42 --> Total execution time: 1.0335
ERROR - 2023-12-07 15:18:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:18:44 --> Config Class Initialized
INFO - 2023-12-07 15:18:44 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:18:44 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:18:44 --> Utf8 Class Initialized
INFO - 2023-12-07 15:18:44 --> URI Class Initialized
INFO - 2023-12-07 15:18:44 --> Router Class Initialized
INFO - 2023-12-07 15:18:44 --> Output Class Initialized
INFO - 2023-12-07 15:18:44 --> Security Class Initialized
DEBUG - 2023-12-07 15:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:18:44 --> Input Class Initialized
INFO - 2023-12-07 15:18:44 --> Language Class Initialized
INFO - 2023-12-07 15:18:44 --> Loader Class Initialized
INFO - 2023-12-07 15:18:44 --> Helper loaded: url_helper
INFO - 2023-12-07 15:18:44 --> Helper loaded: form_helper
INFO - 2023-12-07 15:18:44 --> Helper loaded: file_helper
INFO - 2023-12-07 15:18:44 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:18:44 --> Form Validation Class Initialized
INFO - 2023-12-07 15:18:44 --> Upload Class Initialized
INFO - 2023-12-07 15:18:44 --> Model "M_auth" initialized
INFO - 2023-12-07 15:18:44 --> Model "M_user" initialized
INFO - 2023-12-07 15:18:44 --> Model "M_produk" initialized
INFO - 2023-12-07 15:18:44 --> Controller Class Initialized
INFO - 2023-12-07 15:18:44 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:18:44 --> Final output sent to browser
DEBUG - 2023-12-07 15:18:44 --> Total execution time: 0.0280
ERROR - 2023-12-07 15:19:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:19:53 --> Config Class Initialized
INFO - 2023-12-07 15:19:53 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:19:53 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:19:53 --> Utf8 Class Initialized
INFO - 2023-12-07 15:19:53 --> URI Class Initialized
INFO - 2023-12-07 15:19:53 --> Router Class Initialized
INFO - 2023-12-07 15:19:53 --> Output Class Initialized
INFO - 2023-12-07 15:19:53 --> Security Class Initialized
DEBUG - 2023-12-07 15:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:19:53 --> Input Class Initialized
INFO - 2023-12-07 15:19:53 --> Language Class Initialized
INFO - 2023-12-07 15:19:53 --> Loader Class Initialized
INFO - 2023-12-07 15:19:53 --> Helper loaded: url_helper
INFO - 2023-12-07 15:19:53 --> Helper loaded: form_helper
INFO - 2023-12-07 15:19:53 --> Helper loaded: file_helper
INFO - 2023-12-07 15:19:53 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:19:53 --> Form Validation Class Initialized
INFO - 2023-12-07 15:19:53 --> Upload Class Initialized
INFO - 2023-12-07 15:19:53 --> Model "M_auth" initialized
INFO - 2023-12-07 15:19:53 --> Model "M_user" initialized
INFO - 2023-12-07 15:19:53 --> Model "M_produk" initialized
INFO - 2023-12-07 15:19:53 --> Controller Class Initialized
INFO - 2023-12-07 15:19:53 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:19:53 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:19:53 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:19:53 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:19:53 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:19:53 --> Model "M_bank" initialized
INFO - 2023-12-07 15:19:53 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:19:53 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:19:54 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:19:54 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:19:54 --> Final output sent to browser
DEBUG - 2023-12-07 15:19:54 --> Total execution time: 0.3952
ERROR - 2023-12-07 15:19:54 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:19:54 --> Config Class Initialized
INFO - 2023-12-07 15:19:54 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:19:54 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:19:54 --> Utf8 Class Initialized
INFO - 2023-12-07 15:19:54 --> URI Class Initialized
INFO - 2023-12-07 15:19:54 --> Router Class Initialized
INFO - 2023-12-07 15:19:54 --> Output Class Initialized
INFO - 2023-12-07 15:19:54 --> Security Class Initialized
DEBUG - 2023-12-07 15:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:19:54 --> Input Class Initialized
INFO - 2023-12-07 15:19:54 --> Language Class Initialized
INFO - 2023-12-07 15:19:54 --> Loader Class Initialized
INFO - 2023-12-07 15:19:54 --> Helper loaded: url_helper
INFO - 2023-12-07 15:19:54 --> Helper loaded: form_helper
INFO - 2023-12-07 15:19:54 --> Helper loaded: file_helper
INFO - 2023-12-07 15:19:54 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:19:54 --> Form Validation Class Initialized
INFO - 2023-12-07 15:19:54 --> Upload Class Initialized
INFO - 2023-12-07 15:19:54 --> Model "M_auth" initialized
INFO - 2023-12-07 15:19:54 --> Model "M_user" initialized
INFO - 2023-12-07 15:19:54 --> Model "M_produk" initialized
INFO - 2023-12-07 15:19:54 --> Controller Class Initialized
INFO - 2023-12-07 15:19:54 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:19:54 --> Final output sent to browser
DEBUG - 2023-12-07 15:19:54 --> Total execution time: 0.0315
ERROR - 2023-12-07 15:20:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:20:03 --> Config Class Initialized
INFO - 2023-12-07 15:20:03 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:20:03 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:20:03 --> Utf8 Class Initialized
INFO - 2023-12-07 15:20:03 --> URI Class Initialized
INFO - 2023-12-07 15:20:03 --> Router Class Initialized
INFO - 2023-12-07 15:20:03 --> Output Class Initialized
INFO - 2023-12-07 15:20:03 --> Security Class Initialized
DEBUG - 2023-12-07 15:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:20:03 --> Input Class Initialized
INFO - 2023-12-07 15:20:03 --> Language Class Initialized
INFO - 2023-12-07 15:20:03 --> Loader Class Initialized
INFO - 2023-12-07 15:20:03 --> Helper loaded: url_helper
INFO - 2023-12-07 15:20:03 --> Helper loaded: form_helper
INFO - 2023-12-07 15:20:03 --> Helper loaded: file_helper
INFO - 2023-12-07 15:20:03 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:20:03 --> Form Validation Class Initialized
INFO - 2023-12-07 15:20:03 --> Upload Class Initialized
INFO - 2023-12-07 15:20:03 --> Model "M_auth" initialized
INFO - 2023-12-07 15:20:03 --> Model "M_user" initialized
INFO - 2023-12-07 15:20:03 --> Model "M_produk" initialized
INFO - 2023-12-07 15:20:03 --> Controller Class Initialized
INFO - 2023-12-07 15:20:03 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:20:03 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:20:03 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:20:03 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:20:03 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:20:03 --> Model "M_bank" initialized
INFO - 2023-12-07 15:20:03 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:20:03 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:20:03 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:20:03 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:20:03 --> Final output sent to browser
DEBUG - 2023-12-07 15:20:03 --> Total execution time: 0.4332
ERROR - 2023-12-07 15:20:04 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:20:04 --> Config Class Initialized
INFO - 2023-12-07 15:20:04 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:20:04 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:20:04 --> Utf8 Class Initialized
INFO - 2023-12-07 15:20:04 --> URI Class Initialized
INFO - 2023-12-07 15:20:04 --> Router Class Initialized
INFO - 2023-12-07 15:20:04 --> Output Class Initialized
INFO - 2023-12-07 15:20:04 --> Security Class Initialized
DEBUG - 2023-12-07 15:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:20:04 --> Input Class Initialized
INFO - 2023-12-07 15:20:04 --> Language Class Initialized
INFO - 2023-12-07 15:20:04 --> Loader Class Initialized
INFO - 2023-12-07 15:20:04 --> Helper loaded: url_helper
INFO - 2023-12-07 15:20:04 --> Helper loaded: form_helper
INFO - 2023-12-07 15:20:04 --> Helper loaded: file_helper
INFO - 2023-12-07 15:20:04 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:20:04 --> Form Validation Class Initialized
INFO - 2023-12-07 15:20:04 --> Upload Class Initialized
INFO - 2023-12-07 15:20:04 --> Model "M_auth" initialized
INFO - 2023-12-07 15:20:04 --> Model "M_user" initialized
INFO - 2023-12-07 15:20:04 --> Model "M_produk" initialized
INFO - 2023-12-07 15:20:04 --> Controller Class Initialized
INFO - 2023-12-07 15:20:04 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:20:04 --> Final output sent to browser
DEBUG - 2023-12-07 15:20:04 --> Total execution time: 0.0277
ERROR - 2023-12-07 15:20:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:20:11 --> Config Class Initialized
INFO - 2023-12-07 15:20:11 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:20:11 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:20:11 --> Utf8 Class Initialized
INFO - 2023-12-07 15:20:11 --> URI Class Initialized
INFO - 2023-12-07 15:20:11 --> Router Class Initialized
INFO - 2023-12-07 15:20:11 --> Output Class Initialized
INFO - 2023-12-07 15:20:11 --> Security Class Initialized
DEBUG - 2023-12-07 15:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:20:11 --> Input Class Initialized
INFO - 2023-12-07 15:20:11 --> Language Class Initialized
INFO - 2023-12-07 15:20:11 --> Loader Class Initialized
INFO - 2023-12-07 15:20:11 --> Helper loaded: url_helper
INFO - 2023-12-07 15:20:11 --> Helper loaded: form_helper
INFO - 2023-12-07 15:20:11 --> Helper loaded: file_helper
INFO - 2023-12-07 15:20:11 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:20:11 --> Form Validation Class Initialized
INFO - 2023-12-07 15:20:11 --> Upload Class Initialized
INFO - 2023-12-07 15:20:11 --> Model "M_auth" initialized
INFO - 2023-12-07 15:20:11 --> Model "M_user" initialized
INFO - 2023-12-07 15:20:11 --> Model "M_produk" initialized
INFO - 2023-12-07 15:20:11 --> Controller Class Initialized
INFO - 2023-12-07 15:20:11 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:20:11 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:20:11 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:20:11 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:20:11 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:20:11 --> Model "M_bank" initialized
INFO - 2023-12-07 15:20:11 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:20:11 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:20:11 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:20:11 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:20:11 --> Final output sent to browser
DEBUG - 2023-12-07 15:20:11 --> Total execution time: 0.4391
ERROR - 2023-12-07 15:20:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:20:12 --> Config Class Initialized
INFO - 2023-12-07 15:20:12 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:20:12 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:20:12 --> Utf8 Class Initialized
INFO - 2023-12-07 15:20:12 --> URI Class Initialized
INFO - 2023-12-07 15:20:12 --> Router Class Initialized
INFO - 2023-12-07 15:20:12 --> Output Class Initialized
INFO - 2023-12-07 15:20:12 --> Security Class Initialized
DEBUG - 2023-12-07 15:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:20:12 --> Input Class Initialized
INFO - 2023-12-07 15:20:12 --> Language Class Initialized
INFO - 2023-12-07 15:20:12 --> Loader Class Initialized
INFO - 2023-12-07 15:20:12 --> Helper loaded: url_helper
INFO - 2023-12-07 15:20:12 --> Helper loaded: form_helper
INFO - 2023-12-07 15:20:12 --> Helper loaded: file_helper
INFO - 2023-12-07 15:20:12 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:20:12 --> Form Validation Class Initialized
INFO - 2023-12-07 15:20:12 --> Upload Class Initialized
INFO - 2023-12-07 15:20:12 --> Model "M_auth" initialized
INFO - 2023-12-07 15:20:12 --> Model "M_user" initialized
INFO - 2023-12-07 15:20:12 --> Model "M_produk" initialized
INFO - 2023-12-07 15:20:12 --> Controller Class Initialized
INFO - 2023-12-07 15:20:12 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:20:12 --> Final output sent to browser
DEBUG - 2023-12-07 15:20:12 --> Total execution time: 0.0383
ERROR - 2023-12-07 15:20:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:20:29 --> Config Class Initialized
INFO - 2023-12-07 15:20:29 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:20:29 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:20:29 --> Utf8 Class Initialized
INFO - 2023-12-07 15:20:29 --> URI Class Initialized
INFO - 2023-12-07 15:20:29 --> Router Class Initialized
INFO - 2023-12-07 15:20:29 --> Output Class Initialized
INFO - 2023-12-07 15:20:29 --> Security Class Initialized
DEBUG - 2023-12-07 15:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:20:29 --> Input Class Initialized
INFO - 2023-12-07 15:20:29 --> Language Class Initialized
INFO - 2023-12-07 15:20:29 --> Loader Class Initialized
INFO - 2023-12-07 15:20:29 --> Helper loaded: url_helper
INFO - 2023-12-07 15:20:29 --> Helper loaded: form_helper
INFO - 2023-12-07 15:20:29 --> Helper loaded: file_helper
INFO - 2023-12-07 15:20:29 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:20:29 --> Form Validation Class Initialized
INFO - 2023-12-07 15:20:29 --> Upload Class Initialized
INFO - 2023-12-07 15:20:29 --> Model "M_auth" initialized
INFO - 2023-12-07 15:20:29 --> Model "M_user" initialized
INFO - 2023-12-07 15:20:29 --> Model "M_produk" initialized
INFO - 2023-12-07 15:20:29 --> Controller Class Initialized
INFO - 2023-12-07 15:20:29 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:20:29 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:20:29 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:20:29 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:20:29 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:20:29 --> Model "M_bank" initialized
INFO - 2023-12-07 15:20:29 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:20:29 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:20:30 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:20:30 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:20:30 --> Final output sent to browser
DEBUG - 2023-12-07 15:20:30 --> Total execution time: 0.3961
ERROR - 2023-12-07 15:20:30 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:20:30 --> Config Class Initialized
INFO - 2023-12-07 15:20:30 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:20:30 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:20:30 --> Utf8 Class Initialized
INFO - 2023-12-07 15:20:30 --> URI Class Initialized
INFO - 2023-12-07 15:20:30 --> Router Class Initialized
INFO - 2023-12-07 15:20:30 --> Output Class Initialized
INFO - 2023-12-07 15:20:30 --> Security Class Initialized
DEBUG - 2023-12-07 15:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:20:30 --> Input Class Initialized
INFO - 2023-12-07 15:20:30 --> Language Class Initialized
INFO - 2023-12-07 15:20:30 --> Loader Class Initialized
INFO - 2023-12-07 15:20:30 --> Helper loaded: url_helper
INFO - 2023-12-07 15:20:30 --> Helper loaded: form_helper
INFO - 2023-12-07 15:20:30 --> Helper loaded: file_helper
INFO - 2023-12-07 15:20:30 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:20:30 --> Form Validation Class Initialized
INFO - 2023-12-07 15:20:30 --> Upload Class Initialized
INFO - 2023-12-07 15:20:30 --> Model "M_auth" initialized
INFO - 2023-12-07 15:20:30 --> Model "M_user" initialized
INFO - 2023-12-07 15:20:30 --> Model "M_produk" initialized
INFO - 2023-12-07 15:20:30 --> Controller Class Initialized
INFO - 2023-12-07 15:20:30 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:20:30 --> Final output sent to browser
DEBUG - 2023-12-07 15:20:30 --> Total execution time: 0.0324
ERROR - 2023-12-07 15:20:42 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:20:42 --> Config Class Initialized
INFO - 2023-12-07 15:20:42 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:20:42 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:20:42 --> Utf8 Class Initialized
INFO - 2023-12-07 15:20:42 --> URI Class Initialized
INFO - 2023-12-07 15:20:42 --> Router Class Initialized
INFO - 2023-12-07 15:20:42 --> Output Class Initialized
INFO - 2023-12-07 15:20:42 --> Security Class Initialized
DEBUG - 2023-12-07 15:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:20:42 --> Input Class Initialized
INFO - 2023-12-07 15:20:42 --> Language Class Initialized
INFO - 2023-12-07 15:20:42 --> Loader Class Initialized
INFO - 2023-12-07 15:20:42 --> Helper loaded: url_helper
INFO - 2023-12-07 15:20:42 --> Helper loaded: form_helper
INFO - 2023-12-07 15:20:42 --> Helper loaded: file_helper
INFO - 2023-12-07 15:20:42 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:20:42 --> Form Validation Class Initialized
INFO - 2023-12-07 15:20:42 --> Upload Class Initialized
INFO - 2023-12-07 15:20:42 --> Model "M_auth" initialized
INFO - 2023-12-07 15:20:42 --> Model "M_user" initialized
INFO - 2023-12-07 15:20:42 --> Model "M_produk" initialized
INFO - 2023-12-07 15:20:42 --> Controller Class Initialized
INFO - 2023-12-07 15:20:42 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:20:42 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:20:42 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:20:42 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:20:42 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:20:42 --> Model "M_bank" initialized
INFO - 2023-12-07 15:20:42 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:20:42 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:20:42 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:20:42 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:20:42 --> Final output sent to browser
DEBUG - 2023-12-07 15:20:42 --> Total execution time: 0.4288
ERROR - 2023-12-07 15:22:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:22:22 --> Config Class Initialized
INFO - 2023-12-07 15:22:22 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:22:22 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:22:22 --> Utf8 Class Initialized
INFO - 2023-12-07 15:22:22 --> URI Class Initialized
INFO - 2023-12-07 15:22:22 --> Router Class Initialized
INFO - 2023-12-07 15:22:22 --> Output Class Initialized
INFO - 2023-12-07 15:22:22 --> Security Class Initialized
DEBUG - 2023-12-07 15:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:22:22 --> Input Class Initialized
INFO - 2023-12-07 15:22:22 --> Language Class Initialized
INFO - 2023-12-07 15:22:22 --> Loader Class Initialized
INFO - 2023-12-07 15:22:22 --> Helper loaded: url_helper
INFO - 2023-12-07 15:22:22 --> Helper loaded: form_helper
INFO - 2023-12-07 15:22:22 --> Helper loaded: file_helper
INFO - 2023-12-07 15:22:22 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:22:22 --> Form Validation Class Initialized
INFO - 2023-12-07 15:22:22 --> Upload Class Initialized
INFO - 2023-12-07 15:22:22 --> Model "M_auth" initialized
INFO - 2023-12-07 15:22:22 --> Model "M_user" initialized
INFO - 2023-12-07 15:22:22 --> Model "M_produk" initialized
INFO - 2023-12-07 15:22:22 --> Controller Class Initialized
INFO - 2023-12-07 15:22:22 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:22:22 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:22:22 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:22:22 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:22:22 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:22:22 --> Model "M_bank" initialized
INFO - 2023-12-07 15:22:22 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:22:22 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:22:22 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:22:22 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:22:22 --> Final output sent to browser
DEBUG - 2023-12-07 15:22:22 --> Total execution time: 0.3484
ERROR - 2023-12-07 15:22:28 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:22:28 --> Config Class Initialized
INFO - 2023-12-07 15:22:28 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:22:28 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:22:28 --> Utf8 Class Initialized
INFO - 2023-12-07 15:22:28 --> URI Class Initialized
INFO - 2023-12-07 15:22:28 --> Router Class Initialized
INFO - 2023-12-07 15:22:28 --> Output Class Initialized
INFO - 2023-12-07 15:22:28 --> Security Class Initialized
DEBUG - 2023-12-07 15:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:22:28 --> Input Class Initialized
INFO - 2023-12-07 15:22:28 --> Language Class Initialized
INFO - 2023-12-07 15:22:28 --> Loader Class Initialized
INFO - 2023-12-07 15:22:28 --> Helper loaded: url_helper
INFO - 2023-12-07 15:22:28 --> Helper loaded: form_helper
INFO - 2023-12-07 15:22:28 --> Helper loaded: file_helper
INFO - 2023-12-07 15:22:28 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:22:28 --> Form Validation Class Initialized
INFO - 2023-12-07 15:22:28 --> Upload Class Initialized
INFO - 2023-12-07 15:22:28 --> Model "M_auth" initialized
INFO - 2023-12-07 15:22:28 --> Model "M_user" initialized
INFO - 2023-12-07 15:22:28 --> Model "M_produk" initialized
INFO - 2023-12-07 15:22:28 --> Controller Class Initialized
INFO - 2023-12-07 15:22:28 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:22:28 --> Final output sent to browser
DEBUG - 2023-12-07 15:22:28 --> Total execution time: 0.0281
ERROR - 2023-12-07 15:22:31 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:22:31 --> Config Class Initialized
INFO - 2023-12-07 15:22:31 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:22:31 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:22:31 --> Utf8 Class Initialized
INFO - 2023-12-07 15:22:31 --> URI Class Initialized
INFO - 2023-12-07 15:22:31 --> Router Class Initialized
INFO - 2023-12-07 15:22:31 --> Output Class Initialized
INFO - 2023-12-07 15:22:31 --> Security Class Initialized
DEBUG - 2023-12-07 15:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:22:31 --> Input Class Initialized
INFO - 2023-12-07 15:22:31 --> Language Class Initialized
INFO - 2023-12-07 15:22:31 --> Loader Class Initialized
INFO - 2023-12-07 15:22:31 --> Helper loaded: url_helper
INFO - 2023-12-07 15:22:31 --> Helper loaded: form_helper
INFO - 2023-12-07 15:22:31 --> Helper loaded: file_helper
INFO - 2023-12-07 15:22:31 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:22:31 --> Form Validation Class Initialized
INFO - 2023-12-07 15:22:31 --> Upload Class Initialized
INFO - 2023-12-07 15:22:31 --> Model "M_auth" initialized
INFO - 2023-12-07 15:22:31 --> Model "M_user" initialized
INFO - 2023-12-07 15:22:31 --> Model "M_produk" initialized
INFO - 2023-12-07 15:22:31 --> Controller Class Initialized
INFO - 2023-12-07 15:22:31 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:22:31 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:22:31 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:22:31 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:22:31 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:22:31 --> Model "M_bank" initialized
INFO - 2023-12-07 15:22:31 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:22:31 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:22:31 --> Final output sent to browser
DEBUG - 2023-12-07 15:22:31 --> Total execution time: 0.0754
ERROR - 2023-12-07 15:22:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:22:34 --> Config Class Initialized
INFO - 2023-12-07 15:22:34 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:22:34 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:22:34 --> Utf8 Class Initialized
INFO - 2023-12-07 15:22:34 --> URI Class Initialized
INFO - 2023-12-07 15:22:35 --> Router Class Initialized
INFO - 2023-12-07 15:22:35 --> Output Class Initialized
INFO - 2023-12-07 15:22:35 --> Security Class Initialized
DEBUG - 2023-12-07 15:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:22:35 --> Input Class Initialized
INFO - 2023-12-07 15:22:35 --> Language Class Initialized
INFO - 2023-12-07 15:22:35 --> Loader Class Initialized
INFO - 2023-12-07 15:22:35 --> Helper loaded: url_helper
INFO - 2023-12-07 15:22:35 --> Helper loaded: form_helper
INFO - 2023-12-07 15:22:35 --> Helper loaded: file_helper
INFO - 2023-12-07 15:22:35 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:22:35 --> Form Validation Class Initialized
INFO - 2023-12-07 15:22:35 --> Upload Class Initialized
INFO - 2023-12-07 15:22:35 --> Model "M_auth" initialized
INFO - 2023-12-07 15:22:35 --> Model "M_user" initialized
INFO - 2023-12-07 15:22:35 --> Model "M_produk" initialized
INFO - 2023-12-07 15:22:35 --> Controller Class Initialized
INFO - 2023-12-07 15:22:35 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:22:35 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:22:35 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:22:35 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:22:35 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:22:35 --> Model "M_bank" initialized
INFO - 2023-12-07 15:22:35 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:22:35 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:22:35 --> Final output sent to browser
DEBUG - 2023-12-07 15:22:35 --> Total execution time: 0.0971
ERROR - 2023-12-07 15:22:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:22:39 --> Config Class Initialized
INFO - 2023-12-07 15:22:39 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:22:39 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:22:39 --> Utf8 Class Initialized
INFO - 2023-12-07 15:22:39 --> URI Class Initialized
INFO - 2023-12-07 15:22:39 --> Router Class Initialized
INFO - 2023-12-07 15:22:39 --> Output Class Initialized
INFO - 2023-12-07 15:22:39 --> Security Class Initialized
DEBUG - 2023-12-07 15:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:22:39 --> Input Class Initialized
INFO - 2023-12-07 15:22:39 --> Language Class Initialized
INFO - 2023-12-07 15:22:39 --> Loader Class Initialized
INFO - 2023-12-07 15:22:39 --> Helper loaded: url_helper
INFO - 2023-12-07 15:22:39 --> Helper loaded: form_helper
INFO - 2023-12-07 15:22:39 --> Helper loaded: file_helper
INFO - 2023-12-07 15:22:39 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:22:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:22:39 --> Form Validation Class Initialized
INFO - 2023-12-07 15:22:39 --> Upload Class Initialized
INFO - 2023-12-07 15:22:39 --> Model "M_auth" initialized
INFO - 2023-12-07 15:22:39 --> Model "M_user" initialized
INFO - 2023-12-07 15:22:39 --> Model "M_produk" initialized
INFO - 2023-12-07 15:22:39 --> Controller Class Initialized
INFO - 2023-12-07 15:22:39 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:22:39 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:22:39 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:22:39 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:22:39 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:22:39 --> Model "M_bank" initialized
INFO - 2023-12-07 15:22:39 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:22:39 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
ERROR - 2023-12-07 15:22:39 --> Severity: error --> Exception: Too few arguments to function Home::delete_booking_pelanggan(), 0 passed in C:\xampp\htdocs\semakar_adventure_new\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\semakar_adventure_new\application\controllers\Home.php 599
ERROR - 2023-12-07 15:22:46 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:22:46 --> Config Class Initialized
INFO - 2023-12-07 15:22:46 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:22:46 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:22:46 --> Utf8 Class Initialized
INFO - 2023-12-07 15:22:46 --> URI Class Initialized
INFO - 2023-12-07 15:22:46 --> Router Class Initialized
INFO - 2023-12-07 15:22:46 --> Output Class Initialized
INFO - 2023-12-07 15:22:46 --> Security Class Initialized
DEBUG - 2023-12-07 15:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:22:46 --> Input Class Initialized
INFO - 2023-12-07 15:22:46 --> Language Class Initialized
INFO - 2023-12-07 15:22:46 --> Loader Class Initialized
INFO - 2023-12-07 15:22:46 --> Helper loaded: url_helper
INFO - 2023-12-07 15:22:46 --> Helper loaded: form_helper
INFO - 2023-12-07 15:22:46 --> Helper loaded: file_helper
INFO - 2023-12-07 15:22:46 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:22:46 --> Form Validation Class Initialized
INFO - 2023-12-07 15:22:46 --> Upload Class Initialized
INFO - 2023-12-07 15:22:46 --> Model "M_auth" initialized
INFO - 2023-12-07 15:22:46 --> Model "M_user" initialized
INFO - 2023-12-07 15:22:46 --> Model "M_produk" initialized
INFO - 2023-12-07 15:22:46 --> Controller Class Initialized
INFO - 2023-12-07 15:22:46 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:22:46 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:22:46 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:22:46 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:22:46 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:22:46 --> Model "M_bank" initialized
INFO - 2023-12-07 15:22:46 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:22:46 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:22:46 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:22:46 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/index.php
INFO - 2023-12-07 15:22:46 --> Final output sent to browser
DEBUG - 2023-12-07 15:22:46 --> Total execution time: 0.0698
ERROR - 2023-12-07 15:22:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:22:47 --> Config Class Initialized
INFO - 2023-12-07 15:22:47 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:22:47 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:22:47 --> Utf8 Class Initialized
INFO - 2023-12-07 15:22:47 --> URI Class Initialized
ERROR - 2023-12-07 15:22:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:22:47 --> Router Class Initialized
INFO - 2023-12-07 15:22:47 --> Config Class Initialized
INFO - 2023-12-07 15:22:47 --> Output Class Initialized
INFO - 2023-12-07 15:22:47 --> Hooks Class Initialized
INFO - 2023-12-07 15:22:47 --> Security Class Initialized
DEBUG - 2023-12-07 15:22:47 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:22:47 --> Utf8 Class Initialized
DEBUG - 2023-12-07 15:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:22:47 --> Input Class Initialized
INFO - 2023-12-07 15:22:47 --> URI Class Initialized
INFO - 2023-12-07 15:22:47 --> Language Class Initialized
INFO - 2023-12-07 15:22:47 --> Router Class Initialized
INFO - 2023-12-07 15:22:47 --> Loader Class Initialized
INFO - 2023-12-07 15:22:47 --> Output Class Initialized
INFO - 2023-12-07 15:22:47 --> Helper loaded: url_helper
INFO - 2023-12-07 15:22:47 --> Security Class Initialized
DEBUG - 2023-12-07 15:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:22:47 --> Helper loaded: form_helper
INFO - 2023-12-07 15:22:47 --> Input Class Initialized
INFO - 2023-12-07 15:22:47 --> Language Class Initialized
INFO - 2023-12-07 15:22:47 --> Helper loaded: file_helper
INFO - 2023-12-07 15:22:47 --> Loader Class Initialized
INFO - 2023-12-07 15:22:47 --> Database Driver Class Initialized
INFO - 2023-12-07 15:22:47 --> Helper loaded: url_helper
INFO - 2023-12-07 15:22:47 --> Helper loaded: form_helper
INFO - 2023-12-07 15:22:47 --> Helper loaded: file_helper
DEBUG - 2023-12-07 15:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:22:47 --> Form Validation Class Initialized
INFO - 2023-12-07 15:22:47 --> Database Driver Class Initialized
INFO - 2023-12-07 15:22:47 --> Upload Class Initialized
INFO - 2023-12-07 15:22:47 --> Model "M_auth" initialized
INFO - 2023-12-07 15:22:47 --> Model "M_user" initialized
INFO - 2023-12-07 15:22:47 --> Model "M_produk" initialized
INFO - 2023-12-07 15:22:47 --> Controller Class Initialized
INFO - 2023-12-07 15:22:47 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
DEBUG - 2023-12-07 15:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:22:47 --> Final output sent to browser
DEBUG - 2023-12-07 15:22:47 --> Total execution time: 0.1079
INFO - 2023-12-07 15:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:22:47 --> Form Validation Class Initialized
INFO - 2023-12-07 15:22:47 --> Upload Class Initialized
INFO - 2023-12-07 15:22:47 --> Model "M_auth" initialized
INFO - 2023-12-07 15:22:47 --> Model "M_user" initialized
INFO - 2023-12-07 15:22:47 --> Model "M_produk" initialized
INFO - 2023-12-07 15:22:47 --> Controller Class Initialized
INFO - 2023-12-07 15:22:47 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:22:47 --> Final output sent to browser
DEBUG - 2023-12-07 15:22:47 --> Total execution time: 0.1053
ERROR - 2023-12-07 15:22:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:22:47 --> Config Class Initialized
INFO - 2023-12-07 15:22:47 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:22:47 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:22:47 --> Utf8 Class Initialized
INFO - 2023-12-07 15:22:47 --> URI Class Initialized
INFO - 2023-12-07 15:22:47 --> Router Class Initialized
INFO - 2023-12-07 15:22:47 --> Output Class Initialized
INFO - 2023-12-07 15:22:47 --> Security Class Initialized
DEBUG - 2023-12-07 15:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:22:47 --> Input Class Initialized
INFO - 2023-12-07 15:22:47 --> Language Class Initialized
INFO - 2023-12-07 15:22:47 --> Loader Class Initialized
INFO - 2023-12-07 15:22:47 --> Helper loaded: url_helper
INFO - 2023-12-07 15:22:47 --> Helper loaded: form_helper
INFO - 2023-12-07 15:22:47 --> Helper loaded: file_helper
INFO - 2023-12-07 15:22:47 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:22:47 --> Form Validation Class Initialized
INFO - 2023-12-07 15:22:47 --> Upload Class Initialized
INFO - 2023-12-07 15:22:47 --> Model "M_auth" initialized
INFO - 2023-12-07 15:22:47 --> Model "M_user" initialized
INFO - 2023-12-07 15:22:47 --> Model "M_produk" initialized
INFO - 2023-12-07 15:22:47 --> Controller Class Initialized
INFO - 2023-12-07 15:22:47 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:22:47 --> Final output sent to browser
DEBUG - 2023-12-07 15:22:47 --> Total execution time: 0.0259
ERROR - 2023-12-07 15:22:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:22:49 --> Config Class Initialized
INFO - 2023-12-07 15:22:49 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:22:49 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:22:49 --> Utf8 Class Initialized
INFO - 2023-12-07 15:22:49 --> URI Class Initialized
INFO - 2023-12-07 15:22:49 --> Router Class Initialized
INFO - 2023-12-07 15:22:49 --> Output Class Initialized
INFO - 2023-12-07 15:22:49 --> Security Class Initialized
DEBUG - 2023-12-07 15:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:22:49 --> Input Class Initialized
INFO - 2023-12-07 15:22:49 --> Language Class Initialized
INFO - 2023-12-07 15:22:49 --> Loader Class Initialized
INFO - 2023-12-07 15:22:49 --> Helper loaded: url_helper
INFO - 2023-12-07 15:22:49 --> Helper loaded: form_helper
INFO - 2023-12-07 15:22:49 --> Helper loaded: file_helper
INFO - 2023-12-07 15:22:49 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:22:49 --> Form Validation Class Initialized
INFO - 2023-12-07 15:22:49 --> Upload Class Initialized
INFO - 2023-12-07 15:22:49 --> Model "M_auth" initialized
INFO - 2023-12-07 15:22:49 --> Model "M_user" initialized
INFO - 2023-12-07 15:22:49 --> Model "M_produk" initialized
INFO - 2023-12-07 15:22:49 --> Controller Class Initialized
INFO - 2023-12-07 15:22:49 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:22:49 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:22:49 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:22:49 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:22:49 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:22:49 --> Model "M_bank" initialized
INFO - 2023-12-07 15:22:49 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:22:49 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:22:49 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:22:49 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:22:49 --> Final output sent to browser
DEBUG - 2023-12-07 15:22:49 --> Total execution time: 0.3997
ERROR - 2023-12-07 15:22:50 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:22:50 --> Config Class Initialized
INFO - 2023-12-07 15:22:50 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:22:50 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:22:50 --> Utf8 Class Initialized
INFO - 2023-12-07 15:22:50 --> URI Class Initialized
INFO - 2023-12-07 15:22:50 --> Router Class Initialized
INFO - 2023-12-07 15:22:50 --> Output Class Initialized
INFO - 2023-12-07 15:22:50 --> Security Class Initialized
DEBUG - 2023-12-07 15:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:22:50 --> Input Class Initialized
INFO - 2023-12-07 15:22:50 --> Language Class Initialized
INFO - 2023-12-07 15:22:50 --> Loader Class Initialized
INFO - 2023-12-07 15:22:50 --> Helper loaded: url_helper
INFO - 2023-12-07 15:22:50 --> Helper loaded: form_helper
INFO - 2023-12-07 15:22:50 --> Helper loaded: file_helper
INFO - 2023-12-07 15:22:50 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:22:50 --> Form Validation Class Initialized
INFO - 2023-12-07 15:22:50 --> Upload Class Initialized
INFO - 2023-12-07 15:22:50 --> Model "M_auth" initialized
INFO - 2023-12-07 15:22:50 --> Model "M_user" initialized
INFO - 2023-12-07 15:22:50 --> Model "M_produk" initialized
INFO - 2023-12-07 15:22:50 --> Controller Class Initialized
INFO - 2023-12-07 15:22:50 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:22:50 --> Final output sent to browser
DEBUG - 2023-12-07 15:22:50 --> Total execution time: 0.0262
ERROR - 2023-12-07 15:24:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:24:48 --> Config Class Initialized
INFO - 2023-12-07 15:24:48 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:24:48 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:24:48 --> Utf8 Class Initialized
INFO - 2023-12-07 15:24:48 --> URI Class Initialized
INFO - 2023-12-07 15:24:48 --> Router Class Initialized
INFO - 2023-12-07 15:24:48 --> Output Class Initialized
INFO - 2023-12-07 15:24:48 --> Security Class Initialized
DEBUG - 2023-12-07 15:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:24:48 --> Input Class Initialized
INFO - 2023-12-07 15:24:48 --> Language Class Initialized
INFO - 2023-12-07 15:24:48 --> Loader Class Initialized
INFO - 2023-12-07 15:24:48 --> Helper loaded: url_helper
INFO - 2023-12-07 15:24:48 --> Helper loaded: form_helper
INFO - 2023-12-07 15:24:48 --> Helper loaded: file_helper
INFO - 2023-12-07 15:24:48 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:24:48 --> Form Validation Class Initialized
INFO - 2023-12-07 15:24:48 --> Upload Class Initialized
INFO - 2023-12-07 15:24:48 --> Model "M_auth" initialized
INFO - 2023-12-07 15:24:48 --> Model "M_user" initialized
INFO - 2023-12-07 15:24:48 --> Model "M_produk" initialized
INFO - 2023-12-07 15:24:48 --> Controller Class Initialized
INFO - 2023-12-07 15:24:48 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:24:48 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:24:48 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:24:48 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:24:48 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:24:48 --> Model "M_bank" initialized
INFO - 2023-12-07 15:24:48 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:24:48 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:24:48 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:24:48 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:24:48 --> Final output sent to browser
DEBUG - 2023-12-07 15:24:48 --> Total execution time: 0.4300
ERROR - 2023-12-07 15:24:49 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:24:49 --> Config Class Initialized
INFO - 2023-12-07 15:24:49 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:24:49 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:24:49 --> Utf8 Class Initialized
INFO - 2023-12-07 15:24:49 --> URI Class Initialized
INFO - 2023-12-07 15:24:49 --> Router Class Initialized
INFO - 2023-12-07 15:24:49 --> Output Class Initialized
INFO - 2023-12-07 15:24:49 --> Security Class Initialized
DEBUG - 2023-12-07 15:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:24:49 --> Input Class Initialized
INFO - 2023-12-07 15:24:49 --> Language Class Initialized
INFO - 2023-12-07 15:24:49 --> Loader Class Initialized
INFO - 2023-12-07 15:24:49 --> Helper loaded: url_helper
INFO - 2023-12-07 15:24:49 --> Helper loaded: form_helper
INFO - 2023-12-07 15:24:49 --> Helper loaded: file_helper
INFO - 2023-12-07 15:24:49 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:24:49 --> Form Validation Class Initialized
INFO - 2023-12-07 15:24:49 --> Upload Class Initialized
INFO - 2023-12-07 15:24:49 --> Model "M_auth" initialized
INFO - 2023-12-07 15:24:49 --> Model "M_user" initialized
INFO - 2023-12-07 15:24:49 --> Model "M_produk" initialized
INFO - 2023-12-07 15:24:49 --> Controller Class Initialized
INFO - 2023-12-07 15:24:49 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:24:49 --> Final output sent to browser
DEBUG - 2023-12-07 15:24:49 --> Total execution time: 0.0222
ERROR - 2023-12-07 15:25:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:25:08 --> Config Class Initialized
INFO - 2023-12-07 15:25:08 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:25:08 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:25:08 --> Utf8 Class Initialized
INFO - 2023-12-07 15:25:08 --> URI Class Initialized
INFO - 2023-12-07 15:25:08 --> Router Class Initialized
INFO - 2023-12-07 15:25:08 --> Output Class Initialized
INFO - 2023-12-07 15:25:08 --> Security Class Initialized
DEBUG - 2023-12-07 15:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:25:08 --> Input Class Initialized
INFO - 2023-12-07 15:25:08 --> Language Class Initialized
INFO - 2023-12-07 15:25:08 --> Loader Class Initialized
INFO - 2023-12-07 15:25:08 --> Helper loaded: url_helper
INFO - 2023-12-07 15:25:08 --> Helper loaded: form_helper
INFO - 2023-12-07 15:25:08 --> Helper loaded: file_helper
INFO - 2023-12-07 15:25:08 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:25:08 --> Form Validation Class Initialized
INFO - 2023-12-07 15:25:08 --> Upload Class Initialized
INFO - 2023-12-07 15:25:08 --> Model "M_auth" initialized
INFO - 2023-12-07 15:25:08 --> Model "M_user" initialized
INFO - 2023-12-07 15:25:08 --> Model "M_produk" initialized
INFO - 2023-12-07 15:25:08 --> Controller Class Initialized
INFO - 2023-12-07 15:25:08 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:25:08 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:25:08 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:25:08 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:25:08 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:25:08 --> Model "M_bank" initialized
INFO - 2023-12-07 15:25:08 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:25:08 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:25:09 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:25:09 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:25:09 --> Final output sent to browser
DEBUG - 2023-12-07 15:25:09 --> Total execution time: 0.4241
ERROR - 2023-12-07 15:25:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:25:09 --> Config Class Initialized
INFO - 2023-12-07 15:25:09 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:25:09 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:25:09 --> Utf8 Class Initialized
INFO - 2023-12-07 15:25:09 --> URI Class Initialized
INFO - 2023-12-07 15:25:09 --> Router Class Initialized
INFO - 2023-12-07 15:25:09 --> Output Class Initialized
INFO - 2023-12-07 15:25:09 --> Security Class Initialized
DEBUG - 2023-12-07 15:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:25:09 --> Input Class Initialized
INFO - 2023-12-07 15:25:09 --> Language Class Initialized
INFO - 2023-12-07 15:25:09 --> Loader Class Initialized
INFO - 2023-12-07 15:25:09 --> Helper loaded: url_helper
INFO - 2023-12-07 15:25:09 --> Helper loaded: form_helper
INFO - 2023-12-07 15:25:09 --> Helper loaded: file_helper
INFO - 2023-12-07 15:25:09 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:25:09 --> Form Validation Class Initialized
INFO - 2023-12-07 15:25:09 --> Upload Class Initialized
INFO - 2023-12-07 15:25:09 --> Model "M_auth" initialized
INFO - 2023-12-07 15:25:09 --> Model "M_user" initialized
INFO - 2023-12-07 15:25:09 --> Model "M_produk" initialized
INFO - 2023-12-07 15:25:09 --> Controller Class Initialized
INFO - 2023-12-07 15:25:09 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:25:09 --> Final output sent to browser
DEBUG - 2023-12-07 15:25:09 --> Total execution time: 0.0350
ERROR - 2023-12-07 15:25:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:25:13 --> Config Class Initialized
INFO - 2023-12-07 15:25:13 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:25:13 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:25:13 --> Utf8 Class Initialized
INFO - 2023-12-07 15:25:13 --> URI Class Initialized
INFO - 2023-12-07 15:25:13 --> Router Class Initialized
INFO - 2023-12-07 15:25:13 --> Output Class Initialized
INFO - 2023-12-07 15:25:13 --> Security Class Initialized
DEBUG - 2023-12-07 15:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:25:13 --> Input Class Initialized
INFO - 2023-12-07 15:25:13 --> Language Class Initialized
INFO - 2023-12-07 15:25:13 --> Loader Class Initialized
INFO - 2023-12-07 15:25:13 --> Helper loaded: url_helper
INFO - 2023-12-07 15:25:13 --> Helper loaded: form_helper
INFO - 2023-12-07 15:25:13 --> Helper loaded: file_helper
INFO - 2023-12-07 15:25:13 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:25:13 --> Form Validation Class Initialized
INFO - 2023-12-07 15:25:13 --> Upload Class Initialized
INFO - 2023-12-07 15:25:13 --> Model "M_auth" initialized
INFO - 2023-12-07 15:25:13 --> Model "M_user" initialized
INFO - 2023-12-07 15:25:13 --> Model "M_produk" initialized
INFO - 2023-12-07 15:25:13 --> Controller Class Initialized
INFO - 2023-12-07 15:25:13 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:25:13 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:25:13 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:25:13 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:25:13 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:25:13 --> Model "M_bank" initialized
INFO - 2023-12-07 15:25:13 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:25:13 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
ERROR - 2023-12-07 15:25:13 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\semakar_adventure_new\application\views\front\v_booking_saya.php 9
ERROR - 2023-12-07 15:25:13 --> Severity: Warning --> Undefined variable $transaksi C:\xampp\htdocs\semakar_adventure_new\application\views\front\v_booking_saya.php 218
ERROR - 2023-12-07 15:25:13 --> Severity: Warning --> Undefined variable $transaksi_pending C:\xampp\htdocs\semakar_adventure_new\application\views\front\v_booking_saya.php 330
ERROR - 2023-12-07 15:25:13 --> Severity: Warning --> Undefined variable $transaksi_lunas C:\xampp\htdocs\semakar_adventure_new\application\views\front\v_booking_saya.php 408
ERROR - 2023-12-07 15:25:13 --> Severity: Warning --> Undefined variable $transaksi_sewaselesai C:\xampp\htdocs\semakar_adventure_new\application\views\front\v_booking_saya.php 483
INFO - 2023-12-07 15:25:13 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:25:13 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:25:13 --> Final output sent to browser
DEBUG - 2023-12-07 15:25:13 --> Total execution time: 0.0755
ERROR - 2023-12-07 15:25:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:25:13 --> Config Class Initialized
INFO - 2023-12-07 15:25:13 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:25:13 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:25:13 --> Utf8 Class Initialized
INFO - 2023-12-07 15:25:13 --> URI Class Initialized
INFO - 2023-12-07 15:25:13 --> Router Class Initialized
INFO - 2023-12-07 15:25:13 --> Output Class Initialized
INFO - 2023-12-07 15:25:13 --> Security Class Initialized
DEBUG - 2023-12-07 15:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:25:13 --> Input Class Initialized
INFO - 2023-12-07 15:25:13 --> Language Class Initialized
INFO - 2023-12-07 15:25:13 --> Loader Class Initialized
INFO - 2023-12-07 15:25:13 --> Helper loaded: url_helper
INFO - 2023-12-07 15:25:13 --> Helper loaded: form_helper
INFO - 2023-12-07 15:25:13 --> Helper loaded: file_helper
INFO - 2023-12-07 15:25:13 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:25:13 --> Form Validation Class Initialized
INFO - 2023-12-07 15:25:13 --> Upload Class Initialized
INFO - 2023-12-07 15:25:13 --> Model "M_auth" initialized
INFO - 2023-12-07 15:25:13 --> Model "M_user" initialized
INFO - 2023-12-07 15:25:13 --> Model "M_produk" initialized
INFO - 2023-12-07 15:25:13 --> Controller Class Initialized
INFO - 2023-12-07 15:25:13 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:25:13 --> Final output sent to browser
DEBUG - 2023-12-07 15:25:13 --> Total execution time: 0.0447
ERROR - 2023-12-07 15:25:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:25:13 --> Config Class Initialized
INFO - 2023-12-07 15:25:13 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:25:13 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:25:13 --> Utf8 Class Initialized
INFO - 2023-12-07 15:25:13 --> URI Class Initialized
INFO - 2023-12-07 15:25:13 --> Router Class Initialized
INFO - 2023-12-07 15:25:13 --> Output Class Initialized
INFO - 2023-12-07 15:25:13 --> Security Class Initialized
DEBUG - 2023-12-07 15:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:25:13 --> Input Class Initialized
INFO - 2023-12-07 15:25:13 --> Language Class Initialized
INFO - 2023-12-07 15:25:13 --> Loader Class Initialized
INFO - 2023-12-07 15:25:13 --> Helper loaded: url_helper
INFO - 2023-12-07 15:25:13 --> Helper loaded: form_helper
INFO - 2023-12-07 15:25:13 --> Helper loaded: file_helper
INFO - 2023-12-07 15:25:13 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:25:13 --> Form Validation Class Initialized
INFO - 2023-12-07 15:25:13 --> Upload Class Initialized
INFO - 2023-12-07 15:25:13 --> Model "M_auth" initialized
INFO - 2023-12-07 15:25:13 --> Model "M_user" initialized
INFO - 2023-12-07 15:25:13 --> Model "M_produk" initialized
INFO - 2023-12-07 15:25:13 --> Controller Class Initialized
INFO - 2023-12-07 15:25:13 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:25:13 --> Final output sent to browser
DEBUG - 2023-12-07 15:25:13 --> Total execution time: 0.0260
ERROR - 2023-12-07 15:25:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:25:22 --> Config Class Initialized
INFO - 2023-12-07 15:25:22 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:25:22 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:25:22 --> Utf8 Class Initialized
INFO - 2023-12-07 15:25:22 --> URI Class Initialized
INFO - 2023-12-07 15:25:22 --> Router Class Initialized
INFO - 2023-12-07 15:25:22 --> Output Class Initialized
INFO - 2023-12-07 15:25:23 --> Security Class Initialized
DEBUG - 2023-12-07 15:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:25:23 --> Input Class Initialized
INFO - 2023-12-07 15:25:23 --> Language Class Initialized
INFO - 2023-12-07 15:25:23 --> Loader Class Initialized
INFO - 2023-12-07 15:25:23 --> Helper loaded: url_helper
INFO - 2023-12-07 15:25:23 --> Helper loaded: form_helper
INFO - 2023-12-07 15:25:23 --> Helper loaded: file_helper
INFO - 2023-12-07 15:25:23 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:25:23 --> Form Validation Class Initialized
INFO - 2023-12-07 15:25:23 --> Upload Class Initialized
INFO - 2023-12-07 15:25:23 --> Model "M_auth" initialized
INFO - 2023-12-07 15:25:23 --> Model "M_user" initialized
INFO - 2023-12-07 15:25:23 --> Model "M_produk" initialized
INFO - 2023-12-07 15:25:23 --> Controller Class Initialized
INFO - 2023-12-07 15:25:23 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:25:23 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:25:23 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:25:23 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:25:23 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:25:23 --> Model "M_bank" initialized
INFO - 2023-12-07 15:25:23 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:25:23 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
ERROR - 2023-12-07 15:25:23 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\semakar_adventure_new\application\views\front\v_booking_saya.php 9
ERROR - 2023-12-07 15:25:23 --> Severity: Warning --> Undefined variable $transaksi C:\xampp\htdocs\semakar_adventure_new\application\views\front\v_booking_saya.php 218
ERROR - 2023-12-07 15:25:23 --> Severity: Warning --> Undefined variable $transaksi_pending C:\xampp\htdocs\semakar_adventure_new\application\views\front\v_booking_saya.php 330
ERROR - 2023-12-07 15:25:23 --> Severity: Warning --> Undefined variable $transaksi_lunas C:\xampp\htdocs\semakar_adventure_new\application\views\front\v_booking_saya.php 408
ERROR - 2023-12-07 15:25:23 --> Severity: Warning --> Undefined variable $transaksi_sewaselesai C:\xampp\htdocs\semakar_adventure_new\application\views\front\v_booking_saya.php 483
INFO - 2023-12-07 15:25:23 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:25:23 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:25:23 --> Final output sent to browser
DEBUG - 2023-12-07 15:25:23 --> Total execution time: 0.0444
ERROR - 2023-12-07 15:25:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:25:23 --> Config Class Initialized
INFO - 2023-12-07 15:25:23 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:25:23 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:25:23 --> Utf8 Class Initialized
INFO - 2023-12-07 15:25:23 --> URI Class Initialized
INFO - 2023-12-07 15:25:23 --> Router Class Initialized
INFO - 2023-12-07 15:25:23 --> Output Class Initialized
INFO - 2023-12-07 15:25:23 --> Security Class Initialized
DEBUG - 2023-12-07 15:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:25:23 --> Input Class Initialized
INFO - 2023-12-07 15:25:23 --> Language Class Initialized
INFO - 2023-12-07 15:25:23 --> Loader Class Initialized
INFO - 2023-12-07 15:25:23 --> Helper loaded: url_helper
INFO - 2023-12-07 15:25:23 --> Helper loaded: form_helper
INFO - 2023-12-07 15:25:23 --> Helper loaded: file_helper
INFO - 2023-12-07 15:25:23 --> Database Driver Class Initialized
ERROR - 2023-12-07 15:25:23 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:25:23 --> Config Class Initialized
INFO - 2023-12-07 15:25:23 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:25:23 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:25:23 --> Utf8 Class Initialized
INFO - 2023-12-07 15:25:23 --> URI Class Initialized
INFO - 2023-12-07 15:25:23 --> Router Class Initialized
DEBUG - 2023-12-07 15:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:25:23 --> Output Class Initialized
INFO - 2023-12-07 15:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:25:23 --> Security Class Initialized
INFO - 2023-12-07 15:25:23 --> Form Validation Class Initialized
DEBUG - 2023-12-07 15:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:25:23 --> Input Class Initialized
INFO - 2023-12-07 15:25:23 --> Language Class Initialized
INFO - 2023-12-07 15:25:23 --> Upload Class Initialized
INFO - 2023-12-07 15:25:23 --> Model "M_auth" initialized
INFO - 2023-12-07 15:25:23 --> Loader Class Initialized
INFO - 2023-12-07 15:25:23 --> Model "M_user" initialized
INFO - 2023-12-07 15:25:23 --> Model "M_produk" initialized
INFO - 2023-12-07 15:25:23 --> Controller Class Initialized
INFO - 2023-12-07 15:25:23 --> Helper loaded: url_helper
INFO - 2023-12-07 15:25:23 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:25:23 --> Final output sent to browser
DEBUG - 2023-12-07 15:25:23 --> Total execution time: 0.0432
INFO - 2023-12-07 15:25:23 --> Helper loaded: form_helper
INFO - 2023-12-07 15:25:23 --> Helper loaded: file_helper
INFO - 2023-12-07 15:25:23 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:25:23 --> Form Validation Class Initialized
INFO - 2023-12-07 15:25:23 --> Upload Class Initialized
INFO - 2023-12-07 15:25:23 --> Model "M_auth" initialized
INFO - 2023-12-07 15:25:23 --> Model "M_user" initialized
INFO - 2023-12-07 15:25:23 --> Model "M_produk" initialized
INFO - 2023-12-07 15:25:23 --> Controller Class Initialized
INFO - 2023-12-07 15:25:23 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:25:23 --> Final output sent to browser
DEBUG - 2023-12-07 15:25:23 --> Total execution time: 0.0256
ERROR - 2023-12-07 15:25:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:25:34 --> Config Class Initialized
INFO - 2023-12-07 15:25:34 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:25:34 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:25:34 --> Utf8 Class Initialized
INFO - 2023-12-07 15:25:34 --> URI Class Initialized
INFO - 2023-12-07 15:25:34 --> Router Class Initialized
INFO - 2023-12-07 15:25:34 --> Output Class Initialized
INFO - 2023-12-07 15:25:34 --> Security Class Initialized
DEBUG - 2023-12-07 15:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:25:34 --> Input Class Initialized
INFO - 2023-12-07 15:25:34 --> Language Class Initialized
INFO - 2023-12-07 15:25:34 --> Loader Class Initialized
INFO - 2023-12-07 15:25:34 --> Helper loaded: url_helper
INFO - 2023-12-07 15:25:34 --> Helper loaded: form_helper
INFO - 2023-12-07 15:25:34 --> Helper loaded: file_helper
INFO - 2023-12-07 15:25:34 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:25:34 --> Form Validation Class Initialized
INFO - 2023-12-07 15:25:34 --> Upload Class Initialized
INFO - 2023-12-07 15:25:34 --> Model "M_auth" initialized
INFO - 2023-12-07 15:25:34 --> Model "M_user" initialized
INFO - 2023-12-07 15:25:34 --> Model "M_produk" initialized
INFO - 2023-12-07 15:25:34 --> Controller Class Initialized
INFO - 2023-12-07 15:25:34 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:25:34 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:25:34 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:25:34 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:25:34 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:25:34 --> Model "M_bank" initialized
INFO - 2023-12-07 15:25:34 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:25:34 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:25:34 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:25:34 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/index.php
INFO - 2023-12-07 15:25:34 --> Final output sent to browser
DEBUG - 2023-12-07 15:25:34 --> Total execution time: 0.0963
ERROR - 2023-12-07 15:25:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:25:34 --> Config Class Initialized
INFO - 2023-12-07 15:25:34 --> Hooks Class Initialized
ERROR - 2023-12-07 15:25:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
DEBUG - 2023-12-07 15:25:34 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:25:34 --> Utf8 Class Initialized
INFO - 2023-12-07 15:25:34 --> Config Class Initialized
INFO - 2023-12-07 15:25:34 --> Hooks Class Initialized
INFO - 2023-12-07 15:25:34 --> URI Class Initialized
INFO - 2023-12-07 15:25:34 --> Router Class Initialized
DEBUG - 2023-12-07 15:25:34 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:25:34 --> Utf8 Class Initialized
INFO - 2023-12-07 15:25:34 --> Output Class Initialized
INFO - 2023-12-07 15:25:34 --> URI Class Initialized
INFO - 2023-12-07 15:25:34 --> Router Class Initialized
INFO - 2023-12-07 15:25:34 --> Security Class Initialized
DEBUG - 2023-12-07 15:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:25:34 --> Input Class Initialized
INFO - 2023-12-07 15:25:34 --> Output Class Initialized
INFO - 2023-12-07 15:25:34 --> Language Class Initialized
INFO - 2023-12-07 15:25:34 --> Security Class Initialized
INFO - 2023-12-07 15:25:34 --> Loader Class Initialized
DEBUG - 2023-12-07 15:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:25:34 --> Input Class Initialized
INFO - 2023-12-07 15:25:34 --> Language Class Initialized
INFO - 2023-12-07 15:25:34 --> Helper loaded: url_helper
INFO - 2023-12-07 15:25:34 --> Helper loaded: form_helper
INFO - 2023-12-07 15:25:34 --> Loader Class Initialized
INFO - 2023-12-07 15:25:34 --> Helper loaded: file_helper
INFO - 2023-12-07 15:25:34 --> Helper loaded: url_helper
INFO - 2023-12-07 15:25:34 --> Helper loaded: form_helper
INFO - 2023-12-07 15:25:34 --> Helper loaded: file_helper
INFO - 2023-12-07 15:25:34 --> Database Driver Class Initialized
INFO - 2023-12-07 15:25:34 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:25:34 --> Form Validation Class Initialized
DEBUG - 2023-12-07 15:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:25:34 --> Upload Class Initialized
INFO - 2023-12-07 15:25:34 --> Model "M_auth" initialized
INFO - 2023-12-07 15:25:34 --> Model "M_user" initialized
INFO - 2023-12-07 15:25:34 --> Model "M_produk" initialized
INFO - 2023-12-07 15:25:34 --> Controller Class Initialized
INFO - 2023-12-07 15:25:34 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:25:34 --> Final output sent to browser
DEBUG - 2023-12-07 15:25:34 --> Total execution time: 0.0636
INFO - 2023-12-07 15:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:25:34 --> Form Validation Class Initialized
INFO - 2023-12-07 15:25:34 --> Upload Class Initialized
INFO - 2023-12-07 15:25:34 --> Model "M_auth" initialized
INFO - 2023-12-07 15:25:34 --> Model "M_user" initialized
INFO - 2023-12-07 15:25:34 --> Model "M_produk" initialized
INFO - 2023-12-07 15:25:34 --> Controller Class Initialized
INFO - 2023-12-07 15:25:34 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:25:34 --> Final output sent to browser
DEBUG - 2023-12-07 15:25:34 --> Total execution time: 0.0635
ERROR - 2023-12-07 15:25:34 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:25:34 --> Config Class Initialized
INFO - 2023-12-07 15:25:34 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:25:34 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:25:34 --> Utf8 Class Initialized
INFO - 2023-12-07 15:25:34 --> URI Class Initialized
INFO - 2023-12-07 15:25:34 --> Router Class Initialized
INFO - 2023-12-07 15:25:34 --> Output Class Initialized
INFO - 2023-12-07 15:25:34 --> Security Class Initialized
DEBUG - 2023-12-07 15:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:25:34 --> Input Class Initialized
INFO - 2023-12-07 15:25:34 --> Language Class Initialized
INFO - 2023-12-07 15:25:34 --> Loader Class Initialized
INFO - 2023-12-07 15:25:34 --> Helper loaded: url_helper
INFO - 2023-12-07 15:25:34 --> Helper loaded: form_helper
INFO - 2023-12-07 15:25:35 --> Helper loaded: file_helper
INFO - 2023-12-07 15:25:35 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:25:35 --> Form Validation Class Initialized
INFO - 2023-12-07 15:25:35 --> Upload Class Initialized
INFO - 2023-12-07 15:25:35 --> Model "M_auth" initialized
INFO - 2023-12-07 15:25:35 --> Model "M_user" initialized
INFO - 2023-12-07 15:25:35 --> Model "M_produk" initialized
INFO - 2023-12-07 15:25:35 --> Controller Class Initialized
INFO - 2023-12-07 15:25:35 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:25:35 --> Final output sent to browser
DEBUG - 2023-12-07 15:25:35 --> Total execution time: 0.0371
ERROR - 2023-12-07 15:25:37 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:25:37 --> Config Class Initialized
INFO - 2023-12-07 15:25:37 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:25:37 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:25:37 --> Utf8 Class Initialized
INFO - 2023-12-07 15:25:37 --> URI Class Initialized
INFO - 2023-12-07 15:25:37 --> Router Class Initialized
INFO - 2023-12-07 15:25:37 --> Output Class Initialized
INFO - 2023-12-07 15:25:37 --> Security Class Initialized
DEBUG - 2023-12-07 15:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:25:37 --> Input Class Initialized
INFO - 2023-12-07 15:25:37 --> Language Class Initialized
INFO - 2023-12-07 15:25:37 --> Loader Class Initialized
INFO - 2023-12-07 15:25:37 --> Helper loaded: url_helper
INFO - 2023-12-07 15:25:37 --> Helper loaded: form_helper
INFO - 2023-12-07 15:25:37 --> Helper loaded: file_helper
INFO - 2023-12-07 15:25:37 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:25:37 --> Form Validation Class Initialized
INFO - 2023-12-07 15:25:37 --> Upload Class Initialized
INFO - 2023-12-07 15:25:37 --> Model "M_auth" initialized
INFO - 2023-12-07 15:25:37 --> Model "M_user" initialized
INFO - 2023-12-07 15:25:37 --> Model "M_produk" initialized
INFO - 2023-12-07 15:25:37 --> Controller Class Initialized
INFO - 2023-12-07 15:25:37 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:25:37 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:25:37 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:25:37 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:25:37 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:25:37 --> Model "M_bank" initialized
INFO - 2023-12-07 15:25:37 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:25:37 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:25:38 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:25:38 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:25:38 --> Final output sent to browser
DEBUG - 2023-12-07 15:25:38 --> Total execution time: 0.5636
ERROR - 2023-12-07 15:25:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:25:38 --> Config Class Initialized
INFO - 2023-12-07 15:25:38 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:25:38 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:25:38 --> Utf8 Class Initialized
INFO - 2023-12-07 15:25:38 --> URI Class Initialized
INFO - 2023-12-07 15:25:38 --> Router Class Initialized
INFO - 2023-12-07 15:25:38 --> Output Class Initialized
INFO - 2023-12-07 15:25:38 --> Security Class Initialized
DEBUG - 2023-12-07 15:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:25:38 --> Input Class Initialized
INFO - 2023-12-07 15:25:38 --> Language Class Initialized
INFO - 2023-12-07 15:25:38 --> Loader Class Initialized
INFO - 2023-12-07 15:25:38 --> Helper loaded: url_helper
INFO - 2023-12-07 15:25:38 --> Helper loaded: form_helper
INFO - 2023-12-07 15:25:38 --> Helper loaded: file_helper
INFO - 2023-12-07 15:25:38 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:25:38 --> Form Validation Class Initialized
INFO - 2023-12-07 15:25:38 --> Upload Class Initialized
INFO - 2023-12-07 15:25:38 --> Model "M_auth" initialized
INFO - 2023-12-07 15:25:38 --> Model "M_user" initialized
INFO - 2023-12-07 15:25:38 --> Model "M_produk" initialized
INFO - 2023-12-07 15:25:38 --> Controller Class Initialized
INFO - 2023-12-07 15:25:38 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:25:38 --> Final output sent to browser
DEBUG - 2023-12-07 15:25:38 --> Total execution time: 0.0284
ERROR - 2023-12-07 15:25:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:25:41 --> Config Class Initialized
INFO - 2023-12-07 15:25:41 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:25:41 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:25:41 --> Utf8 Class Initialized
INFO - 2023-12-07 15:25:41 --> URI Class Initialized
DEBUG - 2023-12-07 15:25:41 --> No URI present. Default controller set.
INFO - 2023-12-07 15:25:41 --> Router Class Initialized
INFO - 2023-12-07 15:25:41 --> Output Class Initialized
INFO - 2023-12-07 15:25:41 --> Security Class Initialized
DEBUG - 2023-12-07 15:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:25:41 --> Input Class Initialized
INFO - 2023-12-07 15:25:41 --> Language Class Initialized
INFO - 2023-12-07 15:25:41 --> Loader Class Initialized
INFO - 2023-12-07 15:25:41 --> Helper loaded: url_helper
INFO - 2023-12-07 15:25:41 --> Helper loaded: form_helper
INFO - 2023-12-07 15:25:41 --> Helper loaded: file_helper
INFO - 2023-12-07 15:25:41 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:25:41 --> Form Validation Class Initialized
INFO - 2023-12-07 15:25:41 --> Upload Class Initialized
INFO - 2023-12-07 15:25:41 --> Model "M_auth" initialized
INFO - 2023-12-07 15:25:41 --> Model "M_user" initialized
INFO - 2023-12-07 15:25:41 --> Model "M_produk" initialized
INFO - 2023-12-07 15:25:41 --> Controller Class Initialized
INFO - 2023-12-07 15:25:41 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:25:41 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:25:41 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:25:41 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:25:41 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:25:41 --> Model "M_bank" initialized
INFO - 2023-12-07 15:25:41 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:25:41 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:25:41 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:25:41 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/index.php
INFO - 2023-12-07 15:25:41 --> Final output sent to browser
DEBUG - 2023-12-07 15:25:41 --> Total execution time: 0.0864
ERROR - 2023-12-07 15:25:41 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:25:41 --> Config Class Initialized
INFO - 2023-12-07 15:25:41 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:25:41 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:25:41 --> Utf8 Class Initialized
INFO - 2023-12-07 15:25:41 --> URI Class Initialized
INFO - 2023-12-07 15:25:41 --> Router Class Initialized
INFO - 2023-12-07 15:25:41 --> Output Class Initialized
INFO - 2023-12-07 15:25:41 --> Security Class Initialized
DEBUG - 2023-12-07 15:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:25:41 --> Input Class Initialized
INFO - 2023-12-07 15:25:41 --> Language Class Initialized
INFO - 2023-12-07 15:25:41 --> Loader Class Initialized
INFO - 2023-12-07 15:25:41 --> Helper loaded: url_helper
INFO - 2023-12-07 15:25:41 --> Helper loaded: form_helper
INFO - 2023-12-07 15:25:41 --> Helper loaded: file_helper
INFO - 2023-12-07 15:25:41 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:25:41 --> Form Validation Class Initialized
INFO - 2023-12-07 15:25:41 --> Upload Class Initialized
INFO - 2023-12-07 15:25:41 --> Model "M_auth" initialized
INFO - 2023-12-07 15:25:41 --> Model "M_user" initialized
INFO - 2023-12-07 15:25:41 --> Model "M_produk" initialized
INFO - 2023-12-07 15:25:41 --> Controller Class Initialized
INFO - 2023-12-07 15:25:41 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:25:41 --> Final output sent to browser
DEBUG - 2023-12-07 15:25:41 --> Total execution time: 0.0374
ERROR - 2023-12-07 15:26:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:26:03 --> Config Class Initialized
INFO - 2023-12-07 15:26:03 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:26:03 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:26:03 --> Utf8 Class Initialized
INFO - 2023-12-07 15:26:03 --> URI Class Initialized
INFO - 2023-12-07 15:26:03 --> Router Class Initialized
INFO - 2023-12-07 15:26:03 --> Output Class Initialized
INFO - 2023-12-07 15:26:03 --> Security Class Initialized
DEBUG - 2023-12-07 15:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:26:03 --> Input Class Initialized
INFO - 2023-12-07 15:26:03 --> Language Class Initialized
INFO - 2023-12-07 15:26:03 --> Loader Class Initialized
INFO - 2023-12-07 15:26:03 --> Helper loaded: url_helper
INFO - 2023-12-07 15:26:03 --> Helper loaded: form_helper
INFO - 2023-12-07 15:26:03 --> Helper loaded: file_helper
INFO - 2023-12-07 15:26:03 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:26:03 --> Form Validation Class Initialized
INFO - 2023-12-07 15:26:03 --> Upload Class Initialized
INFO - 2023-12-07 15:26:03 --> Model "M_auth" initialized
INFO - 2023-12-07 15:26:03 --> Model "M_user" initialized
INFO - 2023-12-07 15:26:03 --> Model "M_produk" initialized
INFO - 2023-12-07 15:26:03 --> Controller Class Initialized
INFO - 2023-12-07 15:26:03 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:26:03 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:26:03 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:26:03 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:26:03 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:26:03 --> Model "M_bank" initialized
INFO - 2023-12-07 15:26:03 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:26:03 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:26:03 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:26:03 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_produk_detail.php
INFO - 2023-12-07 15:26:03 --> Final output sent to browser
DEBUG - 2023-12-07 15:26:03 --> Total execution time: 0.0389
ERROR - 2023-12-07 15:26:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:26:03 --> Config Class Initialized
INFO - 2023-12-07 15:26:03 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:26:03 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:26:03 --> Utf8 Class Initialized
INFO - 2023-12-07 15:26:03 --> URI Class Initialized
INFO - 2023-12-07 15:26:03 --> Router Class Initialized
INFO - 2023-12-07 15:26:03 --> Output Class Initialized
INFO - 2023-12-07 15:26:03 --> Security Class Initialized
DEBUG - 2023-12-07 15:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:26:03 --> Input Class Initialized
INFO - 2023-12-07 15:26:03 --> Language Class Initialized
INFO - 2023-12-07 15:26:03 --> Loader Class Initialized
INFO - 2023-12-07 15:26:03 --> Helper loaded: url_helper
INFO - 2023-12-07 15:26:03 --> Helper loaded: form_helper
INFO - 2023-12-07 15:26:03 --> Helper loaded: file_helper
INFO - 2023-12-07 15:26:03 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:26:03 --> Form Validation Class Initialized
INFO - 2023-12-07 15:26:03 --> Upload Class Initialized
INFO - 2023-12-07 15:26:03 --> Model "M_auth" initialized
INFO - 2023-12-07 15:26:03 --> Model "M_user" initialized
INFO - 2023-12-07 15:26:03 --> Model "M_produk" initialized
INFO - 2023-12-07 15:26:03 --> Controller Class Initialized
INFO - 2023-12-07 15:26:03 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:26:03 --> Final output sent to browser
DEBUG - 2023-12-07 15:26:03 --> Total execution time: 0.0317
ERROR - 2023-12-07 15:26:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:26:03 --> Config Class Initialized
INFO - 2023-12-07 15:26:03 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:26:03 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:26:03 --> Utf8 Class Initialized
INFO - 2023-12-07 15:26:03 --> URI Class Initialized
INFO - 2023-12-07 15:26:03 --> Router Class Initialized
INFO - 2023-12-07 15:26:03 --> Output Class Initialized
INFO - 2023-12-07 15:26:03 --> Security Class Initialized
DEBUG - 2023-12-07 15:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:26:03 --> Input Class Initialized
INFO - 2023-12-07 15:26:03 --> Language Class Initialized
INFO - 2023-12-07 15:26:03 --> Loader Class Initialized
INFO - 2023-12-07 15:26:03 --> Helper loaded: url_helper
INFO - 2023-12-07 15:26:03 --> Helper loaded: form_helper
INFO - 2023-12-07 15:26:03 --> Helper loaded: file_helper
INFO - 2023-12-07 15:26:03 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:26:03 --> Form Validation Class Initialized
INFO - 2023-12-07 15:26:03 --> Upload Class Initialized
INFO - 2023-12-07 15:26:03 --> Model "M_auth" initialized
INFO - 2023-12-07 15:26:03 --> Model "M_user" initialized
INFO - 2023-12-07 15:26:03 --> Model "M_produk" initialized
INFO - 2023-12-07 15:26:03 --> Controller Class Initialized
INFO - 2023-12-07 15:26:03 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:26:03 --> Final output sent to browser
DEBUG - 2023-12-07 15:26:03 --> Total execution time: 0.0285
ERROR - 2023-12-07 15:26:13 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:26:13 --> Config Class Initialized
INFO - 2023-12-07 15:26:13 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:26:13 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:26:13 --> Utf8 Class Initialized
INFO - 2023-12-07 15:26:13 --> URI Class Initialized
INFO - 2023-12-07 15:26:13 --> Router Class Initialized
INFO - 2023-12-07 15:26:13 --> Output Class Initialized
INFO - 2023-12-07 15:26:13 --> Security Class Initialized
DEBUG - 2023-12-07 15:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:26:13 --> Input Class Initialized
INFO - 2023-12-07 15:26:13 --> Language Class Initialized
INFO - 2023-12-07 15:26:13 --> Loader Class Initialized
INFO - 2023-12-07 15:26:13 --> Helper loaded: url_helper
INFO - 2023-12-07 15:26:13 --> Helper loaded: form_helper
INFO - 2023-12-07 15:26:13 --> Helper loaded: file_helper
INFO - 2023-12-07 15:26:13 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:26:13 --> Form Validation Class Initialized
INFO - 2023-12-07 15:26:13 --> Upload Class Initialized
INFO - 2023-12-07 15:26:13 --> Model "M_auth" initialized
INFO - 2023-12-07 15:26:13 --> Model "M_user" initialized
INFO - 2023-12-07 15:26:13 --> Model "M_produk" initialized
INFO - 2023-12-07 15:26:13 --> Controller Class Initialized
INFO - 2023-12-07 15:26:13 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:26:13 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:26:13 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:26:13 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:26:13 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:26:13 --> Model "M_bank" initialized
INFO - 2023-12-07 15:26:13 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:26:13 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:26:13 --> Email Class Initialized
INFO - 2023-12-07 15:26:14 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-12-07 15:26:17 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:26:17 --> Config Class Initialized
INFO - 2023-12-07 15:26:17 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:26:17 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:26:17 --> Utf8 Class Initialized
INFO - 2023-12-07 15:26:17 --> URI Class Initialized
INFO - 2023-12-07 15:26:17 --> Router Class Initialized
INFO - 2023-12-07 15:26:17 --> Output Class Initialized
INFO - 2023-12-07 15:26:17 --> Security Class Initialized
DEBUG - 2023-12-07 15:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:26:17 --> Input Class Initialized
INFO - 2023-12-07 15:26:17 --> Language Class Initialized
INFO - 2023-12-07 15:26:17 --> Loader Class Initialized
INFO - 2023-12-07 15:26:17 --> Helper loaded: url_helper
INFO - 2023-12-07 15:26:17 --> Helper loaded: form_helper
INFO - 2023-12-07 15:26:17 --> Helper loaded: file_helper
INFO - 2023-12-07 15:26:17 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:26:17 --> Form Validation Class Initialized
INFO - 2023-12-07 15:26:17 --> Upload Class Initialized
INFO - 2023-12-07 15:26:17 --> Model "M_auth" initialized
INFO - 2023-12-07 15:26:17 --> Model "M_user" initialized
INFO - 2023-12-07 15:26:17 --> Model "M_produk" initialized
INFO - 2023-12-07 15:26:17 --> Controller Class Initialized
INFO - 2023-12-07 15:26:17 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:26:17 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:26:17 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:26:17 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:26:17 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:26:17 --> Model "M_bank" initialized
INFO - 2023-12-07 15:26:17 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:26:17 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:26:17 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:26:17 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:26:17 --> Final output sent to browser
DEBUG - 2023-12-07 15:26:17 --> Total execution time: 0.3903
ERROR - 2023-12-07 15:26:18 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:26:18 --> Config Class Initialized
INFO - 2023-12-07 15:26:18 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:26:18 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:26:18 --> Utf8 Class Initialized
INFO - 2023-12-07 15:26:18 --> URI Class Initialized
INFO - 2023-12-07 15:26:18 --> Router Class Initialized
INFO - 2023-12-07 15:26:18 --> Output Class Initialized
INFO - 2023-12-07 15:26:18 --> Security Class Initialized
DEBUG - 2023-12-07 15:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:26:18 --> Input Class Initialized
INFO - 2023-12-07 15:26:18 --> Language Class Initialized
INFO - 2023-12-07 15:26:18 --> Loader Class Initialized
INFO - 2023-12-07 15:26:18 --> Helper loaded: url_helper
INFO - 2023-12-07 15:26:18 --> Helper loaded: form_helper
INFO - 2023-12-07 15:26:18 --> Helper loaded: file_helper
INFO - 2023-12-07 15:26:18 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:26:18 --> Form Validation Class Initialized
INFO - 2023-12-07 15:26:18 --> Upload Class Initialized
INFO - 2023-12-07 15:26:18 --> Model "M_auth" initialized
INFO - 2023-12-07 15:26:18 --> Model "M_user" initialized
INFO - 2023-12-07 15:26:18 --> Model "M_produk" initialized
INFO - 2023-12-07 15:26:18 --> Controller Class Initialized
INFO - 2023-12-07 15:26:18 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:26:18 --> Final output sent to browser
DEBUG - 2023-12-07 15:26:18 --> Total execution time: 0.0315
ERROR - 2023-12-07 15:26:21 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:26:21 --> Config Class Initialized
INFO - 2023-12-07 15:26:21 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:26:21 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:26:21 --> Utf8 Class Initialized
INFO - 2023-12-07 15:26:21 --> URI Class Initialized
INFO - 2023-12-07 15:26:21 --> Router Class Initialized
INFO - 2023-12-07 15:26:21 --> Output Class Initialized
INFO - 2023-12-07 15:26:21 --> Security Class Initialized
DEBUG - 2023-12-07 15:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:26:21 --> Input Class Initialized
INFO - 2023-12-07 15:26:21 --> Language Class Initialized
INFO - 2023-12-07 15:26:21 --> Loader Class Initialized
INFO - 2023-12-07 15:26:21 --> Helper loaded: url_helper
INFO - 2023-12-07 15:26:21 --> Helper loaded: form_helper
INFO - 2023-12-07 15:26:21 --> Helper loaded: file_helper
INFO - 2023-12-07 15:26:21 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:26:21 --> Form Validation Class Initialized
INFO - 2023-12-07 15:26:21 --> Upload Class Initialized
INFO - 2023-12-07 15:26:21 --> Model "M_auth" initialized
INFO - 2023-12-07 15:26:21 --> Model "M_user" initialized
INFO - 2023-12-07 15:26:21 --> Model "M_produk" initialized
INFO - 2023-12-07 15:26:21 --> Controller Class Initialized
INFO - 2023-12-07 15:26:21 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:26:21 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:26:21 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:26:21 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:26:21 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:26:21 --> Model "M_bank" initialized
INFO - 2023-12-07 15:26:21 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:26:21 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:26:22 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:26:22 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:26:22 --> Final output sent to browser
DEBUG - 2023-12-07 15:26:22 --> Total execution time: 0.4507
ERROR - 2023-12-07 15:26:22 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:26:22 --> Config Class Initialized
INFO - 2023-12-07 15:26:22 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:26:22 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:26:22 --> Utf8 Class Initialized
INFO - 2023-12-07 15:26:22 --> URI Class Initialized
INFO - 2023-12-07 15:26:22 --> Router Class Initialized
INFO - 2023-12-07 15:26:22 --> Output Class Initialized
INFO - 2023-12-07 15:26:22 --> Security Class Initialized
DEBUG - 2023-12-07 15:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:26:22 --> Input Class Initialized
INFO - 2023-12-07 15:26:22 --> Language Class Initialized
INFO - 2023-12-07 15:26:22 --> Loader Class Initialized
INFO - 2023-12-07 15:26:22 --> Helper loaded: url_helper
INFO - 2023-12-07 15:26:22 --> Helper loaded: form_helper
INFO - 2023-12-07 15:26:22 --> Helper loaded: file_helper
INFO - 2023-12-07 15:26:22 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:26:22 --> Form Validation Class Initialized
INFO - 2023-12-07 15:26:22 --> Upload Class Initialized
INFO - 2023-12-07 15:26:22 --> Model "M_auth" initialized
INFO - 2023-12-07 15:26:22 --> Model "M_user" initialized
INFO - 2023-12-07 15:26:22 --> Model "M_produk" initialized
INFO - 2023-12-07 15:26:22 --> Controller Class Initialized
INFO - 2023-12-07 15:26:22 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:26:22 --> Final output sent to browser
DEBUG - 2023-12-07 15:26:22 --> Total execution time: 0.0249
ERROR - 2023-12-07 15:26:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:26:26 --> Config Class Initialized
INFO - 2023-12-07 15:26:26 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:26:26 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:26:26 --> Utf8 Class Initialized
INFO - 2023-12-07 15:26:26 --> URI Class Initialized
INFO - 2023-12-07 15:26:26 --> Router Class Initialized
INFO - 2023-12-07 15:26:26 --> Output Class Initialized
INFO - 2023-12-07 15:26:26 --> Security Class Initialized
DEBUG - 2023-12-07 15:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:26:26 --> Input Class Initialized
INFO - 2023-12-07 15:26:26 --> Language Class Initialized
INFO - 2023-12-07 15:26:26 --> Loader Class Initialized
INFO - 2023-12-07 15:26:26 --> Helper loaded: url_helper
INFO - 2023-12-07 15:26:26 --> Helper loaded: form_helper
INFO - 2023-12-07 15:26:26 --> Helper loaded: file_helper
INFO - 2023-12-07 15:26:26 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:26:26 --> Form Validation Class Initialized
INFO - 2023-12-07 15:26:26 --> Upload Class Initialized
INFO - 2023-12-07 15:26:26 --> Model "M_auth" initialized
INFO - 2023-12-07 15:26:26 --> Model "M_user" initialized
INFO - 2023-12-07 15:26:26 --> Model "M_produk" initialized
INFO - 2023-12-07 15:26:26 --> Controller Class Initialized
INFO - 2023-12-07 15:26:26 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:26:26 --> Final output sent to browser
DEBUG - 2023-12-07 15:26:26 --> Total execution time: 0.0922
ERROR - 2023-12-07 15:26:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:26:36 --> Config Class Initialized
INFO - 2023-12-07 15:26:36 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:26:36 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:26:36 --> Utf8 Class Initialized
INFO - 2023-12-07 15:26:36 --> URI Class Initialized
DEBUG - 2023-12-07 15:26:36 --> No URI present. Default controller set.
INFO - 2023-12-07 15:26:36 --> Router Class Initialized
INFO - 2023-12-07 15:26:36 --> Output Class Initialized
INFO - 2023-12-07 15:26:36 --> Security Class Initialized
DEBUG - 2023-12-07 15:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:26:36 --> Input Class Initialized
INFO - 2023-12-07 15:26:36 --> Language Class Initialized
INFO - 2023-12-07 15:26:36 --> Loader Class Initialized
INFO - 2023-12-07 15:26:36 --> Helper loaded: url_helper
INFO - 2023-12-07 15:26:36 --> Helper loaded: form_helper
INFO - 2023-12-07 15:26:36 --> Helper loaded: file_helper
INFO - 2023-12-07 15:26:36 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:26:36 --> Form Validation Class Initialized
INFO - 2023-12-07 15:26:36 --> Upload Class Initialized
INFO - 2023-12-07 15:26:36 --> Model "M_auth" initialized
INFO - 2023-12-07 15:26:36 --> Model "M_user" initialized
INFO - 2023-12-07 15:26:36 --> Model "M_produk" initialized
INFO - 2023-12-07 15:26:36 --> Controller Class Initialized
INFO - 2023-12-07 15:26:36 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:26:36 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:26:36 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:26:36 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:26:36 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:26:36 --> Model "M_bank" initialized
INFO - 2023-12-07 15:26:36 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:26:36 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:26:36 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:26:36 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/index.php
INFO - 2023-12-07 15:26:36 --> Final output sent to browser
DEBUG - 2023-12-07 15:26:36 --> Total execution time: 0.0519
ERROR - 2023-12-07 15:26:36 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:26:36 --> Config Class Initialized
INFO - 2023-12-07 15:26:36 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:26:36 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:26:36 --> Utf8 Class Initialized
INFO - 2023-12-07 15:26:36 --> URI Class Initialized
INFO - 2023-12-07 15:26:36 --> Router Class Initialized
INFO - 2023-12-07 15:26:36 --> Output Class Initialized
INFO - 2023-12-07 15:26:36 --> Security Class Initialized
DEBUG - 2023-12-07 15:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:26:36 --> Input Class Initialized
INFO - 2023-12-07 15:26:36 --> Language Class Initialized
INFO - 2023-12-07 15:26:36 --> Loader Class Initialized
INFO - 2023-12-07 15:26:36 --> Helper loaded: url_helper
INFO - 2023-12-07 15:26:36 --> Helper loaded: form_helper
INFO - 2023-12-07 15:26:36 --> Helper loaded: file_helper
INFO - 2023-12-07 15:26:36 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:26:36 --> Form Validation Class Initialized
INFO - 2023-12-07 15:26:36 --> Upload Class Initialized
INFO - 2023-12-07 15:26:36 --> Model "M_auth" initialized
INFO - 2023-12-07 15:26:36 --> Model "M_user" initialized
INFO - 2023-12-07 15:26:36 --> Model "M_produk" initialized
INFO - 2023-12-07 15:26:36 --> Controller Class Initialized
INFO - 2023-12-07 15:26:36 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:26:36 --> Final output sent to browser
DEBUG - 2023-12-07 15:26:36 --> Total execution time: 0.0497
ERROR - 2023-12-07 15:26:38 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:26:38 --> Config Class Initialized
INFO - 2023-12-07 15:26:38 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:26:38 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:26:38 --> Utf8 Class Initialized
INFO - 2023-12-07 15:26:38 --> URI Class Initialized
INFO - 2023-12-07 15:26:38 --> Router Class Initialized
INFO - 2023-12-07 15:26:38 --> Output Class Initialized
INFO - 2023-12-07 15:26:38 --> Security Class Initialized
DEBUG - 2023-12-07 15:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:26:38 --> Input Class Initialized
INFO - 2023-12-07 15:26:38 --> Language Class Initialized
INFO - 2023-12-07 15:26:38 --> Loader Class Initialized
INFO - 2023-12-07 15:26:38 --> Helper loaded: url_helper
INFO - 2023-12-07 15:26:38 --> Helper loaded: form_helper
INFO - 2023-12-07 15:26:38 --> Helper loaded: file_helper
INFO - 2023-12-07 15:26:38 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:26:38 --> Form Validation Class Initialized
INFO - 2023-12-07 15:26:38 --> Upload Class Initialized
INFO - 2023-12-07 15:26:38 --> Model "M_auth" initialized
INFO - 2023-12-07 15:26:38 --> Model "M_user" initialized
INFO - 2023-12-07 15:26:38 --> Model "M_produk" initialized
INFO - 2023-12-07 15:26:38 --> Controller Class Initialized
INFO - 2023-12-07 15:26:38 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:26:38 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:26:38 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:26:38 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:26:38 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:26:38 --> Model "M_bank" initialized
INFO - 2023-12-07 15:26:38 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:26:38 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:26:38 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:26:38 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:26:38 --> Final output sent to browser
DEBUG - 2023-12-07 15:26:38 --> Total execution time: 0.3532
ERROR - 2023-12-07 15:26:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:26:39 --> Config Class Initialized
INFO - 2023-12-07 15:26:39 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:26:39 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:26:39 --> Utf8 Class Initialized
INFO - 2023-12-07 15:26:39 --> URI Class Initialized
INFO - 2023-12-07 15:26:39 --> Router Class Initialized
INFO - 2023-12-07 15:26:39 --> Output Class Initialized
INFO - 2023-12-07 15:26:39 --> Security Class Initialized
DEBUG - 2023-12-07 15:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:26:39 --> Input Class Initialized
INFO - 2023-12-07 15:26:39 --> Language Class Initialized
INFO - 2023-12-07 15:26:39 --> Loader Class Initialized
INFO - 2023-12-07 15:26:39 --> Helper loaded: url_helper
INFO - 2023-12-07 15:26:39 --> Helper loaded: form_helper
INFO - 2023-12-07 15:26:39 --> Helper loaded: file_helper
INFO - 2023-12-07 15:26:39 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:26:39 --> Form Validation Class Initialized
INFO - 2023-12-07 15:26:39 --> Upload Class Initialized
INFO - 2023-12-07 15:26:39 --> Model "M_auth" initialized
INFO - 2023-12-07 15:26:39 --> Model "M_user" initialized
INFO - 2023-12-07 15:26:39 --> Model "M_produk" initialized
INFO - 2023-12-07 15:26:39 --> Controller Class Initialized
INFO - 2023-12-07 15:26:39 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:26:39 --> Final output sent to browser
DEBUG - 2023-12-07 15:26:39 --> Total execution time: 0.0254
ERROR - 2023-12-07 15:27:39 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:27:39 --> Config Class Initialized
INFO - 2023-12-07 15:27:39 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:27:39 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:27:39 --> Utf8 Class Initialized
INFO - 2023-12-07 15:27:39 --> URI Class Initialized
INFO - 2023-12-07 15:27:39 --> Router Class Initialized
INFO - 2023-12-07 15:27:39 --> Output Class Initialized
INFO - 2023-12-07 15:27:39 --> Security Class Initialized
DEBUG - 2023-12-07 15:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:27:39 --> Input Class Initialized
INFO - 2023-12-07 15:27:39 --> Language Class Initialized
INFO - 2023-12-07 15:27:39 --> Loader Class Initialized
INFO - 2023-12-07 15:27:39 --> Helper loaded: url_helper
INFO - 2023-12-07 15:27:39 --> Helper loaded: form_helper
INFO - 2023-12-07 15:27:39 --> Helper loaded: file_helper
INFO - 2023-12-07 15:27:39 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:27:39 --> Form Validation Class Initialized
INFO - 2023-12-07 15:27:39 --> Upload Class Initialized
INFO - 2023-12-07 15:27:39 --> Model "M_auth" initialized
INFO - 2023-12-07 15:27:39 --> Model "M_user" initialized
INFO - 2023-12-07 15:27:39 --> Model "M_produk" initialized
INFO - 2023-12-07 15:27:39 --> Controller Class Initialized
INFO - 2023-12-07 15:27:39 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:27:39 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:27:39 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:27:39 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:27:39 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:27:39 --> Model "M_bank" initialized
INFO - 2023-12-07 15:27:39 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:27:39 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:27:39 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:27:39 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:27:39 --> Final output sent to browser
DEBUG - 2023-12-07 15:27:39 --> Total execution time: 0.3981
ERROR - 2023-12-07 15:27:40 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:27:40 --> Config Class Initialized
INFO - 2023-12-07 15:27:40 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:27:40 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:27:40 --> Utf8 Class Initialized
INFO - 2023-12-07 15:27:40 --> URI Class Initialized
INFO - 2023-12-07 15:27:40 --> Router Class Initialized
INFO - 2023-12-07 15:27:40 --> Output Class Initialized
INFO - 2023-12-07 15:27:40 --> Security Class Initialized
DEBUG - 2023-12-07 15:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:27:40 --> Input Class Initialized
INFO - 2023-12-07 15:27:40 --> Language Class Initialized
INFO - 2023-12-07 15:27:40 --> Loader Class Initialized
INFO - 2023-12-07 15:27:40 --> Helper loaded: url_helper
INFO - 2023-12-07 15:27:40 --> Helper loaded: form_helper
INFO - 2023-12-07 15:27:40 --> Helper loaded: file_helper
INFO - 2023-12-07 15:27:40 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:27:40 --> Form Validation Class Initialized
INFO - 2023-12-07 15:27:40 --> Upload Class Initialized
INFO - 2023-12-07 15:27:40 --> Model "M_auth" initialized
INFO - 2023-12-07 15:27:40 --> Model "M_user" initialized
INFO - 2023-12-07 15:27:40 --> Model "M_produk" initialized
INFO - 2023-12-07 15:27:40 --> Controller Class Initialized
INFO - 2023-12-07 15:27:40 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:27:40 --> Final output sent to browser
DEBUG - 2023-12-07 15:27:40 --> Total execution time: 0.0339
ERROR - 2023-12-07 15:27:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:27:44 --> Config Class Initialized
INFO - 2023-12-07 15:27:44 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:27:44 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:27:44 --> Utf8 Class Initialized
INFO - 2023-12-07 15:27:44 --> URI Class Initialized
INFO - 2023-12-07 15:27:44 --> Router Class Initialized
INFO - 2023-12-07 15:27:44 --> Output Class Initialized
INFO - 2023-12-07 15:27:44 --> Security Class Initialized
DEBUG - 2023-12-07 15:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:27:44 --> Input Class Initialized
INFO - 2023-12-07 15:27:44 --> Language Class Initialized
INFO - 2023-12-07 15:27:44 --> Loader Class Initialized
INFO - 2023-12-07 15:27:44 --> Helper loaded: url_helper
INFO - 2023-12-07 15:27:44 --> Helper loaded: form_helper
INFO - 2023-12-07 15:27:44 --> Helper loaded: file_helper
INFO - 2023-12-07 15:27:44 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:27:44 --> Form Validation Class Initialized
INFO - 2023-12-07 15:27:44 --> Upload Class Initialized
INFO - 2023-12-07 15:27:44 --> Model "M_auth" initialized
INFO - 2023-12-07 15:27:44 --> Model "M_user" initialized
INFO - 2023-12-07 15:27:44 --> Model "M_produk" initialized
INFO - 2023-12-07 15:27:44 --> Controller Class Initialized
INFO - 2023-12-07 15:27:44 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:27:44 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:27:44 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:27:44 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:27:44 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:27:44 --> Model "M_bank" initialized
INFO - 2023-12-07 15:27:44 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:27:44 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
ERROR - 2023-12-07 15:27:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:27:44 --> Config Class Initialized
INFO - 2023-12-07 15:27:44 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:27:44 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:27:44 --> Utf8 Class Initialized
INFO - 2023-12-07 15:27:44 --> URI Class Initialized
DEBUG - 2023-12-07 15:27:44 --> No URI present. Default controller set.
INFO - 2023-12-07 15:27:44 --> Router Class Initialized
INFO - 2023-12-07 15:27:44 --> Output Class Initialized
INFO - 2023-12-07 15:27:44 --> Security Class Initialized
DEBUG - 2023-12-07 15:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:27:44 --> Input Class Initialized
INFO - 2023-12-07 15:27:44 --> Language Class Initialized
INFO - 2023-12-07 15:27:44 --> Loader Class Initialized
INFO - 2023-12-07 15:27:44 --> Helper loaded: url_helper
INFO - 2023-12-07 15:27:44 --> Helper loaded: form_helper
INFO - 2023-12-07 15:27:44 --> Helper loaded: file_helper
INFO - 2023-12-07 15:27:44 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:27:44 --> Form Validation Class Initialized
INFO - 2023-12-07 15:27:44 --> Upload Class Initialized
INFO - 2023-12-07 15:27:44 --> Model "M_auth" initialized
INFO - 2023-12-07 15:27:44 --> Model "M_user" initialized
INFO - 2023-12-07 15:27:44 --> Model "M_produk" initialized
INFO - 2023-12-07 15:27:44 --> Controller Class Initialized
INFO - 2023-12-07 15:27:44 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:27:44 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:27:44 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:27:44 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:27:44 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:27:44 --> Model "M_bank" initialized
INFO - 2023-12-07 15:27:44 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:27:44 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:27:44 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:27:44 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/index.php
INFO - 2023-12-07 15:27:44 --> Final output sent to browser
DEBUG - 2023-12-07 15:27:44 --> Total execution time: 0.0654
ERROR - 2023-12-07 15:27:44 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:27:44 --> Config Class Initialized
INFO - 2023-12-07 15:27:44 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:27:44 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:27:44 --> Utf8 Class Initialized
INFO - 2023-12-07 15:27:44 --> URI Class Initialized
INFO - 2023-12-07 15:27:44 --> Router Class Initialized
INFO - 2023-12-07 15:27:44 --> Output Class Initialized
INFO - 2023-12-07 15:27:44 --> Security Class Initialized
DEBUG - 2023-12-07 15:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:27:44 --> Input Class Initialized
INFO - 2023-12-07 15:27:44 --> Language Class Initialized
INFO - 2023-12-07 15:27:44 --> Loader Class Initialized
INFO - 2023-12-07 15:27:44 --> Helper loaded: url_helper
INFO - 2023-12-07 15:27:44 --> Helper loaded: form_helper
INFO - 2023-12-07 15:27:44 --> Helper loaded: file_helper
INFO - 2023-12-07 15:27:44 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:27:44 --> Form Validation Class Initialized
INFO - 2023-12-07 15:27:44 --> Upload Class Initialized
INFO - 2023-12-07 15:27:44 --> Model "M_auth" initialized
INFO - 2023-12-07 15:27:44 --> Model "M_user" initialized
INFO - 2023-12-07 15:27:44 --> Model "M_produk" initialized
INFO - 2023-12-07 15:27:44 --> Controller Class Initialized
INFO - 2023-12-07 15:27:44 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:27:44 --> Final output sent to browser
DEBUG - 2023-12-07 15:27:44 --> Total execution time: 0.0315
ERROR - 2023-12-07 15:27:47 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:27:47 --> Config Class Initialized
INFO - 2023-12-07 15:27:47 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:27:47 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:27:47 --> Utf8 Class Initialized
INFO - 2023-12-07 15:27:47 --> URI Class Initialized
INFO - 2023-12-07 15:27:47 --> Router Class Initialized
INFO - 2023-12-07 15:27:47 --> Output Class Initialized
INFO - 2023-12-07 15:27:47 --> Security Class Initialized
DEBUG - 2023-12-07 15:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:27:47 --> Input Class Initialized
INFO - 2023-12-07 15:27:47 --> Language Class Initialized
INFO - 2023-12-07 15:27:47 --> Loader Class Initialized
INFO - 2023-12-07 15:27:47 --> Helper loaded: url_helper
INFO - 2023-12-07 15:27:47 --> Helper loaded: form_helper
INFO - 2023-12-07 15:27:47 --> Helper loaded: file_helper
INFO - 2023-12-07 15:27:47 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:27:47 --> Form Validation Class Initialized
INFO - 2023-12-07 15:27:47 --> Upload Class Initialized
INFO - 2023-12-07 15:27:47 --> Model "M_auth" initialized
INFO - 2023-12-07 15:27:47 --> Model "M_user" initialized
INFO - 2023-12-07 15:27:47 --> Model "M_produk" initialized
INFO - 2023-12-07 15:27:47 --> Controller Class Initialized
INFO - 2023-12-07 15:27:47 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:27:47 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:27:47 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:27:47 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:27:47 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:27:47 --> Model "M_bank" initialized
INFO - 2023-12-07 15:27:47 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:27:47 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:27:47 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:27:47 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:27:47 --> Final output sent to browser
DEBUG - 2023-12-07 15:27:47 --> Total execution time: 0.3830
ERROR - 2023-12-07 15:27:48 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:27:48 --> Config Class Initialized
INFO - 2023-12-07 15:27:48 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:27:48 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:27:48 --> Utf8 Class Initialized
INFO - 2023-12-07 15:27:48 --> URI Class Initialized
INFO - 2023-12-07 15:27:48 --> Router Class Initialized
INFO - 2023-12-07 15:27:48 --> Output Class Initialized
INFO - 2023-12-07 15:27:48 --> Security Class Initialized
DEBUG - 2023-12-07 15:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:27:48 --> Input Class Initialized
INFO - 2023-12-07 15:27:48 --> Language Class Initialized
INFO - 2023-12-07 15:27:48 --> Loader Class Initialized
INFO - 2023-12-07 15:27:48 --> Helper loaded: url_helper
INFO - 2023-12-07 15:27:48 --> Helper loaded: form_helper
INFO - 2023-12-07 15:27:48 --> Helper loaded: file_helper
INFO - 2023-12-07 15:27:48 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:27:48 --> Form Validation Class Initialized
INFO - 2023-12-07 15:27:48 --> Upload Class Initialized
INFO - 2023-12-07 15:27:48 --> Model "M_auth" initialized
INFO - 2023-12-07 15:27:48 --> Model "M_user" initialized
INFO - 2023-12-07 15:27:48 --> Model "M_produk" initialized
INFO - 2023-12-07 15:27:48 --> Controller Class Initialized
INFO - 2023-12-07 15:27:48 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:27:48 --> Final output sent to browser
DEBUG - 2023-12-07 15:27:48 --> Total execution time: 0.0526
ERROR - 2023-12-07 15:28:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:28:08 --> Config Class Initialized
INFO - 2023-12-07 15:28:08 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:28:08 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:28:08 --> Utf8 Class Initialized
INFO - 2023-12-07 15:28:08 --> URI Class Initialized
DEBUG - 2023-12-07 15:28:08 --> No URI present. Default controller set.
INFO - 2023-12-07 15:28:08 --> Router Class Initialized
INFO - 2023-12-07 15:28:08 --> Output Class Initialized
INFO - 2023-12-07 15:28:08 --> Security Class Initialized
DEBUG - 2023-12-07 15:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:28:08 --> Input Class Initialized
INFO - 2023-12-07 15:28:08 --> Language Class Initialized
INFO - 2023-12-07 15:28:08 --> Loader Class Initialized
INFO - 2023-12-07 15:28:08 --> Helper loaded: url_helper
INFO - 2023-12-07 15:28:08 --> Helper loaded: form_helper
INFO - 2023-12-07 15:28:08 --> Helper loaded: file_helper
INFO - 2023-12-07 15:28:08 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:28:08 --> Form Validation Class Initialized
INFO - 2023-12-07 15:28:08 --> Upload Class Initialized
INFO - 2023-12-07 15:28:08 --> Model "M_auth" initialized
INFO - 2023-12-07 15:28:08 --> Model "M_user" initialized
INFO - 2023-12-07 15:28:08 --> Model "M_produk" initialized
INFO - 2023-12-07 15:28:08 --> Controller Class Initialized
INFO - 2023-12-07 15:28:08 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:28:08 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:28:08 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:28:08 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:28:08 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:28:08 --> Model "M_bank" initialized
INFO - 2023-12-07 15:28:08 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:28:08 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:28:08 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:28:08 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/index.php
INFO - 2023-12-07 15:28:08 --> Final output sent to browser
DEBUG - 2023-12-07 15:28:08 --> Total execution time: 0.0906
ERROR - 2023-12-07 15:28:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:28:09 --> Config Class Initialized
INFO - 2023-12-07 15:28:09 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:28:09 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:28:09 --> Utf8 Class Initialized
INFO - 2023-12-07 15:28:09 --> URI Class Initialized
INFO - 2023-12-07 15:28:09 --> Router Class Initialized
INFO - 2023-12-07 15:28:09 --> Output Class Initialized
INFO - 2023-12-07 15:28:09 --> Security Class Initialized
DEBUG - 2023-12-07 15:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:28:09 --> Input Class Initialized
INFO - 2023-12-07 15:28:09 --> Language Class Initialized
INFO - 2023-12-07 15:28:09 --> Loader Class Initialized
INFO - 2023-12-07 15:28:09 --> Helper loaded: url_helper
INFO - 2023-12-07 15:28:09 --> Helper loaded: form_helper
INFO - 2023-12-07 15:28:09 --> Helper loaded: file_helper
INFO - 2023-12-07 15:28:09 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:28:09 --> Form Validation Class Initialized
INFO - 2023-12-07 15:28:09 --> Upload Class Initialized
INFO - 2023-12-07 15:28:09 --> Model "M_auth" initialized
INFO - 2023-12-07 15:28:09 --> Model "M_user" initialized
INFO - 2023-12-07 15:28:09 --> Model "M_produk" initialized
INFO - 2023-12-07 15:28:09 --> Controller Class Initialized
INFO - 2023-12-07 15:28:09 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:28:09 --> Final output sent to browser
DEBUG - 2023-12-07 15:28:09 --> Total execution time: 0.0295
ERROR - 2023-12-07 15:28:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:28:11 --> Config Class Initialized
INFO - 2023-12-07 15:28:11 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:28:11 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:28:11 --> Utf8 Class Initialized
INFO - 2023-12-07 15:28:11 --> URI Class Initialized
INFO - 2023-12-07 15:28:11 --> Router Class Initialized
INFO - 2023-12-07 15:28:11 --> Output Class Initialized
INFO - 2023-12-07 15:28:11 --> Security Class Initialized
DEBUG - 2023-12-07 15:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:28:11 --> Input Class Initialized
INFO - 2023-12-07 15:28:11 --> Language Class Initialized
INFO - 2023-12-07 15:28:11 --> Loader Class Initialized
INFO - 2023-12-07 15:28:11 --> Helper loaded: url_helper
INFO - 2023-12-07 15:28:11 --> Helper loaded: form_helper
INFO - 2023-12-07 15:28:11 --> Helper loaded: file_helper
INFO - 2023-12-07 15:28:11 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:28:12 --> Form Validation Class Initialized
INFO - 2023-12-07 15:28:12 --> Upload Class Initialized
INFO - 2023-12-07 15:28:12 --> Model "M_auth" initialized
INFO - 2023-12-07 15:28:12 --> Model "M_user" initialized
INFO - 2023-12-07 15:28:12 --> Model "M_produk" initialized
INFO - 2023-12-07 15:28:12 --> Controller Class Initialized
INFO - 2023-12-07 15:28:12 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:28:12 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:28:12 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:28:12 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:28:12 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:28:12 --> Model "M_bank" initialized
INFO - 2023-12-07 15:28:12 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:28:12 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:28:12 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:28:12 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_produk_detail.php
INFO - 2023-12-07 15:28:12 --> Final output sent to browser
DEBUG - 2023-12-07 15:28:12 --> Total execution time: 0.0964
ERROR - 2023-12-07 15:28:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:28:12 --> Config Class Initialized
INFO - 2023-12-07 15:28:12 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:28:12 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:28:12 --> Utf8 Class Initialized
INFO - 2023-12-07 15:28:12 --> URI Class Initialized
INFO - 2023-12-07 15:28:12 --> Router Class Initialized
INFO - 2023-12-07 15:28:12 --> Output Class Initialized
INFO - 2023-12-07 15:28:12 --> Security Class Initialized
DEBUG - 2023-12-07 15:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:28:12 --> Input Class Initialized
INFO - 2023-12-07 15:28:12 --> Language Class Initialized
INFO - 2023-12-07 15:28:12 --> Loader Class Initialized
INFO - 2023-12-07 15:28:12 --> Helper loaded: url_helper
INFO - 2023-12-07 15:28:12 --> Helper loaded: form_helper
INFO - 2023-12-07 15:28:12 --> Helper loaded: file_helper
INFO - 2023-12-07 15:28:12 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:28:12 --> Form Validation Class Initialized
INFO - 2023-12-07 15:28:12 --> Upload Class Initialized
INFO - 2023-12-07 15:28:12 --> Model "M_auth" initialized
INFO - 2023-12-07 15:28:12 --> Model "M_user" initialized
INFO - 2023-12-07 15:28:12 --> Model "M_produk" initialized
INFO - 2023-12-07 15:28:12 --> Controller Class Initialized
INFO - 2023-12-07 15:28:12 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:28:12 --> Final output sent to browser
DEBUG - 2023-12-07 15:28:12 --> Total execution time: 0.0504
ERROR - 2023-12-07 15:28:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:28:12 --> Config Class Initialized
INFO - 2023-12-07 15:28:12 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:28:12 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:28:12 --> Utf8 Class Initialized
INFO - 2023-12-07 15:28:12 --> URI Class Initialized
INFO - 2023-12-07 15:28:12 --> Router Class Initialized
INFO - 2023-12-07 15:28:12 --> Output Class Initialized
INFO - 2023-12-07 15:28:12 --> Security Class Initialized
DEBUG - 2023-12-07 15:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:28:12 --> Input Class Initialized
INFO - 2023-12-07 15:28:12 --> Language Class Initialized
INFO - 2023-12-07 15:28:12 --> Loader Class Initialized
INFO - 2023-12-07 15:28:12 --> Helper loaded: url_helper
INFO - 2023-12-07 15:28:12 --> Helper loaded: form_helper
INFO - 2023-12-07 15:28:12 --> Helper loaded: file_helper
INFO - 2023-12-07 15:28:12 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:28:12 --> Form Validation Class Initialized
INFO - 2023-12-07 15:28:12 --> Upload Class Initialized
INFO - 2023-12-07 15:28:12 --> Model "M_auth" initialized
INFO - 2023-12-07 15:28:12 --> Model "M_user" initialized
INFO - 2023-12-07 15:28:12 --> Model "M_produk" initialized
INFO - 2023-12-07 15:28:12 --> Controller Class Initialized
INFO - 2023-12-07 15:28:12 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:28:12 --> Final output sent to browser
DEBUG - 2023-12-07 15:28:12 --> Total execution time: 0.0244
ERROR - 2023-12-07 15:28:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:28:20 --> Config Class Initialized
INFO - 2023-12-07 15:28:20 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:28:20 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:28:20 --> Utf8 Class Initialized
INFO - 2023-12-07 15:28:20 --> URI Class Initialized
INFO - 2023-12-07 15:28:20 --> Router Class Initialized
INFO - 2023-12-07 15:28:20 --> Output Class Initialized
INFO - 2023-12-07 15:28:20 --> Security Class Initialized
DEBUG - 2023-12-07 15:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:28:20 --> Input Class Initialized
INFO - 2023-12-07 15:28:20 --> Language Class Initialized
INFO - 2023-12-07 15:28:20 --> Loader Class Initialized
INFO - 2023-12-07 15:28:20 --> Helper loaded: url_helper
INFO - 2023-12-07 15:28:20 --> Helper loaded: form_helper
INFO - 2023-12-07 15:28:20 --> Helper loaded: file_helper
INFO - 2023-12-07 15:28:20 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:28:20 --> Form Validation Class Initialized
INFO - 2023-12-07 15:28:20 --> Upload Class Initialized
INFO - 2023-12-07 15:28:20 --> Model "M_auth" initialized
INFO - 2023-12-07 15:28:20 --> Model "M_user" initialized
INFO - 2023-12-07 15:28:20 --> Model "M_produk" initialized
INFO - 2023-12-07 15:28:20 --> Controller Class Initialized
INFO - 2023-12-07 15:28:20 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:28:20 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:28:20 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:28:20 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:28:20 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:28:20 --> Model "M_bank" initialized
INFO - 2023-12-07 15:28:20 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:28:20 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:28:21 --> Email Class Initialized
INFO - 2023-12-07 15:28:22 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-12-07 15:28:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:28:25 --> Config Class Initialized
INFO - 2023-12-07 15:28:25 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:28:25 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:28:25 --> Utf8 Class Initialized
INFO - 2023-12-07 15:28:25 --> URI Class Initialized
INFO - 2023-12-07 15:28:25 --> Router Class Initialized
INFO - 2023-12-07 15:28:25 --> Output Class Initialized
INFO - 2023-12-07 15:28:25 --> Security Class Initialized
DEBUG - 2023-12-07 15:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:28:25 --> Input Class Initialized
INFO - 2023-12-07 15:28:25 --> Language Class Initialized
INFO - 2023-12-07 15:28:25 --> Loader Class Initialized
INFO - 2023-12-07 15:28:25 --> Helper loaded: url_helper
INFO - 2023-12-07 15:28:25 --> Helper loaded: form_helper
INFO - 2023-12-07 15:28:25 --> Helper loaded: file_helper
INFO - 2023-12-07 15:28:25 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:28:25 --> Form Validation Class Initialized
INFO - 2023-12-07 15:28:25 --> Upload Class Initialized
INFO - 2023-12-07 15:28:25 --> Model "M_auth" initialized
INFO - 2023-12-07 15:28:25 --> Model "M_user" initialized
INFO - 2023-12-07 15:28:25 --> Model "M_produk" initialized
INFO - 2023-12-07 15:28:25 --> Controller Class Initialized
INFO - 2023-12-07 15:28:25 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:28:25 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:28:25 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:28:25 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:28:25 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:28:25 --> Model "M_bank" initialized
INFO - 2023-12-07 15:28:25 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:28:25 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:28:25 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:28:25 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:28:25 --> Final output sent to browser
DEBUG - 2023-12-07 15:28:25 --> Total execution time: 0.4446
ERROR - 2023-12-07 15:28:26 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:28:26 --> Config Class Initialized
INFO - 2023-12-07 15:28:26 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:28:26 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:28:26 --> Utf8 Class Initialized
INFO - 2023-12-07 15:28:26 --> URI Class Initialized
INFO - 2023-12-07 15:28:26 --> Router Class Initialized
INFO - 2023-12-07 15:28:26 --> Output Class Initialized
INFO - 2023-12-07 15:28:26 --> Security Class Initialized
DEBUG - 2023-12-07 15:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:28:26 --> Input Class Initialized
INFO - 2023-12-07 15:28:26 --> Language Class Initialized
INFO - 2023-12-07 15:28:26 --> Loader Class Initialized
INFO - 2023-12-07 15:28:26 --> Helper loaded: url_helper
INFO - 2023-12-07 15:28:26 --> Helper loaded: form_helper
INFO - 2023-12-07 15:28:26 --> Helper loaded: file_helper
INFO - 2023-12-07 15:28:26 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:28:26 --> Form Validation Class Initialized
INFO - 2023-12-07 15:28:26 --> Upload Class Initialized
INFO - 2023-12-07 15:28:26 --> Model "M_auth" initialized
INFO - 2023-12-07 15:28:26 --> Model "M_user" initialized
INFO - 2023-12-07 15:28:26 --> Model "M_produk" initialized
INFO - 2023-12-07 15:28:26 --> Controller Class Initialized
INFO - 2023-12-07 15:28:26 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:28:26 --> Final output sent to browser
DEBUG - 2023-12-07 15:28:26 --> Total execution time: 0.0255
ERROR - 2023-12-07 15:28:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:28:29 --> Config Class Initialized
INFO - 2023-12-07 15:28:29 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:28:29 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:28:29 --> Utf8 Class Initialized
INFO - 2023-12-07 15:28:29 --> URI Class Initialized
INFO - 2023-12-07 15:28:29 --> Router Class Initialized
INFO - 2023-12-07 15:28:29 --> Output Class Initialized
INFO - 2023-12-07 15:28:29 --> Security Class Initialized
DEBUG - 2023-12-07 15:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:28:29 --> Input Class Initialized
INFO - 2023-12-07 15:28:29 --> Language Class Initialized
INFO - 2023-12-07 15:28:29 --> Loader Class Initialized
INFO - 2023-12-07 15:28:29 --> Helper loaded: url_helper
INFO - 2023-12-07 15:28:29 --> Helper loaded: form_helper
INFO - 2023-12-07 15:28:29 --> Helper loaded: file_helper
INFO - 2023-12-07 15:28:29 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:28:29 --> Form Validation Class Initialized
INFO - 2023-12-07 15:28:29 --> Upload Class Initialized
INFO - 2023-12-07 15:28:29 --> Model "M_auth" initialized
INFO - 2023-12-07 15:28:29 --> Model "M_user" initialized
INFO - 2023-12-07 15:28:29 --> Model "M_produk" initialized
INFO - 2023-12-07 15:28:29 --> Controller Class Initialized
INFO - 2023-12-07 15:28:29 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:28:29 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:28:29 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:28:29 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:28:29 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:28:29 --> Model "M_bank" initialized
INFO - 2023-12-07 15:28:29 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:28:29 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
ERROR - 2023-12-07 15:28:29 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:28:29 --> Config Class Initialized
INFO - 2023-12-07 15:28:29 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:28:29 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:28:29 --> Utf8 Class Initialized
INFO - 2023-12-07 15:28:29 --> URI Class Initialized
INFO - 2023-12-07 15:28:29 --> Router Class Initialized
INFO - 2023-12-07 15:28:29 --> Output Class Initialized
INFO - 2023-12-07 15:28:29 --> Security Class Initialized
DEBUG - 2023-12-07 15:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:28:29 --> Input Class Initialized
INFO - 2023-12-07 15:28:29 --> Language Class Initialized
INFO - 2023-12-07 15:28:29 --> Loader Class Initialized
INFO - 2023-12-07 15:28:29 --> Helper loaded: url_helper
INFO - 2023-12-07 15:28:29 --> Helper loaded: form_helper
INFO - 2023-12-07 15:28:29 --> Helper loaded: file_helper
INFO - 2023-12-07 15:28:29 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:28:29 --> Form Validation Class Initialized
INFO - 2023-12-07 15:28:29 --> Upload Class Initialized
INFO - 2023-12-07 15:28:29 --> Model "M_auth" initialized
INFO - 2023-12-07 15:28:29 --> Model "M_user" initialized
INFO - 2023-12-07 15:28:29 --> Model "M_produk" initialized
INFO - 2023-12-07 15:28:29 --> Controller Class Initialized
INFO - 2023-12-07 15:28:29 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:28:29 --> Final output sent to browser
DEBUG - 2023-12-07 15:28:29 --> Total execution time: 0.0569
ERROR - 2023-12-07 15:28:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:28:43 --> Config Class Initialized
INFO - 2023-12-07 15:28:43 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:28:43 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:28:43 --> Utf8 Class Initialized
INFO - 2023-12-07 15:28:43 --> URI Class Initialized
DEBUG - 2023-12-07 15:28:43 --> No URI present. Default controller set.
INFO - 2023-12-07 15:28:43 --> Router Class Initialized
INFO - 2023-12-07 15:28:43 --> Output Class Initialized
INFO - 2023-12-07 15:28:43 --> Security Class Initialized
DEBUG - 2023-12-07 15:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:28:43 --> Input Class Initialized
INFO - 2023-12-07 15:28:43 --> Language Class Initialized
INFO - 2023-12-07 15:28:43 --> Loader Class Initialized
INFO - 2023-12-07 15:28:43 --> Helper loaded: url_helper
INFO - 2023-12-07 15:28:43 --> Helper loaded: form_helper
INFO - 2023-12-07 15:28:43 --> Helper loaded: file_helper
INFO - 2023-12-07 15:28:43 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:28:43 --> Form Validation Class Initialized
INFO - 2023-12-07 15:28:43 --> Upload Class Initialized
INFO - 2023-12-07 15:28:43 --> Model "M_auth" initialized
INFO - 2023-12-07 15:28:43 --> Model "M_user" initialized
INFO - 2023-12-07 15:28:43 --> Model "M_produk" initialized
INFO - 2023-12-07 15:28:43 --> Controller Class Initialized
INFO - 2023-12-07 15:28:43 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:28:43 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:28:43 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:28:43 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:28:43 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:28:43 --> Model "M_bank" initialized
INFO - 2023-12-07 15:28:43 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:28:43 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:28:43 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:28:43 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/index.php
INFO - 2023-12-07 15:28:43 --> Final output sent to browser
DEBUG - 2023-12-07 15:28:43 --> Total execution time: 0.0746
ERROR - 2023-12-07 15:28:43 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:28:43 --> Config Class Initialized
INFO - 2023-12-07 15:28:43 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:28:43 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:28:43 --> Utf8 Class Initialized
INFO - 2023-12-07 15:28:43 --> URI Class Initialized
INFO - 2023-12-07 15:28:43 --> Router Class Initialized
INFO - 2023-12-07 15:28:43 --> Output Class Initialized
INFO - 2023-12-07 15:28:43 --> Security Class Initialized
DEBUG - 2023-12-07 15:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:28:43 --> Input Class Initialized
INFO - 2023-12-07 15:28:43 --> Language Class Initialized
INFO - 2023-12-07 15:28:43 --> Loader Class Initialized
INFO - 2023-12-07 15:28:43 --> Helper loaded: url_helper
INFO - 2023-12-07 15:28:43 --> Helper loaded: form_helper
INFO - 2023-12-07 15:28:43 --> Helper loaded: file_helper
INFO - 2023-12-07 15:28:43 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:28:43 --> Form Validation Class Initialized
INFO - 2023-12-07 15:28:43 --> Upload Class Initialized
INFO - 2023-12-07 15:28:43 --> Model "M_auth" initialized
INFO - 2023-12-07 15:28:43 --> Model "M_user" initialized
INFO - 2023-12-07 15:28:43 --> Model "M_produk" initialized
INFO - 2023-12-07 15:28:43 --> Controller Class Initialized
INFO - 2023-12-07 15:28:43 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:28:43 --> Final output sent to browser
DEBUG - 2023-12-07 15:28:43 --> Total execution time: 0.0283
ERROR - 2023-12-07 15:28:56 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:28:56 --> Config Class Initialized
INFO - 2023-12-07 15:28:56 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:28:56 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:28:56 --> Utf8 Class Initialized
INFO - 2023-12-07 15:28:56 --> URI Class Initialized
INFO - 2023-12-07 15:28:56 --> Router Class Initialized
INFO - 2023-12-07 15:28:56 --> Output Class Initialized
INFO - 2023-12-07 15:28:56 --> Security Class Initialized
DEBUG - 2023-12-07 15:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:28:56 --> Input Class Initialized
INFO - 2023-12-07 15:28:56 --> Language Class Initialized
INFO - 2023-12-07 15:28:56 --> Loader Class Initialized
INFO - 2023-12-07 15:28:56 --> Helper loaded: url_helper
INFO - 2023-12-07 15:28:56 --> Helper loaded: form_helper
INFO - 2023-12-07 15:28:56 --> Helper loaded: file_helper
INFO - 2023-12-07 15:28:56 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:28:56 --> Form Validation Class Initialized
INFO - 2023-12-07 15:28:56 --> Upload Class Initialized
INFO - 2023-12-07 15:28:56 --> Model "M_auth" initialized
INFO - 2023-12-07 15:28:56 --> Model "M_user" initialized
INFO - 2023-12-07 15:28:56 --> Model "M_produk" initialized
INFO - 2023-12-07 15:28:56 --> Controller Class Initialized
INFO - 2023-12-07 15:28:56 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:28:56 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:28:56 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:28:56 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:28:56 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:28:56 --> Model "M_bank" initialized
INFO - 2023-12-07 15:28:56 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:28:56 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:28:57 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:28:57 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:28:57 --> Final output sent to browser
DEBUG - 2023-12-07 15:28:57 --> Total execution time: 0.4069
ERROR - 2023-12-07 15:28:57 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:28:57 --> Config Class Initialized
INFO - 2023-12-07 15:28:57 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:28:57 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:28:57 --> Utf8 Class Initialized
INFO - 2023-12-07 15:28:57 --> URI Class Initialized
INFO - 2023-12-07 15:28:57 --> Router Class Initialized
INFO - 2023-12-07 15:28:57 --> Output Class Initialized
INFO - 2023-12-07 15:28:57 --> Security Class Initialized
DEBUG - 2023-12-07 15:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:28:57 --> Input Class Initialized
INFO - 2023-12-07 15:28:57 --> Language Class Initialized
INFO - 2023-12-07 15:28:57 --> Loader Class Initialized
INFO - 2023-12-07 15:28:57 --> Helper loaded: url_helper
INFO - 2023-12-07 15:28:57 --> Helper loaded: form_helper
INFO - 2023-12-07 15:28:57 --> Helper loaded: file_helper
INFO - 2023-12-07 15:28:57 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:28:57 --> Form Validation Class Initialized
INFO - 2023-12-07 15:28:57 --> Upload Class Initialized
INFO - 2023-12-07 15:28:57 --> Model "M_auth" initialized
INFO - 2023-12-07 15:28:57 --> Model "M_user" initialized
INFO - 2023-12-07 15:28:57 --> Model "M_produk" initialized
INFO - 2023-12-07 15:28:57 --> Controller Class Initialized
INFO - 2023-12-07 15:28:57 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:28:57 --> Final output sent to browser
DEBUG - 2023-12-07 15:28:57 --> Total execution time: 0.0511
ERROR - 2023-12-07 15:29:08 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:29:08 --> Config Class Initialized
INFO - 2023-12-07 15:29:08 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:29:08 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:29:08 --> Utf8 Class Initialized
INFO - 2023-12-07 15:29:08 --> URI Class Initialized
DEBUG - 2023-12-07 15:29:08 --> No URI present. Default controller set.
INFO - 2023-12-07 15:29:08 --> Router Class Initialized
INFO - 2023-12-07 15:29:08 --> Output Class Initialized
INFO - 2023-12-07 15:29:08 --> Security Class Initialized
DEBUG - 2023-12-07 15:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:29:08 --> Input Class Initialized
INFO - 2023-12-07 15:29:08 --> Language Class Initialized
INFO - 2023-12-07 15:29:08 --> Loader Class Initialized
INFO - 2023-12-07 15:29:08 --> Helper loaded: url_helper
INFO - 2023-12-07 15:29:08 --> Helper loaded: form_helper
INFO - 2023-12-07 15:29:08 --> Helper loaded: file_helper
INFO - 2023-12-07 15:29:08 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:29:08 --> Form Validation Class Initialized
INFO - 2023-12-07 15:29:08 --> Upload Class Initialized
INFO - 2023-12-07 15:29:08 --> Model "M_auth" initialized
INFO - 2023-12-07 15:29:08 --> Model "M_user" initialized
INFO - 2023-12-07 15:29:08 --> Model "M_produk" initialized
INFO - 2023-12-07 15:29:08 --> Controller Class Initialized
INFO - 2023-12-07 15:29:08 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:29:08 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:29:08 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:29:08 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:29:08 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:29:08 --> Model "M_bank" initialized
INFO - 2023-12-07 15:29:08 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:29:08 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:29:08 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:29:08 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/index.php
INFO - 2023-12-07 15:29:08 --> Final output sent to browser
DEBUG - 2023-12-07 15:29:08 --> Total execution time: 0.1136
ERROR - 2023-12-07 15:29:09 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:29:09 --> Config Class Initialized
INFO - 2023-12-07 15:29:09 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:29:09 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:29:09 --> Utf8 Class Initialized
INFO - 2023-12-07 15:29:09 --> URI Class Initialized
INFO - 2023-12-07 15:29:09 --> Router Class Initialized
INFO - 2023-12-07 15:29:09 --> Output Class Initialized
INFO - 2023-12-07 15:29:09 --> Security Class Initialized
DEBUG - 2023-12-07 15:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:29:09 --> Input Class Initialized
INFO - 2023-12-07 15:29:09 --> Language Class Initialized
INFO - 2023-12-07 15:29:09 --> Loader Class Initialized
INFO - 2023-12-07 15:29:09 --> Helper loaded: url_helper
INFO - 2023-12-07 15:29:09 --> Helper loaded: form_helper
INFO - 2023-12-07 15:29:09 --> Helper loaded: file_helper
INFO - 2023-12-07 15:29:09 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:29:09 --> Form Validation Class Initialized
INFO - 2023-12-07 15:29:09 --> Upload Class Initialized
INFO - 2023-12-07 15:29:09 --> Model "M_auth" initialized
INFO - 2023-12-07 15:29:09 --> Model "M_user" initialized
INFO - 2023-12-07 15:29:09 --> Model "M_produk" initialized
INFO - 2023-12-07 15:29:09 --> Controller Class Initialized
INFO - 2023-12-07 15:29:09 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:29:09 --> Final output sent to browser
DEBUG - 2023-12-07 15:29:09 --> Total execution time: 0.0243
ERROR - 2023-12-07 15:29:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:29:11 --> Config Class Initialized
INFO - 2023-12-07 15:29:11 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:29:11 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:29:11 --> Utf8 Class Initialized
INFO - 2023-12-07 15:29:11 --> URI Class Initialized
INFO - 2023-12-07 15:29:11 --> Router Class Initialized
INFO - 2023-12-07 15:29:11 --> Output Class Initialized
INFO - 2023-12-07 15:29:11 --> Security Class Initialized
DEBUG - 2023-12-07 15:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:29:11 --> Input Class Initialized
INFO - 2023-12-07 15:29:11 --> Language Class Initialized
INFO - 2023-12-07 15:29:11 --> Loader Class Initialized
INFO - 2023-12-07 15:29:11 --> Helper loaded: url_helper
INFO - 2023-12-07 15:29:11 --> Helper loaded: form_helper
INFO - 2023-12-07 15:29:11 --> Helper loaded: file_helper
INFO - 2023-12-07 15:29:11 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:29:11 --> Form Validation Class Initialized
INFO - 2023-12-07 15:29:11 --> Upload Class Initialized
INFO - 2023-12-07 15:29:11 --> Model "M_auth" initialized
INFO - 2023-12-07 15:29:11 --> Model "M_user" initialized
INFO - 2023-12-07 15:29:11 --> Model "M_produk" initialized
INFO - 2023-12-07 15:29:11 --> Controller Class Initialized
INFO - 2023-12-07 15:29:11 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:29:11 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:29:11 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:29:11 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:29:11 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:29:11 --> Model "M_bank" initialized
INFO - 2023-12-07 15:29:11 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:29:11 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:29:11 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:29:11 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_produk_detail.php
INFO - 2023-12-07 15:29:11 --> Final output sent to browser
DEBUG - 2023-12-07 15:29:11 --> Total execution time: 0.0595
ERROR - 2023-12-07 15:29:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:29:12 --> Config Class Initialized
INFO - 2023-12-07 15:29:12 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:29:12 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:29:12 --> Utf8 Class Initialized
INFO - 2023-12-07 15:29:12 --> URI Class Initialized
INFO - 2023-12-07 15:29:12 --> Router Class Initialized
INFO - 2023-12-07 15:29:12 --> Output Class Initialized
INFO - 2023-12-07 15:29:12 --> Security Class Initialized
ERROR - 2023-12-07 15:29:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
DEBUG - 2023-12-07 15:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:29:12 --> Input Class Initialized
INFO - 2023-12-07 15:29:12 --> Language Class Initialized
INFO - 2023-12-07 15:29:12 --> Config Class Initialized
INFO - 2023-12-07 15:29:12 --> Loader Class Initialized
INFO - 2023-12-07 15:29:12 --> Hooks Class Initialized
INFO - 2023-12-07 15:29:12 --> Helper loaded: url_helper
INFO - 2023-12-07 15:29:12 --> Helper loaded: form_helper
INFO - 2023-12-07 15:29:12 --> Helper loaded: file_helper
DEBUG - 2023-12-07 15:29:12 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:29:12 --> Utf8 Class Initialized
INFO - 2023-12-07 15:29:12 --> URI Class Initialized
INFO - 2023-12-07 15:29:12 --> Router Class Initialized
INFO - 2023-12-07 15:29:12 --> Output Class Initialized
INFO - 2023-12-07 15:29:12 --> Database Driver Class Initialized
INFO - 2023-12-07 15:29:12 --> Security Class Initialized
DEBUG - 2023-12-07 15:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:29:12 --> Input Class Initialized
INFO - 2023-12-07 15:29:12 --> Language Class Initialized
DEBUG - 2023-12-07 15:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:29:12 --> Loader Class Initialized
INFO - 2023-12-07 15:29:12 --> Helper loaded: url_helper
INFO - 2023-12-07 15:29:12 --> Form Validation Class Initialized
INFO - 2023-12-07 15:29:12 --> Helper loaded: form_helper
INFO - 2023-12-07 15:29:12 --> Upload Class Initialized
INFO - 2023-12-07 15:29:12 --> Helper loaded: file_helper
INFO - 2023-12-07 15:29:12 --> Model "M_auth" initialized
INFO - 2023-12-07 15:29:12 --> Model "M_user" initialized
INFO - 2023-12-07 15:29:12 --> Model "M_produk" initialized
INFO - 2023-12-07 15:29:12 --> Controller Class Initialized
INFO - 2023-12-07 15:29:12 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:29:12 --> Final output sent to browser
DEBUG - 2023-12-07 15:29:12 --> Total execution time: 0.0293
INFO - 2023-12-07 15:29:12 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:29:12 --> Form Validation Class Initialized
INFO - 2023-12-07 15:29:12 --> Upload Class Initialized
INFO - 2023-12-07 15:29:12 --> Model "M_auth" initialized
INFO - 2023-12-07 15:29:12 --> Model "M_user" initialized
INFO - 2023-12-07 15:29:12 --> Model "M_produk" initialized
INFO - 2023-12-07 15:29:12 --> Controller Class Initialized
INFO - 2023-12-07 15:29:12 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:29:12 --> Final output sent to browser
DEBUG - 2023-12-07 15:29:12 --> Total execution time: 0.0337
ERROR - 2023-12-07 15:29:20 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:29:20 --> Config Class Initialized
INFO - 2023-12-07 15:29:20 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:29:20 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:29:20 --> Utf8 Class Initialized
INFO - 2023-12-07 15:29:20 --> URI Class Initialized
INFO - 2023-12-07 15:29:20 --> Router Class Initialized
INFO - 2023-12-07 15:29:20 --> Output Class Initialized
INFO - 2023-12-07 15:29:20 --> Security Class Initialized
DEBUG - 2023-12-07 15:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:29:20 --> Input Class Initialized
INFO - 2023-12-07 15:29:20 --> Language Class Initialized
INFO - 2023-12-07 15:29:20 --> Loader Class Initialized
INFO - 2023-12-07 15:29:20 --> Helper loaded: url_helper
INFO - 2023-12-07 15:29:20 --> Helper loaded: form_helper
INFO - 2023-12-07 15:29:20 --> Helper loaded: file_helper
INFO - 2023-12-07 15:29:20 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:29:20 --> Form Validation Class Initialized
INFO - 2023-12-07 15:29:20 --> Upload Class Initialized
INFO - 2023-12-07 15:29:20 --> Model "M_auth" initialized
INFO - 2023-12-07 15:29:20 --> Model "M_user" initialized
INFO - 2023-12-07 15:29:20 --> Model "M_produk" initialized
INFO - 2023-12-07 15:29:20 --> Controller Class Initialized
INFO - 2023-12-07 15:29:20 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:29:20 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:29:20 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:29:20 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:29:20 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:29:20 --> Model "M_bank" initialized
INFO - 2023-12-07 15:29:20 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:29:20 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:29:20 --> Email Class Initialized
INFO - 2023-12-07 15:29:21 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-12-07 15:29:24 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:29:24 --> Config Class Initialized
INFO - 2023-12-07 15:29:24 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:29:24 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:29:24 --> Utf8 Class Initialized
INFO - 2023-12-07 15:29:24 --> URI Class Initialized
INFO - 2023-12-07 15:29:24 --> Router Class Initialized
INFO - 2023-12-07 15:29:24 --> Output Class Initialized
INFO - 2023-12-07 15:29:24 --> Security Class Initialized
DEBUG - 2023-12-07 15:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:29:24 --> Input Class Initialized
INFO - 2023-12-07 15:29:24 --> Language Class Initialized
INFO - 2023-12-07 15:29:24 --> Loader Class Initialized
INFO - 2023-12-07 15:29:24 --> Helper loaded: url_helper
INFO - 2023-12-07 15:29:24 --> Helper loaded: form_helper
INFO - 2023-12-07 15:29:24 --> Helper loaded: file_helper
INFO - 2023-12-07 15:29:24 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:29:24 --> Form Validation Class Initialized
INFO - 2023-12-07 15:29:24 --> Upload Class Initialized
INFO - 2023-12-07 15:29:24 --> Model "M_auth" initialized
INFO - 2023-12-07 15:29:24 --> Model "M_user" initialized
INFO - 2023-12-07 15:29:24 --> Model "M_produk" initialized
INFO - 2023-12-07 15:29:24 --> Controller Class Initialized
INFO - 2023-12-07 15:29:24 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:29:24 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:29:24 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:29:24 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:29:24 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:29:24 --> Model "M_bank" initialized
INFO - 2023-12-07 15:29:24 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:29:24 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:29:24 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:29:24 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:29:24 --> Final output sent to browser
DEBUG - 2023-12-07 15:29:24 --> Total execution time: 0.3882
ERROR - 2023-12-07 15:29:25 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:29:25 --> Config Class Initialized
INFO - 2023-12-07 15:29:25 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:29:25 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:29:25 --> Utf8 Class Initialized
INFO - 2023-12-07 15:29:25 --> URI Class Initialized
INFO - 2023-12-07 15:29:25 --> Router Class Initialized
INFO - 2023-12-07 15:29:25 --> Output Class Initialized
INFO - 2023-12-07 15:29:25 --> Security Class Initialized
DEBUG - 2023-12-07 15:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:29:25 --> Input Class Initialized
INFO - 2023-12-07 15:29:25 --> Language Class Initialized
INFO - 2023-12-07 15:29:25 --> Loader Class Initialized
INFO - 2023-12-07 15:29:25 --> Helper loaded: url_helper
INFO - 2023-12-07 15:29:25 --> Helper loaded: form_helper
INFO - 2023-12-07 15:29:25 --> Helper loaded: file_helper
INFO - 2023-12-07 15:29:25 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:29:25 --> Form Validation Class Initialized
INFO - 2023-12-07 15:29:25 --> Upload Class Initialized
INFO - 2023-12-07 15:29:25 --> Model "M_auth" initialized
INFO - 2023-12-07 15:29:25 --> Model "M_user" initialized
INFO - 2023-12-07 15:29:25 --> Model "M_produk" initialized
INFO - 2023-12-07 15:29:25 --> Controller Class Initialized
INFO - 2023-12-07 15:29:25 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:29:25 --> Final output sent to browser
DEBUG - 2023-12-07 15:29:25 --> Total execution time: 0.0613
ERROR - 2023-12-07 15:29:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:29:52 --> Config Class Initialized
INFO - 2023-12-07 15:29:52 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:29:52 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:29:52 --> Utf8 Class Initialized
INFO - 2023-12-07 15:29:52 --> URI Class Initialized
INFO - 2023-12-07 15:29:52 --> Router Class Initialized
INFO - 2023-12-07 15:29:52 --> Output Class Initialized
INFO - 2023-12-07 15:29:52 --> Security Class Initialized
DEBUG - 2023-12-07 15:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:29:52 --> Input Class Initialized
INFO - 2023-12-07 15:29:52 --> Language Class Initialized
INFO - 2023-12-07 15:29:52 --> Loader Class Initialized
INFO - 2023-12-07 15:29:52 --> Helper loaded: url_helper
INFO - 2023-12-07 15:29:52 --> Helper loaded: form_helper
INFO - 2023-12-07 15:29:52 --> Helper loaded: file_helper
INFO - 2023-12-07 15:29:52 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:29:52 --> Form Validation Class Initialized
INFO - 2023-12-07 15:29:52 --> Upload Class Initialized
INFO - 2023-12-07 15:29:52 --> Model "M_auth" initialized
INFO - 2023-12-07 15:29:52 --> Model "M_user" initialized
INFO - 2023-12-07 15:29:52 --> Model "M_produk" initialized
INFO - 2023-12-07 15:29:52 --> Controller Class Initialized
INFO - 2023-12-07 15:29:52 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:29:52 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:29:52 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:29:52 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:29:52 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:29:52 --> Model "M_bank" initialized
INFO - 2023-12-07 15:29:52 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:29:52 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
ERROR - 2023-12-07 15:29:52 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:29:52 --> Config Class Initialized
INFO - 2023-12-07 15:29:52 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:29:52 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:29:52 --> Utf8 Class Initialized
INFO - 2023-12-07 15:29:52 --> URI Class Initialized
INFO - 2023-12-07 15:29:52 --> Router Class Initialized
INFO - 2023-12-07 15:29:52 --> Output Class Initialized
INFO - 2023-12-07 15:29:52 --> Security Class Initialized
DEBUG - 2023-12-07 15:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:29:52 --> Input Class Initialized
INFO - 2023-12-07 15:29:52 --> Language Class Initialized
INFO - 2023-12-07 15:29:52 --> Loader Class Initialized
INFO - 2023-12-07 15:29:52 --> Helper loaded: url_helper
INFO - 2023-12-07 15:29:52 --> Helper loaded: form_helper
INFO - 2023-12-07 15:29:52 --> Helper loaded: file_helper
INFO - 2023-12-07 15:29:52 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:29:52 --> Form Validation Class Initialized
INFO - 2023-12-07 15:29:52 --> Upload Class Initialized
INFO - 2023-12-07 15:29:52 --> Model "M_auth" initialized
INFO - 2023-12-07 15:29:52 --> Model "M_user" initialized
INFO - 2023-12-07 15:29:52 --> Model "M_produk" initialized
INFO - 2023-12-07 15:29:52 --> Controller Class Initialized
INFO - 2023-12-07 15:29:52 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:29:52 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:29:52 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:29:52 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:29:52 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:29:52 --> Model "M_bank" initialized
INFO - 2023-12-07 15:29:52 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:29:52 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:29:52 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:29:52 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/v_booking_saya.php
INFO - 2023-12-07 15:29:52 --> Final output sent to browser
DEBUG - 2023-12-07 15:29:52 --> Total execution time: 0.3152
ERROR - 2023-12-07 15:29:53 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:29:53 --> Config Class Initialized
INFO - 2023-12-07 15:29:53 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:29:53 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:29:53 --> Utf8 Class Initialized
INFO - 2023-12-07 15:29:53 --> URI Class Initialized
INFO - 2023-12-07 15:29:53 --> Router Class Initialized
INFO - 2023-12-07 15:29:53 --> Output Class Initialized
INFO - 2023-12-07 15:29:53 --> Security Class Initialized
DEBUG - 2023-12-07 15:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:29:53 --> Input Class Initialized
INFO - 2023-12-07 15:29:53 --> Language Class Initialized
INFO - 2023-12-07 15:29:53 --> Loader Class Initialized
INFO - 2023-12-07 15:29:53 --> Helper loaded: url_helper
INFO - 2023-12-07 15:29:53 --> Helper loaded: form_helper
INFO - 2023-12-07 15:29:53 --> Helper loaded: file_helper
INFO - 2023-12-07 15:29:53 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:29:53 --> Form Validation Class Initialized
INFO - 2023-12-07 15:29:53 --> Upload Class Initialized
INFO - 2023-12-07 15:29:53 --> Model "M_auth" initialized
INFO - 2023-12-07 15:29:53 --> Model "M_user" initialized
INFO - 2023-12-07 15:29:53 --> Model "M_produk" initialized
INFO - 2023-12-07 15:29:53 --> Controller Class Initialized
INFO - 2023-12-07 15:29:53 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:29:53 --> Final output sent to browser
DEBUG - 2023-12-07 15:29:53 --> Total execution time: 0.0357
ERROR - 2023-12-07 15:29:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:29:58 --> Config Class Initialized
INFO - 2023-12-07 15:29:58 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:29:58 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:29:58 --> Utf8 Class Initialized
INFO - 2023-12-07 15:29:58 --> URI Class Initialized
INFO - 2023-12-07 15:29:58 --> Router Class Initialized
INFO - 2023-12-07 15:29:58 --> Output Class Initialized
INFO - 2023-12-07 15:29:58 --> Security Class Initialized
DEBUG - 2023-12-07 15:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:29:58 --> Input Class Initialized
INFO - 2023-12-07 15:29:58 --> Language Class Initialized
INFO - 2023-12-07 15:29:58 --> Loader Class Initialized
INFO - 2023-12-07 15:29:58 --> Helper loaded: url_helper
INFO - 2023-12-07 15:29:58 --> Helper loaded: form_helper
INFO - 2023-12-07 15:29:58 --> Helper loaded: file_helper
INFO - 2023-12-07 15:29:58 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:29:58 --> Form Validation Class Initialized
INFO - 2023-12-07 15:29:58 --> Upload Class Initialized
INFO - 2023-12-07 15:29:58 --> Model "M_auth" initialized
INFO - 2023-12-07 15:29:58 --> Model "M_user" initialized
INFO - 2023-12-07 15:29:58 --> Model "M_produk" initialized
INFO - 2023-12-07 15:29:58 --> Controller Class Initialized
INFO - 2023-12-07 15:29:58 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:29:58 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:29:58 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:29:58 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:29:58 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:29:58 --> Model "M_bank" initialized
INFO - 2023-12-07 15:29:58 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:29:58 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
ERROR - 2023-12-07 15:29:58 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:29:58 --> Config Class Initialized
INFO - 2023-12-07 15:29:58 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:29:58 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:29:58 --> Utf8 Class Initialized
INFO - 2023-12-07 15:29:58 --> URI Class Initialized
DEBUG - 2023-12-07 15:29:58 --> No URI present. Default controller set.
INFO - 2023-12-07 15:29:58 --> Router Class Initialized
INFO - 2023-12-07 15:29:58 --> Output Class Initialized
INFO - 2023-12-07 15:29:58 --> Security Class Initialized
DEBUG - 2023-12-07 15:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:29:58 --> Input Class Initialized
INFO - 2023-12-07 15:29:58 --> Language Class Initialized
INFO - 2023-12-07 15:29:58 --> Loader Class Initialized
INFO - 2023-12-07 15:29:58 --> Helper loaded: url_helper
INFO - 2023-12-07 15:29:58 --> Helper loaded: form_helper
INFO - 2023-12-07 15:29:58 --> Helper loaded: file_helper
INFO - 2023-12-07 15:29:58 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:29:58 --> Form Validation Class Initialized
INFO - 2023-12-07 15:29:58 --> Upload Class Initialized
INFO - 2023-12-07 15:29:58 --> Model "M_auth" initialized
INFO - 2023-12-07 15:29:58 --> Model "M_user" initialized
INFO - 2023-12-07 15:29:58 --> Model "M_produk" initialized
INFO - 2023-12-07 15:29:58 --> Controller Class Initialized
INFO - 2023-12-07 15:29:58 --> Model "M_pelanggan" initialized
INFO - 2023-12-07 15:29:58 --> Model "M_produk" initialized
DEBUG - 2023-12-07 15:29:58 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-12-07 15:29:58 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-12-07 15:29:58 --> Model "M_transaksi" initialized
INFO - 2023-12-07 15:29:58 --> Model "M_bank" initialized
INFO - 2023-12-07 15:29:58 --> Model "M_pesan" initialized
DEBUG - 2023-12-07 15:29:58 --> Config file loaded: C:\xampp\htdocs\semakar_adventure_new\application\config/midtrans.php
INFO - 2023-12-07 15:29:58 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/footer.php
INFO - 2023-12-07 15:29:58 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/index.php
INFO - 2023-12-07 15:29:58 --> Final output sent to browser
DEBUG - 2023-12-07 15:29:58 --> Total execution time: 0.0543
ERROR - 2023-12-07 15:29:59 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:29:59 --> Config Class Initialized
INFO - 2023-12-07 15:29:59 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:29:59 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:29:59 --> Utf8 Class Initialized
INFO - 2023-12-07 15:29:59 --> URI Class Initialized
INFO - 2023-12-07 15:29:59 --> Router Class Initialized
INFO - 2023-12-07 15:29:59 --> Output Class Initialized
INFO - 2023-12-07 15:29:59 --> Security Class Initialized
DEBUG - 2023-12-07 15:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:29:59 --> Input Class Initialized
INFO - 2023-12-07 15:29:59 --> Language Class Initialized
INFO - 2023-12-07 15:29:59 --> Loader Class Initialized
INFO - 2023-12-07 15:29:59 --> Helper loaded: url_helper
INFO - 2023-12-07 15:29:59 --> Helper loaded: form_helper
INFO - 2023-12-07 15:29:59 --> Helper loaded: file_helper
INFO - 2023-12-07 15:29:59 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:29:59 --> Form Validation Class Initialized
INFO - 2023-12-07 15:29:59 --> Upload Class Initialized
INFO - 2023-12-07 15:29:59 --> Model "M_auth" initialized
INFO - 2023-12-07 15:29:59 --> Model "M_user" initialized
INFO - 2023-12-07 15:29:59 --> Model "M_produk" initialized
INFO - 2023-12-07 15:29:59 --> Controller Class Initialized
INFO - 2023-12-07 15:29:59 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\front/not_found.php
INFO - 2023-12-07 15:29:59 --> Final output sent to browser
DEBUG - 2023-12-07 15:29:59 --> Total execution time: 0.0341
ERROR - 2023-12-07 15:30:03 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:30:03 --> Config Class Initialized
INFO - 2023-12-07 15:30:03 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:30:03 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:30:03 --> Utf8 Class Initialized
INFO - 2023-12-07 15:30:03 --> URI Class Initialized
INFO - 2023-12-07 15:30:03 --> Router Class Initialized
INFO - 2023-12-07 15:30:03 --> Output Class Initialized
INFO - 2023-12-07 15:30:03 --> Security Class Initialized
DEBUG - 2023-12-07 15:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:30:03 --> Input Class Initialized
INFO - 2023-12-07 15:30:03 --> Language Class Initialized
INFO - 2023-12-07 15:30:03 --> Loader Class Initialized
INFO - 2023-12-07 15:30:03 --> Helper loaded: url_helper
INFO - 2023-12-07 15:30:03 --> Helper loaded: form_helper
INFO - 2023-12-07 15:30:03 --> Helper loaded: file_helper
INFO - 2023-12-07 15:30:03 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:30:03 --> Form Validation Class Initialized
INFO - 2023-12-07 15:30:03 --> Upload Class Initialized
INFO - 2023-12-07 15:30:03 --> Model "M_auth" initialized
INFO - 2023-12-07 15:30:03 --> Model "M_user" initialized
INFO - 2023-12-07 15:30:03 --> Model "M_produk" initialized
INFO - 2023-12-07 15:30:03 --> Controller Class Initialized
INFO - 2023-12-07 15:30:03 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\back/v_login.php
INFO - 2023-12-07 15:30:03 --> Final output sent to browser
DEBUG - 2023-12-07 15:30:03 --> Total execution time: 0.0798
ERROR - 2023-12-07 15:30:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:30:11 --> Config Class Initialized
INFO - 2023-12-07 15:30:11 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:30:11 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:30:11 --> Utf8 Class Initialized
INFO - 2023-12-07 15:30:11 --> URI Class Initialized
INFO - 2023-12-07 15:30:11 --> Router Class Initialized
INFO - 2023-12-07 15:30:11 --> Output Class Initialized
INFO - 2023-12-07 15:30:11 --> Security Class Initialized
DEBUG - 2023-12-07 15:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:30:11 --> Input Class Initialized
INFO - 2023-12-07 15:30:11 --> Language Class Initialized
INFO - 2023-12-07 15:30:11 --> Loader Class Initialized
INFO - 2023-12-07 15:30:11 --> Helper loaded: url_helper
INFO - 2023-12-07 15:30:11 --> Helper loaded: form_helper
INFO - 2023-12-07 15:30:11 --> Helper loaded: file_helper
INFO - 2023-12-07 15:30:11 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:30:11 --> Form Validation Class Initialized
INFO - 2023-12-07 15:30:11 --> Upload Class Initialized
INFO - 2023-12-07 15:30:11 --> Model "M_auth" initialized
INFO - 2023-12-07 15:30:11 --> Model "M_user" initialized
INFO - 2023-12-07 15:30:11 --> Model "M_produk" initialized
INFO - 2023-12-07 15:30:11 --> Controller Class Initialized
INFO - 2023-12-07 15:30:11 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2023-12-07 15:30:11 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:30:11 --> Config Class Initialized
INFO - 2023-12-07 15:30:11 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:30:11 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:30:11 --> Utf8 Class Initialized
INFO - 2023-12-07 15:30:11 --> URI Class Initialized
INFO - 2023-12-07 15:30:11 --> Router Class Initialized
INFO - 2023-12-07 15:30:11 --> Output Class Initialized
INFO - 2023-12-07 15:30:11 --> Security Class Initialized
DEBUG - 2023-12-07 15:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:30:11 --> Input Class Initialized
INFO - 2023-12-07 15:30:11 --> Language Class Initialized
INFO - 2023-12-07 15:30:11 --> Loader Class Initialized
INFO - 2023-12-07 15:30:11 --> Helper loaded: url_helper
INFO - 2023-12-07 15:30:11 --> Helper loaded: form_helper
INFO - 2023-12-07 15:30:11 --> Helper loaded: file_helper
INFO - 2023-12-07 15:30:11 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:30:11 --> Form Validation Class Initialized
INFO - 2023-12-07 15:30:11 --> Upload Class Initialized
INFO - 2023-12-07 15:30:11 --> Model "M_auth" initialized
INFO - 2023-12-07 15:30:11 --> Model "M_user" initialized
INFO - 2023-12-07 15:30:11 --> Model "M_produk" initialized
INFO - 2023-12-07 15:30:11 --> Controller Class Initialized
INFO - 2023-12-07 15:30:11 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\back/v_dashboard.php
INFO - 2023-12-07 15:30:11 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\back/v_wrapper.php
INFO - 2023-12-07 15:30:11 --> Final output sent to browser
DEBUG - 2023-12-07 15:30:11 --> Total execution time: 0.0515
ERROR - 2023-12-07 15:31:12 --> $config['composer_autoload'] is set to TRUE but C:\xampp\htdocs\semakar_adventure_new\application\vendor/autoload.php was not found.
INFO - 2023-12-07 15:31:12 --> Config Class Initialized
INFO - 2023-12-07 15:31:12 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:31:12 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:31:12 --> Utf8 Class Initialized
INFO - 2023-12-07 15:31:12 --> URI Class Initialized
INFO - 2023-12-07 15:31:12 --> Router Class Initialized
INFO - 2023-12-07 15:31:12 --> Output Class Initialized
INFO - 2023-12-07 15:31:12 --> Security Class Initialized
DEBUG - 2023-12-07 15:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:31:12 --> Input Class Initialized
INFO - 2023-12-07 15:31:12 --> Language Class Initialized
INFO - 2023-12-07 15:31:12 --> Loader Class Initialized
INFO - 2023-12-07 15:31:12 --> Helper loaded: url_helper
INFO - 2023-12-07 15:31:12 --> Helper loaded: form_helper
INFO - 2023-12-07 15:31:12 --> Helper loaded: file_helper
INFO - 2023-12-07 15:31:12 --> Database Driver Class Initialized
DEBUG - 2023-12-07 15:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-12-07 15:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:31:12 --> Form Validation Class Initialized
INFO - 2023-12-07 15:31:12 --> Upload Class Initialized
INFO - 2023-12-07 15:31:12 --> Model "M_auth" initialized
INFO - 2023-12-07 15:31:12 --> Model "M_user" initialized
INFO - 2023-12-07 15:31:12 --> Model "M_produk" initialized
INFO - 2023-12-07 15:31:12 --> Controller Class Initialized
INFO - 2023-12-07 15:31:12 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\back/v_dashboard.php
INFO - 2023-12-07 15:31:12 --> File loaded: C:\xampp\htdocs\semakar_adventure_new\application\views\back/v_wrapper.php
INFO - 2023-12-07 15:31:12 --> Final output sent to browser
DEBUG - 2023-12-07 15:31:12 --> Total execution time: 0.0347
