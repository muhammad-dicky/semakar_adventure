<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-30 22:36:24 --> Config Class Initialized
INFO - 2023-08-30 22:36:24 --> Hooks Class Initialized
DEBUG - 2023-08-30 22:36:24 --> UTF-8 Support Enabled
INFO - 2023-08-30 22:36:24 --> Utf8 Class Initialized
INFO - 2023-08-30 22:36:24 --> URI Class Initialized
DEBUG - 2023-08-30 22:36:24 --> No URI present. Default controller set.
INFO - 2023-08-30 22:36:24 --> Router Class Initialized
INFO - 2023-08-30 22:36:24 --> Output Class Initialized
INFO - 2023-08-30 22:36:25 --> Security Class Initialized
DEBUG - 2023-08-30 22:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-30 22:36:25 --> Input Class Initialized
INFO - 2023-08-30 22:36:25 --> Language Class Initialized
INFO - 2023-08-30 22:36:25 --> Loader Class Initialized
INFO - 2023-08-30 22:36:25 --> Helper loaded: url_helper
INFO - 2023-08-30 22:36:25 --> Helper loaded: form_helper
INFO - 2023-08-30 22:36:25 --> Helper loaded: file_helper
INFO - 2023-08-30 22:36:25 --> Database Driver Class Initialized
DEBUG - 2023-08-30 22:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-30 22:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-30 22:36:25 --> Form Validation Class Initialized
INFO - 2023-08-30 22:36:25 --> Upload Class Initialized
INFO - 2023-08-30 22:36:25 --> Model "M_auth" initialized
INFO - 2023-08-30 22:36:26 --> Model "M_user" initialized
INFO - 2023-08-30 22:36:26 --> Model "M_produk" initialized
INFO - 2023-08-30 22:36:26 --> Controller Class Initialized
INFO - 2023-08-30 22:36:26 --> Model "M_pelanggan" initialized
INFO - 2023-08-30 22:36:26 --> Model "M_produk" initialized
DEBUG - 2023-08-30 22:36:26 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-08-30 22:36:26 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-08-30 22:36:26 --> Model "M_transaksi" initialized
INFO - 2023-08-30 22:36:26 --> Model "M_bank" initialized
INFO - 2023-08-30 22:36:26 --> Model "M_pesan" initialized
INFO - 2023-08-30 22:36:26 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/footer.php
INFO - 2023-08-30 22:36:26 --> File loaded: C:\xampp\htdocs\4_aan\semakar_adventure\application\views\front/index.php
INFO - 2023-08-30 22:36:26 --> Final output sent to browser
DEBUG - 2023-08-30 22:36:26 --> Total execution time: 2.1602
