<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-12 00:22:07 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-12 00:22:07 --> Config Class Initialized
INFO - 2023-11-12 00:22:07 --> Hooks Class Initialized
DEBUG - 2023-11-12 00:22:07 --> UTF-8 Support Enabled
INFO - 2023-11-12 00:22:07 --> Utf8 Class Initialized
INFO - 2023-11-12 00:22:07 --> URI Class Initialized
DEBUG - 2023-11-12 00:22:07 --> No URI present. Default controller set.
INFO - 2023-11-12 00:22:07 --> Router Class Initialized
INFO - 2023-11-12 00:22:07 --> Output Class Initialized
INFO - 2023-11-12 00:22:07 --> Security Class Initialized
DEBUG - 2023-11-12 00:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-12 00:22:07 --> Input Class Initialized
INFO - 2023-11-12 00:22:07 --> Language Class Initialized
INFO - 2023-11-12 00:22:07 --> Loader Class Initialized
INFO - 2023-11-12 00:22:07 --> Helper loaded: url_helper
INFO - 2023-11-12 00:22:07 --> Helper loaded: form_helper
INFO - 2023-11-12 00:22:07 --> Helper loaded: file_helper
INFO - 2023-11-12 00:22:07 --> Database Driver Class Initialized
DEBUG - 2023-11-12 00:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-12 00:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-12 00:22:07 --> Form Validation Class Initialized
INFO - 2023-11-12 00:22:07 --> Upload Class Initialized
INFO - 2023-11-12 00:22:07 --> Model "M_auth" initialized
INFO - 2023-11-12 00:22:07 --> Model "M_user" initialized
INFO - 2023-11-12 00:22:07 --> Model "M_produk" initialized
INFO - 2023-11-12 00:22:07 --> Controller Class Initialized
INFO - 2023-11-12 00:22:07 --> Model "M_pelanggan" initialized
INFO - 2023-11-12 00:22:07 --> Model "M_produk" initialized
DEBUG - 2023-11-12 00:22:07 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-12 00:22:07 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-12 00:22:07 --> Model "M_transaksi" initialized
INFO - 2023-11-12 00:22:07 --> Model "M_bank" initialized
INFO - 2023-11-12 00:22:07 --> Model "M_pesan" initialized
DEBUG - 2023-11-12 00:22:07 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-12 00:22:07 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-12 00:22:07 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-12 00:22:07 --> Final output sent to browser
DEBUG - 2023-11-12 00:22:07 --> Total execution time: 0.0419
ERROR - 2023-11-12 00:22:10 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-12 00:22:10 --> Config Class Initialized
INFO - 2023-11-12 00:22:10 --> Hooks Class Initialized
DEBUG - 2023-11-12 00:22:10 --> UTF-8 Support Enabled
INFO - 2023-11-12 00:22:10 --> Utf8 Class Initialized
INFO - 2023-11-12 00:22:10 --> URI Class Initialized
DEBUG - 2023-11-12 00:22:10 --> No URI present. Default controller set.
INFO - 2023-11-12 00:22:10 --> Router Class Initialized
INFO - 2023-11-12 00:22:10 --> Output Class Initialized
INFO - 2023-11-12 00:22:10 --> Security Class Initialized
DEBUG - 2023-11-12 00:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-12 00:22:10 --> Input Class Initialized
INFO - 2023-11-12 00:22:10 --> Language Class Initialized
INFO - 2023-11-12 00:22:10 --> Loader Class Initialized
INFO - 2023-11-12 00:22:10 --> Helper loaded: url_helper
INFO - 2023-11-12 00:22:10 --> Helper loaded: form_helper
INFO - 2023-11-12 00:22:10 --> Helper loaded: file_helper
INFO - 2023-11-12 00:22:10 --> Database Driver Class Initialized
DEBUG - 2023-11-12 00:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-12 00:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-12 00:22:10 --> Form Validation Class Initialized
INFO - 2023-11-12 00:22:10 --> Upload Class Initialized
INFO - 2023-11-12 00:22:10 --> Model "M_auth" initialized
INFO - 2023-11-12 00:22:10 --> Model "M_user" initialized
INFO - 2023-11-12 00:22:10 --> Model "M_produk" initialized
INFO - 2023-11-12 00:22:10 --> Controller Class Initialized
INFO - 2023-11-12 00:22:10 --> Model "M_pelanggan" initialized
INFO - 2023-11-12 00:22:10 --> Model "M_produk" initialized
DEBUG - 2023-11-12 00:22:10 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-12 00:22:10 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-12 00:22:10 --> Model "M_transaksi" initialized
INFO - 2023-11-12 00:22:10 --> Model "M_bank" initialized
INFO - 2023-11-12 00:22:10 --> Model "M_pesan" initialized
DEBUG - 2023-11-12 00:22:10 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-12 00:22:10 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-12 00:22:10 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-12 00:22:10 --> Final output sent to browser
DEBUG - 2023-11-12 00:22:10 --> Total execution time: 0.0036
ERROR - 2023-11-12 01:22:52 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-12 01:22:52 --> Config Class Initialized
INFO - 2023-11-12 01:22:52 --> Hooks Class Initialized
DEBUG - 2023-11-12 01:22:52 --> UTF-8 Support Enabled
INFO - 2023-11-12 01:22:52 --> Utf8 Class Initialized
INFO - 2023-11-12 01:22:52 --> URI Class Initialized
DEBUG - 2023-11-12 01:22:52 --> No URI present. Default controller set.
INFO - 2023-11-12 01:22:52 --> Router Class Initialized
INFO - 2023-11-12 01:22:52 --> Output Class Initialized
INFO - 2023-11-12 01:22:52 --> Security Class Initialized
DEBUG - 2023-11-12 01:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-12 01:22:52 --> Input Class Initialized
INFO - 2023-11-12 01:22:52 --> Language Class Initialized
INFO - 2023-11-12 01:22:52 --> Loader Class Initialized
INFO - 2023-11-12 01:22:52 --> Helper loaded: url_helper
INFO - 2023-11-12 01:22:52 --> Helper loaded: form_helper
INFO - 2023-11-12 01:22:52 --> Helper loaded: file_helper
INFO - 2023-11-12 01:22:52 --> Database Driver Class Initialized
DEBUG - 2023-11-12 01:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-12 01:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-12 01:22:52 --> Form Validation Class Initialized
INFO - 2023-11-12 01:22:52 --> Upload Class Initialized
INFO - 2023-11-12 01:22:52 --> Model "M_auth" initialized
INFO - 2023-11-12 01:22:52 --> Model "M_user" initialized
INFO - 2023-11-12 01:22:52 --> Model "M_produk" initialized
INFO - 2023-11-12 01:22:52 --> Controller Class Initialized
INFO - 2023-11-12 01:22:52 --> Model "M_pelanggan" initialized
INFO - 2023-11-12 01:22:52 --> Model "M_produk" initialized
DEBUG - 2023-11-12 01:22:52 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-12 01:22:52 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-12 01:22:52 --> Model "M_transaksi" initialized
INFO - 2023-11-12 01:22:52 --> Model "M_bank" initialized
INFO - 2023-11-12 01:22:52 --> Model "M_pesan" initialized
DEBUG - 2023-11-12 01:22:52 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-12 01:22:52 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-12 01:22:52 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-12 01:22:52 --> Final output sent to browser
DEBUG - 2023-11-12 01:22:52 --> Total execution time: 0.0445
ERROR - 2023-11-12 03:16:15 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-12 03:16:15 --> Config Class Initialized
INFO - 2023-11-12 03:16:15 --> Hooks Class Initialized
DEBUG - 2023-11-12 03:16:15 --> UTF-8 Support Enabled
INFO - 2023-11-12 03:16:15 --> Utf8 Class Initialized
INFO - 2023-11-12 03:16:15 --> URI Class Initialized
DEBUG - 2023-11-12 03:16:15 --> No URI present. Default controller set.
INFO - 2023-11-12 03:16:15 --> Router Class Initialized
INFO - 2023-11-12 03:16:15 --> Output Class Initialized
INFO - 2023-11-12 03:16:15 --> Security Class Initialized
DEBUG - 2023-11-12 03:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-12 03:16:15 --> Input Class Initialized
INFO - 2023-11-12 03:16:15 --> Language Class Initialized
INFO - 2023-11-12 03:16:15 --> Loader Class Initialized
INFO - 2023-11-12 03:16:15 --> Helper loaded: url_helper
INFO - 2023-11-12 03:16:15 --> Helper loaded: form_helper
INFO - 2023-11-12 03:16:15 --> Helper loaded: file_helper
INFO - 2023-11-12 03:16:15 --> Database Driver Class Initialized
DEBUG - 2023-11-12 03:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-12 03:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-12 03:16:15 --> Form Validation Class Initialized
INFO - 2023-11-12 03:16:15 --> Upload Class Initialized
INFO - 2023-11-12 03:16:15 --> Model "M_auth" initialized
INFO - 2023-11-12 03:16:15 --> Model "M_user" initialized
INFO - 2023-11-12 03:16:15 --> Model "M_produk" initialized
INFO - 2023-11-12 03:16:15 --> Controller Class Initialized
INFO - 2023-11-12 03:16:15 --> Model "M_pelanggan" initialized
INFO - 2023-11-12 03:16:15 --> Model "M_produk" initialized
DEBUG - 2023-11-12 03:16:15 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-12 03:16:15 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-12 03:16:15 --> Model "M_transaksi" initialized
INFO - 2023-11-12 03:16:15 --> Model "M_bank" initialized
INFO - 2023-11-12 03:16:15 --> Model "M_pesan" initialized
DEBUG - 2023-11-12 03:16:15 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-12 03:16:15 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-12 03:16:15 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-12 03:16:15 --> Final output sent to browser
DEBUG - 2023-11-12 03:16:15 --> Total execution time: 0.0486
ERROR - 2023-11-12 05:50:17 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-12 05:50:17 --> Config Class Initialized
INFO - 2023-11-12 05:50:17 --> Hooks Class Initialized
DEBUG - 2023-11-12 05:50:17 --> UTF-8 Support Enabled
INFO - 2023-11-12 05:50:17 --> Utf8 Class Initialized
INFO - 2023-11-12 05:50:17 --> URI Class Initialized
INFO - 2023-11-12 05:50:17 --> Router Class Initialized
INFO - 2023-11-12 05:50:17 --> Output Class Initialized
INFO - 2023-11-12 05:50:17 --> Security Class Initialized
DEBUG - 2023-11-12 05:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-12 05:50:17 --> Input Class Initialized
INFO - 2023-11-12 05:50:17 --> Language Class Initialized
INFO - 2023-11-12 05:50:17 --> Loader Class Initialized
INFO - 2023-11-12 05:50:17 --> Helper loaded: url_helper
INFO - 2023-11-12 05:50:17 --> Helper loaded: form_helper
INFO - 2023-11-12 05:50:17 --> Helper loaded: file_helper
INFO - 2023-11-12 05:50:17 --> Database Driver Class Initialized
DEBUG - 2023-11-12 05:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-12 05:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-12 05:50:17 --> Form Validation Class Initialized
INFO - 2023-11-12 05:50:17 --> Upload Class Initialized
INFO - 2023-11-12 05:50:17 --> Model "M_auth" initialized
INFO - 2023-11-12 05:50:17 --> Model "M_user" initialized
INFO - 2023-11-12 05:50:17 --> Model "M_produk" initialized
INFO - 2023-11-12 05:50:17 --> Controller Class Initialized
INFO - 2023-11-12 05:50:17 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-12 05:50:17 --> Final output sent to browser
DEBUG - 2023-11-12 05:50:17 --> Total execution time: 0.0406
ERROR - 2023-11-12 05:50:19 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-12 05:50:19 --> Config Class Initialized
INFO - 2023-11-12 05:50:19 --> Hooks Class Initialized
DEBUG - 2023-11-12 05:50:19 --> UTF-8 Support Enabled
INFO - 2023-11-12 05:50:19 --> Utf8 Class Initialized
INFO - 2023-11-12 05:50:19 --> URI Class Initialized
DEBUG - 2023-11-12 05:50:19 --> No URI present. Default controller set.
INFO - 2023-11-12 05:50:19 --> Router Class Initialized
INFO - 2023-11-12 05:50:19 --> Output Class Initialized
INFO - 2023-11-12 05:50:19 --> Security Class Initialized
DEBUG - 2023-11-12 05:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-12 05:50:19 --> Input Class Initialized
INFO - 2023-11-12 05:50:19 --> Language Class Initialized
INFO - 2023-11-12 05:50:19 --> Loader Class Initialized
INFO - 2023-11-12 05:50:19 --> Helper loaded: url_helper
INFO - 2023-11-12 05:50:19 --> Helper loaded: form_helper
INFO - 2023-11-12 05:50:19 --> Helper loaded: file_helper
INFO - 2023-11-12 05:50:19 --> Database Driver Class Initialized
DEBUG - 2023-11-12 05:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-12 05:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-12 05:50:19 --> Form Validation Class Initialized
INFO - 2023-11-12 05:50:19 --> Upload Class Initialized
INFO - 2023-11-12 05:50:19 --> Model "M_auth" initialized
INFO - 2023-11-12 05:50:19 --> Model "M_user" initialized
INFO - 2023-11-12 05:50:19 --> Model "M_produk" initialized
INFO - 2023-11-12 05:50:19 --> Controller Class Initialized
INFO - 2023-11-12 05:50:19 --> Model "M_pelanggan" initialized
INFO - 2023-11-12 05:50:19 --> Model "M_produk" initialized
DEBUG - 2023-11-12 05:50:19 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-12 05:50:19 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-12 05:50:19 --> Model "M_transaksi" initialized
INFO - 2023-11-12 05:50:19 --> Model "M_bank" initialized
INFO - 2023-11-12 05:50:19 --> Model "M_pesan" initialized
DEBUG - 2023-11-12 05:50:19 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-12 05:50:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-12 05:50:19 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-12 05:50:19 --> Final output sent to browser
DEBUG - 2023-11-12 05:50:19 --> Total execution time: 0.0131
ERROR - 2023-11-12 07:10:57 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-12 07:10:57 --> Config Class Initialized
INFO - 2023-11-12 07:10:57 --> Hooks Class Initialized
DEBUG - 2023-11-12 07:10:57 --> UTF-8 Support Enabled
INFO - 2023-11-12 07:10:57 --> Utf8 Class Initialized
INFO - 2023-11-12 07:10:57 --> URI Class Initialized
INFO - 2023-11-12 07:10:57 --> Router Class Initialized
INFO - 2023-11-12 07:10:57 --> Output Class Initialized
INFO - 2023-11-12 07:10:57 --> Security Class Initialized
DEBUG - 2023-11-12 07:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-12 07:10:57 --> Input Class Initialized
INFO - 2023-11-12 07:10:57 --> Language Class Initialized
INFO - 2023-11-12 07:10:57 --> Loader Class Initialized
INFO - 2023-11-12 07:10:57 --> Helper loaded: url_helper
INFO - 2023-11-12 07:10:57 --> Helper loaded: form_helper
INFO - 2023-11-12 07:10:57 --> Helper loaded: file_helper
INFO - 2023-11-12 07:10:57 --> Database Driver Class Initialized
DEBUG - 2023-11-12 07:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-12 07:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-12 07:10:57 --> Form Validation Class Initialized
INFO - 2023-11-12 07:10:57 --> Upload Class Initialized
INFO - 2023-11-12 07:10:57 --> Model "M_auth" initialized
INFO - 2023-11-12 07:10:57 --> Model "M_user" initialized
INFO - 2023-11-12 07:10:57 --> Model "M_produk" initialized
INFO - 2023-11-12 07:10:57 --> Controller Class Initialized
INFO - 2023-11-12 07:10:57 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-12 07:10:57 --> Final output sent to browser
DEBUG - 2023-11-12 07:10:57 --> Total execution time: 0.0382
ERROR - 2023-11-12 07:10:59 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-12 07:10:59 --> Config Class Initialized
INFO - 2023-11-12 07:10:59 --> Hooks Class Initialized
DEBUG - 2023-11-12 07:10:59 --> UTF-8 Support Enabled
INFO - 2023-11-12 07:10:59 --> Utf8 Class Initialized
INFO - 2023-11-12 07:10:59 --> URI Class Initialized
DEBUG - 2023-11-12 07:10:59 --> No URI present. Default controller set.
INFO - 2023-11-12 07:10:59 --> Router Class Initialized
INFO - 2023-11-12 07:10:59 --> Output Class Initialized
INFO - 2023-11-12 07:10:59 --> Security Class Initialized
DEBUG - 2023-11-12 07:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-12 07:10:59 --> Input Class Initialized
INFO - 2023-11-12 07:10:59 --> Language Class Initialized
INFO - 2023-11-12 07:10:59 --> Loader Class Initialized
INFO - 2023-11-12 07:10:59 --> Helper loaded: url_helper
INFO - 2023-11-12 07:10:59 --> Helper loaded: form_helper
INFO - 2023-11-12 07:10:59 --> Helper loaded: file_helper
INFO - 2023-11-12 07:10:59 --> Database Driver Class Initialized
DEBUG - 2023-11-12 07:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-12 07:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-12 07:10:59 --> Form Validation Class Initialized
INFO - 2023-11-12 07:10:59 --> Upload Class Initialized
INFO - 2023-11-12 07:10:59 --> Model "M_auth" initialized
INFO - 2023-11-12 07:10:59 --> Model "M_user" initialized
INFO - 2023-11-12 07:10:59 --> Model "M_produk" initialized
INFO - 2023-11-12 07:10:59 --> Controller Class Initialized
INFO - 2023-11-12 07:10:59 --> Model "M_pelanggan" initialized
INFO - 2023-11-12 07:10:59 --> Model "M_produk" initialized
DEBUG - 2023-11-12 07:10:59 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-12 07:10:59 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-12 07:10:59 --> Model "M_transaksi" initialized
INFO - 2023-11-12 07:10:59 --> Model "M_bank" initialized
INFO - 2023-11-12 07:10:59 --> Model "M_pesan" initialized
DEBUG - 2023-11-12 07:10:59 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-12 07:10:59 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-12 07:10:59 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-12 07:10:59 --> Final output sent to browser
DEBUG - 2023-11-12 07:10:59 --> Total execution time: 0.0111
ERROR - 2023-11-12 09:08:29 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-12 09:08:29 --> Config Class Initialized
INFO - 2023-11-12 09:08:29 --> Hooks Class Initialized
DEBUG - 2023-11-12 09:08:29 --> UTF-8 Support Enabled
INFO - 2023-11-12 09:08:29 --> Utf8 Class Initialized
INFO - 2023-11-12 09:08:29 --> URI Class Initialized
DEBUG - 2023-11-12 09:08:29 --> No URI present. Default controller set.
INFO - 2023-11-12 09:08:29 --> Router Class Initialized
INFO - 2023-11-12 09:08:29 --> Output Class Initialized
INFO - 2023-11-12 09:08:29 --> Security Class Initialized
DEBUG - 2023-11-12 09:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-12 09:08:29 --> Input Class Initialized
INFO - 2023-11-12 09:08:29 --> Language Class Initialized
INFO - 2023-11-12 09:08:29 --> Loader Class Initialized
INFO - 2023-11-12 09:08:29 --> Helper loaded: url_helper
INFO - 2023-11-12 09:08:29 --> Helper loaded: form_helper
INFO - 2023-11-12 09:08:29 --> Helper loaded: file_helper
INFO - 2023-11-12 09:08:29 --> Database Driver Class Initialized
DEBUG - 2023-11-12 09:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-12 09:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-12 09:08:29 --> Form Validation Class Initialized
INFO - 2023-11-12 09:08:29 --> Upload Class Initialized
INFO - 2023-11-12 09:08:29 --> Model "M_auth" initialized
INFO - 2023-11-12 09:08:29 --> Model "M_user" initialized
INFO - 2023-11-12 09:08:30 --> Model "M_produk" initialized
INFO - 2023-11-12 09:08:30 --> Controller Class Initialized
INFO - 2023-11-12 09:08:30 --> Model "M_pelanggan" initialized
INFO - 2023-11-12 09:08:30 --> Model "M_produk" initialized
DEBUG - 2023-11-12 09:08:30 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-12 09:08:30 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-12 09:08:30 --> Model "M_transaksi" initialized
INFO - 2023-11-12 09:08:30 --> Model "M_bank" initialized
INFO - 2023-11-12 09:08:30 --> Model "M_pesan" initialized
DEBUG - 2023-11-12 09:08:30 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-12 09:08:30 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-12 09:08:30 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-12 09:08:30 --> Final output sent to browser
DEBUG - 2023-11-12 09:08:30 --> Total execution time: 0.0456
ERROR - 2023-11-12 11:37:05 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-12 11:37:05 --> Config Class Initialized
INFO - 2023-11-12 11:37:05 --> Hooks Class Initialized
DEBUG - 2023-11-12 11:37:05 --> UTF-8 Support Enabled
INFO - 2023-11-12 11:37:05 --> Utf8 Class Initialized
INFO - 2023-11-12 11:37:05 --> URI Class Initialized
DEBUG - 2023-11-12 11:37:05 --> No URI present. Default controller set.
INFO - 2023-11-12 11:37:05 --> Router Class Initialized
INFO - 2023-11-12 11:37:05 --> Output Class Initialized
INFO - 2023-11-12 11:37:05 --> Security Class Initialized
DEBUG - 2023-11-12 11:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-12 11:37:05 --> Input Class Initialized
INFO - 2023-11-12 11:37:05 --> Language Class Initialized
INFO - 2023-11-12 11:37:05 --> Loader Class Initialized
INFO - 2023-11-12 11:37:05 --> Helper loaded: url_helper
INFO - 2023-11-12 11:37:05 --> Helper loaded: form_helper
INFO - 2023-11-12 11:37:05 --> Helper loaded: file_helper
INFO - 2023-11-12 11:37:05 --> Database Driver Class Initialized
DEBUG - 2023-11-12 11:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-12 11:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-12 11:37:05 --> Form Validation Class Initialized
INFO - 2023-11-12 11:37:05 --> Upload Class Initialized
INFO - 2023-11-12 11:37:05 --> Model "M_auth" initialized
INFO - 2023-11-12 11:37:05 --> Model "M_user" initialized
INFO - 2023-11-12 11:37:05 --> Model "M_produk" initialized
INFO - 2023-11-12 11:37:05 --> Controller Class Initialized
INFO - 2023-11-12 11:37:05 --> Model "M_pelanggan" initialized
INFO - 2023-11-12 11:37:05 --> Model "M_produk" initialized
DEBUG - 2023-11-12 11:37:05 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-12 11:37:05 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-12 11:37:05 --> Model "M_transaksi" initialized
INFO - 2023-11-12 11:37:05 --> Model "M_bank" initialized
INFO - 2023-11-12 11:37:05 --> Model "M_pesan" initialized
DEBUG - 2023-11-12 11:37:05 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-12 11:37:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-12 11:37:05 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-12 11:37:05 --> Final output sent to browser
DEBUG - 2023-11-12 11:37:05 --> Total execution time: 0.0485
ERROR - 2023-11-12 11:51:47 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-12 11:51:47 --> Config Class Initialized
INFO - 2023-11-12 11:51:47 --> Hooks Class Initialized
DEBUG - 2023-11-12 11:51:47 --> UTF-8 Support Enabled
INFO - 2023-11-12 11:51:47 --> Utf8 Class Initialized
INFO - 2023-11-12 11:51:47 --> URI Class Initialized
DEBUG - 2023-11-12 11:51:47 --> No URI present. Default controller set.
INFO - 2023-11-12 11:51:47 --> Router Class Initialized
INFO - 2023-11-12 11:51:47 --> Output Class Initialized
INFO - 2023-11-12 11:51:47 --> Security Class Initialized
DEBUG - 2023-11-12 11:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-12 11:51:47 --> Input Class Initialized
INFO - 2023-11-12 11:51:47 --> Language Class Initialized
INFO - 2023-11-12 11:51:47 --> Loader Class Initialized
INFO - 2023-11-12 11:51:47 --> Helper loaded: url_helper
INFO - 2023-11-12 11:51:47 --> Helper loaded: form_helper
INFO - 2023-11-12 11:51:47 --> Helper loaded: file_helper
INFO - 2023-11-12 11:51:47 --> Database Driver Class Initialized
DEBUG - 2023-11-12 11:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-12 11:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-12 11:51:47 --> Form Validation Class Initialized
INFO - 2023-11-12 11:51:47 --> Upload Class Initialized
INFO - 2023-11-12 11:51:47 --> Model "M_auth" initialized
INFO - 2023-11-12 11:51:47 --> Model "M_user" initialized
INFO - 2023-11-12 11:51:47 --> Model "M_produk" initialized
INFO - 2023-11-12 11:51:47 --> Controller Class Initialized
INFO - 2023-11-12 11:51:47 --> Model "M_pelanggan" initialized
INFO - 2023-11-12 11:51:47 --> Model "M_produk" initialized
DEBUG - 2023-11-12 11:51:47 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-12 11:51:47 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-12 11:51:47 --> Model "M_transaksi" initialized
INFO - 2023-11-12 11:51:47 --> Model "M_bank" initialized
INFO - 2023-11-12 11:51:47 --> Model "M_pesan" initialized
DEBUG - 2023-11-12 11:51:47 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-12 11:51:47 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-12 11:51:47 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-12 11:51:47 --> Final output sent to browser
DEBUG - 2023-11-12 11:51:47 --> Total execution time: 0.0317
ERROR - 2023-11-12 12:14:44 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-12 12:14:44 --> Config Class Initialized
INFO - 2023-11-12 12:14:44 --> Hooks Class Initialized
DEBUG - 2023-11-12 12:14:44 --> UTF-8 Support Enabled
INFO - 2023-11-12 12:14:44 --> Utf8 Class Initialized
INFO - 2023-11-12 12:14:44 --> URI Class Initialized
DEBUG - 2023-11-12 12:14:44 --> No URI present. Default controller set.
INFO - 2023-11-12 12:14:44 --> Router Class Initialized
INFO - 2023-11-12 12:14:44 --> Output Class Initialized
INFO - 2023-11-12 12:14:44 --> Security Class Initialized
DEBUG - 2023-11-12 12:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-12 12:14:44 --> Input Class Initialized
INFO - 2023-11-12 12:14:44 --> Language Class Initialized
INFO - 2023-11-12 12:14:44 --> Loader Class Initialized
INFO - 2023-11-12 12:14:44 --> Helper loaded: url_helper
INFO - 2023-11-12 12:14:44 --> Helper loaded: form_helper
INFO - 2023-11-12 12:14:44 --> Helper loaded: file_helper
INFO - 2023-11-12 12:14:44 --> Database Driver Class Initialized
DEBUG - 2023-11-12 12:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-12 12:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-12 12:14:44 --> Form Validation Class Initialized
INFO - 2023-11-12 12:14:44 --> Upload Class Initialized
INFO - 2023-11-12 12:14:44 --> Model "M_auth" initialized
INFO - 2023-11-12 12:14:44 --> Model "M_user" initialized
INFO - 2023-11-12 12:14:44 --> Model "M_produk" initialized
INFO - 2023-11-12 12:14:44 --> Controller Class Initialized
INFO - 2023-11-12 12:14:44 --> Model "M_pelanggan" initialized
INFO - 2023-11-12 12:14:44 --> Model "M_produk" initialized
DEBUG - 2023-11-12 12:14:44 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-12 12:14:44 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-12 12:14:44 --> Model "M_transaksi" initialized
INFO - 2023-11-12 12:14:44 --> Model "M_bank" initialized
INFO - 2023-11-12 12:14:44 --> Model "M_pesan" initialized
DEBUG - 2023-11-12 12:14:44 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-12 12:14:44 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-12 12:14:44 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-12 12:14:44 --> Final output sent to browser
DEBUG - 2023-11-12 12:14:44 --> Total execution time: 0.0451
ERROR - 2023-11-12 12:15:11 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-12 12:15:11 --> Config Class Initialized
INFO - 2023-11-12 12:15:11 --> Hooks Class Initialized
DEBUG - 2023-11-12 12:15:11 --> UTF-8 Support Enabled
INFO - 2023-11-12 12:15:11 --> Utf8 Class Initialized
INFO - 2023-11-12 12:15:11 --> URI Class Initialized
DEBUG - 2023-11-12 12:15:11 --> No URI present. Default controller set.
INFO - 2023-11-12 12:15:11 --> Router Class Initialized
INFO - 2023-11-12 12:15:11 --> Output Class Initialized
INFO - 2023-11-12 12:15:11 --> Security Class Initialized
DEBUG - 2023-11-12 12:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-12 12:15:11 --> Input Class Initialized
INFO - 2023-11-12 12:15:11 --> Language Class Initialized
INFO - 2023-11-12 12:15:11 --> Loader Class Initialized
INFO - 2023-11-12 12:15:11 --> Helper loaded: url_helper
INFO - 2023-11-12 12:15:11 --> Helper loaded: form_helper
INFO - 2023-11-12 12:15:11 --> Helper loaded: file_helper
INFO - 2023-11-12 12:15:11 --> Database Driver Class Initialized
DEBUG - 2023-11-12 12:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-12 12:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-12 12:15:11 --> Form Validation Class Initialized
INFO - 2023-11-12 12:15:11 --> Upload Class Initialized
INFO - 2023-11-12 12:15:11 --> Model "M_auth" initialized
INFO - 2023-11-12 12:15:11 --> Model "M_user" initialized
INFO - 2023-11-12 12:15:11 --> Model "M_produk" initialized
INFO - 2023-11-12 12:15:11 --> Controller Class Initialized
INFO - 2023-11-12 12:15:11 --> Model "M_pelanggan" initialized
INFO - 2023-11-12 12:15:11 --> Model "M_produk" initialized
DEBUG - 2023-11-12 12:15:11 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-12 12:15:11 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-12 12:15:11 --> Model "M_transaksi" initialized
INFO - 2023-11-12 12:15:11 --> Model "M_bank" initialized
INFO - 2023-11-12 12:15:11 --> Model "M_pesan" initialized
DEBUG - 2023-11-12 12:15:11 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-12 12:15:11 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-12 12:15:11 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-12 12:15:11 --> Final output sent to browser
DEBUG - 2023-11-12 12:15:11 --> Total execution time: 0.0043
ERROR - 2023-11-12 12:15:58 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-12 12:15:58 --> Config Class Initialized
INFO - 2023-11-12 12:15:58 --> Hooks Class Initialized
DEBUG - 2023-11-12 12:15:58 --> UTF-8 Support Enabled
INFO - 2023-11-12 12:15:58 --> Utf8 Class Initialized
INFO - 2023-11-12 12:15:58 --> URI Class Initialized
DEBUG - 2023-11-12 12:15:58 --> No URI present. Default controller set.
INFO - 2023-11-12 12:15:58 --> Router Class Initialized
INFO - 2023-11-12 12:15:58 --> Output Class Initialized
INFO - 2023-11-12 12:15:58 --> Security Class Initialized
DEBUG - 2023-11-12 12:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-12 12:15:58 --> Input Class Initialized
INFO - 2023-11-12 12:15:58 --> Language Class Initialized
INFO - 2023-11-12 12:15:58 --> Loader Class Initialized
INFO - 2023-11-12 12:15:58 --> Helper loaded: url_helper
INFO - 2023-11-12 12:15:58 --> Helper loaded: form_helper
INFO - 2023-11-12 12:15:58 --> Helper loaded: file_helper
INFO - 2023-11-12 12:15:58 --> Database Driver Class Initialized
DEBUG - 2023-11-12 12:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-12 12:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-12 12:15:58 --> Form Validation Class Initialized
INFO - 2023-11-12 12:15:58 --> Upload Class Initialized
INFO - 2023-11-12 12:15:58 --> Model "M_auth" initialized
INFO - 2023-11-12 12:15:58 --> Model "M_user" initialized
INFO - 2023-11-12 12:15:58 --> Model "M_produk" initialized
INFO - 2023-11-12 12:15:58 --> Controller Class Initialized
INFO - 2023-11-12 12:15:58 --> Model "M_pelanggan" initialized
INFO - 2023-11-12 12:15:58 --> Model "M_produk" initialized
DEBUG - 2023-11-12 12:15:58 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-12 12:15:58 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-12 12:15:58 --> Model "M_transaksi" initialized
INFO - 2023-11-12 12:15:58 --> Model "M_bank" initialized
INFO - 2023-11-12 12:15:58 --> Model "M_pesan" initialized
DEBUG - 2023-11-12 12:15:58 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-12 12:15:58 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-12 12:15:58 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-12 12:15:58 --> Final output sent to browser
DEBUG - 2023-11-12 12:15:58 --> Total execution time: 0.0041
ERROR - 2023-11-12 16:06:57 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-12 16:06:57 --> Config Class Initialized
INFO - 2023-11-12 16:06:57 --> Hooks Class Initialized
DEBUG - 2023-11-12 16:06:57 --> UTF-8 Support Enabled
INFO - 2023-11-12 16:06:57 --> Utf8 Class Initialized
INFO - 2023-11-12 16:06:57 --> URI Class Initialized
INFO - 2023-11-12 16:06:57 --> Router Class Initialized
INFO - 2023-11-12 16:06:57 --> Output Class Initialized
INFO - 2023-11-12 16:06:57 --> Security Class Initialized
DEBUG - 2023-11-12 16:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-12 16:06:57 --> Input Class Initialized
INFO - 2023-11-12 16:06:57 --> Language Class Initialized
INFO - 2023-11-12 16:06:57 --> Loader Class Initialized
INFO - 2023-11-12 16:06:57 --> Helper loaded: url_helper
INFO - 2023-11-12 16:06:57 --> Helper loaded: form_helper
INFO - 2023-11-12 16:06:57 --> Helper loaded: file_helper
INFO - 2023-11-12 16:06:57 --> Database Driver Class Initialized
DEBUG - 2023-11-12 16:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-12 16:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-12 16:06:57 --> Form Validation Class Initialized
INFO - 2023-11-12 16:06:57 --> Upload Class Initialized
INFO - 2023-11-12 16:06:57 --> Model "M_auth" initialized
INFO - 2023-11-12 16:06:57 --> Model "M_user" initialized
INFO - 2023-11-12 16:06:57 --> Model "M_produk" initialized
INFO - 2023-11-12 16:06:57 --> Controller Class Initialized
INFO - 2023-11-12 16:06:57 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-12 16:06:57 --> Final output sent to browser
DEBUG - 2023-11-12 16:06:57 --> Total execution time: 0.0335
ERROR - 2023-11-12 16:06:58 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-12 16:06:58 --> Config Class Initialized
INFO - 2023-11-12 16:06:58 --> Hooks Class Initialized
DEBUG - 2023-11-12 16:06:58 --> UTF-8 Support Enabled
INFO - 2023-11-12 16:06:58 --> Utf8 Class Initialized
INFO - 2023-11-12 16:06:58 --> URI Class Initialized
DEBUG - 2023-11-12 16:06:58 --> No URI present. Default controller set.
INFO - 2023-11-12 16:06:58 --> Router Class Initialized
INFO - 2023-11-12 16:06:58 --> Output Class Initialized
INFO - 2023-11-12 16:06:58 --> Security Class Initialized
DEBUG - 2023-11-12 16:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-12 16:06:58 --> Input Class Initialized
INFO - 2023-11-12 16:06:58 --> Language Class Initialized
INFO - 2023-11-12 16:06:58 --> Loader Class Initialized
INFO - 2023-11-12 16:06:58 --> Helper loaded: url_helper
INFO - 2023-11-12 16:06:58 --> Helper loaded: form_helper
INFO - 2023-11-12 16:06:58 --> Helper loaded: file_helper
INFO - 2023-11-12 16:06:58 --> Database Driver Class Initialized
DEBUG - 2023-11-12 16:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-12 16:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-12 16:06:58 --> Form Validation Class Initialized
INFO - 2023-11-12 16:06:58 --> Upload Class Initialized
INFO - 2023-11-12 16:06:58 --> Model "M_auth" initialized
INFO - 2023-11-12 16:06:58 --> Model "M_user" initialized
INFO - 2023-11-12 16:06:58 --> Model "M_produk" initialized
INFO - 2023-11-12 16:06:58 --> Controller Class Initialized
INFO - 2023-11-12 16:06:58 --> Model "M_pelanggan" initialized
INFO - 2023-11-12 16:06:58 --> Model "M_produk" initialized
DEBUG - 2023-11-12 16:06:58 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-12 16:06:58 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-12 16:06:58 --> Model "M_transaksi" initialized
INFO - 2023-11-12 16:06:58 --> Model "M_bank" initialized
INFO - 2023-11-12 16:06:58 --> Model "M_pesan" initialized
DEBUG - 2023-11-12 16:06:58 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-12 16:06:58 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-12 16:06:58 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-12 16:06:58 --> Final output sent to browser
DEBUG - 2023-11-12 16:06:58 --> Total execution time: 0.0115
ERROR - 2023-11-12 18:46:22 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-12 18:46:22 --> Config Class Initialized
INFO - 2023-11-12 18:46:22 --> Hooks Class Initialized
DEBUG - 2023-11-12 18:46:22 --> UTF-8 Support Enabled
INFO - 2023-11-12 18:46:22 --> Utf8 Class Initialized
INFO - 2023-11-12 18:46:22 --> URI Class Initialized
INFO - 2023-11-12 18:46:22 --> Router Class Initialized
INFO - 2023-11-12 18:46:22 --> Output Class Initialized
INFO - 2023-11-12 18:46:22 --> Security Class Initialized
DEBUG - 2023-11-12 18:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-12 18:46:22 --> Input Class Initialized
INFO - 2023-11-12 18:46:22 --> Language Class Initialized
INFO - 2023-11-12 18:46:22 --> Loader Class Initialized
INFO - 2023-11-12 18:46:22 --> Helper loaded: url_helper
INFO - 2023-11-12 18:46:22 --> Helper loaded: form_helper
INFO - 2023-11-12 18:46:22 --> Helper loaded: file_helper
INFO - 2023-11-12 18:46:22 --> Database Driver Class Initialized
DEBUG - 2023-11-12 18:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-12 18:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-12 18:46:22 --> Form Validation Class Initialized
INFO - 2023-11-12 18:46:22 --> Upload Class Initialized
INFO - 2023-11-12 18:46:22 --> Model "M_auth" initialized
INFO - 2023-11-12 18:46:22 --> Model "M_user" initialized
INFO - 2023-11-12 18:46:22 --> Model "M_produk" initialized
INFO - 2023-11-12 18:46:22 --> Controller Class Initialized
INFO - 2023-11-12 18:46:22 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-12 18:46:22 --> Final output sent to browser
DEBUG - 2023-11-12 18:46:22 --> Total execution time: 0.0406
ERROR - 2023-11-12 18:46:23 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-12 18:46:23 --> Config Class Initialized
INFO - 2023-11-12 18:46:23 --> Hooks Class Initialized
DEBUG - 2023-11-12 18:46:23 --> UTF-8 Support Enabled
INFO - 2023-11-12 18:46:23 --> Utf8 Class Initialized
INFO - 2023-11-12 18:46:23 --> URI Class Initialized
DEBUG - 2023-11-12 18:46:23 --> No URI present. Default controller set.
INFO - 2023-11-12 18:46:23 --> Router Class Initialized
INFO - 2023-11-12 18:46:23 --> Output Class Initialized
INFO - 2023-11-12 18:46:23 --> Security Class Initialized
DEBUG - 2023-11-12 18:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-12 18:46:23 --> Input Class Initialized
INFO - 2023-11-12 18:46:23 --> Language Class Initialized
INFO - 2023-11-12 18:46:23 --> Loader Class Initialized
INFO - 2023-11-12 18:46:23 --> Helper loaded: url_helper
INFO - 2023-11-12 18:46:23 --> Helper loaded: form_helper
INFO - 2023-11-12 18:46:23 --> Helper loaded: file_helper
INFO - 2023-11-12 18:46:23 --> Database Driver Class Initialized
DEBUG - 2023-11-12 18:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-12 18:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-12 18:46:23 --> Form Validation Class Initialized
INFO - 2023-11-12 18:46:23 --> Upload Class Initialized
INFO - 2023-11-12 18:46:23 --> Model "M_auth" initialized
INFO - 2023-11-12 18:46:23 --> Model "M_user" initialized
INFO - 2023-11-12 18:46:23 --> Model "M_produk" initialized
INFO - 2023-11-12 18:46:23 --> Controller Class Initialized
INFO - 2023-11-12 18:46:23 --> Model "M_pelanggan" initialized
INFO - 2023-11-12 18:46:23 --> Model "M_produk" initialized
DEBUG - 2023-11-12 18:46:23 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-12 18:46:23 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-12 18:46:23 --> Model "M_transaksi" initialized
INFO - 2023-11-12 18:46:23 --> Model "M_bank" initialized
INFO - 2023-11-12 18:46:23 --> Model "M_pesan" initialized
DEBUG - 2023-11-12 18:46:23 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-12 18:46:23 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-12 18:46:23 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-12 18:46:23 --> Final output sent to browser
DEBUG - 2023-11-12 18:46:23 --> Total execution time: 0.0188
ERROR - 2023-11-12 19:07:45 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-12 19:07:45 --> Config Class Initialized
INFO - 2023-11-12 19:07:45 --> Hooks Class Initialized
DEBUG - 2023-11-12 19:07:45 --> UTF-8 Support Enabled
INFO - 2023-11-12 19:07:45 --> Utf8 Class Initialized
INFO - 2023-11-12 19:07:45 --> URI Class Initialized
DEBUG - 2023-11-12 19:07:45 --> No URI present. Default controller set.
INFO - 2023-11-12 19:07:45 --> Router Class Initialized
INFO - 2023-11-12 19:07:45 --> Output Class Initialized
INFO - 2023-11-12 19:07:45 --> Security Class Initialized
DEBUG - 2023-11-12 19:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-12 19:07:45 --> Input Class Initialized
INFO - 2023-11-12 19:07:45 --> Language Class Initialized
INFO - 2023-11-12 19:07:45 --> Loader Class Initialized
INFO - 2023-11-12 19:07:45 --> Helper loaded: url_helper
INFO - 2023-11-12 19:07:45 --> Helper loaded: form_helper
INFO - 2023-11-12 19:07:45 --> Helper loaded: file_helper
INFO - 2023-11-12 19:07:45 --> Database Driver Class Initialized
DEBUG - 2023-11-12 19:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-12 19:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-12 19:07:45 --> Form Validation Class Initialized
INFO - 2023-11-12 19:07:45 --> Upload Class Initialized
INFO - 2023-11-12 19:07:45 --> Model "M_auth" initialized
INFO - 2023-11-12 19:07:45 --> Model "M_user" initialized
INFO - 2023-11-12 19:07:45 --> Model "M_produk" initialized
INFO - 2023-11-12 19:07:45 --> Controller Class Initialized
INFO - 2023-11-12 19:07:45 --> Model "M_pelanggan" initialized
INFO - 2023-11-12 19:07:45 --> Model "M_produk" initialized
DEBUG - 2023-11-12 19:07:45 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-12 19:07:45 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-12 19:07:45 --> Model "M_transaksi" initialized
INFO - 2023-11-12 19:07:45 --> Model "M_bank" initialized
INFO - 2023-11-12 19:07:45 --> Model "M_pesan" initialized
DEBUG - 2023-11-12 19:07:45 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-12 19:07:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-12 19:07:45 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-12 19:07:45 --> Final output sent to browser
DEBUG - 2023-11-12 19:07:45 --> Total execution time: 0.0389
ERROR - 2023-11-12 19:48:16 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-12 19:48:16 --> Config Class Initialized
INFO - 2023-11-12 19:48:16 --> Hooks Class Initialized
DEBUG - 2023-11-12 19:48:16 --> UTF-8 Support Enabled
INFO - 2023-11-12 19:48:16 --> Utf8 Class Initialized
INFO - 2023-11-12 19:48:16 --> URI Class Initialized
INFO - 2023-11-12 19:48:16 --> Router Class Initialized
INFO - 2023-11-12 19:48:16 --> Output Class Initialized
INFO - 2023-11-12 19:48:16 --> Security Class Initialized
DEBUG - 2023-11-12 19:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-12 19:48:16 --> Input Class Initialized
INFO - 2023-11-12 19:48:16 --> Language Class Initialized
INFO - 2023-11-12 19:48:16 --> Loader Class Initialized
INFO - 2023-11-12 19:48:16 --> Helper loaded: url_helper
INFO - 2023-11-12 19:48:16 --> Helper loaded: form_helper
INFO - 2023-11-12 19:48:16 --> Helper loaded: file_helper
INFO - 2023-11-12 19:48:16 --> Database Driver Class Initialized
DEBUG - 2023-11-12 19:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-12 19:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-12 19:48:16 --> Form Validation Class Initialized
INFO - 2023-11-12 19:48:16 --> Upload Class Initialized
INFO - 2023-11-12 19:48:16 --> Model "M_auth" initialized
INFO - 2023-11-12 19:48:16 --> Model "M_user" initialized
INFO - 2023-11-12 19:48:16 --> Model "M_produk" initialized
INFO - 2023-11-12 19:48:16 --> Controller Class Initialized
INFO - 2023-11-12 19:48:16 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/not_found.php
INFO - 2023-11-12 19:48:16 --> Final output sent to browser
DEBUG - 2023-11-12 19:48:16 --> Total execution time: 0.0360
ERROR - 2023-11-12 19:48:18 --> $config['composer_autoload'] is set to TRUE but /home/u967005227/domains/travelkuy.fun/public_html/application/vendor/autoload.php was not found.
INFO - 2023-11-12 19:48:18 --> Config Class Initialized
INFO - 2023-11-12 19:48:18 --> Hooks Class Initialized
DEBUG - 2023-11-12 19:48:18 --> UTF-8 Support Enabled
INFO - 2023-11-12 19:48:18 --> Utf8 Class Initialized
INFO - 2023-11-12 19:48:18 --> URI Class Initialized
DEBUG - 2023-11-12 19:48:18 --> No URI present. Default controller set.
INFO - 2023-11-12 19:48:18 --> Router Class Initialized
INFO - 2023-11-12 19:48:18 --> Output Class Initialized
INFO - 2023-11-12 19:48:18 --> Security Class Initialized
DEBUG - 2023-11-12 19:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-12 19:48:18 --> Input Class Initialized
INFO - 2023-11-12 19:48:18 --> Language Class Initialized
INFO - 2023-11-12 19:48:18 --> Loader Class Initialized
INFO - 2023-11-12 19:48:18 --> Helper loaded: url_helper
INFO - 2023-11-12 19:48:18 --> Helper loaded: form_helper
INFO - 2023-11-12 19:48:18 --> Helper loaded: file_helper
INFO - 2023-11-12 19:48:18 --> Database Driver Class Initialized
DEBUG - 2023-11-12 19:48:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-11-12 19:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-12 19:48:18 --> Form Validation Class Initialized
INFO - 2023-11-12 19:48:18 --> Upload Class Initialized
INFO - 2023-11-12 19:48:18 --> Model "M_auth" initialized
INFO - 2023-11-12 19:48:18 --> Model "M_user" initialized
INFO - 2023-11-12 19:48:18 --> Model "M_produk" initialized
INFO - 2023-11-12 19:48:18 --> Controller Class Initialized
INFO - 2023-11-12 19:48:18 --> Model "M_pelanggan" initialized
INFO - 2023-11-12 19:48:18 --> Model "M_produk" initialized
DEBUG - 2023-11-12 19:48:18 --> User_login class already loaded. Second attempt ignored.
DEBUG - 2023-11-12 19:48:18 --> Pelanggan_login class already loaded. Second attempt ignored.
INFO - 2023-11-12 19:48:18 --> Model "M_transaksi" initialized
INFO - 2023-11-12 19:48:18 --> Model "M_bank" initialized
INFO - 2023-11-12 19:48:18 --> Model "M_pesan" initialized
DEBUG - 2023-11-12 19:48:18 --> Config file loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/config/midtrans.php
INFO - 2023-11-12 19:48:18 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/footer.php
INFO - 2023-11-12 19:48:18 --> File loaded: /home/u967005227/domains/travelkuy.fun/public_html/application/views/front/index.php
INFO - 2023-11-12 19:48:18 --> Final output sent to browser
DEBUG - 2023-11-12 19:48:18 --> Total execution time: 0.0119
